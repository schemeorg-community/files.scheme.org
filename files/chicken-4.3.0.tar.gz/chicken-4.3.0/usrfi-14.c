/* Generated from srfi-14.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-12-14 09:03
   Version 4.2.0 - SVN rev. 16023
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-12-14 on galinha (Linux)
   command line: srfi-14.scm -optimize-level 2 -include-path . -include-path ./ -inline -explicit-use -no-trace -unsafe -no-lambda-info -output-file usrfi-14.c
   unit: srfi_14
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[105];
static double C_possibly_force_alignment;


C_noret_decl(C_srfi_14_toplevel)
C_externexport void C_ccall C_srfi_14_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_821)
static void C_ccall f_821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2901)
static void C_ccall f_2901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2905)
static void C_ccall f_2905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2909)
static void C_ccall f_2909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2912)
static void C_ccall f_2912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2915)
static void C_ccall f_2915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2918)
static void C_ccall f_2918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2922)
static void C_ccall f_2922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3013)
static void C_ccall f_3013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2925)
static void C_ccall f_2925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2930)
static void C_ccall f_2930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2933)
static void C_ccall f_2933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2937)
static void C_ccall f_2937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2941)
static void C_ccall f_2941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2945)
static void C_ccall f_2945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2949)
static void C_ccall f_2949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2952)
static void C_ccall f_2952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2955)
static void C_ccall f_2955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2959)
static void C_ccall f_2959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2962)
static void C_ccall f_2962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2965)
static void C_ccall f_2965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2969)
static void C_ccall f_2969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3001)
static void C_ccall f_3001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2973)
static void C_ccall f_2973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2977)
static void C_ccall f_2977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2997)
static void C_ccall f_2997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2981)
static void C_ccall f_2981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2993)
static void C_ccall f_2993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2985)
static void C_ccall f_2985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2989)
static void C_ccall f_2989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2872)
static void C_ccall f_2872(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2872)
static void C_ccall f_2872r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2897)
static void C_ccall f_2897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2876)
static void C_ccall f_2876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2879)
static void C_ccall f_2879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2882)
static void C_ccall f_2882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2889)
static void C_ccall f_2889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2893)
static void C_ccall f_2893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2821)
static void C_ccall f_2821(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2821)
static void C_ccall f_2821r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2825)
static void C_ccall f_2825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2828)
static void C_ccall f_2828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2839)
static void C_ccall f_2839(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2831)
static void C_ccall f_2831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2834)
static void C_ccall f_2834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2752)
static void C_fcall f_2752(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2758)
static void C_fcall f_2758(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2819)
static void C_ccall f_2819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2780)
static void C_ccall f_2780(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2771)
static void C_ccall f_2771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2688)
static void C_ccall f_2688(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2688)
static void C_ccall f_2688r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2743)
static void C_ccall f_2743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2698)
static void C_ccall f_2698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2710)
static void C_ccall f_2710(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2701)
static void C_ccall f_2701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2647)
static void C_ccall f_2647(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2647)
static void C_ccall f_2647r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2655)
static void C_ccall f_2655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2657)
static void C_ccall f_2657(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2651)
static void C_ccall f_2651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2606)
static void C_ccall f_2606(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2606)
static void C_ccall f_2606r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2642)
static void C_ccall f_2642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2616)
static void C_ccall f_2616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2624)
static void C_ccall f_2624(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2619)
static void C_ccall f_2619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2580)
static void C_ccall f_2580(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2580)
static void C_ccall f_2580r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2588)
static void C_ccall f_2588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2590)
static void C_ccall f_2590(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2584)
static void C_ccall f_2584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2535)
static void C_ccall f_2535(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2535)
static void C_ccall f_2535r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2571)
static void C_ccall f_2571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2545)
static void C_ccall f_2545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2557)
static void C_ccall f_2557(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2548)
static void C_ccall f_2548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2513)
static void C_ccall f_2513(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2513)
static void C_ccall f_2513r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2521)
static void C_ccall f_2521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2523)
static void C_ccall f_2523(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2517)
static void C_ccall f_2517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2464)
static void C_ccall f_2464(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2464)
static void C_ccall f_2464r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2504)
static void C_ccall f_2504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2474)
static void C_ccall f_2474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2486)
static void C_ccall f_2486(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2477)
static void C_ccall f_2477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2438)
static void C_ccall f_2438(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2438)
static void C_ccall f_2438r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2446)
static void C_ccall f_2446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2448)
static void C_ccall f_2448(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2442)
static void C_ccall f_2442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2416)
static void C_ccall f_2416(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2420)
static void C_ccall f_2420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2425)
static void C_ccall f_2425(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2423)
static void C_ccall f_2423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2388)
static void C_ccall f_2388(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2392)
static void C_ccall f_2392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2395)
static void C_ccall f_2395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2403)
static void C_ccall f_2403(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2398)
static void C_ccall f_2398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2330)
static void C_fcall f_2330(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2336)
static void C_fcall f_2336(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2349)
static void C_ccall f_2349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2361)
static void C_fcall f_2361(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2371)
static void C_ccall f_2371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2352)
static void C_ccall f_2352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2289)
static void C_fcall f_2289(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2299)
static void C_fcall f_2299(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2309)
static void C_ccall f_2309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2259)
static void C_ccall f_2259(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2266)
static void C_ccall f_2266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2245)
static void C_ccall f_2245(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2253)
static void C_ccall f_2253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2257)
static void C_ccall f_2257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2249)
static void C_ccall f_2249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2229)
static void C_ccall f_2229(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2229)
static void C_ccall f_2229r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2233)
static void C_ccall f_2233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2243)
static void C_ccall f_2243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2236)
static void C_ccall f_2236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2176)
static void C_fcall f_2176(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2182)
static void C_fcall f_2182(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2202)
static void C_ccall f_2202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2192)
static void C_fcall f_2192(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2166)
static void C_ccall f_2166(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2174)
static void C_ccall f_2174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2170)
static void C_ccall f_2170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2136)
static void C_ccall f_2136(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2136)
static void C_ccall f_2136r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2146)
static void C_ccall f_2146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2149)
static void C_ccall f_2149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2079)
static void C_fcall f_2079(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2122)
static void C_fcall f_2122(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2089)
static void C_ccall f_2089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2119)
static void C_ccall f_2119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2098)
static C_word C_fcall f_2098(C_word t0,C_word t1);
C_noret_decl(f_2023)
static void C_ccall f_2023(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2027)
static void C_ccall f_2027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2077)
static void C_ccall f_2077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2030)
static void C_ccall f_2030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2035)
static void C_fcall f_2035(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2045)
static void C_fcall f_2045(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2013)
static void C_ccall f_2013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2021)
static void C_ccall f_2021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2017)
static void C_ccall f_2017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2001)
static void C_ccall f_2001(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2001)
static void C_ccall f_2001r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2005)
static void C_ccall f_2005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2008)
static void C_ccall f_2008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1958)
static void C_fcall f_1958(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1971)
static C_word C_fcall f_1971(C_word t0,C_word t1);
C_noret_decl(f_1911)
static void C_ccall f_1911(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1915)
static void C_ccall f_1915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1920)
static void C_fcall f_1920(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1938)
static void C_fcall f_1938(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1901)
static void C_ccall f_1901(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1909)
static void C_ccall f_1909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1905)
static void C_ccall f_1905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1889)
static void C_ccall f_1889(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1889)
static void C_ccall f_1889r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1893)
static void C_ccall f_1893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1896)
static void C_ccall f_1896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1877)
static void C_ccall f_1877(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1877)
static void C_ccall f_1877r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1881)
static void C_ccall f_1881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1884)
static void C_ccall f_1884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1846)
static void C_fcall f_1846(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1852)
static C_word C_fcall f_1852(C_word t0,C_word t1);
C_noret_decl(f_1836)
static void C_ccall f_1836(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1844)
static void C_ccall f_1844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1840)
static void C_ccall f_1840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1824)
static void C_ccall f_1824(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_1824)
static void C_ccall f_1824r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_1828)
static void C_ccall f_1828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1831)
static void C_ccall f_1831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1788)
static void C_fcall f_1788(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1794)
static void C_fcall f_1794(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1822)
static void C_ccall f_1822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1818)
static void C_ccall f_1818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1814)
static void C_ccall f_1814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1735)
static void C_ccall f_1735(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1739)
static void C_ccall f_1739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1744)
static void C_fcall f_1744(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1754)
static void C_ccall f_1754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1686)
static void C_ccall f_1686(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1690)
static void C_ccall f_1690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1695)
static void C_fcall f_1695(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1711)
static void C_ccall f_1711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1639)
static void C_ccall f_1639(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1643)
static void C_ccall f_1643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1648)
static void C_fcall f_1648(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1666)
static void C_ccall f_1666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1576)
static void C_ccall f_1576(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1580)
static void C_ccall f_1580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1583)
static void C_ccall f_1583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1591)
static void C_fcall f_1591(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1621)
static void C_ccall f_1621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1601)
static void C_fcall f_1601(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1586)
static void C_ccall f_1586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1526)
static void C_ccall f_1526(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1530)
static void C_ccall f_1530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1535)
static void C_fcall f_1535(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1545)
static void C_ccall f_1545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1484)
static void C_fcall f_1484(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1488)
static void C_ccall f_1488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1493)
static void C_fcall f_1493(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1506)
static void C_fcall f_1506(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1475)
static void C_ccall f_1475(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1469)
static void C_ccall f_1469(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1463)
static void C_ccall f_1463(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1457)
static void C_ccall f_1457(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1445)
static void C_ccall f_1445(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1445)
static void C_ccall f_1445r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1451)
static void C_ccall f_1451(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1433)
static void C_ccall f_1433(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1433)
static void C_ccall f_1433r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1439)
static void C_ccall f_1439(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1421)
static void C_ccall f_1421(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1421)
static void C_ccall f_1421r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1427)
static void C_ccall f_1427(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1409)
static void C_ccall f_1409(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1409)
static void C_ccall f_1409r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1415)
static void C_ccall f_1415(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1374)
static void C_fcall f_1374(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1378)
static void C_ccall f_1378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1383)
static void C_fcall f_1383(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1396)
static void C_ccall f_1396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1381)
static void C_ccall f_1381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1332)
static void C_fcall f_1332(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1372)
static void C_ccall f_1372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1336)
static void C_ccall f_1336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1344)
static void C_fcall f_1344(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1357)
static void C_ccall f_1357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1339)
static void C_ccall f_1339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1275)
static void C_ccall f_1275(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1279)
static void C_ccall f_1279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1284)
static void C_fcall f_1284(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1305)
static void C_ccall f_1305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1238)
static void C_ccall f_1238(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1242)
static void C_ccall f_1242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1247)
static C_word C_fcall f_1247(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_1211)
static void C_ccall f_1211(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1218)
static void C_ccall f_1218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1110)
static void C_ccall f_1110(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1110)
static void C_ccall f_1110r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1117)
static void C_fcall f_1117(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1123)
static void C_ccall f_1123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1131)
static void C_fcall f_1131(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1152)
static void C_fcall f_1152(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1176)
static C_word C_fcall f_1176(C_word t0,C_word t1);
C_noret_decl(f_1012)
static void C_ccall f_1012(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1012)
static void C_ccall f_1012r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1032)
static void C_ccall f_1032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1034)
static void C_fcall f_1034(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1044)
static void C_ccall f_1044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1061)
static void C_fcall f_1061(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_957)
static void C_ccall f_957(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_957)
static void C_ccall f_957r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_973)
static void C_ccall f_973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_978)
static void C_fcall f_978(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1002)
static void C_ccall f_1002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_943)
static void C_ccall f_943(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_955)
static void C_ccall f_955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_951)
static void C_ccall f_951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_910)
static void C_fcall f_910(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_916)
static void C_fcall f_916(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_923)
static void C_ccall f_923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_933)
static void C_ccall f_933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_863)
static void C_fcall f_863(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_888)
static void C_ccall f_888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_895)
static void C_ccall f_895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_853)
static void C_fcall f_853(C_word t0,C_word t1) C_noret;
C_noret_decl(f_847)
static void C_ccall f_847(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_841)
static void C_ccall f_841(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_835)
static void C_ccall f_835(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_823)
static void C_ccall f_823(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_2752)
static void C_fcall trf_2752(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2752(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2752(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2758)
static void C_fcall trf_2758(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2758(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2758(t0,t1,t2);}

C_noret_decl(trf_2330)
static void C_fcall trf_2330(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2330(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2330(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2336)
static void C_fcall trf_2336(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2336(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2336(t0,t1,t2);}

C_noret_decl(trf_2361)
static void C_fcall trf_2361(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2361(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2361(t0,t1,t2);}

C_noret_decl(trf_2289)
static void C_fcall trf_2289(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2289(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2289(t0,t1,t2);}

C_noret_decl(trf_2299)
static void C_fcall trf_2299(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2299(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2299(t0,t1,t2);}

C_noret_decl(trf_2176)
static void C_fcall trf_2176(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2176(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2176(t0,t1,t2,t3);}

C_noret_decl(trf_2182)
static void C_fcall trf_2182(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2182(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2182(t0,t1,t2);}

C_noret_decl(trf_2192)
static void C_fcall trf_2192(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2192(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2192(t0,t1);}

C_noret_decl(trf_2079)
static void C_fcall trf_2079(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2079(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2079(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2122)
static void C_fcall trf_2122(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2122(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2122(t0,t1);}

C_noret_decl(trf_2035)
static void C_fcall trf_2035(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2035(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2035(t0,t1,t2,t3);}

C_noret_decl(trf_2045)
static void C_fcall trf_2045(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2045(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2045(t0,t1);}

C_noret_decl(trf_1958)
static void C_fcall trf_1958(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1958(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1958(t0,t1,t2,t3);}

C_noret_decl(trf_1920)
static void C_fcall trf_1920(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1920(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1920(t0,t1,t2,t3);}

C_noret_decl(trf_1938)
static void C_fcall trf_1938(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1938(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1938(t0,t1);}

C_noret_decl(trf_1846)
static void C_fcall trf_1846(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1846(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1846(t0,t1,t2);}

C_noret_decl(trf_1788)
static void C_fcall trf_1788(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1788(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1788(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1794)
static void C_fcall trf_1794(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1794(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1794(t0,t1,t2);}

C_noret_decl(trf_1744)
static void C_fcall trf_1744(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1744(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1744(t0,t1,t2);}

C_noret_decl(trf_1695)
static void C_fcall trf_1695(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1695(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1695(t0,t1,t2);}

C_noret_decl(trf_1648)
static void C_fcall trf_1648(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1648(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1648(t0,t1,t2,t3);}

C_noret_decl(trf_1591)
static void C_fcall trf_1591(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1591(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1591(t0,t1,t2);}

C_noret_decl(trf_1601)
static void C_fcall trf_1601(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1601(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1601(t0,t1);}

C_noret_decl(trf_1535)
static void C_fcall trf_1535(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1535(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1535(t0,t1,t2);}

C_noret_decl(trf_1484)
static void C_fcall trf_1484(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1484(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1484(t0,t1,t2,t3);}

C_noret_decl(trf_1493)
static void C_fcall trf_1493(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1493(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1493(t0,t1,t2);}

C_noret_decl(trf_1506)
static void C_fcall trf_1506(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1506(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1506(t0,t1);}

C_noret_decl(trf_1374)
static void C_fcall trf_1374(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1374(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1374(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1383)
static void C_fcall trf_1383(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1383(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1383(t0,t1,t2);}

C_noret_decl(trf_1332)
static void C_fcall trf_1332(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1332(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1332(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1344)
static void C_fcall trf_1344(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1344(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1344(t0,t1,t2);}

C_noret_decl(trf_1284)
static void C_fcall trf_1284(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1284(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1284(t0,t1,t2,t3);}

C_noret_decl(trf_1117)
static void C_fcall trf_1117(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1117(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1117(t0,t1);}

C_noret_decl(trf_1131)
static void C_fcall trf_1131(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1131(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1131(t0,t1,t2,t3);}

C_noret_decl(trf_1152)
static void C_fcall trf_1152(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1152(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1152(t0,t1);}

C_noret_decl(trf_1034)
static void C_fcall trf_1034(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1034(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1034(t0,t1,t2,t3);}

C_noret_decl(trf_1061)
static void C_fcall trf_1061(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1061(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1061(t0,t1,t2);}

C_noret_decl(trf_978)
static void C_fcall trf_978(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_978(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_978(t0,t1,t2);}

C_noret_decl(trf_910)
static void C_fcall trf_910(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_910(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_910(t0,t1,t2);}

C_noret_decl(trf_916)
static void C_fcall trf_916(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_916(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_916(t0,t1,t2);}

C_noret_decl(trf_863)
static void C_fcall trf_863(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_863(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_863(t0,t1,t2);}

C_noret_decl(trf_853)
static void C_fcall trf_853(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_853(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_853(t0,t1);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_14_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_14_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_14_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(852)){
C_save(t1);
C_rereclaim2(852*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,105);
lf[1]=C_h_intern(&lf[1],13,"make-char-set");
lf[2]=C_h_intern(&lf[2],8,"char-set");
lf[3]=C_h_intern(&lf[3],10,"char-set:s");
lf[4]=C_h_intern(&lf[4],9,"char-set\077");
lf[6]=C_h_intern(&lf[6],13,"\003syssubstring");
lf[8]=C_h_intern(&lf[8],9,"\003syserror");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000 BASE-CS parameter not a char-set");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\0003Expected final base char set -- too many parameters");
lf[11]=C_h_intern(&lf[11],11,"make-string");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\000\016Not a char-set");
lf[16]=C_h_intern(&lf[16],13,"char-set-copy");
lf[17]=C_h_intern(&lf[17],9,"char-set=");
lf[18]=C_h_intern(&lf[18],10,"char-set<=");
lf[19]=C_h_intern(&lf[19],13,"char-set-hash");
lf[20]=C_h_intern(&lf[20],6,"modulo");
lf[21]=C_h_intern(&lf[21],18,"char-set-contains\077");
lf[22]=C_h_intern(&lf[22],13,"char-set-size");
lf[23]=C_h_intern(&lf[23],14,"char-set-count");
lf[26]=C_h_intern(&lf[26],15,"char-set-adjoin");
lf[27]=C_h_intern(&lf[27],16,"char-set-adjoin!");
lf[28]=C_h_intern(&lf[28],15,"char-set-delete");
lf[29]=C_h_intern(&lf[29],16,"char-set-delete!");
lf[30]=C_h_intern(&lf[30],15,"char-set-cursor");
lf[32]=C_h_intern(&lf[32],16,"end-of-char-set\077");
lf[33]=C_h_intern(&lf[33],12,"char-set-ref");
lf[34]=C_h_intern(&lf[34],20,"char-set-cursor-next");
lf[35]=C_h_intern(&lf[35],17,"char-set-for-each");
lf[36]=C_h_intern(&lf[36],12,"char-set-map");
lf[37]=C_h_intern(&lf[37],13,"char-set-fold");
lf[38]=C_h_intern(&lf[38],14,"char-set-every");
lf[39]=C_h_intern(&lf[39],12,"char-set-any");
lf[41]=C_h_intern(&lf[41],15,"char-set-unfold");
lf[42]=C_h_intern(&lf[42],16,"char-set-unfold!");
lf[44]=C_h_intern(&lf[44],14,"list->char-set");
lf[45]=C_h_intern(&lf[45],15,"list->char-set!");
lf[46]=C_h_intern(&lf[46],14,"char-set->list");
lf[48]=C_h_intern(&lf[48],16,"string->char-set");
lf[49]=C_h_intern(&lf[49],17,"string->char-set!");
lf[50]=C_h_intern(&lf[50],16,"char-set->string");
lf[52]=C_h_intern(&lf[52],3,"min");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000`Requested UCS range contains unavailable characters -- this implementation "
"only supports Latin-1");
lf[54]=C_h_intern(&lf[54],19,"ucs-range->char-set");
lf[55]=C_h_intern(&lf[55],20,"ucs-range->char-set!");
lf[57]=C_h_intern(&lf[57],15,"char-set-filter");
lf[58]=C_h_intern(&lf[58],16,"char-set-filter!");
lf[59]=C_h_intern(&lf[59],10,"->char-set");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\036Not a charset, string or char.");
lf[63]=C_h_intern(&lf[63],19,"char-set-complement");
lf[64]=C_h_intern(&lf[64],20,"char-set-complement!");
lf[65]=C_h_intern(&lf[65],15,"char-set-union!");
lf[66]=C_h_intern(&lf[66],14,"char-set-union");
lf[67]=C_h_intern(&lf[67],14,"char-set:empty");
lf[68]=C_h_intern(&lf[68],22,"char-set-intersection!");
lf[69]=C_h_intern(&lf[69],21,"char-set-intersection");
lf[70]=C_h_intern(&lf[70],13,"char-set:full");
lf[71]=C_h_intern(&lf[71],20,"char-set-difference!");
lf[72]=C_h_intern(&lf[72],19,"char-set-difference");
lf[73]=C_h_intern(&lf[73],13,"char-set-xor!");
lf[74]=C_h_intern(&lf[74],12,"char-set-xor");
lf[76]=C_h_intern(&lf[76],27,"char-set-diff+intersection!");
lf[77]=C_h_intern(&lf[77],26,"char-set-diff+intersection");
lf[78]=C_h_intern(&lf[78],11,"string-copy");
lf[79]=C_h_intern(&lf[79],19,"char-set:lower-case");
lf[80]=C_h_intern(&lf[80],19,"char-set:upper-case");
lf[81]=C_h_intern(&lf[81],19,"char-set:title-case");
lf[82]=C_h_intern(&lf[82],15,"char-set:letter");
lf[83]=C_h_intern(&lf[83],14,"char-set:digit");
lf[84]=C_h_intern(&lf[84],18,"char-set:hex-digit");
lf[85]=C_h_intern(&lf[85],21,"char-set:letter+digit");
lf[86]=C_h_intern(&lf[86],20,"char-set:punctuation");
lf[87]=C_h_intern(&lf[87],15,"char-set:symbol");
lf[88]=C_h_intern(&lf[88],16,"char-set:graphic");
lf[89]=C_h_intern(&lf[89],19,"char-set:whitespace");
lf[90]=C_h_intern(&lf[90],17,"char-set:printing");
lf[91]=C_h_intern(&lf[91],14,"char-set:blank");
lf[92]=C_h_intern(&lf[92],20,"char-set:iso-control");
lf[93]=C_h_intern(&lf[93],14,"char-set:ascii");
lf[94]=C_h_intern(&lf[94],7,"\003sysmap");
lf[95]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\011\376\003\000\000\002\376\377\001\000\000\000 \376\003\000\000\002\376\377\001\000\000\000\240\376\377\016");
lf[96]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\011\376\003\000\000\002\376\377\001\000\000\000\012\376\003\000\000\002\376\377\001\000\000\000\013\376\003\000\000\002\376\377\001\000\000\000\014\376\003\000\000\002\376\377\001\000\000\000\015\376\003\000\000\002\376\377\001\000\000\000 \376\003\000\000\002\376\377\001"
"\000\000\000\240\376\377\016");
lf[97]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\242\376\003\000\000\002\376\377\001\000\000\000\243\376\003\000\000\002\376\377\001\000\000\000\244\376\003\000\000\002\376\377\001\000\000\000\245\376\003\000\000\002\376\377\001\000\000\000\246\376\003\000\000\002\376\377\001\000\000\000\247\376\003\000\000\002\376\377\001"
"\000\000\000\250\376\003\000\000\002\376\377\001\000\000\000\251\376\003\000\000\002\376\377\001\000\000\000\254\376\003\000\000\002\376\377\001\000\000\000\256\376\003\000\000\002\376\377\001\000\000\000\257\376\003\000\000\002\376\377\001\000\000\000\260\376\003\000\000\002\376\377\001\000\000\000\261\376\003\000\000"
"\002\376\377\001\000\000\000\264\376\003\000\000\002\376\377\001\000\000\000\266\376\003\000\000\002\376\377\001\000\000\000\270\376\003\000\000\002\376\377\001\000\000\000\327\376\003\000\000\002\376\377\001\000\000\000\367\376\377\016");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\011$+<=>^`|~");
lf[99]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\241\376\003\000\000\002\376\377\001\000\000\000\253\376\003\000\000\002\376\377\001\000\000\000\255\376\003\000\000\002\376\377\001\000\000\000\267\376\003\000\000\002\376\377\001\000\000\000\273\376\003\000\000\002\376\377\001\000\000\000\277\376\377\016");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\027!\042#%&\047()*,-./:;\077@[\134]_{}");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\0260123456789abcdefABCDEF");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\0120123456789");
lf[103]=C_h_intern(&lf[103],17,"register-feature!");
lf[104]=C_h_intern(&lf[104],7,"srfi-14");
C_register_lf2(lf,105,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_821,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 28   register-feature! */
t3=*((C_word*)lf[103]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[104]);}

/* k819 */
static void C_ccall f_821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word ab[131],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_821,2,t0,t1);}
t2=C_mutate(&lf[0] /* (set! %latin1->char ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_823,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[1]+1 /* (set! make-char-set ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_835,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[3]+1 /* (set! char-set:s ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_841,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[4]+1 /* (set! char-set? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_847,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate(&lf[5] /* (set! %string-copy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_853,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate(&lf[7] /* (set! %default-base ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_863,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate(&lf[12] /* (set! %char-set:s/check ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_910,tmp=(C_word)a,a+=2,tmp));
t9=(C_word)C_make_character((C_word)C_unfix(C_fix(0)));
t10=C_mutate(&lf[14] /* (set! c0 ...) */,t9);
t11=(C_word)C_make_character((C_word)C_unfix(C_fix(1)));
t12=C_mutate(&lf[15] /* (set! c1 ...) */,t11);
t13=C_mutate((C_word*)lf[16]+1 /* (set! char-set-copy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_943,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[17]+1 /* (set! char-set= ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_957,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[18]+1 /* (set! char-set<= ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1012,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[19]+1 /* (set! char-set-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1110,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[21]+1 /* (set! char-set-contains? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1211,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[22]+1 /* (set! char-set-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1238,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[23]+1 /* (set! char-set-count ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1275,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate(&lf[24] /* (set! %set-char-set ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1332,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate(&lf[25] /* (set! %set-char-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1374,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[26]+1 /* (set! char-set-adjoin ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1409,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[27]+1 /* (set! char-set-adjoin! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1421,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[28]+1 /* (set! char-set-delete ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1433,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[29]+1 /* (set! char-set-delete! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1445,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[30]+1 /* (set! char-set-cursor ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1457,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[32]+1 /* (set! end-of-char-set? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1463,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[33]+1 /* (set! char-set-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1469,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[34]+1 /* (set! char-set-cursor-next ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1475,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate(&lf[31] /* (set! %char-set-cursor-next ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1484,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[35]+1 /* (set! char-set-for-each ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1526,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[36]+1 /* (set! char-set-map ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1576,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[37]+1 /* (set! char-set-fold ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1639,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[38]+1 /* (set! char-set-every ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1686,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[39]+1 /* (set! char-set-any ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1735,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate(&lf[40] /* (set! %char-set-unfold! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1788,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[41]+1 /* (set! char-set-unfold ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1824,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate((C_word*)lf[42]+1 /* (set! char-set-unfold! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1836,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate(&lf[43] /* (set! %list->char-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1846,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate((C_word*)lf[2]+1 /* (set! char-set ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1877,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate((C_word*)lf[44]+1 /* (set! list->char-set ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1889,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[45]+1 /* (set! list->char-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1901,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[46]+1 /* (set! char-set->list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1911,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate(&lf[47] /* (set! %string->char-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1958,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[48]+1 /* (set! string->char-set ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2001,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[49]+1 /* (set! string->char-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2013,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[50]+1 /* (set! char-set->string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2023,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate(&lf[51] /* (set! %ucs-range->char-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2079,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[54]+1 /* (set! ucs-range->char-set ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2136,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[55]+1 /* (set! ucs-range->char-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2166,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate(&lf[56] /* (set! %char-set-filter! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2176,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[57]+1 /* (set! char-set-filter ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2229,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[58]+1 /* (set! char-set-filter! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2245,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate((C_word*)lf[59]+1 /* (set! ->char-set ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2259,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate(&lf[61] /* (set! %string-iter ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2289,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate(&lf[62] /* (set! %char-set-algebra ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2330,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[63]+1 /* (set! char-set-complement ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2388,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[64]+1 /* (set! char-set-complement! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2416,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate((C_word*)lf[65]+1 /* (set! char-set-union! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2438,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[66]+1 /* (set! char-set-union ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2464,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate((C_word*)lf[68]+1 /* (set! char-set-intersection! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2513,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[69]+1 /* (set! char-set-intersection ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2535,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[71]+1 /* (set! char-set-difference! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2580,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[72]+1 /* (set! char-set-difference ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2606,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[73]+1 /* (set! char-set-xor! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2647,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[74]+1 /* (set! char-set-xor ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2688,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate(&lf[75] /* (set! %char-set-diff+intersection! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2752,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate((C_word*)lf[76]+1 /* (set! char-set-diff+intersection! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2821,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate((C_word*)lf[77]+1 /* (set! char-set-diff+intersection ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2872,tmp=(C_word)a,a+=2,tmp));
t70=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2901,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 643  char-set */
t71=*((C_word*)lf[2]+1);
((C_proc2)(void*)(*((C_word*)t71+1)))(2,t71,t70);}

/* k2899 in k819 */
static void C_ccall f_2901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2901,2,t0,t1);}
t2=C_mutate((C_word*)lf[67]+1 /* (set! char-set:empty ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2905,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 644  char-set-complement */
t4=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[67]+1));}

/* k2903 in k2899 in k819 */
static void C_ccall f_2905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2905,2,t0,t1);}
t2=C_mutate((C_word*)lf[70]+1 /* (set! char-set:full ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2909,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 647  ucs-range->char-set */
t4=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(97),C_fix(123));}

/* k2907 in k2903 in k2899 in k819 */
static void C_ccall f_2909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2909,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2912,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 648  ucs-range->char-set! */
t3=*((C_word*)lf[55]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,C_fix(223),C_fix(247),C_SCHEME_TRUE,t1);}

/* k2910 in k2907 in k2903 in k2899 in k819 */
static void C_ccall f_2912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2912,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2915,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 649  ucs-range->char-set! */
t3=*((C_word*)lf[55]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,C_fix(248),C_fix(256),C_SCHEME_TRUE,t1);}

/* k2913 in k2910 in k2907 in k2903 in k2899 in k819 */
static void C_ccall f_2915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2918,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_make_character((C_word)C_unfix(C_fix(181)));
/* srfi-14.scm: 650  char-set-adjoin! */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t1,t3);}

/* k2916 in k2913 in k2910 in k2907 in k2903 in k2899 in k819 */
static void C_ccall f_2918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2918,2,t0,t1);}
t2=C_mutate((C_word*)lf[79]+1 /* (set! char-set:lower-case ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2922,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 653  ucs-range->char-set */
t4=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(65),C_fix(91));}

/* k2920 in k2916 in k2913 in k2910 in k2907 in k2903 in k2899 in k819 */
static void C_ccall f_2922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2925,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3013,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 656  ucs-range->char-set! */
t4=*((C_word*)lf[55]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,C_fix(192),C_fix(215),C_SCHEME_TRUE,t1);}

/* k3011 in k2920 in k2916 in k2913 in k2910 in k2907 in k2903 in k2899 in k819 */
static void C_ccall f_3013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 655  ucs-range->char-set! */
t2=*((C_word*)lf[55]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],C_fix(216),C_fix(223),C_SCHEME_TRUE,t1);}

/* k2923 in k2920 in k2916 in k2913 in k2910 in k2907 in k2903 in k2899 in k819 */
static void C_ccall f_2925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2925,2,t0,t1);}
t2=C_mutate((C_word*)lf[80]+1 /* (set! char-set:upper-case ...) */,t1);
t3=C_mutate((C_word*)lf[81]+1 /* (set! char-set:title-case ...) */,*((C_word*)lf[67]+1));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2930,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 661  char-set-union */
t5=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[80]+1),*((C_word*)lf[79]+1));}

/* k2928 in k2923 in k2920 in k2916 in k2913 in k2910 in k2907 in k2903 in k2899 in k819 */
static void C_ccall f_2930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2933,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_make_character((C_word)C_unfix(C_fix(170)));
t4=(C_word)C_make_character((C_word)C_unfix(C_fix(186)));
/* srfi-14.scm: 662  char-set-adjoin! */
t5=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,t1,t3,t4);}

/* k2931 in k2928 in k2923 in k2920 in k2916 in k2913 in k2910 in k2907 in k2903 in k2899 in k819 */
static void C_ccall f_2933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2933,2,t0,t1);}
t2=C_mutate((C_word*)lf[82]+1 /* (set! char-set:letter ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2937,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 666  string->char-set */
t4=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[102]);}

/* k2935 in k2931 in k2928 in k2923 in k2920 in k2916 in k2913 in k2910 in k2907 in k2903 in k2899 in k819 */
static void C_ccall f_2937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2937,2,t0,t1);}
t2=C_mutate((C_word*)lf[83]+1 /* (set! char-set:digit ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2941,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 667  string->char-set */
t4=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[101]);}

/* k2939 in k2935 in k2931 in k2928 in k2923 in k2920 in k2916 in k2913 in k2910 in k2907 in k2903 in k2899 in k819 */
static void C_ccall f_2941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2941,2,t0,t1);}
t2=C_mutate((C_word*)lf[84]+1 /* (set! char-set:hex-digit ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2945,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 670  char-set-union */
t4=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[82]+1),*((C_word*)lf[83]+1));}

/* k2943 in k2939 in k2935 in k2931 in k2928 in k2923 in k2920 in k2916 in k2913 in k2910 in k2907 in k2903 in k2899 in k819 */
static void C_ccall f_2945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2945,2,t0,t1);}
t2=C_mutate((C_word*)lf[85]+1 /* (set! char-set:letter+digit ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2949,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 673  string->char-set */
t4=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[100]);}

/* k2947 in k2943 in k2939 in k2935 in k2931 in k2928 in k2923 in k2920 in k2916 in k2913 in k2910 in k2907 in k2903 in k2899 in k819 */
static void C_ccall f_2949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2949,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2952,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[0],lf[99]);}

/* k2950 in k2947 in k2943 in k2939 in k2935 in k2931 in k2928 in k2923 in k2920 in k2916 in k2913 in k2910 in k2907 in k2903 in k2899 in k819 */
static void C_ccall f_2952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2955,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 680  list->char-set! */
t3=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k2953 in k2950 in k2947 in k2943 in k2939 in k2935 in k2931 in k2928 in k2923 in k2920 in k2916 in k2913 in k2910 in k2907 in k2903 in k2899 in k819 */
static void C_ccall f_2955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2955,2,t0,t1);}
t2=C_mutate((C_word*)lf[86]+1 /* (set! char-set:punctuation ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2959,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 683  string->char-set */
t4=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[98]);}

/* k2957 in k2953 in k2950 in k2947 in k2943 in k2939 in k2935 in k2931 in k2928 in k2923 in k2920 in k2916 in k2913 in k2910 in k2907 in k2903 in k2899 in k819 */
static void C_ccall f_2959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2959,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2962,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[0],lf[97]);}

/* k2960 in k2957 in k2953 in k2950 in k2947 in k2943 in k2939 in k2935 in k2931 in k2928 in k2923 in k2920 in k2916 in k2913 in k2910 in k2907 in k2903 in k2899 in k819 */
static void C_ccall f_2962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2962,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2965,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 702  list->char-set! */
t3=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k2963 in k2960 in k2957 in k2953 in k2950 in k2947 in k2943 in k2939 in k2935 in k2931 in k2928 in k2923 in k2920 in k2916 in k2913 in k2910 in k2907 in k2903 in k2899 in k819 */
static void C_ccall f_2965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2965,2,t0,t1);}
t2=C_mutate((C_word*)lf[87]+1 /* (set! char-set:symbol ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2969,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 706  char-set-union */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,*((C_word*)lf[85]+1),*((C_word*)lf[86]+1),*((C_word*)lf[87]+1));}

/* k2967 in k2963 in k2960 in k2957 in k2953 in k2950 in k2947 in k2943 in k2939 in k2935 in k2931 in k2928 in k2923 in k2920 in k2916 in k2913 in k2910 in k2907 in k2903 in k2899 in k819 */
static void C_ccall f_2969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2969,2,t0,t1);}
t2=C_mutate((C_word*)lf[88]+1 /* (set! char-set:graphic ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2973,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3001,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[0],lf[96]);}

/* k2999 in k2967 in k2963 in k2960 in k2957 in k2953 in k2950 in k2947 in k2943 in k2939 in k2935 in k2931 in k2928 in k2923 in k2920 in k2916 in k2913 in k2910 in k2907 in k2903 in k2899 in k819 */
static void C_ccall f_3001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 709  list->char-set */
t2=*((C_word*)lf[44]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2971 in k2967 in k2963 in k2960 in k2957 in k2953 in k2950 in k2947 in k2943 in k2939 in k2935 in k2931 in k2928 in k2923 in k2920 in k2916 in k2913 in k2910 in k2907 in k2903 in k2899 in k819 */
static void C_ccall f_2973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2973,2,t0,t1);}
t2=C_mutate((C_word*)lf[89]+1 /* (set! char-set:whitespace ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2977,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 717  char-set-union */
t4=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[89]+1),*((C_word*)lf[88]+1));}

/* k2975 in k2971 in k2967 in k2963 in k2960 in k2957 in k2953 in k2950 in k2947 in k2943 in k2939 in k2935 in k2931 in k2928 in k2923 in k2920 in k2916 in k2913 in k2910 in k2907 in k2903 in k2899 in k819 */
static void C_ccall f_2977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2977,2,t0,t1);}
t2=C_mutate((C_word*)lf[90]+1 /* (set! char-set:printing ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2981,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2997,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[0],lf[95]);}

/* k2995 in k2975 in k2971 in k2967 in k2963 in k2960 in k2957 in k2953 in k2950 in k2947 in k2943 in k2939 in k2935 in k2931 in k2928 in k2923 in k2920 in k2916 in k2913 in k2910 in k2907 in k2903 in k2899 in k819 */
static void C_ccall f_2997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 720  list->char-set */
t2=*((C_word*)lf[44]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2979 in k2975 in k2971 in k2967 in k2963 in k2960 in k2957 in k2953 in k2950 in k2947 in k2943 in k2939 in k2935 in k2931 in k2928 in k2923 in k2920 in k2916 in k2913 in k2910 in k2907 in k2903 in k2899 in k819 */
static void C_ccall f_2981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2981,2,t0,t1);}
t2=C_mutate((C_word*)lf[91]+1 /* (set! char-set:blank ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2985,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2993,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 726  ucs-range->char-set */
t5=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_fix(0),C_fix(32));}

/* k2991 in k2979 in k2975 in k2971 in k2967 in k2963 in k2960 in k2957 in k2953 in k2950 in k2947 in k2943 in k2939 in k2935 in k2931 in k2928 in k2923 in k2920 in k2916 in k2913 in k2910 in k2907 in k2903 in k2899 in k819 */
static void C_ccall f_2993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 726  ucs-range->char-set! */
t2=*((C_word*)lf[55]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],C_fix(127),C_fix(160),C_SCHEME_TRUE,t1);}

/* k2983 in k2979 in k2975 in k2971 in k2967 in k2963 in k2960 in k2957 in k2953 in k2950 in k2947 in k2943 in k2939 in k2935 in k2931 in k2928 in k2923 in k2920 in k2916 in k2913 in k2910 in k2907 in k2903 in k2899 in k819 */
static void C_ccall f_2985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2985,2,t0,t1);}
t2=C_mutate((C_word*)lf[92]+1 /* (set! char-set:iso-control ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2989,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 728  ucs-range->char-set */
t4=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(0),C_fix(128));}

/* k2987 in k2983 in k2979 in k2975 in k2971 in k2967 in k2963 in k2960 in k2957 in k2953 in k2950 in k2947 in k2943 in k2939 in k2935 in k2931 in k2928 in k2923 in k2920 in k2916 in k2913 in k2910 in k2907 in k2903 in k2899 in k819 */
static void C_ccall f_2989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[93]+1 /* (set! char-set:ascii ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* char-set-diff+intersection in k819 */
static void C_ccall f_2872(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_2872r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2872r(t0,t1,t2,t3);}}

static void C_ccall f_2872r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2876,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2897,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 629  %char-set:s/check */
f_910(t5,t2,lf[77]);}

/* k2895 in char-set-diff+intersection in k819 */
static void C_ccall f_2897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 629  string-copy */
t2=*((C_word*)lf[78]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2874 in char-set-diff+intersection in k819 */
static void C_ccall f_2876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2876,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2879,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 630  make-string */
t3=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(256),lf[14]);}

/* k2877 in k2874 in char-set-diff+intersection in k819 */
static void C_ccall f_2879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2879,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2882,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 631  %char-set-diff+intersection! */
f_2752(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],lf[77]);}

/* k2880 in k2877 in k2874 in char-set-diff+intersection in k819 */
static void C_ccall f_2882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2882,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2889,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 632  make-char-set */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2887 in k2880 in k2877 in k2874 in char-set-diff+intersection in k819 */
static void C_ccall f_2889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2889,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2893,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 632  make-char-set */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2891 in k2887 in k2880 in k2877 in k2874 in char-set-diff+intersection in k819 */
static void C_ccall f_2893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 632  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* char-set-diff+intersection! in k819 */
static void C_ccall f_2821(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_2821r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2821r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2821r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2825,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-14.scm: 619  %char-set:s/check */
f_910(t5,t2,lf[76]);}

/* k2823 in char-set-diff+intersection! in k819 */
static void C_ccall f_2825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2825,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2828,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* srfi-14.scm: 620  %char-set:s/check */
f_910(t2,((C_word*)t0)[3],lf[76]);}

/* k2826 in k2823 in char-set-diff+intersection! in k819 */
static void C_ccall f_2828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2828,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2831,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2839,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 621  %string-iter */
f_2289(t2,t3,((C_word*)t0)[3]);}

/* a2838 in k2826 in k2823 in char-set-diff+intersection! in k819 */
static void C_ccall f_2839(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2839,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t2;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_setsubchar(((C_word*)t0)[3],t5,lf[14]));}
else{
t5=t2;
t6=(C_word)C_subchar(((C_word*)t0)[3],t5);
t7=(C_word)C_fix((C_word)C_character_code(t6));
t8=(C_word)C_eqp(t7,C_fix(0));
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}
else{
t9=t2;
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_setsubchar(((C_word*)t0)[2],t9,lf[14]));}}}

/* k2829 in k2826 in k2823 in char-set-diff+intersection! in k819 */
static void C_ccall f_2831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2834,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 625  %char-set-diff+intersection! */
f_2752(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[76]);}

/* k2832 in k2829 in k2826 in k2823 in char-set-diff+intersection! in k819 */
static void C_ccall f_2834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 626  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %char-set-diff+intersection! in k819 */
static void C_fcall f_2752(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2752,NULL,5,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2758,a[2]=t5,a[3]=t3,a[4]=t2,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_2758(t9,t1,t4);}

/* loop670 in %char-set-diff+intersection! in k819 */
static void C_fcall f_2758(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2758,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2771,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2780,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2819,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 615  %char-set:s/check */
f_910(t6,t3,((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2817 in loop670 in %char-set-diff+intersection! in k819 */
static void C_ccall f_2819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 610  %string-iter */
f_2289(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2779 in loop670 in %char-set-diff+intersection! in k819 */
static void C_ccall f_2780(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2780,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=((C_word*)t0)[3];
t6=t2;
t7=(C_word)C_subchar(t5,t6);
t8=(C_word)C_fix((C_word)C_character_code(t7));
t9=(C_word)C_eqp(t8,C_fix(0));
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}
else{
t10=((C_word*)t0)[3];
t11=t2;
t12=(C_word)C_setsubchar(t10,t11,lf[14]);
t13=((C_word*)t0)[2];
t14=t2;
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_setsubchar(t13,t14,lf[15]));}}}

/* k2769 in loop670 in %char-set-diff+intersection! in k819 */
static void C_ccall f_2771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2758(t3,((C_word*)t0)[2],t2);}

/* char-set-xor in k819 */
static void C_ccall f_2688(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_2688r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2688r(t0,t1,t2);}}

static void C_ccall f_2688r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2698,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2743,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_u_i_car(t2);
/* srfi-14.scm: 600  %char-set:s/check */
f_910(t4,t5,lf[74]);}
else{
/* srfi-14.scm: 603  char-set-copy */
t3=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,*((C_word*)lf[67]+1));}}

/* k2741 in char-set-xor in k819 */
static void C_ccall f_2743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 600  %string-copy */
f_853(((C_word*)t0)[2],t1);}

/* k2696 in char-set-xor in k819 */
static void C_ccall f_2698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2698,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2701,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2710,tmp=(C_word)a,a+=2,tmp);
/* srfi-14.scm: 601  %char-set-algebra */
f_2330(t2,t1,t3,t4,lf[74]);}

/* a2709 in k2696 in char-set-xor in k819 */
static void C_ccall f_2710(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2710,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=t2;
t7=t3;
t8=t2;
t9=t3;
t10=(C_word)C_subchar(t8,t9);
t11=(C_word)C_fix((C_word)C_character_code(t10));
t12=(C_word)C_u_fixnum_difference(C_fix(1),t11);
t13=(C_word)C_make_character((C_word)C_unfix(t12));
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_setsubchar(t6,t7,t13));}}

/* k2699 in k2696 in char-set-xor in k819 */
static void C_ccall f_2701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 602  make-char-set */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-xor! in k819 */
static void C_ccall f_2647(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_2647r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2647r(t0,t1,t2,t3);}}

static void C_ccall f_2647r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2651,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2655,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 594  %char-set:s/check */
f_910(t5,t2,lf[73]);}

/* k2653 in char-set-xor! in k819 */
static void C_ccall f_2655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2655,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2657,tmp=(C_word)a,a+=2,tmp);
/* srfi-14.scm: 594  %char-set-algebra */
f_2330(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2,lf[73]);}

/* a2656 in k2653 in char-set-xor! in k819 */
static void C_ccall f_2657(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2657,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=t2;
t7=t3;
t8=t2;
t9=t3;
t10=(C_word)C_subchar(t8,t9);
t11=(C_word)C_fix((C_word)C_character_code(t10));
t12=(C_word)C_u_fixnum_difference(C_fix(1),t11);
t13=(C_word)C_make_character((C_word)C_unfix(t12));
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_setsubchar(t6,t7,t13));}}

/* k2649 in char-set-xor! in k819 */
static void C_ccall f_2651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-difference in k819 */
static void C_ccall f_2606(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_2606r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2606r(t0,t1,t2,t3);}}

static void C_ccall f_2606r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2616,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2642,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 585  %char-set:s/check */
f_910(t5,t2,lf[72]);}
else{
/* srfi-14.scm: 588  char-set-copy */
t4=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}}

/* k2640 in char-set-difference in k819 */
static void C_ccall f_2642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 585  %string-copy */
f_853(((C_word*)t0)[2],t1);}

/* k2614 in char-set-difference in k819 */
static void C_ccall f_2616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2619,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2624,tmp=(C_word)a,a+=2,tmp);
/* srfi-14.scm: 586  %char-set-algebra */
f_2330(t2,t1,((C_word*)t0)[2],t3,lf[72]);}

/* a2623 in k2614 in char-set-difference in k819 */
static void C_ccall f_2624(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2624,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?C_SCHEME_UNDEFINED:(C_word)C_setsubchar(t2,t3,lf[14])));}

/* k2617 in k2614 in char-set-difference in k819 */
static void C_ccall f_2619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 587  make-char-set */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-difference! in k819 */
static void C_ccall f_2580(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_2580r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2580r(t0,t1,t2,t3);}}

static void C_ccall f_2580r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2584,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2588,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 579  %char-set:s/check */
f_910(t5,t2,lf[71]);}

/* k2586 in char-set-difference! in k819 */
static void C_ccall f_2588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2588,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2590,tmp=(C_word)a,a+=2,tmp);
/* srfi-14.scm: 579  %char-set-algebra */
f_2330(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2,lf[71]);}

/* a2589 in k2586 in char-set-difference! in k819 */
static void C_ccall f_2590(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2590,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?C_SCHEME_UNDEFINED:(C_word)C_setsubchar(t2,t3,lf[14])));}

/* k2582 in char-set-difference! in k819 */
static void C_ccall f_2584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-intersection in k819 */
static void C_ccall f_2535(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_2535r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2535r(t0,t1,t2);}}

static void C_ccall f_2535r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2545,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2571,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_u_i_car(t2);
/* srfi-14.scm: 570  %char-set:s/check */
f_910(t4,t5,lf[69]);}
else{
/* srfi-14.scm: 573  char-set-copy */
t3=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,*((C_word*)lf[70]+1));}}

/* k2569 in char-set-intersection in k819 */
static void C_ccall f_2571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 570  %string-copy */
f_853(((C_word*)t0)[2],t1);}

/* k2543 in char-set-intersection in k819 */
static void C_ccall f_2545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2548,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2557,tmp=(C_word)a,a+=2,tmp);
/* srfi-14.scm: 571  %char-set-algebra */
f_2330(t2,t1,t3,t4,lf[69]);}

/* a2556 in k2543 in char-set-intersection in k819 */
static void C_ccall f_2557(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2557,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?(C_word)C_setsubchar(t2,t3,lf[14]):C_SCHEME_UNDEFINED));}

/* k2546 in k2543 in char-set-intersection in k819 */
static void C_ccall f_2548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 572  make-char-set */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-intersection! in k819 */
static void C_ccall f_2513(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_2513r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2513r(t0,t1,t2,t3);}}

static void C_ccall f_2513r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2517,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2521,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 564  %char-set:s/check */
f_910(t5,t2,lf[68]);}

/* k2519 in char-set-intersection! in k819 */
static void C_ccall f_2521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2523,tmp=(C_word)a,a+=2,tmp);
/* srfi-14.scm: 564  %char-set-algebra */
f_2330(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2,lf[68]);}

/* a2522 in k2519 in char-set-intersection! in k819 */
static void C_ccall f_2523(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2523,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?(C_word)C_setsubchar(t2,t3,lf[14]):C_SCHEME_UNDEFINED));}

/* k2515 in char-set-intersection! in k819 */
static void C_ccall f_2517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-union in k819 */
static void C_ccall f_2464(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_2464r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2464r(t0,t1,t2);}}

static void C_ccall f_2464r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2474,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2504,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_u_i_car(t2);
/* srfi-14.scm: 555  %char-set:s/check */
f_910(t4,t5,lf[66]);}
else{
/* srfi-14.scm: 558  char-set-copy */
t3=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,*((C_word*)lf[67]+1));}}

/* k2502 in char-set-union in k819 */
static void C_ccall f_2504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 555  %string-copy */
f_853(((C_word*)t0)[2],t1);}

/* k2472 in char-set-union in k819 */
static void C_ccall f_2474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2477,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2486,tmp=(C_word)a,a+=2,tmp);
/* srfi-14.scm: 556  %char-set-algebra */
f_2330(t2,t1,t3,t4,lf[66]);}

/* a2485 in k2472 in char-set-union in k819 */
static void C_ccall f_2486(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2486,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?C_SCHEME_UNDEFINED:(C_word)C_setsubchar(t2,t3,lf[15])));}

/* k2475 in k2472 in char-set-union in k819 */
static void C_ccall f_2477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 557  make-char-set */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-union! in k819 */
static void C_ccall f_2438(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_2438r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2438r(t0,t1,t2,t3);}}

static void C_ccall f_2438r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2442,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2446,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 549  %char-set:s/check */
f_910(t5,t2,lf[65]);}

/* k2444 in char-set-union! in k819 */
static void C_ccall f_2446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2448,tmp=(C_word)a,a+=2,tmp);
/* srfi-14.scm: 549  %char-set-algebra */
f_2330(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2,lf[65]);}

/* a2447 in k2444 in char-set-union! in k819 */
static void C_ccall f_2448(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2448,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?C_SCHEME_UNDEFINED:(C_word)C_setsubchar(t2,t3,lf[15])));}

/* k2440 in char-set-union! in k819 */
static void C_ccall f_2442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-complement! in k819 */
static void C_ccall f_2416(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2416,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2420,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 541  %char-set:s/check */
f_910(t3,t2,lf[64]);}

/* k2418 in char-set-complement! in k819 */
static void C_ccall f_2420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2420,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2423,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2425,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 542  %string-iter */
f_2289(t2,t3,t1);}

/* a2424 in k2418 in char-set-complement! in k819 */
static void C_ccall f_2425(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2425,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(C_fix(1),t3);
t5=(C_word)C_make_character((C_word)C_unfix(t4));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_setsubchar(((C_word*)t0)[2],t2,t5));}

/* k2421 in k2418 in char-set-complement! in k819 */
static void C_ccall f_2423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-complement in k819 */
static void C_ccall f_2388(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2388,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2392,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 535  %char-set:s/check */
f_910(t3,t2,lf[63]);}

/* k2390 in char-set-complement in k819 */
static void C_ccall f_2392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2395,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 536  make-string */
t3=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix(256));}

/* k2393 in k2390 in char-set-complement in k819 */
static void C_ccall f_2395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2398,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2403,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 537  %string-iter */
f_2289(t2,t3,((C_word*)t0)[2]);}

/* a2402 in k2393 in k2390 in char-set-complement in k819 */
static void C_ccall f_2403(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2403,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(C_fix(1),t3);
t5=(C_word)C_make_character((C_word)C_unfix(t4));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_setsubchar(((C_word*)t0)[2],t2,t5));}

/* k2396 in k2393 in k2390 in char-set-complement in k819 */
static void C_ccall f_2398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 538  make-char-set */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %char-set-algebra in k819 */
static void C_fcall f_2330(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2330,NULL,5,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2336,a[2]=t5,a[3]=t2,a[4]=t4,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_2336(t9,t1,t3);}

/* loop538 in %char-set-algebra in k819 */
static void C_fcall f_2336(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2336,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2349,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* srfi-14.scm: 524  %char-set:s/check */
f_910(t4,t3,((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2347 in loop538 in %char-set-algebra in k819 */
static void C_ccall f_2349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2349,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2352,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2361,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2361(t6,t2,C_fix(255));}

/* lp in k2347 in loop538 in %char-set-algebra in k819 */
static void C_fcall f_2361(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2361,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2371,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=(C_word)C_subchar(((C_word*)t0)[4],t5);
t7=(C_word)C_fix((C_word)C_character_code(t6));
/* srfi-14.scm: 527  op */
t8=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t4,((C_word*)t0)[2],t2,t7);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k2369 in lp in k2347 in loop538 in %char-set-algebra in k819 */
static void C_ccall f_2371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm: 528  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2361(t3,((C_word*)t0)[2],t2);}

/* k2350 in k2347 in loop538 in %char-set-algebra in k819 */
static void C_ccall f_2352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2336(t3,((C_word*)t0)[2],t2);}

/* %string-iter in k819 */
static void C_fcall f_2289(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2289,NULL,3,t1,t2,t3);}
t4=(C_word)C_fix((C_word)C_header_size(t3));
t5=(C_word)C_u_fixnum_difference(t4,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2299,a[2]=t2,a[3]=t3,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_2299(t9,t1,t5);}

/* lp in %string-iter in k819 */
static void C_fcall f_2299(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2299,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2309,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_subchar(((C_word*)t0)[3],t2);
t6=(C_word)C_fix((C_word)C_character_code(t5));
/* srfi-14.scm: 513  p */
t7=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t2,t6);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k2307 in lp in %string-iter in k819 */
static void C_ccall f_2309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm: 514  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2299(t3,((C_word*)t0)[2],t2);}

/* ->char-set in k819 */
static void C_ccall f_2259(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2259,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2266,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 490  char-set? */
t4=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2264 in ->char-set in k819 */
static void C_ccall f_2266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[2]))){
/* srfi-14.scm: 491  string->char-set */
t2=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[2]))){
/* srfi-14.scm: 492  char-set */
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* srfi-14.scm: 493  ##sys#error */
t2=*((C_word*)lf[8]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[59],lf[60],((C_word*)t0)[2]);}}}}

/* char-set-filter! in k819 */
static void C_ccall f_2245(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2245,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2249,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2253,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 481  %char-set:s/check */
f_910(t6,t3,lf[58]);}

/* k2251 in char-set-filter! in k819 */
static void C_ccall f_2253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2253,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2257,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 482  %char-set:s/check */
f_910(t2,((C_word*)t0)[2],lf[58]);}

/* k2255 in k2251 in char-set-filter! in k819 */
static void C_ccall f_2257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 480  %char-set-filter! */
f_2176(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2247 in char-set-filter! in k819 */
static void C_ccall f_2249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-filter in k819 */
static void C_ccall f_2229(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_2229r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2229r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2229r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2233,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 472  %default-base */
f_863(t5,t4,*((C_word*)lf[57]+1));}

/* k2231 in char-set-filter in k819 */
static void C_ccall f_2233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2233,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2236,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2243,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 474  %char-set:s/check */
f_910(t3,((C_word*)t0)[2],lf[58]);}

/* k2241 in k2231 in char-set-filter in k819 */
static void C_ccall f_2243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 473  %char-set-filter! */
f_2176(((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2234 in k2231 in char-set-filter in k819 */
static void C_ccall f_2236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 477  make-char-set */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %char-set-filter! in k819 */
static void C_fcall f_2176(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2176,NULL,4,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2182,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_2182(t8,t1,C_fix(255));}

/* lp in %char-set-filter! in k819 */
static void C_fcall f_2182(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2182,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2192,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2202,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=((C_word*)t0)[3];
t7=t2;
t8=(C_word)C_subchar(t6,t7);
t9=(C_word)C_fix((C_word)C_character_code(t8));
t10=(C_word)C_eqp(t9,C_fix(0));
if(C_truep(t10)){
t11=t5;
f_2202(2,t11,C_SCHEME_FALSE);}
else{
t11=t2;
t12=(C_word)C_make_character((C_word)C_unfix(t11));
/* srfi-14.scm: 467  pred */
t13=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t5,t12);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k2200 in lp in %char-set-filter! in k819 */
static void C_ccall f_2202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
f_2192(t4,(C_word)C_setsubchar(t2,t3,lf[15]));}
else{
t2=((C_word*)t0)[2];
f_2192(t2,C_SCHEME_UNDEFINED);}}

/* k2190 in lp in %char-set-filter! in k819 */
static void C_fcall f_2192(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm: 469  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2182(t3,((C_word*)t0)[2],t2);}

/* ucs-range->char-set! in k819 */
static void C_ccall f_2166(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2166,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2170,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2174,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* srfi-14.scm: 456  %char-set:s/check */
f_910(t7,t5,lf[55]);}

/* k2172 in ucs-range->char-set! in k819 */
static void C_ccall f_2174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 455  %ucs-range->char-set! */
f_2079(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[54]);}

/* k2168 in ucs-range->char-set! in k819 */
static void C_ccall f_2170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ucs-range->char-set in k819 */
static void C_ccall f_2136(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_2136r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2136r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2136r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_u_i_car(t4));
t7=(C_word)C_i_nullp(t4);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t4,C_fix(1)));
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2146,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-14.scm: 450  %default-base */
f_863(t9,t8,*((C_word*)lf[54]+1));}

/* k2144 in ucs-range->char-set in k819 */
static void C_ccall f_2146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2146,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2149,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 451  %ucs-range->char-set! */
f_2079(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[54]);}

/* k2147 in k2144 in ucs-range->char-set in k819 */
static void C_ccall f_2149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 452  make-char-set */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %ucs-range->char-set! in k819 */
static void C_fcall f_2079(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2079,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_exact_2(t2,t6);
t8=(C_word)C_i_check_exact_2(t3,t6);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2089,a[2]=t3,a[3]=t1,a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2122,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
t11=t2;
t12=t3;
if(C_truep((C_word)C_fixnum_lessp(t11,t12))){
t13=t3;
t14=(C_word)C_fixnum_lessp(C_fix(256),t13);
t15=t10;
f_2122(t15,(C_truep(t14)?t4:C_SCHEME_FALSE));}
else{
t13=t10;
f_2122(t13,C_SCHEME_FALSE);}}

/* k2120 in %ucs-range->char-set! in k819 */
static void C_fcall f_2122(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-14.scm: 442  ##sys#error */
t2=*((C_word*)lf[8]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],lf[53],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_2089(2,t2,C_SCHEME_UNDEFINED);}}

/* k2087 in %ucs-range->char-set! in k819 */
static void C_ccall f_2089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2089,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2119,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 445  min */
t3=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(256));}

/* k2117 in k2087 in %ucs-range->char-set! in k819 */
static void C_ccall f_2119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2119,2,t0,t1);}
t2=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2098,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_2098(t3,t2));}

/* lp in k2117 in k2087 in %ucs-range->char-set! in k819 */
static C_word C_fcall f_2098(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
t2=((C_word*)t0)[3];
t3=t1;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,t3))){
t4=((C_word*)t0)[2];
t5=t1;
t6=(C_word)C_setsubchar(t4,t5,lf[15]);
t7=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t9=t7;
t1=t9;
goto loop;}
else{
return(C_SCHEME_UNDEFINED);}}

/* char-set->string in k819 */
static void C_ccall f_2023(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2023,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2027,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 423  %char-set:s/check */
f_910(t3,t2,lf[50]);}

/* k2025 in char-set->string in k819 */
static void C_ccall f_2027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2030,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2077,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 424  char-set-size */
t4=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k2075 in k2025 in char-set->string in k819 */
static void C_ccall f_2077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 424  make-string */
t2=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2028 in k2025 in char-set->string in k819 */
static void C_ccall f_2030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2030,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2035,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2035(t5,((C_word*)t0)[2],C_fix(255),C_fix(0));}

/* lp in k2028 in k2025 in char-set->string in k819 */
static void C_fcall f_2035(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2035,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2045,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=t2;
t7=(C_word)C_subchar(((C_word*)t0)[2],t6);
t8=(C_word)C_fix((C_word)C_character_code(t7));
t9=(C_word)C_eqp(t8,C_fix(0));
if(C_truep(t9)){
t10=t5;
f_2045(t10,t3);}
else{
t10=t2;
t11=(C_word)C_make_character((C_word)C_unfix(t10));
t12=(C_word)C_setsubchar(((C_word*)t0)[4],t3,t11);
t13=t5;
f_2045(t13,(C_word)C_u_fixnum_plus(t3,C_fix(1)));}}}

/* k2043 in lp in k2028 in k2025 in char-set->string in k819 */
static void C_fcall f_2045(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm: 430  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2035(t3,((C_word*)t0)[2],t2,t1);}

/* string->char-set! in k819 */
static void C_ccall f_2013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2013,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2017,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2021,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 417  %char-set:s/check */
f_910(t5,t3,lf[49]);}

/* k2019 in string->char-set! in k819 */
static void C_ccall f_2021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 417  %string->char-set! */
f_1958(((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[49]);}

/* k2015 in string->char-set! in k819 */
static void C_ccall f_2017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* string->char-set in k819 */
static void C_ccall f_2001(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2001r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2001r(t0,t1,t2,t3);}}

static void C_ccall f_2001r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2005,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 412  %default-base */
f_863(t4,t3,*((C_word*)lf[48]+1));}

/* k2003 in string->char-set in k819 */
static void C_ccall f_2005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2005,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2008,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 413  %string->char-set! */
f_1958(t2,((C_word*)t0)[2],t1,lf[48]);}

/* k2006 in k2003 in string->char-set in k819 */
static void C_ccall f_2008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 414  make-char-set */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string->char-set! in k819 */
static void C_fcall f_1958(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1958,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(C_word)C_fix((C_word)C_header_size(t2));
t7=(C_word)C_u_fixnum_difference(t6,C_fix(1));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1971,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,f_1971(t8,t7));}

/* doloop397 in %string->char-set! in k819 */
static C_word C_fcall f_1971(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
t2=t1;
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
return(C_SCHEME_UNDEFINED);}
else{
t3=((C_word*)t0)[3];
t4=(C_word)C_subchar(((C_word*)t0)[2],t1);
t5=(C_word)C_fix((C_word)C_character_code(t4));
t6=(C_word)C_setsubchar(t3,t5,lf[15]);
t7=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t9=t7;
t1=t9;
goto loop;}}

/* char-set->list in k819 */
static void C_ccall f_1911(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1911,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1915,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 393  %char-set:s/check */
f_910(t3,t2,lf[46]);}

/* k1913 in char-set->list in k819 */
static void C_ccall f_1915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1915,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1920,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_1920(t5,((C_word*)t0)[2],C_fix(255),C_SCHEME_END_OF_LIST);}

/* lp in k1913 in char-set->list in k819 */
static void C_fcall f_1920(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1920,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1938,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=t2;
t8=(C_word)C_subchar(((C_word*)t0)[2],t7);
t9=(C_word)C_fix((C_word)C_character_code(t8));
t10=(C_word)C_eqp(t9,C_fix(0));
if(C_truep(t10)){
t11=t6;
f_1938(t11,t3);}
else{
t11=t2;
t12=(C_word)C_make_character((C_word)C_unfix(t11));
t13=t6;
f_1938(t13,(C_word)C_a_i_cons(&a,2,t12,t3));}}}

/* k1936 in lp in k1913 in char-set->list in k819 */
static void C_fcall f_1938(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 396  lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1920(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* list->char-set! in k819 */
static void C_ccall f_1901(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1901,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1905,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1909,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 388  %char-set:s/check */
f_910(t5,t3,lf[45]);}

/* k1907 in list->char-set! in k819 */
static void C_ccall f_1909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 388  %list->char-set! */
f_1846(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1903 in list->char-set! in k819 */
static void C_ccall f_1905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* list->char-set in k819 */
static void C_ccall f_1889(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1889r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1889r(t0,t1,t2,t3);}}

static void C_ccall f_1889r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1893,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 383  %default-base */
f_863(t4,t3,*((C_word*)lf[44]+1));}

/* k1891 in list->char-set in k819 */
static void C_ccall f_1893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1896,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 384  %list->char-set! */
f_1846(t2,((C_word*)t0)[2],t1);}

/* k1894 in k1891 in list->char-set in k819 */
static void C_ccall f_1896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 385  make-char-set */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set in k819 */
static void C_ccall f_1877(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1877r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1877r(t0,t1,t2);}}

static void C_ccall f_1877r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1881,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 378  make-string */
t4=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(256),lf[14]);}

/* k1879 in char-set in k819 */
static void C_ccall f_1881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1884,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 379  %list->char-set! */
f_1846(t2,((C_word*)t0)[2],t1);}

/* k1882 in k1879 in char-set in k819 */
static void C_ccall f_1884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 380  make-char-set */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %list->char-set! in k819 */
static void C_fcall f_1846(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1846,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1852,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_1852(t4,t2));}

/* loop361 in %list->char-set! in k819 */
static C_word C_fcall f_1852(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_slot(t1,C_fix(0));
t3=((C_word*)t0)[2];
t4=(C_word)C_fix((C_word)C_character_code(t2));
t5=(C_word)C_setsubchar(t3,t4,lf[15]);
t6=(C_word)C_slot(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}
else{
return(C_SCHEME_UNDEFINED);}}

/* char-set-unfold! in k819 */
static void C_ccall f_1836(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_1836,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1840,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1844,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* srfi-14.scm: 365  %char-set:s/check */
f_910(t8,t6,lf[42]);}

/* k1842 in char-set-unfold! in k819 */
static void C_ccall f_1844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 364  %char-set-unfold! */
f_1788(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1838 in char-set-unfold! in k819 */
static void C_ccall f_1840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-unfold in k819 */
static void C_ccall f_1824(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr6r,(void*)f_1824r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_1824r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_1824r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word *a=C_alloc(7);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1828,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-14.scm: 359  %default-base */
f_863(t7,t6,*((C_word*)lf[41]+1));}

/* k1826 in char-set-unfold in k819 */
static void C_ccall f_1828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1828,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1831,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 360  %char-set-unfold! */
f_1788(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1829 in k1826 in char-set-unfold in k819 */
static void C_ccall f_1831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 361  make-char-set */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %char-set-unfold! in k819 */
static void C_fcall f_1788(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1788,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1794,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t8,a[6]=t5,tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_1794(t10,t1,t6);}

/* lp in %char-set-unfold! in k819 */
static void C_fcall f_1794(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1794,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1822,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* srfi-14.scm: 354  p */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k1820 in lp in %char-set-unfold! in k819 */
static void C_ccall f_1822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1822,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=((C_word*)t0)[6];
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1818,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* srfi-14.scm: 355  f */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}}

/* k1816 in k1820 in lp in %char-set-unfold! in k819 */
static void C_ccall f_1818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1818,2,t0,t1);}
t2=(C_word)C_fix((C_word)C_character_code(t1));
t3=(C_word)C_setsubchar(((C_word*)t0)[6],t2,lf[15]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1814,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 356  g */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k1812 in k1816 in k1820 in lp in %char-set-unfold! in k819 */
static void C_ccall f_1814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 356  lp */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1794(t2,((C_word*)t0)[2],t1);}

/* char-set-any in k819 */
static void C_ccall f_1735(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1735,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1739,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 342  %char-set:s/check */
f_910(t4,t3,lf[39]);}

/* k1737 in char-set-any in k819 */
static void C_ccall f_1739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1739,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1744,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1744(t5,((C_word*)t0)[2],C_fix(255));}

/* lp in k1737 in char-set-any in k819 */
static void C_fcall f_1744(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1744,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1754,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=(C_word)C_subchar(((C_word*)t0)[3],t5);
t7=(C_word)C_fix((C_word)C_character_code(t6));
t8=(C_word)C_eqp(t7,C_fix(0));
if(C_truep(t8)){
t9=t4;
f_1754(2,t9,C_SCHEME_FALSE);}
else{
t9=t2;
t10=(C_word)C_make_character((C_word)C_unfix(t9));
/* srfi-14.scm: 345  pred */
t11=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t4,t10);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k1752 in lp in k1737 in char-set-any in k819 */
static void C_ccall f_1754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* srfi-14.scm: 346  lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1744(t3,((C_word*)t0)[4],t2);}}

/* char-set-every in k819 */
static void C_ccall f_1686(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1686,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1690,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 334  %char-set:s/check */
f_910(t4,t3,lf[38]);}

/* k1688 in char-set-every in k819 */
static void C_ccall f_1690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1690,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1695,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1695(t5,((C_word*)t0)[2],C_fix(255));}

/* lp in k1688 in char-set-every in k819 */
static void C_fcall f_1695(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1695,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_fixnum_lessp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=t2;
t6=(C_word)C_subchar(((C_word*)t0)[4],t5);
t7=(C_word)C_fix((C_word)C_character_code(t6));
t8=(C_word)C_eqp(t7,C_fix(0));
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1711,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t8)){
t10=t9;
f_1711(2,t10,t8);}
else{
t10=t2;
t11=(C_word)C_make_character((C_word)C_unfix(t10));
/* srfi-14.scm: 337  pred */
t12=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t9,t11);}}}

/* k1709 in lp in k1688 in char-set-every in k819 */
static void C_ccall f_1711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm: 338  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1695(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* char-set-fold in k819 */
static void C_ccall f_1639(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1639,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1643,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 325  %char-set:s/check */
f_910(t5,t4,lf[37]);}

/* k1641 in char-set-fold in k819 */
static void C_ccall f_1643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1643,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1648,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1648(t5,((C_word*)t0)[3],C_fix(255),((C_word*)t0)[2]);}

/* lp in k1641 in char-set-fold in k819 */
static void C_fcall f_1648(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1648,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1666,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=t2;
t8=(C_word)C_subchar(((C_word*)t0)[3],t7);
t9=(C_word)C_fix((C_word)C_character_code(t8));
t10=(C_word)C_eqp(t9,C_fix(0));
if(C_truep(t10)){
t11=t6;
f_1666(2,t11,t3);}
else{
t11=t2;
t12=(C_word)C_make_character((C_word)C_unfix(t11));
/* srfi-14.scm: 330  kons */
t13=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t6,t12,t3);}}}

/* k1664 in lp in k1641 in char-set-fold in k819 */
static void C_ccall f_1666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 328  lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1648(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* char-set-map in k819 */
static void C_ccall f_1576(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1576,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1580,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 314  %char-set:s/check */
f_910(t4,t3,lf[36]);}

/* k1578 in char-set-map in k819 */
static void C_ccall f_1580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1580,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1583,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 315  make-string */
t3=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(256),lf[14]);}

/* k1581 in k1578 in char-set-map in k819 */
static void C_ccall f_1583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1583,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1586,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1591,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_1591(t6,t2,C_fix(255));}

/* lp in k1581 in k1578 in char-set-map in k819 */
static void C_fcall f_1591(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1591,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1601,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=(C_word)C_subchar(((C_word*)t0)[4],t5);
t7=(C_word)C_fix((C_word)C_character_code(t6));
t8=(C_word)C_eqp(t7,C_fix(0));
if(C_truep(t8)){
t9=t4;
f_1601(t9,C_SCHEME_UNDEFINED);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1621,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t10=t2;
t11=(C_word)C_make_character((C_word)C_unfix(t10));
/* srfi-14.scm: 319  proc */
t12=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t9,t11);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1619 in lp in k1581 in k1578 in char-set-map in k819 */
static void C_ccall f_1621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fix((C_word)C_character_code(t1));
t3=((C_word*)t0)[3];
f_1601(t3,(C_word)C_setsubchar(((C_word*)t0)[2],t2,lf[15]));}

/* k1599 in lp in k1581 in k1578 in char-set-map in k819 */
static void C_fcall f_1601(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm: 320  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1591(t3,((C_word*)t0)[2],t2);}

/* k1584 in k1581 in k1578 in char-set-map in k819 */
static void C_ccall f_1586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 321  make-char-set */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-for-each in k819 */
static void C_ccall f_1526(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1526,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1530,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 306  %char-set:s/check */
f_910(t4,t3,lf[35]);}

/* k1528 in char-set-for-each in k819 */
static void C_ccall f_1530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1530,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1535,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1535(t5,((C_word*)t0)[2],C_fix(255));}

/* lp in k1528 in char-set-for-each in k819 */
static void C_fcall f_1535(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1535,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1545,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=(C_word)C_subchar(((C_word*)t0)[3],t5);
t7=(C_word)C_fix((C_word)C_character_code(t6));
t8=(C_word)C_eqp(t7,C_fix(0));
if(C_truep(t8)){
t9=t4;
f_1545(2,t9,C_SCHEME_UNDEFINED);}
else{
t9=t2;
t10=(C_word)C_make_character((C_word)C_unfix(t9));
/* srfi-14.scm: 309  proc */
t11=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t4,t10);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1543 in lp in k1528 in char-set-for-each in k819 */
static void C_ccall f_1545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm: 310  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1535(t3,((C_word*)t0)[2],t2);}

/* %char-set-cursor-next in k819 */
static void C_fcall f_1484(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1484,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1488,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 295  %char-set:s/check */
f_910(t5,t2,t4);}

/* k1486 in %char-set-cursor-next in k819 */
static void C_ccall f_1488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1488,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1493,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_1493(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k1486 in %char-set-cursor-next in k819 */
static void C_fcall f_1493(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1493,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t4=(C_word)C_fixnum_lessp(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1506,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_1506(t6,t4);}
else{
t6=(C_word)C_subchar(((C_word*)t0)[2],t3);
t7=(C_word)C_fix((C_word)C_character_code(t6));
t8=(C_word)C_eqp(t7,C_fix(0));
t9=t5;
f_1506(t9,(C_word)C_i_not(t8));}}

/* k1504 in lp in k1486 in %char-set-cursor-next in k819 */
static void C_fcall f_1506(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
/* srfi-14.scm: 299  lp */
t2=((C_word*)((C_word*)t0)[2])[1];
f_1493(t2,((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* char-set-cursor-next in k819 */
static void C_ccall f_1475(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1475,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t3,lf[34]);
/* srfi-14.scm: 292  %char-set-cursor-next */
f_1484(t1,t2,t3,lf[34]);}

/* char-set-ref in k819 */
static void C_ccall f_1469(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1469,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_make_character((C_word)C_unfix(t3)));}

/* end-of-char-set? in k819 */
static void C_ccall f_1463(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1463,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_lessp(t2,C_fix(0)));}

/* char-set-cursor in k819 */
static void C_ccall f_1457(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1457,3,t0,t1,t2);}
/* srfi-14.scm: 282  %char-set-cursor-next */
f_1484(t1,t2,C_fix(256),lf[30]);}

/* char-set-delete! in k819 */
static void C_ccall f_1445(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr3r,(void*)f_1445r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1445r(t0,t1,t2,t3);}}

static void C_ccall f_1445r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1451,tmp=(C_word)a,a+=2,tmp);
/* srfi-14.scm: 268  %set-char-set! */
f_1374(t1,t4,lf[29],t2,t3);}

/* a1450 in char-set-delete! in k819 */
static void C_ccall f_1451(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1451,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_setsubchar(t2,t3,lf[14]));}

/* char-set-delete in k819 */
static void C_ccall f_1433(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr3r,(void*)f_1433r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1433r(t0,t1,t2,t3);}}

static void C_ccall f_1433r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1439,tmp=(C_word)a,a+=2,tmp);
/* srfi-14.scm: 266  %set-char-set */
f_1332(t1,t4,lf[28],t2,t3);}

/* a1438 in char-set-delete in k819 */
static void C_ccall f_1439(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1439,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_setsubchar(t2,t3,lf[14]));}

/* char-set-adjoin! in k819 */
static void C_ccall f_1421(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr3r,(void*)f_1421r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1421r(t0,t1,t2,t3);}}

static void C_ccall f_1421r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1427,tmp=(C_word)a,a+=2,tmp);
/* srfi-14.scm: 264  %set-char-set! */
f_1374(t1,t4,lf[27],t2,t3);}

/* a1426 in char-set-adjoin! in k819 */
static void C_ccall f_1427(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1427,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_setsubchar(t2,t3,lf[15]));}

/* char-set-adjoin in k819 */
static void C_ccall f_1409(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr3r,(void*)f_1409r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1409r(t0,t1,t2,t3);}}

static void C_ccall f_1409r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1415,tmp=(C_word)a,a+=2,tmp);
/* srfi-14.scm: 262  %set-char-set */
f_1332(t1,t4,lf[26],t2,t3);}

/* a1414 in char-set-adjoin in k819 */
static void C_ccall f_1415(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1415,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_setsubchar(t2,t3,lf[15]));}

/* %set-char-set! in k819 */
static void C_fcall f_1374(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1374,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1378,a[2]=t5,a[3]=t2,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-14.scm: 256  %char-set:s/check */
f_910(t6,t4,t3);}

/* k1376 in %set-char-set! in k819 */
static void C_ccall f_1378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1378,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1381,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1383,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1383(t6,t2,((C_word*)t0)[2]);}

/* loop172 in k1376 in %set-char-set! in k819 */
static void C_fcall f_1383(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1383,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1396,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_fix((C_word)C_character_code(t3));
/* srfi-14.scm: 257  set */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[2],t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k1394 in loop172 in k1376 in %set-char-set! in k819 */
static void C_ccall f_1396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1383(t3,((C_word*)t0)[2],t2);}

/* k1379 in k1376 in %set-char-set! in k819 */
static void C_ccall f_1381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* %set-char-set in k819 */
static void C_fcall f_1332(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1332,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1336,a[2]=t5,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1372,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 250  %char-set:s/check */
f_910(t7,t4,t3);}

/* k1370 in %set-char-set in k819 */
static void C_ccall f_1372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 250  %string-copy */
f_853(((C_word*)t0)[2],t1);}

/* k1334 in %set-char-set in k819 */
static void C_ccall f_1336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1339,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1344,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1344(t6,t2,((C_word*)t0)[2]);}

/* loop155 in k1334 in %set-char-set in k819 */
static void C_fcall f_1344(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1344,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1357,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_fix((C_word)C_character_code(t3));
/* srfi-14.scm: 251  set */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[2],t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k1355 in loop155 in k1334 in %set-char-set in k819 */
static void C_ccall f_1357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1344(t3,((C_word*)t0)[2],t2);}

/* k1337 in k1334 in %set-char-set in k819 */
static void C_ccall f_1339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 253  make-char-set */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-count in k819 */
static void C_ccall f_1275(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1275,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1279,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 238  %char-set:s/check */
f_910(t4,t3,lf[23]);}

/* k1277 in char-set-count in k819 */
static void C_ccall f_1279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1279,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1284,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1284(t5,((C_word*)t0)[2],C_fix(255),C_fix(0));}

/* lp in k1277 in char-set-count in k819 */
static void C_fcall f_1284(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1284,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1305,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=t2;
t8=(C_word)C_subchar(((C_word*)t0)[3],t7);
t9=(C_word)C_fix((C_word)C_character_code(t8));
t10=(C_word)C_eqp(t9,C_fix(0));
if(C_truep(t10)){
t11=t6;
f_1305(2,t11,C_SCHEME_FALSE);}
else{
t11=t2;
t12=(C_word)C_make_character((C_word)C_unfix(t11));
/* srfi-14.scm: 242  pred */
t13=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t6,t12);}}}

/* k1303 in lp in k1277 in char-set-count in k819 */
static void C_ccall f_1305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1)):((C_word*)t0)[5]);
/* srfi-14.scm: 241  lp */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1284(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* char-set-size in k819 */
static void C_ccall f_1238(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1238,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1242,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 231  %char-set:s/check */
f_910(t3,t2,lf[22]);}

/* k1240 in char-set-size in k819 */
static void C_ccall f_1242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1242,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1247,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1247(t2,C_fix(255),C_fix(0)));}

/* lp in k1240 in char-set-size in k819 */
static C_word C_fcall f_1247(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
t3=t1;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
return(t2);}
else{
t4=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t5=t1;
t6=(C_word)C_subchar(((C_word*)t0)[2],t5);
t7=(C_word)C_fix((C_word)C_character_code(t6));
t8=(C_word)C_u_fixnum_plus(t2,t7);
t10=t4;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* char-set-contains? in k819 */
static void C_ccall f_1211(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1211,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_char_2(t3,lf[21]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1218,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 226  %char-set:s/check */
f_910(t5,t2,lf[21]);}

/* k1216 in char-set-contains? in k819 */
static void C_ccall f_1218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_word)C_fix((C_word)C_character_code(t2));
t4=(C_word)C_subchar(t1,t3);
t5=(C_word)C_fix((C_word)C_character_code(t4));
t6=(C_word)C_eqp(t5,C_fix(0));
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_not(t6));}

/* char-set-hash in k819 */
static void C_ccall f_1110(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1110r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1110r(t0,t1,t2,t3);}}

static void C_ccall f_1110r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(7);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(4194304):(C_word)C_slot(t3,C_fix(0)));
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1117,a[2]=t2,a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_eqp(((C_word*)t7)[1],C_fix(0));
if(C_truep(t9)){
t10=C_set_block_item(t7,0,C_fix(4194304));
t11=t8;
f_1117(t11,t10);}
else{
t10=t8;
f_1117(t10,C_SCHEME_UNDEFINED);}}

/* k1115 in char-set-hash in k819 */
static void C_fcall f_1117(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1117,NULL,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)((C_word*)t0)[4])[1],lf[19]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1123,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 213  %char-set:s/check */
f_910(t3,((C_word*)t0)[2],lf[19]);}

/* k1121 in k1115 in char-set-hash in k819 */
static void C_ccall f_1123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1123,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1176,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=f_1176(t2,C_fix(65536));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1131,a[2]=t3,a[3]=t1,a[4]=t5,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_1131(t7,((C_word*)t0)[2],C_fix(255),C_fix(0));}

/* lp in k1121 in k1115 in char-set-hash in k819 */
static void C_fcall f_1131(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1131,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
/* srfi-14.scm: 218  modulo */
t5=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,((C_word*)((C_word*)t0)[5])[1]);}
else{
t5=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1152,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=t2;
t8=(C_word)C_subchar(((C_word*)t0)[3],t7);
t9=(C_word)C_fix((C_word)C_character_code(t8));
t10=(C_word)C_eqp(t9,C_fix(0));
if(C_truep(t10)){
t11=t6;
f_1152(t11,t3);}
else{
t11=(C_word)C_fixnum_times(C_fix(37),t3);
t12=(C_word)C_u_fixnum_plus(t11,t2);
t13=t6;
f_1152(t13,(C_word)C_u_fixnum_and(((C_word*)t0)[2],t12));}}}

/* k1150 in lp in k1121 in k1115 in char-set-hash in k819 */
static void C_fcall f_1152(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 219  lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1131(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* lp in k1121 in k1115 in char-set-hash in k819 */
static C_word C_fcall f_1176(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
t2=t1;
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,t3))){
return((C_word)C_u_fixnum_difference(t1,C_fix(1)));}
else{
t4=(C_word)C_u_fixnum_plus(t1,t1);
t6=t4;
t1=t6;
goto loop;}}

/* char-set<= in k819 */
static void C_ccall f_1012(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1012r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1012r(t0,t1,t2);}}

static void C_ccall f_1012r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1032,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 186  %char-set:s/check */
f_910(t6,t4,lf[18]);}}

/* k1030 in char-set<= in k819 */
static void C_ccall f_1032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1032,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1034,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_1034(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* lp in k1030 in char-set<= in k819 */
static void C_fcall f_1034(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1034,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_pairp(t3);
t5=(C_word)C_i_not(t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1044,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_u_i_car(t3);
/* srfi-14.scm: 188  %char-set:s/check */
f_910(t6,t7,lf[18]);}}

/* k1042 in lp in k1030 in char-set<= in k819 */
static void C_ccall f_1044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1044,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t3)){
/* srfi-14.scm: 190  lp */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1034(t4,((C_word*)t0)[2],t1,t2);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1061,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_1061(t7,((C_word*)t0)[2],C_fix(255));}}

/* lp2 in k1042 in lp in k1030 in char-set<= in k819 */
static void C_fcall f_1061(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1061,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
/* srfi-14.scm: 192  lp */
t4=((C_word*)((C_word*)t0)[6])[1];
f_1034(t4,t1,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t4=((C_word*)t0)[3];
t5=t2;
t6=(C_word)C_subchar(t4,t5);
t7=(C_word)C_fix((C_word)C_character_code(t6));
t8=t2;
t9=(C_word)C_subchar(((C_word*)t0)[5],t8);
t10=(C_word)C_fix((C_word)C_character_code(t9));
if(C_truep((C_word)C_fixnum_less_or_equal_p(t7,t10))){
t11=(C_word)C_u_fixnum_difference(t2,C_fix(1));
/* srfi-14.scm: 194  lp2 */
t13=t1;
t14=t11;
t1=t13;
t2=t14;
goto loop;}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}}

/* char-set= in k819 */
static void C_ccall f_957(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_957r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_957r(t0,t1,t2);}}

static void C_ccall f_957r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_973,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 175  %char-set:s/check */
f_910(t6,t4,lf[17]);}}

/* k971 in char-set= in k819 */
static void C_ccall f_973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_973,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_978,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_978(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k971 in char-set= in k819 */
static void C_fcall f_978(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_978,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=(C_word)C_i_not(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1002,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_u_i_car(t2);
/* srfi-14.scm: 178  %char-set:s/check */
f_910(t5,t6,lf[17]);}}

/* k1000 in lp in k971 in char-set= in k819 */
static void C_ccall f_1002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_u_i_string_equal_p(((C_word*)t0)[5],t1))){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-14.scm: 179  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_978(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* char-set-copy in k819 */
static void C_ccall f_943(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_943,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_951,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_955,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 168  %char-set:s/check */
f_910(t4,t2,lf[16]);}

/* k953 in char-set-copy in k819 */
static void C_ccall f_955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 168  %string-copy */
f_853(((C_word*)t0)[2],t1);}

/* k949 in char-set-copy in k819 */
static void C_ccall f_951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 168  make-char-set */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* %char-set:s/check in k819 */
static void C_fcall f_910(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_910,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_916,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_916(t7,t1,t2);}

/* lp in %char-set:s/check in k819 */
static void C_fcall f_916(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_916,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_923,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-14.scm: 139  char-set? */
t4=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k921 in lp in %char-set:s/check in k819 */
static void C_ccall f_923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_923,2,t0,t1);}
if(C_truep(t1)){
/* srfi-14.scm: 139  char-set:s */
t2=*((C_word*)lf[3]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_933,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-14.scm: 140  ##sys#error */
t3=*((C_word*)lf[8]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],lf[13],((C_word*)t0)[4]);}}

/* k931 in k921 in lp in %char-set:s/check in k819 */
static void C_ccall f_933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 140  lp */
t2=((C_word*)((C_word*)t0)[3])[1];
f_916(t2,((C_word*)t0)[2],t1);}

/* %default-base in k819 */
static void C_fcall f_863(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_863,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t5))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_888,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-14.scm: 127  char-set? */
t7=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}
else{
/* srfi-14.scm: 129  ##sys#error */
t6=*((C_word*)lf[8]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,lf[10],t3,t2);}}
else{
t4=(C_word)C_make_character((C_word)C_unfix(C_fix(0)));
/* srfi-14.scm: 131  make-string */
t5=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,C_fix(256),t4);}}

/* k886 in %default-base in k819 */
static void C_ccall f_888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_888,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_895,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* srfi-14.scm: 127  char-set:s */
t3=*((C_word*)lf[3]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
/* srfi-14.scm: 128  ##sys#error */
t2=*((C_word*)lf[8]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[9],((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k893 in k886 in %default-base in k819 */
static void C_ccall f_895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-14.scm: 127  %string-copy */
f_853(((C_word*)t0)[2],t1);}

/* %string-copy in k819 */
static void C_fcall f_853(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_853,NULL,2,t1,t2);}
t3=(C_word)C_fix((C_word)C_header_size(t2));
/* substring */
t4=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,t2,C_fix(0),t3);}

/* char-set? in k819 */
static void C_ccall f_847(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_847,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[2]));}

/* char-set:s in k819 */
static void C_ccall f_841(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_841,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* make-char-set in k819 */
static void C_ccall f_835(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_835,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,2,lf[2],t2));}

/* %latin1->char in k819 */
static void C_ccall f_823(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_823,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_make_character((C_word)C_unfix(t2)));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[258] = {
{"toplevel:srfi_14_scm",(void*)C_srfi_14_toplevel},
{"f_821:srfi_14_scm",(void*)f_821},
{"f_2901:srfi_14_scm",(void*)f_2901},
{"f_2905:srfi_14_scm",(void*)f_2905},
{"f_2909:srfi_14_scm",(void*)f_2909},
{"f_2912:srfi_14_scm",(void*)f_2912},
{"f_2915:srfi_14_scm",(void*)f_2915},
{"f_2918:srfi_14_scm",(void*)f_2918},
{"f_2922:srfi_14_scm",(void*)f_2922},
{"f_3013:srfi_14_scm",(void*)f_3013},
{"f_2925:srfi_14_scm",(void*)f_2925},
{"f_2930:srfi_14_scm",(void*)f_2930},
{"f_2933:srfi_14_scm",(void*)f_2933},
{"f_2937:srfi_14_scm",(void*)f_2937},
{"f_2941:srfi_14_scm",(void*)f_2941},
{"f_2945:srfi_14_scm",(void*)f_2945},
{"f_2949:srfi_14_scm",(void*)f_2949},
{"f_2952:srfi_14_scm",(void*)f_2952},
{"f_2955:srfi_14_scm",(void*)f_2955},
{"f_2959:srfi_14_scm",(void*)f_2959},
{"f_2962:srfi_14_scm",(void*)f_2962},
{"f_2965:srfi_14_scm",(void*)f_2965},
{"f_2969:srfi_14_scm",(void*)f_2969},
{"f_3001:srfi_14_scm",(void*)f_3001},
{"f_2973:srfi_14_scm",(void*)f_2973},
{"f_2977:srfi_14_scm",(void*)f_2977},
{"f_2997:srfi_14_scm",(void*)f_2997},
{"f_2981:srfi_14_scm",(void*)f_2981},
{"f_2993:srfi_14_scm",(void*)f_2993},
{"f_2985:srfi_14_scm",(void*)f_2985},
{"f_2989:srfi_14_scm",(void*)f_2989},
{"f_2872:srfi_14_scm",(void*)f_2872},
{"f_2897:srfi_14_scm",(void*)f_2897},
{"f_2876:srfi_14_scm",(void*)f_2876},
{"f_2879:srfi_14_scm",(void*)f_2879},
{"f_2882:srfi_14_scm",(void*)f_2882},
{"f_2889:srfi_14_scm",(void*)f_2889},
{"f_2893:srfi_14_scm",(void*)f_2893},
{"f_2821:srfi_14_scm",(void*)f_2821},
{"f_2825:srfi_14_scm",(void*)f_2825},
{"f_2828:srfi_14_scm",(void*)f_2828},
{"f_2839:srfi_14_scm",(void*)f_2839},
{"f_2831:srfi_14_scm",(void*)f_2831},
{"f_2834:srfi_14_scm",(void*)f_2834},
{"f_2752:srfi_14_scm",(void*)f_2752},
{"f_2758:srfi_14_scm",(void*)f_2758},
{"f_2819:srfi_14_scm",(void*)f_2819},
{"f_2780:srfi_14_scm",(void*)f_2780},
{"f_2771:srfi_14_scm",(void*)f_2771},
{"f_2688:srfi_14_scm",(void*)f_2688},
{"f_2743:srfi_14_scm",(void*)f_2743},
{"f_2698:srfi_14_scm",(void*)f_2698},
{"f_2710:srfi_14_scm",(void*)f_2710},
{"f_2701:srfi_14_scm",(void*)f_2701},
{"f_2647:srfi_14_scm",(void*)f_2647},
{"f_2655:srfi_14_scm",(void*)f_2655},
{"f_2657:srfi_14_scm",(void*)f_2657},
{"f_2651:srfi_14_scm",(void*)f_2651},
{"f_2606:srfi_14_scm",(void*)f_2606},
{"f_2642:srfi_14_scm",(void*)f_2642},
{"f_2616:srfi_14_scm",(void*)f_2616},
{"f_2624:srfi_14_scm",(void*)f_2624},
{"f_2619:srfi_14_scm",(void*)f_2619},
{"f_2580:srfi_14_scm",(void*)f_2580},
{"f_2588:srfi_14_scm",(void*)f_2588},
{"f_2590:srfi_14_scm",(void*)f_2590},
{"f_2584:srfi_14_scm",(void*)f_2584},
{"f_2535:srfi_14_scm",(void*)f_2535},
{"f_2571:srfi_14_scm",(void*)f_2571},
{"f_2545:srfi_14_scm",(void*)f_2545},
{"f_2557:srfi_14_scm",(void*)f_2557},
{"f_2548:srfi_14_scm",(void*)f_2548},
{"f_2513:srfi_14_scm",(void*)f_2513},
{"f_2521:srfi_14_scm",(void*)f_2521},
{"f_2523:srfi_14_scm",(void*)f_2523},
{"f_2517:srfi_14_scm",(void*)f_2517},
{"f_2464:srfi_14_scm",(void*)f_2464},
{"f_2504:srfi_14_scm",(void*)f_2504},
{"f_2474:srfi_14_scm",(void*)f_2474},
{"f_2486:srfi_14_scm",(void*)f_2486},
{"f_2477:srfi_14_scm",(void*)f_2477},
{"f_2438:srfi_14_scm",(void*)f_2438},
{"f_2446:srfi_14_scm",(void*)f_2446},
{"f_2448:srfi_14_scm",(void*)f_2448},
{"f_2442:srfi_14_scm",(void*)f_2442},
{"f_2416:srfi_14_scm",(void*)f_2416},
{"f_2420:srfi_14_scm",(void*)f_2420},
{"f_2425:srfi_14_scm",(void*)f_2425},
{"f_2423:srfi_14_scm",(void*)f_2423},
{"f_2388:srfi_14_scm",(void*)f_2388},
{"f_2392:srfi_14_scm",(void*)f_2392},
{"f_2395:srfi_14_scm",(void*)f_2395},
{"f_2403:srfi_14_scm",(void*)f_2403},
{"f_2398:srfi_14_scm",(void*)f_2398},
{"f_2330:srfi_14_scm",(void*)f_2330},
{"f_2336:srfi_14_scm",(void*)f_2336},
{"f_2349:srfi_14_scm",(void*)f_2349},
{"f_2361:srfi_14_scm",(void*)f_2361},
{"f_2371:srfi_14_scm",(void*)f_2371},
{"f_2352:srfi_14_scm",(void*)f_2352},
{"f_2289:srfi_14_scm",(void*)f_2289},
{"f_2299:srfi_14_scm",(void*)f_2299},
{"f_2309:srfi_14_scm",(void*)f_2309},
{"f_2259:srfi_14_scm",(void*)f_2259},
{"f_2266:srfi_14_scm",(void*)f_2266},
{"f_2245:srfi_14_scm",(void*)f_2245},
{"f_2253:srfi_14_scm",(void*)f_2253},
{"f_2257:srfi_14_scm",(void*)f_2257},
{"f_2249:srfi_14_scm",(void*)f_2249},
{"f_2229:srfi_14_scm",(void*)f_2229},
{"f_2233:srfi_14_scm",(void*)f_2233},
{"f_2243:srfi_14_scm",(void*)f_2243},
{"f_2236:srfi_14_scm",(void*)f_2236},
{"f_2176:srfi_14_scm",(void*)f_2176},
{"f_2182:srfi_14_scm",(void*)f_2182},
{"f_2202:srfi_14_scm",(void*)f_2202},
{"f_2192:srfi_14_scm",(void*)f_2192},
{"f_2166:srfi_14_scm",(void*)f_2166},
{"f_2174:srfi_14_scm",(void*)f_2174},
{"f_2170:srfi_14_scm",(void*)f_2170},
{"f_2136:srfi_14_scm",(void*)f_2136},
{"f_2146:srfi_14_scm",(void*)f_2146},
{"f_2149:srfi_14_scm",(void*)f_2149},
{"f_2079:srfi_14_scm",(void*)f_2079},
{"f_2122:srfi_14_scm",(void*)f_2122},
{"f_2089:srfi_14_scm",(void*)f_2089},
{"f_2119:srfi_14_scm",(void*)f_2119},
{"f_2098:srfi_14_scm",(void*)f_2098},
{"f_2023:srfi_14_scm",(void*)f_2023},
{"f_2027:srfi_14_scm",(void*)f_2027},
{"f_2077:srfi_14_scm",(void*)f_2077},
{"f_2030:srfi_14_scm",(void*)f_2030},
{"f_2035:srfi_14_scm",(void*)f_2035},
{"f_2045:srfi_14_scm",(void*)f_2045},
{"f_2013:srfi_14_scm",(void*)f_2013},
{"f_2021:srfi_14_scm",(void*)f_2021},
{"f_2017:srfi_14_scm",(void*)f_2017},
{"f_2001:srfi_14_scm",(void*)f_2001},
{"f_2005:srfi_14_scm",(void*)f_2005},
{"f_2008:srfi_14_scm",(void*)f_2008},
{"f_1958:srfi_14_scm",(void*)f_1958},
{"f_1971:srfi_14_scm",(void*)f_1971},
{"f_1911:srfi_14_scm",(void*)f_1911},
{"f_1915:srfi_14_scm",(void*)f_1915},
{"f_1920:srfi_14_scm",(void*)f_1920},
{"f_1938:srfi_14_scm",(void*)f_1938},
{"f_1901:srfi_14_scm",(void*)f_1901},
{"f_1909:srfi_14_scm",(void*)f_1909},
{"f_1905:srfi_14_scm",(void*)f_1905},
{"f_1889:srfi_14_scm",(void*)f_1889},
{"f_1893:srfi_14_scm",(void*)f_1893},
{"f_1896:srfi_14_scm",(void*)f_1896},
{"f_1877:srfi_14_scm",(void*)f_1877},
{"f_1881:srfi_14_scm",(void*)f_1881},
{"f_1884:srfi_14_scm",(void*)f_1884},
{"f_1846:srfi_14_scm",(void*)f_1846},
{"f_1852:srfi_14_scm",(void*)f_1852},
{"f_1836:srfi_14_scm",(void*)f_1836},
{"f_1844:srfi_14_scm",(void*)f_1844},
{"f_1840:srfi_14_scm",(void*)f_1840},
{"f_1824:srfi_14_scm",(void*)f_1824},
{"f_1828:srfi_14_scm",(void*)f_1828},
{"f_1831:srfi_14_scm",(void*)f_1831},
{"f_1788:srfi_14_scm",(void*)f_1788},
{"f_1794:srfi_14_scm",(void*)f_1794},
{"f_1822:srfi_14_scm",(void*)f_1822},
{"f_1818:srfi_14_scm",(void*)f_1818},
{"f_1814:srfi_14_scm",(void*)f_1814},
{"f_1735:srfi_14_scm",(void*)f_1735},
{"f_1739:srfi_14_scm",(void*)f_1739},
{"f_1744:srfi_14_scm",(void*)f_1744},
{"f_1754:srfi_14_scm",(void*)f_1754},
{"f_1686:srfi_14_scm",(void*)f_1686},
{"f_1690:srfi_14_scm",(void*)f_1690},
{"f_1695:srfi_14_scm",(void*)f_1695},
{"f_1711:srfi_14_scm",(void*)f_1711},
{"f_1639:srfi_14_scm",(void*)f_1639},
{"f_1643:srfi_14_scm",(void*)f_1643},
{"f_1648:srfi_14_scm",(void*)f_1648},
{"f_1666:srfi_14_scm",(void*)f_1666},
{"f_1576:srfi_14_scm",(void*)f_1576},
{"f_1580:srfi_14_scm",(void*)f_1580},
{"f_1583:srfi_14_scm",(void*)f_1583},
{"f_1591:srfi_14_scm",(void*)f_1591},
{"f_1621:srfi_14_scm",(void*)f_1621},
{"f_1601:srfi_14_scm",(void*)f_1601},
{"f_1586:srfi_14_scm",(void*)f_1586},
{"f_1526:srfi_14_scm",(void*)f_1526},
{"f_1530:srfi_14_scm",(void*)f_1530},
{"f_1535:srfi_14_scm",(void*)f_1535},
{"f_1545:srfi_14_scm",(void*)f_1545},
{"f_1484:srfi_14_scm",(void*)f_1484},
{"f_1488:srfi_14_scm",(void*)f_1488},
{"f_1493:srfi_14_scm",(void*)f_1493},
{"f_1506:srfi_14_scm",(void*)f_1506},
{"f_1475:srfi_14_scm",(void*)f_1475},
{"f_1469:srfi_14_scm",(void*)f_1469},
{"f_1463:srfi_14_scm",(void*)f_1463},
{"f_1457:srfi_14_scm",(void*)f_1457},
{"f_1445:srfi_14_scm",(void*)f_1445},
{"f_1451:srfi_14_scm",(void*)f_1451},
{"f_1433:srfi_14_scm",(void*)f_1433},
{"f_1439:srfi_14_scm",(void*)f_1439},
{"f_1421:srfi_14_scm",(void*)f_1421},
{"f_1427:srfi_14_scm",(void*)f_1427},
{"f_1409:srfi_14_scm",(void*)f_1409},
{"f_1415:srfi_14_scm",(void*)f_1415},
{"f_1374:srfi_14_scm",(void*)f_1374},
{"f_1378:srfi_14_scm",(void*)f_1378},
{"f_1383:srfi_14_scm",(void*)f_1383},
{"f_1396:srfi_14_scm",(void*)f_1396},
{"f_1381:srfi_14_scm",(void*)f_1381},
{"f_1332:srfi_14_scm",(void*)f_1332},
{"f_1372:srfi_14_scm",(void*)f_1372},
{"f_1336:srfi_14_scm",(void*)f_1336},
{"f_1344:srfi_14_scm",(void*)f_1344},
{"f_1357:srfi_14_scm",(void*)f_1357},
{"f_1339:srfi_14_scm",(void*)f_1339},
{"f_1275:srfi_14_scm",(void*)f_1275},
{"f_1279:srfi_14_scm",(void*)f_1279},
{"f_1284:srfi_14_scm",(void*)f_1284},
{"f_1305:srfi_14_scm",(void*)f_1305},
{"f_1238:srfi_14_scm",(void*)f_1238},
{"f_1242:srfi_14_scm",(void*)f_1242},
{"f_1247:srfi_14_scm",(void*)f_1247},
{"f_1211:srfi_14_scm",(void*)f_1211},
{"f_1218:srfi_14_scm",(void*)f_1218},
{"f_1110:srfi_14_scm",(void*)f_1110},
{"f_1117:srfi_14_scm",(void*)f_1117},
{"f_1123:srfi_14_scm",(void*)f_1123},
{"f_1131:srfi_14_scm",(void*)f_1131},
{"f_1152:srfi_14_scm",(void*)f_1152},
{"f_1176:srfi_14_scm",(void*)f_1176},
{"f_1012:srfi_14_scm",(void*)f_1012},
{"f_1032:srfi_14_scm",(void*)f_1032},
{"f_1034:srfi_14_scm",(void*)f_1034},
{"f_1044:srfi_14_scm",(void*)f_1044},
{"f_1061:srfi_14_scm",(void*)f_1061},
{"f_957:srfi_14_scm",(void*)f_957},
{"f_973:srfi_14_scm",(void*)f_973},
{"f_978:srfi_14_scm",(void*)f_978},
{"f_1002:srfi_14_scm",(void*)f_1002},
{"f_943:srfi_14_scm",(void*)f_943},
{"f_955:srfi_14_scm",(void*)f_955},
{"f_951:srfi_14_scm",(void*)f_951},
{"f_910:srfi_14_scm",(void*)f_910},
{"f_916:srfi_14_scm",(void*)f_916},
{"f_923:srfi_14_scm",(void*)f_923},
{"f_933:srfi_14_scm",(void*)f_933},
{"f_863:srfi_14_scm",(void*)f_863},
{"f_888:srfi_14_scm",(void*)f_888},
{"f_895:srfi_14_scm",(void*)f_895},
{"f_853:srfi_14_scm",(void*)f_853},
{"f_847:srfi_14_scm",(void*)f_847},
{"f_841:srfi_14_scm",(void*)f_841},
{"f_835:srfi_14_scm",(void*)f_835},
{"f_823:srfi_14_scm",(void*)f_823},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
