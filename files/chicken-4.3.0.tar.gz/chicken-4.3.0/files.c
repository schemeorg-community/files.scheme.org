/* Generated from files.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-12-14 09:01
   Version 4.2.0 - SVN rev. 16023
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-12-14 on galinha (Linux)
   command line: files.scm -optimize-level 2 -include-path . -include-path ./ -inline -explicit-use -no-trace -output-file files.c -extend ./private-namespace.scm
   unit: files
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[102];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,21),40,100,101,108,101,116,101,45,102,105,108,101,42,32,102,105,108,101,50,55,41,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,6),40,97,57,52,55,41,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,18),40,97,57,52,49,32,101,120,118,97,114,49,51,50,49,52,51,41,0,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,6),40,97,57,56,50,41,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,6),40,97,57,57,52,41,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,19),40,97,57,56,56,32,46,32,97,114,103,115,49,52,48,49,53,54,41,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,6),40,97,57,55,54,41,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,14),40,97,57,51,53,32,107,49,51,57,49,52,50,41,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,100,49,50,56,32,108,49,50,57,41};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,7),40,97,49,48,49,53,41,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,19),40,97,49,48,48,57,32,101,120,118,97,114,49,48,51,49,49,52,41,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,7),40,97,49,48,52,48,41,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,7),40,97,49,48,53,50,41,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,20),40,97,49,48,52,54,32,46,32,97,114,103,115,49,49,49,49,50,53,41,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,7),40,97,49,48,51,52,41,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,15),40,97,49,48,48,51,32,107,49,49,48,49,49,51,41,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,7),40,97,49,48,55,51,41,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,17),40,97,49,48,54,55,32,101,120,118,97,114,55,57,57,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,7),40,97,49,48,57,56,41,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,7),40,97,49,49,49,48,41,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,19),40,97,49,49,48,52,32,46,32,97,114,103,115,56,55,49,48,49,41,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,7),40,97,49,48,57,50,41,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,13),40,97,49,48,54,49,32,107,56,54,56,57,41,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,30),40,98,111,100,121,52,55,32,99,108,111,98,98,101,114,53,54,32,98,108,111,99,107,115,105,122,101,53,55,41,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,31),40,100,101,102,45,98,108,111,99,107,115,105,122,101,53,48,32,37,99,108,111,98,98,101,114,52,53,49,54,54,41,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,15),40,100,101,102,45,99,108,111,98,98,101,114,52,57,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,42),40,102,105,108,101,45,99,111,112,121,32,111,114,105,103,102,105,108,101,51,57,32,110,101,119,102,105,108,101,52,48,32,46,32,116,109,112,51,56,52,49,41,0,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,7),40,97,49,50,56,51,41,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,19),40,97,49,50,55,55,32,101,120,118,97,114,50,55,49,50,56,50,41,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,7),40,97,49,51,48,56,41,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,7),40,97,49,51,50,48,41,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,20),40,97,49,51,49,52,32,46,32,97,114,103,115,50,55,57,50,57,51,41,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,7),40,97,49,51,48,50,41,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,15),40,97,49,50,55,49,32,107,50,55,56,50,56,49,41,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,7),40,97,49,51,53,53,41,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,19),40,97,49,51,52,57,32,101,120,118,97,114,50,57,55,51,48,56,41,0,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,7),40,97,49,51,57,48,41,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,7),40,97,49,52,48,50,41,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,20),40,97,49,51,57,54,32,46,32,97,114,103,115,51,48,53,51,50,49,41,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,7),40,97,49,51,56,52,41,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,15),40,97,49,51,52,51,32,107,51,48,52,51,48,55,41,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,100,50,54,57,32,108,50,55,48,41};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,7),40,97,49,52,50,51,41,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,19),40,97,49,52,49,55,32,101,120,118,97,114,50,52,52,50,53,53,41,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,7),40,97,49,52,52,56,41,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,7),40,97,49,52,54,48,41,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,20),40,97,49,52,53,52,32,46,32,97,114,103,115,50,53,50,50,54,54,41,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,7),40,97,49,52,52,50,41,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,15),40,97,49,52,49,49,32,107,50,53,49,50,53,52,41,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,7),40,97,49,52,56,49,41,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,19),40,97,49,52,55,53,32,101,120,118,97,114,50,50,48,50,51,49,41,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,7),40,97,49,53,48,54,41,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,7),40,97,49,53,49,56,41,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,20),40,97,49,53,49,50,32,46,32,97,114,103,115,50,50,56,50,52,50,41,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,7),40,97,49,53,48,48,41,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,15),40,97,49,52,54,57,32,107,50,50,55,50,51,48,41,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,33),40,98,111,100,121,49,56,56,32,99,108,111,98,98,101,114,49,57,55,32,98,108,111,99,107,115,105,122,101,49,57,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,33),40,100,101,102,45,98,108,111,99,107,115,105,122,101,49,57,49,32,37,99,108,111,98,98,101,114,49,56,54,51,51,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,99,108,111,98,98,101,114,49,57,48,41};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,46),40,102,105,108,101,45,109,111,118,101,32,111,114,105,103,102,105,108,101,49,56,48,32,110,101,119,102,105,108,101,49,56,49,32,46,32,116,109,112,49,55,57,49,56,50,41,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,26),40,97,98,115,111,108,117,116,101,45,112,97,116,104,110,97,109,101,63,32,112,110,51,53,55,41,0,0,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,24),40,99,104,111,112,45,112,100,115,32,115,116,114,51,54,49,32,112,100,115,51,54,50,41};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,115,116,114,115,51,55,57,41,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,26),40,99,111,110,99,45,100,105,114,115,32,100,105,114,115,51,55,54,32,112,100,115,51,55,55,41,0,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,34),40,99,97,110,111,110,105,99,97,108,105,122,101,45,100,105,114,115,32,100,105,114,115,51,56,56,32,112,100,115,51,56,57,41,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,52),40,95,109,97,107,101,45,112,97,116,104,110,97,109,101,32,108,111,99,52,48,49,32,100,105,114,52,48,50,32,102,105,108,101,52,48,51,32,101,120,116,52,48,52,32,112,100,115,52,48,53,41,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,23),40,98,111,100,121,52,52,52,32,101,120,116,52,53,51,32,112,100,115,52,53,52,41,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,23),40,100,101,102,45,112,100,115,52,52,55,32,37,101,120,116,52,52,50,52,53,54,41,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,12),40,100,101,102,45,101,120,116,52,52,54,41,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,43),40,109,97,107,101,45,112,97,116,104,110,97,109,101,32,100,105,114,115,52,51,54,32,102,105,108,101,52,51,55,32,46,32,116,109,112,52,51,53,52,51,56,41,0,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,23),40,98,111,100,121,52,55,54,32,101,120,116,52,56,53,32,112,100,115,52,56,54,41,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,23),40,100,101,102,45,112,100,115,52,55,57,32,37,101,120,116,52,55,52,52,57,52,41,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,12),40,100,101,102,45,101,120,116,52,55,56,41,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,52),40,109,97,107,101,45,97,98,115,111,108,117,116,101,45,112,97,116,104,110,97,109,101,32,100,105,114,115,52,54,56,32,102,105,108,101,52,54,57,32,46,32,116,109,112,52,54,55,52,55,48,41,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,18),40,115,116,114,105,112,45,112,100,115,32,100,105,114,53,49,49,41,0,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,26),40,100,101,99,111,109,112,111,115,101,45,112,97,116,104,110,97,109,101,32,112,110,53,49,52,41,0,0,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,7),40,97,50,49,48,51,41,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,47),40,97,50,49,48,57,32,100,105,114,53,50,50,53,50,51,53,50,56,32,102,105,108,101,53,50,52,53,50,53,53,50,57,32,101,120,116,53,50,54,53,50,55,53,51,48,41,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,26),40,112,97,116,104,110,97,109,101,45,100,105,114,101,99,116,111,114,121,32,112,110,53,49,57,41,0,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,7),40,97,50,49,49,56,41,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,47),40,97,50,49,50,52,32,100,105,114,53,51,55,53,51,56,53,52,51,32,102,105,108,101,53,51,57,53,52,48,53,52,52,32,101,120,116,53,52,49,53,52,50,53,52,53,41,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,21),40,112,97,116,104,110,97,109,101,45,102,105,108,101,32,112,110,53,51,52,41,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,7),40,97,50,49,51,51,41,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,47),40,97,50,49,51,57,32,100,105,114,53,53,50,53,53,51,53,53,56,32,102,105,108,101,53,53,52,53,53,53,53,53,57,32,101,120,116,53,53,54,53,53,55,53,54,48,41,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,26),40,112,97,116,104,110,97,109,101,45,101,120,116,101,110,115,105,111,110,32,112,110,53,52,57,41,0,0,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,7),40,97,50,49,52,56,41,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,47),40,97,50,49,53,52,32,100,105,114,53,54,55,53,54,56,53,55,51,32,102,105,108,101,53,54,57,53,55,48,53,55,52,32,101,120,116,53,55,49,53,55,50,53,55,53,41,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,32),40,112,97,116,104,110,97,109,101,45,115,116,114,105,112,45,100,105,114,101,99,116,111,114,121,32,112,110,53,54,52,41};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,7),40,97,50,49,54,54,41,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,47),40,97,50,49,55,50,32,100,105,114,53,56,50,53,56,51,53,56,56,32,102,105,108,101,53,56,52,53,56,53,53,56,57,32,101,120,116,53,56,54,53,56,55,53,57,48,41,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,32),40,112,97,116,104,110,97,109,101,45,115,116,114,105,112,45,101,120,116,101,110,115,105,111,110,32,112,110,53,55,57,41};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,7),40,97,50,49,56,52,41,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,45),40,97,50,49,57,48,32,95,53,57,56,53,57,57,54,48,52,32,102,105,108,101,54,48,48,54,48,49,54,48,53,32,101,120,116,54,48,50,54,48,51,54,48,54,41,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,41),40,112,97,116,104,110,97,109,101,45,114,101,112,108,97,99,101,45,100,105,114,101,99,116,111,114,121,32,112,110,53,57,52,32,100,105,114,53,57,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,7),40,97,50,50,48,50,41,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,44),40,97,50,50,48,56,32,100,105,114,54,49,52,54,49,53,54,50,48,32,95,54,49,54,54,49,55,54,50,49,32,101,120,116,54,49,56,54,49,57,54,50,50,41,0,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,37),40,112,97,116,104,110,97,109,101,45,114,101,112,108,97,99,101,45,102,105,108,101,32,112,110,54,49,48,32,102,105,108,101,54,49,49,41,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,7),40,97,50,50,50,48,41,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,45),40,97,50,50,50,54,32,100,105,114,54,51,48,54,51,49,54,51,54,32,102,105,108,101,54,51,50,54,51,51,54,51,55,32,95,54,51,52,54,51,53,54,51,56,41,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,41),40,112,97,116,104,110,97,109,101,45,114,101,112,108,97,99,101,45,101,120,116,101,110,115,105,111,110,32,112,110,54,50,54,32,101,120,116,54,50,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,12),40,97,50,50,55,49,32,112,54,55,53,41,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,32),40,99,114,101,97,116,101,45,116,101,109,112,111,114,97,114,121,45,102,105,108,101,32,46,32,101,120,116,54,53,51,41};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,18),40,97,100,100,112,97,114,116,32,112,97,114,116,115,54,56,54,41,0,0,0,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,55,50,54,32,108,115,116,55,50,55,55,51,48,41,0,0,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,28),40,108,111,111,112,32,105,55,49,49,32,112,114,101,118,55,49,50,32,112,97,114,116,115,55,49,51,41,0,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,40),40,110,111,114,109,97,108,105,122,101,45,112,97,116,104,110,97,109,101,32,112,97,116,104,54,57,57,32,46,32,116,109,112,54,57,56,55,48,48,41};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,40),40,115,112,108,105,116,45,100,105,114,101,99,116,111,114,121,32,108,111,99,55,54,55,32,100,105,114,55,54,56,32,107,101,101,112,63,55,54,57,41};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,24),40,100,105,114,101,99,116,111,114,121,45,110,117,108,108,63,32,100,105,114,55,55,50,41};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,28),40,100,101,99,111,109,112,111,115,101,45,100,105,114,101,99,116,111,114,121,32,100,105,114,55,56,52,41,0,0,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,14),40,102,95,50,55,52,57,32,112,110,51,51,57,41,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,14),40,102,95,50,55,53,53,32,114,116,51,52,48,41,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,14),40,102,95,50,55,54,52,32,114,116,51,52,51,41,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,30),40,97,98,115,111,108,117,116,101,45,112,97,116,104,110,97,109,101,45,114,111,111,116,32,112,110,51,52,57,41,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,19),40,114,111,111,116,45,111,114,105,103,105,110,32,114,116,51,53,48,41,0,0,0,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,22),40,114,111,111,116,45,100,105,114,101,99,116,111,114,121,32,114,116,51,53,49,41,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_files_toplevel)
C_externexport void C_ccall C_files_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_836)
static void C_ccall f_836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_839)
static void C_ccall f_839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_842)
static void C_ccall f_842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2774)
static void C_ccall f_2774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2785)
static void C_ccall f_2785(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2782)
static void C_ccall f_2782(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2776)
static void C_ccall f_2776(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2747)
static void C_ccall f_2747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2764)
static void C_ccall f_2764(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2755)
static void C_ccall f_2755(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2749)
static void C_ccall f_2749(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1618)
static void C_fcall f_1618(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1996)
static void C_ccall f_1996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1999)
static void C_ccall f_1999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2744)
static void C_ccall f_2744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2661)
static void C_ccall f_2661(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2709)
static void C_ccall f_2709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2712)
static void C_ccall f_2712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2715)
static void C_ccall f_2715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2722)
static void C_ccall f_2722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2702)
static void C_ccall f_2702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2726)
static void C_fcall f_2726(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2619)
static void C_ccall f_2619(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2627)
static void C_ccall f_2627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2629)
static C_word C_fcall f_2629(C_word t0);
C_noret_decl(f_2610)
static void C_fcall f_2610(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2334)
static void C_ccall f_2334(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2334)
static void C_ccall f_2334r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2338)
static void C_ccall f_2338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2352)
static void C_fcall f_2352(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2544)
static void C_fcall f_2544(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2548)
static void C_ccall f_2548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2492)
static void C_fcall f_2492(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2528)
static void C_ccall f_2528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2480)
static void C_ccall f_2480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2362)
static void C_fcall f_2362(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2388)
static void C_ccall f_2388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2391)
static void C_ccall f_2391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2394)
static void C_ccall f_2394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2442)
static void C_fcall f_2442(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2455)
static void C_ccall f_2455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2458)
static void C_ccall f_2458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2397)
static void C_ccall f_2397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2400)
static void C_ccall f_2400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2403)
static void C_ccall f_2403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2406)
static void C_ccall f_2406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2426)
static void C_ccall f_2426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2415)
static void C_fcall f_2415(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2422)
static void C_ccall f_2422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2409)
static void C_fcall f_2409(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2308)
static C_word C_fcall f_2308(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_2233)
static void C_ccall f_2233(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2233)
static void C_ccall f_2233r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2237)
static void C_ccall f_2237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2290)
static void C_ccall f_2290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2296)
static void C_ccall f_2296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2240)
static void C_ccall f_2240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2251)
static void C_fcall f_2251(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2281)
static void C_ccall f_2281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2277)
static void C_ccall f_2277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2258)
static void C_ccall f_2258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2264)
static void C_ccall f_2264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2272)
static void C_ccall f_2272(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2215)
static void C_ccall f_2215(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2227)
static void C_ccall f_2227(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2221)
static void C_ccall f_2221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2197)
static void C_ccall f_2197(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2209)
static void C_ccall f_2209(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2203)
static void C_ccall f_2203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2179)
static void C_ccall f_2179(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2191)
static void C_ccall f_2191(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2185)
static void C_ccall f_2185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2161)
static void C_ccall f_2161(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2173)
static void C_ccall f_2173(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2167)
static void C_ccall f_2167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2143)
static void C_ccall f_2143(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2155)
static void C_ccall f_2155(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2149)
static void C_ccall f_2149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2128)
static void C_ccall f_2128(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2140)
static void C_ccall f_2140(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2134)
static void C_ccall f_2134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2113)
static void C_ccall f_2113(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2125)
static void C_ccall f_2125(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2119)
static void C_ccall f_2119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2098)
static void C_ccall f_2098(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2110)
static void C_ccall f_2110(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2104)
static void C_ccall f_2104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2014)
static void C_ccall f_2014(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2030)
static void C_ccall f_2030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2059)
static void C_ccall f_2059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2084)
static void C_ccall f_2084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2069)
static void C_ccall f_2069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2040)
static void C_ccall f_2040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2000)
static void C_fcall f_2000(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1917)
static void C_ccall f_1917(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1917)
static void C_ccall f_1917r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1946)
static void C_fcall f_1946(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1941)
static void C_fcall f_1941(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1919)
static void C_fcall f_1919(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1927)
static void C_ccall f_1927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1933)
static void C_ccall f_1933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1930)
static void C_ccall f_1930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1853)
static void C_ccall f_1853(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1853)
static void C_ccall f_1853r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1869)
static void C_fcall f_1869(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1864)
static void C_fcall f_1864(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1855)
static void C_fcall f_1855(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1863)
static void C_ccall f_1863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1772)
static void C_fcall f_1772(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1825)
static void C_fcall f_1825(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1801)
static void C_ccall f_1801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1808)
static void C_fcall f_1808(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1741)
static void C_fcall f_1741(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1680)
static void C_fcall f_1680(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1689)
static void C_fcall f_1689(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1719)
static void C_ccall f_1719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1727)
static void C_ccall f_1727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1633)
static void C_fcall f_1633(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1649)
static void C_fcall f_1649(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1620)
static void C_ccall f_1620(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1631)
static void C_ccall f_1631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1206)
static void C_ccall f_1206(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1206)
static void C_ccall f_1206r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1566)
static void C_fcall f_1566(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1561)
static void C_fcall f_1561(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1208)
static void C_fcall f_1208(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1221)
static void C_fcall f_1221(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1554)
static void C_ccall f_1554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1550)
static void C_ccall f_1550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1224)
static void C_ccall f_1224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1227)
static void C_ccall f_1227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1543)
static void C_ccall f_1543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1230)
static void C_ccall f_1230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1526)
static void C_ccall f_1526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1536)
static void C_ccall f_1536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1233)
static void C_ccall f_1233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1470)
static void C_ccall f_1470(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1501)
static void C_ccall f_1501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1513)
static void C_ccall f_1513(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1513)
static void C_ccall f_1513r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1519)
static void C_ccall f_1519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1507)
static void C_ccall f_1507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1476)
static void C_ccall f_1476(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1482)
static void C_ccall f_1482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1493)
static void C_ccall f_1493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1468)
static void C_ccall f_1468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1236)
static void C_ccall f_1236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1412)
static void C_ccall f_1412(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1443)
static void C_ccall f_1443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1455)
static void C_ccall f_1455(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1455)
static void C_ccall f_1455r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1461)
static void C_ccall f_1461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1449)
static void C_ccall f_1449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1418)
static void C_ccall f_1418(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1424)
static void C_ccall f_1424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1435)
static void C_ccall f_1435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1410)
static void C_ccall f_1410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1239)
static void C_ccall f_1239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1242)
static void C_ccall f_1242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1249)
static void C_ccall f_1249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1251)
static void C_fcall f_1251(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1344)
static void C_ccall f_1344(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1385)
static void C_ccall f_1385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1397)
static void C_ccall f_1397(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1397)
static void C_ccall f_1397r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1403)
static void C_ccall f_1403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1391)
static void C_ccall f_1391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1350)
static void C_ccall f_1350(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1356)
static void C_ccall f_1356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1363)
static void C_ccall f_1363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1366)
static void C_ccall f_1366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1377)
static void C_ccall f_1377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1373)
static void C_ccall f_1373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1342)
static void C_ccall f_1342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1328)
static void C_ccall f_1328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1335)
static void C_ccall f_1335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1261)
static void C_ccall f_1261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1264)
static void C_ccall f_1264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1272)
static void C_ccall f_1272(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1303)
static void C_ccall f_1303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1315)
static void C_ccall f_1315(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1315)
static void C_ccall f_1315r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1321)
static void C_ccall f_1321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1309)
static void C_ccall f_1309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1278)
static void C_ccall f_1278(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1284)
static void C_ccall f_1284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1295)
static void C_ccall f_1295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1270)
static void C_ccall f_1270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1267)
static void C_ccall f_1267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_859)
static void C_ccall f_859(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_859)
static void C_ccall f_859r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1158)
static void C_fcall f_1158(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1153)
static void C_fcall f_1153(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_861)
static void C_fcall f_861(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_874)
static void C_fcall f_874(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1146)
static void C_ccall f_1146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1142)
static void C_ccall f_1142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_877)
static void C_ccall f_877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_880)
static void C_ccall f_880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1135)
static void C_ccall f_1135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_883)
static void C_ccall f_883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1118)
static void C_ccall f_1118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1128)
static void C_ccall f_1128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_886)
static void C_ccall f_886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1062)
static void C_ccall f_1062(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1093)
static void C_ccall f_1093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1105)
static void C_ccall f_1105(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1105)
static void C_ccall f_1105r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1111)
static void C_ccall f_1111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1099)
static void C_ccall f_1099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1068)
static void C_ccall f_1068(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1074)
static void C_ccall f_1074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1085)
static void C_ccall f_1085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1060)
static void C_ccall f_1060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_889)
static void C_ccall f_889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1004)
static void C_ccall f_1004(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1035)
static void C_ccall f_1035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1047)
static void C_ccall f_1047(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1047)
static void C_ccall f_1047r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1053)
static void C_ccall f_1053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1041)
static void C_ccall f_1041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1010)
static void C_ccall f_1010(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1016)
static void C_ccall f_1016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1027)
static void C_ccall f_1027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1002)
static void C_ccall f_1002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_892)
static void C_ccall f_892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_895)
static void C_ccall f_895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_902)
static void C_ccall f_902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_904)
static void C_fcall f_904(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_936)
static void C_ccall f_936(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_977)
static void C_ccall f_977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_989)
static void C_ccall f_989(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_989)
static void C_ccall f_989r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_995)
static void C_ccall f_995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_983)
static void C_ccall f_983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_942)
static void C_ccall f_942(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_948)
static void C_ccall f_948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_955)
static void C_ccall f_955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_958)
static void C_ccall f_958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_969)
static void C_ccall f_969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_965)
static void C_ccall f_965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_934)
static void C_ccall f_934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_920)
static void C_ccall f_920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_927)
static void C_ccall f_927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_914)
static void C_ccall f_914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_917)
static void C_ccall f_917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_844)
static void C_ccall f_844(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_851)
static void C_ccall f_851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_857)
static void C_ccall f_857(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1618)
static void C_fcall trf_1618(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1618(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1618(t0,t1);}

C_noret_decl(trf_2726)
static void C_fcall trf_2726(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2726(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2726(t0,t1);}

C_noret_decl(trf_2610)
static void C_fcall trf_2610(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2610(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2610(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2352)
static void C_fcall trf_2352(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2352(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2352(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2544)
static void C_fcall trf_2544(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2544(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2544(t0,t1);}

C_noret_decl(trf_2492)
static void C_fcall trf_2492(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2492(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2492(t0,t1);}

C_noret_decl(trf_2362)
static void C_fcall trf_2362(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2362(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2362(t0,t1);}

C_noret_decl(trf_2442)
static void C_fcall trf_2442(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2442(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2442(t0,t1,t2);}

C_noret_decl(trf_2415)
static void C_fcall trf_2415(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2415(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2415(t0,t1);}

C_noret_decl(trf_2409)
static void C_fcall trf_2409(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2409(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2409(t0,t1);}

C_noret_decl(trf_2251)
static void C_fcall trf_2251(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2251(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2251(t0,t1);}

C_noret_decl(trf_2000)
static void C_fcall trf_2000(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2000(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2000(t0,t1);}

C_noret_decl(trf_1946)
static void C_fcall trf_1946(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1946(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1946(t0,t1);}

C_noret_decl(trf_1941)
static void C_fcall trf_1941(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1941(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1941(t0,t1,t2);}

C_noret_decl(trf_1919)
static void C_fcall trf_1919(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1919(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1919(t0,t1,t2,t3);}

C_noret_decl(trf_1869)
static void C_fcall trf_1869(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1869(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1869(t0,t1);}

C_noret_decl(trf_1864)
static void C_fcall trf_1864(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1864(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1864(t0,t1,t2);}

C_noret_decl(trf_1855)
static void C_fcall trf_1855(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1855(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1855(t0,t1,t2,t3);}

C_noret_decl(trf_1772)
static void C_fcall trf_1772(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1772(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_1772(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_1825)
static void C_fcall trf_1825(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1825(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1825(t0,t1);}

C_noret_decl(trf_1808)
static void C_fcall trf_1808(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1808(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1808(t0,t1);}

C_noret_decl(trf_1741)
static void C_fcall trf_1741(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1741(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1741(t0,t1,t2,t3);}

C_noret_decl(trf_1680)
static void C_fcall trf_1680(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1680(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1680(t0,t1,t2,t3);}

C_noret_decl(trf_1689)
static void C_fcall trf_1689(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1689(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1689(t0,t1,t2);}

C_noret_decl(trf_1633)
static void C_fcall trf_1633(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1633(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1633(t0,t1,t2);}

C_noret_decl(trf_1649)
static void C_fcall trf_1649(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1649(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1649(t0,t1);}

C_noret_decl(trf_1566)
static void C_fcall trf_1566(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1566(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1566(t0,t1);}

C_noret_decl(trf_1561)
static void C_fcall trf_1561(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1561(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1561(t0,t1,t2);}

C_noret_decl(trf_1208)
static void C_fcall trf_1208(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1208(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1208(t0,t1,t2,t3);}

C_noret_decl(trf_1221)
static void C_fcall trf_1221(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1221(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1221(t0,t1);}

C_noret_decl(trf_1251)
static void C_fcall trf_1251(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1251(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1251(t0,t1,t2,t3);}

C_noret_decl(trf_1158)
static void C_fcall trf_1158(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1158(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1158(t0,t1);}

C_noret_decl(trf_1153)
static void C_fcall trf_1153(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1153(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1153(t0,t1,t2);}

C_noret_decl(trf_861)
static void C_fcall trf_861(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_861(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_861(t0,t1,t2,t3);}

C_noret_decl(trf_874)
static void C_fcall trf_874(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_874(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_874(t0,t1);}

C_noret_decl(trf_904)
static void C_fcall trf_904(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_904(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_904(t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_files_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_files_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("files_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(561)){
C_save(t1);
C_rereclaim2(561*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,102);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],12,"file-exists\077");
lf[3]=C_h_intern(&lf[3],11,"delete-file");
lf[4]=C_h_intern(&lf[4],12,"delete-file*");
lf[5]=C_h_intern(&lf[5],9,"file-copy");
lf[6]=C_h_intern(&lf[6],17,"close-output-port");
lf[7]=C_h_intern(&lf[7],16,"close-input-port");
lf[8]=C_h_intern(&lf[8],12,"read-string!");
lf[9]=C_h_intern(&lf[9],9,"condition");
lf[10]=C_h_intern(&lf[10],9,"\003syserror");
lf[11]=C_h_intern(&lf[11],13,"string-append");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\037error writing file starting at ");
lf[13]=C_h_intern(&lf[13],12,"write-string");
lf[14]=C_h_intern(&lf[14],22,"with-exception-handler");
lf[15]=C_h_intern(&lf[15],30,"call-with-current-continuation");
lf[16]=C_h_intern(&lf[16],11,"make-string");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\000#could not open newfile for write - ");
lf[18]=C_h_intern(&lf[18],16,"open-output-file");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000#could not open origfile for read - ");
lf[20]=C_h_intern(&lf[20],15,"open-input-file");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000&newfile exists but clobber is false - ");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\032origfile does not exist - ");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\0002invalid blocksize given: not a positive integer - ");
lf[24]=C_h_intern(&lf[24],9,"file-move");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\034could not remove origfile - ");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000\037error writing file starting at ");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000#could not open newfile for write - ");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000#could not open origfile for read - ");
lf[29]=C_decode_literal(C_heaptop,"\376B\000\000&newfile exists but clobber is false - ");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\032origfile does not exist - ");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\0002invalid blocksize given: not a positive integer - ");
lf[35]=C_h_intern(&lf[35],12,"string-match");
lf[36]=C_h_intern(&lf[36],18,"absolute-pathname\077");
lf[38]=C_h_intern(&lf[38],13,"\003syssubstring");
lf[39]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[40]=C_h_intern(&lf[40],13,"make-pathname");
lf[41]=C_h_intern(&lf[41],22,"make-absolute-pathname");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[49]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[50]=C_h_intern(&lf[50],17,"\003sysstring-append");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[53]=C_h_intern(&lf[53],18,"decompose-pathname");
lf[54]=C_h_intern(&lf[54],18,"pathname-directory");
lf[55]=C_h_intern(&lf[55],13,"pathname-file");
lf[56]=C_h_intern(&lf[56],18,"pathname-extension");
lf[57]=C_h_intern(&lf[57],24,"pathname-strip-directory");
lf[58]=C_h_intern(&lf[58],24,"pathname-strip-extension");
lf[59]=C_h_intern(&lf[59],26,"pathname-replace-directory");
lf[60]=C_h_intern(&lf[60],21,"pathname-replace-file");
lf[61]=C_h_intern(&lf[61],26,"pathname-replace-extension");
lf[62]=C_h_intern(&lf[62],24,"get-environment-variable");
lf[63]=C_h_intern(&lf[63],21,"call-with-output-file");
lf[64]=C_h_intern(&lf[64],21,"create-temporary-file");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\003tmp");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\004/tmp");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\003TMP");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\004TEMP");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\006TMPDIR");
lf[71]=C_h_intern(&lf[71],18,"open-output-string");
lf[72]=C_h_intern(&lf[72],17,"get-output-string");
lf[73]=C_h_intern(&lf[73],7,"reverse");
lf[74]=C_h_intern(&lf[74],7,"display");
lf[75]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\004msvc\376\003\000\000\002\376\001\000\000\007mingw32\376\377\016");
lf[76]=C_h_intern(&lf[76],7,"windows");
lf[77]=C_h_intern(&lf[77],4,"unix");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[80]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002..\376\377\016");
lf[81]=C_h_intern(&lf[81],18,"normalize-pathname");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[84]=C_h_intern(&lf[84],20,"\003sysexpand-home-path");
lf[85]=C_h_intern(&lf[85],16,"\003syswrite-char-0");
lf[86]=C_h_intern(&lf[86],12,"string-split");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[89]=C_h_intern(&lf[89],15,"directory-null\077");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[92]=C_h_intern(&lf[92],19,"decompose-directory");
lf[93]=C_h_intern(&lf[93],14,"build-platform");
lf[94]=C_h_intern(&lf[94],6,"regexp");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\034^(.*[\134/\134\134])\077((\134.)\077[^\134/\134\134]+)$");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000&^(.*[\134/\134\134])\077([^\134/\134\134]+)(\134.([^\134/\134\134.]+))$");
lf[97]=C_h_intern(&lf[97],20,"\003syswindows-platform");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\026([A-Za-z]:)\077([\134/\134\134]).*");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\012([\134/\134\134]).*");
lf[100]=C_h_intern(&lf[100],17,"register-feature!");
lf[101]=C_h_intern(&lf[101],5,"files");
C_register_lf2(lf,102,create_ptable());
t2=C_mutate(&lf[0] /* (set! c172 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_836,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k834 */
static void C_ccall f_836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_836,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_839,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k837 in k834 */
static void C_ccall f_839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_839,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_842,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* files.scm: 62   register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[100]+1)))(3,*((C_word*)lf[100]+1),t2,lf[101]);}

/* k840 in k837 in k834 */
static void C_ccall f_842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_842,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=*((C_word*)lf[3]+1);
t4=C_mutate((C_word*)lf[4]+1 /* (set! delete-file* ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_844,a[2]=t2,a[3]=t3,a[4]=((C_word)li0),tmp=(C_word)a,a+=5,tmp));
t5=C_mutate((C_word*)lf[5]+1 /* (set! file-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_859,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[24]+1 /* (set! file-move ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1206,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp));
t7=lf[32] /* absolute-pathname-root */ =C_SCHEME_UNDEFINED;;
t8=lf[33] /* root-origin */ =C_SCHEME_UNDEFINED;;
t9=lf[34] /* root-directory */ =C_SCHEME_UNDEFINED;;
t10=*((C_word*)lf[35]+1);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1618,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(*((C_word*)lf[97]+1))){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2747,a[2]=t11,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
/* files.scm: 177  regexp */
t13=*((C_word*)lf[94]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,lf[98]);}
else{
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2774,a[2]=t11,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
/* files.scm: 181  regexp */
t13=*((C_word*)lf[94]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,lf[99]);}}

/* k2772 in k840 in k837 in k834 */
static void C_ccall f_2774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2774,2,t0,t1);}
t2=C_mutate(&lf[32] /* (set! absolute-pathname-root ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2776,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li114),tmp=(C_word)a,a+=5,tmp));
t3=C_mutate(&lf[33] /* (set! root-origin ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2782,a[2]=((C_word)li115),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[34] /* (set! root-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2785,a[2]=((C_word)li116),tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t0)[2];
f_1618(t5,t4);}

/* root-directory in k2772 in k840 in k837 in k834 */
static void C_ccall f_2785(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2785,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_i_cadr(t2):C_SCHEME_FALSE));}

/* root-origin in k2772 in k840 in k837 in k834 */
static void C_ccall f_2782(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2782,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* absolute-pathname-root in k2772 in k840 in k837 in k834 */
static void C_ccall f_2776(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2776,3,t0,t1,t2);}
/* files.scm: 182  string-match */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* k2745 in k840 in k837 in k834 */
static void C_ccall f_2747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2747,2,t0,t1);}
t2=C_mutate(&lf[32] /* (set! absolute-pathname-root ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2749,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li111),tmp=(C_word)a,a+=5,tmp));
t3=C_mutate(&lf[33] /* (set! root-origin ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2755,a[2]=((C_word)li112),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[34] /* (set! root-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2764,a[2]=((C_word)li113),tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t0)[2];
f_1618(t5,t4);}

/* f_2764 in k2745 in k840 in k837 in k834 */
static void C_ccall f_2764(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2764,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_i_caddr(t2):C_SCHEME_FALSE));}

/* f_2755 in k2745 in k840 in k837 in k834 */
static void C_ccall f_2755(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2755,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_i_cadr(t2):C_SCHEME_FALSE));}

/* f_2749 in k2745 in k840 in k837 in k834 */
static void C_ccall f_2749(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2749,3,t0,t1,t2);}
/* files.scm: 178  string-match */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* k1616 in k840 in k837 in k834 */
static void C_fcall f_1618(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1618,NULL,2,t0,t1);}
t2=C_mutate((C_word*)lf[36]+1 /* (set! absolute-pathname? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1620,a[2]=((C_word)li60),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate(&lf[37] /* (set! chop-pds ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1633,a[2]=((C_word)li61),tmp=(C_word)a,a+=3,tmp));
t4=C_set_block_item(lf[40] /* make-pathname */,0,C_SCHEME_UNDEFINED);
t5=C_set_block_item(lf[41] /* make-absolute-pathname */,0,C_SCHEME_UNDEFINED);
t6=*((C_word*)lf[11]+1);
t7=*((C_word*)lf[36]+1);
t8=lf[42];
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1680,a[2]=t6,a[3]=t8,a[4]=((C_word)li63),tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1741,a[2]=t9,a[3]=((C_word)li64),tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1772,a[2]=t6,a[3]=((C_word)li65),tmp=(C_word)a,a+=4,tmp);
t12=C_mutate((C_word*)lf[40]+1 /* (set! make-pathname ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1853,a[2]=t10,a[3]=t11,a[4]=((C_word)li69),tmp=(C_word)a,a+=5,tmp));
t13=C_mutate((C_word*)lf[41]+1 /* (set! make-absolute-pathname ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1917,a[2]=t10,a[3]=t7,a[4]=t8,a[5]=t11,a[6]=((C_word)li73),tmp=(C_word)a,a+=7,tmp));
t14=*((C_word*)lf[35]+1);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1996,a[2]=((C_word*)t0)[2],a[3]=t14,tmp=(C_word)a,a+=4,tmp);
/* files.scm: 267  regexp */
t16=*((C_word*)lf[94]+1);
((C_proc3)(void*)(*((C_word*)t16+1)))(3,t16,t15,lf[96]);}

/* k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_1996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1996,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1999,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* files.scm: 268  regexp */
t3=*((C_word*)lf[94]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[95]);}

/* k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_1999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1999,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2000,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp);
t3=C_mutate((C_word*)lf[53]+1 /* (set! decompose-pathname ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2014,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li75),tmp=(C_word)a,a+=7,tmp));
t4=C_set_block_item(lf[54] /* pathname-directory */,0,C_SCHEME_UNDEFINED);
t5=C_set_block_item(lf[55] /* pathname-file */,0,C_SCHEME_UNDEFINED);
t6=C_set_block_item(lf[56] /* pathname-extension */,0,C_SCHEME_UNDEFINED);
t7=C_set_block_item(lf[57] /* pathname-strip-directory */,0,C_SCHEME_UNDEFINED);
t8=C_set_block_item(lf[58] /* pathname-strip-extension */,0,C_SCHEME_UNDEFINED);
t9=C_set_block_item(lf[59] /* pathname-replace-directory */,0,C_SCHEME_UNDEFINED);
t10=C_set_block_item(lf[60] /* pathname-replace-file */,0,C_SCHEME_UNDEFINED);
t11=C_set_block_item(lf[61] /* pathname-replace-extension */,0,C_SCHEME_UNDEFINED);
t12=*((C_word*)lf[53]+1);
t13=C_mutate((C_word*)lf[54]+1 /* (set! pathname-directory ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2098,a[2]=t12,a[3]=((C_word)li78),tmp=(C_word)a,a+=4,tmp));
t14=C_mutate((C_word*)lf[55]+1 /* (set! pathname-file ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2113,a[2]=t12,a[3]=((C_word)li81),tmp=(C_word)a,a+=4,tmp));
t15=C_mutate((C_word*)lf[56]+1 /* (set! pathname-extension ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2128,a[2]=t12,a[3]=((C_word)li84),tmp=(C_word)a,a+=4,tmp));
t16=C_mutate((C_word*)lf[57]+1 /* (set! pathname-strip-directory ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2143,a[2]=t12,a[3]=((C_word)li87),tmp=(C_word)a,a+=4,tmp));
t17=C_mutate((C_word*)lf[58]+1 /* (set! pathname-strip-extension ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2161,a[2]=t12,a[3]=((C_word)li90),tmp=(C_word)a,a+=4,tmp));
t18=C_mutate((C_word*)lf[59]+1 /* (set! pathname-replace-directory ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2179,a[2]=t12,a[3]=((C_word)li93),tmp=(C_word)a,a+=4,tmp));
t19=C_mutate((C_word*)lf[60]+1 /* (set! pathname-replace-file ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2197,a[2]=t12,a[3]=((C_word)li96),tmp=(C_word)a,a+=4,tmp));
t20=C_mutate((C_word*)lf[61]+1 /* (set! pathname-replace-extension ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2215,a[2]=t12,a[3]=((C_word)li99),tmp=(C_word)a,a+=4,tmp));
t21=*((C_word*)lf[62]+1);
t22=*((C_word*)lf[40]+1);
t23=*((C_word*)lf[2]+1);
t24=*((C_word*)lf[63]+1);
t25=C_mutate((C_word*)lf[64]+1 /* (set! create-temporary-file ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2233,a[2]=t21,a[3]=t22,a[4]=t23,a[5]=t24,a[6]=((C_word)li102),tmp=(C_word)a,a+=7,tmp));
t26=*((C_word*)lf[71]+1);
t27=*((C_word*)lf[72]+1);
t28=*((C_word*)lf[62]+1);
t29=*((C_word*)lf[73]+1);
t30=*((C_word*)lf[74]+1);
t31=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2744,a[2]=((C_word*)t0)[2],a[3]=t26,a[4]=t29,a[5]=t30,a[6]=t27,tmp=(C_word)a,a+=7,tmp);
/* files.scm: 365  build-platform */
((C_proc2)C_retrieve_proc(*((C_word*)lf[93]+1)))(2,*((C_word*)lf[93]+1),t31);}

/* k2742 in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2744,2,t0,t1);}
t2=(C_word)C_i_memq(t1,lf[75]);
t3=(C_truep(t2)?lf[76]:lf[77]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2308,a[2]=((C_word)li103),tmp=(C_word)a,a+=3,tmp);
t5=C_mutate((C_word*)lf[81]+1 /* (set! normalize-pathname ...) */,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2334,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word)li106),tmp=(C_word)a,a+=9,tmp));
t6=*((C_word*)lf[86]+1);
t7=C_mutate(&lf[87] /* (set! split-directory ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2610,a[2]=t6,a[3]=((C_word)li107),tmp=(C_word)a,a+=4,tmp));
t8=C_mutate((C_word*)lf[89]+1 /* (set! directory-null? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2619,a[2]=((C_word)li109),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[92]+1 /* (set! decompose-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2661,a[2]=((C_word)li110),tmp=(C_word)a,a+=3,tmp));
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}

/* decompose-directory in k2742 in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2661(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2661,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2709,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* files.scm: 456  split-directory */
t4=lf[87];
f_2610(t4,t3,lf[92],t2,C_SCHEME_FALSE);}

/* k2707 in decompose-directory in k2742 in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2709,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2712,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* files.scm: 457  absolute-pathname-root */
((C_proc3)C_retrieve_proc(lf[32]))(3,lf[32],t2,((C_word*)t0)[2]);}

/* k2710 in k2707 in decompose-directory in k2742 in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2712,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2715,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* files.scm: 458  root-origin */
((C_proc3)C_retrieve_proc(lf[33]))(3,lf[33],t2,t1);}

/* k2713 in k2710 in k2707 in decompose-directory in k2742 in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2722,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* files.scm: 459  root-directory */
((C_proc3)C_retrieve_proc(lf[34]))(3,lf[34],t2,((C_word*)t0)[2]);}

/* k2720 in k2713 in k2710 in k2707 in decompose-directory in k2742 in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2722,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2726,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_nullp(((C_word*)t0)[2]);
t4=(C_truep(t3)?C_SCHEME_FALSE:((C_word*)t0)[2]);
t5=((C_word*)t0)[3];
if(C_truep(t5)){
t6=(C_word)C_i_car(t4);
t7=(C_word)C_block_size(t5);
if(C_truep((C_word)C_substring_compare(t5,t6,C_fix(0),C_fix(0),t7))){
t8=(C_word)C_i_cdr(t4);
t9=(C_word)C_block_size(t6);
t10=(C_word)C_block_size(t9);
t11=(C_word)C_eqp(t7,t10);
if(C_truep(t11)){
t12=t2;
f_2726(t12,t8);}
else{
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2702,a[2]=t8,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* files.scm: 455  ##sys#substring */
t13=*((C_word*)lf[38]+1);
((C_proc5)(void*)(*((C_word*)t13+1)))(5,t13,t12,t6,t7,t9);}}
else{
t8=t2;
f_2726(t8,t4);}}
else{
t6=t2;
f_2726(t6,t4);}}

/* k2700 in k2720 in k2713 in k2710 in k2707 in decompose-directory in k2742 in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2702,2,t0,t1);}
t2=((C_word*)t0)[3];
f_2726(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k2724 in k2720 in k2713 in k2710 in k2707 in decompose-directory in k2742 in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_fcall f_2726(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 459  values */
C_values(5,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* directory-null? in k2742 in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2619(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2619,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2627,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=t3;
f_2627(2,t4,t2);}
else{
/* files.scm: 430  split-directory */
t4=lf[87];
f_2610(t4,t3,lf[89],t2,C_SCHEME_TRUE);}}

/* k2625 in directory-null? in k2742 in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2627,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2629,a[2]=((C_word)li108),tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2629(t1));}

/* loop in k2625 in directory-null? in k2742 in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static C_word C_fcall f_2629(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
t2=(C_word)C_i_nullp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_word)C_i_car(t1);
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[90]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[91]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=(C_word)C_i_cdr(t1);
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* split-directory in k2742 in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_fcall f_2610(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2610,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t3,t2);
/* files.scm: 424  string-split */
t6=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,t3,lf[88],t4);}

/* normalize-pathname in k2742 in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2334(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_2334r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2334r(t0,t1,t2,t3);}}

static void C_ccall f_2334r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2338,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2338(2,t5,((C_word*)t0)[2]);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2338(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2336 in normalize-pathname in k2742 in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2338,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[76]);
t3=(C_truep(t2)?C_make_character(92):C_make_character(47));
t4=(C_word)C_i_check_string_2(((C_word*)t0)[8],lf[81]);
t5=(C_word)C_block_size(((C_word*)t0)[8]);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2352,a[2]=t1,a[3]=t11,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t9,a[11]=t3,a[12]=t7,a[13]=t5,a[14]=((C_word)li105),tmp=(C_word)a,a+=15,tmp));
t13=((C_word*)t11)[1];
f_2352(t13,((C_word*)t0)[2],C_fix(0),C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in k2336 in normalize-pathname in k2742 in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_fcall f_2352(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2352,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[13]))){
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2362,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t5,tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t2,t3))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2480,a[2]=t6,a[3]=t5,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* files.scm: 379  ##sys#substring */
t8=*((C_word*)lf[38]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,((C_word*)t0)[4],t3,t2);}
else{
t7=t6;
f_2362(t7,C_SCHEME_UNDEFINED);}}
else{
t6=(C_word)C_i_string_ref(((C_word*)t0)[4],t2);
if(C_truep((C_truep((C_word)C_eqp(t6,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t6,C_make_character(47)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2492,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t8=(C_word)C_i_nullp(((C_word*)t5)[1]);
t9=(C_truep(t8)?(C_word)C_eqp(t2,t3):C_SCHEME_FALSE);
if(C_truep(t9)){
t10=C_set_block_item(((C_word*)t0)[12],0,C_SCHEME_TRUE);
t11=t7;
f_2492(t11,t10);}
else{
t10=t7;
f_2492(t10,C_SCHEME_UNDEFINED);}}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2544,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t2,a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t5)[1]))){
t8=(C_word)C_i_string_ref(((C_word*)t0)[4],t2);
t9=(C_word)C_eqp(t8,C_make_character(58));
t10=t7;
f_2544(t10,(C_truep(t9)?(C_word)C_eqp(lf[76],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
t8=t7;
f_2544(t8,C_SCHEME_FALSE);}}}}

/* k2542 in loop in k2336 in normalize-pathname in k2742 in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_fcall f_2544(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2544,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2548,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* files.scm: 412  ##sys#substring */
t4=*((C_word*)lf[38]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[4],C_fix(0),t3);}
else{
t2=(C_word)C_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* files.scm: 414  loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_2352(t3,((C_word*)t0)[5],t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}}

/* k2546 in k2542 in loop in k2336 in normalize-pathname in k2742 in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* files.scm: 413  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2352(t5,((C_word*)t0)[2],t3,t4,C_SCHEME_END_OF_LIST);}

/* k2490 in loop in k2336 in normalize-pathname in k2742 in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_fcall f_2492(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2492,NULL,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[8],((C_word*)t0)[7]);
if(C_truep(t2)){
t3=(C_word)C_fixnum_plus(((C_word*)t0)[8],C_fix(1));
t4=(C_word)C_fixnum_plus(((C_word*)t0)[8],C_fix(1));
/* files.scm: 405  loop */
t5=((C_word*)((C_word*)t0)[6])[1];
f_2352(t5,((C_word*)t0)[5],t3,t4,((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=(C_word)C_fixnum_plus(((C_word*)t0)[8],C_fix(1));
t4=(C_word)C_fixnum_plus(((C_word*)t0)[8],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2528,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* files.scm: 408  ##sys#substring */
t6=*((C_word*)lf[38]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[2],((C_word*)t0)[7],((C_word*)t0)[8]);}}

/* k2526 in k2490 in loop in k2336 in normalize-pathname in k2742 in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2528,2,t0,t1);}
t2=f_2308(C_a_i(&a,3),t1,((C_word*)((C_word*)t0)[6])[1]);
/* files.scm: 406  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2352(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2478 in loop in k2336 in normalize-pathname in k2742 in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2480,2,t0,t1);}
t2=f_2308(C_a_i(&a,3),t1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_2362(t4,t3);}

/* k2360 in loop in k2336 in normalize-pathname in k2742 in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_fcall f_2362(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2362,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[12])[1]))){
if(C_truep(((C_word*)((C_word*)t0)[11])[1])){
t2=(C_word)C_a_i_string(&a,1,((C_word*)t0)[10]);
/* files.scm: 382  ##sys#string-append */
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[9],t2,lf[82]);}
else{
t2=(C_word)C_a_i_string(&a,1,((C_word*)t0)[10]);
/* files.scm: 383  ##sys#string-append */
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[9],lf[83],t2);}}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2388,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
/* files.scm: 384  open-output-string */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}}

/* k2386 in k2360 in loop in k2336 in normalize-pathname in k2742 in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2388,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2391,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* files.scm: 385  reverse */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k2389 in k2386 in k2360 in loop in k2336 in normalize-pathname in k2742 in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2391,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2394,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_i_car(t1);
/* files.scm: 386  display */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)t0)[5]);}

/* k2392 in k2389 in k2386 in k2360 in loop in k2336 in normalize-pathname in k2742 in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2397,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2442,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=((C_word)li104),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_2442(t7,t2,t3);}

/* loop726 in k2392 in k2389 in k2386 in k2360 in loop in k2336 in normalize-pathname in k2742 in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_fcall f_2442(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2442,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2455,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* files.scm: 389  ##sys#write-char-0 */
((C_proc4)C_retrieve_proc(*((C_word*)lf[85]+1)))(4,*((C_word*)lf[85]+1),t4,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2453 in loop726 in k2392 in k2389 in k2386 in k2360 in loop in k2336 in normalize-pathname in k2742 in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2458,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* files.scm: 390  display */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2456 in k2453 in loop726 in k2392 in k2389 in k2386 in k2360 in loop in k2336 in normalize-pathname in k2742 in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2442(t3,((C_word*)t0)[2],t2);}

/* k2395 in k2392 in k2389 in k2386 in k2360 in loop in k2336 in normalize-pathname in k2742 in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2400,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)t0)[2]);
if(C_truep(t3)){
/* files.scm: 392  ##sys#write-char-0 */
((C_proc4)C_retrieve_proc(*((C_word*)lf[85]+1)))(4,*((C_word*)lf[85]+1),t2,((C_word*)t0)[6],((C_word*)t0)[4]);}
else{
t4=t2;
f_2400(2,t4,C_SCHEME_UNDEFINED);}}

/* k2398 in k2395 in k2392 in k2389 in k2386 in k2360 in loop in k2336 in normalize-pathname in k2742 in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2400,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2403,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* files.scm: 393  get-output-string */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2360 in loop in k2336 in normalize-pathname in k2742 in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2403,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2406,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* files.scm: 394  ##sys#expand-home-path */
((C_proc3)C_retrieve_proc(*((C_word*)lf[84]+1)))(3,*((C_word*)lf[84]+1),t2,t1);}

/* k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2360 in loop in k2336 in normalize-pathname in k2742 in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2406,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2409,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_string_equal_p(((C_word*)t0)[5],((C_word*)t3)[1]))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2415,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2426,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_a_i_string(&a,1,((C_word*)t0)[2]);
/* files.scm: 397  ##sys#string-append */
t8=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t3)[1]);}
else{
t6=t5;
f_2415(t6,C_SCHEME_UNDEFINED);}}
else{
t5=t4;
f_2409(t5,C_SCHEME_UNDEFINED);}}

/* k2424 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2360 in loop in k2336 in normalize-pathname in k2742 in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2415(t3,t2);}

/* k2413 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2360 in loop in k2336 in normalize-pathname in k2742 in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_fcall f_2415(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2415,NULL,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2422,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* files.scm: 399  ##sys#string-append */
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);}
else{
t2=((C_word*)t0)[2];
f_2409(t2,C_SCHEME_UNDEFINED);}}

/* k2420 in k2413 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2360 in loop in k2336 in normalize-pathname in k2742 in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2409(t3,t2);}

/* k2407 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2360 in loop in k2336 in normalize-pathname in k2742 in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_fcall f_2409(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* addpart in k2742 in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static C_word C_fcall f_2308(C_word *a,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_stack_check;
if(C_truep((C_word)C_i_string_equal_p(lf[78],t1))){
return(t2);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[79],t1))){
t3=(C_word)C_i_nullp(t2);
return((C_truep(t3)?lf[80]:(C_word)C_i_cdr(t2)));}
else{
return((C_word)C_a_i_cons(&a,2,t1,t2));}}}

/* create-temporary-file in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2233(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2233r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2233r(t0,t1,t2);}}

static void C_ccall f_2233r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2237,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* files.scm: 343  get-environment-variable */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[70]);}

/* k2235 in create-temporary-file in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2237,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2240,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_2240(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2290,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* files.scm: 344  get-environment-variable */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[69]);}}

/* k2288 in k2235 in create-temporary-file in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2290,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_2240(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2296,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* files.scm: 345  get-environment-variable */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[68]);}}

/* k2294 in k2288 in k2235 in create-temporary-file in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2240(2,t2,t1);}
else{
/* files.scm: 346  file-exists? */
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],lf[67]);}}

/* k2238 in k2235 in create-temporary-file in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2240,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[6]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[6],C_fix(0)):lf[65]);
t4=(C_word)C_i_check_string_2(t3,lf[64]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2251,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t6,a[8]=((C_word)li101),tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_2251(t8,((C_word*)t0)[2]);}

/* loop in k2238 in k2235 in create-temporary-file in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_fcall f_2251(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2251,NULL,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(16));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2258,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2277,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2281,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* files.scm: 351  number->string */
C_number_to_string(4,0,t5,t2,C_fix(16));}

/* k2279 in loop in k2238 in k2235 in create-temporary-file in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 351  ##sys#string-append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[66],t1);}

/* k2275 in loop in k2238 in k2235 in create-temporary-file in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 351  make-pathname */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2256 in loop in k2238 in k2235 in create-temporary-file in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2258,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2264,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* files.scm: 352  file-exists? */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k2262 in k2256 in loop in k2238 in k2235 in create-temporary-file in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2264,2,t0,t1);}
if(C_truep(t1)){
/* files.scm: 353  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2251(t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2272,a[2]=((C_word*)t0)[3],a[3]=((C_word)li100),tmp=(C_word)a,a+=4,tmp);
/* files.scm: 354  call-with-output-file */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],((C_word*)t0)[3],t2);}}

/* a2271 in k2262 in k2256 in loop in k2238 in k2235 in create-temporary-file in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2272(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2272,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* pathname-replace-extension in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2215(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2215,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2221,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li97),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2227,a[2]=t3,a[3]=((C_word)li98),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a2226 in pathname-replace-extension in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2227(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2227,5,t0,t1,t2,t3,t4);}
/* files.scm: 335  make-pathname */
((C_proc5)C_retrieve_proc(*((C_word*)lf[40]+1)))(5,*((C_word*)lf[40]+1),t1,t2,t3,((C_word*)t0)[2]);}

/* a2220 in pathname-replace-extension in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2221,2,t0,t1);}
/* files.scm: 334  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-replace-file in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2197(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2197,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2203,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li94),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2209,a[2]=t3,a[3]=((C_word)li95),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a2208 in pathname-replace-file in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2209(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2209,5,t0,t1,t2,t3,t4);}
/* files.scm: 330  make-pathname */
((C_proc5)C_retrieve_proc(*((C_word*)lf[40]+1)))(5,*((C_word*)lf[40]+1),t1,t2,((C_word*)t0)[2],t4);}

/* a2202 in pathname-replace-file in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2203,2,t0,t1);}
/* files.scm: 329  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-replace-directory in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2179(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2179,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2185,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li91),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2191,a[2]=t3,a[3]=((C_word)li92),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a2190 in pathname-replace-directory in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2191(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2191,5,t0,t1,t2,t3,t4);}
/* files.scm: 325  make-pathname */
((C_proc5)C_retrieve_proc(*((C_word*)lf[40]+1)))(5,*((C_word*)lf[40]+1),t1,((C_word*)t0)[2],t3,t4);}

/* a2184 in pathname-replace-directory in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2185,2,t0,t1);}
/* files.scm: 324  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-strip-extension in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2161(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2161,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2167,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li88),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2173,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a2172 in pathname-strip-extension in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2173(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2173,5,t0,t1,t2,t3,t4);}
/* files.scm: 320  make-pathname */
((C_proc4)C_retrieve_proc(*((C_word*)lf[40]+1)))(4,*((C_word*)lf[40]+1),t1,t2,t3);}

/* a2166 in pathname-strip-extension in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2167,2,t0,t1);}
/* files.scm: 319  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-strip-directory in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2143(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2143,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2149,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li85),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2155,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a2154 in pathname-strip-directory in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2155(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2155,5,t0,t1,t2,t3,t4);}
/* files.scm: 315  make-pathname */
((C_proc5)C_retrieve_proc(*((C_word*)lf[40]+1)))(5,*((C_word*)lf[40]+1),t1,C_SCHEME_FALSE,t3,t4);}

/* a2148 in pathname-strip-directory in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2149,2,t0,t1);}
/* files.scm: 314  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-extension in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2128(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2128,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2134,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li82),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2140,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a2139 in pathname-extension in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2140(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2140,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* a2133 in pathname-extension in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2134,2,t0,t1);}
/* files.scm: 309  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-file in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2113(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2113,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2119,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li79),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2125,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a2124 in pathname-file in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2125(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2125,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* a2118 in pathname-file in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2119,2,t0,t1);}
/* files.scm: 304  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-directory in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2098(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2098,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2104,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li76),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2110,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a2109 in pathname-directory in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2110(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2110,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* a2103 in pathname-directory in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2104,2,t0,t1);}
/* files.scm: 299  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* decompose-pathname in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2014(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2014,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[53]);
t4=(C_word)C_block_size(t2);
t5=(C_word)C_eqp(C_fix(0),t4);
if(C_truep(t5)){
/* files.scm: 278  values */
C_values(5,0,t1,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2030,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* files.scm: 279  string-match */
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[2],t2);}}

/* k2028 in decompose-pathname in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2030,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2040,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(t1);
/* files.scm: 281  strip-pds */
f_2000(t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2059,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* files.scm: 282  string-match */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4]);}}

/* k2057 in k2028 in decompose-pathname in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2059,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2069,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(t1);
/* files.scm: 284  strip-pds */
f_2000(t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2084,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* files.scm: 285  strip-pds */
f_2000(t2,((C_word*)t0)[2]);}}

/* k2082 in k2057 in k2028 in decompose-pathname in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 285  values */
C_values(5,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k2067 in k2057 in k2028 in decompose-pathname in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_caddr(((C_word*)t0)[3]);
/* files.scm: 284  values */
C_values(5,0,((C_word*)t0)[2],t1,t2,C_SCHEME_FALSE);}

/* k2038 in k2028 in decompose-pathname in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_ccall f_2040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_caddr(((C_word*)t0)[3]);
t3=(C_word)C_i_cddddr(((C_word*)t0)[3]);
t4=(C_word)C_i_car(t3);
/* files.scm: 281  values */
C_values(5,0,((C_word*)t0)[2],t1,t2,t4);}

/* strip-pds in k1997 in k1994 in k1616 in k840 in k837 in k834 */
static void C_fcall f_2000(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2000,NULL,2,t1,t2);}
if(C_truep(t2)){
t3=t2;
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[51]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[52]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
/* files.scm: 274  chop-pds */
f_1633(t1,t2,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* make-absolute-pathname in k1616 in k840 in k837 in k834 */
static void C_ccall f_1917(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_1917r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1917r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1917r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(17);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1919,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=((C_word)li70),tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1941,a[2]=t5,a[3]=((C_word)li71),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1946,a[2]=t6,a[3]=((C_word)li72),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-ext478495 */
t8=t7;
f_1946(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-pds479493 */
t10=t6;
f_1941(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body476484 */
t12=t5;
f_1919(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-ext478 in make-absolute-pathname in k1616 in k840 in k837 in k834 */
static void C_fcall f_1946(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1946,NULL,2,t0,t1);}
/* def-pds479493 */
t2=((C_word*)t0)[2];
f_1941(t2,t1,C_SCHEME_FALSE);}

/* def-pds479 in make-absolute-pathname in k1616 in k840 in k837 in k834 */
static void C_fcall f_1941(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1941,NULL,3,t0,t1,t2);}
/* body476484 */
t3=((C_word*)t0)[2];
f_1919(t3,t1,t2,C_SCHEME_FALSE);}

/* body476 in make-absolute-pathname in k1616 in k840 in k837 in k834 */
static void C_fcall f_1919(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1919,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1927,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* files.scm: 257  canonicalize-dirs */
t5=((C_word*)t0)[3];
f_1741(t5,t4,((C_word*)t0)[2],t3);}

/* k1925 in body476 in make-absolute-pathname in k1616 in k840 in k837 in k834 */
static void C_ccall f_1927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1930,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1933,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* files.scm: 258  absolute-pathname? */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}

/* k1931 in k1925 in body476 in make-absolute-pathname in k1616 in k840 in k837 in k834 */
static void C_ccall f_1933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_1930(2,t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
t3=(C_truep(t2)?t2:((C_word*)t0)[2]);
/* files.scm: 260  ##sys#string-append */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[5],t3,((C_word*)t0)[4]);}}

/* k1928 in k1925 in body476 in make-absolute-pathname in k1616 in k840 in k837 in k834 */
static void C_ccall f_1930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 255  _make-pathname */
t2=((C_word*)t0)[6];
f_1772(t2,((C_word*)t0)[5],lf[41],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* make-pathname in k1616 in k840 in k837 in k834 */
static void C_ccall f_1853(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr4r,(void*)f_1853r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1853r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1853r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(15);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1855,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word)li66),tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1864,a[2]=t5,a[3]=((C_word)li67),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1869,a[2]=t6,a[3]=((C_word)li68),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-ext446457 */
t8=t7;
f_1869(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-pds447455 */
t10=t6;
f_1864(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body444452 */
t12=t5;
f_1855(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-ext446 in make-pathname in k1616 in k840 in k837 in k834 */
static void C_fcall f_1869(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1869,NULL,2,t0,t1);}
/* def-pds447455 */
t2=((C_word*)t0)[2];
f_1864(t2,t1,C_SCHEME_FALSE);}

/* def-pds447 in make-pathname in k1616 in k840 in k837 in k834 */
static void C_fcall f_1864(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1864,NULL,3,t0,t1,t2);}
/* body444452 */
t3=((C_word*)t0)[2];
f_1855(t3,t1,t2,C_SCHEME_FALSE);}

/* body444 in make-pathname in k1616 in k840 in k837 in k834 */
static void C_fcall f_1855(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1855,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1863,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* files.scm: 251  canonicalize-dirs */
t5=((C_word*)t0)[3];
f_1741(t5,t4,((C_word*)t0)[2],t3);}

/* k1861 in body444 in make-pathname in k1616 in k840 in k837 in k834 */
static void C_ccall f_1863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 251  _make-pathname */
t2=((C_word*)t0)[6];
f_1772(t2,((C_word*)t0)[5],lf[40],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* _make-pathname in k1616 in k840 in k837 in k834 */
static void C_fcall f_1772(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1772,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_truep(t5)?t5:lf[45]);
t8=(C_truep(t4)?t4:lf[46]);
t9=(C_truep(t6)?(C_word)C_block_size(t6):C_fix(1));
t10=(C_word)C_i_check_string_2(t3,t2);
t11=(C_word)C_i_check_string_2(t8,t2);
t12=(C_word)C_i_check_string_2(t7,t2);
t13=(C_truep(t6)?(C_word)C_i_check_string_2(t6,t2):C_SCHEME_UNDEFINED);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1801,a[2]=t7,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1825,a[2]=t9,a[3]=t14,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t16=(C_word)C_block_size(t8);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t16,t9))){
if(C_truep(t6)){
t17=t15;
f_1825(t17,(C_word)C_substring_compare(t6,t8,C_fix(0),C_fix(0),t9));}
else{
t17=(C_word)C_subchar(t8,C_fix(0));
t18=t15;
f_1825(t18,(C_word)C_i_memq(t17,lf[49]));}}
else{
t17=t15;
f_1825(t17,C_SCHEME_FALSE);}}

/* k1823 in _make-pathname in k1616 in k840 in k837 in k834 */
static void C_fcall f_1825(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[4]);
/* files.scm: 241  ##sys#substring */
t3=*((C_word*)lf[38]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[3];
f_1801(2,t2,((C_word*)t0)[4]);}}

/* k1799 in _make-pathname in k1616 in k840 in k837 in k834 */
static void C_ccall f_1801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1808,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t4=(C_word)C_eqp((C_word)C_subchar(((C_word*)t0)[2],C_fix(0)),C_make_character(46));
t5=t2;
f_1808(t5,(C_word)C_i_not(t4));}
else{
t4=t2;
f_1808(t4,C_SCHEME_FALSE);}}

/* k1806 in k1799 in _make-pathname in k1616 in k840 in k837 in k834 */
static void C_fcall f_1808(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?lf[47]:lf[48]);
/* files.scm: 235  string-append */
t3=((C_word*)t0)[6];
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* canonicalize-dirs in k1616 in k840 in k837 in k834 */
static void C_fcall f_1741(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1741,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_not(t2);
t5=(C_truep(t4)?t4:(C_word)C_i_nullp(t2));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[44]);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t6=(C_word)C_a_i_list(&a,1,t2);
/* files.scm: 224  conc-dirs */
t7=((C_word*)t0)[2];
f_1680(t7,t1,t6,t3);}
else{
/* files.scm: 225  conc-dirs */
t6=((C_word*)t0)[2];
f_1680(t6,t1,t2,t3);}}}

/* conc-dirs in k1616 in k840 in k837 in k834 */
static void C_fcall f_1680(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1680,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_list_2(t2,lf[40]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1689,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t6,a[6]=((C_word)li62),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_1689(t8,t1,t2);}

/* loop in conc-dirs in k1616 in k840 in k837 in k834 */
static void C_fcall f_1689(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1689,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[43]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_string_length(t3);
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
/* files.scm: 216  loop */
t10=t1;
t11=t6;
t1=t10;
t2=t11;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1719,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_i_car(t2);
/* files.scm: 218  chop-pds */
f_1633(t6,t7,((C_word*)t0)[4]);}}}

/* k1717 in loop in conc-dirs in k1616 in k840 in k837 in k834 */
static void C_ccall f_1719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1719,2,t0,t1);}
t2=((C_word*)t0)[7];
t3=(C_truep(t2)?t2:((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1727,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* files.scm: 220  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_1689(t6,t4,t5);}

/* k1725 in k1717 in loop in conc-dirs in k1616 in k840 in k837 in k834 */
static void C_ccall f_1727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 217  string-append */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* chop-pds in k1616 in k840 in k837 in k834 */
static void C_fcall f_1633(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1633,NULL,3,t1,t2,t3);}
if(C_truep(t2)){
t4=(C_word)C_block_size(t2);
t5=(C_truep(t3)?(C_word)C_block_size(t3):C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1649,a[2]=t2,a[3]=t1,a[4]=t5,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,C_fix(1)))){
if(C_truep(t3)){
t7=(C_word)C_fixnum_difference(t4,t5);
t8=t6;
f_1649(t8,(C_word)C_substring_compare(t2,t3,t7,C_fix(0),t5));}
else{
t7=(C_word)C_fixnum_difference(t4,t5);
t8=(C_word)C_subchar(t2,t7);
t9=t6;
f_1649(t9,(C_word)C_i_memq(t8,lf[39]));}}
else{
t7=t6;
f_1649(t7,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k1647 in chop-pds in k1616 in k840 in k837 in k834 */
static void C_fcall f_1649(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
/* files.scm: 200  ##sys#substring */
t3=*((C_word*)lf[38]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* absolute-pathname? in k1616 in k840 in k837 in k834 */
static void C_ccall f_1620(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1620,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[36]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1631,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* files.scm: 188  absolute-pathname-root */
((C_proc3)C_retrieve_proc(lf[32]))(3,lf[32],t4,t2);}

/* k1629 in absolute-pathname? in k1616 in k840 in k837 in k834 */
static void C_ccall f_1631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_pairp(t1));}

/* file-move in k840 in k837 in k834 */
static void C_ccall f_1206(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_1206r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1206r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1206r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1208,a[2]=t3,a[3]=t2,a[4]=((C_word)li56),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1561,a[2]=t5,a[3]=((C_word)li57),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1566,a[2]=t6,a[3]=((C_word)li58),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-clobber190332 */
t8=t7;
f_1566(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-blocksize191330 */
t10=t6;
f_1561(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body188196 */
t12=t5;
f_1208(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-clobber190 in file-move in k840 in k837 in k834 */
static void C_fcall f_1566(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1566,NULL,2,t0,t1);}
/* def-blocksize191330 */
t2=((C_word*)t0)[2];
f_1561(t2,t1,C_SCHEME_FALSE);}

/* def-blocksize191 in file-move in k840 in k837 in k834 */
static void C_fcall f_1561(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1561,NULL,3,t0,t1,t2);}
/* body188196 */
t3=((C_word*)t0)[2];
f_1208(t3,t1,t2,C_fix(1024));}

/* body188 in file-move in k840 in k837 in k834 */
static void C_fcall f_1208(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1208,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[24]);
t5=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[24]);
t6=(C_word)C_i_check_number_2(t3,lf[24]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1221,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_integerp(t3))){
t8=t3;
t9=t7;
f_1221(t9,(C_word)C_fixnum_greaterp(t8,C_fix(0)));}
else{
t8=t7;
f_1221(t8,C_SCHEME_FALSE);}}

/* k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_fcall f_1221(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1221,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1224,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_1224(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1550,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1554,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* files.scm: 124  number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[5]);}}

/* k1552 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 122  string-append */
t2=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[31],t1);}

/* k1548 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 122  ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1224,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1227,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* files.scm: 125  file-exists? */
t3=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1227,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1230,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_1230(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1543,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* files.scm: 126  string-append */
t4=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[30],((C_word*)t0)[6]);}}

/* k1541 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 126  ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1230,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1233,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1526,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* files.scm: 127  file-exists? */
t4=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* k1524 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1526,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_1233(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1536,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* files.scm: 129  string-append */
t4=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[29],((C_word*)t0)[2]);}}
else{
t2=((C_word*)t0)[3];
f_1233(2,t2,C_SCHEME_FALSE);}}

/* k1534 in k1524 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 129  ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1233,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1236,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1468,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1470,a[2]=((C_word*)t0)[5],a[3]=((C_word)li55),tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
t5=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1469 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1470(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1470,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1476,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li50),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1501,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li54),tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_proc(*((C_word*)lf[14]+1)))(4,*((C_word*)lf[14]+1),t1,t3,t4);}

/* a1500 in a1469 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1501,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1507,a[2]=((C_word*)t0)[3],a[3]=((C_word)li51),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1513,a[2]=((C_word*)t0)[2],a[3]=((C_word)li53),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1512 in a1500 in a1469 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1513(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1513r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1513r(t0,t1,t2);}}

static void C_ccall f_1513r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1519,a[2]=t2,a[3]=((C_word)li52),tmp=(C_word)a,a+=4,tmp);
/* k227230 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1518 in a1512 in a1500 in a1469 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1519,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1506 in a1500 in a1469 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1507,2,t0,t1);}
/* files.scm: 132  open-input-file */
t2=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a1475 in a1469 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1476(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1476,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1482,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li49),tmp=(C_word)a,a+=5,tmp);
/* k227230 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1481 in a1475 in a1469 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1482,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[3],lf[9]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1493,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* files.scm: 134  string-append */
t5=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[28],((C_word*)t0)[2]);}

/* k1491 in a1481 in a1475 in a1469 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 134  ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1466 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1236,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1239,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1410,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1412,a[2]=((C_word*)t0)[2],a[3]=((C_word)li48),tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
t5=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1411 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1412(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1412,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1418,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li43),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1443,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li47),tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_proc(*((C_word*)lf[14]+1)))(4,*((C_word*)lf[14]+1),t1,t3,t4);}

/* a1442 in a1411 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1449,a[2]=((C_word*)t0)[3],a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1455,a[2]=((C_word*)t0)[2],a[3]=((C_word)li46),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1454 in a1442 in a1411 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1455(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1455r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1455r(t0,t1,t2);}}

static void C_ccall f_1455r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1461,a[2]=t2,a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp);
/* k251254 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1460 in a1454 in a1442 in a1411 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1461,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1448 in a1442 in a1411 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1449,2,t0,t1);}
/* files.scm: 137  open-output-file */
t2=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a1417 in a1411 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1418(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1418,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1424,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li42),tmp=(C_word)a,a+=5,tmp);
/* k251254 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1423 in a1417 in a1411 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1424,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[3],lf[9]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1435,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* files.scm: 139  string-append */
t5=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[27],((C_word*)t0)[2]);}

/* k1433 in a1423 in a1417 in a1411 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 139  ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1408 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1237 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1239,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1242,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* files.scm: 142  make-string */
t3=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k1240 in k1237 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1242,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1249,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* files.scm: 143  read-string! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[8]+1)))(5,*((C_word*)lf[8]+1),t2,((C_word*)t0)[3],t1,((C_word*)t0)[4]);}

/* k1247 in k1240 in k1237 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1249,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1251,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li41),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_1251(t5,((C_word*)t0)[2],t1,C_fix(0));}

/* loop in k1247 in k1240 in k1237 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_fcall f_1251(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1251,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(C_fix(0),t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1261,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* files.scm: 147  close-input-port */
t7=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[5]);}
else{
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1328,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1342,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1344,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word)li40),tmp=(C_word)a,a+=8,tmp);
/* call-with-current-continuation */
t9=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}}

/* a1343 in loop in k1247 in k1240 in k1237 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1344(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1344,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1350,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word)li35),tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1385,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word)li39),tmp=(C_word)a,a+=7,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_proc(*((C_word*)lf[14]+1)))(4,*((C_word*)lf[14]+1),t1,t3,t4);}

/* a1384 in a1343 in loop in k1247 in k1240 in k1237 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1391,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li36),tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1397,a[2]=((C_word*)t0)[2],a[3]=((C_word)li38),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1396 in a1384 in a1343 in loop in k1247 in k1240 in k1237 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1397(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1397r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1397r(t0,t1,t2);}}

static void C_ccall f_1397r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1403,a[2]=t2,a[3]=((C_word)li37),tmp=(C_word)a,a+=4,tmp);
/* k304307 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1402 in a1396 in a1384 in a1343 in loop in k1247 in k1240 in k1237 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1403,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1390 in a1384 in a1343 in loop in k1247 in k1240 in k1237 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1391,2,t0,t1);}
/* files.scm: 156  write-string */
((C_proc5)C_retrieve_proc(*((C_word*)lf[13]+1)))(5,*((C_word*)lf[13]+1),t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1349 in a1343 in loop in k1247 in k1240 in k1237 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1350(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1350,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1356,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word)li34),tmp=(C_word)a,a+=7,tmp);
/* k304307 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1355 in a1349 in a1343 in loop in k1247 in k1240 in k1237 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1356,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[5],lf[9]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[5],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1363,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* files.scm: 158  close-input-port */
t5=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k1361 in a1355 in a1349 in a1343 in loop in k1247 in k1240 in k1237 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1366,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* files.scm: 159  close-output-port */
t3=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1364 in k1361 in a1355 in a1349 in a1343 in loop in k1247 in k1240 in k1237 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1373,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1377,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* files.scm: 162  number->string */
C_number_to_string(3,0,t3,((C_word*)t0)[2]);}

/* k1375 in k1364 in k1361 in a1355 in a1349 in a1343 in loop in k1247 in k1240 in k1237 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 160  string-append */
t2=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[26],t1);}

/* k1371 in k1364 in k1361 in a1355 in a1349 in a1343 in loop in k1247 in k1240 in k1237 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 160  ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1340 in loop in k1247 in k1240 in k1237 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1326 in loop in k1247 in k1240 in k1237 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1328,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1335,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* files.scm: 163  read-string! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[8]+1)))(5,*((C_word*)lf[8]+1),t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1333 in k1326 in loop in k1247 in k1240 in k1237 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
/* files.scm: 163  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1251(t3,((C_word*)t0)[2],t1,t2);}

/* k1259 in loop in k1247 in k1240 in k1237 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1264,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* files.scm: 148  close-output-port */
t3=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1262 in k1259 in loop in k1247 in k1240 in k1237 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1264,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1267,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1270,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1272,a[2]=((C_word*)t0)[2],a[3]=((C_word)li33),tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
t5=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1271 in k1262 in k1259 in loop in k1247 in k1240 in k1237 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1272(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1272,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1278,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li28),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1303,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li32),tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_proc(*((C_word*)lf[14]+1)))(4,*((C_word*)lf[14]+1),t1,t3,t4);}

/* a1302 in a1271 in k1262 in k1259 in loop in k1247 in k1240 in k1237 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1309,a[2]=((C_word*)t0)[3],a[3]=((C_word)li29),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1315,a[2]=((C_word*)t0)[2],a[3]=((C_word)li31),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1314 in a1302 in a1271 in k1262 in k1259 in loop in k1247 in k1240 in k1237 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1315(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1315r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1315r(t0,t1,t2);}}

static void C_ccall f_1315r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1321,a[2]=t2,a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp);
/* k278281 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1320 in a1314 in a1302 in a1271 in k1262 in k1259 in loop in k1247 in k1240 in k1237 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1321,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1308 in a1302 in a1271 in k1262 in k1259 in loop in k1247 in k1240 in k1237 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1309,2,t0,t1);}
/* files.scm: 149  delete-file */
t2=*((C_word*)lf[3]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a1277 in a1271 in k1262 in k1259 in loop in k1247 in k1240 in k1237 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1278(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1278,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1284,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li27),tmp=(C_word)a,a+=5,tmp);
/* k278281 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1283 in a1277 in a1271 in k1262 in k1259 in loop in k1247 in k1240 in k1237 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1284,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[3],lf[9]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1295,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* files.scm: 151  string-append */
t5=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[25],((C_word*)t0)[2]);}

/* k1293 in a1283 in a1277 in a1271 in k1262 in k1259 in loop in k1247 in k1240 in k1237 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 151  ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1268 in k1262 in k1259 in loop in k1247 in k1240 in k1237 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1265 in k1262 in k1259 in loop in k1247 in k1240 in k1237 in k1234 in k1231 in k1228 in k1225 in k1222 in k1219 in body188 in file-move in k840 in k837 in k834 */
static void C_ccall f_1267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-copy in k840 in k837 in k834 */
static void C_ccall f_859(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_859r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_859r(t0,t1,t2,t3,t4);}}

static void C_ccall f_859r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_861,a[2]=t3,a[3]=t2,a[4]=((C_word)li23),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1153,a[2]=t5,a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1158,a[2]=t6,a[3]=((C_word)li25),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-clobber49167 */
t8=t7;
f_1158(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-blocksize50165 */
t10=t6;
f_1153(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body4755 */
t12=t5;
f_861(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-clobber49 in file-copy in k840 in k837 in k834 */
static void C_fcall f_1158(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1158,NULL,2,t0,t1);}
/* def-blocksize50165 */
t2=((C_word*)t0)[2];
f_1153(t2,t1,C_SCHEME_FALSE);}

/* def-blocksize50 in file-copy in k840 in k837 in k834 */
static void C_fcall f_1153(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1153,NULL,3,t0,t1,t2);}
/* body4755 */
t3=((C_word*)t0)[2];
f_861(t3,t1,t2,C_fix(1024));}

/* body47 in file-copy in k840 in k837 in k834 */
static void C_fcall f_861(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_861,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[5]);
t5=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[5]);
t6=(C_word)C_i_check_number_2(t3,lf[5]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_874,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_integerp(t3))){
t8=t3;
t9=t7;
f_874(t9,(C_word)C_fixnum_greaterp(t8,C_fix(0)));}
else{
t8=t7;
f_874(t8,C_SCHEME_FALSE);}}

/* k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_fcall f_874(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_874,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_877,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_877(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1142,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1146,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* files.scm: 81   number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[6]);}}

/* k1144 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_1146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 79   string-append */
t2=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[23],t1);}

/* k1140 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_1142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 79   ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_880,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* files.scm: 82   file-exists? */
t3=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_883,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_883(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1135,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* files.scm: 83   string-append */
t4=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[22],((C_word*)t0)[3]);}}

/* k1133 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_1135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 83   ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_886,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1118,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* files.scm: 84   file-exists? */
t4=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k1116 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_1118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1118,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_886(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1128,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* files.scm: 86   string-append */
t4=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[21],((C_word*)t0)[2]);}}
else{
t2=((C_word*)t0)[3];
f_886(2,t2,C_SCHEME_FALSE);}}

/* k1126 in k1116 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_1128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 86   ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_889,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1060,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1062,a[2]=((C_word*)t0)[2],a[3]=((C_word)li22),tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
t5=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1061 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_1062(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1062,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1068,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li17),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1093,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li21),tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_proc(*((C_word*)lf[14]+1)))(4,*((C_word*)lf[14]+1),t1,t3,t4);}

/* a1092 in a1061 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_1093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1093,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1099,a[2]=((C_word*)t0)[3],a[3]=((C_word)li18),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1105,a[2]=((C_word*)t0)[2],a[3]=((C_word)li20),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1104 in a1092 in a1061 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_1105(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1105r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1105r(t0,t1,t2);}}

static void C_ccall f_1105r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1111,a[2]=t2,a[3]=((C_word)li19),tmp=(C_word)a,a+=4,tmp);
/* k8689 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1110 in a1104 in a1092 in a1061 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_1111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1111,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1098 in a1092 in a1061 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_1099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1099,2,t0,t1);}
/* files.scm: 89   open-input-file */
t2=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a1067 in a1061 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_1068(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1068,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1074,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li16),tmp=(C_word)a,a+=5,tmp);
/* k8689 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1073 in a1067 in a1061 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_1074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1074,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[3],lf[9]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1085,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* files.scm: 91   string-append */
t5=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[19],((C_word*)t0)[2]);}

/* k1083 in a1073 in a1067 in a1061 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_1085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 91   ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1058 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_1060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k887 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_889,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_892,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1002,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1004,a[2]=((C_word*)t0)[2],a[3]=((C_word)li15),tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
t5=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1003 in k887 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_1004(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1004,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1010,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li10),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1035,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_proc(*((C_word*)lf[14]+1)))(4,*((C_word*)lf[14]+1),t1,t3,t4);}

/* a1034 in a1003 in k887 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_1035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1035,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1041,a[2]=((C_word*)t0)[3],a[3]=((C_word)li11),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1047,a[2]=((C_word*)t0)[2],a[3]=((C_word)li13),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1046 in a1034 in a1003 in k887 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_1047(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1047r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1047r(t0,t1,t2);}}

static void C_ccall f_1047r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1053,a[2]=t2,a[3]=((C_word)li12),tmp=(C_word)a,a+=4,tmp);
/* k110113 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1052 in a1046 in a1034 in a1003 in k887 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_1053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1053,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1040 in a1034 in a1003 in k887 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_1041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1041,2,t0,t1);}
/* files.scm: 94   open-output-file */
t2=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a1009 in a1003 in k887 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_1010(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1010,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1016,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li9),tmp=(C_word)a,a+=5,tmp);
/* k110113 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1015 in a1009 in a1003 in k887 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_1016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1016,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[3],lf[9]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1027,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* files.scm: 96   string-append */
t5=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[17],((C_word*)t0)[2]);}

/* k1025 in a1015 in a1009 in a1003 in k887 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_1027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 96   ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1000 in k887 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_1002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k890 in k887 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_892,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_895,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* files.scm: 99   make-string */
t3=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k893 in k890 in k887 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_902,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* files.scm: 100  read-string! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[8]+1)))(5,*((C_word*)lf[8]+1),t2,((C_word*)t0)[3],t1,((C_word*)t0)[4]);}

/* k900 in k893 in k890 in k887 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_902,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_904,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li8),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_904(t5,((C_word*)t0)[2],t1,C_fix(0));}

/* loop in k900 in k893 in k890 in k887 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_fcall f_904(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_904,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(C_fix(0),t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_914,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* files.scm: 104  close-input-port */
t7=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[5]);}
else{
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_920,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_934,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_936,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word)li7),tmp=(C_word)a,a+=8,tmp);
/* call-with-current-continuation */
t9=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}}

/* a935 in loop in k900 in k893 in k890 in k887 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_936(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_936,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_942,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word)li2),tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_977,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word)li6),tmp=(C_word)a,a+=7,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_proc(*((C_word*)lf[14]+1)))(4,*((C_word*)lf[14]+1),t1,t3,t4);}

/* a976 in a935 in loop in k900 in k893 in k890 in k887 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_983,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li3),tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_989,a[2]=((C_word*)t0)[2],a[3]=((C_word)li5),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a988 in a976 in a935 in loop in k900 in k893 in k890 in k887 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_989(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_989r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_989r(t0,t1,t2);}}

static void C_ccall f_989r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_995,a[2]=t2,a[3]=((C_word)li4),tmp=(C_word)a,a+=4,tmp);
/* k139142 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a994 in a988 in a976 in a935 in loop in k900 in k893 in k890 in k887 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_995,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a982 in a976 in a935 in loop in k900 in k893 in k890 in k887 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_983,2,t0,t1);}
/* files.scm: 108  write-string */
((C_proc5)C_retrieve_proc(*((C_word*)lf[13]+1)))(5,*((C_word*)lf[13]+1),t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a941 in a935 in loop in k900 in k893 in k890 in k887 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_942(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_942,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_948,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word)li1),tmp=(C_word)a,a+=7,tmp);
/* k139142 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a947 in a941 in a935 in loop in k900 in k893 in k890 in k887 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_948,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[5],lf[9]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[5],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_955,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* files.scm: 110  close-input-port */
t5=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k953 in a947 in a941 in a935 in loop in k900 in k893 in k890 in k887 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_955,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_958,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* files.scm: 111  close-output-port */
t3=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k956 in k953 in a947 in a941 in a935 in loop in k900 in k893 in k890 in k887 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_958,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_965,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_969,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* files.scm: 114  number->string */
C_number_to_string(3,0,t3,((C_word*)t0)[2]);}

/* k967 in k956 in k953 in a947 in a941 in a935 in loop in k900 in k893 in k890 in k887 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 112  string-append */
t2=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[12],t1);}

/* k963 in k956 in k953 in a947 in a941 in a935 in loop in k900 in k893 in k890 in k887 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 112  ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k932 in loop in k900 in k893 in k890 in k887 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k918 in loop in k900 in k893 in k890 in k887 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_920,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_927,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* files.scm: 115  read-string! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[8]+1)))(5,*((C_word*)lf[8]+1),t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k925 in k918 in loop in k900 in k893 in k890 in k887 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
/* files.scm: 115  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_904(t3,((C_word*)t0)[2],t1,t2);}

/* k912 in loop in k900 in k893 in k890 in k887 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_914,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_917,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* files.scm: 105  close-output-port */
t3=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k915 in k912 in loop in k900 in k893 in k890 in k887 in k884 in k881 in k878 in k875 in k872 in body47 in file-copy in k840 in k837 in k834 */
static void C_ccall f_917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* delete-file* in k840 in k837 in k834 */
static void C_ccall f_844(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_844,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_851,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* files.scm: 71   file-exists? */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k849 in delete-file* in k840 in k837 in k834 */
static void C_ccall f_851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_851,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_857,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* files.scm: 71   delete-file */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k855 in k849 in delete-file* in k840 in k837 in k834 */
static void C_ccall f_857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[238] = {
{"toplevel:files_scm",(void*)C_files_toplevel},
{"f_836:files_scm",(void*)f_836},
{"f_839:files_scm",(void*)f_839},
{"f_842:files_scm",(void*)f_842},
{"f_2774:files_scm",(void*)f_2774},
{"f_2785:files_scm",(void*)f_2785},
{"f_2782:files_scm",(void*)f_2782},
{"f_2776:files_scm",(void*)f_2776},
{"f_2747:files_scm",(void*)f_2747},
{"f_2764:files_scm",(void*)f_2764},
{"f_2755:files_scm",(void*)f_2755},
{"f_2749:files_scm",(void*)f_2749},
{"f_1618:files_scm",(void*)f_1618},
{"f_1996:files_scm",(void*)f_1996},
{"f_1999:files_scm",(void*)f_1999},
{"f_2744:files_scm",(void*)f_2744},
{"f_2661:files_scm",(void*)f_2661},
{"f_2709:files_scm",(void*)f_2709},
{"f_2712:files_scm",(void*)f_2712},
{"f_2715:files_scm",(void*)f_2715},
{"f_2722:files_scm",(void*)f_2722},
{"f_2702:files_scm",(void*)f_2702},
{"f_2726:files_scm",(void*)f_2726},
{"f_2619:files_scm",(void*)f_2619},
{"f_2627:files_scm",(void*)f_2627},
{"f_2629:files_scm",(void*)f_2629},
{"f_2610:files_scm",(void*)f_2610},
{"f_2334:files_scm",(void*)f_2334},
{"f_2338:files_scm",(void*)f_2338},
{"f_2352:files_scm",(void*)f_2352},
{"f_2544:files_scm",(void*)f_2544},
{"f_2548:files_scm",(void*)f_2548},
{"f_2492:files_scm",(void*)f_2492},
{"f_2528:files_scm",(void*)f_2528},
{"f_2480:files_scm",(void*)f_2480},
{"f_2362:files_scm",(void*)f_2362},
{"f_2388:files_scm",(void*)f_2388},
{"f_2391:files_scm",(void*)f_2391},
{"f_2394:files_scm",(void*)f_2394},
{"f_2442:files_scm",(void*)f_2442},
{"f_2455:files_scm",(void*)f_2455},
{"f_2458:files_scm",(void*)f_2458},
{"f_2397:files_scm",(void*)f_2397},
{"f_2400:files_scm",(void*)f_2400},
{"f_2403:files_scm",(void*)f_2403},
{"f_2406:files_scm",(void*)f_2406},
{"f_2426:files_scm",(void*)f_2426},
{"f_2415:files_scm",(void*)f_2415},
{"f_2422:files_scm",(void*)f_2422},
{"f_2409:files_scm",(void*)f_2409},
{"f_2308:files_scm",(void*)f_2308},
{"f_2233:files_scm",(void*)f_2233},
{"f_2237:files_scm",(void*)f_2237},
{"f_2290:files_scm",(void*)f_2290},
{"f_2296:files_scm",(void*)f_2296},
{"f_2240:files_scm",(void*)f_2240},
{"f_2251:files_scm",(void*)f_2251},
{"f_2281:files_scm",(void*)f_2281},
{"f_2277:files_scm",(void*)f_2277},
{"f_2258:files_scm",(void*)f_2258},
{"f_2264:files_scm",(void*)f_2264},
{"f_2272:files_scm",(void*)f_2272},
{"f_2215:files_scm",(void*)f_2215},
{"f_2227:files_scm",(void*)f_2227},
{"f_2221:files_scm",(void*)f_2221},
{"f_2197:files_scm",(void*)f_2197},
{"f_2209:files_scm",(void*)f_2209},
{"f_2203:files_scm",(void*)f_2203},
{"f_2179:files_scm",(void*)f_2179},
{"f_2191:files_scm",(void*)f_2191},
{"f_2185:files_scm",(void*)f_2185},
{"f_2161:files_scm",(void*)f_2161},
{"f_2173:files_scm",(void*)f_2173},
{"f_2167:files_scm",(void*)f_2167},
{"f_2143:files_scm",(void*)f_2143},
{"f_2155:files_scm",(void*)f_2155},
{"f_2149:files_scm",(void*)f_2149},
{"f_2128:files_scm",(void*)f_2128},
{"f_2140:files_scm",(void*)f_2140},
{"f_2134:files_scm",(void*)f_2134},
{"f_2113:files_scm",(void*)f_2113},
{"f_2125:files_scm",(void*)f_2125},
{"f_2119:files_scm",(void*)f_2119},
{"f_2098:files_scm",(void*)f_2098},
{"f_2110:files_scm",(void*)f_2110},
{"f_2104:files_scm",(void*)f_2104},
{"f_2014:files_scm",(void*)f_2014},
{"f_2030:files_scm",(void*)f_2030},
{"f_2059:files_scm",(void*)f_2059},
{"f_2084:files_scm",(void*)f_2084},
{"f_2069:files_scm",(void*)f_2069},
{"f_2040:files_scm",(void*)f_2040},
{"f_2000:files_scm",(void*)f_2000},
{"f_1917:files_scm",(void*)f_1917},
{"f_1946:files_scm",(void*)f_1946},
{"f_1941:files_scm",(void*)f_1941},
{"f_1919:files_scm",(void*)f_1919},
{"f_1927:files_scm",(void*)f_1927},
{"f_1933:files_scm",(void*)f_1933},
{"f_1930:files_scm",(void*)f_1930},
{"f_1853:files_scm",(void*)f_1853},
{"f_1869:files_scm",(void*)f_1869},
{"f_1864:files_scm",(void*)f_1864},
{"f_1855:files_scm",(void*)f_1855},
{"f_1863:files_scm",(void*)f_1863},
{"f_1772:files_scm",(void*)f_1772},
{"f_1825:files_scm",(void*)f_1825},
{"f_1801:files_scm",(void*)f_1801},
{"f_1808:files_scm",(void*)f_1808},
{"f_1741:files_scm",(void*)f_1741},
{"f_1680:files_scm",(void*)f_1680},
{"f_1689:files_scm",(void*)f_1689},
{"f_1719:files_scm",(void*)f_1719},
{"f_1727:files_scm",(void*)f_1727},
{"f_1633:files_scm",(void*)f_1633},
{"f_1649:files_scm",(void*)f_1649},
{"f_1620:files_scm",(void*)f_1620},
{"f_1631:files_scm",(void*)f_1631},
{"f_1206:files_scm",(void*)f_1206},
{"f_1566:files_scm",(void*)f_1566},
{"f_1561:files_scm",(void*)f_1561},
{"f_1208:files_scm",(void*)f_1208},
{"f_1221:files_scm",(void*)f_1221},
{"f_1554:files_scm",(void*)f_1554},
{"f_1550:files_scm",(void*)f_1550},
{"f_1224:files_scm",(void*)f_1224},
{"f_1227:files_scm",(void*)f_1227},
{"f_1543:files_scm",(void*)f_1543},
{"f_1230:files_scm",(void*)f_1230},
{"f_1526:files_scm",(void*)f_1526},
{"f_1536:files_scm",(void*)f_1536},
{"f_1233:files_scm",(void*)f_1233},
{"f_1470:files_scm",(void*)f_1470},
{"f_1501:files_scm",(void*)f_1501},
{"f_1513:files_scm",(void*)f_1513},
{"f_1519:files_scm",(void*)f_1519},
{"f_1507:files_scm",(void*)f_1507},
{"f_1476:files_scm",(void*)f_1476},
{"f_1482:files_scm",(void*)f_1482},
{"f_1493:files_scm",(void*)f_1493},
{"f_1468:files_scm",(void*)f_1468},
{"f_1236:files_scm",(void*)f_1236},
{"f_1412:files_scm",(void*)f_1412},
{"f_1443:files_scm",(void*)f_1443},
{"f_1455:files_scm",(void*)f_1455},
{"f_1461:files_scm",(void*)f_1461},
{"f_1449:files_scm",(void*)f_1449},
{"f_1418:files_scm",(void*)f_1418},
{"f_1424:files_scm",(void*)f_1424},
{"f_1435:files_scm",(void*)f_1435},
{"f_1410:files_scm",(void*)f_1410},
{"f_1239:files_scm",(void*)f_1239},
{"f_1242:files_scm",(void*)f_1242},
{"f_1249:files_scm",(void*)f_1249},
{"f_1251:files_scm",(void*)f_1251},
{"f_1344:files_scm",(void*)f_1344},
{"f_1385:files_scm",(void*)f_1385},
{"f_1397:files_scm",(void*)f_1397},
{"f_1403:files_scm",(void*)f_1403},
{"f_1391:files_scm",(void*)f_1391},
{"f_1350:files_scm",(void*)f_1350},
{"f_1356:files_scm",(void*)f_1356},
{"f_1363:files_scm",(void*)f_1363},
{"f_1366:files_scm",(void*)f_1366},
{"f_1377:files_scm",(void*)f_1377},
{"f_1373:files_scm",(void*)f_1373},
{"f_1342:files_scm",(void*)f_1342},
{"f_1328:files_scm",(void*)f_1328},
{"f_1335:files_scm",(void*)f_1335},
{"f_1261:files_scm",(void*)f_1261},
{"f_1264:files_scm",(void*)f_1264},
{"f_1272:files_scm",(void*)f_1272},
{"f_1303:files_scm",(void*)f_1303},
{"f_1315:files_scm",(void*)f_1315},
{"f_1321:files_scm",(void*)f_1321},
{"f_1309:files_scm",(void*)f_1309},
{"f_1278:files_scm",(void*)f_1278},
{"f_1284:files_scm",(void*)f_1284},
{"f_1295:files_scm",(void*)f_1295},
{"f_1270:files_scm",(void*)f_1270},
{"f_1267:files_scm",(void*)f_1267},
{"f_859:files_scm",(void*)f_859},
{"f_1158:files_scm",(void*)f_1158},
{"f_1153:files_scm",(void*)f_1153},
{"f_861:files_scm",(void*)f_861},
{"f_874:files_scm",(void*)f_874},
{"f_1146:files_scm",(void*)f_1146},
{"f_1142:files_scm",(void*)f_1142},
{"f_877:files_scm",(void*)f_877},
{"f_880:files_scm",(void*)f_880},
{"f_1135:files_scm",(void*)f_1135},
{"f_883:files_scm",(void*)f_883},
{"f_1118:files_scm",(void*)f_1118},
{"f_1128:files_scm",(void*)f_1128},
{"f_886:files_scm",(void*)f_886},
{"f_1062:files_scm",(void*)f_1062},
{"f_1093:files_scm",(void*)f_1093},
{"f_1105:files_scm",(void*)f_1105},
{"f_1111:files_scm",(void*)f_1111},
{"f_1099:files_scm",(void*)f_1099},
{"f_1068:files_scm",(void*)f_1068},
{"f_1074:files_scm",(void*)f_1074},
{"f_1085:files_scm",(void*)f_1085},
{"f_1060:files_scm",(void*)f_1060},
{"f_889:files_scm",(void*)f_889},
{"f_1004:files_scm",(void*)f_1004},
{"f_1035:files_scm",(void*)f_1035},
{"f_1047:files_scm",(void*)f_1047},
{"f_1053:files_scm",(void*)f_1053},
{"f_1041:files_scm",(void*)f_1041},
{"f_1010:files_scm",(void*)f_1010},
{"f_1016:files_scm",(void*)f_1016},
{"f_1027:files_scm",(void*)f_1027},
{"f_1002:files_scm",(void*)f_1002},
{"f_892:files_scm",(void*)f_892},
{"f_895:files_scm",(void*)f_895},
{"f_902:files_scm",(void*)f_902},
{"f_904:files_scm",(void*)f_904},
{"f_936:files_scm",(void*)f_936},
{"f_977:files_scm",(void*)f_977},
{"f_989:files_scm",(void*)f_989},
{"f_995:files_scm",(void*)f_995},
{"f_983:files_scm",(void*)f_983},
{"f_942:files_scm",(void*)f_942},
{"f_948:files_scm",(void*)f_948},
{"f_955:files_scm",(void*)f_955},
{"f_958:files_scm",(void*)f_958},
{"f_969:files_scm",(void*)f_969},
{"f_965:files_scm",(void*)f_965},
{"f_934:files_scm",(void*)f_934},
{"f_920:files_scm",(void*)f_920},
{"f_927:files_scm",(void*)f_927},
{"f_914:files_scm",(void*)f_914},
{"f_917:files_scm",(void*)f_917},
{"f_844:files_scm",(void*)f_844},
{"f_851:files_scm",(void*)f_851},
{"f_857:files_scm",(void*)f_857},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
