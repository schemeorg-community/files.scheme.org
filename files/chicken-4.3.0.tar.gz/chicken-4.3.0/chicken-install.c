/* Generated from chicken-install.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-12-14 09:04
   Version 4.2.0 - SVN rev. 16023
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-12-14 on galinha (Linux)
   command line: chicken-install.scm -optimize-level 2 -include-path . -include-path ./ -inline -no-lambda-info -local -no-trace -ignore-repository -output-file chicken-install.c
   used units: library eval data_structures ports extras srfi_69 srfi_1 posix data_structures utils regex ports extras srfi_13 files chicken_syntax
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_chicken_syntax_toplevel)
C_externimport void C_ccall C_chicken_syntax_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[266];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_930)
static void C_ccall f_930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_933)
static void C_ccall f_933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_936)
static void C_ccall f_936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_939)
static void C_ccall f_939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_942)
static void C_ccall f_942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_945)
static void C_ccall f_945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_948)
static void C_ccall f_948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_951)
static void C_ccall f_951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_954)
static void C_ccall f_954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_957)
static void C_ccall f_957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_960)
static void C_ccall f_960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_963)
static void C_ccall f_963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_966)
static void C_ccall f_966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_969)
static void C_ccall f_969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_972)
static void C_ccall f_972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_975)
static void C_ccall f_975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_978)
static void C_ccall f_978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_981)
static void C_ccall f_981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_986)
static void C_ccall f_986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_989)
static void C_ccall f_989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_992)
static void C_ccall f_992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3376)
static void C_ccall f_3376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3372)
static void C_ccall f_3372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1449)
static void C_ccall f_1449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3290)
static void C_ccall f_3290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3304)
static void C_ccall f_3304(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3339)
static void C_ccall f_3339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3358)
static void C_ccall f_3358(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3358)
static void C_ccall f_3358r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3364)
static void C_ccall f_3364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3345)
static void C_ccall f_3345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3356)
static void C_ccall f_3356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1036)
static void C_ccall f_1036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1015)
static void C_ccall f_1015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1032)
static void C_ccall f_1032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1025)
static void C_ccall f_1025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2582)
static void C_fcall f_2582(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2587)
static void C_fcall f_2587(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2677)
static void C_fcall f_2677(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3086)
static void C_fcall f_3086(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3231)
static void C_ccall f_3231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3194)
static void C_ccall f_3194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3208)
static void C_ccall f_3208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3149)
static void C_ccall f_3149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3172)
static void C_ccall f_3172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3181)
static void C_ccall f_3181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3188)
static void C_ccall f_3188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3175)
static void C_ccall f_3175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3153)
static void C_ccall f_3153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3133)
static void C_ccall f_3133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3095)
static void C_ccall f_3095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3129)
static void C_ccall f_3129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3118)
static void C_ccall f_3118(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3112)
static void C_ccall f_3112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3108)
static void C_ccall f_3108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3059)
static void C_ccall f_3059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3029)
static void C_ccall f_3029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2945)
static void C_ccall f_2945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2948)
static void C_ccall f_2948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2966)
static void C_ccall f_2966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2951)
static void C_fcall f_2951(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2916)
static void C_ccall f_2916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1100)
static void C_ccall f_1100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1106)
static void C_ccall f_1106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1111)
static void C_fcall f_1111(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1135)
static void C_ccall f_1135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1138)
static void C_ccall f_1138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1141)
static void C_ccall f_1141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1165)
static void C_ccall f_1165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1161)
static void C_ccall f_1161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1144)
static void C_ccall f_1144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1147)
static void C_ccall f_1147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1157)
static void C_ccall f_1157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1150)
static void C_ccall f_1150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1153)
static void C_ccall f_1153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1124)
static void C_ccall f_1124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2919)
static void C_ccall f_2919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2887)
static void C_ccall f_2887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2880)
static void C_ccall f_2880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2829)
static void C_ccall f_2829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2792)
static void C_ccall f_2792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2796)
static void C_ccall f_2796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2759)
static void C_ccall f_2759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2723)
static void C_ccall f_2723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2631)
static void C_ccall f_2631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2662)
static void C_ccall f_2662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2647)
static void C_ccall f_2647(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2655)
static void C_ccall f_2655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2645)
static void C_ccall f_2645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2641)
static void C_ccall f_2641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2603)
static void C_ccall f_2603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2616)
static void C_ccall f_2616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2606)
static void C_ccall f_2606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2613)
static void C_ccall f_2613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2098)
static void C_ccall f_2098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2240)
static void C_ccall f_2240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2104)
static void C_ccall f_2104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2107)
static void C_ccall f_2107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2110)
static void C_ccall f_2110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2232)
static void C_ccall f_2232(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2117)
static void C_ccall f_2117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2119)
static void C_fcall f_2119(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2132)
static void C_ccall f_2132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2135)
static void C_ccall f_2135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2159)
static void C_ccall f_2159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2089)
static void C_ccall f_2089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2003)
static void C_ccall f_2003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2006)
static void C_ccall f_2006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2009)
static void C_ccall f_2009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2012)
static void C_ccall f_2012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2015)
static void C_ccall f_2015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2018)
static void C_ccall f_2018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2021)
static void C_ccall f_2021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2075)
static void C_ccall f_2075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2060)
static void C_ccall f_2060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2063)
static void C_ccall f_2063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2066)
static void C_ccall f_2066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2069)
static void C_ccall f_2069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2041)
static void C_ccall f_2041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2049)
static void C_ccall f_2049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2045)
static void C_ccall f_2045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2163)
static void C_ccall f_2163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2166)
static void C_ccall f_2166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2169)
static void C_ccall f_2169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2209)
static void C_ccall f_2209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2215)
static void C_ccall f_2215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2175)
static void C_ccall f_2175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2178)
static void C_ccall f_2178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2181)
static void C_ccall f_2181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2184)
static void C_ccall f_2184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2187)
static void C_ccall f_2187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2190)
static void C_ccall f_2190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2193)
static void C_ccall f_2193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2196)
static void C_ccall f_2196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2150)
static void C_ccall f_2150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2139)
static void C_ccall f_2139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2143)
static void C_ccall f_2143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2146)
static void C_ccall f_2146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2544)
static void C_ccall f_2544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2540)
static void C_ccall f_2540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2261)
static void C_ccall f_2261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2264)
static void C_ccall f_2264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2267)
static void C_ccall f_2267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2270)
static void C_ccall f_2270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2273)
static void C_ccall f_2273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2533)
static void C_ccall f_2533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2421)
static void C_ccall f_2421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2427)
static void C_fcall f_2427(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2440)
static void C_ccall f_2440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2455)
static void C_ccall f_2455(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2493)
static void C_ccall f_2493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2521)
static void C_ccall f_2521(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2521)
static void C_ccall f_2521r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2527)
static void C_ccall f_2527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2499)
static void C_ccall f_2499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2515)
static void C_ccall f_2515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2461)
static void C_ccall f_2461(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2467)
static void C_ccall f_2467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2475)
static void C_ccall f_2475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2479)
static void C_ccall f_2479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2482)
static void C_ccall f_2482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2485)
static void C_ccall f_2485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2488)
static void C_ccall f_2488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2491)
static void C_ccall f_2491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2453)
static void C_ccall f_2453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2443)
static void C_ccall f_2443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2416)
static void C_ccall f_2416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2276)
static void C_ccall f_2276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2279)
static void C_ccall f_2279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2361)
static void C_ccall f_2361(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2368)
static void C_ccall f_2368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2371)
static void C_ccall f_2371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2382)
static void C_ccall f_2382(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2406)
static void C_ccall f_2406(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2390)
static void C_ccall f_2390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2396)
static void C_ccall f_2396(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2394)
static void C_ccall f_2394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2376)
static void C_ccall f_2376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2337)
static void C_ccall f_2337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2339)
static void C_ccall f_2339(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2347)
static void C_ccall f_2347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2351)
static void C_ccall f_2351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2282)
static void C_ccall f_2282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2285)
static void C_ccall f_2285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2304)
static void C_ccall f_2304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2310)
static void C_fcall f_2310(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2323)
static void C_ccall f_2323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2326)
static void C_ccall f_2326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2288)
static void C_ccall f_2288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2302)
static void C_ccall f_2302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2298)
static void C_ccall f_2298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2291)
static void C_ccall f_2291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3349)
static void C_ccall f_3349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3310)
static void C_ccall f_3310(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3316)
static void C_ccall f_3316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3337)
static void C_ccall f_3337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3320)
static void C_ccall f_3320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3333)
static void C_ccall f_3333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3323)
static void C_ccall f_3323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3326)
static void C_ccall f_3326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3302)
static void C_ccall f_3302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3293)
static void C_ccall f_3293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3299)
static void C_ccall f_3299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3296)
static void C_ccall f_3296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2568)
static void C_fcall f_2568(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2572)
static void C_ccall f_2572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2546)
static void C_fcall f_2546(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2563)
static void C_ccall f_2563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2550)
static void C_ccall f_2550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2242)
static void C_fcall f_2242(C_word t0) C_noret;
C_noret_decl(f_2249)
static void C_ccall f_2249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1717)
static void C_fcall f_1717(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1721)
static void C_ccall f_1721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1911)
static void C_fcall f_1911(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1959)
static void C_ccall f_1959(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1963)
static void C_ccall f_1963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1966)
static void C_ccall f_1966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1953)
static void C_ccall f_1953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1592)
static void C_fcall f_1592(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1594)
static void C_fcall f_1594(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1658)
static void C_ccall f_1658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1648)
static void C_ccall f_1648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1624)
static void C_ccall f_1624(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1079)
static void C_ccall f_1079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1618)
static void C_ccall f_1618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1460)
static void C_ccall f_1460(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1553)
static void C_ccall f_1553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1572)
static void C_ccall f_1572(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1572)
static void C_ccall f_1572r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1578)
static void C_ccall f_1578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1559)
static void C_ccall f_1559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1567)
static void C_ccall f_1567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1466)
static void C_ccall f_1466(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1472)
static void C_ccall f_1472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1482)
static void C_fcall f_1482(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1494)
static void C_fcall f_1494(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1506)
static void C_fcall f_1506(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1509)
static void C_ccall f_1509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1512)
static void C_ccall f_1512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1497)
static void C_ccall f_1497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1485)
static void C_ccall f_1485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1458)
static void C_ccall f_1458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1942)
static void C_ccall f_1942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1927)
static void C_ccall f_1927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1724)
static void C_ccall f_1724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1732)
static void C_fcall f_1732(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1762)
static void C_ccall f_1762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1768)
static void C_ccall f_1768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1889)
static void C_ccall f_1889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1771)
static void C_ccall f_1771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1774)
static void C_ccall f_1774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1785)
static void C_ccall f_1785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1878)
static void C_ccall f_1878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1866)
static void C_ccall f_1866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1859)
static void C_ccall f_1859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1793)
static void C_ccall f_1793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1681)
static void C_ccall f_1681(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1707)
static void C_ccall f_1707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1679)
static void C_ccall f_1679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1671)
static void C_ccall f_1671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1853)
static void C_ccall f_1853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1799)
static void C_ccall f_1799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1802)
static void C_ccall f_1802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1840)
static void C_ccall f_1840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1805)
static void C_ccall f_1805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1813)
static void C_fcall f_1813(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1826)
static void C_ccall f_1826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1829)
static void C_ccall f_1829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1808)
static void C_ccall f_1808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1779)
static void C_ccall f_1779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1230)
static void C_fcall f_1230(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1239)
static void C_ccall f_1239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1244)
static void C_fcall f_1244(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1300)
static void C_fcall f_1300(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1406)
static void C_ccall f_1406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1303)
static void C_ccall f_1303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1320)
static void C_ccall f_1320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1395)
static void C_ccall f_1395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1391)
static void C_ccall f_1391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1380)
static void C_ccall f_1380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1366)
static void C_ccall f_1366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1333)
static void C_ccall f_1333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1344)
static void C_ccall f_1344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1348)
static void C_ccall f_1348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1340)
static void C_ccall f_1340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1287)
static void C_ccall f_1287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1294)
static void C_ccall f_1294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1284)
static void C_fcall f_1284(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1258)
static void C_ccall f_1258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1262)
static void C_ccall f_1262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1745)
static void C_ccall f_1745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1167)
static void C_fcall f_1167(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1212)
static void C_ccall f_1212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1177)
static void C_fcall f_1177(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1183)
static void C_ccall f_1183(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_2582)
static void C_fcall trf_2582(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2582(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2582(t0,t1);}

C_noret_decl(trf_2587)
static void C_fcall trf_2587(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2587(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2587(t0,t1,t2,t3);}

C_noret_decl(trf_2677)
static void C_fcall trf_2677(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2677(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2677(t0,t1);}

C_noret_decl(trf_3086)
static void C_fcall trf_3086(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3086(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3086(t0,t1);}

C_noret_decl(trf_2951)
static void C_fcall trf_2951(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2951(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2951(t0,t1);}

C_noret_decl(trf_1111)
static void C_fcall trf_1111(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1111(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1111(t0,t1,t2);}

C_noret_decl(trf_2119)
static void C_fcall trf_2119(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2119(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2119(t0,t1,t2);}

C_noret_decl(trf_2427)
static void C_fcall trf_2427(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2427(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2427(t0,t1,t2);}

C_noret_decl(trf_2310)
static void C_fcall trf_2310(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2310(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2310(t0,t1,t2);}

C_noret_decl(trf_2568)
static void C_fcall trf_2568(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2568(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2568(t0,t1);}

C_noret_decl(trf_2546)
static void C_fcall trf_2546(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2546(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2546(t0,t1);}

C_noret_decl(trf_2242)
static void C_fcall trf_2242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2242(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_2242(t0);}

C_noret_decl(trf_1717)
static void C_fcall trf_1717(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1717(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1717(t0,t1);}

C_noret_decl(trf_1911)
static void C_fcall trf_1911(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1911(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1911(t0,t1,t2);}

C_noret_decl(trf_1592)
static void C_fcall trf_1592(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1592(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1592(t0,t1);}

C_noret_decl(trf_1594)
static void C_fcall trf_1594(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1594(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1594(t0,t1,t2);}

C_noret_decl(trf_1482)
static void C_fcall trf_1482(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1482(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1482(t0,t1);}

C_noret_decl(trf_1494)
static void C_fcall trf_1494(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1494(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1494(t0,t1);}

C_noret_decl(trf_1506)
static void C_fcall trf_1506(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1506(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1506(t0,t1);}

C_noret_decl(trf_1732)
static void C_fcall trf_1732(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1732(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1732(t0,t1,t2);}

C_noret_decl(trf_1813)
static void C_fcall trf_1813(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1813(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1813(t0,t1,t2);}

C_noret_decl(trf_1230)
static void C_fcall trf_1230(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1230(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1230(t0,t1);}

C_noret_decl(trf_1244)
static void C_fcall trf_1244(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1244(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1244(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1300)
static void C_fcall trf_1300(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1300(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1300(t0,t1);}

C_noret_decl(trf_1284)
static void C_fcall trf_1284(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1284(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1284(t0,t1);}

C_noret_decl(trf_1167)
static void C_fcall trf_1167(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1167(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1167(t0,t1);}

C_noret_decl(trf_1177)
static void C_fcall trf_1177(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1177(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1177(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1211)){
C_save(t1);
C_rereclaim2(1211*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,266);
lf[13]=C_h_intern(&lf[13],4,"http");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\012modules.db");
lf[20]=C_h_intern(&lf[20],7,"chicken");
lf[21]=C_h_intern(&lf[21],15,"chicken-version");
lf[22]=C_h_intern(&lf[22],7,"version");
lf[23]=C_h_intern(&lf[23],8,"->string");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000\0050.0.0");
lf[25]=C_h_intern(&lf[25],21,"extension-information");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[27]=C_h_intern(&lf[27],24,"\003syscore-library-modules");
lf[33]=C_h_intern(&lf[33],7,"reverse");
lf[34]=C_h_intern(&lf[34],10,"alist-cons");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[36]=C_h_intern(&lf[36],5,"error");
lf[37]=C_h_intern(&lf[37],13,"string-append");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000JYour CHICKEN version is not recent enough to use this extension - version ");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\025 or newer is required");
lf[40]=C_h_intern(&lf[40],20,"setup-api#version>=\077");
lf[41]=C_h_intern(&lf[41],7,"warning");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\0007invalid dependency syntax in extension meta information");
lf[43]=C_h_intern(&lf[43],7,"depends");
lf[44]=C_h_intern(&lf[44],5,"needs");
lf[45]=C_h_intern(&lf[45],6,"append");
lf[46]=C_h_intern(&lf[46],12,"test-depends");
lf[47]=C_h_intern(&lf[47],26,"setup-api#remove-extension");
lf[48]=C_h_intern(&lf[48],5,"print");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000)removing previously installed extension `");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\005\047 ...");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\012 upgrade: ");
lf[52]=C_h_intern(&lf[52],18,"string-intersperse");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\002, ");
lf[54]=C_h_intern(&lf[54],6,"unzip1");
lf[55]=C_h_intern(&lf[55],20,"setup-api#yes-or-no\077");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\002no");
lf[57]=C_h_intern(&lf[57],18,"string-concatenate");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000:The following installed extensions are outdated, because `");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\033\047 requires later versions:\012");
lf[60]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\0000\012Do you want to replace the existing extensions\077\376\377\016");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\003\077\077\077");
lf[62]=C_h_intern(&lf[62],4,"conc");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\002 (");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\004 -> ");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[67]=C_h_intern(&lf[67],7,"\003sysmap");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\012 missing: ");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\002, ");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\033checking dependencies for `");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\005\047 ...");
lf[72]=C_h_intern(&lf[72],20,"with-input-from-file");
lf[73]=C_h_intern(&lf[73],4,"read");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\013extension `");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\024\047 has no .meta file ");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000!- assuming it has no dependencies");
lf[77]=C_h_intern(&lf[77],12,"file-exists\077");
lf[78]=C_h_intern(&lf[78],13,"make-pathname");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\004meta");
lf[80]=C_h_intern(&lf[80],6,"delete");
lf[81]=C_h_intern(&lf[81],3,"eq\077");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[83]=C_h_intern(&lf[83],8,"location");
lf[84]=C_h_intern(&lf[84],9,"transport");
lf[85]=C_h_intern(&lf[85],9,"condition");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\023TCP connect timeout");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\023HTTP protocol error");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[91]=C_h_intern(&lf[91],19,"print-error-message");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\015Server error:");
lf[93]=C_h_intern(&lf[93],5,"abort");
lf[94]=C_h_intern(&lf[94],3,"exn");
lf[95]=C_h_intern(&lf[95],20,"setup-download-error");
lf[96]=C_h_intern(&lf[96],10,"http-fetch");
lf[97]=C_h_intern(&lf[97],3,"net");
lf[98]=C_h_intern(&lf[98],33,"setup-download#retrieve-extension");
lf[99]=C_h_intern(&lf[99],8,"\000version");
lf[100]=C_h_intern(&lf[100],12,"\000destination");
lf[101]=C_h_intern(&lf[101],6,"\000tests");
lf[102]=C_h_intern(&lf[102],9,"\000username");
lf[103]=C_h_intern(&lf[103],9,"\000password");
lf[104]=C_h_intern(&lf[104],11,"\000proxy-host");
lf[105]=C_h_intern(&lf[105],11,"\000proxy-port");
lf[106]=C_h_intern(&lf[106],17,"current-directory");
lf[107]=C_h_intern(&lf[107],22,"with-exception-handler");
lf[108]=C_h_intern(&lf[108],30,"call-with-current-continuation");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\027missing transport entry");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\026missing location entry");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\014 located at ");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\036extension or version not found");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\016retrieving ...");
lf[116]=C_h_intern(&lf[116],26,"setup-api#remove-directory");
lf[117]=C_h_intern(&lf[117],34,"setup-download#temporary-directory");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000/shell command terminated with nonzero exit code");
lf[120]=C_h_intern(&lf[120],6,"system");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[124]=C_h_intern(&lf[124],4,"exit");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\004\340usage: chicken-install [OPTION | EXTENSION[:VERSION]] ...\012\012  -h   -help    "
"                show this message and exit\012  -v   -version                 show "
"version and exit\012       -force                   don\047t ask, install even if vers"
"ions don\047t match\012  -k   -keep                    keep temporary files\012  -l   -lo"
"cation LOCATION       install from given location instead of default\012  -t   -tra"
"nsport TRANSPORT     use given transport instead of default\012       -proxy HOST[:"
"PORT]       download via HTTP proxy\012  -s   -sudo                    use sudo(1) "
"for filesystem operations\012  -r   -retrieve                only retrieve egg into"
" current directory, don\047t install\012  -n   -no-install              do not install"
", just build (implies `-keep\047)\012  -p   -prefix PREFIX           change installati"
"on prefix to PREFIX\012       -host                    when cross-compiling, compil"
"e extension for host\012       -test                    run included test-cases, if"
" available\012       -username USER           set username for transports that requ"
"ire this\012       -password PASS           set password for transports that requir"
"e this\012  -i   -init DIRECTORY          initialize empty alternative repository\012 "
" -u   -update-db               update export database");
lf[126]=C_h_intern(&lf[126],25,"\003sysimplicit-exit-handler");
lf[127]=C_h_intern(&lf[127],18,"current-error-port");
lf[128]=C_h_intern(&lf[128],7,"newline");
lf[129]=C_h_intern(&lf[129],19,"setup-api#copy-file");
lf[130]=C_h_intern(&lf[130],15,"repository-path");
lf[131]=C_h_intern(&lf[131],5,"write");
lf[132]=C_h_intern(&lf[132],19,"with-output-to-file");
lf[133]=C_h_intern(&lf[133],8,"string<\077");
lf[134]=C_h_intern(&lf[134],14,"symbol->string");
lf[135]=C_h_intern(&lf[135],4,"sort");
lf[136]=C_h_intern(&lf[136],18,"\003sysmodule-exports");
lf[137]=C_h_intern(&lf[137],5,"value");
lf[138]=C_h_intern(&lf[138],6,"syntax");
lf[139]=C_h_intern(&lf[139],6,"print*");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[141]=C_h_intern(&lf[141],15,"\003sysmodule-name");
lf[142]=C_h_intern(&lf[142],10,"append-map");
lf[143]=C_h_intern(&lf[143],16,"\003sysmodule-table");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\023generating database");
lf[145]=C_h_intern(&lf[145],20,"\003syswarnings-enabled");
lf[146]=C_h_intern(&lf[146],17,"get-output-string");
lf[147]=C_h_intern(&lf[147],19,"\003syswrite-char/port");
lf[148]=C_h_intern(&lf[148],7,"display");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\027Failed to import from `");
lf[150]=C_h_intern(&lf[150],18,"open-output-string");
lf[151]=C_h_intern(&lf[151],6,"import");
lf[152]=C_h_intern(&lf[152],4,"eval");
lf[153]=C_h_intern(&lf[153],14,"string->symbol");
lf[154]=C_h_intern(&lf[154],12,"string-match");
lf[155]=C_h_intern(&lf[155],16,"\003sysdynamic-wind");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\034loading import libraries ...");
lf[157]=C_h_intern(&lf[157],6,"regexp");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\034.*/([^/]+)\134.import\134.(scm|so)");
lf[159]=C_h_intern(&lf[159],36,"setup-api#create-temporary-directory");
lf[160]=C_h_intern(&lf[160],4,"glob");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\012*.import.*");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\014 -s run.scm ");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\005tests");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\015tests/run.scm");
lf[166]=C_h_intern(&lf[166],10,"directory\077");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\005tests");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\005tests");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\014-setup-mode ");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\027 -e \042(sudo-install #t)\042");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\035 -e \042(keep-intermediates #t)\042");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\035 -e \042(setup-install-mode #f)\042");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\031 -e \042(host-extension #t)\042");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\006 -bnq ");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\0008-e \042(require-library setup-api)\042 -e \042(import setup-api)\042");
lf[182]=C_h_intern(&lf[182],19,"setup-api#shellpath");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\005setup");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\004\134\042)\042");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\034 -e \042(installation-prefix \134\042");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[187]=C_h_intern(&lf[187],22,"setup-api#sudo-install");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\005\134\042))\042");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\005\134\042 \134\042");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000% -e \042(extension-name-and-version \047(\134\042");
lf[191]=C_h_intern(&lf[191],8,"feature\077");
lf[192]=C_h_intern(&lf[192],14,"\000cross-chicken");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\036changing current directory to ");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\013installing ");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[196]=C_h_intern(&lf[196],2,"pp");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\016install order:");
lf[198]=C_h_intern(&lf[198],16,"topological-sort");
lf[199]=C_h_intern(&lf[199],8,"string=\077");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000;no default location defined - please use `-location\047 option");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000=no default transport defined - please use `-transport\047 option");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[204]=C_h_intern(&lf[204],13,"pathname-file");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\033no setup-scripts to process");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\007*.setup");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\006-force");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\002-k");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\005-keep");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\005-sudo");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\002-r");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\011-retrieve");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\002-l");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\011-location");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\002-t");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\012-transport");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\002-p");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\007-prefix");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\002-n");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\013-no-install");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\010-version");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\002-u");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\012-update-db");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\002-i");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\005-init");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\004copy");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\005cp -r");
lf[231]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014setup-api.so\376\003\000\000\002\376B\000\000\023setup-api.import.so\376\003\000\000\002\376B\000\000\021setup-download.so\376\003"
"\000\000\002\376B\000\000\030setup-download.import.so\376\003\000\000\002\376B\000\000\021chicken.import.so\376\003\000\000\002\376B\000\000\021lolevel.imp"
"ort.so\376\003\000\000\002\376B\000\000\020srfi-1.import.so\376\003\000\000\002\376B\000\000\020srfi-4.import.so\376\003\000\000\002\376B\000\000\031data-structu"
"res.import.so\376\003\000\000\002\376B\000\000\017ports.import.so\376\003\000\000\002\376B\000\000\017files.import.so\376\003\000\000\002\376B\000\000\017posix.i"
"mport.so\376\003\000\000\002\376B\000\000\021srfi-13.import.so\376\003\000\000\002\376B\000\000\021srfi-69.import.so\376\003\000\000\002\376B\000\000\020extras.i"
"mport.so\376\003\000\000\002\376B\000\000\017regex.import.so\376\003\000\000\002\376B\000\000\021srfi-14.import.so\376\003\000\000\002\376B\000\000\015tcp.import"
".so\376\003\000\000\002\376B\000\000\021foreign.import.so\376\003\000\000\002\376B\000\000\020scheme.import.so\376\003\000\000\002\376B\000\000\021srfi-18.import"
".so\376\003\000\000\002\376B\000\000\017utils.import.so\376\003\000\000\002\376B\000\000\015csi.import.so\376\003\000\000\002\376B\000\000\021irregex.import.so\376\003"
"\000\000\002\376B\000\000\010types.db\376\377\016");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\032copying required files to ");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\006-proxy");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\016(.+)\134:([0-9]+)");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\005-test");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\005-host");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\017-host-extension");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\011-username");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\011-password");
lf[241]=C_h_intern(&lf[241],17,"lset-intersection");
lf[242]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000k\376\003\000\000\002\376\377\012\000\000l\376\003\000\000\002\376\377\012\000\000t\376\003\000\000\002\376\377\012\000\000s\376\003\000\000\002\376\377\012\000\000p\376\003\000\000\002\376\377\012\000\000r\376\003\000"
"\000\002\376\377\012\000\000n\376\003\000\000\002\376\377\012\000\000v\376\003\000\000\002\376\377\012\000\000i\376\003\000\000\002\376\377\012\000\000u\376\377\016");
lf[243]=C_h_intern(&lf[243],16,"\003sysstring->list");
lf[244]=C_h_intern(&lf[244],9,"substring");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\005setup");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[247]=C_h_intern(&lf[247],18,"absolute-pathname\077");
lf[248]=C_h_intern(&lf[248],18,"pathname-directory");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\014([^:]+):(.+)");
lf[250]=C_h_intern(&lf[250],18,"pathname-extension");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[253]=C_h_intern(&lf[253],9,"read-file");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000\016setup.defaults");
lf[255]=C_h_intern(&lf[255],12,"chicken-home");
lf[256]=C_h_intern(&lf[256],22,"command-line-arguments");
lf[257]=C_h_intern(&lf[257],17,"register-feature!");
lf[258]=C_h_intern(&lf[258],15,"chicken-install");
lf[259]=C_h_intern(&lf[259],17,"\003syspeek-c-string");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[261]=C_h_intern(&lf[261],24,"get-environment-variable");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[263]=C_h_intern(&lf[263],11,"\003sysrequire");
lf[264]=C_h_intern(&lf[264],9,"setup-api");
lf[265]=C_h_intern(&lf[265],14,"setup-download");
C_register_lf2(lf,266,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_930,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k928 */
static void C_ccall f_930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_933,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k931 in k928 */
static void C_ccall f_933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_933,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_936,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k934 in k931 in k928 */
static void C_ccall f_936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_939,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k937 in k934 in k931 in k928 */
static void C_ccall f_939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_942,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_945,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_948,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_951,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_954,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_957,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_957,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_960,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_963,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_963,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_966,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_969,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_969,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_972,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_975,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_chicken_syntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_975,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_978,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#require */
((C_proc3)C_retrieve_symbol_proc(lf[263]))(3,*((C_word*)lf[263]+1),t2,lf[265]);}

/* k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_981,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#require */
((C_proc3)C_retrieve_symbol_proc(lf[263]))(3,*((C_word*)lf[263]+1),t2,lf[264]);}

/* k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_986,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 67   get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[261]))(3,*((C_word*)lf[261]+1),t2,lf[262]);}

/* k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_989,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
/* chicken-install.scm: 68   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[78]))(4,*((C_word*)lf[78]+1),t2,t1,lf[260]);}
else{
t3=t2;
f_989(2,t3,C_SCHEME_FALSE);}}

/* k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_992,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_992(2,t3,t1);}
else{
/* ##sys#peek-c-string */
t3=*((C_word*)lf[259]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}}

/* k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_992,2,t0,t1);}
t2=C_mutate(&lf[0] /* (set! main#*program-path* ...) */,t1);
t3=lf[1] /* main#*keep* */ =C_SCHEME_FALSE;;
t4=lf[2] /* main#*force* */ =C_SCHEME_FALSE;;
t5=lf[3] /* main#*prefix* */ =C_SCHEME_FALSE;;
t6=lf[4] /* main#*host-extension* */ =C_SCHEME_FALSE;;
t7=lf[5] /* main#*run-tests* */ =C_SCHEME_FALSE;;
t8=lf[6] /* main#*retrieve-only* */ =C_SCHEME_FALSE;;
t9=lf[7] /* main#*no-install* */ =C_SCHEME_FALSE;;
t10=lf[8] /* main#*username* */ =C_SCHEME_FALSE;;
t11=lf[9] /* main#*password* */ =C_SCHEME_FALSE;;
t12=lf[10] /* main#*default-sources* */ =C_SCHEME_END_OF_LIST;;
t13=lf[11] /* main#*default-location* */ =C_SCHEME_FALSE;;
t14=C_mutate(&lf[12] /* (set! main#*default-transport* ...) */,lf[13]);
t15=C_mutate(&lf[14] /* (set! main#*windows-shell* ...) */,C_mk_bool(C_WINDOWS_SHELL));
t16=lf[15] /* main#*proxy-host* */ =C_SCHEME_FALSE;;
t17=lf[16] /* main#*proxy-port* */ =C_SCHEME_FALSE;;
t18=C_mutate(&lf[17] /* (set! main#constant174 ...) */,lf[18]);
t19=C_mutate(&lf[19] /* (set! main#ext-version ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1167,tmp=(C_word)a,a+=2,tmp));
t20=lf[28] /* main#*eggs+dirs+vers* */ =C_SCHEME_END_OF_LIST;;
t21=lf[29] /* main#*dependencies* */ =C_SCHEME_END_OF_LIST;;
t22=lf[30] /* main#*checked* */ =C_SCHEME_END_OF_LIST;;
t23=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1449,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3372,a[2]=t23,tmp=(C_word)a,a+=3,tmp);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3376,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t26=*((C_word*)lf[259]+1);
((C_proc4)(void*)(*((C_word*)t26+1)))(4,t26,t25,C_mpointer(&a,(void*)C_CSI_PROGRAM),C_fix(0));}

/* k3374 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 182  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[78]))(4,*((C_word*)lf[78]+1),((C_word*)t0)[2],C_retrieve2(lf[0],"main#*program-path*"),t1);}

/* k3370 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 182  setup-api#shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[182]))(3,*((C_word*)lf[182]+1),((C_word*)t0)[2],t1);}

/* k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1449,2,t0,t1);}
t2=C_mutate(&lf[31] /* (set! main#*csi* ...) */,t1);
t3=C_mutate(&lf[32] /* (set! main#retrieve ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1717,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[115] /* (set! main#cleanup ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2242,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate(&lf[118] /* (set! main#$system ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2546,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate(&lf[123] /* (set! main#usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2568,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3290,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 536  register-feature! */
((C_proc3)C_retrieve_symbol_proc(lf[257]))(3,*((C_word*)lf[257]+1),t7,lf[258]);}

/* k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3290,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3293,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3302,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3304,tmp=(C_word)a,a+=2,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[108]+1)))(3,*((C_word*)lf[108]+1),t3,t4);}

/* a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3304(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3304,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3310,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3339,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),t1,t3,t4);}

/* a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3339,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3345,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3358,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a3357 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3358(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3358r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3358r(t0,t1,t2);}}

static void C_ccall f_3358r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3364,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k852855 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3363 in a3357 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3364,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3345,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3349,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3356,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 544  command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[256]))(2,*((C_word*)lf[256]+1),t3);}

/* k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3356,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2582,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1015,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1036,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 91   chicken-home */
((C_proc2)C_retrieve_symbol_proc(lf[255]))(2,*((C_word*)lf[255]+1),t4);}

/* k1034 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 91   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[78]))(4,*((C_word*)lf[78]+1),((C_word*)t0)[2],t1,lf[254]);}

/* k1013 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1015,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1032,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 92   file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[77]))(3,*((C_word*)lf[77]+1),t2,t1);}

/* k1030 in k1013 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1032,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1025,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 95   read-file */
((C_proc3)C_retrieve_symbol_proc(lf[253]))(3,*((C_word*)lf[253]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2582(t2,C_SCHEME_END_OF_LIST);}}

/* k1023 in k1030 in k1013 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[10] /* (set! main#*default-sources* ...) */,t1);
t3=((C_word*)t0)[2];
f_2582(t3,(C_word)C_i_pairp(C_retrieve2(lf[10],"main#*default-sources*")));}

/* k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_fcall f_2582(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2582,NULL,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2587,a[2]=t5,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_2587(t7,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_fcall f_2587(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2587,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t4=t1;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2261,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2540,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2544,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 341  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[130]))(2,*((C_word*)lf[130]+1),t7);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2603,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2631,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 422  glob */
((C_proc3)C_retrieve_symbol_proc(lf[160]))(3,*((C_word*)lf[160]+1),t5,lf[206]);}
else{
t5=t4;
f_2603(2,t5,C_SCHEME_UNDEFINED);}}}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_string_equal_p(t4,lf[207]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2677,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t4,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t5)){
t7=t6;
f_2677(t7,t5);}
else{
t7=(C_word)C_i_string_equal_p(t4,lf[251]);
t8=t6;
f_2677(t8,(C_truep(t7)?t7:(C_word)C_i_string_equal_p(t4,lf[252])));}}}

/* k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_fcall f_2677(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2677,NULL,2,t0,t1);}
if(C_truep(t1)){
/* chicken-install.scm: 444  usage */
f_2568(((C_word*)t0)[7],C_fix(0));}
else{
if(C_truep((C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[208]))){
t2=lf[2] /* main#*force* */ =C_SCHEME_TRUE;;
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 447  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2587(t4,((C_word*)t0)[7],t3,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[209]);
t3=(C_truep(t2)?t2:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[210]));
if(C_truep(t3)){
t4=lf[1] /* main#*keep* */ =C_SCHEME_TRUE;;
t5=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 450  loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2587(t6,((C_word*)t0)[7],t5,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[211]);
t5=(C_truep(t4)?t4:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[212]));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2723,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 452  setup-api#sudo-install */
((C_proc3)C_retrieve_symbol_proc(lf[187]))(3,*((C_word*)lf[187]+1),t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[213]);
t7=(C_truep(t6)?t6:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[214]));
if(C_truep(t7)){
t8=lf[6] /* main#*retrieve-only* */ =C_SCHEME_TRUE;;
t9=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 456  loop */
t10=((C_word*)((C_word*)t0)[4])[1];
f_2587(t10,((C_word*)t0)[7],t9,((C_word*)t0)[3]);}
else{
t8=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[215]);
t9=(C_truep(t8)?t8:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[216]));
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2759,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t11))){
t12=t10;
f_2759(2,t12,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 458  usage */
f_2568(t10,C_fix(1));}}
else{
t10=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[217]);
t11=(C_truep(t10)?t10:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[218]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2792,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t13=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t13))){
t14=t12;
f_2792(2,t14,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 462  usage */
f_2568(t12,C_fix(1));}}
else{
t12=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[219]);
t13=(C_truep(t12)?t12:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[220]));
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2829,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t15=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t15))){
t16=t14;
f_2829(2,t16,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 466  usage */
f_2568(t14,C_fix(1));}}
else{
t14=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[221]);
t15=(C_truep(t14)?t14:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[222]));
if(C_truep(t15)){
t16=lf[1] /* main#*keep* */ =C_SCHEME_TRUE;;
t17=lf[7] /* main#*no-install* */ =C_SCHEME_TRUE;;
t18=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 472  loop */
t19=((C_word*)((C_word*)t0)[4])[1];
f_2587(t19,((C_word*)t0)[7],t18,((C_word*)t0)[3]);}
else{
t16=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[223]);
t17=(C_truep(t16)?t16:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[224]));
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2880,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2887,a[2]=t18,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 474  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[21]))(2,*((C_word*)lf[21]+1),t19);}
else{
t18=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[225]);
t19=(C_truep(t18)?t18:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[226]));
if(C_truep(t19)){
t20=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t21=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 478  loop */
t22=((C_word*)((C_word*)t0)[4])[1];
f_2587(t22,((C_word*)t0)[7],t21,((C_word*)t0)[3]);}
else{
t20=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[227]);
t21=(C_truep(t20)?t20:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[228]));
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2916,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t23=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t23))){
t24=t22;
f_2916(2,t24,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 480  usage */
f_2568(t22,C_fix(1));}}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[234],((C_word*)t0)[6]))){
t22=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2945,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t23=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t23))){
t24=t22;
f_2945(2,t24,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 484  usage */
f_2568(t22,C_fix(1));}}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[236],((C_word*)t0)[6]))){
t22=lf[5] /* main#*run-tests* */ =C_SCHEME_TRUE;;
t23=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 495  loop */
t24=((C_word*)((C_word*)t0)[4])[1];
f_2587(t24,((C_word*)t0)[7],t23,((C_word*)t0)[3]);}
else{
t22=(C_word)C_i_string_equal_p(lf[237],((C_word*)t0)[6]);
t23=(C_truep(t22)?t22:(C_word)C_i_string_equal_p(lf[238],((C_word*)t0)[6]));
if(C_truep(t23)){
t24=lf[4] /* main#*host-extension* */ =C_SCHEME_TRUE;;
t25=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 499  loop */
t26=((C_word*)((C_word*)t0)[4])[1];
f_2587(t26,((C_word*)t0)[7],t25,((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[239],((C_word*)t0)[6]))){
t24=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3029,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t25=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t25))){
t26=t24;
f_3029(2,t26,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 501  usage */
f_2568(t24,C_fix(1));}}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[240],((C_word*)t0)[6]))){
t24=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3059,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t25=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t25))){
t26=t24;
f_3059(2,t26,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 505  usage */
f_2568(t24,C_fix(1));}}
else{
t24=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3086,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t25=(C_word)C_i_string_length(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_positivep(t25))){
t26=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(0));
t27=t24;
f_3086(t27,(C_word)C_eqp(C_make_character(45),t26));}
else{
t26=t24;
f_3086(t26,C_SCHEME_FALSE);}}}}}}}}}}}}}}}}}}}

/* k3084 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_fcall f_3086(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3086,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_length(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3095,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3133,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 511  substring */
((C_proc4)C_retrieve_proc(*((C_word*)lf[244]+1)))(4,*((C_word*)lf[244]+1),t4,((C_word*)t0)[6],C_fix(1));}
else{
/* chicken-install.scm: 515  usage */
f_2568(((C_word*)t0)[4],C_fix(1));}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3231,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 516  pathname-extension */
((C_proc3)C_retrieve_symbol_proc(lf[250]))(3,*((C_word*)lf[250]+1),t2,((C_word*)t0)[6]);}}

/* k3229 in k3084 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3231,2,t0,t1);}
if(C_truep((C_word)C_i_equalp(lf[245],t1))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3149,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 517  pathname-file */
((C_proc3)C_retrieve_symbol_proc(lf[204]))(3,*((C_word*)lf[204]+1),t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3194,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 531  string-match */
((C_proc4)C_retrieve_symbol_proc(lf[154]))(4,*((C_word*)lf[154]+1),t2,lf[249],((C_word*)t0)[2]);}}

/* k3192 in k3229 in k3084 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3194,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3208,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cadr(t1);
t5=(C_word)C_i_caddr(t1);
/* chicken-install.scm: 533  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[34]))(5,*((C_word*)lf[34]+1),t3,t4,t5,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
/* chicken-install.scm: 534  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2587(t4,((C_word*)t0)[4],t2,t3);}}

/* k3206 in k3192 in k3229 in k3084 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 533  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2587(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3147 in k3229 in k3084 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3149,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3153,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3172,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 522  pathname-directory */
((C_proc3)C_retrieve_symbol_proc(lf[248]))(3,*((C_word*)lf[248]+1),t3,((C_word*)t0)[2]);}

/* k3170 in k3147 in k3229 in k3084 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3172,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3175,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3181,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 524  absolute-pathname? */
((C_proc3)C_retrieve_symbol_proc(lf[247]))(3,*((C_word*)lf[247]+1),t3,t1);}
else{
/* chicken-install.scm: 527  current-directory */
((C_proc2)C_retrieve_symbol_proc(lf[106]))(2,*((C_word*)lf[106]+1),t2);}}

/* k3179 in k3170 in k3147 in k3229 in k3084 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3181,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_3175(2,t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3188,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 526  current-directory */
((C_proc2)C_retrieve_symbol_proc(lf[106]))(2,*((C_word*)lf[106]+1),t2);}}

/* k3186 in k3179 in k3170 in k3147 in k3229 in k3084 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 526  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[78]))(4,*((C_word*)lf[78]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3173 in k3170 in k3147 in k3229 in k3084 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3175,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,lf[246]);
/* chicken-install.scm: 519  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[34]))(5,*((C_word*)lf[34]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2,C_retrieve2(lf[28],"main#*eggs+dirs+vers*"));}

/* k3151 in k3147 in k3229 in k3084 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3153,2,t0,t1);}
t2=C_mutate(&lf[28] /* (set! main#*eggs+dirs+vers* ...) */,t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* chicken-install.scm: 530  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2587(t5,((C_word*)t0)[2],t3,t4);}

/* k3131 in k3084 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[243]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3093 in k3084 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3095,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3129,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 512  lset-intersection */
((C_proc5)C_retrieve_symbol_proc(lf[241]))(5,*((C_word*)lf[241]+1),t2,*((C_word*)lf[81]+1),lf[242],t1);}

/* k3127 in k3093 in k3084 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3129,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3108,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3112,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3118,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}
else{
/* chicken-install.scm: 514  usage */
f_2568(((C_word*)t0)[5],C_fix(1));}}

/* a3117 in k3127 in k3093 in k3084 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3118(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3118,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_string(&a,2,C_make_character(45),t2));}

/* k3110 in k3127 in k3093 in k3084 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken-install.scm: 513  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[45]+1)))(4,*((C_word*)lf[45]+1),((C_word*)t0)[2],t1,t2);}

/* k3106 in k3127 in k3093 in k3084 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 513  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2587(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3057 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=C_mutate(&lf[9] /* (set! main#*password* ...) */,t2);
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* chicken-install.scm: 507  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2587(t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* k3027 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=C_mutate(&lf[8] /* (set! main#*username* ...) */,t2);
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* chicken-install.scm: 503  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2587(t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* k2943 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2948,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* chicken-install.scm: 485  string-match */
((C_proc4)C_retrieve_symbol_proc(lf[154]))(4,*((C_word*)lf[154]+1),t2,lf[235],t3);}

/* k2946 in k2943 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2951,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_cadr(t1);
t4=C_mutate(&lf[15] /* (set! main#*proxy-host* ...) */,t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2966,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_caddr(t1);
/* chicken-install.scm: 488  string->number */
C_string_to_number(3,0,t5,t6);}
else{
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
t4=C_mutate(&lf[15] /* (set! main#*proxy-host* ...) */,t3);
t5=lf[16] /* main#*proxy-port* */ =C_fix(80);;
t6=t2;
f_2951(t6,t5);}}

/* k2964 in k2946 in k2943 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[16] /* (set! main#*proxy-port* ...) */,t1);
t3=((C_word*)t0)[2];
f_2951(t3,t2);}

/* k2949 in k2946 in k2943 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_fcall f_2951(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* chicken-install.scm: 492  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2587(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k2914 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2919,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1100,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 113  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[130]))(2,*((C_word*)lf[130]+1),t4);}

/* k1098 in k2914 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1100,2,t0,t1);}
t2=(C_truep(C_retrieve2(lf[14],"main#*windows-shell*"))?lf[229]:lf[230]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1106,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 117  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[48]+1)))(5,*((C_word*)lf[48]+1),t3,lf[232],((C_word*)t0)[3],lf[233]);}

/* k1104 in k1098 in k2914 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1106,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1111,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1111(t5,((C_word*)t0)[2],lf[231]);}

/* loop213 in k1104 in k1098 in k2914 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_fcall f_1111(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1111,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1124,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1135,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[150]))(2,*((C_word*)lf[150]+1),t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k1133 in loop213 in k1104 in k1098 in k2914 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1135,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1138,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[148]+1)))(4,*((C_word*)lf[148]+1),t2,((C_word*)t0)[2],t1);}

/* k1136 in k1133 in loop213 in k1104 in k1098 in k2914 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1138,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1141,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* write-char/port */
t3=C_retrieve(lf[147]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[5]);}

/* k1139 in k1136 in k1133 in loop213 in k1104 in k1098 in k2914 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1141,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1144,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1161,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1165,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 120  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[78]))(4,*((C_word*)lf[78]+1),t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1163 in k1139 in k1136 in k1133 in loop213 in k1104 in k1098 in k2914 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 120  setup-api#shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[182]))(3,*((C_word*)lf[182]+1),((C_word*)t0)[2],t1);}

/* k1159 in k1139 in k1136 in k1133 in loop213 in k1104 in k1098 in k2914 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[148]+1)))(4,*((C_word*)lf[148]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1142 in k1139 in k1136 in k1133 in loop213 in k1104 in k1098 in k2914 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1147,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=C_retrieve(lf[147]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[3]);}

/* k1145 in k1142 in k1139 in k1136 in k1133 in loop213 in k1104 in k1098 in k2914 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1147,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1150,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1157,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 120  setup-api#shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[182]))(3,*((C_word*)lf[182]+1),t3,((C_word*)t0)[2]);}

/* k1155 in k1145 in k1142 in k1139 in k1136 in k1133 in loop213 in k1104 in k1098 in k2914 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[148]+1)))(4,*((C_word*)lf[148]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1148 in k1145 in k1142 in k1139 in k1136 in k1133 in loop213 in k1104 in k1098 in k2914 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1150,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1153,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[146]))(3,*((C_word*)lf[146]+1),t2,((C_word*)t0)[2]);}

/* k1151 in k1148 in k1145 in k1142 in k1139 in k1136 in k1133 in loop213 in k1104 in k1098 in k2914 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 120  $system */
f_2546(((C_word*)t0)[2],t1);}

/* k1122 in loop213 in k1104 in k1098 in k2914 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1111(t3,((C_word*)t0)[2],t2);}

/* k2917 in k2914 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 482  exit */
((C_proc3)C_retrieve_symbol_proc(lf[124]))(3,*((C_word*)lf[124]+1),((C_word*)t0)[2],C_fix(0));}

/* k2885 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 474  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[48]+1)))(3,*((C_word*)lf[48]+1),((C_word*)t0)[2],t1);}

/* k2878 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 475  exit */
((C_proc3)C_retrieve_symbol_proc(lf[124]))(3,*((C_word*)lf[124]+1),((C_word*)t0)[2],C_fix(0));}

/* k2827 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=C_mutate(&lf[3] /* (set! main#*prefix* ...) */,t2);
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* chicken-install.scm: 468  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2587(t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* k2790 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2792,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2796,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* chicken-install.scm: 463  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[153]+1)))(3,*((C_word*)lf[153]+1),t2,t3);}

/* k2794 in k2790 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[12] /* (set! main#*default-transport* ...) */,t1);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* chicken-install.scm: 464  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2587(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k2757 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=C_mutate(&lf[11] /* (set! main#*default-location* ...) */,t2);
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* chicken-install.scm: 460  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2587(t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* k2721 in k2675 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 453  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2587(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k2629 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2631,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2641,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2645,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2647,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2662,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 431  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[48]+1)))(3,*((C_word*)lf[48]+1),t2,lf[205]);}}

/* k2660 in k2629 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 432  exit */
((C_proc3)C_retrieve_symbol_proc(lf[124]))(3,*((C_word*)lf[124]+1),((C_word*)t0)[2],C_fix(1));}

/* a2646 in k2629 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2647(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2647,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2655,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 427  pathname-file */
((C_proc3)C_retrieve_symbol_proc(lf[204]))(3,*((C_word*)lf[204]+1),t3,t2);}

/* k2653 in a2646 in k2629 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2655,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[202],lf[203]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,t1,t2));}

/* k2643 in k2629 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 425  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[45]+1)))(4,*((C_word*)lf[45]+1),((C_word*)t0)[2],t1,C_retrieve2(lf[28],"main#*eggs+dirs+vers*"));}

/* k2639 in k2629 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[28] /* (set! main#*eggs+dirs+vers* ...) */,t1);
t3=((C_word*)t0)[2];
f_2603(2,t3,t2);}

/* k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2603,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2606,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_2606(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2616,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[12],"main#*default-transport*"))){
t4=t3;
f_2616(2,t4,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 435  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t3,lf[201]);}}}

/* k2614 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve2(lf[11],"main#*default-location*"))){
t2=((C_word*)t0)[2];
f_2606(2,t2,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 437  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),((C_word*)t0)[2],lf[200]);}}

/* k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2606,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2613,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 438  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),t2,((C_word*)t0)[2]);}

/* k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2613,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2098,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 312  retrieve */
f_1717(t3,t1);}

/* k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2098,2,t0,t1);}
if(C_truep(C_retrieve2(lf[6],"main#*retrieve-only*"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2104,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2240,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 314  topological-sort */
((C_proc4)C_retrieve_symbol_proc(lf[198]))(4,*((C_word*)lf[198]+1),t3,C_retrieve2(lf[29],"main#*dependencies*"),*((C_word*)lf[199]+1));}}

/* k2238 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 314  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),((C_word*)t0)[2],t1);}

/* k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2104,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2107,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 315  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[48]+1)))(3,*((C_word*)lf[48]+1),t2,lf[197]);}

/* k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2107,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2110,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 316  pp */
((C_proc3)C_retrieve_symbol_proc(lf[196]))(3,*((C_word*)lf[196]+1),t2,((C_word*)t0)[2]);}

/* k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2110,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2117,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2232,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a2231 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2232(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2232,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assoc(t2,C_retrieve2(lf[28],"main#*eggs+dirs+vers*")));}

/* k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2117,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2119,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2119(t5,((C_word*)t0)[2],t1);}

/* loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_fcall f_2119(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2119,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2132,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
t6=(C_word)C_i_caddr(t3);
/* chicken-install.scm: 319  print */
((C_proc7)C_retrieve_proc(*((C_word*)lf[48]+1)))(7,*((C_word*)lf[48]+1),t4,lf[194],t5,C_make_character(58),t6,lf[195]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2130 in loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2132,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2135,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* chicken-install.scm: 320  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[48]+1)))(4,*((C_word*)lf[48]+1),t2,lf[193],t3);}

/* k2133 in k2130 in loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2135,2,t0,t1);}
t2=C_retrieve(lf[106]);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2139,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2150,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2159,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[155]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t7,t6,t8,t6);}

/* a2158 in k2133 in k2130 in loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2159,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2163,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2089,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 297  feature? */
((C_proc3)C_retrieve_symbol_proc(lf[191]))(3,*((C_word*)lf[191]+1),t3,lf[192]);}

/* k2087 in a2158 in k2133 in k2130 in loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2089,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_not(C_retrieve2(lf[4],"main#*host-extension*")):C_SCHEME_FALSE);
t3=(C_truep(t2)?lf[170]:lf[171]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2003,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[150]))(2,*((C_word*)lf[150]+1),t4);}

/* k2001 in k2087 in a2158 in k2133 in k2130 in loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2006,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[148]+1)))(4,*((C_word*)lf[148]+1),t2,lf[190],t1);}

/* k2004 in k2001 in k2087 in a2158 in k2133 in k2130 in loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2009,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[148]+1)))(4,*((C_word*)lf[148]+1),t2,t3,((C_word*)t0)[2]);}

/* k2007 in k2004 in k2001 in k2087 in a2158 in k2133 in k2130 in loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2009,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2012,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[148]+1)))(4,*((C_word*)lf[148]+1),t2,lf[189],((C_word*)t0)[2]);}

/* k2010 in k2007 in k2004 in k2001 in k2087 in a2158 in k2133 in k2130 in loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2012,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2015,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[3]);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[148]+1)))(4,*((C_word*)lf[148]+1),t2,t3,((C_word*)t0)[2]);}

/* k2013 in k2010 in k2007 in k2004 in k2001 in k2087 in a2158 in k2133 in k2130 in loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2015,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2018,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[148]+1)))(4,*((C_word*)lf[148]+1),t2,lf[188],((C_word*)t0)[2]);}

/* k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k2087 in a2158 in k2133 in k2130 in loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2021,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[146]))(3,*((C_word*)lf[146]+1),t2,((C_word*)t0)[2]);}

/* k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k2087 in a2158 in k2133 in k2130 in loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2021,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2075,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 303  setup-api#sudo-install */
((C_proc2)C_retrieve_symbol_proc(lf[187]))(2,*((C_word*)lf[187]+1),t2);}

/* k2073 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k2087 in a2158 in k2133 in k2130 in loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2075,2,t0,t1);}
t2=(C_truep(t1)?lf[172]:lf[173]);
t3=(C_truep(C_retrieve2(lf[1],"main#*keep*"))?lf[174]:lf[175]);
t4=(C_truep(C_retrieve2(lf[7],"main#*no-install*"))?lf[176]:lf[177]);
t5=(C_truep(C_retrieve2(lf[4],"main#*host-extension*"))?lf[178]:lf[179]);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2041,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
if(C_truep(C_retrieve2(lf[3],"main#*prefix*"))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2060,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[150]))(2,*((C_word*)lf[150]+1),t7);}
else{
t7=t6;
f_2041(2,t7,lf[186]);}}

/* k2058 in k2073 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k2087 in a2158 in k2133 in k2130 in loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2060,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2063,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[148]+1)))(4,*((C_word*)lf[148]+1),t2,lf[185],t1);}

/* k2061 in k2058 in k2073 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k2087 in a2158 in k2133 in k2130 in loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2063,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2066,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[148]+1)))(4,*((C_word*)lf[148]+1),t2,C_retrieve2(lf[3],"main#*prefix*"),((C_word*)t0)[2]);}

/* k2064 in k2061 in k2058 in k2073 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k2087 in a2158 in k2133 in k2130 in loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2066,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2069,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[148]+1)))(4,*((C_word*)lf[148]+1),t2,lf[184],((C_word*)t0)[2]);}

/* k2067 in k2064 in k2061 in k2058 in k2073 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k2087 in a2158 in k2133 in k2130 in loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[146]))(3,*((C_word*)lf[146]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2039 in k2073 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k2087 in a2158 in k2133 in k2130 in loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2045,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2049,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
t5=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 309  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[78]))(5,*((C_word*)lf[78]+1),t3,t4,t5,lf[183]);}

/* k2047 in k2039 in k2073 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k2087 in a2158 in k2133 in k2130 in loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 309  setup-api#shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[182]))(3,*((C_word*)lf[182]+1),((C_word*)t0)[2],t1);}

/* k2043 in k2039 in k2073 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k2087 in a2158 in k2133 in k2130 in loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 294  conc */
((C_proc14)C_retrieve_symbol_proc(lf[62]))(14,*((C_word*)lf[62]+1),((C_word*)t0)[9],C_retrieve2(lf[31],"main#*csi*"),lf[180],((C_word*)t0)[8],lf[181],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_make_character(32),t1);}

/* k2161 in a2158 in k2133 in k2130 in loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2163,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2166,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 323  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[48]+1)))(4,*((C_word*)lf[48]+1),t2,lf[169],t1);}

/* k2164 in k2161 in a2158 in k2133 in k2130 in loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2166,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2169,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 324  $system */
f_2546(t2,((C_word*)t0)[2]);}

/* k2167 in k2164 in k2161 in a2158 in k2133 in k2130 in loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2169,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2175,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[5],"main#*run-tests*"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2209,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 326  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[77]))(3,*((C_word*)lf[77]+1),t3,lf[168]);}
else{
t3=t2;
f_2175(2,t3,C_SCHEME_FALSE);}}

/* k2207 in k2167 in k2164 in k2161 in a2158 in k2133 in k2130 in loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2209,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2215,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 327  directory? */
((C_proc3)C_retrieve_symbol_proc(lf[166]))(3,*((C_word*)lf[166]+1),t2,lf[167]);}
else{
t2=((C_word*)t0)[2];
f_2175(2,t2,C_SCHEME_FALSE);}}

/* k2213 in k2207 in k2167 in k2164 in k2161 in a2158 in k2133 in k2130 in loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-install.scm: 328  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[77]))(3,*((C_word*)lf[77]+1),((C_word*)t0)[2],lf[165]);}
else{
t2=((C_word*)t0)[2];
f_2175(2,t2,C_SCHEME_FALSE);}}

/* k2173 in k2167 in k2164 in k2161 in a2158 in k2133 in k2130 in loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2175,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2178,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 329  current-directory */
((C_proc3)C_retrieve_symbol_proc(lf[106]))(3,*((C_word*)lf[106]+1),t2,lf[164]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2176 in k2173 in k2167 in k2164 in k2161 in a2158 in k2133 in k2130 in loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2178,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2181,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[150]))(2,*((C_word*)lf[150]+1),t2);}

/* k2179 in k2176 in k2173 in k2167 in k2164 in k2161 in a2158 in k2133 in k2130 in loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2181,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2184,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[148]+1)))(4,*((C_word*)lf[148]+1),t2,C_retrieve2(lf[31],"main#*csi*"),t1);}

/* k2182 in k2179 in k2176 in k2173 in k2167 in k2164 in k2161 in a2158 in k2133 in k2130 in loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2184,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2187,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[148]+1)))(4,*((C_word*)lf[148]+1),t2,lf[163],((C_word*)t0)[3]);}

/* k2185 in k2182 in k2179 in k2176 in k2173 in k2167 in k2164 in k2161 in a2158 in k2133 in k2130 in loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2187,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2190,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[148]+1)))(4,*((C_word*)lf[148]+1),t2,t3,((C_word*)t0)[3]);}

/* k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2167 in k2164 in k2161 in a2158 in k2133 in k2130 in loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2193,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[146]))(3,*((C_word*)lf[146]+1),t2,((C_word*)t0)[2]);}

/* k2191 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2167 in k2164 in k2161 in a2158 in k2133 in k2130 in loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2193,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2196,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 331  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[48]+1)))(4,*((C_word*)lf[48]+1),t2,lf[162],t1);}

/* k2194 in k2191 in k2188 in k2185 in k2182 in k2179 in k2176 in k2173 in k2167 in k2164 in k2161 in a2158 in k2133 in k2130 in loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 332  $system */
f_2546(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2148 in k2133 in k2130 in loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2119(t3,((C_word*)t0)[2],t2);}

/* swap523 in k2133 in k2130 in loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2139,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2143,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* g526527530 */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2141 in swap523 in k2133 in k2130 in loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2143,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2146,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g526527530 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k2144 in k2141 in swap523 in k2133 in k2130 in loop517 in k2115 in k2108 in k2105 in k2102 in k2096 in k2611 in k2604 in k2601 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2542 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 341  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[78]))(4,*((C_word*)lf[78]+1),((C_word*)t0)[2],t1,lf[161]);}

/* k2538 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 341  glob */
((C_proc3)C_retrieve_symbol_proc(lf[160]))(3,*((C_word*)lf[160]+1),((C_word*)t0)[2],t1);}

/* k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2264,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 342  setup-api#create-temporary-directory */
((C_proc2)C_retrieve_symbol_proc(lf[159]))(2,*((C_word*)lf[159]+1),t2);}

/* k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2264,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2267,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 343  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[78]))(4,*((C_word*)lf[78]+1),t2,t1,C_retrieve2(lf[17],"main#constant174"));}

/* k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2270,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 344  regexp */
((C_proc3)C_retrieve_symbol_proc(lf[157]))(3,*((C_word*)lf[157]+1),t2,lf[158]);}

/* k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2270,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2273,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 345  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[48]+1)))(3,*((C_word*)lf[48]+1),t2,lf[156]);}

/* k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2273,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2276,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2416,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2421,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2533,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t10=*((C_word*)lf[155]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t6,t7,t8,t9);}

/* a2532 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2533,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[145]));
t3=C_mutate((C_word*)lf[145]+1 /* (set! warnings-enabled ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a2420 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2421,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2427,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2427(t5,t1,((C_word*)t0)[2]);}

/* loop596 in a2420 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_fcall f_2427(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2427,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2440,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 349  string-match */
((C_proc4)C_retrieve_symbol_proc(lf[154]))(4,*((C_word*)lf[154]+1),t4,((C_word*)t0)[2],t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2438 in loop596 in a2420 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2443,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2453,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2455,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[108]+1)))(3,*((C_word*)lf[108]+1),t3,t4);}

/* a2454 in k2438 in loop596 in a2420 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2455(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2455,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2461,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2493,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),t1,t3,t4);}

/* a2492 in a2454 in k2438 in loop596 in a2420 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2493,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2499,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2521,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a2520 in a2492 in a2454 in k2438 in loop596 in a2420 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2521(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2521r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2521r(t0,t1,t2);}}

static void C_ccall f_2521r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2527,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k603606 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2526 in a2520 in a2492 in a2454 in k2438 in loop596 in a2420 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2527,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a2498 in a2492 in a2454 in k2438 in loop596 in a2420 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2499,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2515,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm: 354  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[153]+1)))(3,*((C_word*)lf[153]+1),t2,t3);}

/* k2513 in a2498 in a2492 in a2454 in k2438 in loop596 in a2420 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2515,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[151],t2);
/* chicken-install.scm: 354  eval */
((C_proc3)C_retrieve_symbol_proc(lf[152]))(3,*((C_word*)lf[152]+1),((C_word*)t0)[2],t3);}

/* a2460 in a2454 in k2438 in loop596 in a2420 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2461(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2461,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2467,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* k603606 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2466 in a2460 in a2454 in k2438 in loop596 in a2420 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2467,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2475,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 352  current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[127]))(2,*((C_word*)lf[127]+1),t2);}

/* k2473 in a2466 in a2460 in a2454 in k2438 in loop596 in a2420 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2475,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2479,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[150]))(2,*((C_word*)lf[150]+1),t2);}

/* k2477 in k2473 in a2466 in a2460 in a2454 in k2438 in loop596 in a2420 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2479,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2482,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[148]+1)))(4,*((C_word*)lf[148]+1),t2,lf[149],t1);}

/* k2480 in k2477 in k2473 in a2466 in a2460 in a2454 in k2438 in loop596 in a2420 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2482,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2485,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[148]+1)))(4,*((C_word*)lf[148]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2483 in k2480 in k2477 in k2473 in a2466 in a2460 in a2454 in k2438 in loop596 in a2420 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2485,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2488,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t3=C_retrieve(lf[147]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(39),((C_word*)t0)[2]);}

/* k2486 in k2483 in k2480 in k2477 in k2473 in a2466 in a2460 in a2454 in k2438 in loop596 in a2420 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2488,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2491,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[146]))(3,*((C_word*)lf[146]+1),t2,((C_word*)t0)[2]);}

/* k2489 in k2486 in k2483 in k2480 in k2477 in k2473 in a2466 in a2460 in a2454 in k2438 in loop596 in a2420 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 351  print-error-message */
((C_proc5)C_retrieve_symbol_proc(lf[91]))(5,*((C_word*)lf[91]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2451 in k2438 in loop596 in a2420 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k2441 in k2438 in loop596 in a2420 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2427(t3,((C_word*)t0)[2],t2);}

/* a2415 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2416,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[145]));
t3=C_mutate((C_word*)lf[145]+1 /* (set! warnings-enabled ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k2274 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2279,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 356  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[48]+1)))(3,*((C_word*)lf[48]+1),t2,lf[144]);}

/* k2277 in k2274 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2279,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2282,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2337,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2361,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm: 359  append-map */
((C_proc4)C_retrieve_symbol_proc(lf[142]))(4,*((C_word*)lf[142]+1),t3,t4,C_retrieve(lf[143]));}

/* a2360 in k2277 in k2274 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2361(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2361,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2368,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 362  ##sys#module-name */
((C_proc3)C_retrieve_symbol_proc(lf[141]))(3,*((C_word*)lf[141]+1),t4,t3);}

/* k2366 in a2360 in k2277 in k2274 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2368,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2371,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 363  print* */
((C_proc4)C_retrieve_proc(*((C_word*)lf[139]+1)))(4,*((C_word*)lf[139]+1),t2,lf[140],t1);}

/* k2369 in k2366 in a2360 in k2277 in k2274 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2371,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2376,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2382,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2381 in k2369 in k2366 in a2360 in k2277 in k2274 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2382(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2382,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2390,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2406,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t7=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t4);}

/* a2405 in a2381 in k2369 in k2366 in a2360 in k2277 in k2274 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2406(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2406,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,t3,lf[138],((C_word*)t0)[2]));}

/* k2388 in a2381 in k2369 in k2366 in a2360 in k2277 in k2274 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2390,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2394,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2396,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a2395 in k2388 in a2381 in k2369 in k2366 in a2360 in k2277 in k2274 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2396(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2396,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,t3,lf[137],((C_word*)t0)[2]));}

/* k2392 in k2388 in a2381 in k2369 in k2366 in a2360 in k2277 in k2274 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 365  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[45]+1)))(4,*((C_word*)lf[45]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2375 in k2369 in k2366 in a2360 in k2277 in k2274 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2376,2,t0,t1);}
/* chicken-install.scm: 364  ##sys#module-exports */
((C_proc3)C_retrieve_symbol_proc(lf[136]))(3,*((C_word*)lf[136]+1),t1,((C_word*)t0)[2]);}

/* k2335 in k2277 in k2274 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2337,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2339,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm: 358  sort */
((C_proc4)C_retrieve_symbol_proc(lf[135]))(4,*((C_word*)lf[135]+1),((C_word*)t0)[2],t1,t2);}

/* a2338 in k2335 in k2277 in k2274 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2339(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2339,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2347,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(t2);
/* chicken-install.scm: 370  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[134]+1)))(3,*((C_word*)lf[134]+1),t4,t5);}

/* k2345 in a2338 in k2335 in k2277 in k2274 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2351,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 370  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[134]+1)))(3,*((C_word*)lf[134]+1),t2,t3);}

/* k2349 in k2345 in a2338 in k2335 in k2277 in k2274 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 370  string<? */
((C_proc4)C_retrieve_proc(*((C_word*)lf[133]+1)))(4,*((C_word*)lf[133]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2280 in k2277 in k2274 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2282,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2285,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 371  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[128]+1)))(2,*((C_word*)lf[128]+1),t2);}

/* k2283 in k2280 in k2277 in k2274 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2288,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2304,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 372  with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[132]))(4,*((C_word*)lf[132]+1),t2,((C_word*)t0)[3],t3);}

/* a2303 in k2283 in k2280 in k2277 in k2274 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2304,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2310,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2310(t5,t1,((C_word*)t0)[2]);}

/* loop651 in a2303 in k2283 in k2280 in k2277 in k2274 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_fcall f_2310(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2310,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2323,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 374  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[131]+1)))(3,*((C_word*)lf[131]+1),t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2321 in loop651 in a2303 in k2283 in k2280 in k2277 in k2274 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2323,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2326,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 374  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[128]+1)))(2,*((C_word*)lf[128]+1),t2);}

/* k2324 in k2321 in loop651 in a2303 in k2283 in k2280 in k2277 in k2274 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2310(t3,((C_word*)t0)[2],t2);}

/* k2286 in k2283 in k2280 in k2277 in k2274 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2291,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2298,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2302,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 375  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[130]))(2,*((C_word*)lf[130]+1),t4);}

/* k2300 in k2286 in k2283 in k2280 in k2277 in k2274 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 375  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[78]))(4,*((C_word*)lf[78]+1),((C_word*)t0)[2],t1,C_retrieve2(lf[17],"main#constant174"));}

/* k2296 in k2286 in k2283 in k2280 in k2277 in k2274 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 375  setup-api#copy-file */
((C_proc4)C_retrieve_symbol_proc(lf[129]))(4,*((C_word*)lf[129]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2289 in k2286 in k2283 in k2280 in k2277 in k2274 in k2271 in k2268 in k2265 in k2262 in k2259 in loop in k2580 in k3354 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 376  setup-api#remove-directory */
((C_proc3)C_retrieve_symbol_proc(lf[116]))(3,*((C_word*)lf[116]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3347 in a3344 in a3338 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 545  cleanup */
f_2242(((C_word*)t0)[2]);}

/* a3309 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3310(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3310,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3316,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k852855 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3315 in a3309 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3316,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3320,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3337,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 540  current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[127]))(2,*((C_word*)lf[127]+1),t3);}

/* k3335 in a3315 in a3309 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 540  newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[128]+1)))(3,*((C_word*)lf[128]+1),((C_word*)t0)[2],t1);}

/* k3318 in a3315 in a3309 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3320,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3323,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3333,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 541  current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[127]))(2,*((C_word*)lf[127]+1),t3);}

/* k3331 in k3318 in a3315 in a3309 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 541  print-error-message */
((C_proc4)C_retrieve_symbol_proc(lf[91]))(4,*((C_word*)lf[91]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3321 in k3318 in a3315 in a3309 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3323,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3326,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 542  cleanup */
f_2242(t2);}

/* k3324 in k3321 in k3318 in a3315 in a3309 in a3303 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 543  exit */
((C_proc3)C_retrieve_symbol_proc(lf[124]))(3,*((C_word*)lf[124]+1),((C_word*)t0)[2],C_fix(1));}

/* k3300 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k3291 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3293,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3296,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3299,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[126]))(2,*((C_word*)lf[126]+1),t3);}

/* k3297 in k3291 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k3294 in k3291 in k3288 in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_3296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* main#usage in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_fcall f_2568(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2568,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2572,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 387  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[48]+1)))(3,*((C_word*)lf[48]+1),t3,lf[125]);}

/* k2570 in main#usage in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 409  exit */
((C_proc3)C_retrieve_symbol_proc(lf[124]))(3,*((C_word*)lf[124]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* main#$system in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_fcall f_2546(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2546,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2550,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2563,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[14],"main#*windows-shell*"))){
/* chicken-install.scm: 381  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[37]+1)))(5,*((C_word*)lf[37]+1),t4,lf[121],t2,lf[122]);}
else{
t5=t4;
f_2563(2,t5,t2);}}

/* k2561 in main#$system in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 379  system */
((C_proc3)C_retrieve_symbol_proc(lf[120]))(3,*((C_word*)lf[120]+1),((C_word*)t0)[2],t1);}

/* k2548 in main#$system in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 384  error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[36]+1)))(5,*((C_word*)lf[36]+1),((C_word*)t0)[3],lf[119],t1,((C_word*)t0)[2]);}}

/* main#cleanup in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_fcall f_2242(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2242,NULL,1,t1);}
if(C_truep(C_retrieve2(lf[1],"main#*keep*"))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2249,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 337  setup-download#temporary-directory */
((C_proc2)C_retrieve_symbol_proc(lf[117]))(2,*((C_word*)lf[117]+1),t2);}}

/* k2247 in main#cleanup in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_2249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-install.scm: 338  setup-api#remove-directory */
((C_proc3)C_retrieve_symbol_proc(lf[116]))(3,*((C_word*)lf[116]+1),((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_fcall f_1717(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1717,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1721,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 241  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[48]+1)))(3,*((C_word*)lf[48]+1),t3,lf[114]);}

/* k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1721,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1724,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1911,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_1911(t6,t2,((C_word*)t0)[2]);}

/* loop389 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_fcall f_1911(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1911,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_i_assoc(t3,C_retrieve2(lf[28],"main#*eggs+dirs+vers*"));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1927,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1942,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 247  delete */
((C_proc5)C_retrieve_symbol_proc(lf[80]))(5,*((C_word*)lf[80]+1),t6,t4,C_retrieve2(lf[28],"main#*eggs+dirs+vers*"),*((C_word*)lf[81]+1));}
else{
t6=(C_word)C_i_pairp(t3);
t7=(C_truep(t6)?(C_word)C_i_car(t3):t3);
t8=(C_word)C_i_pairp(t3);
t9=(C_truep(t8)?(C_word)C_i_cdr(t3):C_SCHEME_FALSE);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1953,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1959,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t5,t10,t11);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a1958 in loop389 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1959(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1959,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1963,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t5=t4;
f_1963(2,t5,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 252  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t4,lf[113]);}}

/* k1961 in a1958 in loop389 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1963,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1966,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 253  print */
((C_proc6)C_retrieve_proc(*((C_word*)lf[48]+1)))(6,*((C_word*)lf[48]+1),t2,lf[111],((C_word*)t0)[5],lf[112],((C_word*)t0)[4]);}

/* k1964 in k1961 in a1958 in loop389 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1966,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve2(lf[28],"main#*eggs+dirs+vers*"));
t4=C_mutate(&lf[28] /* (set! main#*eggs+dirs+vers* ...) */,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* a1952 in loop389 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1953,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1592,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(C_retrieve2(lf[11],"main#*default-location*"))?C_retrieve2(lf[12],"main#*default-transport*"):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[11],"main#*default-location*"),C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[83],t4);
t6=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[12],"main#*default-transport*"),C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[84],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t5,t8);
t10=t2;
f_1592(t10,(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST));}
else{
t4=t2;
f_1592(t4,C_retrieve2(lf[10],"main#*default-sources*"));}}

/* k1590 in a1952 in loop389 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_fcall f_1592(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1592,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1594,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1594(t5,((C_word*)t0)[2],t1);}

/* trying-sources in k1590 in a1952 in loop389 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_fcall f_1594(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1594,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* chicken-install.scm: 211  values */
C_values(4,0,t1,C_SCHEME_FALSE,lf[82]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_assq(lf[83],t3);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1658,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t4)){
t6=t5;
f_1658(2,t6,t4);}
else{
/* chicken-install.scm: 214  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[36]+1)))(4,*((C_word*)lf[36]+1),t5,lf[110],t3);}}}

/* k1656 in trying-sources in k1590 in a1952 in loop389 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1658,2,t0,t1);}
t2=(C_word)C_i_cadr(t1);
t3=(C_word)C_i_assq(lf[84],((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1648,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t5=t4;
f_1648(2,t5,t3);}
else{
/* chicken-install.scm: 216  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[36]+1)))(4,*((C_word*)lf[36]+1),t4,lf[109],((C_word*)t0)[7]);}}

/* k1646 in k1656 in trying-sources in k1590 in a1952 in loop389 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1648,2,t0,t1);}
t2=(C_word)C_i_cadr(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1618,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1624,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a1623 in k1646 in k1656 in trying-sources in k1590 in a1952 in loop389 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1624(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1624,4,t0,t1,t2,t3);}
if(C_truep(t2)){
/* chicken-install.scm: 219  values */
C_values(4,0,t1,t2,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1079,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 105  delete */
((C_proc5)C_retrieve_symbol_proc(lf[80]))(5,*((C_word*)lf[80]+1),t4,((C_word*)t0)[2],C_retrieve2(lf[10],"main#*default-sources*"),*((C_word*)lf[81]+1));}}

/* k1077 in a1623 in k1646 in k1656 in trying-sources in k1590 in a1952 in loop389 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[10] /* (set! main#*default-sources* ...) */,t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-install.scm: 222  trying-sources */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1594(t4,((C_word*)t0)[2],t3);}

/* a1617 in k1646 in k1656 in trying-sources in k1590 in a1952 in loop389 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1618,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1458,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1460,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[108]+1)))(3,*((C_word*)lf[108]+1),t2,t3);}

/* a1459 in a1617 in k1646 in k1656 in trying-sources in k1590 in a1952 in loop389 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1460(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1460,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1466,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1553,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),t1,t3,t4);}

/* a1552 in a1459 in a1617 in k1646 in k1656 in trying-sources in k1590 in a1952 in loop389 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1553,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1559,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1572,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1571 in a1552 in a1459 in a1617 in k1646 in k1656 in trying-sources in k1590 in a1952 in loop389 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1572(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1572r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1572r(t0,t1,t2);}}

static void C_ccall f_1572r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1578,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k314317 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1577 in a1571 in a1552 in a1459 in a1617 in k1646 in k1656 in trying-sources in k1590 in a1952 in loop389 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1578,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1558 in a1552 in a1459 in a1617 in k1646 in k1656 in trying-sources in k1590 in a1952 in loop389 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1567,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve2(lf[6],"main#*retrieve-only*"))){
/* chicken-install.scm: 189  current-directory */
((C_proc2)C_retrieve_symbol_proc(lf[106]))(2,*((C_word*)lf[106]+1),t2);}
else{
t3=t2;
f_1567(2,t3,C_SCHEME_FALSE);}}

/* k1565 in a1558 in a1552 in a1459 in a1617 in k1646 in k1656 in trying-sources in k1590 in a1952 in loop389 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 186  setup-download#retrieve-extension */
((C_proc19)C_retrieve_symbol_proc(lf[98]))(19,*((C_word*)lf[98]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[99],((C_word*)t0)[2],lf[100],t1,lf[101],C_retrieve2(lf[5],"main#*run-tests*"),lf[102],C_retrieve2(lf[8],"main#*username*"),lf[103],C_retrieve2(lf[9],"main#*password*"),lf[104],C_retrieve2(lf[15],"main#*proxy-host*"),lf[105],C_retrieve2(lf[16],"main#*proxy-port*"));}

/* a1465 in a1459 in a1617 in k1646 in k1656 in trying-sources in k1590 in a1952 in loop389 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1466(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1466,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1472,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k314317 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1471 in a1465 in a1459 in a1617 in k1646 in k1656 in trying-sources in k1590 in a1952 in loop389 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1472,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[2],lf[85]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[2],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1482,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=(C_word)C_i_memv(lf[94],t3);
t6=t4;
f_1482(t6,(C_truep(t5)?(C_word)C_i_memv(lf[97],t3):C_SCHEME_FALSE));}
else{
t5=t4;
f_1482(t5,C_SCHEME_FALSE);}}

/* k1480 in a1471 in a1465 in a1459 in a1617 in k1646 in k1656 in trying-sources in k1590 in a1952 in loop389 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_fcall f_1482(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1482,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1485,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 196  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[48]+1)))(3,*((C_word*)lf[48]+1),t2,lf[87]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1494,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_memv(lf[94],((C_word*)t0)[2]);
t4=t2;
f_1494(t4,(C_truep(t3)?(C_word)C_i_memv(lf[96],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
t3=t2;
f_1494(t3,C_SCHEME_FALSE);}}}

/* k1492 in k1480 in a1471 in a1465 in a1459 in a1617 in k1646 in k1656 in trying-sources in k1590 in a1952 in loop389 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_fcall f_1494(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1494,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1497,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 199  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[48]+1)))(3,*((C_word*)lf[48]+1),t2,lf[89]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1506,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_memv(lf[94],((C_word*)t0)[2]);
t4=t2;
f_1506(t4,(C_truep(t3)?(C_word)C_i_memv(lf[95],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
t3=t2;
f_1506(t3,C_SCHEME_FALSE);}}}

/* k1504 in k1492 in k1480 in a1471 in a1465 in a1459 in a1617 in k1646 in k1656 in trying-sources in k1590 in a1952 in loop389 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_fcall f_1506(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1506,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1509,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 202  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[48]+1)))(3,*((C_word*)lf[48]+1),t3,lf[92]);}
else{
t2=((C_word*)t0)[3];
/* chicken-install.scm: 206  abort */
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),((C_word*)t0)[2],t2);}}

/* k1507 in k1504 in k1492 in k1480 in a1471 in a1465 in a1459 in a1617 in k1646 in k1656 in trying-sources in k1590 in a1952 in loop389 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1509,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1512,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 203  print-error-message */
((C_proc3)C_retrieve_symbol_proc(lf[91]))(3,*((C_word*)lf[91]+1),t2,((C_word*)t0)[2]);}

/* k1510 in k1507 in k1504 in k1492 in k1480 in a1471 in a1465 in a1459 in a1617 in k1646 in k1656 in trying-sources in k1590 in a1952 in loop389 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 204  values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_FALSE,lf[90]);}

/* k1495 in k1492 in k1480 in a1471 in a1465 in a1459 in a1617 in k1646 in k1656 in trying-sources in k1590 in a1952 in loop389 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 200  values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_FALSE,lf[88]);}

/* k1483 in k1480 in a1471 in a1465 in a1459 in a1617 in k1646 in k1656 in trying-sources in k1590 in a1952 in loop389 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 197  values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_FALSE,lf[86]);}

/* k1456 in a1617 in k1646 in k1656 in trying-sources in k1590 in a1952 in loop389 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1940 in loop389 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1942,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=C_mutate(&lf[28] /* (set! main#*eggs+dirs+vers* ...) */,t2);
t4=((C_word*)t0)[2];
f_1927(2,t4,t3);}

/* k1925 in loop389 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1911(t3,((C_word*)t0)[2],t2);}

/* k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1724,2,t0,t1);}
if(C_truep(C_retrieve2(lf[6],"main#*retrieve-only*"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1732,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_1732(t5,((C_word*)t0)[2],C_retrieve2(lf[28],"main#*eggs+dirs+vers*"));}}

/* loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_fcall f_1732(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1732,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1745,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_member(t5,C_retrieve2(lf[30],"main#*checked*")))){
t6=t4;
f_1745(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_word)C_i_car(t3);
t7=(C_word)C_a_i_cons(&a,2,t6,C_retrieve2(lf[30],"main#*checked*"));
t8=C_mutate(&lf[30] /* (set! main#*checked* ...) */,t7);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1762,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_i_cadr(t3);
t11=(C_word)C_i_car(t3);
/* chicken-install.scm: 261  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[78]))(5,*((C_word*)lf[78]+1),t9,t10,t11,lf[79]);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1762,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1768,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 262  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[77]))(3,*((C_word*)lf[77]+1),t2,t1);}

/* k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1768,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1771,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 263  with-input-from-file */
((C_proc4)C_retrieve_symbol_proc(lf[72]))(4,*((C_word*)lf[72]+1),t2,((C_word*)t0)[2],*((C_word*)lf[73]+1));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1889,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* chicken-install.scm: 288  string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[37]+1)))(6,*((C_word*)lf[37]+1),t2,lf[74],t3,lf[75],lf[76]);}}

/* k1887 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 287  warning */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),((C_word*)t0)[2],t1);}

/* k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1771,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1774,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* chicken-install.scm: 264  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[48]+1)))(5,*((C_word*)lf[48]+1),t2,lf[70],t3,lf[71]);}

/* k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1774,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1779,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1785,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a1784 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1785,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(((C_word*)t0)[2]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1878,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 268  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[45]+1)))(4,*((C_word*)lf[45]+1),t5,t2,t3);}

/* k1876 in a1784 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1878,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve2(lf[29],"main#*dependencies*"));
t4=C_mutate(&lf[29] /* (set! main#*dependencies* ...) */,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1793,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1859,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1866,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 271  string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[52]))(4,*((C_word*)lf[52]+1),t7,((C_word*)t0)[2],lf[69]);}
else{
t6=t5;
f_1793(2,t6,C_SCHEME_UNDEFINED);}}

/* k1864 in k1876 in a1784 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 271  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[48]+1)))(4,*((C_word*)lf[48]+1),((C_word*)t0)[2],lf[68],t1);}

/* k1857 in k1876 in a1784 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 272  retrieve */
f_1717(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1791 in k1876 in a1784 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1793,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1799,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=C_retrieve2(lf[2],"main#*force*");
if(C_truep(t3)){
t4=t2;
f_1799(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1853,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[3];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1671,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_car(((C_word*)t0)[2]);
t8=(C_word)C_a_i_list(&a,3,lf[58],t7,lf[59]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1679,a[2]=t8,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1681,tmp=(C_word)a,a+=2,tmp);
/* map */
t11=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,t5);}}
else{
t3=t2;
f_1799(2,t3,C_SCHEME_FALSE);}}

/* a1680 in k1791 in k1876 in a1784 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1681(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1681,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1707,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t2);
/* chicken-install.scm: 234  extension-information */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),t4,t5);}

/* k1705 in a1680 in k1791 in k1876 in a1784 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_assq(lf[22],t1);
t3=(C_truep(t2)?(C_word)C_i_cadr(t2):lf[61]);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-install.scm: 232  conc */
((C_proc10)C_retrieve_symbol_proc(lf[62]))(10,*((C_word*)lf[62]+1),((C_word*)t0)[3],lf[63],((C_word*)t0)[2],lf[64],t3,lf[65],t4,lf[66],C_make_character(10));}

/* k1677 in k1791 in k1876 in a1784 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 226  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[45]+1)))(5,*((C_word*)lf[45]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[60]);}

/* k1669 in k1791 in k1876 in a1784 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 225  string-concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[57]))(3,*((C_word*)lf[57]+1),((C_word*)t0)[2],t1);}

/* k1851 in k1791 in k1876 in a1784 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 275  setup-api#yes-or-no? */
((C_proc4)C_retrieve_symbol_proc(lf[55]))(4,*((C_word*)lf[55]+1),((C_word*)t0)[2],t1,lf[56]);}

/* k1797 in k1791 in k1876 in a1784 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1799,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1802,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 278  unzip1 */
((C_proc3)C_retrieve_symbol_proc(lf[54]))(3,*((C_word*)lf[54]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1800 in k1797 in k1791 in k1876 in a1784 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1802,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1805,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1840,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 279  string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[52]))(4,*((C_word*)lf[52]+1),t3,t1,lf[53]);}

/* k1838 in k1800 in k1797 in k1791 in k1876 in a1784 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 279  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[48]+1)))(4,*((C_word*)lf[48]+1),((C_word*)t0)[2],lf[51],t1);}

/* k1803 in k1800 in k1797 in k1791 in k1876 in a1784 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1805,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1808,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1813,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_1813(t6,t2,((C_word*)t0)[2]);}

/* loop469 in k1803 in k1800 in k1797 in k1791 in k1876 in a1784 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_fcall f_1813(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1813,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1826,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 282  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[48]+1)))(5,*((C_word*)lf[48]+1),t4,lf[49],t3,lf[50]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k1824 in loop469 in k1803 in k1800 in k1797 in k1791 in k1876 in a1784 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1826,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1829,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 283  setup-api#remove-extension */
((C_proc3)C_retrieve_symbol_proc(lf[47]))(3,*((C_word*)lf[47]+1),t2,((C_word*)t0)[2]);}

/* k1827 in k1824 in loop469 in k1803 in k1800 in k1797 in k1791 in k1876 in a1784 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1813(t3,((C_word*)t0)[2],t2);}

/* k1806 in k1803 in k1800 in k1797 in k1791 in k1876 in a1784 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 285  retrieve */
f_1717(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1778 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1779,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1239,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_assq(lf[43],t2);
t5=(C_truep(t4)?(C_word)C_i_cdr(t4):C_SCHEME_FALSE);
t6=(C_truep(t5)?t5:C_SCHEME_END_OF_LIST);
t7=(C_word)C_i_assq(lf[44],t2);
t8=(C_truep(t7)?(C_word)C_i_cdr(t7):C_SCHEME_FALSE);
t9=(C_truep(t8)?t8:C_SCHEME_END_OF_LIST);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1230,a[2]=t9,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve2(lf[5],"main#*run-tests*"))){
t11=(C_word)C_i_assq(lf[46],t2);
t12=(C_truep(t11)?(C_word)C_i_cdr(t11):C_SCHEME_FALSE);
t13=t10;
f_1230(t13,(C_truep(t12)?t12:C_SCHEME_END_OF_LIST));}
else{
t11=t10;
f_1230(t11,C_SCHEME_END_OF_LIST);}}

/* k1228 in a1778 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_fcall f_1230(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 137  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[45]+1)))(5,*((C_word*)lf[45]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1237 in a1778 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1239,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1244,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_1244(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* loop in k1237 in a1778 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_fcall f_1244(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1244,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1258,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 146  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),t5,t3);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_symbolp(t5);
t8=(C_truep(t7)?t7:(C_word)C_i_stringp(t5));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1284,a[2]=t4,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1287,a[2]=t5,a[3]=t3,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 151  ext-version */
f_1167(t10,t5);}
else{
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1300,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t6,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_listp(t5))){
t10=(C_word)C_i_length(t5);
if(C_truep((C_word)C_i_nequalp(C_fix(2),t10))){
t11=(C_word)C_i_car(t5);
t12=(C_word)C_i_stringp(t11);
if(C_truep(t12)){
t13=t9;
f_1300(t13,t12);}
else{
t13=(C_word)C_i_car(t5);
t14=t9;
f_1300(t14,(C_word)C_i_symbolp(t13));}}
else{
t11=t9;
f_1300(t11,C_SCHEME_FALSE);}}
else{
t10=t9;
f_1300(t10,C_SCHEME_FALSE);}}}}

/* k1298 in loop in k1237 in a1778 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_fcall f_1300(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1300,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1303,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 157  ext-version */
f_1167(t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1406,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 174  warning */
((C_proc4)C_retrieve_symbol_proc(lf[41]))(4,*((C_word*)lf[41]+1),t2,lf[42],((C_word*)t0)[2]);}}

/* k1404 in k1298 in loop in k1237 in a1778 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 177  loop */
t2=((C_word*)((C_word*)t0)[6])[1];
f_1244(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1301 in k1298 in loop in k1237 in a1778 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1303,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1391,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1395,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm: 160  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),t4,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1320,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 159  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),t3,t4);}}

/* k1318 in k1301 in k1298 in loop in k1237 in a1778 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1320,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* chicken-install.scm: 159  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1244(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k1393 in k1301 in k1298 in loop in k1237 in a1778 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 160  setup-api#version>=? */
((C_proc4)C_retrieve_symbol_proc(lf[40]))(4,*((C_word*)lf[40]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1389 in k1301 in k1298 in loop in k1237 in a1778 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1391,2,t0,t1);}
if(C_truep(t1)){
/* chicken-install.scm: 172  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_1244(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1333,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1380,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 161  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),t3,t4);}}

/* k1378 in k1389 in k1301 in k1298 in loop in k1237 in a1778 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1380,2,t0,t1);}
t2=(C_word)C_i_string_equal_p(lf[35],t1);
t3=(C_truep(t2)?(C_word)C_i_not(C_retrieve2(lf[2],"main#*force*")):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1366,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm: 164  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[37]+1)))(5,*((C_word*)lf[37]+1),t4,lf[38],t5,lf[39]);}
else{
t4=((C_word*)t0)[3];
f_1333(2,t4,C_SCHEME_UNDEFINED);}}

/* k1364 in k1378 in k1389 in k1301 in k1298 in loop in k1237 in a1778 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 163  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),((C_word*)t0)[2],t1);}

/* k1331 in k1389 in k1301 in k1298 in loop in k1237 in a1778 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1340,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1344,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 170  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),t3,t4);}

/* k1342 in k1331 in k1389 in k1301 in k1298 in loop in k1237 in a1778 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1348,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm: 170  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),t2,t3);}

/* k1346 in k1342 in k1331 in k1389 in k1301 in k1298 in loop in k1237 in a1778 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 169  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[34]))(5,*((C_word*)lf[34]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1338 in k1331 in k1389 in k1301 in k1298 in loop in k1237 in a1778 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 168  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_1244(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1285 in loop in k1237 in a1778 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1287,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_1284(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1294,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 153  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),t2,((C_word*)t0)[2]);}}

/* k1292 in k1285 in loop in k1237 in a1778 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1294,2,t0,t1);}
t2=((C_word*)t0)[3];
f_1284(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k1282 in loop in k1237 in a1778 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_fcall f_1284(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 150  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_1244(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1256 in loop in k1237 in a1778 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1258,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1262,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 146  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),t2,((C_word*)t0)[2]);}

/* k1260 in k1256 in loop in k1237 in a1778 in k1772 in k1769 in k1766 in k1760 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 146  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1743 in loop428 in k1722 in k1719 in main#retrieve in k1447 in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1732(t3,((C_word*)t0)[2],t2);}

/* main#ext-version in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_fcall f_1167(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1167,NULL,2,t1,t2);}
t3=(C_word)C_eqp(t2,lf[20]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1177,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_1177(t5,t3);}
else{
t5=(C_word)C_i_equalp(t2,lf[26]);
if(C_truep(t5)){
t6=t4;
f_1177(t6,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1212,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 126  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),t6,t2);}}}

/* k1210 in main#ext-version in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1177(t2,(C_word)C_i_member(t1,C_retrieve(lf[27])));}

/* k1175 in main#ext-version in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_fcall f_1177(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1177,NULL,2,t0,t1);}
if(C_truep(t1)){
/* chicken-install.scm: 127  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[21]))(2,*((C_word*)lf[21]+1),((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1183,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 128  extension-information */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),t2,((C_word*)t0)[2]);}}

/* k1181 in k1175 in main#ext-version in k990 in k987 in k984 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 */
static void C_ccall f_1183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[22],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cadr(t2);
/* chicken-install.scm: 132  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),((C_word*)t0)[2],t3);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[24]);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[294] = {
{"toplevel:chicken_install_scm",(void*)C_toplevel},
{"f_930:chicken_install_scm",(void*)f_930},
{"f_933:chicken_install_scm",(void*)f_933},
{"f_936:chicken_install_scm",(void*)f_936},
{"f_939:chicken_install_scm",(void*)f_939},
{"f_942:chicken_install_scm",(void*)f_942},
{"f_945:chicken_install_scm",(void*)f_945},
{"f_948:chicken_install_scm",(void*)f_948},
{"f_951:chicken_install_scm",(void*)f_951},
{"f_954:chicken_install_scm",(void*)f_954},
{"f_957:chicken_install_scm",(void*)f_957},
{"f_960:chicken_install_scm",(void*)f_960},
{"f_963:chicken_install_scm",(void*)f_963},
{"f_966:chicken_install_scm",(void*)f_966},
{"f_969:chicken_install_scm",(void*)f_969},
{"f_972:chicken_install_scm",(void*)f_972},
{"f_975:chicken_install_scm",(void*)f_975},
{"f_978:chicken_install_scm",(void*)f_978},
{"f_981:chicken_install_scm",(void*)f_981},
{"f_986:chicken_install_scm",(void*)f_986},
{"f_989:chicken_install_scm",(void*)f_989},
{"f_992:chicken_install_scm",(void*)f_992},
{"f_3376:chicken_install_scm",(void*)f_3376},
{"f_3372:chicken_install_scm",(void*)f_3372},
{"f_1449:chicken_install_scm",(void*)f_1449},
{"f_3290:chicken_install_scm",(void*)f_3290},
{"f_3304:chicken_install_scm",(void*)f_3304},
{"f_3339:chicken_install_scm",(void*)f_3339},
{"f_3358:chicken_install_scm",(void*)f_3358},
{"f_3364:chicken_install_scm",(void*)f_3364},
{"f_3345:chicken_install_scm",(void*)f_3345},
{"f_3356:chicken_install_scm",(void*)f_3356},
{"f_1036:chicken_install_scm",(void*)f_1036},
{"f_1015:chicken_install_scm",(void*)f_1015},
{"f_1032:chicken_install_scm",(void*)f_1032},
{"f_1025:chicken_install_scm",(void*)f_1025},
{"f_2582:chicken_install_scm",(void*)f_2582},
{"f_2587:chicken_install_scm",(void*)f_2587},
{"f_2677:chicken_install_scm",(void*)f_2677},
{"f_3086:chicken_install_scm",(void*)f_3086},
{"f_3231:chicken_install_scm",(void*)f_3231},
{"f_3194:chicken_install_scm",(void*)f_3194},
{"f_3208:chicken_install_scm",(void*)f_3208},
{"f_3149:chicken_install_scm",(void*)f_3149},
{"f_3172:chicken_install_scm",(void*)f_3172},
{"f_3181:chicken_install_scm",(void*)f_3181},
{"f_3188:chicken_install_scm",(void*)f_3188},
{"f_3175:chicken_install_scm",(void*)f_3175},
{"f_3153:chicken_install_scm",(void*)f_3153},
{"f_3133:chicken_install_scm",(void*)f_3133},
{"f_3095:chicken_install_scm",(void*)f_3095},
{"f_3129:chicken_install_scm",(void*)f_3129},
{"f_3118:chicken_install_scm",(void*)f_3118},
{"f_3112:chicken_install_scm",(void*)f_3112},
{"f_3108:chicken_install_scm",(void*)f_3108},
{"f_3059:chicken_install_scm",(void*)f_3059},
{"f_3029:chicken_install_scm",(void*)f_3029},
{"f_2945:chicken_install_scm",(void*)f_2945},
{"f_2948:chicken_install_scm",(void*)f_2948},
{"f_2966:chicken_install_scm",(void*)f_2966},
{"f_2951:chicken_install_scm",(void*)f_2951},
{"f_2916:chicken_install_scm",(void*)f_2916},
{"f_1100:chicken_install_scm",(void*)f_1100},
{"f_1106:chicken_install_scm",(void*)f_1106},
{"f_1111:chicken_install_scm",(void*)f_1111},
{"f_1135:chicken_install_scm",(void*)f_1135},
{"f_1138:chicken_install_scm",(void*)f_1138},
{"f_1141:chicken_install_scm",(void*)f_1141},
{"f_1165:chicken_install_scm",(void*)f_1165},
{"f_1161:chicken_install_scm",(void*)f_1161},
{"f_1144:chicken_install_scm",(void*)f_1144},
{"f_1147:chicken_install_scm",(void*)f_1147},
{"f_1157:chicken_install_scm",(void*)f_1157},
{"f_1150:chicken_install_scm",(void*)f_1150},
{"f_1153:chicken_install_scm",(void*)f_1153},
{"f_1124:chicken_install_scm",(void*)f_1124},
{"f_2919:chicken_install_scm",(void*)f_2919},
{"f_2887:chicken_install_scm",(void*)f_2887},
{"f_2880:chicken_install_scm",(void*)f_2880},
{"f_2829:chicken_install_scm",(void*)f_2829},
{"f_2792:chicken_install_scm",(void*)f_2792},
{"f_2796:chicken_install_scm",(void*)f_2796},
{"f_2759:chicken_install_scm",(void*)f_2759},
{"f_2723:chicken_install_scm",(void*)f_2723},
{"f_2631:chicken_install_scm",(void*)f_2631},
{"f_2662:chicken_install_scm",(void*)f_2662},
{"f_2647:chicken_install_scm",(void*)f_2647},
{"f_2655:chicken_install_scm",(void*)f_2655},
{"f_2645:chicken_install_scm",(void*)f_2645},
{"f_2641:chicken_install_scm",(void*)f_2641},
{"f_2603:chicken_install_scm",(void*)f_2603},
{"f_2616:chicken_install_scm",(void*)f_2616},
{"f_2606:chicken_install_scm",(void*)f_2606},
{"f_2613:chicken_install_scm",(void*)f_2613},
{"f_2098:chicken_install_scm",(void*)f_2098},
{"f_2240:chicken_install_scm",(void*)f_2240},
{"f_2104:chicken_install_scm",(void*)f_2104},
{"f_2107:chicken_install_scm",(void*)f_2107},
{"f_2110:chicken_install_scm",(void*)f_2110},
{"f_2232:chicken_install_scm",(void*)f_2232},
{"f_2117:chicken_install_scm",(void*)f_2117},
{"f_2119:chicken_install_scm",(void*)f_2119},
{"f_2132:chicken_install_scm",(void*)f_2132},
{"f_2135:chicken_install_scm",(void*)f_2135},
{"f_2159:chicken_install_scm",(void*)f_2159},
{"f_2089:chicken_install_scm",(void*)f_2089},
{"f_2003:chicken_install_scm",(void*)f_2003},
{"f_2006:chicken_install_scm",(void*)f_2006},
{"f_2009:chicken_install_scm",(void*)f_2009},
{"f_2012:chicken_install_scm",(void*)f_2012},
{"f_2015:chicken_install_scm",(void*)f_2015},
{"f_2018:chicken_install_scm",(void*)f_2018},
{"f_2021:chicken_install_scm",(void*)f_2021},
{"f_2075:chicken_install_scm",(void*)f_2075},
{"f_2060:chicken_install_scm",(void*)f_2060},
{"f_2063:chicken_install_scm",(void*)f_2063},
{"f_2066:chicken_install_scm",(void*)f_2066},
{"f_2069:chicken_install_scm",(void*)f_2069},
{"f_2041:chicken_install_scm",(void*)f_2041},
{"f_2049:chicken_install_scm",(void*)f_2049},
{"f_2045:chicken_install_scm",(void*)f_2045},
{"f_2163:chicken_install_scm",(void*)f_2163},
{"f_2166:chicken_install_scm",(void*)f_2166},
{"f_2169:chicken_install_scm",(void*)f_2169},
{"f_2209:chicken_install_scm",(void*)f_2209},
{"f_2215:chicken_install_scm",(void*)f_2215},
{"f_2175:chicken_install_scm",(void*)f_2175},
{"f_2178:chicken_install_scm",(void*)f_2178},
{"f_2181:chicken_install_scm",(void*)f_2181},
{"f_2184:chicken_install_scm",(void*)f_2184},
{"f_2187:chicken_install_scm",(void*)f_2187},
{"f_2190:chicken_install_scm",(void*)f_2190},
{"f_2193:chicken_install_scm",(void*)f_2193},
{"f_2196:chicken_install_scm",(void*)f_2196},
{"f_2150:chicken_install_scm",(void*)f_2150},
{"f_2139:chicken_install_scm",(void*)f_2139},
{"f_2143:chicken_install_scm",(void*)f_2143},
{"f_2146:chicken_install_scm",(void*)f_2146},
{"f_2544:chicken_install_scm",(void*)f_2544},
{"f_2540:chicken_install_scm",(void*)f_2540},
{"f_2261:chicken_install_scm",(void*)f_2261},
{"f_2264:chicken_install_scm",(void*)f_2264},
{"f_2267:chicken_install_scm",(void*)f_2267},
{"f_2270:chicken_install_scm",(void*)f_2270},
{"f_2273:chicken_install_scm",(void*)f_2273},
{"f_2533:chicken_install_scm",(void*)f_2533},
{"f_2421:chicken_install_scm",(void*)f_2421},
{"f_2427:chicken_install_scm",(void*)f_2427},
{"f_2440:chicken_install_scm",(void*)f_2440},
{"f_2455:chicken_install_scm",(void*)f_2455},
{"f_2493:chicken_install_scm",(void*)f_2493},
{"f_2521:chicken_install_scm",(void*)f_2521},
{"f_2527:chicken_install_scm",(void*)f_2527},
{"f_2499:chicken_install_scm",(void*)f_2499},
{"f_2515:chicken_install_scm",(void*)f_2515},
{"f_2461:chicken_install_scm",(void*)f_2461},
{"f_2467:chicken_install_scm",(void*)f_2467},
{"f_2475:chicken_install_scm",(void*)f_2475},
{"f_2479:chicken_install_scm",(void*)f_2479},
{"f_2482:chicken_install_scm",(void*)f_2482},
{"f_2485:chicken_install_scm",(void*)f_2485},
{"f_2488:chicken_install_scm",(void*)f_2488},
{"f_2491:chicken_install_scm",(void*)f_2491},
{"f_2453:chicken_install_scm",(void*)f_2453},
{"f_2443:chicken_install_scm",(void*)f_2443},
{"f_2416:chicken_install_scm",(void*)f_2416},
{"f_2276:chicken_install_scm",(void*)f_2276},
{"f_2279:chicken_install_scm",(void*)f_2279},
{"f_2361:chicken_install_scm",(void*)f_2361},
{"f_2368:chicken_install_scm",(void*)f_2368},
{"f_2371:chicken_install_scm",(void*)f_2371},
{"f_2382:chicken_install_scm",(void*)f_2382},
{"f_2406:chicken_install_scm",(void*)f_2406},
{"f_2390:chicken_install_scm",(void*)f_2390},
{"f_2396:chicken_install_scm",(void*)f_2396},
{"f_2394:chicken_install_scm",(void*)f_2394},
{"f_2376:chicken_install_scm",(void*)f_2376},
{"f_2337:chicken_install_scm",(void*)f_2337},
{"f_2339:chicken_install_scm",(void*)f_2339},
{"f_2347:chicken_install_scm",(void*)f_2347},
{"f_2351:chicken_install_scm",(void*)f_2351},
{"f_2282:chicken_install_scm",(void*)f_2282},
{"f_2285:chicken_install_scm",(void*)f_2285},
{"f_2304:chicken_install_scm",(void*)f_2304},
{"f_2310:chicken_install_scm",(void*)f_2310},
{"f_2323:chicken_install_scm",(void*)f_2323},
{"f_2326:chicken_install_scm",(void*)f_2326},
{"f_2288:chicken_install_scm",(void*)f_2288},
{"f_2302:chicken_install_scm",(void*)f_2302},
{"f_2298:chicken_install_scm",(void*)f_2298},
{"f_2291:chicken_install_scm",(void*)f_2291},
{"f_3349:chicken_install_scm",(void*)f_3349},
{"f_3310:chicken_install_scm",(void*)f_3310},
{"f_3316:chicken_install_scm",(void*)f_3316},
{"f_3337:chicken_install_scm",(void*)f_3337},
{"f_3320:chicken_install_scm",(void*)f_3320},
{"f_3333:chicken_install_scm",(void*)f_3333},
{"f_3323:chicken_install_scm",(void*)f_3323},
{"f_3326:chicken_install_scm",(void*)f_3326},
{"f_3302:chicken_install_scm",(void*)f_3302},
{"f_3293:chicken_install_scm",(void*)f_3293},
{"f_3299:chicken_install_scm",(void*)f_3299},
{"f_3296:chicken_install_scm",(void*)f_3296},
{"f_2568:chicken_install_scm",(void*)f_2568},
{"f_2572:chicken_install_scm",(void*)f_2572},
{"f_2546:chicken_install_scm",(void*)f_2546},
{"f_2563:chicken_install_scm",(void*)f_2563},
{"f_2550:chicken_install_scm",(void*)f_2550},
{"f_2242:chicken_install_scm",(void*)f_2242},
{"f_2249:chicken_install_scm",(void*)f_2249},
{"f_1717:chicken_install_scm",(void*)f_1717},
{"f_1721:chicken_install_scm",(void*)f_1721},
{"f_1911:chicken_install_scm",(void*)f_1911},
{"f_1959:chicken_install_scm",(void*)f_1959},
{"f_1963:chicken_install_scm",(void*)f_1963},
{"f_1966:chicken_install_scm",(void*)f_1966},
{"f_1953:chicken_install_scm",(void*)f_1953},
{"f_1592:chicken_install_scm",(void*)f_1592},
{"f_1594:chicken_install_scm",(void*)f_1594},
{"f_1658:chicken_install_scm",(void*)f_1658},
{"f_1648:chicken_install_scm",(void*)f_1648},
{"f_1624:chicken_install_scm",(void*)f_1624},
{"f_1079:chicken_install_scm",(void*)f_1079},
{"f_1618:chicken_install_scm",(void*)f_1618},
{"f_1460:chicken_install_scm",(void*)f_1460},
{"f_1553:chicken_install_scm",(void*)f_1553},
{"f_1572:chicken_install_scm",(void*)f_1572},
{"f_1578:chicken_install_scm",(void*)f_1578},
{"f_1559:chicken_install_scm",(void*)f_1559},
{"f_1567:chicken_install_scm",(void*)f_1567},
{"f_1466:chicken_install_scm",(void*)f_1466},
{"f_1472:chicken_install_scm",(void*)f_1472},
{"f_1482:chicken_install_scm",(void*)f_1482},
{"f_1494:chicken_install_scm",(void*)f_1494},
{"f_1506:chicken_install_scm",(void*)f_1506},
{"f_1509:chicken_install_scm",(void*)f_1509},
{"f_1512:chicken_install_scm",(void*)f_1512},
{"f_1497:chicken_install_scm",(void*)f_1497},
{"f_1485:chicken_install_scm",(void*)f_1485},
{"f_1458:chicken_install_scm",(void*)f_1458},
{"f_1942:chicken_install_scm",(void*)f_1942},
{"f_1927:chicken_install_scm",(void*)f_1927},
{"f_1724:chicken_install_scm",(void*)f_1724},
{"f_1732:chicken_install_scm",(void*)f_1732},
{"f_1762:chicken_install_scm",(void*)f_1762},
{"f_1768:chicken_install_scm",(void*)f_1768},
{"f_1889:chicken_install_scm",(void*)f_1889},
{"f_1771:chicken_install_scm",(void*)f_1771},
{"f_1774:chicken_install_scm",(void*)f_1774},
{"f_1785:chicken_install_scm",(void*)f_1785},
{"f_1878:chicken_install_scm",(void*)f_1878},
{"f_1866:chicken_install_scm",(void*)f_1866},
{"f_1859:chicken_install_scm",(void*)f_1859},
{"f_1793:chicken_install_scm",(void*)f_1793},
{"f_1681:chicken_install_scm",(void*)f_1681},
{"f_1707:chicken_install_scm",(void*)f_1707},
{"f_1679:chicken_install_scm",(void*)f_1679},
{"f_1671:chicken_install_scm",(void*)f_1671},
{"f_1853:chicken_install_scm",(void*)f_1853},
{"f_1799:chicken_install_scm",(void*)f_1799},
{"f_1802:chicken_install_scm",(void*)f_1802},
{"f_1840:chicken_install_scm",(void*)f_1840},
{"f_1805:chicken_install_scm",(void*)f_1805},
{"f_1813:chicken_install_scm",(void*)f_1813},
{"f_1826:chicken_install_scm",(void*)f_1826},
{"f_1829:chicken_install_scm",(void*)f_1829},
{"f_1808:chicken_install_scm",(void*)f_1808},
{"f_1779:chicken_install_scm",(void*)f_1779},
{"f_1230:chicken_install_scm",(void*)f_1230},
{"f_1239:chicken_install_scm",(void*)f_1239},
{"f_1244:chicken_install_scm",(void*)f_1244},
{"f_1300:chicken_install_scm",(void*)f_1300},
{"f_1406:chicken_install_scm",(void*)f_1406},
{"f_1303:chicken_install_scm",(void*)f_1303},
{"f_1320:chicken_install_scm",(void*)f_1320},
{"f_1395:chicken_install_scm",(void*)f_1395},
{"f_1391:chicken_install_scm",(void*)f_1391},
{"f_1380:chicken_install_scm",(void*)f_1380},
{"f_1366:chicken_install_scm",(void*)f_1366},
{"f_1333:chicken_install_scm",(void*)f_1333},
{"f_1344:chicken_install_scm",(void*)f_1344},
{"f_1348:chicken_install_scm",(void*)f_1348},
{"f_1340:chicken_install_scm",(void*)f_1340},
{"f_1287:chicken_install_scm",(void*)f_1287},
{"f_1294:chicken_install_scm",(void*)f_1294},
{"f_1284:chicken_install_scm",(void*)f_1284},
{"f_1258:chicken_install_scm",(void*)f_1258},
{"f_1262:chicken_install_scm",(void*)f_1262},
{"f_1745:chicken_install_scm",(void*)f_1745},
{"f_1167:chicken_install_scm",(void*)f_1167},
{"f_1212:chicken_install_scm",(void*)f_1212},
{"f_1177:chicken_install_scm",(void*)f_1177},
{"f_1183:chicken_install_scm",(void*)f_1183},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
