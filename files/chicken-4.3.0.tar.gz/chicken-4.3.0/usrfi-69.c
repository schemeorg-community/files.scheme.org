/* Generated from srfi-69.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-12-14 09:03
   Version 4.2.0 - SVN rev. 16023
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-12-14 on galinha (Linux)
   command line: srfi-69.scm -optimize-level 2 -include-path . -include-path ./ -inline -explicit-use -no-trace -unsafe -no-lambda-info -output-file usrfi-69.c -extend ./private-namespace.scm
   unit: srfi_69
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[115];
static double C_possibly_force_alignment;


C_noret_decl(C_srfi_69_toplevel)
C_externexport void C_ccall C_srfi_69_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1328)
static void C_ccall f_1328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4975)
static void C_ccall f_4975(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4975)
static void C_ccall f_4975r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4985)
static void C_ccall f_4985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4997)
static void C_ccall f_4997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5054)
static void C_fcall f_5054(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5073)
static void C_ccall f_5073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5012)
static void C_fcall f_5012(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5095)
static void C_ccall f_5095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3967)
static void C_ccall f_3967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4959)
static void C_ccall f_4959(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4963)
static void C_ccall f_4963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4966)
static void C_ccall f_4966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4957)
static void C_ccall f_4957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4934)
static void C_ccall f_4934(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4941)
static void C_ccall f_4941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4946)
static void C_ccall f_4946(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4954)
static void C_ccall f_4954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4922)
static void C_ccall f_4922(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4929)
static void C_ccall f_4929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4910)
static void C_ccall f_4910(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4917)
static void C_ccall f_4917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4898)
static void C_ccall f_4898(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4905)
static void C_ccall f_4905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4832)
static void C_fcall f_4832(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4844)
static void C_fcall f_4844(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4860)
static void C_fcall f_4860(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4888)
static void C_ccall f_4888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4767)
static void C_fcall f_4767(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4779)
static void C_fcall f_4779(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4802)
static void C_fcall f_4802(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4815)
static void C_ccall f_4815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4789)
static void C_ccall f_4789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4702)
static void C_ccall f_4702(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4717)
static void C_fcall f_4717(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4733)
static void C_fcall f_4733(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4637)
static void C_ccall f_4637(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4652)
static void C_fcall f_4652(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4668)
static void C_fcall f_4668(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4592)
static void C_ccall f_4592(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4592)
static void C_ccall f_4592r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4599)
static void C_ccall f_4599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4604)
static void C_fcall f_4604(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4620)
static void C_ccall f_4620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4602)
static void C_ccall f_4602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4519)
static void C_ccall f_4519(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4534)
static void C_fcall f_4534(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4550)
static void C_fcall f_4550(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4503)
static void C_ccall f_4503(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4517)
static void C_ccall f_4517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4491)
static void C_ccall f_4491(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4426)
static void C_fcall f_4426(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4438)
static void C_fcall f_4438(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4461)
static void C_fcall f_4461(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4474)
static void C_ccall f_4474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4448)
static void C_ccall f_4448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4410)
static void C_ccall f_4410(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4417)
static void C_ccall f_4417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4314)
static void C_ccall f_4314(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4321)
static void C_ccall f_4321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4335)
static void C_fcall f_4335(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4361)
static void C_fcall f_4361(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4380)
static void C_ccall f_4380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4348)
static void C_ccall f_4348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4183)
static void C_ccall f_4183(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4199)
static void C_ccall f_4199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4266)
static void C_fcall f_4266(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4285)
static void C_ccall f_4285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4219)
static C_word C_fcall f_4219(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_4075)
static void C_ccall f_4075(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4091)
static void C_ccall f_4091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4146)
static void C_fcall f_4146(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4159)
static void C_ccall f_4159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4106)
static C_word C_fcall f_4106(C_word t0,C_word t1);
C_noret_decl(f_3969)
static void C_ccall f_3969(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3985)
static void C_ccall f_3985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4039)
static void C_fcall f_4039(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4055)
static void C_ccall f_4055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4000)
static C_word C_fcall f_4000(C_word t0,C_word t1);
C_noret_decl(f_3772)
static void C_ccall f_3772(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3955)
static void C_ccall f_3955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3947)
static void C_ccall f_3947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3928)
static void C_fcall f_3928(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3800)
static void C_ccall f_3800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3815)
static void C_ccall f_3815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3881)
static void C_fcall f_3881(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3911)
static void C_ccall f_3911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3832)
static void C_fcall f_3832(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3821)
static void C_ccall f_3821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3760)
static void C_ccall f_3760(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3767)
static void C_ccall f_3767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3553)
static void C_fcall f_3553(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3750)
static void C_ccall f_3750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3742)
static void C_ccall f_3742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3723)
static void C_fcall f_3723(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3578)
static void C_ccall f_3578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3593)
static void C_ccall f_3593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3666)
static void C_fcall f_3666(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3699)
static void C_ccall f_3699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3702)
static void C_ccall f_3702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3676)
static void C_ccall f_3676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3607)
static void C_fcall f_3607(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3643)
static void C_ccall f_3643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3617)
static void C_ccall f_3617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3266)
static void C_ccall f_3266(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3266)
static void C_ccall f_3266r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3508)
static void C_fcall f_3508(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3491)
static void C_fcall f_3491(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3503)
static void C_ccall f_3503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3268)
static void C_fcall f_3268(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3275)
static void C_ccall f_3275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3278)
static void C_ccall f_3278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3482)
static void C_ccall f_3482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3474)
static void C_ccall f_3474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3455)
static void C_fcall f_3455(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3302)
static void C_ccall f_3302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3317)
static void C_ccall f_3317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3394)
static void C_fcall f_3394(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3431)
static void C_ccall f_3431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3434)
static void C_ccall f_3434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3422)
static void C_ccall f_3422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3404)
static void C_ccall f_3404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3331)
static void C_fcall f_3331(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3371)
static void C_ccall f_3371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3359)
static void C_ccall f_3359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3341)
static void C_ccall f_3341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3257)
static void C_ccall f_3257(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3145)
static void C_fcall f_3145(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3155)
static void C_ccall f_3155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3160)
static void C_fcall f_3160(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3222)
static void C_fcall f_3222(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3243)
static void C_ccall f_3243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3216)
static void C_ccall f_3216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3119)
static void C_ccall f_3119(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3126)
static void C_ccall f_3126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3129)
static void C_ccall f_3129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3052)
static void C_fcall f_3052(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3075)
static void C_fcall f_3075(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3091)
static void C_ccall f_3091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3062)
static void C_ccall f_3062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3132)
static void C_ccall f_3132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3025)
static void C_ccall f_3025(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3013)
static void C_ccall f_3013(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3004)
static void C_ccall f_3004(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2995)
static void C_ccall f_2995(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2986)
static void C_ccall f_2986(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2977)
static void C_ccall f_2977(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2968)
static void C_ccall f_2968(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2959)
static void C_ccall f_2959(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2950)
static void C_ccall f_2950(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2944)
static void C_ccall f_2944(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2581)
static void C_ccall f_2581(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2581)
static void C_ccall f_2581r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2934)
static void C_ccall f_2934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2937)
static void C_ccall f_2937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2659)
static void C_fcall f_2659(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2914)
static void C_ccall f_2914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2917)
static void C_ccall f_2917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2662)
static void C_fcall f_2662(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2882)
static void C_ccall f_2882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2888)
static void C_ccall f_2888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2665)
static void C_fcall f_2665(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2700)
static void C_fcall f_2700(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2721)
static void C_ccall f_2721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2727)
static void C_ccall f_2727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2819)
static void C_ccall f_2819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2822)
static void C_ccall f_2822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2794)
static void C_ccall f_2794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2797)
static void C_ccall f_2797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2784)
static void C_ccall f_2784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2766)
static void C_ccall f_2766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2753)
static void C_ccall f_2753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2743)
static void C_ccall f_2743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2730)
static void C_ccall f_2730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2711)
static void C_fcall f_2711(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2668)
static void C_ccall f_2668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2671)
static void C_ccall f_2671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2675)
static void C_ccall f_2675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2691)
static void C_ccall f_2691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2678)
static void C_fcall f_2678(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2583)
static C_word C_fcall f_2583(C_word t0);
C_noret_decl(f_2557)
static void C_fcall f_2557(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_2561)
static void C_ccall f_2561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2527)
static void C_fcall f_2527(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2533)
static C_word C_fcall f_2533(C_word t0,C_word t1);
C_noret_decl(f_2403)
static void C_ccall f_2403(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2403)
static void C_ccall f_2403r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2468)
static void C_fcall f_2468(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2459)
static void C_fcall f_2459(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2440)
static void C_fcall f_2440(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2444)
static void C_ccall f_2444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2447)
static void C_ccall f_2447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2419)
static void C_ccall f_2419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2281)
static void C_ccall f_2281(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2281)
static void C_ccall f_2281r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2346)
static void C_fcall f_2346(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2337)
static void C_fcall f_2337(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2318)
static void C_fcall f_2318(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2322)
static void C_ccall f_2322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2325)
static void C_ccall f_2325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2297)
static void C_ccall f_2297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2239)
static void C_ccall f_2239(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2239)
static void C_ccall f_2239r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2249)
static void C_ccall f_2249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1905)
static void C_fcall f_1905(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2004)
static void C_fcall f_2004(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2217)
static void C_ccall f_2217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2196)
static void C_ccall f_2196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2188)
static void C_ccall f_2188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2167)
static void C_ccall f_2167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2141)
static void C_ccall f_2141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1973)
static void C_fcall f_1973(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1989)
static void C_fcall f_1989(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1908)
static void C_fcall f_1908(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1925)
static void C_fcall f_1925(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1959)
static void C_ccall f_1959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1864)
static void C_ccall f_1864(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1864)
static void C_ccall f_1864r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1853)
static void C_ccall f_1853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1874)
static void C_ccall f_1874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1680)
static void C_ccall f_1680(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1680)
static void C_ccall f_1680r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1690)
static void C_ccall f_1690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1576)
static void C_ccall f_1576(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1576)
static void C_ccall f_1576r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1583)
static void C_ccall f_1583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1550)
static void C_ccall f_1550(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1550)
static void C_ccall f_1550r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1557)
static void C_ccall f_1557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1506)
static void C_ccall f_1506(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1506)
static void C_ccall f_1506r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1465)
static void C_ccall f_1465(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1465)
static void C_ccall f_1465r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1475)
static void C_ccall f_1475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1336)
static void C_ccall f_1336(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1336)
static void C_ccall f_1336r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1343)
static void C_ccall f_1343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1445)
static void C_ccall f_1445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1349)
static void C_fcall f_1349(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1330)
static void C_ccall f_1330(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_5054)
static void C_fcall trf_5054(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5054(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5054(t0,t1,t2);}

C_noret_decl(trf_5012)
static void C_fcall trf_5012(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5012(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5012(t0,t1,t2);}

C_noret_decl(trf_4832)
static void C_fcall trf_4832(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4832(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4832(t0,t1,t2,t3);}

C_noret_decl(trf_4844)
static void C_fcall trf_4844(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4844(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4844(t0,t1,t2,t3);}

C_noret_decl(trf_4860)
static void C_fcall trf_4860(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4860(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4860(t0,t1,t2,t3);}

C_noret_decl(trf_4767)
static void C_fcall trf_4767(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4767(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4767(t0,t1,t2);}

C_noret_decl(trf_4779)
static void C_fcall trf_4779(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4779(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4779(t0,t1,t2);}

C_noret_decl(trf_4802)
static void C_fcall trf_4802(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4802(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4802(t0,t1,t2);}

C_noret_decl(trf_4717)
static void C_fcall trf_4717(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4717(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4717(t0,t1,t2,t3);}

C_noret_decl(trf_4733)
static void C_fcall trf_4733(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4733(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4733(t0,t1,t2,t3);}

C_noret_decl(trf_4652)
static void C_fcall trf_4652(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4652(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4652(t0,t1,t2,t3);}

C_noret_decl(trf_4668)
static void C_fcall trf_4668(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4668(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4668(t0,t1,t2,t3);}

C_noret_decl(trf_4604)
static void C_fcall trf_4604(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4604(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4604(t0,t1,t2);}

C_noret_decl(trf_4534)
static void C_fcall trf_4534(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4534(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4534(t0,t1,t2,t3);}

C_noret_decl(trf_4550)
static void C_fcall trf_4550(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4550(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4550(t0,t1,t2,t3);}

C_noret_decl(trf_4426)
static void C_fcall trf_4426(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4426(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4426(t0,t1,t2);}

C_noret_decl(trf_4438)
static void C_fcall trf_4438(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4438(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4438(t0,t1,t2);}

C_noret_decl(trf_4461)
static void C_fcall trf_4461(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4461(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4461(t0,t1,t2);}

C_noret_decl(trf_4335)
static void C_fcall trf_4335(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4335(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4335(t0,t1,t2);}

C_noret_decl(trf_4361)
static void C_fcall trf_4361(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4361(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4361(t0,t1,t2,t3);}

C_noret_decl(trf_4266)
static void C_fcall trf_4266(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4266(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4266(t0,t1,t2,t3);}

C_noret_decl(trf_4146)
static void C_fcall trf_4146(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4146(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4146(t0,t1,t2);}

C_noret_decl(trf_4039)
static void C_fcall trf_4039(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4039(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4039(t0,t1,t2);}

C_noret_decl(trf_3928)
static void C_fcall trf_3928(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3928(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3928(t0,t1);}

C_noret_decl(trf_3881)
static void C_fcall trf_3881(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3881(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3881(t0,t1,t2);}

C_noret_decl(trf_3832)
static void C_fcall trf_3832(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3832(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3832(t0,t1,t2);}

C_noret_decl(trf_3553)
static void C_fcall trf_3553(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3553(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3553(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3723)
static void C_fcall trf_3723(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3723(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3723(t0,t1);}

C_noret_decl(trf_3666)
static void C_fcall trf_3666(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3666(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3666(t0,t1,t2);}

C_noret_decl(trf_3607)
static void C_fcall trf_3607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3607(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3607(t0,t1,t2);}

C_noret_decl(trf_3508)
static void C_fcall trf_3508(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3508(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3508(t0,t1);}

C_noret_decl(trf_3491)
static void C_fcall trf_3491(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3491(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3491(t0,t1,t2);}

C_noret_decl(trf_3268)
static void C_fcall trf_3268(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3268(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3268(t0,t1,t2,t3);}

C_noret_decl(trf_3455)
static void C_fcall trf_3455(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3455(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3455(t0,t1);}

C_noret_decl(trf_3394)
static void C_fcall trf_3394(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3394(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3394(t0,t1,t2);}

C_noret_decl(trf_3331)
static void C_fcall trf_3331(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3331(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3331(t0,t1,t2);}

C_noret_decl(trf_3145)
static void C_fcall trf_3145(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3145(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3145(t0,t1,t2);}

C_noret_decl(trf_3160)
static void C_fcall trf_3160(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3160(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3160(t0,t1,t2);}

C_noret_decl(trf_3222)
static void C_fcall trf_3222(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3222(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3222(t0,t1,t2);}

C_noret_decl(trf_3052)
static void C_fcall trf_3052(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3052(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3052(t0,t1,t2);}

C_noret_decl(trf_3075)
static void C_fcall trf_3075(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3075(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3075(t0,t1,t2);}

C_noret_decl(trf_2659)
static void C_fcall trf_2659(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2659(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2659(t0,t1);}

C_noret_decl(trf_2662)
static void C_fcall trf_2662(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2662(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2662(t0,t1);}

C_noret_decl(trf_2665)
static void C_fcall trf_2665(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2665(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2665(t0,t1);}

C_noret_decl(trf_2700)
static void C_fcall trf_2700(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2700(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2700(t0,t1,t2);}

C_noret_decl(trf_2711)
static void C_fcall trf_2711(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2711(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2711(t0,t1,t2);}

C_noret_decl(trf_2678)
static void C_fcall trf_2678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2678(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2678(t0,t1);}

C_noret_decl(trf_2557)
static void C_fcall trf_2557(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2557(void *dummy){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
f_2557(t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(trf_2527)
static void C_fcall trf_2527(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2527(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2527(t0,t1,t2);}

C_noret_decl(trf_2468)
static void C_fcall trf_2468(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2468(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2468(t0,t1);}

C_noret_decl(trf_2459)
static void C_fcall trf_2459(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2459(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2459(t0,t1,t2);}

C_noret_decl(trf_2440)
static void C_fcall trf_2440(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2440(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2440(t0,t1,t2,t3);}

C_noret_decl(trf_2346)
static void C_fcall trf_2346(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2346(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2346(t0,t1);}

C_noret_decl(trf_2337)
static void C_fcall trf_2337(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2337(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2337(t0,t1,t2);}

C_noret_decl(trf_2318)
static void C_fcall trf_2318(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2318(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2318(t0,t1,t2,t3);}

C_noret_decl(trf_1905)
static void C_fcall trf_1905(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1905(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1905(t0,t1);}

C_noret_decl(trf_2004)
static void C_fcall trf_2004(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2004(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2004(t0,t1,t2,t3);}

C_noret_decl(trf_1973)
static void C_fcall trf_1973(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1973(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1973(t0,t1,t2,t3);}

C_noret_decl(trf_1989)
static void C_fcall trf_1989(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1989(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1989(t0,t1);}

C_noret_decl(trf_1908)
static void C_fcall trf_1908(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1908(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1908(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1925)
static void C_fcall trf_1925(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1925(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1925(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1349)
static void C_fcall trf_1349(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1349(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1349(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_69_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_69_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(933)){
C_save(t1);
C_rereclaim2(933*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,115);
lf[0]=C_h_intern(&lf[0],20,"\003sysnumber-hash-hook");
lf[2]=C_h_intern(&lf[2],11,"number-hash");
lf[3]=C_h_intern(&lf[3],15,"\003syssignal-hook");
lf[4]=C_h_intern(&lf[4],5,"\000type");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid number");
lf[6]=C_h_intern(&lf[6],15,"object-uid-hash");
lf[7]=C_h_intern(&lf[7],11,"symbol-hash");
lf[8]=C_h_intern(&lf[8],17,"\003syscheck-keyword");
lf[9]=C_h_intern(&lf[9],11,"\000type-error");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a keyword");
lf[11]=C_h_intern(&lf[11],8,"keyword\077");
lf[12]=C_h_intern(&lf[12],12,"keyword-hash");
lf[13]=C_h_intern(&lf[13],8,"eq\077-hash");
lf[14]=C_h_intern(&lf[14],16,"hash-by-identity");
lf[15]=C_h_intern(&lf[15],9,"eqv\077-hash");
lf[16]=C_h_intern(&lf[16],11,"input-port\077");
lf[17]=C_h_intern(&lf[17],11,"equal\077-hash");
lf[18]=C_h_intern(&lf[18],4,"hash");
lf[19]=C_h_intern(&lf[19],11,"string-hash");
lf[20]=C_h_intern(&lf[20],13,"\003syssubstring");
lf[21]=C_h_intern(&lf[21],15,"\003syscheck-range");
lf[22]=C_h_intern(&lf[22],14,"string-ci-hash");
lf[23]=C_h_intern(&lf[23],14,"string-hash-ci");
lf[25]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\0013\376\003\000\000\002\376\377\001\000\000\002i\376\003\000\000\002\376\377\001\000\000\004\325\376\003\000\000\002\376\377\001\000\000\011\255\376\003\000\000\002\376\377\001\000\000\023]\376\003\000\000\002\376\377\001\000\000&\303\376\003\000\000\002\376\377\001"
"\000\000M\215\376\003\000\000\002\376\377\001\000\000\233\035\376\003\000\000\002\376\377\001\000\0016\077\376\003\000\000\002\376\377\001\000\002l\201\376\003\000\000\002\376\377\001\000\004\331\005\376\003\000\000\002\376\377\001\000\011\262\025\376\003\000\000\002\376\377\001\000\023dA\376\003\000\000"
"\002\376\377\001\000&\310\205\376\003\000\000\002\376\377\001\000M\221\037\376\003\000\000\002\376\377\001\000\233\042I\376\003\000\000\002\376\377\001\0016D\277\376\003\000\000\002\376\377\001\002l\211\207\376\003\000\000\002\376\377\001\004\331\023\027\376\003\000\000\002\376\377\001\011\262&1"
"\376\003\000\000\002\376\377\001\023dLq\376\003\000\000\002\376\377\001&\310\230\373\376\003\000\000\002\376\377\001\077\377\377\377\376\377\016");
lf[27]=C_h_intern(&lf[27],11,"make-vector");
lf[29]=C_h_intern(&lf[29],10,"hash-table");
lf[30]=C_h_intern(&lf[30],3,"eq\077");
lf[31]=C_h_intern(&lf[31],4,"eqv\077");
lf[32]=C_h_intern(&lf[32],6,"equal\077");
lf[33]=C_h_intern(&lf[33],8,"string=\077");
lf[34]=C_h_intern(&lf[34],11,"string-ci=\077");
lf[35]=C_h_intern(&lf[35],1,"=");
lf[36]=C_h_intern(&lf[36],15,"make-hash-table");
lf[37]=C_decode_literal(C_heaptop,"\376U0.5\000");
lf[38]=C_decode_literal(C_heaptop,"\376U0.8\000");
lf[39]=C_h_intern(&lf[39],7,"warning");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\033user test without user hash");
lf[41]=C_h_intern(&lf[41],5,"error");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\036min-load greater than max-load");
lf[43]=C_h_intern(&lf[43],5,"\000test");
lf[44]=C_h_intern(&lf[44],17,"\003syscheck-closure");
lf[45]=C_h_intern(&lf[45],5,"\000hash");
lf[46]=C_h_intern(&lf[46],5,"\000size");
lf[47]=C_h_intern(&lf[47],19,"hash-table-max-size");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid size");
lf[49]=C_h_intern(&lf[49],8,"\000initial");
lf[50]=C_h_intern(&lf[50],9,"\000min-load");
lf[51]=C_decode_literal(C_heaptop,"\376U0.0\000");
lf[52]=C_decode_literal(C_heaptop,"\376U1.0\000");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid min-load");
lf[54]=C_h_intern(&lf[54],17,"\003syscheck-inexact");
lf[55]=C_h_intern(&lf[55],9,"\000max-load");
lf[56]=C_decode_literal(C_heaptop,"\376U0.0\000");
lf[57]=C_decode_literal(C_heaptop,"\376U1.0\000");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid max-load");
lf[59]=C_h_intern(&lf[59],10,"\000weak-keys");
lf[60]=C_h_intern(&lf[60],12,"\000weak-values");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\017unknown keyword");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\025missing keyword value");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\017missing keyword");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid size");
lf[65]=C_h_intern(&lf[65],11,"hash-table\077");
lf[66]=C_h_intern(&lf[66],15,"hash-table-size");
lf[67]=C_h_intern(&lf[67],31,"hash-table-equivalence-function");
lf[68]=C_h_intern(&lf[68],24,"hash-table-hash-function");
lf[69]=C_h_intern(&lf[69],19,"hash-table-min-load");
lf[70]=C_h_intern(&lf[70],19,"hash-table-max-load");
lf[71]=C_h_intern(&lf[71],20,"hash-table-weak-keys");
lf[72]=C_h_intern(&lf[72],22,"hash-table-weak-values");
lf[73]=C_h_intern(&lf[73],23,"hash-table-has-initial\077");
lf[74]=C_h_intern(&lf[74],18,"hash-table-initial");
lf[75]=C_h_intern(&lf[75],18,"hash-table-resize!");
lf[77]=C_h_intern(&lf[77],15,"hash-table-copy");
lf[78]=C_h_intern(&lf[78],18,"hash-table-update!");
lf[79]=C_h_intern(&lf[79],5,"floor");
lf[80]=C_h_intern(&lf[80],13,"\000access-error");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\037hash-table does not contain key");
lf[82]=C_h_intern(&lf[82],8,"identity");
lf[84]=C_h_intern(&lf[84],26,"hash-table-update!/default");
lf[85]=C_h_intern(&lf[85],15,"hash-table-set!");
lf[86]=C_h_intern(&lf[86],19,"\003sysundefined-value");
lf[87]=C_h_intern(&lf[87],14,"hash-table-ref");
lf[88]=C_h_intern(&lf[88],22,"hash-table-ref/default");
lf[89]=C_h_intern(&lf[89],18,"hash-table-exists\077");
lf[90]=C_h_intern(&lf[90],18,"hash-table-delete!");
lf[91]=C_h_intern(&lf[91],18,"hash-table-remove!");
lf[92]=C_h_intern(&lf[92],17,"hash-table-clear!");
lf[93]=C_h_intern(&lf[93],12,"vector-fill!");
lf[95]=C_h_intern(&lf[95],17,"hash-table-merge!");
lf[96]=C_h_intern(&lf[96],16,"hash-table-merge");
lf[97]=C_h_intern(&lf[97],17,"hash-table->alist");
lf[98]=C_h_intern(&lf[98],17,"alist->hash-table");
lf[99]=C_h_intern(&lf[99],15,"hash-table-keys");
lf[100]=C_h_intern(&lf[100],17,"hash-table-values");
lf[103]=C_h_intern(&lf[103],15,"hash-table-fold");
lf[104]=C_h_intern(&lf[104],19,"hash-table-for-each");
lf[105]=C_h_intern(&lf[105],15,"hash-table-walk");
lf[106]=C_h_intern(&lf[106],14,"hash-table-map");
lf[107]=C_h_intern(&lf[107],9,"\003sysprint");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\002)>");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\016#<hash-table (");
lf[110]=C_h_intern(&lf[110],27,"\003sysregister-record-printer");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\037hash-table does not contain key");
lf[112]=C_h_intern(&lf[112],18,"getter-with-setter");
lf[113]=C_h_intern(&lf[113],17,"register-feature!");
lf[114]=C_h_intern(&lf[114],7,"srfi-69");
C_register_lf2(lf,115,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1328,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 65   register-feature! */
t3=*((C_word*)lf[113]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[114]);}

/* k1326 */
static void C_ccall f_1328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word ab[81],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1328,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! number-hash-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1330,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[2]+1 /* (set! number-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1336,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[6]+1 /* (set! object-uid-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1465,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[7]+1 /* (set! symbol-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1506,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[8]+1 /* (set! check-keyword ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1550,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[12]+1 /* (set! keyword-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1576,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[13]+1 /* (set! eq?-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1680,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[14]+1 /* (set! hash-by-identity ...) */,*((C_word*)lf[13]+1));
t10=C_mutate((C_word*)lf[15]+1 /* (set! eqv?-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1864,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate(&lf[1] /* (set! *equal?-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1905,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[17]+1 /* (set! equal?-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2239,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[18]+1 /* (set! hash ...) */,*((C_word*)lf[17]+1));
t14=C_mutate((C_word*)lf[19]+1 /* (set! string-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2281,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[22]+1 /* (set! string-ci-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2403,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[23]+1 /* (set! string-hash-ci ...) */,*((C_word*)lf[22]+1));
t17=C_mutate(&lf[24] /* (set! constant539 ...) */,lf[25]);
t18=C_mutate(&lf[26] /* (set! hash-table-canonical-length ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2527,tmp=(C_word)a,a+=2,tmp));
t19=*((C_word*)lf[27]+1);
t20=C_mutate(&lf[28] /* (set! *make-hash-table ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2557,a[2]=t19,tmp=(C_word)a,a+=3,tmp));
t21=*((C_word*)lf[30]+1);
t22=*((C_word*)lf[31]+1);
t23=*((C_word*)lf[32]+1);
t24=*((C_word*)lf[33]+1);
t25=*((C_word*)lf[34]+1);
t26=*((C_word*)lf[35]+1);
t27=C_mutate((C_word*)lf[36]+1 /* (set! make-hash-table ...) */,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2581,a[2]=t26,a[3]=t25,a[4]=t24,a[5]=t23,a[6]=t22,a[7]=t21,tmp=(C_word)a,a+=8,tmp));
t28=C_mutate((C_word*)lf[65]+1 /* (set! hash-table? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2944,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[66]+1 /* (set! hash-table-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2950,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[67]+1 /* (set! hash-table-equivalence-function ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2959,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[68]+1 /* (set! hash-table-hash-function ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2968,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[69]+1 /* (set! hash-table-min-load ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2977,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[70]+1 /* (set! hash-table-max-load ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2986,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[71]+1 /* (set! hash-table-weak-keys ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2995,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[72]+1 /* (set! hash-table-weak-values ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3004,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[73]+1 /* (set! hash-table-has-initial? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3013,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[74]+1 /* (set! hash-table-initial ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3025,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate((C_word*)lf[75]+1 /* (set! hash-table-resize! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3119,tmp=(C_word)a,a+=2,tmp));
t39=*((C_word*)lf[27]+1);
t40=C_mutate(&lf[76] /* (set! *hash-table-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3145,a[2]=t39,tmp=(C_word)a,a+=3,tmp));
t41=C_mutate((C_word*)lf[77]+1 /* (set! hash-table-copy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3257,tmp=(C_word)a,a+=2,tmp));
t42=*((C_word*)lf[30]+1);
t43=C_mutate((C_word*)lf[78]+1 /* (set! hash-table-update! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3266,a[2]=t42,tmp=(C_word)a,a+=3,tmp));
t44=*((C_word*)lf[30]+1);
t45=C_mutate(&lf[83] /* (set! *hash-table-update!/default ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3553,a[2]=t44,tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[84]+1 /* (set! hash-table-update!/default ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3760,tmp=(C_word)a,a+=2,tmp));
t47=*((C_word*)lf[30]+1);
t48=C_mutate((C_word*)lf[85]+1 /* (set! hash-table-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3772,a[2]=t47,tmp=(C_word)a,a+=3,tmp));
t49=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3967,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t50=*((C_word*)lf[30]+1);
t51=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4975,a[2]=t50,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 808  getter-with-setter */
t52=*((C_word*)lf[112]+1);
((C_proc4)(void*)(*((C_word*)t52+1)))(4,t52,t49,t51,*((C_word*)lf[85]+1));}

/* a4974 in k1326 */
static void C_ccall f_4975(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr4rv,(void*)f_4975r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_4975r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4975r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(11);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5095,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp):(C_word)C_slot(t4,C_fix(0)));
t7=(C_word)C_i_check_structure_2(t2,lf[29],lf[87]);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4985,a[2]=t1,a[3]=t3,a[4]=t6,a[5]=((C_word*)t0)[2],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 815  ##sys#check-closure */
t9=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t6,lf[87]);}

/* k4983 in a4974 in k1326 */
static void C_ccall f_4985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4985,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(4));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4997,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_block_size(t2);
/* srfi-69.scm: 819  hash */
t7=t4;
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[3],t6);}

/* k4995 in k4983 in a4974 in k1326 */
static void C_ccall f_4997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4997,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[5],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5012,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_5012(t7,((C_word*)t0)[2],t3);}
else{
t3=(C_word)C_slot(((C_word*)t0)[5],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5054,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_5054(t7,((C_word*)t0)[2],t3);}}

/* loop in k4995 in k4983 in a4974 in k1326 */
static void C_fcall f_5054(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5054,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-69.scm: 832  def */
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5073,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 834  test */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[2],t5);}}

/* k5071 in loop in k4995 in k4983 in a4974 in k1326 */
static void C_ccall f_5073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 836  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5054(t3,((C_word*)t0)[5],t2);}}

/* loop in k4995 in k4983 in a4974 in k1326 */
static void C_fcall f_5012(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5012,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-69.scm: 824  def */
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[3],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_slot(t3,C_fix(1)));}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 828  loop */
t8=t1;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* f_5095 in a4974 in k1326 */
static void C_ccall f_5095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5095,2,t0,t1);}
/* srfi-69.scm: 811  ##sys#signal-hook */
t2=*((C_word*)lf[3]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,t1,lf[80],lf[87],lf[111],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3965 in k1326 */
static void C_ccall f_3967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word ab[45],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3967,2,t0,t1);}
t2=C_mutate((C_word*)lf[87]+1 /* (set! hash-table-ref ...) */,t1);
t3=*((C_word*)lf[30]+1);
t4=C_mutate((C_word*)lf[88]+1 /* (set! hash-table-ref/default ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3969,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=*((C_word*)lf[30]+1);
t6=C_mutate((C_word*)lf[89]+1 /* (set! hash-table-exists? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4075,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=*((C_word*)lf[30]+1);
t8=C_mutate((C_word*)lf[90]+1 /* (set! hash-table-delete! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4183,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[91]+1 /* (set! hash-table-remove! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4314,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[92]+1 /* (set! hash-table-clear! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4410,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate(&lf[94] /* (set! *hash-table-merge! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4426,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[95]+1 /* (set! hash-table-merge! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4491,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[96]+1 /* (set! hash-table-merge ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4503,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[97]+1 /* (set! hash-table->alist ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4519,tmp=(C_word)a,a+=2,tmp));
t15=*((C_word*)lf[36]+1);
t16=C_mutate((C_word*)lf[98]+1 /* (set! alist->hash-table ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4592,a[2]=t15,tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[99]+1 /* (set! hash-table-keys ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4637,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[100]+1 /* (set! hash-table-values ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4702,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[101] /* (set! *hash-table-for-each ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4767,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate(&lf[102] /* (set! *hash-table-fold ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4832,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[103]+1 /* (set! hash-table-fold ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4898,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[104]+1 /* (set! hash-table-for-each ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4910,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[105]+1 /* (set! hash-table-walk ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4922,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[106]+1 /* (set! hash-table-map ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4934,tmp=(C_word)a,a+=2,tmp));
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4957,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t26=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4959,tmp=(C_word)a,a+=2,tmp);
/* srfi-69.scm: 1094 ##sys#register-record-printer */
t27=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t27+1)))(4,t27,t25,lf[29],t26);}

/* a4958 in k3965 in k1326 */
static void C_ccall f_4959(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4959,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4963,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 1097 ##sys#print */
t5=*((C_word*)lf[107]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,lf[109],C_SCHEME_FALSE,t3);}

/* k4961 in a4958 in k3965 in k1326 */
static void C_ccall f_4963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4963,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4966,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(2));
/* srfi-69.scm: 1098 ##sys#print */
t4=*((C_word*)lf[107]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k4964 in k4961 in a4958 in k3965 in k1326 */
static void C_ccall f_4966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 1099 ##sys#print */
t2=*((C_word*)lf[107]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[108],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k4955 in k3965 in k1326 */
static void C_ccall f_4957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* hash-table-map in k3965 in k1326 */
static void C_ccall f_4934(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4934,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[29],lf[106]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4941,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 1088 ##sys#check-closure */
t6=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[106]);}

/* k4939 in hash-table-map in k3965 in k1326 */
static void C_ccall f_4941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4941,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4946,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 1089 *hash-table-fold */
f_4832(((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST);}

/* a4945 in k4939 in hash-table-map in k3965 in k1326 */
static void C_ccall f_4946(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4946,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4954,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 1089 func */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,t3);}

/* k4952 in a4945 in k4939 in hash-table-map in k3965 in k1326 */
static void C_ccall f_4954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4954,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* hash-table-walk in k3965 in k1326 */
static void C_ccall f_4922(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4922,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[29],lf[105]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4929,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 1083 ##sys#check-closure */
t6=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[105]);}

/* k4927 in hash-table-walk in k3965 in k1326 */
static void C_ccall f_4929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 1084 *hash-table-for-each */
f_4767(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* hash-table-for-each in k3965 in k1326 */
static void C_ccall f_4910(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4910,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[29],lf[104]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4917,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 1078 ##sys#check-closure */
t6=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[104]);}

/* k4915 in hash-table-for-each in k3965 in k1326 */
static void C_ccall f_4917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 1079 *hash-table-for-each */
f_4767(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* hash-table-fold in k3965 in k1326 */
static void C_ccall f_4898(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4898,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(t2,lf[29],lf[103]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4905,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 1073 ##sys#check-closure */
t7=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,lf[103]);}

/* k4903 in hash-table-fold in k3965 in k1326 */
static void C_ccall f_4905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 1074 *hash-table-fold */
f_4832(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* *hash-table-fold in k3965 in k1326 */
static void C_fcall f_4832(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4832,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_block_size(t5);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4844,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_4844(t10,t1,C_fix(0),t4);}

/* loop in *hash-table-fold in k3965 in k1326 */
static void C_fcall f_4844(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4844,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4860,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_4860(t8,t1,t4,t3);}}

/* fold2 in loop in *hash-table-fold in k3965 in k1326 */
static void C_fcall f_4860(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4860,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* srfi-69.scm: 1066 loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_4844(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4888,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
t8=(C_word)C_slot(t4,C_fix(1));
/* srfi-69.scm: 1069 func */
t9=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t6,t7,t8,t3);}}

/* k4886 in fold2 in loop in *hash-table-fold in k3965 in k1326 */
static void C_ccall f_4888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 1068 fold2 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4860(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* *hash-table-for-each in k3965 in k1326 */
static void C_fcall f_4767(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4767,NULL,3,t1,t2,t3);}
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4779,a[2]=t3,a[3]=t4,a[4]=t7,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_4779(t9,t1,C_fix(0));}

/* doloop1200 in *hash-table-for-each in k3965 in k1326 */
static void C_fcall f_4779(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4779,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4789,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4802,a[2]=((C_word*)t0)[2],a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_4802(t8,t3,t4);}}

/* loop1207 in doloop1200 in *hash-table-for-each in k3965 in k1326 */
static void C_fcall f_4802(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4802,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4815,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
t6=(C_word)C_slot(t3,C_fix(1));
/* srfi-69.scm: 1054 proc */
t7=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,t6);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k4813 in loop1207 in doloop1200 in *hash-table-for-each in k3965 in k1326 */
static void C_ccall f_4815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4802(t3,((C_word*)t0)[2],t2);}

/* k4787 in doloop1200 in *hash-table-for-each in k3965 in k1326 */
static void C_ccall f_4789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4779(t3,((C_word*)t0)[2],t2);}

/* hash-table-values in k3965 in k1326 */
static void C_ccall f_4702(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4702,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[100]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4717,a[2]=t7,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_4717(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table-values in k3965 in k1326 */
static void C_fcall f_4717(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4717,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4733,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4733(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table-values in k3965 in k1326 */
static void C_fcall f_4733(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4733,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 1036 loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4717(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
/* srfi-69.scm: 1037 loop2 */
t10=t1;
t11=t4;
t12=t7;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* hash-table-keys in k3965 in k1326 */
static void C_ccall f_4637(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4637,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[99]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4652,a[2]=t7,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_4652(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table-keys in k3965 in k1326 */
static void C_fcall f_4652(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4652,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4668,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4668(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table-keys in k3965 in k1326 */
static void C_fcall f_4668(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4668,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 1021 loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4652(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(0));
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
/* srfi-69.scm: 1022 loop2 */
t10=t1;
t11=t4;
t12=t7;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* alist->hash-table in k3965 in k1326 */
static void C_ccall f_4592(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4592r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4592r(t0,t1,t2,t3);}}

static void C_ccall f_4592r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_list_2(t2,lf[98]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4599,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t5,((C_word*)t0)[2],t3);}

/* k4597 in alist->hash-table in k3965 in k1326 */
static void C_ccall f_4599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4599,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4602,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4604,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4604(t6,t2,((C_word*)t0)[2]);}

/* loop1153 in k4597 in alist->hash-table in k3965 in k1326 */
static void C_fcall f_4604(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4604,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_i_check_pair_2(t3,lf[98]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4620,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_slot(t3,C_fix(0));
t7=(C_word)C_slot(t3,C_fix(1));
/* srfi-69.scm: 1005 *hash-table-update!/default */
t8=lf[83];
f_3553(t8,t5,((C_word*)t0)[2],t6,*((C_word*)lf[82]+1),t7);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k4618 in loop1153 in k4597 in alist->hash-table in k3965 in k1326 */
static void C_ccall f_4620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4604(t3,((C_word*)t0)[2],t2);}

/* k4600 in k4597 in alist->hash-table in k3965 in k1326 */
static void C_ccall f_4602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* hash-table->alist in k3965 in k1326 */
static void C_ccall f_4519(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4519,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[97]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4534,a[2]=t7,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_4534(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table->alist in k3965 in k1326 */
static void C_fcall f_4534(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4534,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4550,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4550(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table->alist in k3965 in k1326 */
static void C_fcall f_4550(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4550,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 992  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4534(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(0));
t7=(C_word)C_slot(t5,C_fix(1));
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,t8,t3);
/* srfi-69.scm: 993  loop2 */
t12=t1;
t13=t4;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* hash-table-merge in k3965 in k1326 */
static void C_ccall f_4503(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4503,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[29],lf[96]);
t5=(C_word)C_i_check_structure_2(t3,lf[29],lf[96]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4517,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 978  *hash-table-copy */
t7=lf[76];
f_3145(t7,t6,t2);}

/* k4515 in hash-table-merge in k3965 in k1326 */
static void C_ccall f_4517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 978  *hash-table-merge! */
f_4426(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* hash-table-merge! in k3965 in k1326 */
static void C_ccall f_4491(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4491,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[29],lf[95]);
t5=(C_word)C_i_check_structure_2(t3,lf[29],lf[95]);
/* srfi-69.scm: 973  *hash-table-merge! */
f_4426(t1,t2,t3);}

/* *hash-table-merge! in k3965 in k1326 */
static void C_fcall f_4426(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4426,NULL,3,t1,t2,t3);}
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4438,a[2]=t4,a[3]=t7,a[4]=t2,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_4438(t9,t1,C_fix(0));}

/* doloop1107 in *hash-table-merge! in k3965 in k1326 */
static void C_fcall f_4438(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4438,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4448,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4461,a[2]=((C_word*)t0)[4],a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_4461(t8,t3,t4);}}

/* doloop1112 in doloop1107 in *hash-table-merge! in k3965 in k1326 */
static void C_fcall f_4461(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4461,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4474,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
t6=(C_word)C_slot(t3,C_fix(1));
/* srfi-69.scm: 968  *hash-table-update!/default */
t7=lf[83];
f_3553(t7,t4,((C_word*)t0)[2],t5,*((C_word*)lf[82]+1),t6);}}

/* k4472 in doloop1112 in doloop1107 in *hash-table-merge! in k3965 in k1326 */
static void C_ccall f_4474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4461(t3,((C_word*)t0)[2],t2);}

/* k4446 in doloop1107 in *hash-table-merge! in k3965 in k1326 */
static void C_ccall f_4448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4438(t3,((C_word*)t0)[2],t2);}

/* hash-table-clear! in k3965 in k1326 */
static void C_ccall f_4410(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4410,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[92]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4417,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 955  vector-fill! */
t6=*((C_word*)lf[93]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_SCHEME_END_OF_LIST);}

/* k4415 in hash-table-clear! in k3965 in k1326 */
static void C_ccall f_4417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(2),C_fix(0)));}

/* hash-table-remove! in k3965 in k1326 */
static void C_ccall f_4314(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4314,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[29],lf[91]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4321,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 932  ##sys#check-closure */
t6=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[91]);}

/* k4319 in hash-table-remove! in k3965 in k1326 */
static void C_ccall f_4321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4321,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_block_size(t2);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(2));
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4335,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t8,a[5]=t6,a[6]=((C_word*)t0)[4],a[7]=t3,tmp=(C_word)a,a+=8,tmp));
t10=((C_word*)t8)[1];
f_4335(t10,((C_word*)t0)[2],C_fix(0));}

/* doloop1078 in k4319 in hash-table-remove! in k3965 in k1326 */
static void C_fcall f_4335(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4335,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),((C_word*)((C_word*)t0)[5])[1]));}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4348,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4361,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_4361(t8,t3,C_SCHEME_FALSE,t4);}}

/* loop in doloop1078 in k4319 in hash-table-remove! in k3965 in k1326 */
static void C_fcall f_4361(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4361,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4380,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t5,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
t8=(C_word)C_slot(t4,C_fix(1));
/* srfi-69.scm: 942  func */
t9=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,t7,t8);}}

/* k4378 in loop in doloop1078 in k4319 in hash-table-remove! in k3965 in k1326 */
static void C_ccall f_4380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[9])?(C_word)C_i_setslot(((C_word*)t0)[9],C_fix(1),((C_word*)t0)[8]):(C_word)C_i_setslot(((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[8]));
t3=(C_word)C_u_fixnum_difference(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}
else{
/* srfi-69.scm: 949  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4361(t2,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[8]);}}

/* k4346 in doloop1078 in k4319 in hash-table-remove! in k3965 in k1326 */
static void C_ccall f_4348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4335(t3,((C_word*)t0)[2],t2);}

/* hash-table-delete! in k3965 in k1326 */
static void C_ccall f_4183(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4183,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[29],lf[90]);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_block_size(t5);
t7=(C_word)C_slot(t2,C_fix(4));
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4199,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 896  hash */
t9=t7;
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t3,t6);}

/* k4197 in hash-table-delete! in k3965 in k1326 */
static void C_ccall f_4199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4199,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(C_word)C_slot(((C_word*)t0)[5],t1);
t6=(C_word)C_eqp(((C_word*)t0)[4],t2);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4219,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,f_4219(t7,C_SCHEME_FALSE,t5));}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4266,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t8,a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp));
t10=((C_word*)t8)[1];
f_4266(t10,((C_word*)t0)[2],C_SCHEME_FALSE,t5);}}

/* loop in k4197 in hash-table-delete! in k3965 in k1326 */
static void C_fcall f_4266(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4266,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4285,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t5,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
/* srfi-69.scm: 919  test */
t8=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,((C_word*)t0)[2],t7);}}

/* k4283 in loop in k4197 in hash-table-delete! in k3965 in k1326 */
static void C_ccall f_4285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[10])?(C_word)C_i_setslot(((C_word*)t0)[10],C_fix(1),((C_word*)t0)[9]):(C_word)C_i_setslot(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[9]));
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),((C_word*)t0)[5]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}
else{
/* srfi-69.scm: 926  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4266(t2,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[9]);}}

/* loop in k4197 in hash-table-delete! in k3965 in k1326 */
static C_word C_fcall f_4219(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
if(C_truep((C_word)C_i_nullp(t2))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t3,C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[6],t5);
if(C_truep(t6)){
t7=(C_truep(t1)?(C_word)C_i_setslot(t1,C_fix(1),t4):(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t4));
t8=(C_word)C_i_set_i_slot(((C_word*)t0)[3],C_fix(2),((C_word*)t0)[2]);
return(C_SCHEME_TRUE);}
else{
t10=t2;
t11=t4;
t1=t10;
t2=t11;
goto loop;}}}

/* hash-table-exists? in k3965 in k1326 */
static void C_ccall f_4075(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4075,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[29],lf[89]);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_slot(t2,C_fix(3));
t7=(C_word)C_slot(t2,C_fix(4));
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4091,a[2]=t1,a[3]=t3,a[4]=t5,a[5]=t6,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_block_size(t5);
/* srfi-69.scm: 872  hash */
t10=t7;
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,t3,t9);}

/* k4089 in hash-table-exists? in k3965 in k1326 */
static void C_ccall f_4091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4091,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],((C_word*)t0)[5]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[4],t1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4106,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_4106(t4,t3));}
else{
t3=(C_word)C_slot(((C_word*)t0)[4],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4146,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4146(t7,((C_word*)t0)[2],t3);}}

/* loop in k4089 in hash-table-exists? in k3965 in k1326 */
static void C_fcall f_4146(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4146,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4159,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 884  test */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[2],t5);}}

/* k4157 in loop in k4089 in hash-table-exists? in k3965 in k1326 */
static void C_ccall f_4159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 885  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4146(t3,((C_word*)t0)[4],t2);}}

/* loop in k4089 in hash-table-exists? in k3965 in k1326 */
static C_word C_fcall f_4106(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t4);}
else{
t5=(C_word)C_slot(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}}}

/* hash-table-ref/default in k3965 in k1326 */
static void C_ccall f_3969(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3969,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(t2,lf[29],lf[88]);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t2,C_fix(3));
t8=(C_word)C_slot(t2,C_fix(4));
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3985,a[2]=t1,a[3]=t3,a[4]=t4,a[5]=t6,a[6]=t7,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t10=(C_word)C_block_size(t6);
/* srfi-69.scm: 846  hash */
t11=t8;
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t3,t10);}

/* k3983 in hash-table-ref/default in k3965 in k1326 */
static void C_ccall f_3985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3985,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[5],t1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4000,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_4000(t4,t3));}
else{
t3=(C_word)C_slot(((C_word*)t0)[5],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4039,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_4039(t7,((C_word*)t0)[2],t3);}}

/* loop in k3983 in hash-table-ref/default in k3965 in k1326 */
static void C_fcall f_4039(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4039,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4055,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 861  test */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[2],t5);}}

/* k4053 in loop in k3983 in hash-table-ref/default in k3965 in k1326 */
static void C_ccall f_4055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 863  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4039(t3,((C_word*)t0)[5],t2);}}

/* loop in k3983 in hash-table-ref/default in k3965 in k1326 */
static C_word C_fcall f_4000(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(((C_word*)t0)[3]);}
else{
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return((C_word)C_slot(t2,C_fix(1)));}
else{
t5=(C_word)C_slot(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}}}

/* hash-table-set! in k1326 */
static void C_ccall f_3772(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3772,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(t2,lf[29],lf[85]);
t6=(C_word)C_slot(t2,C_fix(2));
t7=(C_word)C_u_fixnum_plus(t6,C_fix(1));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_slot(t8,C_fix(5));
t11=(C_word)C_slot(t8,C_fix(6));
t12=(C_word)C_block_size(t9);
t13=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3955,a[2]=t11,a[3]=t12,a[4]=t9,a[5]=t8,a[6]=t7,a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[2],a[10]=t1,a[11]=t2,tmp=(C_word)a,a+=12,tmp);
t14=(C_word)C_a_i_times(&a,2,t12,t10);
/* srfi-69.scm: 636  floor */
t15=*((C_word*)lf[79]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t13,t14);}

/* k3953 in hash-table-set! in k1326 */
static void C_ccall f_3955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3955,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3947,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t4=(C_word)C_a_i_times(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
/* srfi-69.scm: 637  floor */
t5=*((C_word*)lf[79]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3945 in k3953 in hash-table-set! in k1326 */
static void C_ccall f_3947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3947,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3800,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3928,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(1073741823)))){
t5=(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],((C_word*)t0)[6]);
t6=t4;
f_3928(t6,(C_truep(t5)?(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[6],t2):C_SCHEME_FALSE));}
else{
t5=t4;
f_3928(t5,C_SCHEME_FALSE);}}

/* k3926 in k3945 in k3953 in hash-table-set! in k1326 */
static void C_fcall f_3928(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-69.scm: 640  hash-table-resize! */
t2=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_3800(2,t2,C_SCHEME_UNDEFINED);}}

/* k3798 in k3945 in k3953 in hash-table-set! in k1326 */
static void C_ccall f_3800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3800,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(4));
t3=(C_word)C_slot(((C_word*)t0)[7],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t5=(C_word)C_block_size(t4);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3815,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t4,tmp=(C_word)a,a+=10,tmp);
/* srfi-69.scm: 780  hash */
t7=t2;
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[4],t5);}

/* k3813 in k3798 in k3945 in k3953 in hash-table-set! in k1326 */
static void C_ccall f_3815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3815,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[9],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3821,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3832,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[9],a[7]=t2,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp));
t8=((C_word*)t6)[1];
f_3832(t8,t3,t2);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3881,a[2]=((C_word*)t0)[6],a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=t2,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp));
t8=((C_word*)t6)[1];
f_3881(t8,t3,t2);}}

/* loop in k3813 in k3798 in k3945 in k3953 in hash-table-set! in k1326 */
static void C_fcall f_3881(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3881,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[8]);
t5=(C_word)C_i_setslot(((C_word*)t0)[7],((C_word*)t0)[6],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_set_i_slot(((C_word*)t0)[5],C_fix(2),((C_word*)t0)[4]));}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3911,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[9],a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 800  test */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[10],t5);}}

/* k3909 in loop in k3813 in k3798 in k3945 in k3953 in hash-table-set! in k1326 */
static void C_ccall f_3911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(1),((C_word*)t0)[4]));}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 802  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3881(t3,((C_word*)t0)[6],t2);}}

/* loop in k3813 in k3798 in k3945 in k3953 in hash-table-set! in k1326 */
static void C_fcall f_3832(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3832,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],((C_word*)t0)[8]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[7]);
t5=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]));}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[9],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_setslot(t3,C_fix(1),((C_word*)t0)[8]));}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 792  loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* k3819 in k3813 in k3798 in k3945 in k3953 in hash-table-set! in k1326 */
static void C_ccall f_3821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[86]+1));}

/* hash-table-update!/default in k1326 */
static void C_ccall f_3760(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3760,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_structure_2(t2,lf[29],lf[84]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3767,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 767  ##sys#check-closure */
t8=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t4,lf[84]);}

/* k3765 in hash-table-update!/default in k1326 */
static void C_ccall f_3767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 768  *hash-table-update!/default */
t2=lf[83];
f_3553(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* *hash-table-update!/default in k1326 */
static void C_fcall f_3553(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3553,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_slot(t2,C_fix(2));
t7=(C_word)C_u_fixnum_plus(t6,C_fix(1));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_slot(t8,C_fix(5));
t11=(C_word)C_slot(t8,C_fix(6));
t12=(C_word)C_block_size(t9);
t13=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3750,a[2]=t11,a[3]=t12,a[4]=t9,a[5]=t8,a[6]=t1,a[7]=t5,a[8]=t4,a[9]=t7,a[10]=t3,a[11]=((C_word*)t0)[2],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t14=(C_word)C_a_i_times(&a,2,t12,t10);
/* srfi-69.scm: 636  floor */
t15=*((C_word*)lf[79]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t13,t14);}

/* k3748 in *hash-table-update!/default in k1326 */
static void C_ccall f_3750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3750,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3742,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_a_i_times(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
/* srfi-69.scm: 637  floor */
t5=*((C_word*)lf[79]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3740 in k3748 in *hash-table-update!/default in k1326 */
static void C_ccall f_3742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3742,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3578,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3723,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(1073741823)))){
t5=(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],((C_word*)t0)[9]);
t6=t4;
f_3723(t6,(C_truep(t5)?(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[9],t2):C_SCHEME_FALSE));}
else{
t5=t4;
f_3723(t5,C_SCHEME_FALSE);}}

/* k3721 in k3740 in k3748 in *hash-table-update!/default in k1326 */
static void C_fcall f_3723(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-69.scm: 640  hash-table-resize! */
t2=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_3578(2,t2,C_SCHEME_UNDEFINED);}}

/* k3576 in k3740 in k3748 in *hash-table-update!/default in k1326 */
static void C_ccall f_3578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3578,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(4));
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t5=(C_word)C_block_size(t4);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3593,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* srfi-69.scm: 735  hash */
t7=t2;
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[6],t5);}

/* k3591 in k3576 in k3740 in k3748 in *hash-table-update!/default in k1326 */
static void C_ccall f_3593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3593,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[10],t1);
t3=(C_word)C_eqp(((C_word*)t0)[9],((C_word*)t0)[8]);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3607,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[10],a[9]=t2,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp));
t7=((C_word*)t5)[1];
f_3607(t7,((C_word*)t0)[2],t2);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3666,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=t2,a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp));
t7=((C_word*)t5)[1];
f_3666(t7,((C_word*)t0)[2],t2);}}

/* loop in k3591 in k3576 in k3740 in k3748 in *hash-table-update!/default in k1326 */
static void C_fcall f_3666(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3666,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3676,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
/* srfi-69.scm: 754  func */
t4=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3699,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 759  test */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[11],t5);}}

/* k3697 in loop in k3591 in k3576 in k3740 in k3748 in *hash-table-update!/default in k1326 */
static void C_ccall f_3699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3699,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3702,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* srfi-69.scm: 760  func */
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 763  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3666(t3,((C_word*)t0)[5],t2);}}

/* k3700 in k3697 in loop in k3591 in k3576 in k3740 in k3748 in *hash-table-update!/default in k1326 */
static void C_ccall f_3702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k3674 in loop in k3591 in k3576 in k3740 in k3748 in *hash-table-update!/default in k1326 */
static void C_ccall f_3676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3676,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* loop in k3591 in k3576 in k3740 in k3748 in *hash-table-update!/default in k1326 */
static void C_fcall f_3607(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(9);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3607,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3617,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* srfi-69.scm: 741  func */
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[10],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3643,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t3,C_fix(1));
/* srfi-69.scm: 747  func */
t8=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 750  loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* k3641 in loop in k3591 in k3576 in k3740 in k3748 in *hash-table-update!/default in k1326 */
static void C_ccall f_3643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k3615 in loop in k3591 in k3576 in k3740 in k3748 in *hash-table-update!/default in k1326 */
static void C_ccall f_3617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3617,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* hash-table-update! in k1326 */
static void C_ccall f_3266(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_3266r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3266r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3266r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3268,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3491,a[2]=t5,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3508,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-func808867 */
t8=t7;
f_3508(t8,t1);}
else{
t8=(C_word)C_u_i_car(t4);
t9=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-thunk809859 */
t10=t6;
f_3491(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
/* body806814 */
t12=t5;
f_3268(t12,t1,t8,t10);}}}

/* def-func808 in hash-table-update! in k1326 */
static void C_fcall f_3508(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3508,NULL,2,t0,t1);}
/* def-thunk809859 */
t2=((C_word*)t0)[2];
f_3491(t2,t1,*((C_word*)lf[82]+1));}

/* def-thunk809 in hash-table-update! in k1326 */
static void C_fcall f_3491(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3491,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(9));
t4=(C_truep(t3)?t3:(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3503,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
/* body806814 */
t5=((C_word*)t0)[2];
f_3268(t5,t1,t2,t4);}

/* f_3503 in def-thunk809 in hash-table-update! in k1326 */
static void C_ccall f_3503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3503,2,t0,t1);}
/* srfi-69.scm: 684  ##sys#signal-hook */
t2=*((C_word*)lf[3]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,t1,lf[80],lf[78],lf[81],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* body806 in hash-table-update! in k1326 */
static void C_fcall f_3268(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3268,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(((C_word*)t0)[4],lf[29],lf[78]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3275,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm: 688  ##sys#check-closure */
t6=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[78]);}

/* k3273 in body806 in hash-table-update! in k1326 */
static void C_ccall f_3275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3275,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3278,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm: 689  ##sys#check-closure */
t3=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],lf[78]);}

/* k3276 in k3273 in body806 in hash-table-update! in k1326 */
static void C_ccall f_3278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3278,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(2));
t3=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t4=((C_word*)t0)[7];
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_slot(t4,C_fix(5));
t7=(C_word)C_slot(t4,C_fix(6));
t8=(C_word)C_block_size(t5);
t9=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3482,a[2]=t7,a[3]=t8,a[4]=t5,a[5]=t4,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=t3,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],a[12]=((C_word*)t0)[7],tmp=(C_word)a,a+=13,tmp);
t10=(C_word)C_a_i_times(&a,2,t8,t6);
/* srfi-69.scm: 636  floor */
t11=*((C_word*)lf[79]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t9,t10);}

/* k3480 in k3276 in k3273 in body806 in hash-table-update! in k1326 */
static void C_ccall f_3482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3482,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3474,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_a_i_times(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
/* srfi-69.scm: 637  floor */
t5=*((C_word*)lf[79]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3472 in k3480 in k3276 in k3273 in body806 in hash-table-update! in k1326 */
static void C_ccall f_3474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3474,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3302,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3455,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(1073741823)))){
t5=(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],((C_word*)t0)[9]);
t6=t4;
f_3455(t6,(C_truep(t5)?(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[9],t2):C_SCHEME_FALSE));}
else{
t5=t4;
f_3455(t5,C_SCHEME_FALSE);}}

/* k3453 in k3472 in k3480 in k3276 in k3273 in body806 in hash-table-update! in k1326 */
static void C_fcall f_3455(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-69.scm: 640  hash-table-resize! */
t2=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_3302(2,t2,C_SCHEME_UNDEFINED);}}

/* k3300 in k3472 in k3480 in k3276 in k3273 in body806 in hash-table-update! in k1326 */
static void C_ccall f_3302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3302,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(4));
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t5=(C_word)C_block_size(t4);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3317,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* srfi-69.scm: 696  hash */
t7=t2;
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[6],t5);}

/* k3315 in k3300 in k3472 in k3480 in k3276 in k3273 in body806 in hash-table-update! in k1326 */
static void C_ccall f_3317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3317,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[10],t1);
t3=(C_word)C_eqp(((C_word*)t0)[9],((C_word*)t0)[8]);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3331,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[10],a[9]=t2,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp));
t7=((C_word*)t5)[1];
f_3331(t7,((C_word*)t0)[2],t2);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3394,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=t2,a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp));
t7=((C_word*)t5)[1];
f_3394(t7,((C_word*)t0)[2],t2);}}

/* loop in k3315 in k3300 in k3472 in k3480 in k3276 in k3273 in body806 in hash-table-update! in k1326 */
static void C_fcall f_3394(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3394,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3404,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3422,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 715  thunk */
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3431,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 720  test */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[11],t5);}}

/* k3429 in loop in k3315 in k3300 in k3472 in k3480 in k3276 in k3273 in body806 in hash-table-update! in k1326 */
static void C_ccall f_3431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3431,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3434,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* srfi-69.scm: 721  func */
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 724  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3394(t3,((C_word*)t0)[5],t2);}}

/* k3432 in k3429 in loop in k3315 in k3300 in k3472 in k3480 in k3276 in k3273 in body806 in hash-table-update! in k1326 */
static void C_ccall f_3434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k3420 in loop in k3315 in k3300 in k3472 in k3480 in k3276 in k3273 in body806 in hash-table-update! in k1326 */
static void C_ccall f_3422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 715  func */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3402 in loop in k3315 in k3300 in k3472 in k3480 in k3276 in k3273 in body806 in hash-table-update! in k1326 */
static void C_ccall f_3404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3404,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* loop in k3315 in k3300 in k3472 in k3480 in k3276 in k3273 in body806 in hash-table-update! in k1326 */
static void C_fcall f_3331(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(13);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3331,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3341,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3359,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 702  thunk */
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[10],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3371,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t3,C_fix(1));
/* srfi-69.scm: 708  func */
t8=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 711  loop */
t12=t1;
t13=t6;
t1=t12;
t2=t13;
goto loop;}}}

/* k3369 in loop in k3315 in k3300 in k3472 in k3480 in k3276 in k3273 in body806 in hash-table-update! in k1326 */
static void C_ccall f_3371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k3357 in loop in k3315 in k3300 in k3472 in k3480 in k3276 in k3273 in body806 in hash-table-update! in k1326 */
static void C_ccall f_3359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 702  func */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3339 in loop in k3315 in k3300 in k3472 in k3480 in k3276 in k3273 in body806 in hash-table-update! in k1326 */
static void C_ccall f_3341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3341,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* hash-table-copy in k1326 */
static void C_ccall f_3257(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3257,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[77]);
/* srfi-69.scm: 669  *hash-table-copy */
t4=lf[76];
f_3145(t4,t1,t2);}

/* *hash-table-copy in k1326 */
static void C_fcall f_3145(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3145,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_block_size(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3155,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 649  make-vector */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,C_SCHEME_END_OF_LIST);}

/* k3153 in *hash-table-copy in k1326 */
static void C_ccall f_3155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3155,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3160,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_3160(t5,((C_word*)t0)[2],C_fix(0));}

/* doloop777 in k3153 in *hash-table-copy in k1326 */
static void C_fcall f_3160(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3160,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(4));
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t6=(C_word)C_slot(((C_word*)t0)[5],C_fix(5));
t7=(C_word)C_slot(((C_word*)t0)[5],C_fix(6));
t8=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t9=(C_word)C_slot(((C_word*)t0)[5],C_fix(8));
t10=(C_word)C_slot(((C_word*)t0)[5],C_fix(9));
/* srfi-69.scm: 652  *make-hash-table */
t11=lf[28];
f_2557(t11,t1,t3,t4,t5,t6,t7,t10,(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3216,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3222,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_3222(t8,t3,t4);}}

/* copy-loop in doloop777 in k3153 in *hash-table-copy in k1326 */
static void C_fcall f_3222(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3222,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3243,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 665  copy-loop */
t10=t7;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* k3241 in copy-loop in doloop777 in k3153 in *hash-table-copy in k1326 */
static void C_ccall f_3243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3243,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3214 in doloop777 in k3153 in *hash-table-copy in k1326 */
static void C_ccall f_3216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3160(t4,((C_word*)t0)[2],t3);}

/* hash-table-resize! in k1326 */
static void C_ccall f_3119(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3119,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_times(t4,C_fix(2));
t6=(C_word)C_i_fixnum_min(C_fix(1073741823),t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3126,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 624  hash-table-canonical-length */
f_2527(t7,lf[24],t6);}

/* k3124 in hash-table-resize! in k1326 */
static void C_ccall f_3126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3126,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3129,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 625  make-vector */
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,C_SCHEME_END_OF_LIST);}

/* k3127 in k3124 in hash-table-resize! in k1326 */
static void C_ccall f_3129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3129,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3132,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
t4=((C_word*)t0)[2];
t5=t1;
t6=(C_word)C_block_size(t4);
t7=(C_word)C_block_size(t5);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3052,a[2]=t7,a[3]=t3,a[4]=t5,a[5]=t4,a[6]=t9,a[7]=t6,tmp=(C_word)a,a+=8,tmp));
t11=((C_word*)t9)[1];
f_3052(t11,t2,C_fix(0));}

/* doloop744 in k3127 in k3124 in hash-table-resize! in k1326 */
static void C_fcall f_3052(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3052,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3062,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3075,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3075(t8,t3,t4);}}

/* loop in doloop744 in k3127 in k3124 in hash-table-resize! in k1326 */
static void C_fcall f_3075(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3075,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3091,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm: 615  hash */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,((C_word*)t0)[2]);}}

/* k3089 in loop in doloop744 in k3127 in k3124 in hash-table-resize! in k1326 */
static void C_ccall f_3091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3091,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_slot(((C_word*)t0)[5],t1);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=(C_word)C_i_setslot(((C_word*)t0)[5],t1,t5);
t7=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 618  loop */
t8=((C_word*)((C_word*)t0)[3])[1];
f_3075(t8,((C_word*)t0)[2],t7);}

/* k3060 in doloop744 in k3127 in k3124 in hash-table-resize! in k1326 */
static void C_ccall f_3062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3052(t3,((C_word*)t0)[2],t2);}

/* k3130 in k3127 in k3124 in hash-table-resize! in k1326 */
static void C_ccall f_3132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2]));}

/* hash-table-initial in k1326 */
static void C_ccall f_3025(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3025,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[74]);
t4=(C_word)C_slot(t2,C_fix(9));
if(C_truep(t4)){
/* srfi-69.scm: 602  thunk */
t5=t4;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* hash-table-has-initial? in k1326 */
static void C_ccall f_3013(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3013,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[73]);
t4=(C_word)C_slot(t2,C_fix(9));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* hash-table-weak-values in k1326 */
static void C_ccall f_3004(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3004,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[72]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(8)));}

/* hash-table-weak-keys in k1326 */
static void C_ccall f_2995(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2995,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[71]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(7)));}

/* hash-table-max-load in k1326 */
static void C_ccall f_2986(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2986,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[70]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(6)));}

/* hash-table-min-load in k1326 */
static void C_ccall f_2977(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2977,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[69]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(5)));}

/* hash-table-hash-function in k1326 */
static void C_ccall f_2968(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2968,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[68]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(4)));}

/* hash-table-equivalence-function in k1326 */
static void C_ccall f_2959(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2959,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[67]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(3)));}

/* hash-table-size in k1326 */
static void C_ccall f_2950(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2950,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[66]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(2)));}

/* hash-table? in k1326 */
static void C_ccall f_2944(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2944,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[29]));}

/* make-hash-table in k1326 */
static void C_ccall f_2581(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+41)){
C_save_and_reclaim((void*)tr2r,(void*)f_2581r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2581r(t0,t1,t2);}}

static void C_ccall f_2581r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a=C_alloc(41);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=*((C_word*)lf[32]+1);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(307);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=lf[37];
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=lf[38];
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2583,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t6,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t18=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2659,a[2]=t4,a[3]=t2,a[4]=t17,a[5]=t12,a[6]=t16,a[7]=t14,a[8]=t8,a[9]=t6,a[10]=t1,a[11]=t10,tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t4)[1]))){
t19=t18;
f_2659(t19,C_SCHEME_UNDEFINED);}
else{
t19=(C_word)C_u_i_car(((C_word*)t4)[1]);
t20=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2934,a[2]=t4,a[3]=t19,a[4]=t6,a[5]=t18,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 481  keyword? */
t21=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t21+1)))(3,t21,t20,t19);}}

/* k2932 in make-hash-table in k1326 */
static void C_ccall f_2934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2934,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_2659(t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2937,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 482  ##sys#check-closure */
t3=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],lf[36]);}}

/* k2935 in k2932 in make-hash-table in k1326 */
static void C_ccall f_2937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t0)[4]);
t3=(C_word)C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_2659(t5,t4);}

/* k2657 in make-hash-table in k1326 */
static void C_fcall f_2659(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2659,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2662,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t3=t2;
f_2662(t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_u_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2914,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 487  keyword? */
t5=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}}

/* k2912 in k2657 in make-hash-table in k1326 */
static void C_ccall f_2914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2914,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_2662(t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2917,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 488  ##sys#check-closure */
t3=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],lf[36]);}}

/* k2915 in k2912 in k2657 in make-hash-table in k1326 */
static void C_ccall f_2917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t0)[4]);
t3=(C_word)C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_2662(t5,t4);}

/* k2660 in k2657 in make-hash-table in k1326 */
static void C_fcall f_2662(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2662,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2665,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t3=t2;
f_2665(t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_u_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2882,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[11],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 493  keyword? */
t5=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}}

/* k2880 in k2660 in k2657 in make-hash-table in k1326 */
static void C_ccall f_2882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2882,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_2665(t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[36]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2888,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),((C_word*)t0)[4]))){
t4=t3;
f_2888(2,t4,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 496  error */
t4=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[36],lf[64],((C_word*)t0)[4]);}}}

/* k2886 in k2880 in k2660 in k2657 in make-hash-table in k1326 */
static void C_ccall f_2888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_fixnum_min(*((C_word*)lf[47]+1),((C_word*)t0)[5]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=(C_word)C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_2665(t6,t5);}

/* k2663 in k2660 in k2657 in make-hash-table in k1326 */
static void C_fcall f_2665(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2665,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2668,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2700,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t4,a[9]=((C_word*)t0)[3],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_2700(t6,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in k2663 in k2660 in k2657 in make-hash-table in k1326 */
static void C_fcall f_2700(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2700,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2711,a[2]=((C_word*)t0)[9],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2721,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t3,a[10]=t1,a[11]=((C_word*)t0)[8],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
/* srfi-69.scm: 506  keyword? */
t6=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}}

/* k2719 in loop in k2663 in k2660 in k2657 in make-hash-table in k1326 */
static void C_ccall f_2721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2721,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[12],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2727,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=t3;
f_2727(2,t4,(C_word)C_u_i_car(t2));}
else{
/* srfi-69.scm: 510  invarg-err */
t4=((C_word*)t0)[2];
f_2711(t4,t3,lf[62]);}}
else{
/* srfi-69.scm: 542  invarg-err */
t2=((C_word*)t0)[2];
f_2711(t2,((C_word*)t0)[10],lf[63]);}}

/* k2725 in k2719 in loop in k2663 in k2660 in k2657 in make-hash-table in k1326 */
static void C_ccall f_2727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2730,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[9],lf[43]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2743,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 513  ##sys#check-closure */
t5=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t1,lf[36]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[9],lf[45]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2753,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 516  ##sys#check-closure */
t6=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t1,lf[36]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[9],lf[46]);
if(C_truep(t5)){
t6=(C_word)C_i_check_exact_2(t1,lf[36]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2766,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),t1))){
t8=t7;
f_2766(2,t8,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 521  error */
t8=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,lf[36],lf[48],t1);}}
else{
t6=(C_word)C_eqp(((C_word*)t0)[9],lf[49]);
if(C_truep(t6)){
t7=C_mutate(((C_word *)((C_word*)t0)[5])+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2784,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t8=t2;
f_2730(2,t8,t7);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[9],lf[50]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2794,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 526  ##sys#check-inexact */
t9=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t1,lf[36]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[9],lf[55]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2819,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 531  ##sys#check-inexact */
t10=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t1,lf[36]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[9],lf[59]);
if(C_truep(t9)){
t10=(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE);
t11=C_SCHEME_UNDEFINED;
t12=t2;
f_2730(2,t12,t11);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[9],lf[60]);
if(C_truep(t10)){
t11=(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE);
t12=C_SCHEME_UNDEFINED;
t13=t2;
f_2730(2,t13,t12);}
else{
/* srfi-69.scm: 540  invarg-err */
t11=((C_word*)t0)[2];
f_2711(t11,t2,lf[61]);}}}}}}}}}

/* k2817 in k2725 in k2719 in loop in k2663 in k2660 in k2657 in make-hash-table in k1326 */
static void C_ccall f_2819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2819,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2822,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_flonum_lessp(lf[56],((C_word*)t0)[3]);
t4=(C_truep(t3)?(C_word)C_flonum_lessp(((C_word*)t0)[3],lf[57]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t2;
f_2822(2,t5,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 533  error */
t5=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,lf[36],lf[58],((C_word*)t0)[3]);}}

/* k2820 in k2817 in k2725 in k2719 in loop in k2663 in k2660 in k2657 in make-hash-table in k1326 */
static void C_ccall f_2822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_2730(2,t3,t2);}

/* k2792 in k2725 in k2719 in loop in k2663 in k2660 in k2657 in make-hash-table in k1326 */
static void C_ccall f_2794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2794,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2797,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_flonum_lessp(lf[51],((C_word*)t0)[3]);
t4=(C_truep(t3)?(C_word)C_flonum_lessp(((C_word*)t0)[3],lf[52]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t2;
f_2797(2,t5,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 528  error */
t5=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,lf[36],lf[53],((C_word*)t0)[3]);}}

/* k2795 in k2792 in k2725 in k2719 in loop in k2663 in k2660 in k2657 in make-hash-table in k1326 */
static void C_ccall f_2797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_2730(2,t3,t2);}

/* f_2784 in k2725 in k2719 in loop in k2663 in k2660 in k2657 in make-hash-table in k1326 */
static void C_ccall f_2784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2784,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2764 in k2725 in k2719 in loop in k2663 in k2660 in k2657 in make-hash-table in k1326 */
static void C_ccall f_2766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_fixnum_min(*((C_word*)lf[47]+1),((C_word*)t0)[4]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_2730(2,t4,t3);}

/* k2751 in k2725 in k2719 in loop in k2663 in k2660 in k2657 in make-hash-table in k1326 */
static void C_ccall f_2753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_2730(2,t3,t2);}

/* k2741 in k2725 in k2719 in loop in k2663 in k2660 in k2657 in make-hash-table in k1326 */
static void C_ccall f_2743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_2730(2,t3,t2);}

/* k2728 in k2725 in k2719 in loop in k2663 in k2660 in k2657 in make-hash-table in k1326 */
static void C_ccall f_2730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 541  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2700(t3,((C_word*)t0)[2],t2);}

/* invarg-err in loop in k2663 in k2660 in k2657 in make-hash-table in k1326 */
static void C_fcall f_2711(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2711,NULL,3,t0,t1,t2);}
/* srfi-69.scm: 505  error */
t3=*((C_word*)lf[41]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t1,lf[36],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2666 in k2663 in k2660 in k2657 in make-hash-table in k1326 */
static void C_ccall f_2668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2668,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2671,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_flonum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[5])[1]))){
/* srfi-69.scm: 545  error */
t3=*((C_word*)lf[41]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[36],lf[42],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=t2;
f_2671(2,t3,C_SCHEME_UNDEFINED);}}

/* k2669 in k2666 in k2663 in k2660 in k2657 in make-hash-table in k1326 */
static void C_ccall f_2671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2671,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* srfi-69.scm: 547  hash-table-canonical-length */
f_2527(t2,lf[24],((C_word*)((C_word*)t0)[9])[1]);}

/* k2673 in k2669 in k2666 in k2663 in k2660 in k2657 in make-hash-table in k1326 */
static void C_ccall f_2675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2675,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2678,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t4=t3;
f_2678(t4,C_SCHEME_UNDEFINED);}
else{
t4=f_2583(((C_word*)t0)[2]);
if(C_truep(t4)){
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,t4);
t6=t3;
f_2678(t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2691,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 554  warning */
t6=*((C_word*)lf[39]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,lf[36],lf[40]);}}}

/* k2689 in k2673 in k2669 in k2666 in k2663 in k2660 in k2657 in make-hash-table in k1326 */
static void C_ccall f_2691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[17]+1));
t3=((C_word*)t0)[2];
f_2678(t3,t2);}

/* k2676 in k2673 in k2669 in k2666 in k2663 in k2660 in k2657 in make-hash-table in k1326 */
static void C_fcall f_2678(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 557  *make-hash-table */
t2=lf[28];
f_2557(t2,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1],C_SCHEME_END_OF_LIST);}

/* hash-for-test in make-hash-table in k1326 */
static C_word C_fcall f_2583(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
t1=(C_word)C_eqp(((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);
t2=(C_truep(t1)?t1:(C_word)C_eqp(*((C_word*)lf[30]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t2)){
return(*((C_word*)lf[13]+1));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],((C_word*)((C_word*)t0)[7])[1]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(*((C_word*)lf[31]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t4)){
return(*((C_word*)lf[15]+1));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],((C_word*)((C_word*)t0)[7])[1]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(*((C_word*)lf[32]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t6)){
return(*((C_word*)lf[17]+1));}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(*((C_word*)lf[33]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t8)){
return(*((C_word*)lf[19]+1));}
else{
t9=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)((C_word*)t0)[7])[1]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(*((C_word*)lf[34]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t10)){
return(*((C_word*)lf[23]+1));}
else{
t11=(C_word)C_eqp(((C_word*)t0)[2],((C_word*)((C_word*)t0)[7])[1]);
t12=(C_truep(t11)?t11:(C_word)C_eqp(*((C_word*)lf[35]+1),((C_word*)((C_word*)t0)[7])[1]));
return((C_truep(t12)?*((C_word*)lf[2]+1):C_SCHEME_FALSE));}}}}}}

/* *make-hash-table in k1326 */
static void C_fcall f_2557(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2557,NULL,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2561,a[2]=t7,a[3]=t6,a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_nullp(t8))){
/* srfi-69.scm: 429  make-vector */
t10=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t4,C_SCHEME_END_OF_LIST);}
else{
t10=t9;
f_2561(2,t10,(C_word)C_u_i_car(t8));}}

/* k2559 in *make-hash-table in k1326 */
static void C_ccall f_2561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2561,2,t0,t1);}
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,10,lf[29],t1,C_fix(0),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]));}

/* hash-table-canonical-length in k1326 */
static void C_fcall f_2527(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2527,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2533,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_2533(t4,t2));}

/* loop in hash-table-canonical-length in k1326 */
static C_word C_fcall f_2533(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]);
t5=(C_truep(t4)?t4:(C_word)C_i_nullp(t3));
if(C_truep(t5)){
return(t2);}
else{
t7=t3;
t1=t7;
goto loop;}}

/* string-ci-hash in k1326 */
static void C_ccall f_2403(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr3r,(void*)f_2403r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2403r(t0,t1,t2,t3);}}

static void C_ccall f_2403r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a=C_alloc(14);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t8=(C_word)C_i_check_string_2(t2,lf[22]);
t9=(C_word)C_i_check_exact_2(t5,lf[22]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2419,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t7))){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2440,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2459,a[2]=t11,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2468,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-start500513 */
t14=t13;
f_2468(t14,t10);}
else{
t14=(C_word)C_u_i_car(t7);
t15=(C_word)C_slot(t7,C_fix(1));
if(C_truep((C_word)C_i_nullp(t15))){
/* def-end501511 */
t16=t12;
f_2459(t16,t10,t14);}
else{
t16=(C_word)C_u_i_car(t15);
t17=(C_word)C_slot(t15,C_fix(1));
/* body498506 */
t18=t11;
f_2440(t18,t10,t14,t16);}}}
else{
t11=t10;
f_2419(2,t11,t2);}}

/* def-start500 in string-ci-hash in k1326 */
static void C_fcall f_2468(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2468,NULL,2,t0,t1);}
/* def-end501511 */
t2=((C_word*)t0)[2];
f_2459(t2,t1,C_fix(0));}

/* def-end501 in string-ci-hash in k1326 */
static void C_fcall f_2459(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2459,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(((C_word*)t0)[3]);
/* body498506 */
t4=((C_word*)t0)[2];
f_2440(t4,t1,t2,t3);}

/* body498 in string-ci-hash in k1326 */
static void C_fcall f_2440(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2440,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2444,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_block_size(((C_word*)t0)[2]);
/* srfi-69.scm: 377  ##sys#check-range */
t6=*((C_word*)lf[21]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t4,t2,C_fix(0),t5,lf[23]);}

/* k2442 in body498 in string-ci-hash in k1326 */
static void C_ccall f_2444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2444,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2447,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* srfi-69.scm: 378  ##sys#check-range */
t4=*((C_word*)lf[21]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,((C_word*)t0)[2],C_fix(0),t3,lf[23]);}

/* k2445 in k2442 in body498 in string-ci-hash in k1326 */
static void C_ccall f_2447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 379  ##sys#substring */
t2=*((C_word*)lf[20]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2417 in string-ci-hash in k1326 */
static void C_ccall f_2419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_hash_string_ci(t1);
t3=(C_word)C_fixnum_lessp(t2,C_fix(0));
t4=(C_truep(t3)?(C_word)C_u_fixnum_negate(t2):t2);
t5=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_fixnum_modulo(t5,((C_word*)t0)[2]));}

/* string-hash in k1326 */
static void C_ccall f_2281(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr3r,(void*)f_2281r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2281r(t0,t1,t2,t3);}}

static void C_ccall f_2281r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a=C_alloc(14);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t8=(C_word)C_i_check_string_2(t2,lf[19]);
t9=(C_word)C_i_check_exact_2(t5,lf[19]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2297,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t7))){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2318,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2337,a[2]=t11,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2346,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-start446459 */
t14=t13;
f_2346(t14,t10);}
else{
t14=(C_word)C_u_i_car(t7);
t15=(C_word)C_slot(t7,C_fix(1));
if(C_truep((C_word)C_i_nullp(t15))){
/* def-end447457 */
t16=t12;
f_2337(t16,t10,t14);}
else{
t16=(C_word)C_u_i_car(t15);
t17=(C_word)C_slot(t15,C_fix(1));
/* body444452 */
t18=t11;
f_2318(t18,t10,t14,t16);}}}
else{
t11=t10;
f_2297(2,t11,t2);}}

/* def-start446 in string-hash in k1326 */
static void C_fcall f_2346(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2346,NULL,2,t0,t1);}
/* def-end447457 */
t2=((C_word*)t0)[2];
f_2337(t2,t1,C_fix(0));}

/* def-end447 in string-hash in k1326 */
static void C_fcall f_2337(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2337,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(((C_word*)t0)[3]);
/* body444452 */
t4=((C_word*)t0)[2];
f_2318(t4,t1,t2,t3);}

/* body444 in string-hash in k1326 */
static void C_fcall f_2318(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2318,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2322,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_block_size(((C_word*)t0)[2]);
/* srfi-69.scm: 365  ##sys#check-range */
t6=*((C_word*)lf[21]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t4,t2,C_fix(0),t5,lf[19]);}

/* k2320 in body444 in string-hash in k1326 */
static void C_ccall f_2322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2322,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2325,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* srfi-69.scm: 366  ##sys#check-range */
t4=*((C_word*)lf[21]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,((C_word*)t0)[2],C_fix(0),t3,lf[19]);}

/* k2323 in k2320 in body444 in string-hash in k1326 */
static void C_ccall f_2325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 367  ##sys#substring */
t2=*((C_word*)lf[20]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2295 in string-hash in k1326 */
static void C_ccall f_2297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_hash_string(t1);
t3=(C_word)C_fixnum_lessp(t2,C_fix(0));
t4=(C_truep(t3)?(C_word)C_u_fixnum_negate(t2):t2);
t5=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_fixnum_modulo(t5,((C_word*)t0)[2]));}

/* equal?-hash in k1326 */
static void C_ccall f_2239(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2239r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2239r(t0,t1,t2,t3);}}

static void C_ccall f_2239r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_exact_2(t5,lf[18]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2249,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 353  *equal?-hash */
f_1905(t7,t2);}

/* k2247 in equal?-hash in k1326 */
static void C_ccall f_2249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_lessp(t1,C_fix(0));
t3=(C_truep(t2)?(C_word)C_u_fixnum_negate(t1):t1);
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}

/* *equal?-hash in k1326 */
static void C_fcall f_1905(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1905,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1908,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1973,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2004,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
/* srfi-69.scm: 349  recursive-hash */
t12=((C_word*)t8)[1];
f_2004(t12,t1,t2,C_fix(0));}

/* recursive-hash in *equal?-hash in k1326 */
static void C_fcall f_2004(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2004,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(4)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(99));}
else{
if(C_truep((C_word)C_fixnump(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
if(C_truep((C_word)C_charp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fix((C_word)C_character_code(t2)));}
else{
switch(t2){
case C_SCHEME_TRUE:
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(256));
case C_SCHEME_FALSE:
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(257));
default:
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(258));}
else{
if(C_truep((C_word)C_eofp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(259));}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_hash_string(t5));}
else{
if(C_truep((C_word)C_i_numberp(t2))){
t4=t2;
if(C_truep((C_word)C_i_flonump(t4))){
t5=(C_word)C_subbyte(t4,C_fix(7));
t6=(C_word)C_subbyte(t4,C_fix(6));
t7=(C_word)C_subbyte(t4,C_fix(5));
t8=(C_word)C_subbyte(t4,C_fix(4));
t9=(C_word)C_subbyte(t4,C_fix(3));
t10=(C_word)C_subbyte(t4,C_fix(2));
t11=(C_word)C_subbyte(t4,C_fix(1));
t12=(C_word)C_subbyte(t4,C_fix(0));
t13=(C_word)C_fixnum_shift_left(t12,C_fix(1));
t14=(C_word)C_u_fixnum_plus(t11,t13);
t15=(C_word)C_fixnum_shift_left(t14,C_fix(1));
t16=(C_word)C_u_fixnum_plus(t10,t15);
t17=(C_word)C_fixnum_shift_left(t16,C_fix(1));
t18=(C_word)C_u_fixnum_plus(t9,t17);
t19=(C_word)C_fixnum_shift_left(t18,C_fix(1));
t20=(C_word)C_u_fixnum_plus(t8,t19);
t21=(C_word)C_fixnum_shift_left(t20,C_fix(1));
t22=(C_word)C_u_fixnum_plus(t7,t21);
t23=(C_word)C_fixnum_shift_left(t22,C_fix(1));
t24=(C_word)C_u_fixnum_plus(t6,t23);
t25=(C_word)C_fixnum_shift_left(t24,C_fix(1));
t26=(C_word)C_u_fixnum_plus(t5,t25);
t27=t1;
((C_proc2)(void*)(*((C_word*)t27+1)))(2,t27,(C_word)C_fixnum_times(C_fix(331804471),t26));}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2141,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 165  ##sys#number-hash-hook */
t6=*((C_word*)lf[0]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}}
else{
t4=t2;
if(C_truep((C_word)C_blockp(t4))){
t5=t2;
if(C_truep((C_word)C_byteblockp(t5))){
t6=t2;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_hash_string(t6));}
else{
if(C_truep((C_word)C_i_listp(t2))){
t6=t2;
t7=(C_word)C_i_length(t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2167,a[2]=t7,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_slot(t6,C_fix(0));
/* srfi-69.scm: 285  recursive-atomic-hash */
t10=((C_word*)((C_word*)t0)[3])[1];
f_1973(t10,t8,t9,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t6=t2;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2196,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_slot(t6,C_fix(0));
/* srfi-69.scm: 288  recursive-atomic-hash */
t9=((C_word*)((C_word*)t0)[3])[1];
f_1973(t9,t7,t8,t3);}
else{
t6=t2;
if(C_truep((C_word)C_portp(t6))){
t7=t2;
t8=(C_word)C_peek_fixnum(t7,C_fix(0));
t9=(C_word)C_fixnum_shift_left(t8,C_fix(4));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2217,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 293  input-port? */
t11=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,t7);}
else{
t7=t2;
if(C_truep((C_word)C_specialp(t7))){
t8=t2;
t9=(C_word)C_peek_fixnum(t8,C_fix(0));
/* srfi-69.scm: 298  vector-hash */
t10=((C_word*)((C_word*)t0)[2])[1];
f_1908(t10,t1,t8,t9,t3,C_fix(1));}
else{
t8=t2;
/* srfi-69.scm: 301  vector-hash */
t9=((C_word*)((C_word*)t0)[2])[1];
f_1908(t9,t1,t8,C_fix(0),t3,C_fix(0));}}}}}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_fix(262));}}}}}}}}}}

/* k2215 in recursive-hash in *equal?-hash in k1326 */
static void C_ccall f_2217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?C_fix(260):C_fix(261));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_fixnum_plus(((C_word*)t0)[2],t2));}

/* k2194 in recursive-hash in *equal?-hash in k1326 */
static void C_ccall f_2196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2196,2,t0,t1);}
t2=(C_word)C_fixnum_shift_left(t1,C_fix(16));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2188,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 289  recursive-atomic-hash */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1973(t5,t3,t4,((C_word*)t0)[2]);}

/* k2186 in k2194 in recursive-hash in *equal?-hash in k1326 */
static void C_ccall f_2188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_fixnum_plus(((C_word*)t0)[2],t1));}

/* k2165 in recursive-hash in *equal?-hash in k1326 */
static void C_ccall f_2167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_fixnum_plus(((C_word*)t0)[2],t1));}

/* k2139 in recursive-hash in *equal?-hash in k1326 */
static void C_ccall f_2141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fix(t1));}

/* recursive-atomic-hash in *equal?-hash in k1326 */
static void C_fcall f_1973(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1973,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_i_not((C_word)C_blockp(t4));
t6=(C_truep(t5)?t5:(C_word)C_i_symbolp(t4));
t7=(C_truep(t6)?t6:(C_word)C_i_numberp(t4));
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1989,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t7)){
t9=t8;
f_1989(t9,t7);}
else{
t9=t2;
t10=t8;
f_1989(t10,(C_word)C_byteblockp(t9));}}

/* k1987 in recursive-atomic-hash in *equal?-hash in k1326 */
static void C_fcall f_1989(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* srfi-69.scm: 323  recursive-hash */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2004(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(99));}}

/* vector-hash in *equal?-hash in k1326 */
static void C_fcall f_1908(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1908,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_block_size(t2);
t7=(C_word)C_u_fixnum_plus(t6,t3);
t8=(C_word)C_i_fixnum_min(C_fix(4),t6);
t9=(C_word)C_u_fixnum_difference(t8,t5);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1925,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=t11,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_1925(t13,t1,t7,t5,t9);}

/* loop in vector-hash in *equal?-hash in k1326 */
static void C_fcall f_1925(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1925,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}
else{
t6=(C_word)C_fixnum_shift_left(t2,C_fix(4));
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1959,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_slot(((C_word*)t0)[4],t3);
t9=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 315  recursive-hash */
t10=((C_word*)((C_word*)t0)[2])[1];
f_2004(t10,t7,t8,t9);}}

/* k1957 in loop in vector-hash in *equal?-hash in k1326 */
static void C_ccall f_1959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t2);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t5=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 313  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1925(t6,((C_word*)t0)[2],t3,t4,t5);}

/* eqv?-hash in k1326 */
static void C_ccall f_1864(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1864r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1864r(t0,t1,t2,t3);}}

static void C_ccall f_1864r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word *a=C_alloc(7);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_exact_2(t5,lf[15]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1874,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t8=t7;
f_1874(2,t8,t2);}
else{
if(C_truep((C_word)C_charp(t2))){
t8=t7;
f_1874(2,t8,(C_word)C_fix((C_word)C_character_code(t2)));}
else{
switch(t2){
case C_SCHEME_TRUE:
t8=t7;
f_1874(2,t8,C_fix(256));
case C_SCHEME_FALSE:
t8=t7;
f_1874(2,t8,C_fix(257));
default:
if(C_truep((C_word)C_i_nullp(t2))){
t8=t7;
f_1874(2,t8,C_fix(258));}
else{
if(C_truep((C_word)C_eofp(t2))){
t8=t7;
f_1874(2,t8,C_fix(259));}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t8=(C_word)C_slot(t2,C_fix(1));
t9=t7;
f_1874(2,t9,(C_word)C_hash_string(t8));}
else{
if(C_truep((C_word)C_i_numberp(t2))){
if(C_truep((C_word)C_i_flonump(t2))){
t8=(C_word)C_subbyte(t2,C_fix(7));
t9=(C_word)C_subbyte(t2,C_fix(6));
t10=(C_word)C_subbyte(t2,C_fix(5));
t11=(C_word)C_subbyte(t2,C_fix(4));
t12=(C_word)C_subbyte(t2,C_fix(3));
t13=(C_word)C_subbyte(t2,C_fix(2));
t14=(C_word)C_subbyte(t2,C_fix(1));
t15=(C_word)C_subbyte(t2,C_fix(0));
t16=(C_word)C_fixnum_shift_left(t15,C_fix(1));
t17=(C_word)C_u_fixnum_plus(t14,t16);
t18=(C_word)C_fixnum_shift_left(t17,C_fix(1));
t19=(C_word)C_u_fixnum_plus(t13,t18);
t20=(C_word)C_fixnum_shift_left(t19,C_fix(1));
t21=(C_word)C_u_fixnum_plus(t12,t20);
t22=(C_word)C_fixnum_shift_left(t21,C_fix(1));
t23=(C_word)C_u_fixnum_plus(t11,t22);
t24=(C_word)C_fixnum_shift_left(t23,C_fix(1));
t25=(C_word)C_u_fixnum_plus(t10,t24);
t26=(C_word)C_fixnum_shift_left(t25,C_fix(1));
t27=(C_word)C_u_fixnum_plus(t9,t26);
t28=(C_word)C_fixnum_shift_left(t27,C_fix(1));
t29=(C_word)C_u_fixnum_plus(t8,t28);
t30=t7;
f_1874(2,t30,(C_word)C_fixnum_times(C_fix(331804471),t29));}
else{
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1853,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 165  ##sys#number-hash-hook */
t9=*((C_word*)lf[0]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}}
else{
if(C_truep((C_word)C_blockp(t2))){
/* srfi-69.scm: 184  *equal?-hash */
f_1905(t7,t2);}
else{
t8=t7;
f_1874(2,t8,C_fix(262));}}}}}}}}}

/* k1851 in eqv?-hash in k1326 */
static void C_ccall f_1853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1874(2,t2,(C_word)C_fix(t1));}

/* k1872 in eqv?-hash in k1326 */
static void C_ccall f_1874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_lessp(t1,C_fix(0));
t3=(C_truep(t2)?(C_word)C_u_fixnum_negate(t1):t1);
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}

/* eq?-hash in k1326 */
static void C_ccall f_1680(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1680r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1680r(t0,t1,t2,t3);}}

static void C_ccall f_1680r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(4);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_exact_2(t5,lf[13]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1690,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t8=t7;
f_1690(2,t8,t2);}
else{
if(C_truep((C_word)C_charp(t2))){
t8=t7;
f_1690(2,t8,(C_word)C_fix((C_word)C_character_code(t2)));}
else{
switch(t2){
case C_SCHEME_TRUE:
t8=t7;
f_1690(2,t8,C_fix(256));
case C_SCHEME_FALSE:
t8=t7;
f_1690(2,t8,C_fix(257));
default:
if(C_truep((C_word)C_i_nullp(t2))){
t8=t7;
f_1690(2,t8,C_fix(258));}
else{
if(C_truep((C_word)C_eofp(t2))){
t8=t7;
f_1690(2,t8,C_fix(259));}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t8=(C_word)C_slot(t2,C_fix(1));
t9=t7;
f_1690(2,t9,(C_word)C_hash_string(t8));}
else{
if(C_truep((C_word)C_blockp(t2))){
/* srfi-69.scm: 184  *equal?-hash */
f_1905(t7,t2);}
else{
t8=t7;
f_1690(2,t8,C_fix(262));}}}}}}}}

/* k1688 in eq?-hash in k1326 */
static void C_ccall f_1690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_lessp(t1,C_fix(0));
t3=(C_truep(t2)?(C_word)C_u_fixnum_negate(t1):t1);
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}

/* keyword-hash in k1326 */
static void C_ccall f_1576(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1576r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1576r(t0,t1,t2,t3);}}

static void C_ccall f_1576r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1583,a[2]=t1,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 220  ##sys#check-keyword */
t7=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t2,lf[12]);}

/* k1581 in keyword-hash in k1326 */
static void C_ccall f_1583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[12]);
t3=((C_word*)t0)[3];
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_hash_string(t4);
t6=(C_word)C_fixnum_lessp(t5,C_fix(0));
t7=(C_truep(t6)?(C_word)C_u_fixnum_negate(t5):t5);
t8=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t7);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_fixnum_modulo(t8,((C_word*)t0)[4]));}

/* ##sys#check-keyword in k1326 */
static void C_ccall f_1550(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1550r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1550r(t0,t1,t2,t3);}}

static void C_ccall f_1550r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1557,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 207  keyword? */
t5=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1555 in ##sys#check-keyword in k1326 */
static void C_ccall f_1557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_vemptyp(((C_word*)t0)[3]);
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_slot(((C_word*)t0)[3],C_fix(0)));
/* srfi-69.scm: 208  ##sys#signal-hook */
t4=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,((C_word*)t0)[4],lf[9],t3,lf[10],((C_word*)t0)[2]);}}

/* symbol-hash in k1326 */
static void C_ccall f_1506(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1506r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1506r(t0,t1,t2,t3);}}

static void C_ccall f_1506r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_symbol_2(t2,lf[7]);
t7=(C_word)C_i_check_exact_2(t5,lf[7]);
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_hash_string(t9);
t11=(C_word)C_fixnum_lessp(t10,C_fix(0));
t12=(C_truep(t11)?(C_word)C_u_fixnum_negate(t10):t10);
t13=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t12);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_fixnum_modulo(t13,t5));}

/* object-uid-hash in k1326 */
static void C_ccall f_1465(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1465r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1465r(t0,t1,t2,t3);}}

static void C_ccall f_1465r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_exact_2(t5,lf[6]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1475,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 184  *equal?-hash */
f_1905(t7,t2);}

/* k1473 in object-uid-hash in k1326 */
static void C_ccall f_1475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_lessp(t1,C_fix(0));
t3=(C_truep(t2)?(C_word)C_u_fixnum_negate(t1):t1);
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}

/* number-hash in k1326 */
static void C_ccall f_1336(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1336r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1336r(t0,t1,t2,t3);}}

static void C_ccall f_1336r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1343,a[2]=t1,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_numberp(t2))){
t7=t6;
f_1343(2,t7,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 173  ##sys#signal-hook */
t7=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,lf[4],lf[2],lf[5],t2);}}

/* k1341 in number-hash in k1326 */
static void C_ccall f_1343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1343,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[2]);
t3=((C_word*)t0)[3];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1349,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t3))){
t5=t4;
f_1349(t5,t3);}
else{
if(C_truep((C_word)C_i_flonump(t3))){
t5=(C_word)C_subbyte(t3,C_fix(7));
t6=(C_word)C_subbyte(t3,C_fix(6));
t7=(C_word)C_subbyte(t3,C_fix(5));
t8=(C_word)C_subbyte(t3,C_fix(4));
t9=(C_word)C_subbyte(t3,C_fix(3));
t10=(C_word)C_subbyte(t3,C_fix(2));
t11=(C_word)C_subbyte(t3,C_fix(1));
t12=(C_word)C_subbyte(t3,C_fix(0));
t13=(C_word)C_fixnum_shift_left(t12,C_fix(1));
t14=(C_word)C_u_fixnum_plus(t11,t13);
t15=(C_word)C_fixnum_shift_left(t14,C_fix(1));
t16=(C_word)C_u_fixnum_plus(t10,t15);
t17=(C_word)C_fixnum_shift_left(t16,C_fix(1));
t18=(C_word)C_u_fixnum_plus(t9,t17);
t19=(C_word)C_fixnum_shift_left(t18,C_fix(1));
t20=(C_word)C_u_fixnum_plus(t8,t19);
t21=(C_word)C_fixnum_shift_left(t20,C_fix(1));
t22=(C_word)C_u_fixnum_plus(t7,t21);
t23=(C_word)C_fixnum_shift_left(t22,C_fix(1));
t24=(C_word)C_u_fixnum_plus(t6,t23);
t25=(C_word)C_fixnum_shift_left(t24,C_fix(1));
t26=(C_word)C_u_fixnum_plus(t5,t25);
t27=t4;
f_1349(t27,(C_word)C_fixnum_times(C_fix(331804471),t26));}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1445,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 165  ##sys#number-hash-hook */
t6=*((C_word*)lf[0]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}}}

/* k1443 in k1341 in number-hash in k1326 */
static void C_ccall f_1445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1349(t2,(C_word)C_fix(t1));}

/* k1347 in k1341 in number-hash in k1326 */
static void C_fcall f_1349(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_lessp(t1,C_fix(0));
t3=(C_truep(t2)?(C_word)C_u_fixnum_negate(t1):t1);
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}

/* ##sys#number-hash-hook in k1326 */
static void C_ccall f_1330(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1330,3,t0,t1,t2);}
/* srfi-69.scm: 161  *equal?-hash */
f_1905(t1,t2);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[228] = {
{"toplevel:srfi_69_scm",(void*)C_srfi_69_toplevel},
{"f_1328:srfi_69_scm",(void*)f_1328},
{"f_4975:srfi_69_scm",(void*)f_4975},
{"f_4985:srfi_69_scm",(void*)f_4985},
{"f_4997:srfi_69_scm",(void*)f_4997},
{"f_5054:srfi_69_scm",(void*)f_5054},
{"f_5073:srfi_69_scm",(void*)f_5073},
{"f_5012:srfi_69_scm",(void*)f_5012},
{"f_5095:srfi_69_scm",(void*)f_5095},
{"f_3967:srfi_69_scm",(void*)f_3967},
{"f_4959:srfi_69_scm",(void*)f_4959},
{"f_4963:srfi_69_scm",(void*)f_4963},
{"f_4966:srfi_69_scm",(void*)f_4966},
{"f_4957:srfi_69_scm",(void*)f_4957},
{"f_4934:srfi_69_scm",(void*)f_4934},
{"f_4941:srfi_69_scm",(void*)f_4941},
{"f_4946:srfi_69_scm",(void*)f_4946},
{"f_4954:srfi_69_scm",(void*)f_4954},
{"f_4922:srfi_69_scm",(void*)f_4922},
{"f_4929:srfi_69_scm",(void*)f_4929},
{"f_4910:srfi_69_scm",(void*)f_4910},
{"f_4917:srfi_69_scm",(void*)f_4917},
{"f_4898:srfi_69_scm",(void*)f_4898},
{"f_4905:srfi_69_scm",(void*)f_4905},
{"f_4832:srfi_69_scm",(void*)f_4832},
{"f_4844:srfi_69_scm",(void*)f_4844},
{"f_4860:srfi_69_scm",(void*)f_4860},
{"f_4888:srfi_69_scm",(void*)f_4888},
{"f_4767:srfi_69_scm",(void*)f_4767},
{"f_4779:srfi_69_scm",(void*)f_4779},
{"f_4802:srfi_69_scm",(void*)f_4802},
{"f_4815:srfi_69_scm",(void*)f_4815},
{"f_4789:srfi_69_scm",(void*)f_4789},
{"f_4702:srfi_69_scm",(void*)f_4702},
{"f_4717:srfi_69_scm",(void*)f_4717},
{"f_4733:srfi_69_scm",(void*)f_4733},
{"f_4637:srfi_69_scm",(void*)f_4637},
{"f_4652:srfi_69_scm",(void*)f_4652},
{"f_4668:srfi_69_scm",(void*)f_4668},
{"f_4592:srfi_69_scm",(void*)f_4592},
{"f_4599:srfi_69_scm",(void*)f_4599},
{"f_4604:srfi_69_scm",(void*)f_4604},
{"f_4620:srfi_69_scm",(void*)f_4620},
{"f_4602:srfi_69_scm",(void*)f_4602},
{"f_4519:srfi_69_scm",(void*)f_4519},
{"f_4534:srfi_69_scm",(void*)f_4534},
{"f_4550:srfi_69_scm",(void*)f_4550},
{"f_4503:srfi_69_scm",(void*)f_4503},
{"f_4517:srfi_69_scm",(void*)f_4517},
{"f_4491:srfi_69_scm",(void*)f_4491},
{"f_4426:srfi_69_scm",(void*)f_4426},
{"f_4438:srfi_69_scm",(void*)f_4438},
{"f_4461:srfi_69_scm",(void*)f_4461},
{"f_4474:srfi_69_scm",(void*)f_4474},
{"f_4448:srfi_69_scm",(void*)f_4448},
{"f_4410:srfi_69_scm",(void*)f_4410},
{"f_4417:srfi_69_scm",(void*)f_4417},
{"f_4314:srfi_69_scm",(void*)f_4314},
{"f_4321:srfi_69_scm",(void*)f_4321},
{"f_4335:srfi_69_scm",(void*)f_4335},
{"f_4361:srfi_69_scm",(void*)f_4361},
{"f_4380:srfi_69_scm",(void*)f_4380},
{"f_4348:srfi_69_scm",(void*)f_4348},
{"f_4183:srfi_69_scm",(void*)f_4183},
{"f_4199:srfi_69_scm",(void*)f_4199},
{"f_4266:srfi_69_scm",(void*)f_4266},
{"f_4285:srfi_69_scm",(void*)f_4285},
{"f_4219:srfi_69_scm",(void*)f_4219},
{"f_4075:srfi_69_scm",(void*)f_4075},
{"f_4091:srfi_69_scm",(void*)f_4091},
{"f_4146:srfi_69_scm",(void*)f_4146},
{"f_4159:srfi_69_scm",(void*)f_4159},
{"f_4106:srfi_69_scm",(void*)f_4106},
{"f_3969:srfi_69_scm",(void*)f_3969},
{"f_3985:srfi_69_scm",(void*)f_3985},
{"f_4039:srfi_69_scm",(void*)f_4039},
{"f_4055:srfi_69_scm",(void*)f_4055},
{"f_4000:srfi_69_scm",(void*)f_4000},
{"f_3772:srfi_69_scm",(void*)f_3772},
{"f_3955:srfi_69_scm",(void*)f_3955},
{"f_3947:srfi_69_scm",(void*)f_3947},
{"f_3928:srfi_69_scm",(void*)f_3928},
{"f_3800:srfi_69_scm",(void*)f_3800},
{"f_3815:srfi_69_scm",(void*)f_3815},
{"f_3881:srfi_69_scm",(void*)f_3881},
{"f_3911:srfi_69_scm",(void*)f_3911},
{"f_3832:srfi_69_scm",(void*)f_3832},
{"f_3821:srfi_69_scm",(void*)f_3821},
{"f_3760:srfi_69_scm",(void*)f_3760},
{"f_3767:srfi_69_scm",(void*)f_3767},
{"f_3553:srfi_69_scm",(void*)f_3553},
{"f_3750:srfi_69_scm",(void*)f_3750},
{"f_3742:srfi_69_scm",(void*)f_3742},
{"f_3723:srfi_69_scm",(void*)f_3723},
{"f_3578:srfi_69_scm",(void*)f_3578},
{"f_3593:srfi_69_scm",(void*)f_3593},
{"f_3666:srfi_69_scm",(void*)f_3666},
{"f_3699:srfi_69_scm",(void*)f_3699},
{"f_3702:srfi_69_scm",(void*)f_3702},
{"f_3676:srfi_69_scm",(void*)f_3676},
{"f_3607:srfi_69_scm",(void*)f_3607},
{"f_3643:srfi_69_scm",(void*)f_3643},
{"f_3617:srfi_69_scm",(void*)f_3617},
{"f_3266:srfi_69_scm",(void*)f_3266},
{"f_3508:srfi_69_scm",(void*)f_3508},
{"f_3491:srfi_69_scm",(void*)f_3491},
{"f_3503:srfi_69_scm",(void*)f_3503},
{"f_3268:srfi_69_scm",(void*)f_3268},
{"f_3275:srfi_69_scm",(void*)f_3275},
{"f_3278:srfi_69_scm",(void*)f_3278},
{"f_3482:srfi_69_scm",(void*)f_3482},
{"f_3474:srfi_69_scm",(void*)f_3474},
{"f_3455:srfi_69_scm",(void*)f_3455},
{"f_3302:srfi_69_scm",(void*)f_3302},
{"f_3317:srfi_69_scm",(void*)f_3317},
{"f_3394:srfi_69_scm",(void*)f_3394},
{"f_3431:srfi_69_scm",(void*)f_3431},
{"f_3434:srfi_69_scm",(void*)f_3434},
{"f_3422:srfi_69_scm",(void*)f_3422},
{"f_3404:srfi_69_scm",(void*)f_3404},
{"f_3331:srfi_69_scm",(void*)f_3331},
{"f_3371:srfi_69_scm",(void*)f_3371},
{"f_3359:srfi_69_scm",(void*)f_3359},
{"f_3341:srfi_69_scm",(void*)f_3341},
{"f_3257:srfi_69_scm",(void*)f_3257},
{"f_3145:srfi_69_scm",(void*)f_3145},
{"f_3155:srfi_69_scm",(void*)f_3155},
{"f_3160:srfi_69_scm",(void*)f_3160},
{"f_3222:srfi_69_scm",(void*)f_3222},
{"f_3243:srfi_69_scm",(void*)f_3243},
{"f_3216:srfi_69_scm",(void*)f_3216},
{"f_3119:srfi_69_scm",(void*)f_3119},
{"f_3126:srfi_69_scm",(void*)f_3126},
{"f_3129:srfi_69_scm",(void*)f_3129},
{"f_3052:srfi_69_scm",(void*)f_3052},
{"f_3075:srfi_69_scm",(void*)f_3075},
{"f_3091:srfi_69_scm",(void*)f_3091},
{"f_3062:srfi_69_scm",(void*)f_3062},
{"f_3132:srfi_69_scm",(void*)f_3132},
{"f_3025:srfi_69_scm",(void*)f_3025},
{"f_3013:srfi_69_scm",(void*)f_3013},
{"f_3004:srfi_69_scm",(void*)f_3004},
{"f_2995:srfi_69_scm",(void*)f_2995},
{"f_2986:srfi_69_scm",(void*)f_2986},
{"f_2977:srfi_69_scm",(void*)f_2977},
{"f_2968:srfi_69_scm",(void*)f_2968},
{"f_2959:srfi_69_scm",(void*)f_2959},
{"f_2950:srfi_69_scm",(void*)f_2950},
{"f_2944:srfi_69_scm",(void*)f_2944},
{"f_2581:srfi_69_scm",(void*)f_2581},
{"f_2934:srfi_69_scm",(void*)f_2934},
{"f_2937:srfi_69_scm",(void*)f_2937},
{"f_2659:srfi_69_scm",(void*)f_2659},
{"f_2914:srfi_69_scm",(void*)f_2914},
{"f_2917:srfi_69_scm",(void*)f_2917},
{"f_2662:srfi_69_scm",(void*)f_2662},
{"f_2882:srfi_69_scm",(void*)f_2882},
{"f_2888:srfi_69_scm",(void*)f_2888},
{"f_2665:srfi_69_scm",(void*)f_2665},
{"f_2700:srfi_69_scm",(void*)f_2700},
{"f_2721:srfi_69_scm",(void*)f_2721},
{"f_2727:srfi_69_scm",(void*)f_2727},
{"f_2819:srfi_69_scm",(void*)f_2819},
{"f_2822:srfi_69_scm",(void*)f_2822},
{"f_2794:srfi_69_scm",(void*)f_2794},
{"f_2797:srfi_69_scm",(void*)f_2797},
{"f_2784:srfi_69_scm",(void*)f_2784},
{"f_2766:srfi_69_scm",(void*)f_2766},
{"f_2753:srfi_69_scm",(void*)f_2753},
{"f_2743:srfi_69_scm",(void*)f_2743},
{"f_2730:srfi_69_scm",(void*)f_2730},
{"f_2711:srfi_69_scm",(void*)f_2711},
{"f_2668:srfi_69_scm",(void*)f_2668},
{"f_2671:srfi_69_scm",(void*)f_2671},
{"f_2675:srfi_69_scm",(void*)f_2675},
{"f_2691:srfi_69_scm",(void*)f_2691},
{"f_2678:srfi_69_scm",(void*)f_2678},
{"f_2583:srfi_69_scm",(void*)f_2583},
{"f_2557:srfi_69_scm",(void*)f_2557},
{"f_2561:srfi_69_scm",(void*)f_2561},
{"f_2527:srfi_69_scm",(void*)f_2527},
{"f_2533:srfi_69_scm",(void*)f_2533},
{"f_2403:srfi_69_scm",(void*)f_2403},
{"f_2468:srfi_69_scm",(void*)f_2468},
{"f_2459:srfi_69_scm",(void*)f_2459},
{"f_2440:srfi_69_scm",(void*)f_2440},
{"f_2444:srfi_69_scm",(void*)f_2444},
{"f_2447:srfi_69_scm",(void*)f_2447},
{"f_2419:srfi_69_scm",(void*)f_2419},
{"f_2281:srfi_69_scm",(void*)f_2281},
{"f_2346:srfi_69_scm",(void*)f_2346},
{"f_2337:srfi_69_scm",(void*)f_2337},
{"f_2318:srfi_69_scm",(void*)f_2318},
{"f_2322:srfi_69_scm",(void*)f_2322},
{"f_2325:srfi_69_scm",(void*)f_2325},
{"f_2297:srfi_69_scm",(void*)f_2297},
{"f_2239:srfi_69_scm",(void*)f_2239},
{"f_2249:srfi_69_scm",(void*)f_2249},
{"f_1905:srfi_69_scm",(void*)f_1905},
{"f_2004:srfi_69_scm",(void*)f_2004},
{"f_2217:srfi_69_scm",(void*)f_2217},
{"f_2196:srfi_69_scm",(void*)f_2196},
{"f_2188:srfi_69_scm",(void*)f_2188},
{"f_2167:srfi_69_scm",(void*)f_2167},
{"f_2141:srfi_69_scm",(void*)f_2141},
{"f_1973:srfi_69_scm",(void*)f_1973},
{"f_1989:srfi_69_scm",(void*)f_1989},
{"f_1908:srfi_69_scm",(void*)f_1908},
{"f_1925:srfi_69_scm",(void*)f_1925},
{"f_1959:srfi_69_scm",(void*)f_1959},
{"f_1864:srfi_69_scm",(void*)f_1864},
{"f_1853:srfi_69_scm",(void*)f_1853},
{"f_1874:srfi_69_scm",(void*)f_1874},
{"f_1680:srfi_69_scm",(void*)f_1680},
{"f_1690:srfi_69_scm",(void*)f_1690},
{"f_1576:srfi_69_scm",(void*)f_1576},
{"f_1583:srfi_69_scm",(void*)f_1583},
{"f_1550:srfi_69_scm",(void*)f_1550},
{"f_1557:srfi_69_scm",(void*)f_1557},
{"f_1506:srfi_69_scm",(void*)f_1506},
{"f_1465:srfi_69_scm",(void*)f_1465},
{"f_1475:srfi_69_scm",(void*)f_1475},
{"f_1336:srfi_69_scm",(void*)f_1336},
{"f_1343:srfi_69_scm",(void*)f_1343},
{"f_1445:srfi_69_scm",(void*)f_1445},
{"f_1349:srfi_69_scm",(void*)f_1349},
{"f_1330:srfi_69_scm",(void*)f_1330},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
