/* Generated from utils.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-12-14 09:02
   Version 4.2.0 - SVN rev. 16023
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-12-14 on galinha (Linux)
   command line: utils.scm -optimize-level 2 -include-path . -include-path ./ -inline -explicit-use -no-trace -output-file utils.c
   unit: utils
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[64];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,25),40,115,121,115,116,101,109,42,32,102,115,116,114,49,49,32,46,32,97,114,103,115,49,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,31),40,102,111,114,45,101,97,99,104,45,108,105,110,101,32,112,114,111,99,49,57,32,46,32,112,111,114,116,50,48,41,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,6),40,97,50,53,57,41,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,52,49,32,108,115,116,52,50,52,53,41};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,28),40,102,111,114,45,101,97,99,104,45,97,114,103,118,45,108,105,110,101,32,116,104,117,110,107,51,48,41,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,6),40,97,51,50,48,41,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,19),40,114,101,97,100,45,97,108,108,32,46,32,102,105,108,101,53,49,41,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,10),40,97,51,55,54,32,99,56,54,41,0,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,20),40,113,115,32,115,116,114,54,57,32,46,32,116,109,112,54,56,55,48,41,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,6),40,97,52,57,55,41,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,12),40,97,52,57,49,32,101,120,49,52,56,41,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,6),40,97,53,49,50,41,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,6),40,97,53,50,52,41,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,19),40,97,53,49,56,32,46,32,97,114,103,115,49,52,53,49,53,49,41,0,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,6),40,97,53,48,54,41,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,14),40,97,52,56,53,32,107,49,52,52,49,52,55,41,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,6),40,97,53,53,52,41,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,12),40,97,53,52,56,32,101,120,49,51,52,41,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,6),40,97,53,54,51,41,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,6),40,97,53,55,53,41,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,19),40,97,53,54,57,32,46,32,97,114,103,115,49,51,49,49,51,53,41,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,6),40,97,53,53,55,41,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,14),40,97,53,52,50,32,107,49,51,48,49,51,51,41,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,6),40,97,53,51,51,41,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,6),40,97,54,51,49,41,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,6),40,97,54,51,52,41,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,38),40,99,111,109,112,105,108,101,45,102,105,108,101,32,102,105,108,101,110,97,109,101,49,48,55,32,46,32,116,109,112,49,48,54,49,48,56,41,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_utils_toplevel)
C_externexport void C_ccall C_utils_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_174)
static void C_ccall f_174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_177)
static void C_ccall f_177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_180)
static void C_ccall f_180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_183)
static void C_ccall f_183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_186)
static void C_ccall f_186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_433)
static void C_ccall f_433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_437)
static void C_ccall f_437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_440)
static void C_ccall f_440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_441)
static void C_ccall f_441(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_441)
static void C_ccall f_441r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_635)
static void C_ccall f_635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_445)
static void C_ccall f_445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_448)
static void C_ccall f_448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_632)
static void C_ccall f_632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_451)
static void C_ccall f_451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_630)
static void C_ccall f_630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_454)
static void C_ccall f_454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_460)
static void C_ccall f_460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_620)
static void C_ccall f_620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_466)
static void C_ccall f_466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_588)
static void C_ccall f_588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_616)
static void C_ccall f_616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_612)
static void C_ccall f_612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_592)
static void C_ccall f_592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_596)
static void C_ccall f_596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_600)
static void C_ccall f_600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_469)
static void C_ccall f_469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_534)
static void C_ccall f_534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_543)
static void C_ccall f_543(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_558)
static void C_ccall f_558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_570)
static void C_ccall f_570(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_570)
static void C_ccall f_570r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_576)
static void C_ccall f_576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_564)
static void C_ccall f_564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_549)
static void C_ccall f_549(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_555)
static void C_ccall f_555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_541)
static void C_ccall f_541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_472)
static void C_ccall f_472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_486)
static void C_ccall f_486(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_507)
static void C_ccall f_507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_519)
static void C_ccall f_519(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_519)
static void C_ccall f_519r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_525)
static void C_ccall f_525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_513)
static void C_ccall f_513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_517)
static void C_ccall f_517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_492)
static void C_ccall f_492(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_498)
static void C_ccall f_498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_502)
static void C_ccall f_502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_484)
static void C_ccall f_484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_346)
static void C_ccall f_346(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_346)
static void C_ccall f_346r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_350)
static void C_ccall f_350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_400)
static void C_ccall f_400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_377)
static void C_ccall f_377(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_375)
static void C_ccall f_375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_303)
static void C_ccall f_303(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_303)
static void C_ccall f_303r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_307)
static void C_ccall f_307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_313)
static void C_ccall f_313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_321)
static void C_ccall f_321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_242)
static void C_ccall f_242(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_267)
static void C_ccall f_267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_281)
static void C_fcall f_281(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_260)
static void C_ccall f_260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_294)
static void C_ccall f_294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_206)
static void C_ccall f_206(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_206)
static void C_ccall f_206r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_213)
static void C_ccall f_213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_218)
static void C_fcall f_218(C_word t0,C_word t1) C_noret;
C_noret_decl(f_222)
static void C_ccall f_222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_231)
static void C_ccall f_231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_188)
static void C_ccall f_188(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_188)
static void C_ccall f_188r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_192)
static void C_ccall f_192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_195)
static void C_ccall f_195(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_281)
static void C_fcall trf_281(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_281(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_281(t0,t1,t2);}

C_noret_decl(trf_218)
static void C_fcall trf_218(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_218(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_218(t0,t1);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_utils_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_utils_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("utils_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(538)){
C_save(t1);
C_rereclaim2(538*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,64);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],7,"sprintf");
lf[3]=C_h_intern(&lf[3],6,"system");
lf[4]=C_h_intern(&lf[4],7,"system*");
lf[5]=C_h_intern(&lf[5],9,"\003syserror");
lf[6]=C_decode_literal(C_heaptop,"\376B\000\0003shell invocation failed with non-zero return status");
lf[7]=C_h_intern(&lf[7],9,"read-line");
lf[8]=C_h_intern(&lf[8],13,"for-each-line");
lf[9]=C_h_intern(&lf[9],18,"\003sysstandard-input");
lf[10]=C_h_intern(&lf[10],14,"\003syscheck-port");
lf[11]=C_h_intern(&lf[11],18,"for-each-argv-line");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[13]=C_h_intern(&lf[13],20,"with-input-from-file");
lf[14]=C_h_intern(&lf[14],22,"command-line-arguments");
lf[15]=C_h_intern(&lf[15],8,"read-all");
lf[16]=C_h_intern(&lf[16],20,"\003sysread-string/port");
lf[17]=C_h_intern(&lf[17],5,"port\077");
lf[18]=C_h_intern(&lf[18],2,"qs");
lf[19]=C_h_intern(&lf[19],7,"mingw32");
lf[20]=C_h_intern(&lf[20],4,"msvc");
lf[21]=C_h_intern(&lf[21],13,"string-append");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000\002\047\047");
lf[25]=C_h_intern(&lf[25],18,"string-concatenate");
lf[26]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000#\376\003\000\000\002\376\377\012\000\000\042\376\003\000\000\002\376\377\012\000\000\047\376\003\000\000\002\376\377\012\000\000`\376\003\000\000\002\376\377\012\000\000\264\376\003\000\000\002\376\377\012\000\000~\376\003\000\000\002\376\377\012\000\000&\376\003\000"
"\000\002\376\377\012\000\000%\376\003\000\000\002\376\377\012\000\000$\376\003\000\000\002\376\377\012\000\000!\376\003\000\000\002\376\377\012\000\000*\376\003\000\000\002\376\377\012\000\000;\376\003\000\000\002\376\377\012\000\000<\376\003\000\000\002\376\377\012\000\000>\376\003\000\000\002\376"
"\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000(\376\003\000\000\002\376\377\012\000\000)\376\003\000\000\002\376\377\012\000\000[\376\003\000\000\002\376\377\012\000\000]\376\003\000\000\002\376\377\012\000\000{\376\003\000\000\002\376\377\012\000\000}\376\377\016");
lf[27]=C_h_intern(&lf[27],7,"\003sysmap");
lf[28]=C_h_intern(&lf[28],16,"\003sysstring->list");
lf[29]=C_h_intern(&lf[29],14,"build-platform");
lf[30]=C_h_intern(&lf[30],20,"compile-file-options");
lf[31]=C_h_intern(&lf[31],4,"load");
lf[32]=C_h_intern(&lf[32],12,"compile-file");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[34]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007mingw32\376\003\000\000\002\376\001\000\000\004msvc\376\377\016");
lf[35]=C_h_intern(&lf[35],5,"abort");
lf[36]=C_h_intern(&lf[36],12,"delete-file*");
lf[37]=C_h_intern(&lf[37],22,"with-exception-handler");
lf[38]=C_h_intern(&lf[38],30,"call-with-current-continuation");
lf[39]=C_h_intern(&lf[39],7,"on-exit");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\025~a~a -s ~a ~a -o ~a~a");
lf[45]=C_h_intern(&lf[45],18,"string-intersperse");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[47]=C_h_intern(&lf[47],6,"append");
lf[48]=C_h_intern(&lf[48],5,"print");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\014; compiling ");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[51]=C_h_intern(&lf[51],21,"create-temporary-file");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[53]=C_h_intern(&lf[53],12,"file-exists\077");
lf[54]=C_h_intern(&lf[54],13,"make-pathname");
lf[55]=C_h_intern(&lf[55],15,"\003sysget-keyword");
lf[56]=C_h_intern(&lf[56],5,"\000load");
lf[57]=C_h_intern(&lf[57],12,"\000output-file");
lf[58]=C_h_intern(&lf[58],8,"\000options");
lf[59]=C_h_intern(&lf[59],17,"\003syspeek-c-string");
lf[60]=C_h_intern(&lf[60],14,"make-parameter");
lf[61]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-S\376\003\000\000\002\376B\000\000\003-O2\376\003\000\000\002\376B\000\000\003-d2\376\377\016");
lf[62]=C_h_intern(&lf[62],17,"register-feature!");
lf[63]=C_h_intern(&lf[63],5,"utils");
C_register_lf2(lf,64,create_ptable());
t2=C_mutate(&lf[0] /* (set! c57 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_174,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k172 */
static void C_ccall f_174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_174,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_177,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k175 in k172 */
static void C_ccall f_177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_177,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_180,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k178 in k175 in k172 */
static void C_ccall f_180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_183,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k181 in k178 in k175 in k172 */
static void C_ccall f_183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_183,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_186,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 52   register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[62]+1)))(3,*((C_word*)lf[62]+1),t2,lf[63]);}

/* k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_186,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=*((C_word*)lf[3]+1);
t4=C_mutate((C_word*)lf[4]+1 /* (set! system* ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_188,a[2]=t2,a[3]=t3,a[4]=((C_word)li0),tmp=(C_word)a,a+=5,tmp));
t5=*((C_word*)lf[7]+1);
t6=C_mutate((C_word*)lf[8]+1 /* (set! for-each-line ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_206,a[2]=t5,a[3]=((C_word)li2),tmp=(C_word)a,a+=4,tmp));
t7=C_mutate((C_word*)lf[11]+1 /* (set! for-each-argv-line ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_242,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[15]+1 /* (set! read-all ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_303,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[18]+1 /* (set! qs ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_346,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_433,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 126  make-parameter */
((C_proc3)C_retrieve_proc(*((C_word*)lf[60]+1)))(3,*((C_word*)lf[60]+1),t10,lf[61]);}

/* k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_433,2,t0,t1);}
t2=C_mutate((C_word*)lf[30]+1 /* (set! compile-file-options ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_437,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[59]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_CSC_PROGRAM),C_fix(0));}

/* k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_440,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[59]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}

/* k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_440,2,t0,t1);}
t2=*((C_word*)lf[31]+1);
t3=C_mutate((C_word*)lf[32]+1 /* (set! compile-file ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_441,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word)li27),tmp=(C_word)a,a+=6,tmp));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_441(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_441r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_441r(t0,t1,t2,t3);}}

static void C_ccall f_441r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(11);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_445,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_635,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
((C_proc5)C_retrieve_proc(*((C_word*)lf[55]+1)))(5,*((C_word*)lf[55]+1),t4,lf[58],t3,t5);}

/* a634 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_635,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}

/* k443 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_448,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* ##sys#get-keyword */
((C_proc4)C_retrieve_proc(*((C_word*)lf[55]+1)))(4,*((C_word*)lf[55]+1),t2,lf[57],((C_word*)t0)[2]);}

/* k446 in k443 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_451,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_632,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
((C_proc5)C_retrieve_proc(*((C_word*)lf[55]+1)))(5,*((C_word*)lf[55]+1),t2,lf[56],((C_word*)t0)[2],t3);}

/* a631 in k446 in k443 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_632,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* k449 in k446 in k443 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_454,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_630,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 133  make-pathname */
((C_proc4)C_retrieve_proc(*((C_word*)lf[54]+1)))(4,*((C_word*)lf[54]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k628 in k449 in k446 in k443 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 133  file-exists? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),((C_word*)t0)[2],t1);}

/* k452 in k449 in k446 in k443 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_454,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[33]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_460,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=((C_word*)t0)[6];
if(C_truep(t4)){
t5=t3;
f_460(2,t5,C_SCHEME_FALSE);}
else{
/* utils.scm: 134  create-temporary-file */
((C_proc3)C_retrieve_proc(*((C_word*)lf[51]+1)))(3,*((C_word*)lf[51]+1),t3,lf[52]);}}

/* k458 in k452 in k449 in k446 in k443 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_620,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* utils.scm: 135  build-platform */
((C_proc2)C_retrieve_proc(*((C_word*)lf[29]+1)))(2,*((C_word*)lf[29]+1),t2);}

/* k618 in k458 in k452 in k449 in k446 in k443 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_620,2,t0,t1);}
t2=(C_word)C_i_memq(t1,lf[34]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_466,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* utils.scm: 136  print */
t4=*((C_word*)lf[48]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[49],((C_word*)t0)[4],lf[50]);}

/* k464 in k618 in k458 in k452 in k449 in k446 in k443 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_466,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_469,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=(C_truep(((C_word*)t0)[5])?lf[40]:lf[41]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_588,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t3,a[7]=t2,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* utils.scm: 140  qs */
((C_proc3)C_retrieve_proc(*((C_word*)lf[18]+1)))(3,*((C_word*)lf[18]+1),t4,((C_word*)t0)[2]);}

/* k586 in k464 in k618 in k458 in k452 in k449 in k446 in k443 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_588,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_592,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_612,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_616,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 141  compile-file-options */
((C_proc2)C_retrieve_proc(*((C_word*)lf[30]+1)))(2,*((C_word*)lf[30]+1),t4);}

/* k614 in k586 in k464 in k618 in k458 in k452 in k449 in k446 in k443 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 141  append */
t2=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k610 in k586 in k464 in k618 in k458 in k452 in k449 in k446 in k443 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 141  string-intersperse */
((C_proc4)C_retrieve_proc(*((C_word*)lf[45]+1)))(4,*((C_word*)lf[45]+1),((C_word*)t0)[2],t1,lf[46]);}

/* k590 in k586 in k464 in k618 in k458 in k452 in k449 in k446 in k443 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_596,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* utils.scm: 142  qs */
((C_proc3)C_retrieve_proc(*((C_word*)lf[18]+1)))(3,*((C_word*)lf[18]+1),t2,((C_word*)t0)[2]);}

/* k594 in k590 in k586 in k464 in k618 in k458 in k452 in k449 in k446 in k443 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_596,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_600,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_truep(((C_word*)t0)[3])?((C_word*)t0)[3]:((C_word*)t0)[2]);
/* utils.scm: 143  qs */
((C_proc3)C_retrieve_proc(*((C_word*)lf[18]+1)))(3,*((C_word*)lf[18]+1),t2,t3);}

/* k598 in k594 in k590 in k586 in k464 in k618 in k458 in k452 in k449 in k446 in k443 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[7])?lf[42]:lf[43]);
/* utils.scm: 137  system* */
((C_proc9)C_retrieve_proc(*((C_word*)lf[4]+1)))(9,*((C_word*)lf[4]+1),((C_word*)t0)[6],lf[44],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}

/* k467 in k464 in k618 in k458 in k452 in k449 in k446 in k443 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_469,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_472,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_472(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_534,a[2]=((C_word*)t0)[4],a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 146  on-exit */
((C_proc3)C_retrieve_proc(*((C_word*)lf[39]+1)))(3,*((C_word*)lf[39]+1),t2,t3);}}

/* a533 in k467 in k464 in k618 in k458 in k452 in k449 in k446 in k443 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_534,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_541,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_543,a[2]=((C_word*)t0)[2],a[3]=((C_word)li23),tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
t4=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* a542 in a533 in k467 in k464 in k618 in k458 in k452 in k449 in k446 in k443 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_543(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_543,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_549,a[2]=t2,a[3]=((C_word)li18),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_558,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li22),tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_proc(*((C_word*)lf[37]+1)))(4,*((C_word*)lf[37]+1),t1,t3,t4);}

/* a557 in a542 in a533 in k467 in k464 in k618 in k458 in k452 in k449 in k446 in k443 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_564,a[2]=((C_word*)t0)[3],a[3]=((C_word)li19),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_570,a[2]=((C_word*)t0)[2],a[3]=((C_word)li21),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a569 in a557 in a542 in a533 in k467 in k464 in k618 in k458 in k452 in k449 in k446 in k443 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_570(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_570r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_570r(t0,t1,t2);}}

static void C_ccall f_570r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_576,a[2]=t2,a[3]=((C_word)li20),tmp=(C_word)a,a+=4,tmp);
/* k130133 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a575 in a569 in a557 in a542 in a533 in k467 in k464 in k618 in k458 in k452 in k449 in k446 in k443 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_576,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a563 in a557 in a542 in a533 in k467 in k464 in k618 in k458 in k452 in k449 in k446 in k443 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_564,2,t0,t1);}
/* utils.scm: 148  delete-file* */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t1,((C_word*)t0)[2]);}

/* a548 in a542 in a533 in k467 in k464 in k618 in k458 in k452 in k449 in k446 in k443 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_549(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_549,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_555,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp);
/* k130133 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a554 in a548 in a542 in a533 in k467 in k464 in k618 in k458 in k452 in k449 in k446 in k443 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_555,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k539 in a533 in k467 in k464 in k618 in k458 in k452 in k449 in k446 in k443 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k470 in k467 in k464 in k618 in k458 in k452 in k449 in k446 in k443 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_472,2,t0,t1);}
if(C_truep(((C_word*)t0)[6])){
t2=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_484,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_486,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word)li16),tmp=(C_word)a,a+=5,tmp);
/* call-with-current-continuation */
t5=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* a485 in k470 in k467 in k464 in k618 in k458 in k452 in k449 in k446 in k443 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_486(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_486,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_492,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word)li11),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_507,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word)li15),tmp=(C_word)a,a+=6,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_proc(*((C_word*)lf[37]+1)))(4,*((C_word*)lf[37]+1),t1,t3,t4);}

/* a506 in a485 in k470 in k467 in k464 in k618 in k458 in k452 in k449 in k446 in k443 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_507,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_513,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li12),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_519,a[2]=((C_word*)t0)[2],a[3]=((C_word)li14),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a518 in a506 in a485 in k470 in k467 in k464 in k618 in k458 in k452 in k449 in k446 in k443 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_519(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_519r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_519r(t0,t1,t2);}}

static void C_ccall f_519r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_525,a[2]=t2,a[3]=((C_word)li13),tmp=(C_word)a,a+=4,tmp);
/* k144147 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a524 in a518 in a506 in a485 in k470 in k467 in k464 in k618 in k458 in k452 in k449 in k446 in k443 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_525,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a512 in a506 in a485 in k470 in k467 in k464 in k618 in k458 in k452 in k449 in k446 in k443 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_513,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_517,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 155  load-file */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}

/* k515 in a512 in a506 in a485 in k470 in k467 in k464 in k618 in k458 in k452 in k449 in k446 in k443 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a491 in a485 in k470 in k467 in k464 in k618 in k458 in k452 in k449 in k446 in k443 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_492(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_492,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_498,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li10),tmp=(C_word)a,a+=5,tmp);
/* k144147 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a497 in a491 in a485 in k470 in k467 in k464 in k618 in k458 in k452 in k449 in k446 in k443 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_498,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_502,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 153  delete-file* */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t2,((C_word*)t0)[2]);}

/* k500 in a497 in a491 in a485 in k470 in k467 in k464 in k618 in k458 in k452 in k449 in k446 in k443 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 154  abort */
((C_proc3)C_retrieve_proc(*((C_word*)lf[35]+1)))(3,*((C_word*)lf[35]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k482 in k470 in k467 in k464 in k618 in k458 in k452 in k449 in k446 in k443 in compile-file in k438 in k435 in k431 in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* qs in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_346(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_346r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_346r(t0,t1,t2,t3);}}

static void C_ccall f_346r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_350,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* utils.scm: 107  build-platform */
((C_proc2)C_retrieve_proc(*((C_word*)lf[29]+1)))(2,*((C_word*)lf[29]+1),t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_350(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k348 in qs in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_350,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[19]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(t1,lf[20]));
if(C_truep(t3)){
/* utils.scm: 110  string-append */
t4=*((C_word*)lf[21]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],lf[22],((C_word*)t0)[2],lf[23]);}
else{
t4=(C_word)C_i_string_length(((C_word*)t0)[2]);
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[24]);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_375,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_377,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_400,a[2]=t7,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t9=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,((C_word*)t0)[2]);}}}

/* k398 in k348 in qs in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a376 in k348 in qs in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_377(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_377,3,t0,t1,t2);}
t3=(C_word)C_u_i_char_whitespacep(t2);
t4=(C_truep(t3)?t3:(C_word)C_i_memq(t2,lf[26]));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?(C_word)C_a_i_string(&a,2,C_make_character(92),t2):(C_word)C_a_i_string(&a,1,t2)));}

/* k373 in k348 in qs in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 114  string-concatenate */
((C_proc3)C_retrieve_proc(*((C_word*)lf[25]+1)))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* read-all in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_303(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_303r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_303r(t0,t1,t2);}}

static void C_ccall f_303r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_307,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_307(2,t4,*((C_word*)lf[9]+1));}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_307(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k305 in read-all in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_313,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 100  port? */
t3=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k311 in k305 in read-all in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_313,2,t0,t1);}
if(C_truep(t1)){
/* read-string/port */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_321,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 102  with-input-from-file */
t3=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* a320 in k311 in k305 in read-all in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_321,2,t0,t1);}
/* read-string/port */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_SCHEME_FALSE,*((C_word*)lf[9]+1));}

/* for-each-argv-line in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_242(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_242,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_267,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 88   command-line-arguments */
t4=*((C_word*)lf[14]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k265 in for-each-argv-line in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_267,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
/* utils.scm: 91   for-each-line */
t2=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_281,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word)li4),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_281(t5,((C_word*)t0)[3],t1);}}

/* loop41 in k265 in for-each-argv-line in k184 in k181 in k178 in k175 in k172 */
static void C_fcall f_281(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_281,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_294,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
if(C_truep((C_word)C_i_string_equal_p(t3,lf[12]))){
/* utils.scm: 86   for-each-line */
t6=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_260,a[2]=t5,a[3]=((C_word)li3),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 87   with-input-from-file */
t7=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t3,t6);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a259 in loop41 in k265 in for-each-argv-line in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_260,2,t0,t1);}
/* for-each-line */
t2=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k292 in loop41 in k265 in for-each-argv-line in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_281(t3,((C_word*)t0)[2],t2);}

/* for-each-line in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_206(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_206r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_206r(t0,t1,t2,t3);}}

static void C_ccall f_206r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):*((C_word*)lf[9]+1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_213,a[2]=t1,a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 73   ##sys#check-port */
t7=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t5,lf[8]);}

/* k211 in for-each-line in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_213,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_218,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word)li1),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_218(t5,((C_word*)t0)[2]);}

/* loop in k211 in for-each-line in k184 in k181 in k178 in k175 in k172 */
static void C_fcall f_218(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_218,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_222,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 75   read-line */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k220 in loop in k211 in for-each-line in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_222,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_231,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 77   proc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}}

/* k229 in k220 in loop in k211 in for-each-line in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 78   loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_218(t2,((C_word*)t0)[2]);}

/* system* in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_188(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_188r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_188r(t0,t1,t2,t3);}}

static void C_ccall f_188r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_192,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t4,((C_word*)t0)[2],t2,t3);}

/* k190 in system* in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_192,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_195,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 62   system */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k193 in k190 in system* in k184 in k181 in k178 in k175 in k172 */
static void C_ccall f_195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* utils.scm: 64   ##sys#error */
t3=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[6],((C_word*)t0)[2],t1);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[70] = {
{"toplevel:utils_scm",(void*)C_utils_toplevel},
{"f_174:utils_scm",(void*)f_174},
{"f_177:utils_scm",(void*)f_177},
{"f_180:utils_scm",(void*)f_180},
{"f_183:utils_scm",(void*)f_183},
{"f_186:utils_scm",(void*)f_186},
{"f_433:utils_scm",(void*)f_433},
{"f_437:utils_scm",(void*)f_437},
{"f_440:utils_scm",(void*)f_440},
{"f_441:utils_scm",(void*)f_441},
{"f_635:utils_scm",(void*)f_635},
{"f_445:utils_scm",(void*)f_445},
{"f_448:utils_scm",(void*)f_448},
{"f_632:utils_scm",(void*)f_632},
{"f_451:utils_scm",(void*)f_451},
{"f_630:utils_scm",(void*)f_630},
{"f_454:utils_scm",(void*)f_454},
{"f_460:utils_scm",(void*)f_460},
{"f_620:utils_scm",(void*)f_620},
{"f_466:utils_scm",(void*)f_466},
{"f_588:utils_scm",(void*)f_588},
{"f_616:utils_scm",(void*)f_616},
{"f_612:utils_scm",(void*)f_612},
{"f_592:utils_scm",(void*)f_592},
{"f_596:utils_scm",(void*)f_596},
{"f_600:utils_scm",(void*)f_600},
{"f_469:utils_scm",(void*)f_469},
{"f_534:utils_scm",(void*)f_534},
{"f_543:utils_scm",(void*)f_543},
{"f_558:utils_scm",(void*)f_558},
{"f_570:utils_scm",(void*)f_570},
{"f_576:utils_scm",(void*)f_576},
{"f_564:utils_scm",(void*)f_564},
{"f_549:utils_scm",(void*)f_549},
{"f_555:utils_scm",(void*)f_555},
{"f_541:utils_scm",(void*)f_541},
{"f_472:utils_scm",(void*)f_472},
{"f_486:utils_scm",(void*)f_486},
{"f_507:utils_scm",(void*)f_507},
{"f_519:utils_scm",(void*)f_519},
{"f_525:utils_scm",(void*)f_525},
{"f_513:utils_scm",(void*)f_513},
{"f_517:utils_scm",(void*)f_517},
{"f_492:utils_scm",(void*)f_492},
{"f_498:utils_scm",(void*)f_498},
{"f_502:utils_scm",(void*)f_502},
{"f_484:utils_scm",(void*)f_484},
{"f_346:utils_scm",(void*)f_346},
{"f_350:utils_scm",(void*)f_350},
{"f_400:utils_scm",(void*)f_400},
{"f_377:utils_scm",(void*)f_377},
{"f_375:utils_scm",(void*)f_375},
{"f_303:utils_scm",(void*)f_303},
{"f_307:utils_scm",(void*)f_307},
{"f_313:utils_scm",(void*)f_313},
{"f_321:utils_scm",(void*)f_321},
{"f_242:utils_scm",(void*)f_242},
{"f_267:utils_scm",(void*)f_267},
{"f_281:utils_scm",(void*)f_281},
{"f_260:utils_scm",(void*)f_260},
{"f_294:utils_scm",(void*)f_294},
{"f_206:utils_scm",(void*)f_206},
{"f_213:utils_scm",(void*)f_213},
{"f_218:utils_scm",(void*)f_218},
{"f_222:utils_scm",(void*)f_222},
{"f_231:utils_scm",(void*)f_231},
{"f_188:utils_scm",(void*)f_188},
{"f_192:utils_scm",(void*)f_192},
{"f_195:utils_scm",(void*)f_195},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
