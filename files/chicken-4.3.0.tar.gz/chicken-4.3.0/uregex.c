/* Generated from regex.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-12-14 09:03
   Version 4.2.0 - SVN rev. 16023
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-12-14 on galinha (Linux)
   command line: regex.scm -optimize-level 2 -include-path . -include-path ./ -inline -explicit-use -no-trace -unsafe -no-lambda-info -output-file uregex.c
   unit: regex
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[320];
static double C_possibly_force_alignment;


C_noret_decl(C_regex_toplevel)
C_externexport void C_ccall C_regex_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3723)
static void C_ccall f_3723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20437)
static void C_ccall f_20437(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_20444)
static void C_ccall f_20444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20452)
static void C_fcall f_20452(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_20484)
static void C_ccall f_20484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20471)
static void C_ccall f_20471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20474)
static void C_ccall f_20474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20376)
static void C_ccall f_20376(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_20376)
static void C_ccall f_20376r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_20388)
static void C_fcall f_20388(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_20421)
static void C_ccall f_20421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20407)
static void C_ccall f_20407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20414)
static void C_ccall f_20414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20425)
static void C_ccall f_20425(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_20099)
static void C_ccall f_20099(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_20114)
static void C_ccall f_20114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20116)
static void C_fcall f_20116(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_20371)
static void C_ccall f_20371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20367)
static void C_ccall f_20367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20356)
static void C_ccall f_20356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20178)
static void C_fcall f_20178(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_20208)
static void C_fcall f_20208(C_word t0,C_word t1) C_noret;
C_noret_decl(f_20237)
static void C_fcall f_20237(C_word t0,C_word t1) C_noret;
C_noret_decl(f_20285)
static void C_ccall f_20285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20264)
static void C_ccall f_20264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20260)
static void C_ccall f_20260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20227)
static void C_ccall f_20227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20223)
static void C_ccall f_20223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20198)
static void C_ccall f_20198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20176)
static void C_ccall f_20176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20163)
static void C_ccall f_20163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20150)
static void C_ccall f_20150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20146)
static void C_ccall f_20146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20110)
static void C_ccall f_20110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20014)
static void C_ccall f_20014(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_20027)
static void C_fcall f_20027(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_20046)
static void C_fcall f_20046(C_word t0,C_word t1) C_noret;
C_noret_decl(f_19962)
static void C_ccall f_19962(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_19962)
static void C_ccall f_19962r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_19977)
static void C_fcall f_19977(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_19994)
static void C_ccall f_19994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19707)
static void C_ccall f_19707(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_19707)
static void C_ccall f_19707r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_19849)
static void C_fcall f_19849(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_19853)
static void C_ccall f_19853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19944)
static void C_ccall f_19944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19940)
static void C_ccall f_19940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19911)
static void C_ccall f_19911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19893)
static void C_ccall f_19893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19886)
static void C_ccall f_19886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19743)
static void C_fcall f_19743(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_19749)
static void C_fcall f_19749(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_19816)
static void C_ccall f_19816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19804)
static void C_ccall f_19804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19763)
static void C_ccall f_19763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19728)
static C_word C_fcall f_19728(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_19525)
static void C_ccall f_19525(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_19525)
static void C_ccall f_19525r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_19689)
static void C_ccall f_19689(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_19663)
static void C_ccall f_19663(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_19688)
static void C_ccall f_19688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19643)
static void C_ccall f_19643(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_19544)
static void C_fcall f_19544(C_word t0,C_word t1) C_noret;
C_noret_decl(f_19552)
static void C_fcall f_19552(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_19556)
static void C_ccall f_19556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19617)
static void C_ccall f_19617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19598)
static void C_ccall f_19598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19632)
static void C_ccall f_19632(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_19627)
static void C_ccall f_19627(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_19405)
static void C_ccall f_19405(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_19405)
static void C_ccall f_19405r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_19480)
static void C_fcall f_19480(C_word t0,C_word t1) C_noret;
C_noret_decl(f_19471)
static void C_fcall f_19471(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_19407)
static void C_fcall f_19407(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_19411)
static void C_ccall f_19411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19466)
static void C_ccall f_19466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19420)
static void C_ccall f_19420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19430)
static void C_ccall f_19430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19432)
static void C_fcall f_19432(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_19293)
static void C_ccall f_19293(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_19293)
static void C_ccall f_19293r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_19360)
static void C_fcall f_19360(C_word t0,C_word t1) C_noret;
C_noret_decl(f_19351)
static void C_fcall f_19351(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_19295)
static void C_fcall f_19295(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_19299)
static void C_ccall f_19299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19346)
static void C_ccall f_19346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19308)
static void C_ccall f_19308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19318)
static void C_ccall f_19318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19320)
static void C_fcall f_19320(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_19342)
static void C_ccall f_19342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19231)
static void C_ccall f_19231(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_19235)
static void C_ccall f_19235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19238)
static void C_ccall f_19238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19248)
static void C_ccall f_19248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19250)
static void C_fcall f_19250(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_19185)
static void C_ccall f_19185(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_19189)
static void C_ccall f_19189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19192)
static void C_ccall f_19192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19202)
static void C_ccall f_19202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19204)
static void C_fcall f_19204(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_19229)
static void C_ccall f_19229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19164)
static void C_fcall f_19164(C_word t0,C_word t1) C_noret;
C_noret_decl(f_19171)
static void C_ccall f_19171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19180)
static void C_ccall f_19180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19061)
static void C_ccall f_19061(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_19061)
static void C_ccall f_19061r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_19104)
static void C_fcall f_19104(C_word t0,C_word t1) C_noret;
C_noret_decl(f_19099)
static void C_fcall f_19099(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_19094)
static void C_fcall f_19094(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_19063)
static void C_fcall f_19063(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_19075)
static void C_fcall f_19075(C_word t0,C_word t1) C_noret;
C_noret_decl(f_19078)
static void C_fcall f_19078(C_word t0,C_word t1) C_noret;
C_noret_decl(f_19081)
static void C_fcall f_19081(C_word t0,C_word t1) C_noret;
C_noret_decl(f_19071)
static void C_ccall f_19071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19043)
static void C_ccall f_19043(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_18861)
static void C_ccall f_18861(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_18867)
static void C_fcall f_18867(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_18989)
static void C_ccall f_18989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18993)
static void C_ccall f_18993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19001)
static void C_ccall f_19001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18985)
static void C_ccall f_18985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18960)
static void C_ccall f_18960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18964)
static void C_ccall f_18964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18956)
static void C_ccall f_18956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18923)
static void C_ccall f_18923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18895)
static void C_ccall f_18895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18805)
static void C_ccall f_18805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_18805)
static void C_ccall f_18805r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_18838)
static void C_ccall f_18838(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_18859)
static void C_ccall f_18859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18849)
static void C_fcall f_18849(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18811)
static void C_ccall f_18811(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_18815)
static void C_ccall f_18815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18822)
static void C_ccall f_18822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18836)
static void C_ccall f_18836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18826)
static void C_fcall f_18826(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18753)
static void C_ccall f_18753(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_18753)
static void C_ccall f_18753r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_18803)
static void C_ccall f_18803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18757)
static void C_ccall f_18757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18795)
static void C_ccall f_18795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18771)
static void C_ccall f_18771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18779)
static void C_ccall f_18779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18791)
static void C_ccall f_18791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18787)
static void C_ccall f_18787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18775)
static void C_ccall f_18775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18640)
static void C_ccall f_18640(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_18640)
static void C_ccall f_18640r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_18644)
static void C_ccall f_18644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18647)
static void C_ccall f_18647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18730)
static void C_fcall f_18730(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18701)
static void C_fcall f_18701(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18664)
static void C_fcall f_18664(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_18677)
static void C_ccall f_18677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18689)
static void C_ccall f_18689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18692)
static void C_ccall f_18692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18695)
static void C_ccall f_18695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18750)
static void C_ccall f_18750(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_18475)
static void C_ccall f_18475(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_18481)
static void C_fcall f_18481(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_18497)
static void C_fcall f_18497(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18534)
static void C_fcall f_18534(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18592)
static void C_ccall f_18592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18549)
static void C_ccall f_18549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18545)
static void C_ccall f_18545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18517)
static void C_ccall f_18517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18465)
static void C_fcall f_18465(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18473)
static void C_ccall f_18473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18347)
static void C_ccall f_18347(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_18353)
static void C_fcall f_18353(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_18455)
static void C_ccall f_18455(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_18363)
static void C_ccall f_18363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18430)
static void C_ccall f_18430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18371)
static void C_ccall f_18371(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_18422)
static void C_ccall f_18422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18375)
static void C_ccall f_18375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18384)
static void C_ccall f_18384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18387)
static void C_ccall f_18387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18394)
static void C_ccall f_18394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18226)
static void C_fcall f_18226(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_18333)
static void C_ccall f_18333(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_18249)
static void C_ccall f_18249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18308)
static void C_ccall f_18308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18257)
static void C_ccall f_18257(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_18300)
static void C_ccall f_18300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18261)
static void C_ccall f_18261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18270)
static void C_ccall f_18270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18273)
static void C_ccall f_18273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18139)
static void C_ccall f_18139(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_18216)
static void C_ccall f_18216(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_18149)
static void C_ccall f_18149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18195)
static void C_ccall f_18195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18167)
static void C_ccall f_18167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18159)
static void C_ccall f_18159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17994)
static void C_fcall f_17994(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_18010)
static void C_fcall f_18010(C_word t0,C_word t1) C_noret;
C_noret_decl(f_17944)
static void C_fcall f_17944(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_17950)
static void C_ccall f_17950(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_17663)
static void C_fcall f_17663(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_17673)
static void C_fcall f_17673(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_17837)
static void C_ccall f_17837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17841)
static void C_ccall f_17841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12421)
static void C_fcall f_12421(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12448)
static void C_ccall f_12448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12444)
static void C_ccall f_12444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17820)
static void C_ccall f_17820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17587)
static void C_fcall f_17587(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_17810)
static void C_ccall f_17810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17789)
static void C_ccall f_17789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17793)
static void C_ccall f_17793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17781)
static void C_ccall f_17781(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_17758)
static void C_ccall f_17758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17762)
static void C_ccall f_17762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17733)
static void C_ccall f_17733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17737)
static void C_ccall f_17737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17729)
static void C_ccall f_17729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17702)
static void C_ccall f_17702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17676)
static void C_ccall f_17676(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_17546)
static void C_fcall f_17546(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_17548)
static void C_ccall f_17548(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17555)
static void C_ccall f_17555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15182)
static void C_fcall f_15182(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15222)
static void C_ccall f_15222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15101)
static void C_fcall f_15101(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15107)
static void C_fcall f_15107(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_15156)
static void C_ccall f_15156(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15154)
static void C_ccall f_15154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15146)
static void C_ccall f_15146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15134)
static void C_ccall f_15134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15138)
static void C_ccall f_15138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14985)
static void C_fcall f_14985(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15018)
static void C_fcall f_15018(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15022)
static void C_fcall f_15022(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15030)
static void C_fcall f_15030(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14999)
static void C_ccall f_14999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14911)
static void C_fcall f_14911(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14919)
static void C_fcall f_14919(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14923)
static void C_fcall f_14923(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14437)
static void C_fcall f_14437(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14646)
static void C_fcall f_14646(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_14674)
static void C_fcall f_14674(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14831)
static void C_fcall f_14831(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14732)
static void C_fcall f_14732(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14802)
static void C_ccall f_14802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14737)
static void C_ccall f_14737(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_14790)
static void C_ccall f_14790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14750)
static void C_fcall f_14750(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14753)
static void C_fcall f_14753(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14760)
static void C_ccall f_14760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14718)
static void C_ccall f_14718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14679)
static void C_ccall f_14679(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_14706)
static void C_ccall f_14706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14690)
static void C_ccall f_14690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14468)
static void C_fcall f_14468(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_14517)
static void C_fcall f_14517(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14584)
static void C_ccall f_14584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14522)
static void C_ccall f_14522(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_14572)
static void C_ccall f_14572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14538)
static void C_fcall f_14538(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14542)
static void C_fcall f_14542(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14534)
static void C_ccall f_14534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14503)
static void C_ccall f_14503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14440)
static void C_fcall f_14440(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_14140)
static void C_fcall f_14140(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14255)
static void C_ccall f_14255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14153)
static void C_fcall f_14153(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_14348)
static void C_fcall f_14348(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_14427)
static void C_ccall f_14427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14366)
static void C_ccall f_14366(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14378)
static void C_ccall f_14378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14186)
static void C_ccall f_14186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14198)
static void C_fcall f_14198(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14233)
static void C_ccall f_14233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14205)
static void C_ccall f_14205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14229)
static void C_ccall f_14229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14221)
static void C_ccall f_14221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14167)
static void C_ccall f_14167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14332)
static void C_ccall f_14332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14336)
static void C_ccall f_14336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14275)
static void C_ccall f_14275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14294)
static void C_ccall f_14294(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14308)
static void C_ccall f_14308(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14306)
static void C_ccall f_14306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14292)
static void C_ccall f_14292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14277)
static C_word C_fcall f_14277(C_word t0,C_word t1);
C_noret_decl(f_13350)
static void C_fcall f_13350(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13368)
static void C_fcall f_13368(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_13631)
static void C_fcall f_13631(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13685)
static void C_fcall f_13685(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13945)
static void C_ccall f_13945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14033)
static void C_ccall f_14033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13951)
static void C_ccall f_13951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14029)
static void C_ccall f_14029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13954)
static void C_ccall f_13954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14009)
static void C_ccall f_14009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13960)
static void C_fcall f_13960(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13979)
static void C_ccall f_13979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13885)
static void C_ccall f_13885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13929)
static void C_ccall f_13929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13891)
static void C_ccall f_13891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13913)
static void C_ccall f_13913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13782)
static void C_ccall f_13782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13864)
static void C_ccall f_13864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13785)
static void C_ccall f_13785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13849)
static void C_ccall f_13849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13788)
static void C_ccall f_13788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13814)
static void C_ccall f_13814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13806)
static void C_ccall f_13806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13810)
static void C_ccall f_13810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13802)
static void C_ccall f_13802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13773)
static void C_ccall f_13773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13688)
static void C_ccall f_13688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13715)
static void C_ccall f_13715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13743)
static void C_ccall f_13743(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13741)
static void C_ccall f_13741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13729)
static void C_ccall f_13729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13733)
static void C_ccall f_13733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13704)
static void C_ccall f_13704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13634)
static void C_ccall f_13634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13637)
static void C_ccall f_13637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13651)
static void C_ccall f_13651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13614)
static void C_ccall f_13614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13591)
static void C_ccall f_13591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13514)
static void C_ccall f_13514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13481)
static void C_fcall f_13481(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13503)
static void C_ccall f_13503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13488)
static void C_ccall f_13488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13458)
static void C_ccall f_13458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13437)
static void C_ccall f_13437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13433)
static void C_ccall f_13433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13385)
static void C_fcall f_13385(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13400)
static void C_ccall f_13400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13406)
static void C_ccall f_13406(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13404)
static void C_ccall f_13404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13371)
static void C_fcall f_13371(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13243)
static void C_fcall f_13243(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13257)
static void C_fcall f_13257(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13295)
static void C_ccall f_13295(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13270)
static void C_ccall f_13270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13065)
static void C_ccall f_13065(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13069)
static void C_ccall f_13069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13072)
static void C_ccall f_13072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13084)
static void C_ccall f_13084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13112)
static void C_ccall f_13112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13129)
static void C_ccall f_13129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13115)
static void C_ccall f_13115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13109)
static void C_ccall f_13109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13087)
static void C_ccall f_13087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13105)
static void C_ccall f_13105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13102)
static void C_ccall f_13102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12906)
static void C_ccall f_12906(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_12913)
static void C_ccall f_12913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13029)
static void C_ccall f_13029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13034)
static void C_fcall f_13034(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13062)
static void C_ccall f_13062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13044)
static void C_ccall f_13044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13026)
static void C_ccall f_13026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12919)
static void C_ccall f_12919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13022)
static void C_ccall f_13022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13164)
static void C_fcall f_13164(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13199)
static void C_ccall f_13199(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13183)
static void C_ccall f_13183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12944)
static void C_ccall f_12944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13018)
static void C_ccall f_13018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12953)
static void C_ccall f_12953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12959)
static void C_ccall f_12959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12964)
static void C_fcall f_12964(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12974)
static void C_ccall f_12974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12989)
static void C_ccall f_12989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12986)
static void C_ccall f_12986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12941)
static void C_ccall f_12941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12922)
static void C_ccall f_12922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12937)
static void C_ccall f_12937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12934)
static void C_ccall f_12934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12860)
static void C_ccall f_12860(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_12860)
static void C_ccall f_12860r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_12864)
static void C_ccall f_12864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12882)
static void C_fcall f_12882(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12873)
static void C_ccall f_12873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12743)
static void C_ccall f_12743(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12762)
static void C_fcall f_12762(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12833)
static void C_ccall f_12833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12800)
static void C_ccall f_12800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12707)
static void C_fcall f_12707(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12737)
static void C_ccall f_12737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12729)
static void C_ccall f_12729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12477)
static void C_fcall f_12477(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12575)
static void C_fcall f_12575(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12362)
static void C_ccall f_12362(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12337)
static C_word C_fcall f_12337(C_word *a,C_word t0);
C_noret_decl(f_12312)
static C_word C_fcall f_12312(C_word *a,C_word t0);
C_noret_decl(f_11217)
static void C_fcall f_11217(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11223)
static void C_ccall f_11223(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11248)
static void C_fcall f_11248(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11191)
static void C_ccall f_11191(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11105)
static void C_ccall f_11105(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11144)
static void C_fcall f_11144(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11157)
static void C_ccall f_11157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11019)
static void C_ccall f_11019(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11058)
static void C_fcall f_11058(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10963)
static C_word C_fcall f_10963(C_word t0);
C_noret_decl(f_10887)
static void C_ccall f_10887(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10912)
static void C_fcall f_10912(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10759)
static void C_ccall f_10759(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10778)
static void C_fcall f_10778(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10827)
static void C_fcall f_10827(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10618)
static void C_ccall f_10618(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_10618)
static void C_ccall f_10618r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_10622)
static void C_ccall f_10622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10305)
static void C_ccall f_10305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10309)
static void C_ccall f_10309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10311)
static void C_fcall f_10311(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10565)
static void C_fcall f_10565(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10576)
static void C_ccall f_10576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10572)
static void C_ccall f_10572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10424)
static void C_fcall f_10424(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10528)
static void C_ccall f_10528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10509)
static void C_ccall f_10509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10433)
static void C_ccall f_10433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10454)
static void C_ccall f_10454(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10439)
static void C_ccall f_10439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10449)
static void C_ccall f_10449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10407)
static void C_ccall f_10407(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10405)
static void C_ccall f_10405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10380)
static void C_ccall f_10380(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10378)
static void C_ccall f_10378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10314)
static void C_ccall f_10314(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10625)
static void C_ccall f_10625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10628)
static void C_ccall f_10628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10631)
static void C_ccall f_10631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10634)
static void C_fcall f_10634(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10708)
static void C_ccall f_10708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10637)
static void C_ccall f_10637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10640)
static void C_ccall f_10640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10643)
static void C_ccall f_10643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15238)
static void C_fcall f_15238(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_15562)
static void C_ccall f_15562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15252)
static void C_ccall f_15252(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_15265)
static void C_ccall f_15265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15256)
static void C_ccall f_15256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15257)
static void C_ccall f_15257(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_15513)
static void C_ccall f_15513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15514)
static void C_ccall f_15514(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_15518)
static void C_ccall f_15518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15521)
static void C_fcall f_15521(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15488)
static void C_ccall f_15488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15489)
static void C_ccall f_15489(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_15493)
static void C_ccall f_15493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15432)
static void C_ccall f_15432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15457)
static void C_ccall f_15457(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_15461)
static void C_ccall f_15461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15434)
static void C_ccall f_15434(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_15438)
static void C_ccall f_15438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15382)
static void C_ccall f_15382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15407)
static void C_ccall f_15407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15385)
static void C_ccall f_15385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15386)
static void C_ccall f_15386(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_15390)
static void C_ccall f_15390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15289)
static void C_ccall f_15289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15358)
static void C_ccall f_15358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15292)
static void C_ccall f_15292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15293)
static void C_ccall f_15293(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_15299)
static void C_fcall f_15299(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_15309)
static void C_ccall f_15309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15312)
static void C_ccall f_15312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10646)
static void C_ccall f_10646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10649)
static void C_ccall f_10649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10652)
static void C_ccall f_10652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11280)
static void C_ccall f_11280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12301)
static void C_ccall f_12301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11283)
static void C_ccall f_11283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11292)
static void C_fcall f_11292(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_11337)
static void C_fcall f_11337(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11366)
static void C_fcall f_11366(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12096)
static void C_fcall f_12096(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12146)
static void C_fcall f_12146(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12123)
static void C_ccall f_12123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12069)
static void C_ccall f_12069(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12039)
static void C_ccall f_12039(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11895)
static void C_fcall f_11895(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11898)
static void C_fcall f_11898(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11963)
static void C_ccall f_11963(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11916)
static void C_ccall f_11916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11928)
static void C_fcall f_11928(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11875)
static void C_ccall f_11875(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11866)
static void C_ccall f_11866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11753)
static void C_ccall f_11753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11816)
static void C_ccall f_11816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11762)
static void C_fcall f_11762(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11713)
static void C_ccall f_11713(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11542)
static void C_fcall f_11542(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11548)
static void C_ccall f_11548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11551)
static void C_ccall f_11551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11633)
static void C_fcall f_11633(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11560)
static void C_ccall f_11560(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11574)
static void C_ccall f_11574(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11586)
static void C_ccall f_11586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11588)
static void C_ccall f_11588(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11617)
static void C_ccall f_11617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11613)
static void C_ccall f_11613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11600)
static void C_fcall f_11600(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11457)
static void C_fcall f_11457(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_11490)
static void C_ccall f_11490(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11523)
static void C_ccall f_11523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11506)
static void C_ccall f_11506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11510)
static void C_ccall f_11510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11375)
static void C_fcall f_11375(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_11408)
static void C_ccall f_11408(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11438)
static void C_ccall f_11438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11353)
static void C_ccall f_11353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11295)
static void C_fcall f_11295(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11290)
static void C_ccall f_11290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10674)
static void C_ccall f_10674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10681)
static void C_ccall f_10681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10658)
static void C_ccall f_10658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17528)
static void C_fcall f_17528(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15569)
static void C_ccall f_15569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15581)
static void C_fcall f_15581(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17516)
static void C_ccall f_17516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17435)
static void C_ccall f_17435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17468)
static void C_ccall f_17468(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17475)
static void C_fcall f_17475(C_word t0,C_word t1) C_noret;
C_noret_decl(f_17436)
static void C_ccall f_17436(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17443)
static void C_ccall f_17443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17339)
static void C_ccall f_17339(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17346)
static void C_fcall f_17346(C_word t0,C_word t1) C_noret;
C_noret_decl(f_17281)
static void C_ccall f_17281(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17300)
static void C_fcall f_17300(C_word t0,C_word t1) C_noret;
C_noret_decl(f_17288)
static void C_fcall f_17288(C_word t0,C_word t1) C_noret;
C_noret_decl(f_17247)
static void C_ccall f_17247(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17257)
static void C_fcall f_17257(C_word t0,C_word t1) C_noret;
C_noret_decl(f_17223)
static void C_ccall f_17223(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17165)
static void C_ccall f_17165(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17184)
static void C_fcall f_17184(C_word t0,C_word t1) C_noret;
C_noret_decl(f_17172)
static void C_fcall f_17172(C_word t0,C_word t1) C_noret;
C_noret_decl(f_17131)
static void C_ccall f_17131(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17141)
static void C_fcall f_17141(C_word t0,C_word t1) C_noret;
C_noret_decl(f_17111)
static void C_ccall f_17111(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17069)
static void C_ccall f_17069(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17076)
static void C_fcall f_17076(C_word t0,C_word t1) C_noret;
C_noret_decl(f_17041)
static void C_ccall f_17041(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_15627)
static void C_fcall f_15627(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16993)
static void C_ccall f_16993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16953)
static void C_ccall f_16953(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16965)
static void C_ccall f_16965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16923)
static void C_ccall f_16923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16924)
static void C_ccall f_16924(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16936)
static void C_ccall f_16936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16796)
static void C_ccall f_16796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16852)
static void C_ccall f_16852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16800)
static void C_ccall f_16800(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16804)
static void C_ccall f_16804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16838)
static void C_ccall f_16838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16822)
static void C_ccall f_16822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16654)
static void C_ccall f_16654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16657)
static void C_ccall f_16657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16764)
static void C_ccall f_16764(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16759)
static void C_ccall f_16759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16755)
static void C_ccall f_16755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16660)
static void C_ccall f_16660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16669)
static void C_fcall f_16669(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16715)
static void C_ccall f_16715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16716)
static void C_ccall f_16716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16722)
static void C_ccall f_16722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16672)
static void C_ccall f_16672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16673)
static void C_ccall f_16673(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16640)
static void C_ccall f_16640(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16617)
static void C_ccall f_16617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16618)
static void C_ccall f_16618(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16633)
static void C_ccall f_16633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16622)
static void C_ccall f_16622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16599)
static void C_ccall f_16599(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16568)
static void C_ccall f_16568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16569)
static void C_ccall f_16569(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16590)
static void C_ccall f_16590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16592)
static void C_ccall f_16592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16586)
static void C_ccall f_16586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16550)
static void C_ccall f_16550(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16519)
static void C_ccall f_16519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16520)
static void C_ccall f_16520(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16541)
static void C_ccall f_16541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16543)
static void C_ccall f_16543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16537)
static void C_ccall f_16537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16505)
static void C_ccall f_16505(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16482)
static void C_ccall f_16482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16483)
static void C_ccall f_16483(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16498)
static void C_ccall f_16498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16490)
static void C_ccall f_16490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16468)
static void C_ccall f_16468(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16445)
static void C_ccall f_16445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16446)
static void C_ccall f_16446(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16461)
static void C_ccall f_16461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16453)
static void C_ccall f_16453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16432)
static void C_ccall f_16432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16407)
static void C_ccall f_16407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16342)
static void C_ccall f_16342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16155)
static void C_fcall f_16155(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16158)
static void C_fcall f_16158(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16181)
static void C_ccall f_16181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16247)
static void C_ccall f_16247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16231)
static void C_ccall f_16231(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_16184)
static void C_ccall f_16184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16216)
static void C_ccall f_16216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16211)
static void C_ccall f_16211(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_16205)
static void C_ccall f_16205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16201)
static void C_ccall f_16201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16159)
static void C_ccall f_16159(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16136)
static void C_ccall f_16136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16103)
static void C_ccall f_16103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16054)
static void C_ccall f_16054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15991)
static void C_ccall f_15991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16015)
static void C_ccall f_16015(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16021)
static void C_ccall f_16021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15998)
static void C_ccall f_15998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15999)
static void C_ccall f_15999(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16005)
static void C_ccall f_16005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15933)
static void C_ccall f_15933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15957)
static void C_ccall f_15957(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_15963)
static void C_ccall f_15963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15940)
static void C_ccall f_15940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15941)
static void C_ccall f_15941(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_15947)
static void C_ccall f_15947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15902)
static void C_ccall f_15902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15903)
static void C_ccall f_15903(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_15909)
static void C_ccall f_15909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15874)
static void C_ccall f_15874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15875)
static void C_ccall f_15875(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_15881)
static void C_ccall f_15881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15853)
static void C_ccall f_15853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15834)
static void C_ccall f_15834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15796)
static void C_ccall f_15796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15775)
static void C_ccall f_15775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15754)
static void C_ccall f_15754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15733)
static void C_ccall f_15733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15674)
static void C_ccall f_15674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15700)
static void C_ccall f_15700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15677)
static void C_ccall f_15677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15678)
static void C_ccall f_15678(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_15684)
static void C_ccall f_15684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15654)
static void C_ccall f_15654(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_15638)
static void C_ccall f_15638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15634)
static void C_ccall f_15634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15615)
static void C_ccall f_15615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15607)
static void C_ccall f_15607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15584)
static void C_fcall f_15584(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15578)
static void C_ccall f_15578(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_10667)
static void C_ccall f_10667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10608)
static void C_ccall f_10608(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_10608)
static void C_ccall f_10608r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_10616)
static void C_ccall f_10616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10587)
static void C_ccall f_10587(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_10587)
static void C_ccall f_10587r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_10594)
static void C_ccall f_10594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10137)
static void C_fcall f_10137(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10143)
static void C_fcall f_10143(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10234)
static void C_fcall f_10234(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9296)
static void C_ccall f_9296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9299)
static void C_ccall f_9299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10000)
static void C_ccall f_10000(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9998)
static void C_ccall f_9998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9978)
static void C_ccall f_9978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9974)
static void C_ccall f_9974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9892)
static void C_ccall f_9892(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9970)
static void C_ccall f_9970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9966)
static void C_ccall f_9966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9962)
static void C_ccall f_9962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9958)
static void C_ccall f_9958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9934)
static void C_ccall f_9934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9910)
static void C_ccall f_9910(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9908)
static void C_ccall f_9908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9800)
static void C_ccall f_9800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9874)
static void C_ccall f_9874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9822)
static void C_ccall f_9822(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9820)
static void C_ccall f_9820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9792)
static void C_ccall f_9792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9320)
static void C_ccall f_9320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9325)
static void C_fcall f_9325(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9397)
static void C_ccall f_9397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10075)
static void C_fcall f_10075(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10081)
static void C_ccall f_10081(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10079)
static void C_ccall f_10079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9405)
static void C_ccall f_9405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9382)
static void C_ccall f_9382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9386)
static void C_ccall f_9386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9353)
static void C_ccall f_9353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10249)
static void C_ccall f_10249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10161)
static void C_ccall f_10161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10179)
static void C_ccall f_10179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10165)
static void C_fcall f_10165(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10157)
static void C_ccall f_10157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9653)
static void C_fcall f_9653(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9771)
static void C_ccall f_9771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9763)
static void C_ccall f_9763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9755)
static void C_ccall f_9755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9723)
static void C_ccall f_9723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9751)
static void C_ccall f_9751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9719)
static void C_ccall f_9719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9675)
static void C_ccall f_9675(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9673)
static void C_ccall f_9673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9525)
static void C_fcall f_9525(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9643)
static void C_ccall f_9643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9635)
static void C_ccall f_9635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9627)
static void C_ccall f_9627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9595)
static void C_ccall f_9595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9623)
static void C_ccall f_9623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9591)
static void C_ccall f_9591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9547)
static void C_ccall f_9547(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9545)
static void C_ccall f_9545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9439)
static void C_fcall f_9439(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9473)
static void C_ccall f_9473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9481)
static void C_ccall f_9481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9491)
static void C_ccall f_9491(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9489)
static void C_ccall f_9489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9485)
static void C_ccall f_9485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9469)
static void C_ccall f_9469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9163)
static void C_fcall f_9163(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9287)
static void C_ccall f_9287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9251)
static void C_ccall f_9251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9283)
static void C_ccall f_9283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9279)
static void C_ccall f_9279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9255)
static void C_ccall f_9255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9275)
static void C_ccall f_9275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9271)
static void C_ccall f_9271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9259)
static void C_ccall f_9259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9267)
static void C_ccall f_9267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9263)
static void C_ccall f_9263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9238)
static void C_ccall f_9238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9214)
static void C_ccall f_9214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9234)
static void C_ccall f_9234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9230)
static void C_ccall f_9230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9218)
static void C_ccall f_9218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9226)
static void C_ccall f_9226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9222)
static void C_ccall f_9222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9201)
static void C_ccall f_9201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9189)
static void C_ccall f_9189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9197)
static void C_ccall f_9197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9193)
static void C_ccall f_9193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9103)
static void C_fcall f_9103(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8878)
static void C_fcall f_8878(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9053)
static void C_ccall f_9053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9005)
static void C_ccall f_9005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9041)
static void C_ccall f_9041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9009)
static void C_ccall f_9009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9029)
static void C_ccall f_9029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9013)
static void C_ccall f_9013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9017)
static void C_ccall f_9017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9001)
static void C_ccall f_9001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8984)
static void C_ccall f_8984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8952)
static void C_ccall f_8952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8972)
static void C_ccall f_8972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8956)
static void C_ccall f_8956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8960)
static void C_ccall f_8960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8948)
static void C_ccall f_8948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8931)
static void C_ccall f_8931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8915)
static void C_ccall f_8915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8919)
static void C_ccall f_8919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8881)
static C_word C_fcall f_8881(C_word t0,C_word t1);
C_noret_decl(f_8858)
static void C_ccall f_8858(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8066)
static void C_fcall f_8066(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8133)
static void C_ccall f_8133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8136)
static void C_ccall f_8136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4216)
static void C_fcall f_4216(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8085)
static void C_ccall f_8085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8097)
static void C_ccall f_8097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8100)
static void C_ccall f_8100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5115)
static void C_ccall f_5115(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5115)
static void C_ccall f_5115r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5122)
static void C_ccall f_5122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5127)
static void C_fcall f_5127(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_7973)
static void C_ccall f_7973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7976)
static void C_ccall f_7976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7994)
static void C_ccall f_7994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7939)
static void C_ccall f_7939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7954)
static void C_ccall f_7954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7927)
static void C_ccall f_7927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7924)
static void C_ccall f_7924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7896)
static void C_ccall f_7896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7893)
static void C_ccall f_7893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7865)
static void C_ccall f_7865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7832)
static void C_ccall f_7832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7814)
static void C_ccall f_7814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4274)
static void C_fcall f_4274(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7722)
static void C_ccall f_7722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7765)
static void C_ccall f_7765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7758)
static void C_ccall f_7758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7754)
static void C_ccall f_7754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7746)
static void C_ccall f_7746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7742)
static void C_ccall f_7742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7608)
static void C_ccall f_7608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7617)
static void C_fcall f_7617(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7679)
static void C_ccall f_7679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7524)
static void C_fcall f_7524(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7527)
static void C_ccall f_7527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7530)
static void C_ccall f_7530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7580)
static void C_ccall f_7580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7577)
static void C_ccall f_7577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7569)
static void C_ccall f_7569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7565)
static void C_ccall f_7565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7499)
static void C_ccall f_7499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7471)
static void C_ccall f_7471(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7495)
static void C_ccall f_7495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7491)
static void C_ccall f_7491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7460)
static void C_ccall f_7460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7456)
static void C_ccall f_7456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7431)
static void C_ccall f_7431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7427)
static void C_ccall f_7427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7402)
static void C_ccall f_7402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7398)
static void C_ccall f_7398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7373)
static void C_ccall f_7373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7369)
static void C_ccall f_7369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7344)
static void C_ccall f_7344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7340)
static void C_ccall f_7340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7311)
static void C_ccall f_7311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7307)
static void C_ccall f_7307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7274)
static void C_ccall f_7274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7270)
static void C_ccall f_7270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7245)
static void C_ccall f_7245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7241)
static void C_ccall f_7241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7208)
static void C_ccall f_7208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7204)
static void C_ccall f_7204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7155)
static void C_ccall f_7155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7151)
static void C_ccall f_7151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7110)
static void C_ccall f_7110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7106)
static void C_ccall f_7106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7073)
static void C_ccall f_7073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7069)
static void C_ccall f_7069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7040)
static void C_ccall f_7040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7036)
static void C_ccall f_7036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7007)
static void C_ccall f_7007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7003)
static void C_ccall f_7003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6974)
static void C_ccall f_6974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6970)
static void C_ccall f_6970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6904)
static void C_fcall f_6904(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6723)
static void C_fcall f_6723(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6733)
static void C_ccall f_6733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6742)
static void C_ccall f_6742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6886)
static void C_ccall f_6886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4315)
static void C_fcall f_4315(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4360)
static void C_ccall f_4360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4339)
static void C_ccall f_4339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4318)
static void C_fcall f_4318(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4326)
static void C_ccall f_4326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6745)
static void C_ccall f_6745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6748)
static void C_ccall f_6748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6754)
static void C_ccall f_6754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6852)
static void C_ccall f_6852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6817)
static void C_ccall f_6817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6783)
static void C_ccall f_6783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8177)
static void C_ccall f_8177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8849)
static void C_ccall f_8849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8179)
static void C_fcall f_8179(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8796)
static void C_ccall f_8796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8814)
static void C_ccall f_8814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8666)
static void C_fcall f_8666(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8723)
static void C_ccall f_8723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8711)
static void C_ccall f_8711(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8696)
static void C_ccall f_8696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8669)
static void C_ccall f_8669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8692)
static void C_ccall f_8692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8680)
static void C_ccall f_8680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8688)
static void C_ccall f_8688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8684)
static void C_ccall f_8684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8533)
static void C_ccall f_8533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8542)
static void C_fcall f_8542(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8585)
static void C_ccall f_8585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8581)
static void C_ccall f_8581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8548)
static void C_ccall f_8548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8551)
static void C_ccall f_8551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8574)
static void C_ccall f_8574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8562)
static void C_ccall f_8562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8570)
static void C_ccall f_8570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8566)
static void C_ccall f_8566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8481)
static void C_fcall f_8481(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8329)
static void C_fcall f_8329(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8409)
static void C_fcall f_8409(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8422)
static void C_ccall f_8422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8432)
static void C_ccall f_8432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8436)
static void C_ccall f_8436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8392)
static void C_ccall f_8392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8360)
static void C_ccall f_8360(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8218)
static void C_ccall f_8218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8221)
static void C_ccall f_8221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4820)
static void C_fcall f_4820(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4841)
static void C_fcall f_4841(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8224)
static void C_ccall f_8224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8297)
static void C_ccall f_8297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8301)
static void C_ccall f_8301(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8293)
static void C_ccall f_8293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8289)
static void C_ccall f_8289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8244)
static void C_fcall f_8244(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8272)
static void C_ccall f_8272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8254)
static void C_ccall f_8254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17628)
static void C_fcall f_17628(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8265)
static void C_ccall f_8265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8248)
static void C_fcall f_8248(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8231)
static void C_ccall f_8231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6704)
static void C_ccall f_6704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6680)
static void C_ccall f_6680(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6700)
static void C_ccall f_6700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6665)
static void C_ccall f_6665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5930)
static void C_ccall f_5930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5934)
static void C_ccall f_5934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6399)
static void C_fcall f_6399(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6584)
static void C_ccall f_6584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6596)
static void C_ccall f_6596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6563)
static void C_ccall f_6563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6559)
static void C_ccall f_6559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6514)
static void C_ccall f_6514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6494)
static void C_ccall f_6494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6477)
static void C_ccall f_6477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6460)
static void C_ccall f_6460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6411)
static void C_fcall f_6411(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6415)
static void C_ccall f_6415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6418)
static void C_ccall f_6418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6402)
static void C_fcall f_6402(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6357)
static void C_ccall f_6357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6361)
static void C_ccall f_6361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6300)
static void C_ccall f_6300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6334)
static void C_ccall f_6334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6303)
static void C_ccall f_6303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6318)
static void C_ccall f_6318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6326)
static void C_ccall f_6326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6240)
static void C_ccall f_6240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6283)
static void C_ccall f_6283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6243)
static void C_ccall f_6243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6267)
static void C_ccall f_6267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6275)
static void C_ccall f_6275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6212)
static void C_ccall f_6212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6216)
static void C_ccall f_6216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6120)
static void C_ccall f_6120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6138)
static void C_ccall f_6138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6158)
static void C_ccall f_6158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6150)
static void C_ccall f_6150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6146)
static void C_ccall f_6146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6113)
static void C_ccall f_6113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6117)
static void C_ccall f_6117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6088)
static void C_ccall f_6088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6092)
static void C_ccall f_6092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6045)
static void C_ccall f_6045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6049)
static void C_ccall f_6049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6020)
static void C_ccall f_6020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6024)
static void C_ccall f_6024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5995)
static void C_ccall f_5995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5999)
static void C_ccall f_5999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5955)
static void C_ccall f_5955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5970)
static void C_ccall f_5970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5843)
static void C_ccall f_5843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5849)
static void C_ccall f_5849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5864)
static void C_ccall f_5864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5646)
static void C_ccall f_5646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5813)
static void C_ccall f_5813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5784)
static void C_ccall f_5784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5759)
static void C_ccall f_5759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5742)
static void C_ccall f_5742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5725)
static void C_ccall f_5725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5700)
static void C_ccall f_5700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5677)
static void C_fcall f_5677(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5637)
static void C_ccall f_5637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5634)
static void C_ccall f_5634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5572)
static void C_fcall f_5572(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5584)
static void C_ccall f_5584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5272)
static void C_fcall f_5272(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5276)
static void C_ccall f_5276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5570)
static void C_ccall f_5570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5279)
static void C_fcall f_5279(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5532)
static void C_fcall f_5532(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5543)
static void C_ccall f_5543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5282)
static void C_fcall f_5282(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5525)
static void C_ccall f_5525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5514)
static void C_ccall f_5514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5285)
static void C_ccall f_5285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5290)
static void C_fcall f_5290(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5454)
static void C_ccall f_5454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5392)
static void C_fcall f_5392(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5359)
static void C_fcall f_5359(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5293)
static C_word C_fcall f_5293(C_word *a,C_word t0);
C_noret_decl(f_5200)
static void C_fcall f_5200(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5204)
static void C_ccall f_5204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9068)
static void C_fcall f_9068(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5207)
static void C_ccall f_5207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5244)
static void C_ccall f_5244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5216)
static void C_ccall f_5216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5240)
static void C_ccall f_5240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5236)
static void C_ccall f_5236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5180)
static void C_fcall f_5180(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5198)
static void C_ccall f_5198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5194)
static void C_ccall f_5194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5160)
static void C_fcall f_5160(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5167)
static void C_ccall f_5167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5178)
static void C_ccall f_5178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5174)
static void C_ccall f_5174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5130)
static void C_ccall f_5130(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5155)
static void C_ccall f_5155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5015)
static void C_fcall f_5015(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5021)
static void C_fcall f_5021(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5052)
static void C_fcall f_5052(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5046)
static void C_fcall f_5046(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5039)
static void C_ccall f_5039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4996)
static void C_ccall f_4996(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4987)
static void C_ccall f_4987(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4977)
static void C_fcall f_4977(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4985)
static void C_ccall f_4985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4930)
static void C_fcall f_4930(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4962)
static void C_ccall f_4962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4966)
static void C_ccall f_4966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4958)
static void C_ccall f_4958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4883)
static void C_fcall f_4883(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4915)
static void C_ccall f_4915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4919)
static void C_ccall f_4919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4911)
static void C_ccall f_4911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4867)
static void C_fcall f_4867(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4875)
static void C_ccall f_4875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4857)
static void C_fcall f_4857(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4865)
static void C_ccall f_4865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4771)
static void C_fcall f_4771(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4777)
static void C_fcall f_4777(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4801)
static void C_ccall f_4801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4798)
static void C_fcall f_4798(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4741)
static void C_fcall f_4741(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4747)
static void C_fcall f_4747(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4765)
static void C_ccall f_4765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4692)
static void C_fcall f_4692(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4712)
static void C_fcall f_4712(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4728)
static void C_ccall f_4728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4643)
static void C_fcall f_4643(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4663)
static void C_fcall f_4663(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4676)
static void C_ccall f_4676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4601)
static void C_fcall f_4601(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4616)
static C_word C_fcall f_4616(C_word t0);
C_noret_decl(f_4569)
static void C_fcall f_4569(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4575)
static void C_fcall f_4575(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4588)
static void C_ccall f_4588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4557)
static void C_fcall f_4557(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4561)
static void C_ccall f_4561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4514)
static void C_fcall f_4514(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4520)
static void C_fcall f_4520(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4527)
static void C_fcall f_4527(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4475)
static void C_fcall f_4475(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4491)
static void C_fcall f_4491(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4418)
static void C_fcall f_4418(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4428)
static void C_ccall f_4428(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4426)
static void C_ccall f_4426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4442)
static void C_ccall f_4442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4447)
static void C_fcall f_4447(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4391)
static void C_fcall f_4391(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4466)
static void C_ccall f_4466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4445)
static void C_ccall f_4445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4158)
static void C_fcall f_4158(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4171)
static void C_fcall f_4171(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4143)
static void C_ccall f_4143(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4143)
static void C_ccall f_4143r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4151)
static void C_ccall f_4151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4120)
static void C_ccall f_4120(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4120)
static void C_ccall f_4120r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4124)
static void C_ccall f_4124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4077)
static void C_ccall f_4077(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4077)
static void C_ccall f_4077r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4081)
static void C_ccall f_4081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4094)
static void C_ccall f_4094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4045)
static C_word C_fcall f_4045(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_3999)
static void C_fcall f_3999(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3925)
static void C_ccall f_3925(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3907)
static void C_ccall f_3907(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3915)
static void C_ccall f_3915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3854)
static void C_ccall f_3854(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3820)
static void C_ccall f_3820(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3830)
static void C_fcall f_3830(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3806)
static void C_ccall f_3806(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3814)
static void C_ccall f_3814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3818)
static void C_ccall f_3818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3884)
static void C_ccall f_3884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3800)
static void C_ccall f_3800(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3794)
static void C_ccall f_3794(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3788)
static void C_ccall f_3788(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3782)
static void C_ccall f_3782(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3776)
static void C_ccall f_3776(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3770)
static void C_ccall f_3770(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3764)
static void C_ccall f_3764(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3758)
static void C_ccall f_3758(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3732)
static void C_ccall f_3732(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_20452)
static void C_fcall trf_20452(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20452(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_20452(t0,t1,t2);}

C_noret_decl(trf_20388)
static void C_fcall trf_20388(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20388(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_20388(t0,t1,t2);}

C_noret_decl(trf_20116)
static void C_fcall trf_20116(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20116(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_20116(t0,t1,t2);}

C_noret_decl(trf_20178)
static void C_fcall trf_20178(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20178(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_20178(t0,t1,t2);}

C_noret_decl(trf_20208)
static void C_fcall trf_20208(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20208(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_20208(t0,t1);}

C_noret_decl(trf_20237)
static void C_fcall trf_20237(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20237(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_20237(t0,t1);}

C_noret_decl(trf_20027)
static void C_fcall trf_20027(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20027(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_20027(t0,t1,t2);}

C_noret_decl(trf_20046)
static void C_fcall trf_20046(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20046(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_20046(t0,t1);}

C_noret_decl(trf_19977)
static void C_fcall trf_19977(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19977(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_19977(t0,t1,t2,t3);}

C_noret_decl(trf_19849)
static void C_fcall trf_19849(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19849(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_19849(t0,t1,t2,t3);}

C_noret_decl(trf_19743)
static void C_fcall trf_19743(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19743(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_19743(t0,t1,t2);}

C_noret_decl(trf_19749)
static void C_fcall trf_19749(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19749(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_19749(t0,t1,t2,t3);}

C_noret_decl(trf_19544)
static void C_fcall trf_19544(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19544(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_19544(t0,t1);}

C_noret_decl(trf_19552)
static void C_fcall trf_19552(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19552(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_19552(t0,t1,t2,t3);}

C_noret_decl(trf_19480)
static void C_fcall trf_19480(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19480(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_19480(t0,t1);}

C_noret_decl(trf_19471)
static void C_fcall trf_19471(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19471(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_19471(t0,t1,t2);}

C_noret_decl(trf_19407)
static void C_fcall trf_19407(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19407(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_19407(t0,t1,t2,t3);}

C_noret_decl(trf_19432)
static void C_fcall trf_19432(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19432(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_19432(t0,t1,t2,t3);}

C_noret_decl(trf_19360)
static void C_fcall trf_19360(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19360(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_19360(t0,t1);}

C_noret_decl(trf_19351)
static void C_fcall trf_19351(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19351(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_19351(t0,t1,t2);}

C_noret_decl(trf_19295)
static void C_fcall trf_19295(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19295(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_19295(t0,t1,t2,t3);}

C_noret_decl(trf_19320)
static void C_fcall trf_19320(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19320(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_19320(t0,t1,t2,t3);}

C_noret_decl(trf_19250)
static void C_fcall trf_19250(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19250(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_19250(t0,t1,t2,t3);}

C_noret_decl(trf_19204)
static void C_fcall trf_19204(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19204(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_19204(t0,t1,t2,t3);}

C_noret_decl(trf_19164)
static void C_fcall trf_19164(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19164(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_19164(t0,t1);}

C_noret_decl(trf_19104)
static void C_fcall trf_19104(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19104(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_19104(t0,t1);}

C_noret_decl(trf_19099)
static void C_fcall trf_19099(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19099(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_19099(t0,t1,t2);}

C_noret_decl(trf_19094)
static void C_fcall trf_19094(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19094(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_19094(t0,t1,t2,t3);}

C_noret_decl(trf_19063)
static void C_fcall trf_19063(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19063(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_19063(t0,t1,t2,t3,t4);}

C_noret_decl(trf_19075)
static void C_fcall trf_19075(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19075(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_19075(t0,t1);}

C_noret_decl(trf_19078)
static void C_fcall trf_19078(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19078(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_19078(t0,t1);}

C_noret_decl(trf_19081)
static void C_fcall trf_19081(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19081(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_19081(t0,t1);}

C_noret_decl(trf_18867)
static void C_fcall trf_18867(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18867(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_18867(t0,t1,t2,t3);}

C_noret_decl(trf_18849)
static void C_fcall trf_18849(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18849(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_18849(t0,t1);}

C_noret_decl(trf_18826)
static void C_fcall trf_18826(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18826(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_18826(t0,t1);}

C_noret_decl(trf_18730)
static void C_fcall trf_18730(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18730(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_18730(t0,t1);}

C_noret_decl(trf_18701)
static void C_fcall trf_18701(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18701(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_18701(t0,t1);}

C_noret_decl(trf_18664)
static void C_fcall trf_18664(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18664(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_18664(t0,t1,t2,t3);}

C_noret_decl(trf_18481)
static void C_fcall trf_18481(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18481(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_18481(t0,t1,t2,t3);}

C_noret_decl(trf_18497)
static void C_fcall trf_18497(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18497(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_18497(t0,t1);}

C_noret_decl(trf_18534)
static void C_fcall trf_18534(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18534(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_18534(t0,t1);}

C_noret_decl(trf_18465)
static void C_fcall trf_18465(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18465(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_18465(t0,t1);}

C_noret_decl(trf_18353)
static void C_fcall trf_18353(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18353(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_18353(t0,t1,t2,t3,t4);}

C_noret_decl(trf_18226)
static void C_fcall trf_18226(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18226(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_18226(t0,t1,t2);}

C_noret_decl(trf_17994)
static void C_fcall trf_17994(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_17994(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_17994(t0,t1,t2);}

C_noret_decl(trf_18010)
static void C_fcall trf_18010(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18010(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_18010(t0,t1);}

C_noret_decl(trf_17944)
static void C_fcall trf_17944(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_17944(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_17944(t0,t1,t2);}

C_noret_decl(trf_17663)
static void C_fcall trf_17663(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_17663(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_17663(t0,t1,t2);}

C_noret_decl(trf_17673)
static void C_fcall trf_17673(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_17673(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_17673(t0,t1,t2,t3);}

C_noret_decl(trf_12421)
static void C_fcall trf_12421(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12421(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_12421(t0,t1,t2,t3);}

C_noret_decl(trf_17587)
static void C_fcall trf_17587(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_17587(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_17587(t0,t1,t2,t3);}

C_noret_decl(trf_17546)
static void C_fcall trf_17546(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_17546(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_17546(t0,t1,t2);}

C_noret_decl(trf_15182)
static void C_fcall trf_15182(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15182(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_15182(t0,t1,t2);}

C_noret_decl(trf_15101)
static void C_fcall trf_15101(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15101(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_15101(t0,t1,t2);}

C_noret_decl(trf_15107)
static void C_fcall trf_15107(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15107(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_15107(t0,t1,t2,t3);}

C_noret_decl(trf_14985)
static void C_fcall trf_14985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14985(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_14985(t0,t1,t2);}

C_noret_decl(trf_15018)
static void C_fcall trf_15018(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15018(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_15018(t0,t1);}

C_noret_decl(trf_15022)
static void C_fcall trf_15022(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15022(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_15022(t0,t1);}

C_noret_decl(trf_15030)
static void C_fcall trf_15030(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15030(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_15030(t0,t1);}

C_noret_decl(trf_14911)
static void C_fcall trf_14911(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14911(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_14911(t0,t1,t2);}

C_noret_decl(trf_14919)
static void C_fcall trf_14919(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14919(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_14919(t0,t1);}

C_noret_decl(trf_14923)
static void C_fcall trf_14923(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14923(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_14923(t0,t1);}

C_noret_decl(trf_14437)
static void C_fcall trf_14437(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14437(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_14437(t0,t1,t2);}

C_noret_decl(trf_14646)
static void C_fcall trf_14646(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14646(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_14646(t0,t1,t2,t3);}

C_noret_decl(trf_14674)
static void C_fcall trf_14674(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14674(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_14674(t0,t1);}

C_noret_decl(trf_14831)
static void C_fcall trf_14831(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14831(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_14831(t0,t1);}

C_noret_decl(trf_14732)
static void C_fcall trf_14732(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14732(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_14732(t0,t1);}

C_noret_decl(trf_14750)
static void C_fcall trf_14750(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14750(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_14750(t0,t1);}

C_noret_decl(trf_14753)
static void C_fcall trf_14753(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14753(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_14753(t0,t1);}

C_noret_decl(trf_14468)
static void C_fcall trf_14468(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14468(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_14468(t0,t1,t2,t3);}

C_noret_decl(trf_14517)
static void C_fcall trf_14517(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14517(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_14517(t0,t1);}

C_noret_decl(trf_14538)
static void C_fcall trf_14538(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14538(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_14538(t0,t1);}

C_noret_decl(trf_14542)
static void C_fcall trf_14542(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14542(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_14542(t0,t1);}

C_noret_decl(trf_14440)
static void C_fcall trf_14440(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14440(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_14440(t0,t1,t2,t3);}

C_noret_decl(trf_14140)
static void C_fcall trf_14140(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14140(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_14140(t0,t1,t2);}

C_noret_decl(trf_14153)
static void C_fcall trf_14153(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14153(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_14153(t0,t1,t2,t3,t4);}

C_noret_decl(trf_14348)
static void C_fcall trf_14348(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14348(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_14348(t0,t1,t2,t3,t4);}

C_noret_decl(trf_14198)
static void C_fcall trf_14198(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14198(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_14198(t0,t1);}

C_noret_decl(trf_13350)
static void C_fcall trf_13350(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13350(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13350(t0,t1,t2);}

C_noret_decl(trf_13368)
static void C_fcall trf_13368(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13368(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_13368(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_13631)
static void C_fcall trf_13631(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13631(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13631(t0,t1);}

C_noret_decl(trf_13685)
static void C_fcall trf_13685(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13685(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13685(t0,t1);}

C_noret_decl(trf_13960)
static void C_fcall trf_13960(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13960(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13960(t0,t1);}

C_noret_decl(trf_13481)
static void C_fcall trf_13481(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13481(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13481(t0,t1);}

C_noret_decl(trf_13385)
static void C_fcall trf_13385(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13385(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_13385(t0,t1,t2,t3);}

C_noret_decl(trf_13371)
static void C_fcall trf_13371(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13371(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13371(t0,t1,t2);}

C_noret_decl(trf_13243)
static void C_fcall trf_13243(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13243(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_13243(t0,t1,t2,t3,t4);}

C_noret_decl(trf_13257)
static void C_fcall trf_13257(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13257(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_13257(t0,t1,t2,t3,t4);}

C_noret_decl(trf_13034)
static void C_fcall trf_13034(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13034(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13034(t0,t1,t2);}

C_noret_decl(trf_13164)
static void C_fcall trf_13164(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13164(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_13164(t0,t1,t2,t3);}

C_noret_decl(trf_12964)
static void C_fcall trf_12964(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12964(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12964(t0,t1,t2);}

C_noret_decl(trf_12882)
static void C_fcall trf_12882(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12882(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12882(t0,t1);}

C_noret_decl(trf_12762)
static void C_fcall trf_12762(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12762(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12762(t0,t1);}

C_noret_decl(trf_12707)
static void C_fcall trf_12707(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12707(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_12707(t0,t1,t2,t3);}

C_noret_decl(trf_12477)
static void C_fcall trf_12477(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12477(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_12477(t0,t1,t2,t3);}

C_noret_decl(trf_12575)
static void C_fcall trf_12575(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12575(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12575(t0,t1);}

C_noret_decl(trf_11217)
static void C_fcall trf_11217(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11217(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11217(t0,t1);}

C_noret_decl(trf_11248)
static void C_fcall trf_11248(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11248(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11248(t0,t1);}

C_noret_decl(trf_11144)
static void C_fcall trf_11144(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11144(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11144(t0,t1);}

C_noret_decl(trf_11058)
static void C_fcall trf_11058(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11058(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11058(t0,t1);}

C_noret_decl(trf_10912)
static void C_fcall trf_10912(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10912(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10912(t0,t1);}

C_noret_decl(trf_10778)
static void C_fcall trf_10778(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10778(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10778(t0,t1);}

C_noret_decl(trf_10827)
static void C_fcall trf_10827(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10827(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10827(t0,t1);}

C_noret_decl(trf_10311)
static void C_fcall trf_10311(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10311(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_10311(t0,t1,t2,t3,t4);}

C_noret_decl(trf_10565)
static void C_fcall trf_10565(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10565(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10565(t0,t1);}

C_noret_decl(trf_10424)
static void C_fcall trf_10424(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10424(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10424(t0,t1);}

C_noret_decl(trf_10634)
static void C_fcall trf_10634(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10634(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10634(t0,t1);}

C_noret_decl(trf_15238)
static void C_fcall trf_15238(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15238(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_15238(t0,t1,t2,t3,t4);}

C_noret_decl(trf_15521)
static void C_fcall trf_15521(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15521(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_15521(t0,t1);}

C_noret_decl(trf_15299)
static void C_fcall trf_15299(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15299(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_15299(t0,t1,t2,t3);}

C_noret_decl(trf_11292)
static void C_fcall trf_11292(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11292(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_11292(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_11337)
static void C_fcall trf_11337(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11337(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11337(t0,t1);}

C_noret_decl(trf_11366)
static void C_fcall trf_11366(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11366(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11366(t0,t1);}

C_noret_decl(trf_12096)
static void C_fcall trf_12096(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12096(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12096(t0,t1);}

C_noret_decl(trf_12146)
static void C_fcall trf_12146(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12146(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12146(t0,t1);}

C_noret_decl(trf_11895)
static void C_fcall trf_11895(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11895(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11895(t0,t1);}

C_noret_decl(trf_11898)
static void C_fcall trf_11898(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11898(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11898(t0,t1);}

C_noret_decl(trf_11928)
static void C_fcall trf_11928(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11928(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11928(t0,t1);}

C_noret_decl(trf_11762)
static void C_fcall trf_11762(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11762(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11762(t0,t1);}

C_noret_decl(trf_11542)
static void C_fcall trf_11542(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11542(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11542(t0,t1);}

C_noret_decl(trf_11633)
static void C_fcall trf_11633(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11633(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11633(t0,t1);}

C_noret_decl(trf_11600)
static void C_fcall trf_11600(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11600(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11600(t0,t1);}

C_noret_decl(trf_11457)
static void C_fcall trf_11457(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11457(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_11457(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_11375)
static void C_fcall trf_11375(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11375(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_11375(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_11295)
static void C_fcall trf_11295(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11295(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11295(t0,t1,t2);}

C_noret_decl(trf_17528)
static void C_fcall trf_17528(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_17528(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_17528(t0,t1);}

C_noret_decl(trf_15581)
static void C_fcall trf_15581(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15581(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_15581(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_17475)
static void C_fcall trf_17475(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_17475(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_17475(t0,t1);}

C_noret_decl(trf_17346)
static void C_fcall trf_17346(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_17346(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_17346(t0,t1);}

C_noret_decl(trf_17300)
static void C_fcall trf_17300(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_17300(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_17300(t0,t1);}

C_noret_decl(trf_17288)
static void C_fcall trf_17288(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_17288(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_17288(t0,t1);}

C_noret_decl(trf_17257)
static void C_fcall trf_17257(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_17257(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_17257(t0,t1);}

C_noret_decl(trf_17184)
static void C_fcall trf_17184(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_17184(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_17184(t0,t1);}

C_noret_decl(trf_17172)
static void C_fcall trf_17172(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_17172(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_17172(t0,t1);}

C_noret_decl(trf_17141)
static void C_fcall trf_17141(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_17141(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_17141(t0,t1);}

C_noret_decl(trf_17076)
static void C_fcall trf_17076(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_17076(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_17076(t0,t1);}

C_noret_decl(trf_15627)
static void C_fcall trf_15627(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15627(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_15627(t0,t1);}

C_noret_decl(trf_16669)
static void C_fcall trf_16669(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16669(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_16669(t0,t1);}

C_noret_decl(trf_16155)
static void C_fcall trf_16155(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16155(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_16155(t0,t1);}

C_noret_decl(trf_16158)
static void C_fcall trf_16158(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16158(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_16158(t0,t1);}

C_noret_decl(trf_15584)
static void C_fcall trf_15584(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15584(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_15584(t0,t1,t2);}

C_noret_decl(trf_10137)
static void C_fcall trf_10137(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10137(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10137(t0,t1);}

C_noret_decl(trf_10143)
static void C_fcall trf_10143(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10143(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_10143(t0,t1,t2,t3,t4);}

C_noret_decl(trf_10234)
static void C_fcall trf_10234(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10234(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10234(t0,t1);}

C_noret_decl(trf_9325)
static void C_fcall trf_9325(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9325(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9325(t0,t1,t2,t3);}

C_noret_decl(trf_10075)
static void C_fcall trf_10075(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10075(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10075(t0,t1);}

C_noret_decl(trf_10165)
static void C_fcall trf_10165(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10165(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10165(t0,t1);}

C_noret_decl(trf_9653)
static void C_fcall trf_9653(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9653(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9653(t0,t1);}

C_noret_decl(trf_9525)
static void C_fcall trf_9525(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9525(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9525(t0,t1);}

C_noret_decl(trf_9439)
static void C_fcall trf_9439(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9439(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_9439(t0,t1,t2,t3,t4);}

C_noret_decl(trf_9163)
static void C_fcall trf_9163(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9163(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9163(t0,t1);}

C_noret_decl(trf_9103)
static void C_fcall trf_9103(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9103(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9103(t0,t1);}

C_noret_decl(trf_8878)
static void C_fcall trf_8878(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8878(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8878(t0,t1,t2,t3);}

C_noret_decl(trf_8066)
static void C_fcall trf_8066(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8066(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8066(t0,t1,t2,t3);}

C_noret_decl(trf_4216)
static void C_fcall trf_4216(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4216(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4216(t0,t1,t2);}

C_noret_decl(trf_5127)
static void C_fcall trf_5127(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5127(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5127(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_4274)
static void C_fcall trf_4274(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4274(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4274(t0,t1,t2);}

C_noret_decl(trf_7617)
static void C_fcall trf_7617(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7617(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7617(t0,t1,t2);}

C_noret_decl(trf_7524)
static void C_fcall trf_7524(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7524(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7524(t0,t1);}

C_noret_decl(trf_6904)
static void C_fcall trf_6904(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6904(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6904(t0,t1);}

C_noret_decl(trf_6723)
static void C_fcall trf_6723(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6723(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6723(t0,t1);}

C_noret_decl(trf_4315)
static void C_fcall trf_4315(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4315(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4315(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4318)
static void C_fcall trf_4318(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4318(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4318(t0,t1);}

C_noret_decl(trf_8179)
static void C_fcall trf_8179(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8179(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8179(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8666)
static void C_fcall trf_8666(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8666(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8666(t0,t1);}

C_noret_decl(trf_8542)
static void C_fcall trf_8542(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8542(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8542(t0,t1);}

C_noret_decl(trf_8481)
static void C_fcall trf_8481(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8481(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8481(t0,t1);}

C_noret_decl(trf_8329)
static void C_fcall trf_8329(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8329(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8329(t0,t1);}

C_noret_decl(trf_8409)
static void C_fcall trf_8409(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8409(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8409(t0,t1);}

C_noret_decl(trf_4820)
static void C_fcall trf_4820(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4820(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4820(t0,t1,t2,t3);}

C_noret_decl(trf_4841)
static void C_fcall trf_4841(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4841(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4841(t0,t1);}

C_noret_decl(trf_8244)
static void C_fcall trf_8244(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8244(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8244(t0,t1);}

C_noret_decl(trf_17628)
static void C_fcall trf_17628(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_17628(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_17628(t0,t1,t2,t3);}

C_noret_decl(trf_8248)
static void C_fcall trf_8248(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8248(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8248(t0,t1);}

C_noret_decl(trf_6399)
static void C_fcall trf_6399(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6399(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6399(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6411)
static void C_fcall trf_6411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6411(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6411(t0,t1,t2);}

C_noret_decl(trf_6402)
static void C_fcall trf_6402(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6402(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6402(t0,t1,t2);}

C_noret_decl(trf_5677)
static void C_fcall trf_5677(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5677(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5677(t0,t1);}

C_noret_decl(trf_5572)
static void C_fcall trf_5572(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5572(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5572(t0,t1);}

C_noret_decl(trf_5272)
static void C_fcall trf_5272(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5272(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5272(t0,t1);}

C_noret_decl(trf_5279)
static void C_fcall trf_5279(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5279(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5279(t0,t1);}

C_noret_decl(trf_5532)
static void C_fcall trf_5532(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5532(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5532(t0,t1);}

C_noret_decl(trf_5282)
static void C_fcall trf_5282(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5282(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5282(t0,t1);}

C_noret_decl(trf_5290)
static void C_fcall trf_5290(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5290(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5290(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5392)
static void C_fcall trf_5392(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5392(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5392(t0,t1);}

C_noret_decl(trf_5359)
static void C_fcall trf_5359(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5359(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5359(t0,t1);}

C_noret_decl(trf_5200)
static void C_fcall trf_5200(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5200(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5200(t0,t1);}

C_noret_decl(trf_9068)
static void C_fcall trf_9068(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9068(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9068(t0,t1,t2);}

C_noret_decl(trf_5180)
static void C_fcall trf_5180(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5180(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5180(t0,t1);}

C_noret_decl(trf_5160)
static void C_fcall trf_5160(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5160(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5160(t0,t1,t2);}

C_noret_decl(trf_5015)
static void C_fcall trf_5015(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5015(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5015(t0,t1);}

C_noret_decl(trf_5021)
static void C_fcall trf_5021(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5021(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5021(t0,t1,t2,t3);}

C_noret_decl(trf_5052)
static void C_fcall trf_5052(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5052(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5052(t0,t1);}

C_noret_decl(trf_5046)
static void C_fcall trf_5046(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5046(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5046(t0,t1);}

C_noret_decl(trf_4977)
static void C_fcall trf_4977(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4977(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4977(t0,t1,t2);}

C_noret_decl(trf_4930)
static void C_fcall trf_4930(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4930(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4930(t0,t1,t2);}

C_noret_decl(trf_4883)
static void C_fcall trf_4883(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4883(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4883(t0,t1,t2);}

C_noret_decl(trf_4867)
static void C_fcall trf_4867(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4867(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4867(t0,t1,t2);}

C_noret_decl(trf_4857)
static void C_fcall trf_4857(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4857(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4857(t0,t1,t2);}

C_noret_decl(trf_4771)
static void C_fcall trf_4771(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4771(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4771(t0,t1,t2);}

C_noret_decl(trf_4777)
static void C_fcall trf_4777(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4777(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4777(t0,t1,t2,t3);}

C_noret_decl(trf_4798)
static void C_fcall trf_4798(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4798(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4798(t0,t1);}

C_noret_decl(trf_4741)
static void C_fcall trf_4741(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4741(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4741(t0,t1,t2,t3);}

C_noret_decl(trf_4747)
static void C_fcall trf_4747(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4747(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4747(t0,t1,t2,t3);}

C_noret_decl(trf_4692)
static void C_fcall trf_4692(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4692(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4692(t0,t1,t2);}

C_noret_decl(trf_4712)
static void C_fcall trf_4712(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4712(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4712(t0,t1,t2,t3);}

C_noret_decl(trf_4643)
static void C_fcall trf_4643(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4643(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4643(t0,t1,t2);}

C_noret_decl(trf_4663)
static void C_fcall trf_4663(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4663(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4663(t0,t1,t2,t3);}

C_noret_decl(trf_4601)
static void C_fcall trf_4601(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4601(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4601(t0,t1);}

C_noret_decl(trf_4569)
static void C_fcall trf_4569(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4569(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4569(t0,t1,t2);}

C_noret_decl(trf_4575)
static void C_fcall trf_4575(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4575(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4575(t0,t1,t2);}

C_noret_decl(trf_4557)
static void C_fcall trf_4557(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4557(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4557(t0,t1,t2);}

C_noret_decl(trf_4514)
static void C_fcall trf_4514(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4514(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4514(t0,t1,t2);}

C_noret_decl(trf_4520)
static void C_fcall trf_4520(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4520(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4520(t0,t1,t2,t3);}

C_noret_decl(trf_4527)
static void C_fcall trf_4527(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4527(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4527(t0,t1);}

C_noret_decl(trf_4475)
static void C_fcall trf_4475(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4475(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4475(t0,t1);}

C_noret_decl(trf_4491)
static void C_fcall trf_4491(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4491(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4491(t0,t1,t2,t3);}

C_noret_decl(trf_4418)
static void C_fcall trf_4418(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4418(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4418(t0,t1);}

C_noret_decl(trf_4447)
static void C_fcall trf_4447(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4447(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4447(t0,t1,t2,t3);}

C_noret_decl(trf_4391)
static void C_fcall trf_4391(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4391(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4391(t0,t1,t2,t3);}

C_noret_decl(trf_4158)
static void C_fcall trf_4158(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4158(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4158(t0,t1,t2,t3);}

C_noret_decl(trf_4171)
static void C_fcall trf_4171(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4171(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4171(t0,t1,t2);}

C_noret_decl(trf_3999)
static void C_fcall trf_3999(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3999(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3999(t0,t1,t2);}

C_noret_decl(trf_3830)
static void C_fcall trf_3830(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3830(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3830(t0,t1,t2);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr5rv)
static void C_fcall tr5rv(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5rv(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n+1);
t5=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_regex_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_regex_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("regex_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2560)){
C_save(t1);
C_rereclaim2(2560*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,320);
lf[0]=C_h_intern(&lf[0],8,"irregex\077");
lf[1]=C_h_intern(&lf[1],13,"*irregex-tag*");
lf[2]=C_h_intern(&lf[2],11,"irregex-dfa");
lf[3]=C_h_intern(&lf[3],18,"irregex-dfa/search");
lf[4]=C_h_intern(&lf[4],19,"irregex-dfa/extract");
lf[5]=C_h_intern(&lf[5],11,"irregex-nfa");
lf[6]=C_h_intern(&lf[6],13,"irregex-flags");
lf[7]=C_h_intern(&lf[7],18,"irregex-submatches");
lf[8]=C_h_intern(&lf[8],15,"irregex-lengths");
lf[9]=C_h_intern(&lf[9],13,"irregex-names");
lf[10]=C_h_intern(&lf[10],19,"irregex-new-matches");
lf[11]=C_h_intern(&lf[11],19,"*irregex-match-tag*");
lf[12]=C_h_intern(&lf[12],11,"make-vector");
lf[13]=C_h_intern(&lf[13],22,"irregex-reset-matches!");
lf[14]=C_h_intern(&lf[14],19,"irregex-match-data\077");
lf[15]=C_h_intern(&lf[15],28,"irregex-match-num-submatches");
lf[16]=C_h_intern(&lf[16],20,"irregex-match-string");
lf[18]=C_h_intern(&lf[18],5,"error");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\022unknown match name");
lf[21]=C_h_intern(&lf[21],23,"irregex-match-substring");
lf[22]=C_h_intern(&lf[22],13,"\003syssubstring");
lf[23]=C_h_intern(&lf[23],19,"irregex-match-start");
lf[24]=C_h_intern(&lf[24],17,"irregex-match-end");
lf[25]=C_h_intern(&lf[25],1,"/");
lf[29]=C_h_intern(&lf[29],11,"make-string");
lf[33]=C_h_intern(&lf[33],7,"reverse");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\035can\047t take last of empty list");
lf[42]=C_h_intern(&lf[42],4,"expt");
lf[50]=C_h_intern(&lf[50],1,"i");
lf[51]=C_h_intern(&lf[51],1,"m");
lf[52]=C_h_intern(&lf[52],10,"multi-line");
lf[53]=C_h_intern(&lf[53],1,"s");
lf[54]=C_h_intern(&lf[54],11,"single-line");
lf[55]=C_h_intern(&lf[55],1,"x");
lf[56]=C_h_intern(&lf[56],12,"ignore-space");
lf[57]=C_h_intern(&lf[57],1,"u");
lf[58]=C_h_intern(&lf[58],4,"utf8");
lf[59]=C_h_intern(&lf[59],2,"ci");
lf[60]=C_h_intern(&lf[60],16,"case-insensitive");
lf[61]=C_h_intern(&lf[61],11,"string->sre");
lf[62]=C_h_intern(&lf[62],2,"or");
lf[64]=C_h_intern(&lf[64],7,"\003sysmap");
lf[65]=C_h_intern(&lf[65],16,"\003sysstring->list");
lf[68]=C_h_intern(&lf[68],8,"submatch");
lf[69]=C_h_intern(&lf[69],2,"if");
lf[70]=C_h_intern(&lf[70],10,"look-ahead");
lf[71]=C_h_intern(&lf[71],14,"neg-look-ahead");
lf[72]=C_h_intern(&lf[72],11,"look-behind");
lf[73]=C_h_intern(&lf[73],15,"neg-look-behind");
lf[74]=C_h_intern(&lf[74],3,"seq");
lf[75]=C_h_intern(&lf[75],7,"epsilon");
lf[76]=C_h_intern(&lf[76],10,"\003sysappend");
lf[77]=C_h_intern(&lf[77],14,"submatch-named");
lf[78]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006atomic\376\003\000\000\002\376\001\000\000\002if\376\003\000\000\002\376\001\000\000\012look-ahead\376\003\000\000\002\376\001\000\000\016neg-look-ahead\376\003\000\000\002\376\001\000"
"\000\013look-behind\376\003\000\000\002\376\001\000\000\017neg-look-behind\376\003\000\000\002\376\001\000\000\016submatch-named\376\003\000\000\002\376\001\000\000\006w/utf8\376\003"
"\000\000\002\376\001\000\000\010w/noutf8\376\377\016");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\042unterminated parenthesis in regexp");
lf[80]=C_h_intern(&lf[80],3,"any");
lf[81]=C_h_intern(&lf[81],4,"nonl");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\030\077 can\047t follow empty sre");
lf[83]=C_h_intern(&lf[83],1,"*");
lf[84]=C_h_intern(&lf[84],2,"*\077");
lf[85]=C_h_intern(&lf[85],1,"+");
lf[86]=C_h_intern(&lf[86],3,"**\077");
lf[87]=C_h_intern(&lf[87],1,"\077");
lf[88]=C_h_intern(&lf[88],2,"\077\077");
lf[89]=C_h_intern(&lf[89],2,"**");
lf[90]=C_h_intern(&lf[90],1,"=");
lf[91]=C_h_intern(&lf[91],2,">=");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000%duplicate repetition (e.g. **) in sre");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000!can\047t repeat empty sre (e.g. ()*)");
lf[96]=C_h_intern(&lf[96],14,"string->symbol");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\042unterminated parenthesis in regexp");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\042unterminated parenthesis in regexp");
lf[99]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012look-ahead\376\377\016");
lf[100]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016neg-look-ahead\376\377\016");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\042unterminated parenthesis in regexp");
lf[102]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\013look-behind\376\377\016");
lf[103]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\017neg-look-behind\376\377\016");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\024invalid (\077< sequence");
lf[105]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006atomic\376\377\016");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\042unterminated parenthesis in regexp");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\035invalid conditional reference");
lf[108]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002if\376\377\016");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\036unsupported Perl-style cluster");
lf[110]=C_h_intern(&lf[110],6,"w/utf8");
lf[111]=C_h_intern(&lf[111],8,"w/noutf8");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\022incomplete cluster");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\036unknown regex cluster modifier");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\026too many )\047s in regexp");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\023incomplete char set");
lf[116]=C_h_intern(&lf[116],1,"~");
lf[117]=C_h_intern(&lf[117],6,"append");
lf[119]=C_h_intern(&lf[119],16,"\003syslist->string");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\014bad char-set");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\032inverted range in char-set");
lf[125]=C_decode_literal(C_heaptop,"\376\000\000\001\000\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000"
"\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376"
"\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000"
"\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001"
"\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001"
"\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000"
"\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377"
"\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000"
"\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376"
"\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000"
"\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001"
"\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001"
"\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000"
"\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377"
"\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000"
"\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376"
"\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\002\376\377\001\000"
"\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002"
"\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001"
"\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000"
"\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377"
"\001\000\000\000\003\376\377\001\000\000\000\004\376\377\001\000\000\000\004\376\377\001\000\000\000\004\376\377\001\000\000\000\004\376\377\001\000\000\000\004\376\377\001\000\000\000\004\376\377\001\000\000\000\004\376\377\001\000\000\000\004\376\377\001\000\000\000\005\376\377\001\000\000\000\005\376\377\001\000\000"
"\000\005\376\377\001\000\000\000\005\376\377\001\000\000\000\006\376\377\001\000\000\000\006\376\377\001\000\000\000\000\376\377\001\000\000\000\000");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\032incomplete character class");
lf[127]=C_h_intern(&lf[127],5,"pair\077");
lf[128]=C_h_intern(&lf[128],5,"char\077");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000!collating sequences not supported");
lf[132]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\012\376\377\016");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\032incomplete escape sequence");
lf[134]=C_h_intern(&lf[134],7,"numeric");
lf[135]=C_h_intern(&lf[135],5,"space");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\001_");
lf[137]=C_h_intern(&lf[137],12,"alphanumeric");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\001_");
lf[139]=C_h_intern(&lf[139],3,"eow");
lf[140]=C_h_intern(&lf[140],3,"bow");
lf[141]=C_h_intern(&lf[141],3,"nwb");
lf[142]=C_h_intern(&lf[142],3,"bos");
lf[143]=C_h_intern(&lf[143],3,"eos");
lf[144]=C_h_intern(&lf[144],7,"newline");
lf[145]=C_h_intern(&lf[145],5,"reset");
lf[146]=C_h_intern(&lf[146],10,"backref-ci");
lf[147]=C_h_intern(&lf[147],7,"backref");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\032interminated named backref");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\036bad \134k usage, expected \134k<...>");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\027unknown escape sequence");
lf[151]=C_h_intern(&lf[151],3,"bol");
lf[152]=C_h_intern(&lf[152],3,"eol");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\025incomplete hex escape");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\024bad hex brace escape");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\033incomplete hex brace escape");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\025incomplete hex escape");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\016bad hex escape");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid utf8 length");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid utf8 length");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\037unicode codepoint out of range:");
lf[164]=C_h_intern(&lf[164],13,"integer->char");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid utf8 length");
lf[169]=C_h_intern(&lf[169],7,"irregex");
lf[170]=C_h_intern(&lf[170],15,"string->irregex");
lf[171]=C_h_intern(&lf[171],12,"sre->irregex");
lf[174]=C_h_intern(&lf[174],6,"w/case");
lf[175]=C_h_intern(&lf[175],8,"w/nocase");
lf[176]=C_h_intern(&lf[176],1,":");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\024invalid sre: empty *");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid sre: empty *\077");
lf[180]=C_h_intern(&lf[180],4,"word");
lf[181]=C_h_intern(&lf[181],5,"word+");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\001_");
lf[183]=C_h_intern(&lf[183],1,"&");
lf[184]=C_h_intern(&lf[184],12,"posix-string");
lf[185]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\003any\376\377\016");
lf[186]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\003any\376\377\016");
lf[187]=C_h_intern(&lf[187],6,"atomic");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\037unknown named backref in SRE IF");
lf[189]=C_h_intern(&lf[189],11,"string-ci=\077");
lf[190]=C_h_intern(&lf[190],8,"string=\077");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\025unknown backreference");
lf[192]=C_h_intern(&lf[192],3,"dsm");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\027unknown regexp operator");
lf[194]=C_h_intern(&lf[194],1,"-");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\016unknown regexp");
lf[197]=C_h_intern(&lf[197],9,"char-ci=\077");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\016unknown regexp");
lf[201]=C_h_intern(&lf[201],3,"max");
lf[202]=C_h_intern(&lf[202],3,"min");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000!sre-length: invalid backreference");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000)sre-length: invalid forward backreference");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\025unknown backreference");
lf[206]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002>=\376\003\000\000\002\376\001\000\000\003>=\077\376\377\016");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\047sre-length-ranges: unknown sre operator");
lf[208]=C_h_intern(&lf[208],2,"=\077");
lf[209]=C_h_intern(&lf[209],3,">=\077");
lf[210]=C_h_intern(&lf[210],6,"commit");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\036sre-length-ranges: unknown sre");
lf[212]=C_h_intern(&lf[212],4,"cons");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\027unknown regexp operator");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\016unknown regexp");
lf[219]=C_h_intern(&lf[219],5,"small");
lf[220]=C_h_intern(&lf[220],4,"fast");
lf[223]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\003any\376\377\016");
lf[224]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\004nonl\376\377\016");
lf[225]=C_h_intern(&lf[225],8,"utf8-any");
lf[226]=C_h_intern(&lf[226],9,"utf8-nonl");
lf[227]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007epsilon\376\003\000\000\002\376\001\000\000\003bos\376\003\000\000\002\376\001\000\000\003eos\376\003\000\000\002\376\001\000\000\003bol\376\003\000\000\002\376\001\000\000\003eol\376\003\000\000\002\376\001\000\000\003b"
"ow\376\003\000\000\002\376\001\000\000\003eow\376\003\000\000\002\376\001\000\000\006commit\376\377\016");
lf[229]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\001+\376\377\016");
lf[231]=C_h_intern(&lf[231],14,"irregex-search");
lf[232]=C_h_intern(&lf[232],22,"irregex-search/matches");
lf[233]=C_h_intern(&lf[233],13,"irregex-match");
lf[234]=C_h_intern(&lf[234],10,"alphabetic");
lf[235]=C_h_intern(&lf[235],5,"alpha");
lf[236]=C_h_intern(&lf[236],8,"alphanum");
lf[237]=C_h_intern(&lf[237],5,"alnum");
lf[238]=C_h_intern(&lf[238],10,"lower-case");
lf[239]=C_h_intern(&lf[239],5,"lower");
lf[240]=C_h_intern(&lf[240],10,"upper-case");
lf[241]=C_h_intern(&lf[241],5,"upper");
lf[242]=C_h_intern(&lf[242],3,"num");
lf[243]=C_h_intern(&lf[243],5,"digit");
lf[244]=C_h_intern(&lf[244],11,"punctuation");
lf[245]=C_h_intern(&lf[245],5,"punct");
lf[246]=C_h_intern(&lf[246],7,"graphic");
lf[247]=C_h_intern(&lf[247],5,"graph");
lf[248]=C_h_intern(&lf[248],5,"blank");
lf[249]=C_h_intern(&lf[249],10,"whitespace");
lf[250]=C_h_intern(&lf[250],5,"white");
lf[251]=C_h_intern(&lf[251],8,"printing");
lf[252]=C_h_intern(&lf[252],5,"print");
lf[253]=C_h_intern(&lf[253],7,"control");
lf[254]=C_h_intern(&lf[254],5,"cntrl");
lf[255]=C_h_intern(&lf[255],9,"hex-digit");
lf[256]=C_h_intern(&lf[256],6,"xdigit");
lf[257]=C_h_intern(&lf[257],5,"ascii");
lf[258]=C_h_intern(&lf[258],10,"ascii-nonl");
lf[259]=C_h_intern(&lf[259],14,"utf8-tail-char");
lf[260]=C_h_intern(&lf[260],11,"utf8-2-char");
lf[261]=C_h_intern(&lf[261],11,"utf8-3-char");
lf[262]=C_h_intern(&lf[262],11,"utf8-4-char");
lf[263]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006w/case\376\003\000\000\002\376\001\000\000\010w/nocase\376\377\016");
lf[264]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006w/case\376\003\000\000\002\376\001\000\000\006w/utf8\376\377\016");
lf[265]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007epsilon\376\377\016");
lf[266]=C_h_intern(&lf[266],12,"list->vector");
lf[267]=C_h_intern(&lf[267],3,"map");
lf[268]=C_h_intern(&lf[268],3,"car");
lf[269]=C_h_intern(&lf[269],3,"cdr");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000!not a valid sre char-set operator");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\030not a valid sre char-set");
lf[282]=C_h_intern(&lf[282],12,"irregex-fold");
lf[283]=C_h_intern(&lf[283],15,"irregex-replace");
lf[284]=C_h_intern(&lf[284],19,"irregex-apply-match");
lf[285]=C_h_intern(&lf[285],19,"irregex-replace/all");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[287]=C_h_intern(&lf[287],3,"pre");
lf[288]=C_h_intern(&lf[288],4,"post");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\031unknown match replacement");
lf[290]=C_h_intern(&lf[290],7,"regexp\077");
lf[291]=C_h_intern(&lf[291],6,"regexp");
lf[293]=C_h_intern(&lf[293],12,"string-match");
lf[294]=C_h_intern(&lf[294],22,"string-match-positions");
lf[295]=C_h_intern(&lf[295],13,"string-search");
lf[296]=C_h_intern(&lf[296],23,"string-search-positions");
lf[297]=C_h_intern(&lf[297],9,"substring");
lf[298]=C_h_intern(&lf[298],19,"string-split-fields");
lf[299]=C_h_intern(&lf[299],6,"\000infix");
lf[300]=C_h_intern(&lf[300],7,"\000suffix");
lf[301]=C_h_intern(&lf[301],9,"\003syserror");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\037record does not end with suffix");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[304]=C_h_intern(&lf[304],17,"string-substitute");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\030empty substitution match");
lf[306]=C_h_intern(&lf[306],21,"\003sysfragments->string");
lf[307]=C_h_intern(&lf[307],18,"string-substitute*");
lf[308]=C_h_intern(&lf[308],5,"glob\077");
lf[309]=C_h_intern(&lf[309],12,"list->string");
lf[310]=C_h_intern(&lf[310],12,"string->list");
lf[311]=C_h_intern(&lf[311],12,"glob->regexp");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000!unexpected end of character class");
lf[313]=C_h_intern(&lf[313],4,"grep");
lf[314]=C_h_intern(&lf[314],18,"open-output-string");
lf[315]=C_h_intern(&lf[315],17,"get-output-string");
lf[316]=C_h_intern(&lf[316],13,"regexp-escape");
lf[317]=C_h_intern(&lf[317],16,"\003syswrite-char-0");
lf[318]=C_h_intern(&lf[318],17,"register-feature!");
lf[319]=C_h_intern(&lf[319],5,"regex");
C_register_lf2(lf,320,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3723,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 64   register-feature! */
t3=*((C_word*)lf[318]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[319],lf[169]);}

/* k3721 */
static void C_ccall f_3723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word t149;
C_word t150;
C_word t151;
C_word t152;
C_word t153;
C_word t154;
C_word t155;
C_word t156;
C_word t157;
C_word t158;
C_word t159;
C_word t160;
C_word t161;
C_word t162;
C_word t163;
C_word t164;
C_word t165;
C_word t166;
C_word t167;
C_word t168;
C_word t169;
C_word t170;
C_word t171;
C_word t172;
C_word t173;
C_word t174;
C_word t175;
C_word t176;
C_word t177;
C_word t178;
C_word t179;
C_word t180;
C_word t181;
C_word t182;
C_word t183;
C_word t184;
C_word t185;
C_word t186;
C_word t187;
C_word t188;
C_word t189;
C_word t190;
C_word t191;
C_word t192;
C_word t193;
C_word t194;
C_word t195;
C_word t196;
C_word t197;
C_word t198;
C_word t199;
C_word t200;
C_word t201;
C_word t202;
C_word t203;
C_word t204;
C_word t205;
C_word t206;
C_word t207;
C_word t208;
C_word t209;
C_word t210;
C_word t211;
C_word t212;
C_word t213;
C_word t214;
C_word t215;
C_word t216;
C_word t217;
C_word t218;
C_word t219;
C_word t220;
C_word t221;
C_word t222;
C_word t223;
C_word t224;
C_word t225;
C_word t226;
C_word t227;
C_word t228;
C_word t229;
C_word t230;
C_word t231;
C_word t232;
C_word t233;
C_word t234;
C_word t235;
C_word t236;
C_word t237;
C_word t238;
C_word t239;
C_word t240;
C_word t241;
C_word t242;
C_word t243;
C_word t244;
C_word t245;
C_word t246;
C_word t247;
C_word t248;
C_word t249;
C_word t250;
C_word t251;
C_word t252;
C_word t253;
C_word t254;
C_word t255;
C_word t256;
C_word t257;
C_word t258;
C_word t259;
C_word t260;
C_word t261;
C_word t262;
C_word t263;
C_word t264;
C_word t265;
C_word t266;
C_word t267;
C_word t268;
C_word t269;
C_word t270;
C_word t271;
C_word t272;
C_word t273;
C_word t274;
C_word t275;
C_word t276;
C_word t277;
C_word t278;
C_word t279;
C_word t280;
C_word t281;
C_word t282;
C_word t283;
C_word t284;
C_word t285;
C_word t286;
C_word t287;
C_word t288;
C_word t289;
C_word t290;
C_word t291;
C_word t292;
C_word t293;
C_word t294;
C_word t295;
C_word t296;
C_word t297;
C_word t298;
C_word t299;
C_word t300;
C_word t301;
C_word t302;
C_word t303;
C_word t304;
C_word t305;
C_word t306;
C_word t307;
C_word t308;
C_word t309;
C_word t310;
C_word t311;
C_word t312;
C_word t313;
C_word t314;
C_word t315;
C_word t316;
C_word t317;
C_word t318;
C_word t319;
C_word t320;
C_word t321;
C_word t322;
C_word t323;
C_word t324;
C_word t325;
C_word t326;
C_word t327;
C_word t328;
C_word t329;
C_word t330;
C_word t331;
C_word t332;
C_word t333;
C_word t334;
C_word t335;
C_word t336;
C_word t337;
C_word t338;
C_word t339;
C_word t340;
C_word t341;
C_word t342;
C_word t343;
C_word t344;
C_word t345;
C_word t346;
C_word t347;
C_word t348;
C_word t349;
C_word t350;
C_word t351;
C_word t352;
C_word t353;
C_word t354;
C_word t355;
C_word ab[916],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3723,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! irregex? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3732,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[2]+1 /* (set! irregex-dfa ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3758,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[3]+1 /* (set! irregex-dfa/search ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3764,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[4]+1 /* (set! irregex-dfa/extract ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3770,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[5]+1 /* (set! irregex-nfa ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3776,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[6]+1 /* (set! irregex-flags ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3782,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[7]+1 /* (set! irregex-submatches ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3788,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[8]+1 /* (set! irregex-lengths ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3794,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[9]+1 /* (set! irregex-names ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3800,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[10]+1 /* (set! irregex-new-matches ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3806,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[13]+1 /* (set! irregex-reset-matches! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3820,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[14]+1 /* (set! irregex-match-data? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3854,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[15]+1 /* (set! irregex-match-num-submatches ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3907,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[16]+1 /* (set! irregex-match-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3925,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate(&lf[17] /* (set! irregex-match-index ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3999,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate(&lf[20] /* (set! irregex-match-valid-index? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4045,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[21]+1 /* (set! irregex-match-substring ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4077,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[23]+1 /* (set! irregex-match-start ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4120,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[24]+1 /* (set! irregex-match-end ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4143,tmp=(C_word)a,a+=2,tmp));
t21=(C_word)C_a_i_cons(&a,2,C_make_character(1114111),C_SCHEME_END_OF_LIST);
t22=(C_word)C_a_i_cons(&a,2,C_make_character(57344),t21);
t23=(C_word)C_a_i_cons(&a,2,C_make_character(55295),t22);
t24=(C_word)C_a_i_cons(&a,2,C_make_character(0),t23);
t25=(C_word)C_a_i_cons(&a,2,lf[25],t24);
t26=C_mutate(&lf[26] /* (set! *all-chars* ...) */,t25);
t27=C_mutate(&lf[27] /* (set! string-scan-char ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4158,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate(&lf[28] /* (set! string-cat-reverse ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4418,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate(&lf[31] /* (set! zero-to ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4475,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate(&lf[32] /* (set! take-up-to ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4514,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate(&lf[34] /* (set! find ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4557,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate(&lf[35] /* (set! find-tail ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4569,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate(&lf[36] /* (set! last ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4601,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate(&lf[38] /* (set! any ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4643,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate(&lf[39] /* (set! every ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4692,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate(&lf[30] /* (set! fold ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4741,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate(&lf[40] /* (set! filter ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4771,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate(&lf[41] /* (set! bit-shr ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4857,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate(&lf[43] /* (set! bit-shl ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4867,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate(&lf[44] /* (set! bit-ior ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4883,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate(&lf[45] /* (set! bit-and ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4930,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate(&lf[46] /* (set! flag-set? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4977,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate(&lf[47] /* (set! flag-join ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4987,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate(&lf[48] /* (set! flag-clear ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4996,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate(&lf[49] /* (set! symbol-list->flags ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5015,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[61]+1 /* (set! string->sre ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5115,tmp=(C_word)a,a+=2,tmp));
t47=(C_word)C_a_i_cons(&a,2,C_make_character(110),C_make_character(10));
t48=(C_word)C_a_i_cons(&a,2,C_make_character(114),C_make_character(13));
t49=(C_word)C_a_i_cons(&a,2,C_make_character(116),C_make_character(9));
t50=(C_word)C_a_i_cons(&a,2,C_make_character(97),C_make_character(7));
t51=(C_word)C_a_i_cons(&a,2,C_make_character(101),C_make_character(27));
t52=(C_word)C_a_i_cons(&a,2,C_make_character(102),C_make_character(12));
t53=(C_word)C_a_i_cons(&a,2,t52,C_SCHEME_END_OF_LIST);
t54=(C_word)C_a_i_cons(&a,2,t51,t53);
t55=(C_word)C_a_i_cons(&a,2,t50,t54);
t56=(C_word)C_a_i_cons(&a,2,t49,t55);
t57=(C_word)C_a_i_cons(&a,2,t48,t56);
t58=(C_word)C_a_i_cons(&a,2,t47,t57);
t59=C_mutate(&lf[123] /* (set! posix-escape-sequences ...) */,t58);
t60=C_mutate(&lf[124] /* (set! string-parse-hex-escape ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8066,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate(&lf[120] /* (set! high-char? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8858,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate(&lf[66] /* (set! utf8-string-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8878,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate(&lf[159] /* (set! utf8-lowest-digit-of-length ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9103,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate(&lf[161] /* (set! char->utf8-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9163,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate(&lf[163] /* (set! unicode-range-helper ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9439,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate(&lf[165] /* (set! unicode-range-up-from ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9525,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate(&lf[166] /* (set! unicode-range-up-to ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9653,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate(&lf[167] /* (set! cset->utf8-pattern ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10137,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate((C_word*)lf[169]+1 /* (set! irregex ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10587,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate((C_word*)lf[170]+1 /* (set! string->irregex ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10608,tmp=(C_word)a,a+=2,tmp));
t71=C_mutate((C_word*)lf[171]+1 /* (set! sre->irregex ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10618,tmp=(C_word)a,a+=2,tmp));
t72=C_mutate(&lf[95] /* (set! sre-empty? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10759,tmp=(C_word)a,a+=2,tmp));
t73=C_mutate(&lf[228] /* (set! sre-any? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10887,tmp=(C_word)a,a+=2,tmp));
t74=C_mutate(&lf[92] /* (set! sre-repeater? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10963,tmp=(C_word)a,a+=2,tmp));
t75=C_mutate(&lf[222] /* (set! sre-searcher? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11019,tmp=(C_word)a,a+=2,tmp));
t76=C_mutate(&lf[200] /* (set! sre-consumer? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11105,tmp=(C_word)a,a+=2,tmp));
t77=C_mutate(&lf[218] /* (set! sre-has-submatchs? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11191,tmp=(C_word)a,a+=2,tmp));
t78=C_mutate(&lf[173] /* (set! sre-count-submatches ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11217,tmp=(C_word)a,a+=2,tmp));
t79=C_mutate(&lf[63] /* (set! sre-sequence ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12312,tmp=(C_word)a,a+=2,tmp));
t80=C_mutate(&lf[67] /* (set! sre-alternate ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12337,tmp=(C_word)a,a+=2,tmp));
t81=C_mutate(&lf[179] /* (set! sre-strip-submatches ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12362,tmp=(C_word)a,a+=2,tmp));
t82=C_mutate(&lf[199] /* (set! sre-names ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12477,tmp=(C_word)a,a+=2,tmp));
t83=C_mutate(&lf[230] /* (set! sre-sequence-names ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12707,tmp=(C_word)a,a+=2,tmp));
t84=C_mutate(&lf[221] /* (set! sre-remove-initial-bos ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12743,tmp=(C_word)a,a+=2,tmp));
t85=C_mutate((C_word*)lf[231]+1 /* (set! irregex-search ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12860,tmp=(C_word)a,a+=2,tmp));
t86=C_mutate((C_word*)lf[232]+1 /* (set! irregex-search/matches ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12906,tmp=(C_word)a,a+=2,tmp));
t87=C_mutate((C_word*)lf[233]+1 /* (set! irregex-match ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13065,tmp=(C_word)a,a+=2,tmp));
t88=C_mutate(&lf[215] /* (set! dfa-match/longest ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13243,tmp=(C_word)a,a+=2,tmp));
t89=(C_word)C_a_i_cons(&a,2,lf[80],lf[26]);
t90=(C_word)C_a_i_string(&a,1,C_make_character(10));
t91=(C_word)C_a_i_cons(&a,2,t90,C_SCHEME_END_OF_LIST);
t92=(C_word)C_a_i_cons(&a,2,t91,C_SCHEME_END_OF_LIST);
t93=(C_word)C_a_i_cons(&a,2,lf[26],t92);
t94=(C_word)C_a_i_cons(&a,2,lf[194],t93);
t95=(C_word)C_a_i_cons(&a,2,lf[81],t94);
t96=(C_word)C_a_i_cons(&a,2,C_make_character(90),C_SCHEME_END_OF_LIST);
t97=(C_word)C_a_i_cons(&a,2,C_make_character(65),t96);
t98=(C_word)C_a_i_cons(&a,2,C_make_character(122),t97);
t99=(C_word)C_a_i_cons(&a,2,C_make_character(97),t98);
t100=(C_word)C_a_i_cons(&a,2,lf[25],t99);
t101=(C_word)C_a_i_cons(&a,2,lf[234],t100);
t102=(C_word)C_a_i_cons(&a,2,lf[235],lf[234]);
t103=(C_word)C_a_i_cons(&a,2,C_make_character(57),C_SCHEME_END_OF_LIST);
t104=(C_word)C_a_i_cons(&a,2,C_make_character(48),t103);
t105=(C_word)C_a_i_cons(&a,2,C_make_character(90),t104);
t106=(C_word)C_a_i_cons(&a,2,C_make_character(65),t105);
t107=(C_word)C_a_i_cons(&a,2,C_make_character(122),t106);
t108=(C_word)C_a_i_cons(&a,2,C_make_character(97),t107);
t109=(C_word)C_a_i_cons(&a,2,lf[25],t108);
t110=(C_word)C_a_i_cons(&a,2,lf[137],t109);
t111=(C_word)C_a_i_cons(&a,2,lf[236],lf[137]);
t112=(C_word)C_a_i_cons(&a,2,lf[237],lf[137]);
t113=(C_word)C_a_i_cons(&a,2,C_make_character(122),C_SCHEME_END_OF_LIST);
t114=(C_word)C_a_i_cons(&a,2,C_make_character(97),t113);
t115=(C_word)C_a_i_cons(&a,2,lf[25],t114);
t116=(C_word)C_a_i_cons(&a,2,lf[238],t115);
t117=(C_word)C_a_i_cons(&a,2,lf[239],lf[238]);
t118=(C_word)C_a_i_cons(&a,2,C_make_character(90),C_SCHEME_END_OF_LIST);
t119=(C_word)C_a_i_cons(&a,2,C_make_character(65),t118);
t120=(C_word)C_a_i_cons(&a,2,lf[25],t119);
t121=(C_word)C_a_i_cons(&a,2,lf[240],t120);
t122=(C_word)C_a_i_cons(&a,2,lf[241],lf[240]);
t123=(C_word)C_a_i_cons(&a,2,C_make_character(57),C_SCHEME_END_OF_LIST);
t124=(C_word)C_a_i_cons(&a,2,C_make_character(48),t123);
t125=(C_word)C_a_i_cons(&a,2,lf[25],t124);
t126=(C_word)C_a_i_cons(&a,2,lf[134],t125);
t127=(C_word)C_a_i_cons(&a,2,lf[242],lf[134]);
t128=(C_word)C_a_i_cons(&a,2,lf[243],lf[134]);
t129=(C_word)C_a_i_cons(&a,2,C_make_character(125),C_SCHEME_END_OF_LIST);
t130=(C_word)C_a_i_cons(&a,2,C_make_character(123),t129);
t131=(C_word)C_a_i_cons(&a,2,C_make_character(95),t130);
t132=(C_word)C_a_i_cons(&a,2,C_make_character(93),t131);
t133=(C_word)C_a_i_cons(&a,2,C_make_character(92),t132);
t134=(C_word)C_a_i_cons(&a,2,C_make_character(91),t133);
t135=(C_word)C_a_i_cons(&a,2,C_make_character(64),t134);
t136=(C_word)C_a_i_cons(&a,2,C_make_character(63),t135);
t137=(C_word)C_a_i_cons(&a,2,C_make_character(59),t136);
t138=(C_word)C_a_i_cons(&a,2,C_make_character(58),t137);
t139=(C_word)C_a_i_cons(&a,2,C_make_character(47),t138);
t140=(C_word)C_a_i_cons(&a,2,C_make_character(46),t139);
t141=(C_word)C_a_i_cons(&a,2,C_make_character(45),t140);
t142=(C_word)C_a_i_cons(&a,2,C_make_character(44),t141);
t143=(C_word)C_a_i_cons(&a,2,C_make_character(42),t142);
t144=(C_word)C_a_i_cons(&a,2,C_make_character(41),t143);
t145=(C_word)C_a_i_cons(&a,2,C_make_character(40),t144);
t146=(C_word)C_a_i_cons(&a,2,C_make_character(39),t145);
t147=(C_word)C_a_i_cons(&a,2,C_make_character(38),t146);
t148=(C_word)C_a_i_cons(&a,2,C_make_character(37),t147);
t149=(C_word)C_a_i_cons(&a,2,C_make_character(35),t148);
t150=(C_word)C_a_i_cons(&a,2,C_make_character(34),t149);
t151=(C_word)C_a_i_cons(&a,2,C_make_character(33),t150);
t152=(C_word)C_a_i_cons(&a,2,lf[62],t151);
t153=(C_word)C_a_i_cons(&a,2,lf[244],t152);
t154=(C_word)C_a_i_cons(&a,2,lf[245],lf[244]);
t155=(C_word)C_a_i_cons(&a,2,C_make_character(126),C_SCHEME_END_OF_LIST);
t156=(C_word)C_a_i_cons(&a,2,C_make_character(124),t155);
t157=(C_word)C_a_i_cons(&a,2,C_make_character(96),t156);
t158=(C_word)C_a_i_cons(&a,2,C_make_character(94),t157);
t159=(C_word)C_a_i_cons(&a,2,C_make_character(62),t158);
t160=(C_word)C_a_i_cons(&a,2,C_make_character(61),t159);
t161=(C_word)C_a_i_cons(&a,2,C_make_character(60),t160);
t162=(C_word)C_a_i_cons(&a,2,C_make_character(43),t161);
t163=(C_word)C_a_i_cons(&a,2,C_make_character(36),t162);
t164=(C_word)C_a_i_cons(&a,2,lf[244],t163);
t165=(C_word)C_a_i_cons(&a,2,lf[137],t164);
t166=(C_word)C_a_i_cons(&a,2,lf[62],t165);
t167=(C_word)C_a_i_cons(&a,2,lf[246],t166);
t168=(C_word)C_a_i_cons(&a,2,lf[247],lf[246]);
t169=(C_word)C_a_i_cons(&a,2,C_make_character(9),C_SCHEME_END_OF_LIST);
t170=(C_word)C_a_i_cons(&a,2,C_make_character(32),t169);
t171=(C_word)C_a_i_cons(&a,2,lf[62],t170);
t172=(C_word)C_a_i_cons(&a,2,lf[248],t171);
t173=(C_word)C_a_i_cons(&a,2,C_make_character(10),C_SCHEME_END_OF_LIST);
t174=(C_word)C_a_i_cons(&a,2,lf[248],t173);
t175=(C_word)C_a_i_cons(&a,2,lf[62],t174);
t176=(C_word)C_a_i_cons(&a,2,lf[249],t175);
t177=(C_word)C_a_i_cons(&a,2,lf[135],lf[249]);
t178=(C_word)C_a_i_cons(&a,2,lf[250],lf[249]);
t179=(C_word)C_a_i_cons(&a,2,lf[249],C_SCHEME_END_OF_LIST);
t180=(C_word)C_a_i_cons(&a,2,lf[246],t179);
t181=(C_word)C_a_i_cons(&a,2,lf[62],t180);
t182=(C_word)C_a_i_cons(&a,2,lf[251],t181);
t183=(C_word)C_a_i_cons(&a,2,lf[252],lf[251]);
t184=(C_word)C_a_i_cons(&a,2,C_make_character(31),C_SCHEME_END_OF_LIST);
t185=(C_word)C_a_i_cons(&a,2,C_make_character(0),t184);
t186=(C_word)C_a_i_cons(&a,2,lf[25],t185);
t187=(C_word)C_a_i_cons(&a,2,lf[253],t186);
t188=(C_word)C_a_i_cons(&a,2,lf[254],lf[253]);
t189=(C_word)C_a_i_cons(&a,2,C_make_character(70),C_SCHEME_END_OF_LIST);
t190=(C_word)C_a_i_cons(&a,2,C_make_character(65),t189);
t191=(C_word)C_a_i_cons(&a,2,C_make_character(102),t190);
t192=(C_word)C_a_i_cons(&a,2,C_make_character(97),t191);
t193=(C_word)C_a_i_cons(&a,2,lf[25],t192);
t194=(C_word)C_a_i_cons(&a,2,t193,C_SCHEME_END_OF_LIST);
t195=(C_word)C_a_i_cons(&a,2,lf[134],t194);
t196=(C_word)C_a_i_cons(&a,2,lf[62],t195);
t197=(C_word)C_a_i_cons(&a,2,lf[255],t196);
t198=(C_word)C_a_i_cons(&a,2,lf[256],lf[255]);
t199=(C_word)C_a_i_cons(&a,2,C_make_character(127),C_SCHEME_END_OF_LIST);
t200=(C_word)C_a_i_cons(&a,2,C_make_character(0),t199);
t201=(C_word)C_a_i_cons(&a,2,lf[25],t200);
t202=(C_word)C_a_i_cons(&a,2,lf[257],t201);
t203=(C_word)C_a_i_cons(&a,2,C_make_character(127),C_SCHEME_END_OF_LIST);
t204=(C_word)C_a_i_cons(&a,2,C_make_character(11),t203);
t205=(C_word)C_a_i_cons(&a,2,C_make_character(9),t204);
t206=(C_word)C_a_i_cons(&a,2,C_make_character(0),t205);
t207=(C_word)C_a_i_cons(&a,2,lf[25],t206);
t208=(C_word)C_a_i_cons(&a,2,lf[258],t207);
t209=(C_word)C_a_i_cons(&a,2,C_make_character(10),C_SCHEME_END_OF_LIST);
t210=(C_word)C_a_i_cons(&a,2,C_make_character(13),t209);
t211=(C_word)C_a_i_cons(&a,2,lf[74],t210);
t212=(C_word)C_a_i_cons(&a,2,C_make_character(13),C_SCHEME_END_OF_LIST);
t213=(C_word)C_a_i_cons(&a,2,C_make_character(10),t212);
t214=(C_word)C_a_i_cons(&a,2,lf[25],t213);
t215=(C_word)C_a_i_cons(&a,2,t214,C_SCHEME_END_OF_LIST);
t216=(C_word)C_a_i_cons(&a,2,t211,t215);
t217=(C_word)C_a_i_cons(&a,2,lf[62],t216);
t218=(C_word)C_a_i_cons(&a,2,lf[144],t217);
t219=(C_word)C_a_i_cons(&a,2,C_make_character(95),C_SCHEME_END_OF_LIST);
t220=(C_word)C_a_i_cons(&a,2,lf[137],t219);
t221=(C_word)C_a_i_cons(&a,2,lf[62],t220);
t222=(C_word)C_a_i_cons(&a,2,t221,C_SCHEME_END_OF_LIST);
t223=(C_word)C_a_i_cons(&a,2,lf[85],t222);
t224=(C_word)C_a_i_cons(&a,2,lf[139],C_SCHEME_END_OF_LIST);
t225=(C_word)C_a_i_cons(&a,2,t223,t224);
t226=(C_word)C_a_i_cons(&a,2,lf[140],t225);
t227=(C_word)C_a_i_cons(&a,2,lf[74],t226);
t228=(C_word)C_a_i_cons(&a,2,lf[180],t227);
t229=(C_word)C_a_i_cons(&a,2,C_make_character(193),C_SCHEME_END_OF_LIST);
t230=(C_word)C_a_i_cons(&a,2,C_make_character(128),t229);
t231=(C_word)C_a_i_cons(&a,2,lf[25],t230);
t232=(C_word)C_a_i_cons(&a,2,lf[259],t231);
t233=(C_word)C_a_i_cons(&a,2,C_make_character(223),C_SCHEME_END_OF_LIST);
t234=(C_word)C_a_i_cons(&a,2,C_make_character(194),t233);
t235=(C_word)C_a_i_cons(&a,2,lf[25],t234);
t236=(C_word)C_a_i_cons(&a,2,lf[259],C_SCHEME_END_OF_LIST);
t237=(C_word)C_a_i_cons(&a,2,t235,t236);
t238=(C_word)C_a_i_cons(&a,2,lf[74],t237);
t239=(C_word)C_a_i_cons(&a,2,lf[260],t238);
t240=(C_word)C_a_i_cons(&a,2,C_make_character(239),C_SCHEME_END_OF_LIST);
t241=(C_word)C_a_i_cons(&a,2,C_make_character(224),t240);
t242=(C_word)C_a_i_cons(&a,2,lf[25],t241);
t243=(C_word)C_a_i_cons(&a,2,lf[259],C_SCHEME_END_OF_LIST);
t244=(C_word)C_a_i_cons(&a,2,lf[259],t243);
t245=(C_word)C_a_i_cons(&a,2,t242,t244);
t246=(C_word)C_a_i_cons(&a,2,lf[74],t245);
t247=(C_word)C_a_i_cons(&a,2,lf[261],t246);
t248=(C_word)C_a_i_cons(&a,2,C_make_character(247),C_SCHEME_END_OF_LIST);
t249=(C_word)C_a_i_cons(&a,2,C_make_character(240),t248);
t250=(C_word)C_a_i_cons(&a,2,lf[25],t249);
t251=(C_word)C_a_i_cons(&a,2,lf[259],C_SCHEME_END_OF_LIST);
t252=(C_word)C_a_i_cons(&a,2,lf[259],t251);
t253=(C_word)C_a_i_cons(&a,2,lf[259],t252);
t254=(C_word)C_a_i_cons(&a,2,t250,t253);
t255=(C_word)C_a_i_cons(&a,2,lf[74],t254);
t256=(C_word)C_a_i_cons(&a,2,lf[262],t255);
t257=(C_word)C_a_i_cons(&a,2,lf[262],C_SCHEME_END_OF_LIST);
t258=(C_word)C_a_i_cons(&a,2,lf[261],t257);
t259=(C_word)C_a_i_cons(&a,2,lf[260],t258);
t260=(C_word)C_a_i_cons(&a,2,lf[257],t259);
t261=(C_word)C_a_i_cons(&a,2,lf[62],t260);
t262=(C_word)C_a_i_cons(&a,2,lf[225],t261);
t263=(C_word)C_a_i_cons(&a,2,lf[262],C_SCHEME_END_OF_LIST);
t264=(C_word)C_a_i_cons(&a,2,lf[261],t263);
t265=(C_word)C_a_i_cons(&a,2,lf[260],t264);
t266=(C_word)C_a_i_cons(&a,2,lf[258],t265);
t267=(C_word)C_a_i_cons(&a,2,lf[62],t266);
t268=(C_word)C_a_i_cons(&a,2,lf[226],t267);
t269=(C_word)C_a_i_cons(&a,2,t268,C_SCHEME_END_OF_LIST);
t270=(C_word)C_a_i_cons(&a,2,t262,t269);
t271=(C_word)C_a_i_cons(&a,2,t256,t270);
t272=(C_word)C_a_i_cons(&a,2,t247,t271);
t273=(C_word)C_a_i_cons(&a,2,t239,t272);
t274=(C_word)C_a_i_cons(&a,2,t232,t273);
t275=(C_word)C_a_i_cons(&a,2,t228,t274);
t276=(C_word)C_a_i_cons(&a,2,t218,t275);
t277=(C_word)C_a_i_cons(&a,2,t208,t276);
t278=(C_word)C_a_i_cons(&a,2,t202,t277);
t279=(C_word)C_a_i_cons(&a,2,t198,t278);
t280=(C_word)C_a_i_cons(&a,2,t197,t279);
t281=(C_word)C_a_i_cons(&a,2,t188,t280);
t282=(C_word)C_a_i_cons(&a,2,t187,t281);
t283=(C_word)C_a_i_cons(&a,2,t183,t282);
t284=(C_word)C_a_i_cons(&a,2,t182,t283);
t285=(C_word)C_a_i_cons(&a,2,t178,t284);
t286=(C_word)C_a_i_cons(&a,2,t177,t285);
t287=(C_word)C_a_i_cons(&a,2,t176,t286);
t288=(C_word)C_a_i_cons(&a,2,t172,t287);
t289=(C_word)C_a_i_cons(&a,2,t168,t288);
t290=(C_word)C_a_i_cons(&a,2,t167,t289);
t291=(C_word)C_a_i_cons(&a,2,t154,t290);
t292=(C_word)C_a_i_cons(&a,2,t153,t291);
t293=(C_word)C_a_i_cons(&a,2,t128,t292);
t294=(C_word)C_a_i_cons(&a,2,t127,t293);
t295=(C_word)C_a_i_cons(&a,2,t126,t294);
t296=(C_word)C_a_i_cons(&a,2,t122,t295);
t297=(C_word)C_a_i_cons(&a,2,t121,t296);
t298=(C_word)C_a_i_cons(&a,2,t117,t297);
t299=(C_word)C_a_i_cons(&a,2,t116,t298);
t300=(C_word)C_a_i_cons(&a,2,t112,t299);
t301=(C_word)C_a_i_cons(&a,2,t111,t300);
t302=(C_word)C_a_i_cons(&a,2,t110,t301);
t303=(C_word)C_a_i_cons(&a,2,t102,t302);
t304=(C_word)C_a_i_cons(&a,2,t101,t303);
t305=(C_word)C_a_i_cons(&a,2,t95,t304);
t306=(C_word)C_a_i_cons(&a,2,t89,t305);
t307=C_mutate(&lf[195] /* (set! sre-named-definitions ...) */,t306);
t308=C_mutate(&lf[217] /* (set! sre->nfa ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13350,tmp=(C_word)a,a+=2,tmp));
t309=C_mutate(&lf[216] /* (set! nfa->dfa ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14140,tmp=(C_word)a,a+=2,tmp));
t310=C_mutate(&lf[271] /* (set! nfa-join-transitions! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14437,tmp=(C_word)a,a+=2,tmp));
t311=C_mutate(&lf[273] /* (set! split-char-range ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14911,tmp=(C_word)a,a+=2,tmp));
t312=C_mutate(&lf[274] /* (set! intersect-char-ranges ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14985,tmp=(C_word)a,a+=2,tmp));
t313=C_mutate(&lf[270] /* (set! nfa-closure ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15101,tmp=(C_word)a,a+=2,tmp));
t314=C_mutate(&lf[272] /* (set! insert-sorted ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15182,tmp=(C_word)a,a+=2,tmp));
t315=C_mutate(&lf[172] /* (set! sre-cset->procedure ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17546,tmp=(C_word)a,a+=2,tmp));
t316=C_mutate(&lf[130] /* (set! sre->cset ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17663,tmp=(C_word)a,a+=2,tmp));
t317=C_mutate(&lf[275] /* (set! cset-contains? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17944,tmp=(C_word)a,a+=2,tmp));
t318=C_mutate(&lf[281] /* (set! char-ranges-overlap? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17994,tmp=(C_word)a,a+=2,tmp));
t319=C_mutate(&lf[276] /* (set! cset-union ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_18139,tmp=(C_word)a,a+=2,tmp));
t320=C_mutate(&lf[278] /* (set! cset-difference ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_18226,tmp=(C_word)a,a+=2,tmp));
t321=C_mutate(&lf[277] /* (set! cset-intersection ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_18347,tmp=(C_word)a,a+=2,tmp));
t322=C_mutate(&lf[129] /* (set! cset-complement ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_18465,tmp=(C_word)a,a+=2,tmp));
t323=C_mutate(&lf[118] /* (set! cset-case-insensitive ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_18475,tmp=(C_word)a,a+=2,tmp));
t324=C_mutate((C_word*)lf[282]+1 /* (set! irregex-fold ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_18640,tmp=(C_word)a,a+=2,tmp));
t325=C_mutate((C_word*)lf[283]+1 /* (set! irregex-replace ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_18753,tmp=(C_word)a,a+=2,tmp));
t326=C_mutate((C_word*)lf[285]+1 /* (set! irregex-replace/all ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_18805,tmp=(C_word)a,a+=2,tmp));
t327=C_mutate((C_word*)lf[284]+1 /* (set! irregex-apply-match ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_18861,tmp=(C_word)a,a+=2,tmp));
t328=C_mutate((C_word*)lf[290]+1 /* (set! regexp? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19043,tmp=(C_word)a,a+=2,tmp));
t329=C_mutate((C_word*)lf[291]+1 /* (set! regexp ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19061,tmp=(C_word)a,a+=2,tmp));
t330=C_mutate(&lf[292] /* (set! unregexp ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19164,tmp=(C_word)a,a+=2,tmp));
t331=C_mutate((C_word*)lf[293]+1 /* (set! string-match ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19185,tmp=(C_word)a,a+=2,tmp));
t332=C_mutate((C_word*)lf[294]+1 /* (set! string-match-positions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19231,tmp=(C_word)a,a+=2,tmp));
t333=C_mutate((C_word*)lf[295]+1 /* (set! string-search ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19293,tmp=(C_word)a,a+=2,tmp));
t334=C_mutate((C_word*)lf[296]+1 /* (set! string-search-positions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19405,tmp=(C_word)a,a+=2,tmp));
t335=*((C_word*)lf[33]+1);
t336=*((C_word*)lf[297]+1);
t337=*((C_word*)lf[296]+1);
t338=C_mutate((C_word*)lf[298]+1 /* (set! string-split-fields ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19525,a[2]=t335,a[3]=t337,a[4]=t336,tmp=(C_word)a,a+=5,tmp));
t339=*((C_word*)lf[297]+1);
t340=*((C_word*)lf[33]+1);
t341=*((C_word*)lf[29]+1);
t342=*((C_word*)lf[296]+1);
t343=C_mutate((C_word*)lf[304]+1 /* (set! string-substitute ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19707,a[2]=t342,a[3]=t340,a[4]=t339,tmp=(C_word)a,a+=5,tmp));
t344=*((C_word*)lf[304]+1);
t345=C_mutate((C_word*)lf[307]+1 /* (set! string-substitute* ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_19962,a[2]=t344,tmp=(C_word)a,a+=3,tmp));
t346=C_mutate((C_word*)lf[308]+1 /* (set! glob? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_20014,tmp=(C_word)a,a+=2,tmp));
t347=*((C_word*)lf[309]+1);
t348=*((C_word*)lf[310]+1);
t349=C_mutate((C_word*)lf[311]+1 /* (set! glob->regexp ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_20099,tmp=(C_word)a,a+=2,tmp));
t350=*((C_word*)lf[295]+1);
t351=C_mutate((C_word*)lf[313]+1 /* (set! grep ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20376,a[2]=t350,tmp=(C_word)a,a+=3,tmp));
t352=*((C_word*)lf[314]+1);
t353=*((C_word*)lf[315]+1);
t354=C_mutate((C_word*)lf[316]+1 /* (set! regexp-escape ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_20437,tmp=(C_word)a,a+=2,tmp));
t355=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t355+1)))(2,t355,C_SCHEME_UNDEFINED);}

/* regexp-escape in k3721 */
static void C_ccall f_20437(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_20437,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[316]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20444,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 318  open-output-string */
t5=*((C_word*)lf[314]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k20442 in regexp-escape in k3721 */
static void C_ccall f_20444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20444,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20452,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_20452(t6,((C_word*)t0)[2],C_fix(0));}

/* loop in k20442 in regexp-escape in k3721 */
static void C_fcall f_20452(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20452,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
/* regex.scm: 321  get-output-string */
t3=*((C_word*)lf[315]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,((C_word*)t0)[4]);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
if(C_truep((C_truep((C_word)C_eqp(t3,C_make_character(46)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(63)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(42)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(43)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(94)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(36)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(40)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(41)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(91)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(93)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(124)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(123)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(125)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))))))))))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_20471,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* regex.scm: 324  ##sys#write-char-0 */
t5=*((C_word*)lf[317]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_make_character(92),((C_word*)t0)[4]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20484,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 328  ##sys#write-char-0 */
t5=*((C_word*)lf[317]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,(C_word)C_subchar(((C_word*)t0)[3],t2),((C_word*)t0)[4]);}}}

/* k20482 in loop in k20442 in regexp-escape in k3721 */
static void C_ccall f_20484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 329  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_20452(t3,((C_word*)t0)[2],t2);}

/* k20469 in loop in k20442 in regexp-escape in k3721 */
static void C_ccall f_20471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20474,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 325  ##sys#write-char-0 */
t3=*((C_word*)lf[317]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,(C_word)C_subchar(((C_word*)t0)[3],((C_word*)t0)[6]),((C_word*)t0)[2]);}

/* k20472 in k20469 in loop in k20442 in regexp-escape in k3721 */
static void C_ccall f_20474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 326  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_20452(t3,((C_word*)t0)[2],t2);}

/* grep in k3721 */
static void C_ccall f_20376(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4rv,(void*)f_20376r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_20376r(t0,t1,t2,t3,t4);}}

static void C_ccall f_20376r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(10);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_20425,tmp=(C_word)a,a+=2,tmp):(C_word)C_slot(t4,C_fix(0)));
t7=(C_word)C_i_check_list_2(t3,lf[313]);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20388,a[2]=t6,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t9,tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_20388(t11,t1,t3);}

/* loop in grep in k3721 */
static void C_fcall f_20388(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20388,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20407,a[2]=t4,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20421,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 306  acc */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}}

/* k20419 in loop in grep in k3721 */
static void C_ccall f_20421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 306  string-search */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k20405 in loop in grep in k3721 */
static void C_ccall f_20407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20407,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20414,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 307  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_20388(t3,t2,((C_word*)t0)[2]);}
else{
/* regex.scm: 308  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_20388(t2,((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k20412 in k20405 in loop in grep in k3721 */
static void C_ccall f_20414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20414,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* f_20425 in grep in k3721 */
static void C_ccall f_20425(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_20425,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* glob->regexp in k3721 */
static void C_ccall f_20099(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_20099,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[311]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20110,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20114,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t6=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k20112 in glob->regexp in k3721 */
static void C_ccall f_20114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20114,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20116,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_20116(t5,((C_word*)t0)[2],t1);}

/* loop in k20112 in glob->regexp in k3721 */
static void C_fcall f_20116(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_20116,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
switch(t3){
case C_make_character(42):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20146,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20150,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 272  loop */
t18=t6;
t19=t4;
t1=t18;
t2=t19;
goto loop;
case C_make_character(63):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20163,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 273  loop */
t18=t5;
t19=t4;
t1=t18;
t2=t19;
goto loop;
case C_make_character(91):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20176,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20178,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_20178(t9,t5,t4);
default:
t5=(C_word)C_u_i_char_alphabeticp(t3);
t6=(C_truep(t5)?t5:(C_word)C_u_i_char_numericp(t3));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20356,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 291  loop */
t18=t7;
t19=t4;
t1=t18;
t2=t19;
goto loop;}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20367,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20371,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 292  loop */
t18=t8;
t19=t4;
t1=t18;
t2=t19;
goto loop;}}}}

/* k20369 in loop in k20112 in glob->regexp in k3721 */
static void C_ccall f_20371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k20365 in loop in k20112 in glob->regexp in k3721 */
static void C_ccall f_20367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20367,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,C_make_character(92),t2));}

/* k20354 in loop in k20112 in glob->regexp in k3721 */
static void C_ccall f_20356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20356,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* loop2 in loop in k20112 in glob->regexp in k3721 */
static void C_fcall f_20178(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20178,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_eqp(C_make_character(93),t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20198,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_slot(t2,C_fix(1));
/* regex.scm: 280  loop */
t7=((C_word*)((C_word*)t0)[4])[1];
f_20116(t7,t5,t6);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20208,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_eqp(C_make_character(45),t6);
if(C_truep(t7)){
t8=(C_word)C_slot(t2,C_fix(1));
t9=t5;
f_20208(t9,(C_word)C_i_pairp(t8));}
else{
t8=t5;
f_20208(t8,C_SCHEME_FALSE);}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k20206 in loop2 in loop in k20112 in glob->regexp in k3721 */
static void C_fcall f_20208(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20208,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20223,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20227,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_u_i_cddr(((C_word*)t0)[5]);
/* regex.scm: 282  loop2 */
t6=((C_word*)((C_word*)t0)[3])[1];
f_20178(t6,t4,t5);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20237,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_cddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_u_i_cadr(((C_word*)t0)[5]);
t6=t2;
f_20237(t6,(C_word)C_eqp(C_make_character(45),t5));}
else{
t5=t2;
f_20237(t5,C_SCHEME_FALSE);}}
else{
t4=t2;
f_20237(t4,C_SCHEME_FALSE);}}}

/* k20235 in k20206 in loop2 in loop in k20112 in glob->regexp in k3721 */
static void C_fcall f_20237(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20237,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20260,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20264,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_u_i_cdddr(((C_word*)t0)[5]);
/* regex.scm: 286  loop2 */
t7=((C_word*)((C_word*)t0)[3])[1];
f_20178(t7,t5,t6);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20285,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* regex.scm: 288  loop2 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_20178(t5,t3,t4);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
/* regex.scm: 290  error */
t2=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[311],lf[312],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}}}

/* k20283 in k20235 in k20206 in loop2 in loop in k20112 in glob->regexp in k3721 */
static void C_ccall f_20285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20285,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k20262 in k20235 in k20206 in loop2 in loop in k20112 in glob->regexp in k3721 */
static void C_ccall f_20264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k20258 in k20235 in k20206 in loop2 in loop in k20112 in glob->regexp in k3721 */
static void C_ccall f_20260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20260,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,C_make_character(45),t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k20225 in k20206 in loop2 in loop in k20112 in glob->regexp in k3721 */
static void C_ccall f_20227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k20221 in k20206 in loop2 in loop in k20112 in glob->regexp in k3721 */
static void C_ccall f_20223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20223,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,C_make_character(45),t2));}

/* k20196 in loop2 in loop in k20112 in glob->regexp in k3721 */
static void C_ccall f_20198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20198,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_make_character(93),t1));}

/* k20174 in loop in k20112 in glob->regexp in k3721 */
static void C_ccall f_20176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20176,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_make_character(91),t1));}

/* k20161 in loop in k20112 in glob->regexp in k3721 */
static void C_ccall f_20163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20163,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_make_character(46),t1));}

/* k20148 in loop in k20112 in glob->regexp in k3721 */
static void C_ccall f_20150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k20144 in loop in k20112 in glob->regexp in k3721 */
static void C_ccall f_20146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20146,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_make_character(42),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,C_make_character(46),t2));}

/* k20108 in glob->regexp in k3721 */
static void C_ccall f_20110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* list->string */
t2=*((C_word*)lf[119]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* glob? in k3721 */
static void C_ccall f_20014(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_20014,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[308]);
t4=(C_word)C_fix((C_word)C_header_size(t2));
t5=(C_word)C_u_fixnum_difference(t4,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20027,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_20027(t9,t1,t5);}

/* loop in glob? in k3721 */
static void C_fcall f_20027(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20027,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(C_fix(0),t2))){
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
t4=(C_word)C_eqp(t3,C_make_character(42));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20046,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_20046(t6,t4);}
else{
t6=(C_word)C_eqp(t3,C_make_character(93));
t7=t5;
f_20046(t7,(C_truep(t6)?t6:(C_word)C_eqp(t3,C_make_character(63))));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k20044 in loop in glob? in k3721 */
static void C_fcall f_20046(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_eqp(C_fix(0),((C_word*)t0)[5]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_subchar(((C_word*)t0)[3],t3);
t5=(C_word)C_eqp(C_make_character(92),t4);
t6=(C_word)C_i_not(t5);
if(C_truep(t6)){
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(2));
/* regex.scm: 257  loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_20027(t8,((C_word*)t0)[4],t7);}}}
else{
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
/* regex.scm: 259  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_20027(t3,((C_word*)t0)[4],t2);}}

/* string-substitute* in k3721 */
static void C_ccall f_19962(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4rv,(void*)f_19962r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_19962r(t0,t1,t2,t3,t4);}}

static void C_ccall f_19962r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(7);
t5=(C_word)C_i_check_string_2(t2,lf[307]);
t6=(C_word)C_i_check_list_2(t3,lf[307]);
t7=(C_word)C_notvemptyp(t4);
t8=(C_truep(t7)?(C_word)C_slot(t4,C_fix(0)):C_SCHEME_FALSE);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19977,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t10,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_19977(t12,t1,t2,t3);}

/* loop in string-substitute* in k3721 */
static void C_fcall f_19977(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19977,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_u_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19994,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_i_car(t4);
t7=(C_word)C_slot(t4,C_fix(1));
/* regex.scm: 242  string-substitute */
t8=((C_word*)t0)[3];
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t5,t6,t7,t2,((C_word*)t0)[2]);}}

/* k19992 in loop in string-substitute* in k3721 */
static void C_ccall f_19994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 242  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_19977(t3,((C_word*)t0)[2],t1,t2);}

/* string-substitute in k3721 */
static void C_ccall f_19707(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+32)){
C_save_and_reclaim((void*)tr5rv,(void*)f_19707r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_19707r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_19707r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a=C_alloc(32);
t6=(C_word)C_i_check_string_2(t3,lf[304]);
t7=(C_word)C_i_check_string_2(t4,lf[304]);
t8=(C_word)C_notvemptyp(t5);
t9=(C_truep(t8)?(C_word)C_slot(t5,C_fix(0)):C_fix(1));
t10=(C_word)C_block_size(t3);
t11=(C_word)C_block_size(t4);
t12=(C_word)C_u_fixnum_difference(t10,C_fix(1));
t13=C_SCHEME_END_OF_LIST;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_fix(0);
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19728,a[2]=t16,a[3]=t14,tmp=(C_word)a,a+=4,tmp);
t18=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_19743,a[2]=t4,a[3]=t10,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t17,a[7]=t12,tmp=(C_word)a,a+=8,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_19849,a[2]=((C_word*)t0)[2],a[3]=t11,a[4]=t14,a[5]=((C_word*)t0)[3],a[6]=t16,a[7]=t4,a[8]=((C_word*)t0)[4],a[9]=t18,a[10]=t20,a[11]=t17,a[12]=t9,a[13]=t2,tmp=(C_word)a,a+=14,tmp));
t22=((C_word*)t20)[1];
f_19849(t22,t1,C_fix(0),C_fix(1));}

/* loop in string-substitute in k3721 */
static void C_fcall f_19849(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19849,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_19853,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t3,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=t1,tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,((C_word*)t0)[3]))){
/* regex.scm: 213  string-search-positions */
t5=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[13],((C_word*)t0)[7],t2);}
else{
t5=t4;
f_19853(2,t5,C_SCHEME_FALSE);}}

/* k19851 in loop in string-substitute in k3721 */
static void C_ccall f_19853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19853,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_u_i_cadr(t2);
t4=(C_word)C_u_i_cadr(t2);
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_u_fixnum_difference(t4,t5);
t7=(C_word)C_eqp(C_fix(0),t6);
if(C_truep(t7)){
/* regex.scm: 218  ##sys#error */
t8=*((C_word*)lf[301]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,((C_word*)t0)[14],lf[304],lf[305],((C_word*)t0)[13]);}
else{
t8=(C_word)C_fixnump(((C_word*)t0)[12]);
t9=(C_word)C_i_not(t8);
t10=(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[11],((C_word*)t0)[12]));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_19893,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t12=(C_word)C_u_i_car(t2);
/* regex.scm: 222  substring */
t13=((C_word*)t0)[7];
((C_proc5)(void*)(*((C_word*)t13+1)))(5,t13,t11,((C_word*)t0)[6],((C_word*)t0)[5],t12);}
else{
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_19911,a[2]=t3,a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* regex.scm: 226  substring */
t12=((C_word*)t0)[7];
((C_proc5)(void*)(*((C_word*)t12+1)))(5,t12,t11,((C_word*)t0)[6],((C_word*)t0)[5],t3);}}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_19944,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[6]);
/* regex.scm: 229  substring */
t4=((C_word*)t0)[7];
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[6],((C_word*)t0)[5],t3);}}

/* k19942 in k19851 in loop in string-substitute in k3721 */
static void C_ccall f_19944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19944,2,t0,t1);}
t2=f_19728(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19940,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 230  reverse */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k19938 in k19942 in k19851 in loop in string-substitute in k3721 */
static void C_ccall f_19940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 230  ##sys#fragments->string */
t2=*((C_word*)lf[306]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k19909 in k19851 in loop in string-substitute in k3721 */
static void C_ccall f_19911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19911,2,t0,t1);}
t2=f_19728(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* regex.scm: 227  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_19849(t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k19891 in k19851 in loop in string-substitute in k3721 */
static void C_ccall f_19893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19893,2,t0,t1);}
t2=f_19728(C_a_i(&a,3),((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19886,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 223  substitute */
t4=((C_word*)t0)[3];
f_19743(t4,t3,((C_word*)t0)[2]);}

/* k19884 in k19891 in k19851 in loop in string-substitute in k3721 */
static void C_ccall f_19886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 224  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_19849(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* substitute in string-substitute in k3721 */
static void C_fcall f_19743(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19743,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_19749,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_19749(t6,t1,C_fix(0),C_fix(0));}

/* loop in substitute in string-substitute in k3721 */
static void C_fcall f_19749(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_19749,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19763,a[2]=((C_word*)t0)[8],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=t4;
f_19763(2,t6,((C_word*)t0)[7]);}
else{
/* regex.scm: 199  substring */
t6=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[7],t2,((C_word*)t0)[5]);}}
else{
t4=(C_word)C_subchar(((C_word*)t0)[7],t3);
t5=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t6=(C_word)C_eqp(t4,C_make_character(92));
if(C_truep(t6)){
t7=(C_word)C_subchar(((C_word*)t0)[7],t5);
t8=(C_word)C_eqp(C_make_character(92),t7);
t9=(C_truep(t8)?C_SCHEME_FALSE:(C_word)C_u_i_char_numericp(t7));
if(C_truep(t9)){
t10=(C_word)C_fix((C_word)C_character_code(t7));
t11=(C_word)C_u_fixnum_difference(t10,C_fix(48));
t12=(C_word)C_u_i_list_ref(((C_word*)t0)[4],t11);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_19816,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t12,a[5]=t5,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=t3,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* regex.scm: 206  substring */
t14=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,t13,((C_word*)t0)[7],t2,t3);}
else{
t10=(C_word)C_u_fixnum_plus(t5,C_fix(1));
/* regex.scm: 209  loop */
t18=t1;
t19=t2;
t20=t10;
t1=t18;
t2=t19;
t3=t20;
goto loop;}}
else{
/* regex.scm: 210  loop */
t18=t1;
t19=t2;
t20=t5;
t1=t18;
t2=t19;
t3=t20;
goto loop;}}}

/* k19814 in loop in substitute in string-substitute in k3721 */
static void C_ccall f_19816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19816,2,t0,t1);}
t2=f_19728(C_a_i(&a,3),((C_word*)t0)[9],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_19804,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_u_i_car(((C_word*)t0)[4]);
t5=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
/* regex.scm: 207  substring */
t6=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t3,((C_word*)t0)[2],t4,t5);}

/* k19802 in k19814 in loop in substitute in string-substitute in k3721 */
static void C_ccall f_19804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19804,2,t0,t1);}
t2=f_19728(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(2));
/* regex.scm: 208  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_19749(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k19761 in loop in substitute in string-substitute in k3721 */
static void C_ccall f_19763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19763,2,t0,t1);}
/* regex.scm: 199  push */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_19728(C_a_i(&a,3),((C_word*)t0)[2],t1));}

/* push in string-substitute in k3721 */
static C_word C_fcall f_19728(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=(C_word)C_block_size(t1);
t5=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t4);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
return(t6);}

/* string-split-fields in k3721 */
static void C_ccall f_19525(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr4rv,(void*)f_19525r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_19525r(t0,t1,t2,t3,t4);}}

static void C_ccall f_19525r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(16);
t5=(C_word)C_i_check_string_2(t3,lf[298]);
t6=(C_word)C_block_size(t4);
t7=(C_word)C_block_size(t3);
t8=(C_word)C_fixnum_greaterp(t6,C_fix(0));
t9=(C_truep(t8)?(C_word)C_slot(t4,C_fix(0)):C_SCHEME_TRUE);
t10=(C_word)C_fixnum_greaterp(t6,C_fix(1));
t11=(C_truep(t10)?(C_word)C_slot(t4,C_fix(1)):C_fix(0));
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_19544,a[2]=t11,a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t7,a[7]=t3,a[8]=((C_word*)t0)[4],a[9]=t9,tmp=(C_word)a,a+=10,tmp);
t13=(C_word)C_eqp(t9,lf[300]);
if(C_truep(t13)){
t14=t12;
f_19544(t14,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_19643,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t7,tmp=(C_word)a,a+=6,tmp));}
else{
t14=(C_word)C_eqp(t9,lf[299]);
t15=t12;
f_19544(t15,(C_truep(t14)?(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_19663,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=t7,tmp=(C_word)a,a+=6,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_19689,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp)));}}

/* f_19689 in string-split-fields in k3721 */
static void C_ccall f_19689(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_19689,4,t0,t1,t2,t3);}
/* regex.scm: 159  reverse */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}

/* f_19663 in string-split-fields in k3721 */
static void C_ccall f_19663(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_19663,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[5]))){
t4=(C_word)C_a_i_cons(&a,2,lf[303],t2);
/* regex.scm: 157  reverse */
t5=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19688,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 158  substring */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[2],t3,((C_word*)t0)[5]);}}

/* k19686 */
static void C_ccall f_19688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19688,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* regex.scm: 158  reverse */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_19643 in string-split-fields in k3721 */
static void C_ccall f_19643(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_19643,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[5]))){
/* regex.scm: 151  ##sys#error */
t4=*((C_word*)lf[301]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[298],lf[302],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* regex.scm: 153  reverse */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}}

/* k19542 in string-split-fields in k3721 */
static void C_fcall f_19544(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19544,NULL,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[299]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[9],lf[300]));
t4=(C_truep(t3)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19627,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19632,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_19552,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=t6,a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_19552(t8,((C_word*)t0)[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);}

/* loop in k19542 in string-split-fields in k3721 */
static void C_fcall f_19552(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19552,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_19556,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* regex.scm: 164  string-search-positions */
t5=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k19554 in loop in k19542 in string-split-fields in k3721 */
static void C_ccall f_19556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19556,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_u_i_cadr(t2);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_eqp(t4,((C_word*)t0)[8]);
if(C_truep(t6)){
/* regex.scm: 171  fini */
t7=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_19598,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t9=(C_word)C_u_fixnum_plus(t4,C_fix(2));
/* regex.scm: 172  fetch */
t10=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t7,((C_word*)t0)[4],t8,t9);}}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_19617,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 173  fetch */
t7=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,((C_word*)t0)[4],t3,t4);}}
else{
/* regex.scm: 174  fini */
t2=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k19615 in k19554 in loop in k19542 in string-split-fields in k3721 */
static void C_ccall f_19617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19617,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* regex.scm: 173  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_19552(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k19596 in k19554 in loop in k19542 in string-split-fields in k3721 */
static void C_ccall f_19598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19598,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 172  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_19552(t4,((C_word*)t0)[2],t2,t3);}

/* f_19632 in k19542 in string-split-fields in k3721 */
static void C_ccall f_19632(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_19632,5,t0,t1,t2,t3,t4);}
/* regex.scm: 162  substring */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,((C_word*)t0)[2],t3,t4);}

/* f_19627 in k19542 in string-split-fields in k3721 */
static void C_ccall f_19627(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_19627,5,t0,t1,t2,t3,t4);}
/* regex.scm: 161  substring */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,((C_word*)t0)[2],t2,t3);}

/* string-search-positions in k3721 */
static void C_ccall f_19405(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr4r,(void*)f_19405r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_19405r(t0,t1,t2,t3,t4);}}

static void C_ccall f_19405r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(11);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19407,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19471,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_19480,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-start34193440 */
t8=t7;
f_19480(t8,t1);}
else{
t8=(C_word)C_u_i_car(t4);
t9=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-range34203438 */
t10=t6;
f_19471(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
/* body34173425 */
t12=t5;
f_19407(t12,t1,t8,t10);}}}

/* def-start3419 in string-search-positions in k3721 */
static void C_fcall f_19480(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19480,NULL,2,t0,t1);}
/* def-range34203438 */
t2=((C_word*)t0)[2];
f_19471(t2,t1,C_fix(0));}

/* def-range3420 in string-search-positions in k3721 */
static void C_fcall f_19471(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19471,NULL,3,t0,t1,t2);}
t3=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[3]));
/* body34173425 */
t4=((C_word*)t0)[2];
f_19407(t4,t1,t2,t3);}

/* body3417 in string-search-positions in k3721 */
static void C_fcall f_19407(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19407,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_19411,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 123  unregexp */
f_19164(t4,((C_word*)t0)[2]);}

/* k19409 in body3417 in string-search-positions in k3721 */
static void C_ccall f_19411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19411,2,t0,t1);}
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[5]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_19420,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_19466,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],((C_word*)t0)[2]);
/* regex.scm: 125  min */
t6=*((C_word*)lf[202]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t2,t5);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k19464 in k19409 in body3417 in string-search-positions in k3721 */
static void C_ccall f_19466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 125  irregex-search */
t2=*((C_word*)lf[231]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k19418 in k19409 in body3417 in string-search-positions in k3721 */
static void C_ccall f_19420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19420,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19430,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 126  irregex-match-num-submatches */
t3=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k19428 in k19418 in k19409 in body3417 in string-search-positions in k3721 */
static void C_ccall f_19430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19430,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19432,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_19432(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k19428 in k19418 in k19409 in body3417 in string-search-positions in k3721 */
static void C_fcall f_19432(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(25);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_19432,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t5=((C_word*)t0)[3];
t6=t2;
t7=(C_word)C_a_i_times(&a,2,t6,C_fix(2));
t8=(C_word)C_a_i_plus(&a,2,C_fix(3),t7);
t9=(C_word)C_slot(t5,t8);
t10=((C_word*)t0)[3];
t11=t2;
t12=(C_word)C_a_i_times(&a,2,t11,C_fix(2));
t13=(C_word)C_a_i_plus(&a,2,C_fix(4),t12);
t14=(C_word)C_slot(t10,t13);
t15=(C_word)C_a_i_list(&a,2,t9,t14);
t16=(C_word)C_a_i_cons(&a,2,t15,t3);
/* regex.scm: 130  loop */
t18=t1;
t19=t4;
t20=t16;
t1=t18;
t2=t19;
t3=t20;
goto loop;}}

/* string-search in k3721 */
static void C_ccall f_19293(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr4r,(void*)f_19293r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_19293r(t0,t1,t2,t3,t4);}}

static void C_ccall f_19293r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(11);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19295,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19351,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_19360,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-start33763397 */
t8=t7;
f_19360(t8,t1);}
else{
t8=(C_word)C_u_i_car(t4);
t9=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-range33773395 */
t10=t6;
f_19351(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
/* body33743382 */
t12=t5;
f_19295(t12,t1,t8,t10);}}}

/* def-start3376 in string-search in k3721 */
static void C_fcall f_19360(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19360,NULL,2,t0,t1);}
/* def-range33773395 */
t2=((C_word*)t0)[2];
f_19351(t2,t1,C_fix(0));}

/* def-range3377 in string-search in k3721 */
static void C_fcall f_19351(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19351,NULL,3,t0,t1,t2);}
t3=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[3]));
/* body33743382 */
t4=((C_word*)t0)[2];
f_19295(t4,t1,t2,t3);}

/* body3374 in string-search in k3721 */
static void C_fcall f_19295(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19295,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_19299,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 113  unregexp */
f_19164(t4,((C_word*)t0)[2]);}

/* k19297 in body3374 in string-search in k3721 */
static void C_ccall f_19299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19299,2,t0,t1);}
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[5]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_19308,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_19346,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],((C_word*)t0)[2]);
/* regex.scm: 115  min */
t6=*((C_word*)lf[202]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t2,t5);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k19344 in k19297 in body3374 in string-search in k3721 */
static void C_ccall f_19346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 115  irregex-search */
t2=*((C_word*)lf[231]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k19306 in k19297 in body3374 in string-search in k3721 */
static void C_ccall f_19308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19308,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19318,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 116  irregex-match-num-submatches */
t3=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k19316 in k19306 in k19297 in body3374 in string-search in k3721 */
static void C_ccall f_19318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19318,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19320,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_19320(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k19316 in k19306 in k19297 in body3374 in string-search in k3721 */
static void C_fcall f_19320(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19320,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_19342,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 120  irregex-match-substring */
t6=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t2);}}

/* k19340 in loop in k19316 in k19306 in k19297 in body3374 in string-search in k3721 */
static void C_ccall f_19342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19342,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* regex.scm: 120  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_19320(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* string-match-positions in k3721 */
static void C_ccall f_19231(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_19231,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19235,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 102  unregexp */
f_19164(t4,t2);}

/* k19233 in string-match-positions in k3721 */
static void C_ccall f_19235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19235,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19238,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 103  irregex-match */
t3=*((C_word*)lf[233]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[3]);}

/* k19236 in k19233 in string-match-positions in k3721 */
static void C_ccall f_19238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19238,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19248,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 104  irregex-match-num-submatches */
t3=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k19246 in k19236 in k19233 in string-match-positions in k3721 */
static void C_ccall f_19248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19248,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19250,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_19250(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k19246 in k19236 in k19233 in string-match-positions in k3721 */
static void C_fcall f_19250(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
loop:
a=C_alloc(25);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_19250,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t4=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[4]));
t5=(C_word)C_a_i_list(&a,2,C_fix(0),t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,t5,t3));}
else{
t4=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t5=((C_word*)t0)[3];
t6=t2;
t7=(C_word)C_a_i_times(&a,2,t6,C_fix(2));
t8=(C_word)C_a_i_plus(&a,2,C_fix(3),t7);
t9=(C_word)C_slot(t5,t8);
t10=((C_word*)t0)[3];
t11=t2;
t12=(C_word)C_a_i_times(&a,2,t11,C_fix(2));
t13=(C_word)C_a_i_plus(&a,2,C_fix(4),t12);
t14=(C_word)C_slot(t10,t13);
t15=(C_word)C_a_i_list(&a,2,t9,t14);
t16=(C_word)C_a_i_cons(&a,2,t15,t3);
/* regex.scm: 108  loop */
t20=t1;
t21=t4;
t22=t16;
t1=t20;
t2=t21;
t3=t22;
goto loop;}}

/* string-match in k3721 */
static void C_ccall f_19185(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_19185,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19189,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 93   unregexp */
f_19164(t4,t2);}

/* k19187 in string-match in k3721 */
static void C_ccall f_19189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19189,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19192,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 94   irregex-match */
t3=*((C_word*)lf[233]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[3]);}

/* k19190 in k19187 in string-match in k3721 */
static void C_ccall f_19192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19192,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19202,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 95   irregex-match-num-submatches */
t3=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k19200 in k19190 in k19187 in string-match in k3721 */
static void C_ccall f_19202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19202,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19204,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_19204(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k19200 in k19190 in k19187 in string-match in k3721 */
static void C_fcall f_19204(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19204,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3));}
else{
t4=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_19229,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 99   irregex-match-substring */
t6=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t2);}}

/* k19227 in loop in k19200 in k19190 in k19187 in string-match in k3721 */
static void C_ccall f_19229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19229,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* regex.scm: 99   loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_19204(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* unregexp in k3721 */
static void C_fcall f_19164(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19164,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19171,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 85   regexp? */
t4=*((C_word*)lf[290]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k19169 in unregexp in k3721 */
static void C_ccall f_19171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19171,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t3,C_fix(1)));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19180,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 86   irregex? */
t3=*((C_word*)lf[0]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k19178 in k19169 in unregexp in k3721 */
static void C_ccall f_19180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
/* regex.scm: 87   irregex */
t2=*((C_word*)lf[169]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* regexp in k3721 */
static void C_ccall f_19061(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_19061r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_19061r(t0,t1,t2,t3);}}

static void C_ccall f_19061r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_19063,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_19094,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_19099,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_19104,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-caseless32933319 */
t8=t7;
f_19104(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-extended32943317 */
t10=t6;
f_19099(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-utf832953314 */
t12=t5;
f_19094(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body32913300 */
t14=t4;
f_19063(t14,t1,t8,t10,t12);}}}}

/* def-caseless3293 in regexp in k3721 */
static void C_fcall f_19104(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19104,NULL,2,t0,t1);}
/* def-extended32943317 */
t2=((C_word*)t0)[2];
f_19099(t2,t1,C_SCHEME_FALSE);}

/* def-extended3294 in regexp in k3721 */
static void C_fcall f_19099(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19099,NULL,3,t0,t1,t2);}
/* def-utf832953314 */
t3=((C_word*)t0)[2];
f_19094(t3,t1,t2,C_SCHEME_FALSE);}

/* def-utf83295 in regexp in k3721 */
static void C_fcall f_19094(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19094,NULL,4,t0,t1,t2,t3);}
/* body32913300 */
t4=((C_word*)t0)[2];
f_19063(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body3291 in regexp in k3721 */
static void C_fcall f_19063(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19063,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_19071,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_19075,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t9=(C_word)C_a_i_cons(&a,2,lf[50],((C_word*)t7)[1]);
t10=C_set_block_item(t7,0,t9);
t11=t8;
f_19075(t11,t10);}
else{
t9=t8;
f_19075(t9,C_SCHEME_UNDEFINED);}}

/* k19073 in body3291 in regexp in k3721 */
static void C_fcall f_19075(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19075,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_19078,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_a_i_cons(&a,2,lf[55],((C_word*)((C_word*)t0)[6])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=t2;
f_19078(t5,t4);}
else{
t3=t2;
f_19078(t3,C_SCHEME_UNDEFINED);}}

/* k19076 in k19073 in body3291 in regexp in k3721 */
static void C_fcall f_19078(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19078,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19081,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_a_i_cons(&a,2,lf[58],((C_word*)((C_word*)t0)[5])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
t5=t2;
f_19081(t5,t4);}
else{
t3=t2;
f_19081(t3,C_SCHEME_UNDEFINED);}}

/* k19079 in k19076 in k19073 in body3291 in regexp in k3721 */
static void C_fcall f_19081(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
C_apply(5,0,((C_word*)t0)[3],*((C_word*)lf[169]+1),((C_word*)t0)[2],t2);}

/* k19069 in body3291 in regexp in k3721 */
static void C_ccall f_19071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19071,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,2,lf[291],t1));}

/* regexp? in k3721 */
static void C_ccall f_19043(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_19043,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[291]));}

/* irregex-apply-match in k3721 */
static void C_ccall f_18861(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_18861,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18867,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_18867(t7,t1,t3,C_SCHEME_END_OF_LIST);}

/* lp in irregex-apply-match in k3721 */
static void C_fcall f_18867(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_18867,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_integerp(t4))){
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_18895,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_u_i_car(t2);
/* irregex-match-substring */
t8=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,((C_word*)t0)[2],t7);}
else{
t5=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_closurep(t5))){
t6=(C_word)C_slot(t2,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_18923,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_u_i_car(t2);
t9=t8;
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,((C_word*)t0)[2]);}
else{
t6=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t6))){
t7=(C_word)C_u_i_car(t2);
t8=(C_word)C_eqp(t7,lf[287]);
if(C_truep(t8)){
t9=(C_word)C_slot(t2,C_fix(1));
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_18956,a[2]=t9,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18960,a[2]=((C_word*)t0)[2],a[3]=t10,tmp=(C_word)a,a+=4,tmp);
/* irregex-match-string */
t12=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,((C_word*)t0)[2]);}
else{
t9=(C_word)C_eqp(t7,lf[288]);
if(C_truep(t9)){
t10=(C_word)C_slot(t2,C_fix(1));
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_18985,a[2]=t10,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18989,a[2]=((C_word*)t0)[2],a[3]=t11,tmp=(C_word)a,a+=4,tmp);
/* irregex-match-string */
t13=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,((C_word*)t0)[2]);}
else{
t10=(C_word)C_u_i_car(t2);
/* error */
t11=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[289],t10);}}}
else{
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_u_i_car(t2);
t9=(C_word)C_a_i_cons(&a,2,t8,t3);
/* lp3100 */
t27=t1;
t28=t7;
t29=t9;
t1=t27;
t2=t28;
t3=t29;
goto loop;}}}}}

/* k18987 in lp in irregex-apply-match in k3721 */
static void C_ccall f_18989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18993,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* irregex-match-end */
t3=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k18991 in k18987 in lp in irregex-apply-match in k3721 */
static void C_ccall f_18993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18993,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19001,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* irregex-match-string */
t3=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k18999 in k18991 in k18987 in lp in irregex-apply-match in k3721 */
static void C_ccall f_19001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fix((C_word)C_header_size(t1));
/* substring */
t3=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k18983 in lp in irregex-apply-match in k3721 */
static void C_ccall f_18985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18985,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* lp3100 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_18867(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k18958 in lp in irregex-apply-match in k3721 */
static void C_ccall f_18960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18964,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* irregex-match-start */
t3=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k18962 in k18958 in lp in irregex-apply-match in k3721 */
static void C_ccall f_18964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* substring */
t2=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t1);}

/* k18954 in lp in irregex-apply-match in k3721 */
static void C_ccall f_18956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18956,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* lp3100 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_18867(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k18921 in lp in irregex-apply-match in k3721 */
static void C_ccall f_18923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18923,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* lp3100 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_18867(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k18893 in lp in irregex-apply-match in k3721 */
static void C_ccall f_18895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18895,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[286]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[5]);
/* lp3100 */
t4=((C_word*)((C_word*)t0)[4])[1];
f_18867(t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* irregex-replace/all in k3721 */
static void C_ccall f_18805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_18805r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_18805r(t0,t1,t2,t3,t4);}}

static void C_ccall f_18805r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18811,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18838,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* irregex-fold */
t7=*((C_word*)lf[282]+1);
((C_proc7)(void*)(*((C_word*)t7+1)))(7,t7,t1,t2,t5,C_SCHEME_END_OF_LIST,t3,t6);}

/* a18837 in irregex-replace/all in k3721 */
static void C_ccall f_18838(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_18838,4,t0,t1,t2,t3);}
t4=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[2]));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18849,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nequalp(t2,t4))){
t6=t5;
f_18849(t6,t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18859,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* substring */
t7=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,((C_word*)t0)[2],t2,t4);}}

/* k18857 in a18837 in irregex-replace/all in k3721 */
static void C_ccall f_18859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18859,2,t0,t1);}
t2=((C_word*)t0)[3];
f_18849(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k18847 in a18837 in irregex-replace/all in k3721 */
static void C_fcall f_18849(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string-cat-reverse */
f_4418(((C_word*)t0)[2],t1);}

/* a18810 in irregex-replace/all in k3721 */
static void C_ccall f_18811(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_18811,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_18815,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* irregex-match-start */
t6=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,C_fix(0));}

/* k18813 in a18810 in irregex-replace/all in k3721 */
static void C_ccall f_18815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18815,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_18822,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* irregex-apply-match */
t3=*((C_word*)lf[284]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k18820 in k18813 in a18810 in irregex-replace/all in k3721 */
static void C_ccall f_18822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18826,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nequalp(((C_word*)t0)[5],((C_word*)t0)[4]))){
t3=t2;
f_18826(t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18836,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* substring */
t4=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k18834 in k18820 in k18813 in a18810 in irregex-replace/all in k3721 */
static void C_ccall f_18836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18836,2,t0,t1);}
t2=((C_word*)t0)[3];
f_18826(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k18824 in k18820 in k18813 in a18810 in irregex-replace/all in k3721 */
static void C_fcall f_18826(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[117]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* irregex-replace in k3721 */
static void C_ccall f_18753(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4r,(void*)f_18753r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_18753r(t0,t1,t2,t3,t4);}}

static void C_ccall f_18753r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(9);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18757,a[2]=t4,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18803,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* irregex */
t7=*((C_word*)lf[169]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k18801 in irregex-replace in k3721 */
static void C_ccall f_18803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* irregex-search */
t2=*((C_word*)lf[231]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k18755 in irregex-replace in k3721 */
static void C_ccall f_18757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18757,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_18771,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18795,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* irregex-match-end */
t4=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_fix(0));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k18793 in k18755 in irregex-replace in k3721 */
static void C_ccall f_18795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[3]));
/* substring */
t3=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],((C_word*)t0)[3],t1,t2);}

/* k18769 in k18755 in irregex-replace in k3721 */
static void C_ccall f_18771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18771,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18775,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18779,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* irregex-apply-match */
t4=*((C_word*)lf[284]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k18777 in k18769 in k18755 in irregex-replace in k3721 */
static void C_ccall f_18779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18779,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18787,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18791,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* irregex-match-start */
t4=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_fix(0));}

/* k18789 in k18777 in k18769 in k18755 in irregex-replace in k3721 */
static void C_ccall f_18791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* substring */
t2=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t1);}

/* k18785 in k18777 in k18769 in k18755 in irregex-replace in k3721 */
static void C_ccall f_18787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18787,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* append */
t3=*((C_word*)lf[117]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k18773 in k18769 in k18755 in irregex-replace in k3721 */
static void C_ccall f_18775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18775,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* string-cat-reverse */
f_4418(((C_word*)t0)[2],t2);}

/* irregex-fold in k3721 */
static void C_ccall f_18640(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr6r,(void*)f_18640r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_18640r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_18640r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word *a=C_alloc(7);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_18644,a[2]=t4,a[3]=t1,a[4]=t3,a[5]=t5,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* irregex */
t8=*((C_word*)lf[169]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k18642 in irregex-fold in k3721 */
static void C_ccall f_18644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18644,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_18647,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* irregex-new-matches */
t3=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k18645 in k18642 in irregex-fold in k3721 */
static void C_ccall f_18647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18647,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[7]);
t3=(C_truep(t2)?(C_word)C_u_i_car(((C_word*)t0)[7]):(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_18750,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_18730,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t5=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t6=t4;
f_18730(t6,(C_word)C_i_pairp(t5));}
else{
t5=t4;
f_18730(t5,C_SCHEME_FALSE);}}

/* k18728 in k18645 in k18642 in irregex-fold in k3721 */
static void C_fcall f_18730(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_18730,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_u_i_cadr(((C_word*)t0)[9]):C_fix(0));
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_18701,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[9]))){
t4=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_u_i_cddr(((C_word*)t0)[9]);
t6=t3;
f_18701(t6,(C_word)C_i_pairp(t5));}
else{
t5=t3;
f_18701(t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_18701(t4,C_SCHEME_FALSE);}}

/* k18699 in k18728 in k18645 in k18642 in irregex-fold in k3721 */
static void C_fcall f_18701(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_18701,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_u_i_caddr(((C_word*)t0)[10]):(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[9])));
t3=((C_word*)t0)[8];
t4=((C_word*)t0)[9];
t5=(C_word)C_i_setslot(t3,C_fix(1),t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_18664,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[8],a[6]=t7,a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t7)[1];
f_18664(t9,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k18699 in k18728 in k18645 in k18642 in irregex-fold in k3721 */
static void C_fcall f_18664(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_18664,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_greater_or_equalp(t2,((C_word*)t0)[8]))){
/* finish3058 */
t4=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_18677,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* irregex-search/matches */
t5=*((C_word*)lf[232]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,((C_word*)t0)[8],((C_word*)t0)[5]);}}

/* k18675 in lp in k18699 in k18728 in k18645 in k18642 in irregex-fold in k3721 */
static void C_ccall f_18677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18677,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_18689,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* irregex-match-end */
t4=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_fix(0));}
else{
/* finish3058 */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[7],((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* k18687 in k18675 in lp in k18699 in k18728 in k18645 in k18642 in irregex-fold in k3721 */
static void C_ccall f_18689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18689,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_18692,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* kons3051 */
t3=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k18690 in k18687 in k18675 in lp in k18699 in k18728 in k18645 in k18642 in irregex-fold in k3721 */
static void C_ccall f_18692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18692,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_18695,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* irregex-reset-matches! */
t3=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k18693 in k18690 in k18687 in k18675 in lp in k18699 in k18728 in k18645 in k18642 in irregex-fold in k3721 */
static void C_ccall f_18695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp3069 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_18664(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_18750 in k18645 in k18642 in irregex-fold in k3721 */
static void C_ccall f_18750(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_18750,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* cset-case-insensitive in k3721 */
static void C_ccall f_18475(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_18475,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18481,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_18481(t6,t1,t2,C_SCHEME_END_OF_LIST);}

/* lp in cset-case-insensitive in k3721 */
static void C_fcall f_18481(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_18481,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* reverse */
t4=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_18497,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_charp(t5))){
t6=(C_word)C_u_i_car(t2);
t7=t4;
f_18497(t7,(C_word)C_u_i_char_alphabeticp(t6));}
else{
t6=t4;
f_18497(t6,C_SCHEME_FALSE);}}}

/* k18495 in lp in cset-case-insensitive in k3721 */
static void C_fcall f_18497(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_18497,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_u_i_char_upper_casep(t2);
t4=(C_truep(t3)?(C_word)C_u_i_char_downcase(t2):(C_word)C_u_i_char_upcase(t2));
t5=(C_word)C_u_i_car(((C_word*)t0)[5]);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[4]);
t7=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_18517,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* cset-contains? */
f_17944(t8,t6,t4);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_18534,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_caar(((C_word*)t0)[5]);
if(C_truep((C_word)C_u_i_char_alphabeticp(t4))){
t5=(C_word)C_u_i_cdar(((C_word*)t0)[5]);
t6=t2;
f_18534(t6,(C_word)C_u_i_char_alphabeticp(t5));}
else{
t5=t2;
f_18534(t5,C_SCHEME_FALSE);}}
else{
t4=t2;
f_18534(t4,C_SCHEME_FALSE);}}}

/* k18532 in k18495 in lp in cset-case-insensitive in k3721 */
static void C_fcall f_18534(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_18534,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18545,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18549,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_u_i_car(((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,1,t5);
/* cset-union */
t7=lf[276];
f_18139(4,t7,t4,((C_word*)t0)[2],t6);}
else{
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18592,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_i_car(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,1,t4);
/* cset-union */
t6=lf[276];
f_18139(4,t6,t3,((C_word*)t0)[2],t5);}}

/* k18590 in k18532 in k18495 in lp in cset-case-insensitive in k3721 */
static void C_ccall f_18592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp3031 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_18481(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k18547 in k18532 in k18495 in lp in cset-case-insensitive in k3721 */
static void C_ccall f_18549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18549,2,t0,t1);}
t2=(C_word)C_u_i_caar(((C_word*)t0)[3]);
t3=(C_word)C_u_i_char_upper_casep(t2);
t4=(C_truep(t3)?(C_word)C_u_i_char_downcase(t2):(C_word)C_u_i_char_upcase(t2));
t5=(C_word)C_u_i_cdar(((C_word*)t0)[3]);
t6=(C_word)C_u_i_char_upper_casep(t5);
t7=(C_truep(t6)?(C_word)C_u_i_char_downcase(t5):(C_word)C_u_i_char_upcase(t5));
t8=(C_word)C_a_i_cons(&a,2,t4,t7);
t9=(C_word)C_a_i_list(&a,1,t8);
/* cset-union */
t10=lf[276];
f_18139(4,t10,((C_word*)t0)[2],t1,t9);}

/* k18543 in k18532 in k18495 in lp in cset-case-insensitive in k3721 */
static void C_ccall f_18545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp3031 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_18481(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k18515 in k18495 in lp in cset-case-insensitive in k3721 */
static void C_ccall f_18517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18517,2,t0,t1);}
t2=(C_truep(t1)?((C_word*)t0)[6]:(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]));
/* lp3031 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_18481(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* cset-complement in k3721 */
static void C_fcall f_18465(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_18465,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18473,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* sre->cset */
f_17663(t3,lf[26],C_SCHEME_END_OF_LIST);}

/* k18471 in cset-complement in k3721 */
static void C_ccall f_18473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* cset-difference */
f_18226(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* cset-intersection in k3721 */
static void C_ccall f_18347(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_18347,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18353,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_18353(t7,t1,t2,t3,C_SCHEME_END_OF_LIST);}

/* intersect in cset-intersection in k3721 */
static void C_fcall f_18353(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_18353,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t3))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_18363,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18455,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* find-tail */
f_4569(t5,t6,t2);}}

/* a18454 in intersect in cset-intersection in k3721 */
static void C_ccall f_18455(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_18455,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(((C_word*)t0)[2]);
/* char-ranges-overlap? */
f_17994(t1,t2,t3);}

/* k18361 in intersect in cset-intersection in k3721 */
static void C_ccall f_18363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18363,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_18371,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18430,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_i_car(t1);
t5=(C_word)C_charp(t4);
t6=(C_truep(t5)?(C_word)C_a_i_cons(&a,2,t4,t4):t4);
t7=(C_word)C_u_i_car(((C_word*)t0)[4]);
t8=(C_word)C_charp(t7);
t9=(C_truep(t8)?(C_word)C_a_i_cons(&a,2,t7,t7):t7);
/* intersect-char-ranges */
f_14985(t3,t6,t9);}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* intersect3001 */
t3=((C_word*)((C_word*)t0)[6])[1];
f_18353(t3,((C_word*)t0)[2],((C_word*)t0)[3],t2,((C_word*)t0)[5]);}}

/* k18428 in k18361 in intersect in cset-intersection in k3721 */
static void C_ccall f_18430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a18370 in k18361 in intersect in cset-intersection in k3721 */
static void C_ccall f_18371(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_18371,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_18375,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t6,a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=t3,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18422,a[2]=t7,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* take-up-to */
f_4514(t8,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k18420 in a18370 in k18361 in intersect in cset-intersection in k3721 */
static void C_ccall f_18422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* append */
t3=*((C_word*)lf[117]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k18373 in a18370 in k18361 in intersect in cset-intersection in k3721 */
static void C_ccall f_18375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18375,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[10])?(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1):t1);
t3=(C_truep(((C_word*)t0)[9])?(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2):t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_18384,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
/* cset-union */
t6=lf[276];
f_18139(4,t6,t4,((C_word*)t0)[2],t5);}
else{
t5=t4;
f_18384(2,t5,((C_word*)t0)[2]);}}

/* k18382 in k18373 in a18370 in k18361 in intersect in cset-intersection in k3721 */
static void C_ccall f_18384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_18387,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* cset-union */
t4=lf[276];
f_18139(4,t4,t2,t1,t3);}
else{
t3=t2;
f_18387(2,t3,t1);}}

/* k18385 in k18382 in k18373 in a18370 in k18361 in intersect in cset-intersection in k3721 */
static void C_ccall f_18387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_18394,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
/* cset-union */
t4=lf[276];
f_18139(4,t4,t2,((C_word*)t0)[2],t3);}

/* k18392 in k18385 in k18382 in k18373 in a18370 in k18361 in intersect in cset-intersection in k3721 */
static void C_ccall f_18394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* intersect3001 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_18353(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* cset-difference in k3721 */
static void C_fcall f_18226(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_18226,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
if(C_truep((C_word)C_u_i_car(t3))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18249,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18333,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* find-tail */
f_4569(t4,t5,t2);}
else{
t4=(C_word)C_slot(t3,C_fix(1));
/* cset-difference */
t8=t1;
t9=t2;
t10=t4;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}

/* a18332 in cset-difference in k3721 */
static void C_ccall f_18333(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_18333,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(((C_word*)t0)[2]);
/* char-ranges-overlap? */
f_17994(t1,t2,t3);}

/* k18247 in cset-difference in k3721 */
static void C_ccall f_18249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18249,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18257,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18308,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_i_car(t1);
t5=(C_word)C_charp(t4);
t6=(C_truep(t5)?(C_word)C_a_i_cons(&a,2,t4,t4):t4);
t7=(C_word)C_u_i_car(((C_word*)t0)[4]);
t8=(C_word)C_charp(t7);
t9=(C_truep(t8)?(C_word)C_a_i_cons(&a,2,t7,t7):t7);
/* intersect-char-ranges */
f_14985(t3,t6,t9);}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* cset-difference */
f_18226(((C_word*)t0)[2],((C_word*)t0)[3],t2);}}

/* k18306 in k18247 in cset-difference in k3721 */
static void C_ccall f_18308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a18256 in k18247 in cset-difference in k3721 */
static void C_ccall f_18257(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_18257,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_18261,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t6,a[5]=t1,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18300,a[2]=t7,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* take-up-to */
f_4514(t8,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k18298 in a18256 in k18247 in cset-difference in k3721 */
static void C_ccall f_18300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* append */
t3=*((C_word*)lf[117]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k18259 in a18256 in k18247 in cset-difference in k3721 */
static void C_ccall f_18261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18261,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[7])?(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1):t1);
t3=(C_truep(((C_word*)t0)[6])?(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2):t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18270,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
/* cset-union */
t6=lf[276];
f_18139(4,t6,t4,((C_word*)t0)[2],t5);}
else{
t5=t4;
f_18270(2,t5,((C_word*)t0)[2]);}}

/* k18268 in k18259 in a18256 in k18247 in cset-difference in k3721 */
static void C_ccall f_18270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18270,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18273,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* cset-union */
t4=lf[276];
f_18139(4,t4,t2,t1,t3);}
else{
t3=t2;
f_18273(2,t3,t1);}}

/* k18271 in k18268 in k18259 in a18256 in k18247 in cset-difference in k3721 */
static void C_ccall f_18273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* cset-difference */
f_18226(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* cset-union in k3721 */
static void C_ccall f_18139(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_18139,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18149,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18216,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* find-tail */
f_4569(t4,t5,t2);}}

/* a18215 in cset-union in k3721 */
static void C_ccall f_18216(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_18216,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(((C_word*)t0)[2]);
/* char-ranges-overlap? */
f_17994(t1,t2,t3);}

/* k18147 in cset-union in k3721 */
static void C_ccall f_18149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18149,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18159,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18167,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18195,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* take-up-to */
f_4514(t4,((C_word*)t0)[2],t1);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[2]);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* cset-union */
t5=lf[276];
f_18139(4,t5,((C_word*)t0)[3],t3,t4);}}

/* k18193 in k18147 in cset-union in k3721 */
static void C_ccall f_18195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* append */
t3=*((C_word*)lf[117]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k18165 in k18147 in cset-union in k3721 */
static void C_ccall f_18167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18167,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
t3=(C_word)C_charp(t2);
t4=(C_truep(t3)?(C_word)C_a_i_cons(&a,2,t2,t2):t2);
t5=(C_word)C_u_i_car(((C_word*)t0)[3]);
t6=(C_word)C_charp(t5);
t7=(C_truep(t6)?(C_word)C_a_i_cons(&a,2,t5,t5):t5);
t8=(C_word)C_u_i_car(t4);
t9=(C_word)C_u_i_car(t7);
t10=(C_word)C_fixnum_less_or_equal_p(t8,t9);
t11=(C_truep(t10)?(C_word)C_u_i_car(t4):(C_word)C_u_i_car(t7));
t12=(C_word)C_slot(t4,C_fix(1));
t13=(C_word)C_slot(t7,C_fix(1));
t14=(C_word)C_fixnum_greater_or_equal_p(t12,t13);
t15=(C_truep(t14)?(C_word)C_slot(t4,C_fix(1)):(C_word)C_slot(t7,C_fix(1)));
t16=(C_word)C_a_i_cons(&a,2,t11,t15);
t17=(C_word)C_a_i_list(&a,1,t16);
/* cset-union */
t18=lf[276];
f_18139(4,t18,((C_word*)t0)[2],t1,t17);}

/* k18157 in k18147 in cset-union in k3721 */
static void C_ccall f_18159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* cset-union */
t3=lf[276];
f_18139(4,t3,((C_word*)t0)[2],t1,t2);}

/* char-ranges-overlap? in k3721 */
static void C_fcall f_17994(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_17994,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18010,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_fixnum_less_or_equal_p(t5,t6))){
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t2,C_fix(1));
t9=t4;
f_18010(t9,(C_word)C_fixnum_less_or_equal_p(t7,t8));}
else{
t7=t4;
f_18010(t7,C_SCHEME_FALSE);}}
else{
t4=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t4,t3))){
t5=(C_word)C_slot(t2,C_fix(1));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_fixnum_less_or_equal_p(t3,t5));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}}
else{
if(C_truep((C_word)C_i_pairp(t3))){
/* char-ranges-overlap? */
t12=t1;
t13=t3;
t14=t2;
t1=t12;
t2=t13;
t3=t14;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_eqvp(t2,t3));}}}

/* k18008 in char-ranges-overlap? in k3721 */
static void C_fcall f_18010(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_word)C_u_i_car(((C_word*)t0)[2]);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,t3))){
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t5=(C_word)C_u_i_car(((C_word*)t0)[3]);
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_fixnum_less_or_equal_p(t4,t5));}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* cset-contains? in k3721 */
static void C_fcall f_17944(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_17944,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_17950,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* find */
f_4557(t1,t4,t2);}

/* a17949 in cset-contains? in k3721 */
static void C_ccall f_17950(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_17950,3,t0,t1,t2);}
t3=(C_word)C_i_eqvp(t2,((C_word*)t0)[2]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t4,((C_word*)t0)[2]))){
t5=(C_word)C_slot(t2,C_fix(1));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],t5));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* sre->cset in k3721 */
static void C_fcall f_17663(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_17663,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_pairp(t3);
t5=(C_truep(t4)?(C_word)C_u_i_car(t3):C_SCHEME_FALSE);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_17673,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_17673(t9,t1,t2,t5);}

/* lp in sre->cset in k3721 */
static void C_fcall f_17673(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word *a;
loop:
a=C_alloc(16);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_17673,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17676,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_stringp(t5))){
if(C_truep(t3)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_17702,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_u_i_car(t2);
/* string->list */
t8=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
t6=(C_word)C_u_i_car(t2);
/* string->list */
t7=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t6);}}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_eqp(t6,lf[116]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_17729,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17733,a[2]=t4,a[3]=t2,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=(C_word)C_u_i_cadr(t2);
/* rec2914 */
t11=t4;
f_17676(3,t11,t9,t10);}
else{
t8=(C_word)C_eqp(t6,lf[183]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17758,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t10=(C_word)C_u_i_cadr(t2);
/* rec2914 */
t11=t4;
f_17676(3,t11,t9,t10);}
else{
t9=(C_word)C_eqp(t6,lf[194]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17781,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_17789,a[2]=t4,a[3]=t2,a[4]=t10,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t12=(C_word)C_u_i_cadr(t2);
/* rec2914 */
t13=t4;
f_17676(3,t13,t11,t12);}
else{
t10=(C_word)C_eqp(t6,lf[25]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17810,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_17820,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
t13=(C_word)C_slot(t2,C_fix(1));
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12421,a[2]=t15,tmp=(C_word)a,a+=3,tmp));
t17=((C_word*)t15)[1];
f_12421(t17,t12,t13,C_SCHEME_END_OF_LIST);}
else{
t11=(C_word)C_eqp(t6,lf[62]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17837,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t13=(C_word)C_u_i_cadr(t2);
/* rec2914 */
t14=t4;
f_17676(3,t14,t12,t13);}
else{
t12=(C_word)C_eqp(t6,lf[174]);
if(C_truep(t12)){
t13=(C_word)C_slot(t2,C_fix(1));
t14=f_12337(C_a_i(&a,3),t13);
/* lp2905 */
t43=t1;
t44=t14;
t45=C_SCHEME_FALSE;
t1=t43;
t2=t44;
t3=t45;
goto loop;}
else{
t13=(C_word)C_eqp(t6,lf[175]);
if(C_truep(t13)){
t14=(C_word)C_slot(t2,C_fix(1));
t15=f_12337(C_a_i(&a,3),t14);
/* lp2905 */
t43=t1;
t44=t15;
t45=C_SCHEME_TRUE;
t1=t43;
t2=t44;
t3=t45;
goto loop;}
else{
/* error */
t14=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[279],t2);}}}}}}}}}
else{
if(C_truep((C_word)C_charp(t2))){
t5=(C_word)C_a_i_string(&a,1,t2);
t6=(C_word)C_a_i_list(&a,1,t5);
/* rec2914 */
t7=t4;
f_17676(3,t7,t1,t6);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t5=(C_word)C_a_i_list(&a,1,t2);
/* rec2914 */
t6=t4;
f_17676(3,t6,t1,t5);}
else{
t5=(C_word)C_u_i_assq(t2,lf[195]);
if(C_truep(t5)){
t6=(C_word)C_slot(t5,C_fix(1));
/* rec2914 */
t7=t4;
f_17676(3,t7,t1,t6);}
else{
/* error */
t6=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,lf[280],t2);}}}}}

/* k17835 in lp in sre->cset in k3721 */
static void C_ccall f_17837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17841,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k17839 in k17835 in lp in sre->cset in k3721 */
static void C_ccall f_17841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* fold */
f_4741(((C_word*)t0)[3],lf[276],((C_word*)t0)[2],t1);}

/* lp in lp in sre->cset in k3721 */
static void C_fcall f_12421(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_12421,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* reverse */
t4=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_stringp(t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12444,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12448,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_u_i_car(t2);
/* string->list */
t8=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
/* lp1723 */
t12=t1;
t13=t5;
t14=t7;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}}

/* k12446 in lp in lp in sre->cset in k3721 */
static void C_ccall f_12448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* append */
t3=*((C_word*)lf[117]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k12442 in lp in lp in sre->cset in k3721 */
static void C_ccall f_12444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp1723 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_12421(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k17818 in lp in sre->cset in k3721 */
static void C_ccall f_17820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17820,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_17587,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_17587(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* lp in k17818 in lp in sre->cset in k3721 */
static void C_fcall f_17587(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_17587,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* reverse */
t4=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_u_i_cddr(t2);
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_u_i_cadr(t2);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
/* lp2892 */
t10=t1;
t11=t4;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* k17808 in lp in sre->cset in k3721 */
static void C_ccall f_17810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[3])){
/* cset-case-insensitive */
t2=lf[118];
f_18475(3,t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* k17787 in lp in sre->cset in k3721 */
static void C_ccall f_17789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17789,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17793,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k17791 in k17787 in lp in sre->cset in k3721 */
static void C_ccall f_17793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* fold */
f_4741(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a17780 in lp in sre->cset in k3721 */
static void C_ccall f_17781(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_17781,4,t0,t1,t2,t3);}
/* cset-difference */
f_18226(t1,t3,t2);}

/* k17756 in lp in sre->cset in k3721 */
static void C_ccall f_17758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17758,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17762,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k17760 in k17756 in lp in sre->cset in k3721 */
static void C_ccall f_17762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* fold */
f_4741(((C_word*)t0)[3],lf[277],((C_word*)t0)[2],t1);}

/* k17731 in lp in sre->cset in k3721 */
static void C_ccall f_17733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17737,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k17735 in k17731 in lp in sre->cset in k3721 */
static void C_ccall f_17737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* fold */
f_4741(((C_word*)t0)[3],lf[276],((C_word*)t0)[2],t1);}

/* k17727 in lp in sre->cset in k3721 */
static void C_ccall f_17729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* cset-complement */
f_18465(((C_word*)t0)[2],t1);}

/* k17700 in lp in sre->cset in k3721 */
static void C_ccall f_17702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* cset-case-insensitive */
t2=lf[118];
f_18475(3,t2,((C_word*)t0)[2],t1);}

/* rec in lp in sre->cset in k3721 */
static void C_ccall f_17676(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_17676,3,t0,t1,t2);}
/* lp2905 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_17673(t3,t1,t2,((C_word*)t0)[2]);}

/* sre-cset->procedure in k3721 */
static void C_fcall f_17546(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_17546,NULL,3,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17548,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp));}

/* f_17548 in sre-cset->procedure in k3721 */
static void C_ccall f_17548(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17548,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_17555,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_fix((C_word)C_header_size(t2));
if(C_truep((C_word)C_i_lessp(t3,t7))){
t8=(C_word)C_subchar(t2,t3);
/* cset-contains? */
f_17944(t6,((C_word*)t0)[2],t8);}
else{
t8=t6;
f_17555(2,t8,C_SCHEME_FALSE);}}

/* k17553 */
static void C_ccall f_17555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17555,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
/* next2883 */
t3=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail2887 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}

/* insert-sorted in k3721 */
static void C_fcall f_15182(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_15182,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}
else{
t4=(C_word)C_u_i_car(t3);
if(C_truep((C_word)C_i_less_or_equalp(t2,t4))){
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_i_nequalp(t2,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t3:(C_word)C_a_i_cons(&a,2,t2,t3)));}
else{
t5=(C_word)C_u_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15222,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t3,C_fix(1));
/* insert-sorted */
t11=t6;
t12=t2;
t13=t7;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}}

/* k15220 in insert-sorted in k3721 */
static void C_ccall f_15222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15222,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* nfa-closure in k3721 */
static void C_fcall f_15101(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15101,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15107,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_15107(t7,t1,t3,C_SCHEME_END_OF_LIST);}

/* lp in nfa-closure in k3721 */
static void C_fcall f_15107(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(15);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_15107,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_memv(t4,t3))){
t5=(C_word)C_slot(t2,C_fix(1));
/* lp2348 */
t14=t1;
t15=t5;
t16=t3;
t1=t14;
t2=t15;
t3=t16;
goto loop;}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15134,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15146,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15154,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15156,tmp=(C_word)a,a+=2,tmp);
t9=(C_word)C_u_i_car(t2);
t10=(C_word)C_i_assv(t9,((C_word*)t0)[2]);
t11=(C_word)C_slot(t10,C_fix(1));
/* filter */
f_4771(t7,t8,t11);}}}

/* a15155 in lp in nfa-closure in k3721 */
static void C_ccall f_15156(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_15156,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[75],t3));}

/* k15152 in lp in nfa-closure in k3721 */
static void C_ccall f_15154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[269]+1),t1);}

/* k15144 in lp in nfa-closure in k3721 */
static void C_ccall f_15146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* append */
t3=*((C_word*)lf[117]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k15132 in lp in nfa-closure in k3721 */
static void C_ccall f_15134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15134,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15138,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[3]);
/* insert-sorted */
f_15182(t2,t3,((C_word*)t0)[2]);}

/* k15136 in k15132 in lp in nfa-closure in k3721 */
static void C_ccall f_15138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2348 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_15107(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* intersect-char-ranges in k3721 */
static void C_fcall f_14985(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(13);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_14985,NULL,3,t1,t2,t3);}
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_u_i_car(t3);
if(C_truep((C_word)C_fixnum_greaterp(t4,t5))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14999,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* intersect-char-ranges */
t17=t6;
t18=t3;
t19=t2;
t1=t17;
t2=t18;
t3=t19;
goto loop;}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15018,a[2]=t1,a[3]=t8,a[4]=t7,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t6,t8))){
t11=(C_word)C_fix((C_word)C_character_code(t8));
t12=(C_word)C_a_i_minus(&a,2,t11,C_fix(1));
t13=(C_word)C_make_character((C_word)C_unfix(t12));
t14=(C_word)C_i_eqvp(t6,t13);
t15=t10;
f_15018(t15,(C_truep(t14)?t6:(C_word)C_a_i_cons(&a,2,t6,t13)));}
else{
t11=t10;
f_15018(t11,C_SCHEME_FALSE);}}}

/* k15016 in intersect-char-ranges in k3721 */
static void C_fcall f_15018(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15018,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15022,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[4],((C_word*)t0)[5]))){
t3=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[5]));
t4=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t5=(C_word)C_make_character((C_word)C_unfix(t4));
t6=(C_word)C_i_eqvp(t5,((C_word*)t0)[4]);
t7=t2;
f_15022(t7,(C_truep(t6)?t5:(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[4])));}
else{
t3=t2;
f_15022(t3,C_SCHEME_FALSE);}}

/* k15020 in k15016 in intersect-char-ranges in k3721 */
static void C_fcall f_15022(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15022,NULL,2,t0,t1);}
t2=(C_word)C_fixnum_lessp(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_truep(t2)?((C_word*)t0)[6]:((C_word*)t0)[5]);
t4=(C_word)C_i_eqvp(((C_word*)t0)[4],t3);
t5=(C_truep(t4)?((C_word*)t0)[4]:(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15030,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[6],((C_word*)t0)[5]))){
t7=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[5]));
t8=(C_word)C_a_i_plus(&a,2,t7,C_fix(1));
t9=(C_word)C_make_character((C_word)C_unfix(t8));
t10=(C_word)C_i_eqvp(t9,((C_word*)t0)[6]);
t11=t6;
f_15030(t11,(C_truep(t10)?t9:(C_word)C_a_i_cons(&a,2,t9,((C_word*)t0)[6])));}
else{
t7=t6;
f_15030(t7,C_SCHEME_FALSE);}}

/* k15028 in k15020 in k15016 in intersect-char-ranges in k3721 */
static void C_fcall f_15030(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15030,NULL,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,t1));}

/* k14997 in intersect-char-ranges in k3721 */
static void C_ccall f_14999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* reverse */
t2=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* split-char-range in k3721 */
static void C_fcall f_14911(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14911,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14919,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_eqvp(t3,t5))){
t6=t4;
f_14919(t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_fix((C_word)C_character_code(t3));
t8=(C_word)C_a_i_minus(&a,2,t7,C_fix(1));
t9=(C_word)C_make_character((C_word)C_unfix(t8));
t10=(C_word)C_i_eqvp(t6,t9);
t11=t4;
f_14919(t11,(C_truep(t10)?t6:(C_word)C_a_i_cons(&a,2,t6,t9)));}}

/* k14917 in split-char-range in k3721 */
static void C_fcall f_14919(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14919,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14923,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
if(C_truep((C_word)C_i_eqvp(((C_word*)t0)[2],t3))){
t4=t2;
f_14923(t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[2]));
t5=(C_word)C_a_i_plus(&a,2,t4,C_fix(1));
t6=(C_word)C_make_character((C_word)C_unfix(t5));
t7=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t8=(C_word)C_i_eqvp(t6,t7);
t9=t2;
f_14923(t9,(C_truep(t8)?t6:(C_word)C_a_i_cons(&a,2,t6,t7)));}}

/* k14921 in k14917 in split-char-range in k3721 */
static void C_fcall f_14923(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14923,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* nfa-join-transitions! in k3721 */
static void C_fcall f_14437(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14437,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14440,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_u_i_car(t3);
if(C_truep((C_word)C_charp(t5))){
t6=(C_word)C_u_i_car(t3);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14468,a[2]=t8,a[3]=t2,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_14468(t10,t1,t2,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_u_i_caar(t3);
t7=(C_word)C_u_i_cdar(t3);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_14646,a[2]=t6,a[3]=t7,a[4]=t9,a[5]=t4,a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp));
t11=((C_word*)t9)[1];
f_14646(t11,t1,t2,C_SCHEME_END_OF_LIST);}}

/* lp in nfa-join-transitions! in k3721 */
static void C_fcall f_14646(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14646,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
t5=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t6=(C_word)C_a_i_list(&a,2,t4,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[6]));}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_14674,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[7],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t5=(C_word)C_u_i_caar(t2);
if(C_truep((C_word)C_charp(t5))){
t6=(C_word)C_u_i_caar(t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],t6))){
t7=(C_word)C_u_i_caar(t2);
t8=t4;
f_14674(t8,(C_word)C_fixnum_less_or_equal_p(t7,((C_word*)t0)[3]));}
else{
t7=t4;
f_14674(t7,C_SCHEME_FALSE);}}
else{
t6=t4;
f_14674(t6,C_SCHEME_FALSE);}}}

/* k14672 in lp in nfa-join-transitions! in k3721 */
static void C_fcall f_14674(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14674,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14679,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14718,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_i_car(((C_word*)t0)[9]);
t5=(C_word)C_u_i_caar(((C_word*)t0)[10]);
/* split-char-range */
f_14911(t3,t4,t5);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_14732,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_u_i_caar(((C_word*)t0)[10]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14831,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[10],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_caaar(((C_word*)t0)[10]);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t5,((C_word*)t0)[3]))){
t6=(C_word)C_u_i_cdaar(((C_word*)t0)[10]);
t7=t4;
f_14831(t7,(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],t6));}
else{
t6=t4;
f_14831(t6,C_SCHEME_FALSE);}}
else{
t4=t2;
f_14732(t4,C_SCHEME_FALSE);}}}

/* k14829 in k14672 in lp in nfa-join-transitions! in k3721 */
static void C_fcall f_14831(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_14732(t2,t1);}
else{
t2=(C_word)C_u_i_caaar(((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[3],t2))){
t3=(C_word)C_u_i_cdaar(((C_word*)t0)[4]);
t4=((C_word*)t0)[5];
f_14732(t4,(C_word)C_fixnum_less_or_equal_p(t3,((C_word*)t0)[2]));}
else{
t3=((C_word*)t0)[5];
f_14732(t3,C_SCHEME_FALSE);}}}

/* k14730 in k14672 in lp in nfa-join-transitions! in k3721 */
static void C_fcall f_14732(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14732,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14737,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14802,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
t5=(C_word)C_u_i_caar(((C_word*)t0)[8]);
/* intersect-char-ranges */
f_14985(t3,t4,t5);}
else{
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t3=(C_word)C_u_i_car(((C_word*)t0)[8]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
/* lp2282 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_14646(t5,((C_word*)t0)[4],t2,t4);}}

/* k14800 in k14730 in k14672 in lp in nfa-join-transitions! in k3721 */
static void C_ccall f_14802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a14736 in k14730 in k14672 in lp in nfa-join-transitions! in k3721 */
static void C_ccall f_14737(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_14737,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_u_i_cdar(((C_word*)t0)[5]);
t8=(C_word)C_u_i_car(((C_word*)t0)[5]);
t9=(C_word)C_i_setslot(t8,C_fix(0),t4);
t10=(C_word)C_u_i_car(((C_word*)t0)[5]);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_14790,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t7,a[5]=t6,a[6]=t2,a[7]=t3,a[8]=t1,a[9]=((C_word*)t0)[3],a[10]=((C_word*)t0)[4],a[11]=t10,tmp=(C_word)a,a+=12,tmp);
t12=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* insert-sorted */
f_15182(t11,t12,t7);}

/* k14788 in a14736 in k14730 in k14672 in lp in nfa-join-transitions! in k3721 */
static void C_ccall f_14790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14790,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[11],C_fix(1),t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_14750,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
t5=t3;
f_14750(t5,(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[2]));}
else{
t4=t3;
f_14750(t4,((C_word*)t0)[2]);}}

/* k14748 in k14788 in a14736 in k14730 in k14672 in lp in nfa-join-transitions! in k3721 */
static void C_fcall f_14750(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14750,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14753,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t4=t2;
f_14753(t4,(C_word)C_a_i_cons(&a,2,t3,t1));}
else{
t3=t2;
f_14753(t3,t1);}}

/* k14751 in k14748 in k14788 in a14736 in k14730 in k14672 in lp in nfa-join-transitions! in k3721 */
static void C_fcall f_14753(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14753,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14760,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* join2258 */
f_14440(t2,t1,((C_word*)t0)[2],t3);}

/* k14758 in k14751 in k14748 in k14788 in a14736 in k14730 in k14672 in lp in nfa-join-transitions! in k3721 */
static void C_ccall f_14760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* join2258 */
f_14440(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2);}

/* k14716 in k14672 in lp in nfa-join-transitions! in k3721 */
static void C_ccall f_14718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a14678 in k14672 in lp in nfa-join-transitions! in k3721 */
static void C_ccall f_14679(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_14679,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_car(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_14706,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t4,tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t7=(C_word)C_u_i_cdar(((C_word*)t0)[5]);
/* insert-sorted */
f_15182(t5,t6,t7);}

/* k14704 in a14678 in k14672 in lp in nfa-join-transitions! in k3721 */
static void C_ccall f_14706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14706,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[8],C_fix(1),t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14690,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* join2258 */
f_14440(t3,((C_word*)t0)[3],((C_word*)t0)[2],t4);}

/* k14688 in k14704 in a14678 in k14672 in lp in nfa-join-transitions! in k3721 */
static void C_ccall f_14690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* join2258 */
f_14440(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2);}

/* lp in nfa-join-transitions! in k3721 */
static void C_fcall f_14468(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14468,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]));}
else{
t4=(C_word)C_u_i_caar(t2);
if(C_truep((C_word)C_i_eqvp(((C_word*)t0)[4],t4))){
t5=(C_word)C_u_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14503,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t8=(C_word)C_u_i_cdar(t2);
/* insert-sorted */
f_15182(t6,t7,t8);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_14517,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_u_i_caar(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_u_i_caaar(t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t7,((C_word*)t0)[4]))){
t8=(C_word)C_u_i_cdaar(t2);
t9=t5;
f_14517(t9,(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[4],t8));}
else{
t8=t5;
f_14517(t8,C_SCHEME_FALSE);}}
else{
t7=t5;
f_14517(t7,C_SCHEME_FALSE);}}}}

/* k14515 in lp in nfa-join-transitions! in k3721 */
static void C_fcall f_14517(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14517,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14522,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14584,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_i_caar(((C_word*)t0)[6]);
t5=(C_word)C_u_i_car(((C_word*)t0)[4]);
/* split-char-range */
f_14911(t3,t4,t5);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_u_i_car(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[5]);
/* lp2263 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_14468(t5,((C_word*)t0)[3],t2,t4);}}

/* k14582 in k14515 in lp in nfa-join-transitions! in k3721 */
static void C_ccall f_14584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a14521 in k14515 in lp in nfa-join-transitions! in k3721 */
static void C_ccall f_14522(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_14522,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_14572,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t6=(C_word)C_u_i_cdar(((C_word*)t0)[4]);
/* insert-sorted */
f_15182(t4,t5,t6);}

/* k14570 in a14521 in k14515 in lp in nfa-join-transitions! in k3721 */
static void C_ccall f_14572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14572,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14534,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14538,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t5=(C_word)C_u_i_cdar(((C_word*)t0)[5]);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5);
t7=t4;
f_14538(t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t5=t4;
f_14538(t5,C_SCHEME_END_OF_LIST);}}

/* k14536 in k14570 in a14521 in k14515 in lp in nfa-join-transitions! in k3721 */
static void C_fcall f_14538(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14538,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14542,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_u_i_cdar(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
t5=t2;
f_14542(t5,(C_word)C_a_i_list(&a,1,t4));}
else{
t3=t2;
f_14542(t3,C_SCHEME_END_OF_LIST);}}

/* k14540 in k14536 in k14570 in a14521 in k14515 in lp in nfa-join-transitions! in k3721 */
static void C_fcall f_14542(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* append */
t3=*((C_word*)lf[117]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],t2);}

/* k14532 in k14570 in a14521 in k14515 in lp in nfa-join-transitions! in k3721 */
static void C_ccall f_14534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14534,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k14501 in lp in nfa-join-transitions! in k3721 */
static void C_ccall f_14503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(1),t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* join in nfa-join-transitions! in k3721 */
static void C_fcall f_14440(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14440,NULL,4,t1,t2,t3,t4);}
t5=t3;
if(C_truep(t5)){
t6=(C_word)C_a_i_cons(&a,2,t3,t4);
/* nfa-join-transitions! */
f_14437(t1,t2,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}}

/* nfa->dfa in k3721 */
static void C_fcall f_14140(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14140,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_pairp(t3);
t5=(C_truep(t4)?(C_word)C_u_i_car(t3):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14255,a[2]=t1,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_u_i_caar(t2);
t8=(C_word)C_a_i_list(&a,1,t7);
/* nfa-closure */
f_15101(t6,t2,t8);}

/* k14253 in nfa->dfa in k3721 */
static void C_ccall f_14255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14255,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14153,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_14153(t6,((C_word*)t0)[2],t2,C_fix(0),C_SCHEME_END_OF_LIST);}

/* lp in k14253 in nfa->dfa in k3721 */
static void C_fcall f_14153(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(15);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_14153,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14167,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* reverse */
t6=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}
else{
t5=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_assoc(t5,t4))){
t6=(C_word)C_slot(t2,C_fix(1));
/* lp2197 */
t15=t1;
t16=t6;
t17=t3;
t18=t4;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
goto loop;}
else{
t6=(C_word)C_u_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_14186,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[3],a[8]=t6,tmp=(C_word)a,a+=9,tmp);
t8=((C_word*)t0)[2];
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14348,a[2]=t10,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t12=((C_word*)t10)[1];
f_14348(t12,t7,C_SCHEME_END_OF_LIST,t6,C_SCHEME_END_OF_LIST);}}}

/* lp in lp in k14253 in nfa->dfa in k3721 */
static void C_fcall f_14348(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_14348,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(t3))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14366,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,t4);}
else{
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_i_assv(t5,((C_word*)t0)[3]);
t7=(C_truep(t6)?(C_word)C_slot(t6,C_fix(1)):C_SCHEME_END_OF_LIST);
t8=(C_word)C_slot(t3,C_fix(1));
/* lp2236 */
t17=t1;
t18=t7;
t19=t8;
t20=t4;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}}
else{
t5=(C_word)C_u_i_caar(t2);
t6=(C_word)C_eqp(lf[75],t5);
if(C_truep(t6)){
t7=(C_word)C_slot(t2,C_fix(1));
/* lp2236 */
t17=t1;
t18=t7;
t19=t3;
t20=t4;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}
else{
t7=(C_word)C_slot(t2,C_fix(1));
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14427,a[2]=t3,a[3]=t7,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_u_i_car(t2);
/* nfa-join-transitions! */
f_14437(t8,t4,t9);}}}

/* k14425 in lp in lp in k14253 in nfa->dfa in k3721 */
static void C_ccall f_14427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2236 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_14348(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a14365 in lp in lp in k14253 in nfa->dfa in k3721 */
static void C_ccall f_14366(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14366,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14378,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
/* nfa-closure */
f_15101(t4,((C_word*)t0)[2],t5);}

/* k14376 in a14365 in lp in lp in k14253 in nfa->dfa in k3721 */
static void C_ccall f_14378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14378,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k14184 in lp in k14253 in nfa->dfa in k3721 */
static void C_ccall f_14186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14186,2,t0,t1);}
t2=(C_word)C_i_memv(C_fix(0),((C_word*)t0)[8]);
t3=(C_truep(t2)?C_SCHEME_TRUE:C_SCHEME_FALSE);
t4=(C_word)C_i_not(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_14198,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=t3,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t4)){
t6=t5;
f_14198(t6,t4);}
else{
t6=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(1));
t7=t5;
f_14198(t7,(C_word)C_i_lessp(t6,((C_word*)t0)[7]));}}

/* k14196 in k14184 in lp in k14253 in nfa->dfa in k3721 */
static void C_fcall f_14198(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14198,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_14205,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14233,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[269]+1),((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k14231 in k14196 in k14184 in lp in k14253 in nfa->dfa in k3721 */
static void C_ccall f_14233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* append */
t3=*((C_word*)lf[117]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k14203 in k14196 in k14184 in lp in k14253 in nfa->dfa in k3721 */
static void C_ccall f_14205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14205,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[8],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_14229,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* ##sys#append */
t4=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k14227 in k14203 in k14196 in k14184 in lp in k14253 in nfa->dfa in k3721 */
static void C_ccall f_14229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14229,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14221,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* ##sys#append */
t5=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k14219 in k14227 in k14203 in k14196 in k14184 in lp in k14253 in nfa->dfa in k3721 */
static void C_ccall f_14221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14221,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
/* lp2197 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_14153(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k14165 in lp in k14253 in nfa->dfa in k3721 */
static void C_ccall f_14167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14167,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14275,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14332,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[268]+1),t1);}

/* k14330 in k14165 in lp in k14253 in nfa->dfa in k3721 */
static void C_ccall f_14332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14336,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_length(((C_word*)t0)[2]);
/* zero-to */
f_4475(t2,t3);}

/* k14334 in k14330 in k14165 in lp in k14253 in nfa->dfa in k3721 */
static void C_ccall f_14336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[267]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],*((C_word*)lf[212]+1),((C_word*)t0)[2],t1);}

/* k14273 in k14165 in lp in k14253 in nfa->dfa in k3721 */
static void C_ccall f_14275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14275,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14277,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14292,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14294,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a14293 in k14273 in k14165 in lp in k14253 in nfa->dfa in k3721 */
static void C_ccall f_14294(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14294,3,t0,t1,t2);}
t3=(C_word)C_u_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14306,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14308,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_u_i_cddr(t2);
/* map */
t7=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,t6);}

/* a14307 in a14293 in k14273 in k14165 in lp in k14253 in nfa->dfa in k3721 */
static void C_ccall f_14308(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14308,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=f_14277(((C_word*)t0)[2],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,t3,t5));}

/* k14304 in a14293 in k14273 in k14165 in lp in k14253 in nfa->dfa in k3721 */
static void C_ccall f_14306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14306,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k14290 in k14273 in k14165 in lp in k14253 in nfa->dfa in k3721 */
static void C_ccall f_14292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* list->vector */
t2=*((C_word*)lf[266]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* renumber in k14273 in k14165 in lp in k14253 in nfa->dfa in k3721 */
static C_word C_fcall f_14277(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_i_assoc(t1,((C_word*)t0)[2]);
return((C_word)C_slot(t2,C_fix(1)));}

/* sre->nfa in k3721 */
static void C_fcall f_13350(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13350,NULL,3,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,t2);
t5=(C_word)C_i_pairp(t3);
t6=(C_truep(t5)?(C_word)C_u_i_car(t3):C_fix(0));
t7=(C_word)C_a_i_list(&a,1,C_fix(0));
t8=(C_word)C_a_i_list(&a,1,t7);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13368,a[2]=t10,tmp=(C_word)a,a+=3,tmp));
t12=((C_word*)t10)[1];
f_13368(t12,t1,t4,C_fix(1),t6,t8);}

/* lp in sre->nfa in k3721 */
static void C_fcall f_13368(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word *a;
loop:
a=C_alloc(21);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_13368,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13371,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13385,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t5);}
else{
t8=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_stringp(t8))){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13433,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13437,a[2]=t9,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_u_i_car(t2);
/* string->list */
t12=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}
else{
t9=(C_word)C_u_i_car(t2);
t10=(C_word)C_eqp(lf[75],t9);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13458,a[2]=t1,a[3]=t7,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_slot(t2,C_fix(1));
/* lp2045 */
t43=t11;
t44=t12;
t45=t3;
t46=t4;
t47=t5;
t1=t43;
t2=t44;
t3=t45;
t4=t46;
t5=t47;
goto loop;}
else{
t11=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_charp(t11))){
t12=(C_word)C_u_i_car(t2);
t13=(C_word)C_u_i_char_upper_casep(t12);
t14=(C_truep(t13)?(C_word)C_u_i_char_downcase(t12):(C_word)C_u_i_char_upcase(t12));
t15=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13481,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=t14,a[7]=t1,a[8]=t7,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13514,a[2]=t15,a[3]=t14,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* flag-set? */
f_4977(t16,t4,C_fix(2));}
else{
t12=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t12))){
t13=(C_word)C_u_i_car(t2);
t14=(C_word)C_u_i_assq(t13,lf[195]);
if(C_truep(t14)){
t15=(C_word)C_slot(t14,C_fix(1));
t16=(C_word)C_slot(t2,C_fix(1));
t17=(C_word)C_a_i_cons(&a,2,t15,t16);
/* lp2045 */
t43=t1;
t44=t17;
t45=t3;
t46=t4;
t47=t5;
t1=t43;
t2=t44;
t3=t45;
t4=t46;
t5=t47;
goto loop;}
else{
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_pairp(t13))){
t14=(C_word)C_u_i_caar(t2);
if(C_truep((C_word)C_i_stringp(t14))){
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13591,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[2],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t16=(C_word)C_u_i_caar(t2);
/* string->list */
t17=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t15,t16);}
else{
t15=(C_word)C_u_i_caar(t2);
t16=(C_word)C_eqp(t15,lf[74]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(t15,lf[176]));
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13614,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t19=(C_word)C_u_i_cdar(t2);
t20=(C_word)C_slot(t2,C_fix(1));
/* append */
t21=*((C_word*)lf[117]+1);
((C_proc4)(void*)(*((C_word*)t21+1)))(4,t21,t18,t19,t20);}
else{
t18=(C_word)C_eqp(t15,lf[174]);
t19=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_13631,a[2]=t7,a[3]=t15,a[4]=t5,a[5]=t3,a[6]=t4,a[7]=t6,a[8]=t1,a[9]=((C_word*)t0)[2],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t18)){
t20=t19;
f_13631(t20,t18);}
else{
t20=(C_word)C_eqp(t15,lf[175]);
if(C_truep(t20)){
t21=t19;
f_13631(t21,t20);}
else{
t21=(C_word)C_eqp(t15,lf[110]);
t22=t19;
f_13631(t22,(C_truep(t21)?t21:(C_word)C_eqp(t15,lf[111])));}}}}}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}}}}}}

/* k13629 in lp in sre->nfa in k3721 */
static void C_fcall f_13631(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13631,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13634,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_slot(((C_word*)t0)[10],C_fix(1));
/* lp2045 */
t4=((C_word*)((C_word*)t0)[9])[1];
f_13368(t4,t2,t3,((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[4]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[25]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_13685,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[2],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
t4=t3;
f_13685(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[3],lf[194]);
if(C_truep(t4)){
t5=t3;
f_13685(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[3],lf[183]);
t6=t3;
f_13685(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[3],lf[116])));}}}}

/* k13683 in k13629 in lp in sre->nfa in k3721 */
static void C_fcall f_13685(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13685,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13688,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13773,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* flag-set? */
f_4977(t4,((C_word*)t0)[5],C_fix(2));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[2],lf[62]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13782,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
/* lp2045 */
t5=((C_word*)((C_word*)t0)[7])[1];
f_13368(t5,t3,t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[2],lf[87]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13885,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
/* lp2045 */
t6=((C_word*)((C_word*)t0)[7])[1];
f_13368(t6,t4,t5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[2],lf[85]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[2],lf[83]));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13945,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
/* lp2045 */
t8=((C_word*)((C_word*)t0)[7])[1];
f_13368(t8,t6,t7,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[2],lf[68]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[2],lf[77]));
if(C_truep(t7)){
t8=(C_word)C_u_i_cdar(((C_word*)t0)[8]);
t9=f_12312(C_a_i(&a,3),t8);
t10=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t11=(C_word)C_a_i_cons(&a,2,t9,t10);
/* lp2045 */
t12=((C_word*)((C_word*)t0)[7])[1];
f_13368(t12,((C_word*)t0)[9],t11,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t8=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}}}}

/* k13943 in k13683 in k13629 in lp in sre->nfa in k3721 */
static void C_ccall f_13945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13945,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13951,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14033,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* new-state-number2050 */
t4=((C_word*)t0)[2];
f_13371(t4,t3,t1);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k14031 in k13943 in k13683 in k13629 in lp in sre->nfa in k3721 */
static void C_ccall f_14033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2045 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_13368(t2,((C_word*)t0)[4],lf[265],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k13949 in k13943 in k13683 in k13629 in lp in sre->nfa in k3721 */
static void C_ccall f_13951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13954,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_cdar(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14029,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* new-state-number2050 */
t5=((C_word*)t0)[2];
f_13371(t5,t4,t1);}

/* k14027 in k13949 in k13943 in k13683 in k13629 in lp in sre->nfa in k3721 */
static void C_ccall f_14029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2045 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_13368(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k13952 in k13949 in k13943 in k13683 in k13629 in lp in sre->nfa in k3721 */
static void C_ccall f_13954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13954,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13960,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_caar(((C_word*)t0)[2]);
t4=(C_word)C_eqp(lf[83],t3);
if(C_truep(t4)){
t5=(C_word)C_u_i_car(t1);
t6=(C_word)C_u_i_caar(((C_word*)t0)[4]);
t7=(C_word)C_a_i_cons(&a,2,lf[75],t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14009,a[2]=t5,a[3]=t2,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_u_i_cdar(t1);
/* ##sys#append */
t10=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,t9,C_SCHEME_END_OF_LIST);}
else{
t5=t2;
f_13960(t5,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k14007 in k13952 in k13949 in k13943 in k13683 in k13629 in lp in sre->nfa in k3721 */
static void C_ccall f_14009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14009,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_13960(t3,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t2));}

/* k13958 in k13952 in k13949 in k13943 in k13683 in k13629 in lp in sre->nfa in k3721 */
static void C_fcall f_13960(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13960,NULL,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
t3=(C_word)C_u_i_caar(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,lf[75],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13979,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_u_i_cdar(((C_word*)t0)[4]);
/* ##sys#append */
t7=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}

/* k13977 in k13958 in k13952 in k13949 in k13943 in k13683 in k13629 in lp in sre->nfa in k3721 */
static void C_ccall f_13979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13979,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(1),t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}

/* k13883 in k13683 in k13629 in lp in sre->nfa in k3721 */
static void C_ccall f_13885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13885,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13891,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cdar(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13929,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* new-state-number2050 */
t5=((C_word*)t0)[2];
f_13371(t5,t4,t1);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k13927 in k13883 in k13683 in k13629 in lp in sre->nfa in k3721 */
static void C_ccall f_13929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2045 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_13368(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k13889 in k13883 in k13683 in k13629 in lp in sre->nfa in k3721 */
static void C_ccall f_13891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13891,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_u_i_caar(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,lf[75],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13913,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_u_i_cdar(t1);
/* ##sys#append */
t7=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k13911 in k13889 in k13883 in k13683 in k13629 in lp in sre->nfa in k3721 */
static void C_ccall f_13913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13913,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(1),t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}

/* k13780 in k13683 in k13629 in lp in sre->nfa in k3721 */
static void C_ccall f_13782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13782,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13785,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t1)){
t3=(C_word)C_u_i_cddar(((C_word*)t0)[4]);
t4=f_12337(C_a_i(&a,3),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13864,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* new-state-number2050 */
t7=((C_word*)t0)[5];
f_13371(t7,t6,t1);}
else{
t3=t2;
f_13785(2,t3,C_SCHEME_FALSE);}}

/* k13862 in k13780 in k13683 in k13629 in lp in sre->nfa in k3721 */
static void C_ccall f_13864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2045 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_13368(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k13783 in k13780 in k13683 in k13629 in lp in sre->nfa in k3721 */
static void C_ccall f_13785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13785,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13788,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=(C_word)C_u_i_cadar(((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13849,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* new-state-number2050 */
t6=((C_word*)t0)[5];
f_13371(t6,t5,t1);}
else{
t3=t2;
f_13788(2,t3,C_SCHEME_FALSE);}}

/* k13847 in k13783 in k13780 in k13683 in k13629 in lp in sre->nfa in k3721 */
static void C_ccall f_13849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2045 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_13368(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k13786 in k13783 in k13780 in k13683 in k13629 in lp in sre->nfa in k3721 */
static void C_ccall f_13788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13788,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13814,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* new-state-number2050 */
t3=((C_word*)t0)[2];
f_13371(t3,t2,t1);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k13812 in k13786 in k13783 in k13780 in k13683 in k13629 in lp in sre->nfa in k3721 */
static void C_ccall f_13814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13814,2,t0,t1);}
t2=(C_word)C_u_i_caar(((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,lf[75],t2);
t4=(C_word)C_u_i_caar(((C_word*)t0)[4]);
t5=(C_word)C_a_i_cons(&a,2,lf[75],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t3,t6);
t8=(C_word)C_a_i_cons(&a,2,t1,t7);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13802,a[2]=t8,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13806,a[2]=((C_word*)t0)[4],a[3]=t9,tmp=(C_word)a,a+=4,tmp);
/* take-up-to */
f_4514(t10,((C_word*)t0)[5],((C_word*)t0)[2]);}

/* k13804 in k13812 in k13786 in k13783 in k13780 in k13683 in k13629 in lp in sre->nfa in k3721 */
static void C_ccall f_13806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13806,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13810,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t3=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k13808 in k13804 in k13812 in k13786 in k13783 in k13780 in k13683 in k13629 in lp in sre->nfa in k3721 */
static void C_ccall f_13810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k13800 in k13812 in k13786 in k13783 in k13780 in k13683 in k13629 in lp in sre->nfa in k3721 */
static void C_ccall f_13802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13802,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k13771 in k13683 in k13629 in lp in sre->nfa in k3721 */
static void C_ccall f_13773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13773,2,t0,t1);}
/* sre->cset */
f_17663(((C_word*)t0)[3],((C_word*)t0)[2],(C_word)C_a_i_list(&a,1,t1));}

/* k13686 in k13683 in k13629 in lp in sre->nfa in k3721 */
static void C_ccall f_13688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13688,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(t2,C_fix(1));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13704,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* lp2045 */
t6=((C_word*)((C_word*)t0)[6])[1];
f_13368(t6,t4,t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13715,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* lp2045 */
t6=((C_word*)((C_word*)t0)[6])[1];
f_13368(t6,t4,t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* k13713 in k13686 in k13683 in k13629 in lp in sre->nfa in k3721 */
static void C_ccall f_13715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13715,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13741,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13743,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a13742 in k13713 in k13686 in k13683 in k13629 in lp in sre->nfa in k3721 */
static void C_ccall f_13743(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13743,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[25],t3,t4));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k13739 in k13713 in k13686 in k13683 in k13629 in lp in sre->nfa in k3721 */
static void C_ccall f_13741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13741,2,t0,t1);}
t2=f_12337(C_a_i(&a,3),t1);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13729,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* new-state-number2050 */
t5=((C_word*)t0)[2];
f_13371(t5,t4,((C_word*)t0)[4]);}

/* k13727 in k13739 in k13713 in k13686 in k13683 in k13629 in lp in sre->nfa in k3721 */
static void C_ccall f_13729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13729,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13733,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* flag-clear */
t3=lf[48];
f_4996(4,t3,t2,((C_word*)t0)[2],C_fix(2));}

/* k13731 in k13727 in k13739 in k13713 in k13686 in k13683 in k13629 in lp in sre->nfa in k3721 */
static void C_ccall f_13733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2045 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_13368(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k13702 in k13686 in k13683 in k13629 in lp in sre->nfa in k3721 */
static void C_ccall f_13704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13704,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
/* extend-state2051 */
t3=((C_word*)t0)[3];
f_13385(t3,((C_word*)t0)[2],t1,(C_word)C_a_i_list(&a,1,t2));}

/* k13632 in k13629 in lp in sre->nfa in k3721 */
static void C_ccall f_13634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13637,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_u_i_caar(((C_word*)t0)[6]);
t4=(C_word)C_u_i_memq(t3,lf[263]);
t5=(C_truep(t4)?C_fix(2):C_fix(32));
t6=(C_word)C_u_i_caar(((C_word*)t0)[6]);
t7=(C_word)C_u_i_memq(t6,lf[264]);
t8=(C_truep(t7)?lf[48]:lf[47]);
t9=t8;
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t2,((C_word*)t0)[2],t5);}

/* k13635 in k13632 in k13629 in lp in sre->nfa in k3721 */
static void C_ccall f_13637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13637,2,t0,t1);}
if(C_truep(((C_word*)t0)[6])){
t2=(C_word)C_u_i_cdar(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13651,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* new-state-number2050 */
t4=((C_word*)t0)[2];
f_13371(t4,t3,((C_word*)t0)[6]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k13649 in k13635 in k13632 in k13629 in lp in sre->nfa in k3721 */
static void C_ccall f_13651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2045 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_13368(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k13612 in lp in sre->nfa in k3721 */
static void C_ccall f_13614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2045 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_13368(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k13589 in lp in sre->nfa in k3721 */
static void C_ccall f_13591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13591,2,t0,t1);}
t2=f_12337(C_a_i(&a,3),t1);
t3=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
/* lp2045 */
t5=((C_word*)((C_word*)t0)[6])[1];
f_13368(t5,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k13512 in lp in sre->nfa in k3721 */
static void C_ccall f_13514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_eqvp(t2,((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
f_13481(t4,(C_word)C_i_not(t3));}
else{
t2=((C_word*)t0)[2];
f_13481(t2,C_SCHEME_FALSE);}}

/* k13479 in lp in sre->nfa in k3721 */
static void C_fcall f_13481(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13481,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13488,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
/* lp2045 */
t4=((C_word*)((C_word*)t0)[5])[1];
f_13368(t4,t2,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13503,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
/* lp2045 */
t4=((C_word*)((C_word*)t0)[5])[1];
f_13368(t4,t2,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k13501 in k13479 in lp in sre->nfa in k3721 */
static void C_ccall f_13503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13503,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
/* extend-state2051 */
t3=((C_word*)t0)[3];
f_13385(t3,((C_word*)t0)[2],t1,(C_word)C_a_i_list(&a,1,t2));}

/* k13486 in k13479 in lp in sre->nfa in k3721 */
static void C_ccall f_13488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13488,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
/* extend-state2051 */
t3=((C_word*)t0)[4];
f_13385(t3,((C_word*)t0)[3],t1,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}

/* k13456 in lp in sre->nfa in k3721 */
static void C_ccall f_13458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13458,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
/* extend-state2051 */
t3=((C_word*)t0)[3];
f_13385(t3,((C_word*)t0)[2],t1,(C_word)C_a_i_list(&a,1,t2));}

/* k13435 in lp in sre->nfa in k3721 */
static void C_ccall f_13437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* append */
t3=*((C_word*)lf[117]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k13431 in lp in sre->nfa in k3721 */
static void C_ccall f_13433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2045 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_13368(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* extend-state in lp in sre->nfa in k3721 */
static void C_fcall f_13385(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13385,NULL,4,t0,t1,t2,t3);}
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13400,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* new-state-number2050 */
t5=((C_word*)t0)[2];
f_13371(t5,t4,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k13398 in extend-state in lp in sre->nfa in k3721 */
static void C_ccall f_13400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13400,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13404,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13406,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a13405 in k13398 in extend-state in lp in sre->nfa in k3721 */
static void C_ccall f_13406(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13406,3,t0,t1,t2);}
t3=(C_word)C_u_i_caar(((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* k13402 in k13398 in extend-state in lp in sre->nfa in k3721 */
static void C_ccall f_13404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13404,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[2]));}

/* new-state-number in lp in sre->nfa in k3721 */
static void C_fcall f_13371(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13371,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_i_caar(t2);
t4=(C_word)C_a_i_plus(&a,2,C_fix(1),t3);
/* max */
t5=*((C_word*)lf[201]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,((C_word*)t0)[2],t4);}

/* dfa-match/longest in k3721 */
static void C_fcall f_13243(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13243,NULL,5,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_slot(t6,C_fix(0));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(0));
t10=(C_word)C_u_i_car(t9);
t11=(C_truep(t10)?t4:C_SCHEME_FALSE);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13257,a[2]=t13,a[3]=t2,a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_13257(t15,t1,t4,t7,t11);}

/* lp in dfa-match/longest in k3721 */
static void C_fcall f_13257(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13257,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_greater_or_equalp(t2,((C_word*)t0)[5]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_subchar(((C_word*)t0)[4],t2);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13270,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13295,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_slot(t3,C_fix(1));
/* find */
f_4557(t6,t7,t8);}}

/* a13294 in lp in dfa-match/longest in k3721 */
static void C_ccall f_13295(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13295,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_i_eqvp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_u_i_caar(t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t6,((C_word*)t0)[2]))){
t7=(C_word)C_u_i_cdar(t2);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],t7));}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}}

/* k13268 in lp in dfa-match/longest in k3721 */
static void C_ccall f_13270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13270,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
t3=t1;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_slot(t2,t4);
t6=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1));
t7=(C_word)C_u_i_car(t5);
t8=(C_truep(t7)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1)):((C_word*)t0)[4]);
/* lp2017 */
t9=((C_word*)((C_word*)t0)[3])[1];
f_13257(t9,((C_word*)t0)[2],t6,t5,t8);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* irregex-match in k3721 */
static void C_ccall f_13065(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_13065,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13069,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* irregex */
t5=*((C_word*)lf[169]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k13067 in irregex-match in k3721 */
static void C_ccall f_13069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13069,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13072,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* irregex-new-matches */
t3=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k13070 in k13067 in irregex-match in k3721 */
static void C_ccall f_13072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13072,2,t0,t1);}
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[4]));
t3=t1;
t4=((C_word*)t0)[4];
t5=(C_word)C_i_setslot(t3,C_fix(1),t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13084,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* irregex-dfa */
t7=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[2]);}

/* k13082 in k13070 in k13067 in irregex-match in k3721 */
static void C_ccall f_13084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13084,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13087,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13109,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* irregex-dfa */
t4=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13112,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* irregex-nfa */
t3=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k13110 in k13082 in k13070 in k13067 in irregex-match in k3721 */
static void C_ccall f_13112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13112,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13115,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13129,tmp=(C_word)a,a+=2,tmp);
/* matcher1967 */
t4=t1;
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,((C_word*)t0)[2],C_fix(0),((C_word*)t0)[4],t3);}

/* a13128 in k13110 in k13082 in k13070 in k13067 in irregex-match in k3721 */
static void C_ccall f_13129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13129,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k13113 in k13110 in k13082 in k13070 in k13067 in irregex-match in k3721 */
static void C_ccall f_13115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13115,2,t0,t1);}
if(C_truep((C_word)C_i_equalp(t1,((C_word*)t0)[4]))){
t2=((C_word*)t0)[3];
t3=(C_word)C_a_i_times(&a,2,C_fix(0),C_fix(2));
t4=(C_word)C_a_i_plus(&a,2,C_fix(3),t3);
t5=(C_word)C_i_setslot(t2,t4,C_fix(0));
t6=((C_word*)t0)[3];
t7=t1;
t8=(C_word)C_a_i_times(&a,2,C_fix(0),C_fix(2));
t9=(C_word)C_a_i_plus(&a,2,C_fix(4),t8);
t10=(C_word)C_i_setslot(t6,t9,t7);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k13107 in k13082 in k13070 in k13067 in irregex-match in k3721 */
static void C_ccall f_13109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* dfa-match/longest */
f_13243(((C_word*)t0)[4],t1,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k13085 in k13082 in k13070 in k13067 in irregex-match in k3721 */
static void C_ccall f_13087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13087,2,t0,t1);}
if(C_truep((C_word)C_i_equalp(t1,((C_word*)t0)[6]))){
t2=((C_word*)t0)[5];
t3=(C_word)C_a_i_times(&a,2,C_fix(0),C_fix(2));
t4=(C_word)C_a_i_plus(&a,2,C_fix(3),t3);
t5=(C_word)C_i_setslot(t2,t4,C_fix(0));
t6=((C_word*)t0)[5];
t7=t1;
t8=(C_word)C_a_i_times(&a,2,C_fix(0),C_fix(2));
t9=(C_word)C_a_i_plus(&a,2,C_fix(4),t8);
t10=(C_word)C_i_setslot(t6,t9,t7);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13102,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13105,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t11,tmp=(C_word)a,a+=6,tmp);
/* irregex-dfa/extract */
t13=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k13103 in k13085 in k13082 in k13070 in k13067 in irregex-match in k3721 */
static void C_ccall f_13105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],C_fix(0),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k13100 in k13085 in k13082 in k13070 in k13067 in irregex-match in k3721 */
static void C_ccall f_13102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* irregex-search/matches in k3721 */
static void C_ccall f_12906(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_12906,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12913,a[2]=t5,a[3]=t2,a[4]=t3,a[5]=t1,a[6]=t4,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
/* irregex-dfa */
t8=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k12911 in irregex-search/matches in k3721 */
static void C_ccall f_12913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12913,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12919,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13026,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* irregex-flags */
t4=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13029,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* irregex-nfa */
t3=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}}

/* k13027 in k12911 in irregex-search/matches in k3721 */
static void C_ccall f_13029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13029,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13034,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_13034(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k13027 in k12911 in irregex-search/matches in k3721 */
static void C_fcall f_13034(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13034,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_less_or_equalp(t2,((C_word*)t0)[6]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13044,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13062,tmp=(C_word)a,a+=2,tmp);
/* matcher1927 */
t5=((C_word*)t0)[3];
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t3,((C_word*)t0)[2],t2,((C_word*)t0)[5],t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a13061 in lp in k13027 in k12911 in irregex-search/matches in k3721 */
static void C_ccall f_13062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13062,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k13042 in lp in k13027 in k12911 in irregex-search/matches in k3721 */
static void C_ccall f_13044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13044,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
t4=(C_word)C_a_i_times(&a,2,C_fix(0),C_fix(2));
t5=(C_word)C_a_i_plus(&a,2,C_fix(3),t4);
t6=(C_word)C_i_setslot(t2,t5,t3);
t7=((C_word*)t0)[5];
t8=t1;
t9=(C_word)C_a_i_times(&a,2,C_fix(0),C_fix(2));
t10=(C_word)C_a_i_plus(&a,2,C_fix(4),t9);
t11=(C_word)C_i_setslot(t7,t10,t8);
t12=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,((C_word*)t0)[5]);}
else{
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],C_fix(1));
/* lp1928 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_13034(t3,((C_word*)t0)[3],t2);}}

/* k13024 in k12911 in irregex-search/matches in k3721 */
static void C_ccall f_13026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* flag-set? */
f_4977(((C_word*)t0)[2],t1,C_fix(1));}

/* k12917 in k12911 in irregex-search/matches in k3721 */
static void C_ccall f_12919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12919,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12922,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12941,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* irregex-dfa */
t4=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12944,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13022,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* irregex-dfa/search */
t4=*((C_word*)lf[3]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}}

/* k13020 in k12917 in k12911 in irregex-search/matches in k3721 */
static void C_ccall f_13022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13022,2,t0,t1);}
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
t5=t1;
t6=(C_word)C_slot(t5,C_fix(0));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13164,a[2]=t8,a[3]=t1,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_13164(t10,((C_word*)t0)[2],t3,t6);}

/* lp in k13020 in k12917 in k12911 in irregex-search/matches in k3721 */
static void C_fcall f_13164(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13164,NULL,4,t0,t1,t2,t3);}
t4=t3;
if(C_truep((C_word)C_u_i_car(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
if(C_truep((C_word)C_i_lessp(t2,((C_word*)t0)[5]))){
t5=(C_word)C_subchar(((C_word*)t0)[4],t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13183,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13199,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_slot(t3,C_fix(1));
/* find */
f_4557(t6,t7,t8);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}}

/* a13198 in lp in k13020 in k12917 in k12911 in irregex-search/matches in k3721 */
static void C_ccall f_13199(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13199,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_i_eqvp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_u_i_caar(t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t6,((C_word*)t0)[2]))){
t7=(C_word)C_u_i_cdar(t2);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],t7));}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}}

/* k13181 in lp in k13020 in k12917 in k12911 in irregex-search/matches in k3721 */
static void C_ccall f_13183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13183,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1));
t3=((C_word*)t0)[4];
t4=t1;
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_slot(t3,t5);
/* lp1991 */
t7=((C_word*)((C_word*)t0)[3])[1];
f_13164(t7,((C_word*)t0)[2],t2,t6);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k12942 in k12917 in k12911 in irregex-search/matches in k3721 */
static void C_ccall f_12944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12944,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13018,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* irregex-lengths */
t3=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k13016 in k12942 in k12917 in k12911 in irregex-search/matches in k3721 */
static void C_ccall f_13018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13018,2,t0,t1);}
t2=(C_word)C_slot(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12953,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_slot(t2,C_fix(1)))){
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[8],t4);
/* max */
t6=*((C_word*)lf[201]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,((C_word*)t0)[2],t5);}
else{
t4=t3;
f_12953(2,t4,((C_word*)t0)[2]);}}

/* k12951 in k13016 in k12942 in k12917 in k12911 in irregex-search/matches in k3721 */
static void C_ccall f_12953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12953,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[8]);
t3=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[7],t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12959,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* irregex-dfa */
t5=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}

/* k12957 in k12951 in k13016 in k12942 in k12917 in k12911 in irregex-search/matches in k3721 */
static void C_ccall f_12959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12959,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12964,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_12964(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k12957 in k12951 in k13016 in k12942 in k12917 in k12911 in irregex-search/matches in k3721 */
static void C_fcall f_12964(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12964,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_less_or_equalp(t2,((C_word*)t0)[8]))){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12974,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* dfa-match/longest */
f_13243(t3,((C_word*)t0)[3],((C_word*)t0)[6],t2,((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k12972 in lp in k12957 in k12951 in k13016 in k12942 in k12917 in k12911 in irregex-search/matches in k3721 */
static void C_ccall f_12974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12974,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
t3=((C_word*)t0)[6];
t4=(C_word)C_a_i_times(&a,2,C_fix(0),C_fix(2));
t5=(C_word)C_a_i_plus(&a,2,C_fix(3),t4);
t6=(C_word)C_i_setslot(t2,t5,t3);
t7=((C_word*)t0)[7];
t8=t1;
t9=(C_word)C_a_i_times(&a,2,C_fix(0),C_fix(2));
t10=(C_word)C_a_i_plus(&a,2,C_fix(4),t9);
t11=(C_word)C_i_setslot(t7,t10,t8);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12986,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12989,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=t12,tmp=(C_word)a,a+=7,tmp);
/* irregex-dfa/extract */
t14=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t14+1)))(3,t14,t13,((C_word*)t0)[3]);}
else{
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(1));
/* lp1912 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_12964(t3,((C_word*)t0)[5],t2);}}

/* k12987 in k12972 in lp in k12957 in k12951 in k13016 in k12942 in k12917 in k12911 in irregex-search/matches in k3721 */
static void C_ccall f_12989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12984 in k12972 in lp in k12957 in k12951 in k13016 in k12942 in k12917 in k12911 in irregex-search/matches in k3721 */
static void C_ccall f_12986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k12939 in k12917 in k12911 in irregex-search/matches in k3721 */
static void C_ccall f_12941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* dfa-match/longest */
f_13243(((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12920 in k12917 in k12911 in irregex-search/matches in k3721 */
static void C_ccall f_12922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12922,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=(C_word)C_a_i_times(&a,2,C_fix(0),C_fix(2));
t5=(C_word)C_a_i_plus(&a,2,C_fix(3),t4);
t6=(C_word)C_i_setslot(t2,t5,t3);
t7=((C_word*)t0)[6];
t8=t1;
t9=(C_word)C_a_i_times(&a,2,C_fix(0),C_fix(2));
t10=(C_word)C_a_i_plus(&a,2,C_fix(4),t9);
t11=(C_word)C_i_setslot(t7,t10,t8);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12934,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12937,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=t12,tmp=(C_word)a,a+=7,tmp);
/* irregex-dfa/extract */
t14=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t14+1)))(3,t14,t13,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k12935 in k12920 in k12917 in k12911 in irregex-search/matches in k3721 */
static void C_ccall f_12937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12932 in k12920 in k12917 in k12911 in irregex-search/matches in k3721 */
static void C_ccall f_12934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* irregex-search in k3721 */
static void C_ccall f_12860(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_12860r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_12860r(t0,t1,t2,t3,t4);}}

static void C_ccall f_12860r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12864,a[2]=t1,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* irregex */
t6=*((C_word*)lf[169]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k12862 in irregex-search in k3721 */
static void C_ccall f_12864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12864,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[4]);
t3=(C_truep(t2)?(C_word)C_u_i_car(((C_word*)t0)[4]):C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12882,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t6=t4;
f_12882(t6,(C_word)C_i_pairp(t5));}
else{
t5=t4;
f_12882(t5,C_SCHEME_FALSE);}}

/* k12880 in k12862 in irregex-search in k3721 */
static void C_fcall f_12882(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12882,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_u_i_cadr(((C_word*)t0)[6]):(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[5])));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12873,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* irregex-new-matches */
t4=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* k12871 in k12880 in k12862 in irregex-search in k3721 */
static void C_ccall f_12873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=t1;
t3=((C_word*)t0)[6];
t4=(C_word)C_i_setslot(t2,C_fix(1),t3);
/* irregex-search/matches */
t5=*((C_word*)lf[232]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* sre-remove-initial-bos in k3721 */
static void C_ccall f_12743(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12743,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_eqp(t3,lf[74]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12762,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_12762(t6,t4);}
else{
t6=(C_word)C_eqp(t3,lf[176]);
if(C_truep(t6)){
t7=t5;
f_12762(t7,t6);}
else{
t7=(C_word)C_eqp(t3,lf[68]);
if(C_truep(t7)){
t8=t5;
f_12762(t8,t7);}
else{
t8=(C_word)C_eqp(t3,lf[83]);
t9=t5;
f_12762(t9,(C_truep(t8)?t8:(C_word)C_eqp(t3,lf[85])));}}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k12760 in sre-remove-initial-bos in k3721 */
static void C_fcall f_12762(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12762,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t4=(C_word)C_eqp(lf[142],t3);
if(C_truep(t4)){
t5=(C_word)C_u_i_car(((C_word*)t0)[4]);
t6=(C_word)C_u_i_cddr(((C_word*)t0)[4]);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t5,t6));}
else{
t5=(C_word)C_u_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12800,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
/* sre-remove-initial-bos */
t8=lf[221];
f_12743(3,t8,t6,t7);}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[2],lf[62]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12833,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* map */
t5=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[221],t4);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}}}

/* k12831 in k12760 in sre-remove-initial-bos in k3721 */
static void C_ccall f_12833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12833,2,t0,t1);}
/* sre-alternate */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_12337(C_a_i(&a,3),t1));}

/* k12798 in k12760 in sre-remove-initial-bos in k3721 */
static void C_ccall f_12800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12800,2,t0,t1);}
t2=(C_word)C_u_i_cddr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* sre-sequence-names in k3721 */
static void C_fcall f_12707(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12707,NULL,4,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12737,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_u_i_car(t2);
/* sre-count-submatches */
f_11217(t6,t7);}}

/* k12735 in sre-sequence-names in k3721 */
static void C_ccall f_12737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12737,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12729,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_i_car(((C_word*)t0)[3]);
/* sre-names */
f_12477(t3,t4,((C_word*)t0)[6],((C_word*)t0)[2]);}

/* k12727 in k12735 in sre-sequence-names in k3721 */
static void C_ccall f_12729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* sre-sequence-names */
f_12707(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* sre-names in k3721 */
static void C_fcall f_12477(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word *a;
loop:
a=C_alloc(13);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_12477,NULL,4,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_eqp(t5,lf[68]);
if(C_truep(t6)){
t7=(C_word)C_slot(t2,C_fix(1));
t8=f_12312(C_a_i(&a,3),t7);
t9=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
/* sre-names */
t38=t1;
t39=t8;
t40=t9;
t41=t4;
t1=t38;
t2=t39;
t3=t40;
t4=t41;
goto loop;}
else{
t7=(C_word)C_eqp(t5,lf[77]);
if(C_truep(t7)){
t8=(C_word)C_u_i_cddr(t2);
t9=f_12312(C_a_i(&a,3),t8);
t10=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t11=(C_word)C_u_i_cadr(t2);
t12=(C_word)C_a_i_cons(&a,2,t11,t3);
t13=(C_word)C_a_i_cons(&a,2,t12,t4);
/* sre-names */
t38=t1;
t39=t9;
t40=t10;
t41=t13;
t1=t38;
t2=t39;
t3=t40;
t4=t41;
goto loop;}
else{
t8=(C_word)C_eqp(t5,lf[192]);
if(C_truep(t8)){
t9=(C_word)C_u_i_cdddr(t2);
t10=f_12312(C_a_i(&a,3),t9);
t11=(C_word)C_u_i_cadr(t2);
t12=(C_word)C_a_i_plus(&a,2,t3,t11);
/* sre-names */
t38=t1;
t39=t10;
t40=t12;
t41=t4;
t1=t38;
t2=t39;
t3=t40;
t4=t41;
goto loop;}
else{
t9=(C_word)C_eqp(t5,lf[74]);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12575,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t9)){
t11=t10;
f_12575(t11,t9);}
else{
t11=(C_word)C_eqp(t5,lf[176]);
if(C_truep(t11)){
t12=t10;
f_12575(t12,t11);}
else{
t12=(C_word)C_eqp(t5,lf[62]);
if(C_truep(t12)){
t13=t10;
f_12575(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[83]);
if(C_truep(t13)){
t14=t10;
f_12575(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[85]);
if(C_truep(t14)){
t15=t10;
f_12575(t15,t14);}
else{
t15=(C_word)C_eqp(t5,lf[87]);
if(C_truep(t15)){
t16=t10;
f_12575(t16,t15);}
else{
t16=(C_word)C_eqp(t5,lf[84]);
if(C_truep(t16)){
t17=t10;
f_12575(t17,t16);}
else{
t17=(C_word)C_eqp(t5,lf[88]);
if(C_truep(t17)){
t18=t10;
f_12575(t18,t17);}
else{
t18=(C_word)C_eqp(t5,lf[174]);
if(C_truep(t18)){
t19=t10;
f_12575(t19,t18);}
else{
t19=(C_word)C_eqp(t5,lf[175]);
if(C_truep(t19)){
t20=t10;
f_12575(t20,t19);}
else{
t20=(C_word)C_eqp(t5,lf[187]);
if(C_truep(t20)){
t21=t10;
f_12575(t21,t20);}
else{
t21=(C_word)C_eqp(t5,lf[70]);
if(C_truep(t21)){
t22=t10;
f_12575(t22,t21);}
else{
t22=(C_word)C_eqp(t5,lf[72]);
if(C_truep(t22)){
t23=t10;
f_12575(t23,t22);}
else{
t23=(C_word)C_eqp(t5,lf[71]);
t24=t10;
f_12575(t24,(C_truep(t23)?t23:(C_word)C_eqp(t5,lf[73])));}}}}}}}}}}}}}}}}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k12573 in sre-names in k3721 */
static void C_fcall f_12575(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* sre-sequence-names */
f_12707(((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[2],lf[90]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[2],lf[91]));
if(C_truep(t3)){
t4=(C_word)C_u_i_cddr(((C_word*)t0)[6]);
/* sre-sequence-names */
f_12707(((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[2],lf[89]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[2],lf[86]));
if(C_truep(t5)){
t6=(C_word)C_u_i_cdddr(((C_word*)t0)[6]);
/* sre-sequence-names */
f_12707(((C_word*)t0)[5],t6,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,((C_word*)t0)[3]);}}}}

/* sre-strip-submatches in k3721 */
static void C_ccall f_12362(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)tr3,(void*)f_12362,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_eqp(t3,lf[68]);
if(C_truep(t4)){
t5=(C_word)C_slot(t2,C_fix(1));
t6=f_12312(C_a_i(&a,3),t5);
/* sre-strip-submatches */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
c=3;
goto loop;}
else{
t5=(C_word)C_eqp(t3,lf[192]);
if(C_truep(t5)){
t6=(C_word)C_u_i_cdddr(t2);
t7=f_12312(C_a_i(&a,3),t6);
/* sre-strip-submatches */
t11=t1;
t12=t7;
t1=t11;
t2=t12;
c=3;
goto loop;}
else{
/* map */
t6=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,lf[179],t2);}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* sre-alternate in k3721 */
static C_word C_fcall f_12337(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
if(C_truep((C_word)C_i_nullp(t1))){
return(lf[75]);}
else{
t2=(C_word)C_slot(t1,C_fix(1));
t3=(C_word)C_i_nullp(t2);
return((C_truep(t3)?(C_word)C_u_i_car(t1):(C_word)C_a_i_cons(&a,2,lf[62],t1)));}}

/* sre-sequence in k3721 */
static C_word C_fcall f_12312(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
if(C_truep((C_word)C_i_nullp(t1))){
return(lf[75]);}
else{
t2=(C_word)C_slot(t1,C_fix(1));
t3=(C_word)C_i_nullp(t2);
return((C_truep(t3)?(C_word)C_u_i_car(t1):(C_word)C_a_i_cons(&a,2,lf[74],t1)));}}

/* sre-count-submatches in k3721 */
static void C_fcall f_11217(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11217,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11223,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_11223(4,t6,t1,t2,C_fix(0));}

/* count in sre-count-submatches in k3721 */
static void C_ccall f_11223(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11223,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_u_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11248,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_eqp(t4,lf[68]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t4,lf[77]));
if(C_truep(t7)){
t8=t5;
f_11248(t8,C_fix(1));}
else{
t8=(C_word)C_eqp(t4,lf[192]);
if(C_truep(t8)){
t9=(C_word)C_u_i_cadr(t2);
t10=(C_word)C_u_i_caddr(t2);
t11=t5;
f_11248(t11,(C_word)C_a_i_plus(&a,2,t9,t10));}
else{
t9=t5;
f_11248(t9,C_fix(0));}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11246 in count in sre-count-submatches in k3721 */
static void C_fcall f_11248(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11248,NULL,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* fold */
f_4741(((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2,t3);}

/* sre-has-submatchs? in k3721 */
static void C_ccall f_11191(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11191,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_eqp(lf[68],t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_slot(t2,C_fix(1));
/* any */
f_4643(t1,lf[218],t5);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* sre-consumer? in k3721 */
static void C_ccall f_11105(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11105,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_eqp(t3,lf[83]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[85]));
if(C_truep(t5)){
t6=(C_word)C_slot(t2,C_fix(1));
t7=f_12312(C_a_i(&a,3),t6);
/* sre-any? */
t8=lf[228];
f_10887(3,t8,t1,t7);}
else{
t6=(C_word)C_eqp(t3,lf[74]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11144,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t6)){
t8=t7;
f_11144(t8,t6);}
else{
t8=(C_word)C_eqp(t3,lf[176]);
t9=t7;
f_11144(t9,(C_truep(t8)?t8:(C_word)C_eqp(t3,lf[68])));}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(lf[143],t2));}}

/* k11142 in sre-consumer? in k3721 */
static void C_fcall f_11144(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11144,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11157,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* last */
f_4601(t3,((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[2],lf[62]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* every */
f_4692(((C_word*)t0)[3],lf[200],t3);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* k11155 in k11142 in sre-consumer? in k3721 */
static void C_ccall f_11157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* sre-consumer? */
t2=lf[200];
f_11105(3,t2,((C_word*)t0)[2],t1);}

/* sre-searcher? in k3721 */
static void C_ccall f_11019(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11019,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_eqp(t3,lf[83]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[85]));
if(C_truep(t5)){
t6=(C_word)C_slot(t2,C_fix(1));
t7=f_12312(C_a_i(&a,3),t6);
/* sre-any? */
t8=lf[228];
f_10887(3,t8,t1,t7);}
else{
t6=(C_word)C_eqp(t3,lf[74]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11058,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t6)){
t8=t7;
f_11058(t8,t6);}
else{
t8=(C_word)C_eqp(t3,lf[176]);
t9=t7;
f_11058(t9,(C_truep(t8)?t8:(C_word)C_eqp(t3,lf[68])));}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(lf[142],t2));}}

/* k11056 in sre-searcher? in k3721 */
static void C_fcall f_11058(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
/* sre-searcher? */
t4=lf[222];
f_11019(3,t4,((C_word*)t0)[3],t3);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[2],lf[62]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* every */
f_4692(((C_word*)t0)[3],lf[222],t3);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* sre-repeater? in k3721 */
static C_word C_fcall f_10963(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_u_i_memq(t2,lf[229]);
if(C_truep(t3)){
return(t3);}
else{
t4=(C_word)C_u_i_car(t1);
if(C_truep((C_truep((C_word)C_eqp(t4,lf[68]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[74]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[176]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
t5=(C_word)C_slot(t1,C_fix(1));
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_u_i_cddr(t1);
if(C_truep((C_word)C_i_nullp(t6))){
t7=(C_word)C_u_i_cadr(t1);
t9=t7;
t1=t9;
goto loop;}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}}
else{
return(C_SCHEME_FALSE);}}

/* sre-any? in k3721 */
static void C_ccall f_10887(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10887,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,lf[80]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_eqp(t4,lf[74]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10912,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=t6;
f_10912(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[176]);
t8=t6;
f_10912(t8,(C_truep(t7)?t7:(C_word)C_eqp(t4,lf[68])));}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* k10910 in sre-any? in k3721 */
static void C_fcall f_10912(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
/* sre-any? */
t5=lf[228];
f_10887(3,t5,((C_word*)t0)[3],t4);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[2],lf[62]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* every */
f_4692(((C_word*)t0)[3],lf[228],t3);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* sre-empty? in k3721 */
static void C_ccall f_10759(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10759,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_eqp(t3,lf[83]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10778,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_10778(t6,t4);}
else{
t6=(C_word)C_eqp(t3,lf[87]);
if(C_truep(t6)){
t7=t5;
f_10778(t7,t6);}
else{
t7=(C_word)C_eqp(t3,lf[70]);
if(C_truep(t7)){
t8=t5;
f_10778(t8,t7);}
else{
t8=(C_word)C_eqp(t3,lf[72]);
if(C_truep(t8)){
t9=t5;
f_10778(t9,t8);}
else{
t9=(C_word)C_eqp(t3,lf[71]);
t10=t5;
f_10778(t10,(C_truep(t9)?t9:(C_word)C_eqp(t3,lf[73])));}}}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_memq(t2,lf[227]));}}

/* k10776 in sre-empty? in k3721 */
static void C_fcall f_10778(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10778,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[89]);
if(C_truep(t2)){
t3=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
t4=(C_word)C_i_numberp(t3);
t5=(C_word)C_i_not(t4);
if(C_truep(t5)){
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_zerop(t6));}}
else{
t3=(C_word)C_eqp(((C_word*)t0)[3],lf[62]);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* any */
f_4643(((C_word*)t0)[4],lf[95],t4);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[3],lf[176]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10827,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_10827(t6,t4);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[3],lf[74]);
if(C_truep(t6)){
t7=t5;
f_10827(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[3],lf[68]);
if(C_truep(t7)){
t8=t5;
f_10827(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[3],lf[85]);
t9=t5;
f_10827(t9,(C_truep(t8)?t8:(C_word)C_eqp(((C_word*)t0)[3],lf[187])));}}}}}}}

/* k10825 in k10776 in sre-empty? in k3721 */
static void C_fcall f_10827(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* every */
f_4692(((C_word*)t0)[2],lf[95],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* sre->irregex in k3721 */
static void C_ccall f_10618(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_10618r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_10618r(t0,t1,t2,t3);}}

static void C_ccall f_10618r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10622,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* symbol-list->flags */
f_5015(t4,t3);}

/* k10620 in sre->irregex in k3721 */
static void C_ccall f_10622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10622,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10625,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
t4=t1;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10305,a[2]=t4,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* flag-set? */
f_4977(t5,t4,C_fix(32));}

/* k10303 in k10620 in sre->irregex in k3721 */
static void C_ccall f_10305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10305,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10309,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* flag-set? */
f_4977(t2,((C_word*)t0)[2],C_fix(2));}

/* k10307 in k10303 in k10620 in sre->irregex in k3721 */
static void C_ccall f_10309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10309,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10311,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_10311(t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* adjust in k10307 in k10303 in k10620 in sre->irregex in k3721 */
static void C_fcall f_10311(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word *a;
loop:
a=C_alloc(13);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10311,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10314,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_eqp(t6,lf[110]);
if(C_truep(t7)){
t8=(C_word)C_slot(t2,C_fix(1));
t9=f_12312(C_a_i(&a,3),t8);
/* adjust1144 */
t34=t1;
t35=t9;
t36=C_SCHEME_TRUE;
t37=t4;
t1=t34;
t2=t35;
t3=t36;
t4=t37;
goto loop;}
else{
t8=(C_word)C_eqp(t6,lf[111]);
if(C_truep(t8)){
t9=(C_word)C_slot(t2,C_fix(1));
t10=f_12312(C_a_i(&a,3),t9);
/* adjust1144 */
t34=t1;
t35=t10;
t36=C_SCHEME_FALSE;
t37=t4;
t1=t34;
t2=t35;
t3=t36;
t4=t37;
goto loop;}
else{
t9=(C_word)C_eqp(t6,lf[174]);
if(C_truep(t9)){
t10=(C_word)C_u_i_car(t2);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10378,a[2]=t10,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10380,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t13=(C_word)C_slot(t2,C_fix(1));
/* map */
t14=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t11,t12,t13);}
else{
t10=(C_word)C_eqp(t6,lf[175]);
if(C_truep(t10)){
t11=(C_word)C_u_i_car(t2);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10405,a[2]=t11,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10407,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t14=(C_word)C_slot(t2,C_fix(1));
/* map */
t15=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t12,t13,t14);}
else{
t11=(C_word)C_eqp(t6,lf[25]);
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10424,a[2]=t5,a[3]=t6,a[4]=t2,a[5]=t1,a[6]=t4,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t11)){
t13=t12;
f_10424(t13,t11);}
else{
t13=(C_word)C_eqp(t6,lf[116]);
if(C_truep(t13)){
t14=t12;
f_10424(t14,t13);}
else{
t14=(C_word)C_eqp(t6,lf[183]);
t15=t12;
f_10424(t15,(C_truep(t14)?t14:(C_word)C_eqp(t6,lf[194])));}}}}}}}
else{
t6=t2;
t7=(C_word)C_eqp(t6,lf[80]);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[225]);}
else{
t8=(C_word)C_eqp(t6,lf[81]);
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[226]);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10565,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
if(C_truep((C_word)C_charp(t2))){
t10=t2;
t11=(C_word)C_fix((C_word)C_character_code(t10));
t12=t9;
f_10565(t12,(C_word)C_i_less_or_equalp(C_fix(128),t11));}
else{
t10=t9;
f_10565(t10,C_SCHEME_FALSE);}}
else{
t10=t9;
f_10565(t10,C_SCHEME_FALSE);}}}}}

/* k10563 in adjust in k10307 in k10303 in k10620 in sre->irregex in k3721 */
static void C_fcall f_10565(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10565,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10572,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10576,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* char->utf8-list */
f_9163(t3,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k10574 in k10563 in adjust in k10307 in k10303 in k10620 in sre->irregex in k3721 */
static void C_ccall f_10576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[164]+1),t1);}

/* k10570 in k10563 in adjust in k10307 in k10303 in k10620 in sre->irregex in k3721 */
static void C_ccall f_10572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10572,2,t0,t1);}
/* sre-sequence */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_12312(C_a_i(&a,3),t1));}

/* k10422 in adjust in k10307 in k10303 in k10620 in sre->irregex in k3721 */
static void C_fcall f_10424(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10424,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10433,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* sre->cset */
f_17663(t3,((C_word*)t0)[4],(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]));}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[83]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=f_12312(C_a_i(&a,3),t3);
t5=(C_word)C_eqp(t4,lf[80]);
if(C_truep(t5)){
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[223]);}
else{
t6=(C_word)C_eqp(t4,lf[81]);
if(C_truep(t6)){
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,lf[224]);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10509,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* map */
t9=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,((C_word*)t0)[2],t8);}}}
else{
t3=(C_word)C_u_i_car(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10528,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* map */
t6=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[2],t5);}}}

/* k10526 in k10422 in adjust in k10307 in k10303 in k10620 in sre->irregex in k3721 */
static void C_ccall f_10528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10528,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10507 in k10422 in adjust in k10307 in k10303 in k10620 in sre->irregex in k3721 */
static void C_ccall f_10509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10509,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[83],t1));}

/* k10431 in k10422 in adjust in k10307 in k10303 in k10620 in sre->irregex in k3721 */
static void C_ccall f_10433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10439,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10454,tmp=(C_word)a,a+=2,tmp);
/* any */
f_4643(t2,t3,t1);}

/* a10453 in k10431 in k10422 in adjust in k10307 in k10303 in k10620 in sre->irregex in k3721 */
static void C_ccall f_10454(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10454,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_fix((C_word)C_character_code(t3));
t5=(C_word)C_i_less_or_equalp(C_fix(128),t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
t7=t1;
t8=(C_word)C_fix((C_word)C_character_code(t6));
t9=t7;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_i_less_or_equalp(C_fix(128),t8));}}
else{
t3=t1;
t4=t2;
t5=(C_word)C_fix((C_word)C_character_code(t4));
t6=t3;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_less_or_equalp(C_fix(128),t5));}}

/* k10437 in k10431 in k10422 in adjust in k10307 in k10303 in k10620 in sre->irregex in k3721 */
static void C_ccall f_10439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10439,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[5])){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10449,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* cset->utf8-pattern */
f_10137(t2,((C_word*)t0)[3]);}
else{
/* cset->utf8-pattern */
f_10137(((C_word*)t0)[4],((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k10447 in k10437 in k10431 in k10422 in adjust in k10307 in k10303 in k10620 in sre->irregex in k3721 */
static void C_ccall f_10449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10449,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[174],t1));}

/* a10406 in adjust in k10307 in k10303 in k10620 in sre->irregex in k3721 */
static void C_ccall f_10407(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10407,3,t0,t1,t2);}
/* adjust1144 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10311(t3,t1,t2,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k10403 in adjust in k10307 in k10303 in k10620 in sre->irregex in k3721 */
static void C_ccall f_10405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10405,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a10379 in adjust in k10307 in k10303 in k10620 in sre->irregex in k3721 */
static void C_ccall f_10380(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10380,3,t0,t1,t2);}
/* adjust1144 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10311(t3,t1,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k10376 in adjust in k10307 in k10303 in k10620 in sre->irregex in k3721 */
static void C_ccall f_10378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10378,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* rec in adjust in k10307 in k10303 in k10620 in sre->irregex in k3721 */
static void C_ccall f_10314(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10314,3,t0,t1,t2);}
/* adjust1144 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_10311(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_10625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10625,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10628,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* sre-searcher? */
t3=lf[222];
f_11019(3,t3,t2,t1);}

/* k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_10628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10628,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10631,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
/* sre-remove-initial-bos */
t3=lf[221];
f_12743(3,t3,t2,((C_word*)t0)[4]);}
else{
t3=t2;
f_10631(2,t3,((C_word*)t0)[4]);}}

/* k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_10631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10634,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_u_i_memq(lf[219],((C_word*)t0)[2]))){
t3=t2;
f_10634(t3,C_fix(1));}
else{
t3=(C_word)C_u_i_memq(lf[220],((C_word*)t0)[2]);
t4=t2;
f_10634(t4,(C_truep(t3)?C_fix(50):C_fix(10)));}}

/* k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_fcall f_10634(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10634,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10637,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_10637(2,t3,C_SCHEME_TRUE);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10708,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_cons(&a,2,lf[80],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[83],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,lf[74],t7);
/* sre->nfa */
f_13350(t3,t8,(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}}

/* k10706 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_10708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10708,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(t1);
t3=(C_word)C_a_i_times(&a,2,((C_word*)t0)[3],t2);
/* nfa->dfa */
f_14140(((C_word*)t0)[2],t1,(C_word)C_a_i_list(&a,1,t3));}
else{
t2=((C_word*)t0)[2];
f_10637(2,t2,C_SCHEME_FALSE);}}

/* k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_10637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10640,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
/* sre->nfa */
f_13350(t2,((C_word*)t0)[7],(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]));}
else{
t3=t2;
f_10640(2,t3,C_SCHEME_FALSE);}}

/* k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_10640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10643,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_length(t1);
t4=(C_word)C_a_i_times(&a,2,((C_word*)t0)[2],t3);
/* nfa->dfa */
f_14140(t2,t1,(C_word)C_a_i_list(&a,1,t4));}
else{
t3=t2;
f_10643(2,t3,C_SCHEME_FALSE);}}

/* k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_10643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10643,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10646,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[5])){
t3=((C_word*)t0)[7];
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15238,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_15238(t7,t2,t3,C_fix(1),C_SCHEME_FALSE);}
else{
t3=t2;
f_10646(2,t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_10646(2,t3,C_SCHEME_FALSE);}}

/* lp in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_fcall f_15238(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15238,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15562,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* sre-has-submatchs? */
t6=lf[218];
f_11191(3,t6,t5,t2);}

/* k15560 in lp in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15562,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[6]))){
t2=(C_word)C_u_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(t2,lf[176]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(t2,lf[74]));
if(C_truep(t4)){
t5=(C_word)C_u_i_cddr(((C_word*)t0)[6]);
t6=f_12312(C_a_i(&a,3),t5);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15289,a[2]=((C_word*)t0)[6],a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
/* lp2370 */
t9=((C_word*)((C_word*)t0)[3])[1];
f_15238(t9,t7,t8,((C_word*)t0)[4],C_SCHEME_TRUE);}
else{
t5=(C_word)C_eqp(t2,lf[62]);
if(C_truep(t5)){
t6=(C_word)C_u_i_cddr(((C_word*)t0)[6]);
t7=f_12337(C_a_i(&a,3),t6);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_15382,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=t7,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t9=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
/* lp2370 */
t10=((C_word*)((C_word*)t0)[3])[1];
f_15238(t10,t8,t9,((C_word*)t0)[4],C_SCHEME_TRUE);}
else{
t6=(C_word)C_eqp(t2,lf[83]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t2,lf[85]));
if(C_truep(t7)){
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15432,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t11,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
t13=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t14=f_12312(C_a_i(&a,3),t13);
/* lp2370 */
t15=((C_word*)((C_word*)t0)[3])[1];
f_15238(t15,t12,t14,((C_word*)t0)[4],C_SCHEME_TRUE);}
else{
t8=(C_word)C_eqp(t2,lf[87]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15488,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t10=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t11=f_12312(C_a_i(&a,3),t10);
/* lp2370 */
t12=((C_word*)((C_word*)t0)[3])[1];
f_15238(t12,t9,t11,((C_word*)t0)[4],C_SCHEME_TRUE);}
else{
t9=(C_word)C_eqp(t2,lf[68]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15513,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t12=f_12312(C_a_i(&a,3),t11);
t13=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],C_fix(1));
/* lp2370 */
t14=((C_word*)((C_word*)t0)[3])[1];
f_15238(t14,t10,t12,t13,C_SCHEME_TRUE);}
else{
t10=(C_word)C_u_i_car(((C_word*)t0)[6]);
/* error */
t11=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,((C_word*)t0)[5],lf[213],t10);}}}}}}
else{
/* error */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[5],lf[214],((C_word*)t0)[6]);}}
else{
t2=((C_word*)t0)[2];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15256,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15265,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* sre->nfa */
f_13350(t4,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15252,tmp=(C_word)a,a+=2,tmp));}}}

/* f_15252 in k15560 in lp in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15252(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_15252,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t4);}

/* k15263 in k15560 in lp in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* nfa->dfa */
f_14140(((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k15254 in k15560 in lp in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15256,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15257,a[2]=t1,tmp=(C_word)a,a+=3,tmp));}

/* f_15257 in k15254 in k15560 in lp in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15257(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_15257,6,t0,t1,t2,t3,t4,t5);}
/* dfa-match/longest */
f_13243(t1,((C_word*)t0)[2],t2,t3,t4);}

/* k15511 in k15560 in lp in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15513,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15514,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_15514 in k15511 in k15560 in lp in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15514(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_15514,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15518,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* match-one2468 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t2,t3,t4,t5);}

/* k15516 */
static void C_ccall f_15518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15518,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15521,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_numberp(t1))){
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
t5=((C_word*)t0)[2];
t6=(C_word)C_a_i_times(&a,2,t4,C_fix(2));
t7=(C_word)C_a_i_plus(&a,2,C_fix(3),t6);
t8=(C_word)C_i_setslot(t3,t7,t5);
t9=((C_word*)t0)[4];
t10=((C_word*)t0)[3];
t11=t1;
t12=(C_word)C_a_i_times(&a,2,t10,C_fix(2));
t13=(C_word)C_a_i_plus(&a,2,C_fix(4),t12);
t14=t2;
f_15521(t14,(C_word)C_i_setslot(t9,t13,t11));}
else{
t3=t2;
f_15521(t3,C_SCHEME_UNDEFINED);}}

/* k15519 in k15516 */
static void C_fcall f_15521(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k15486 in k15560 in lp in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15488,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15489,a[2]=t1,tmp=(C_word)a,a+=3,tmp));}

/* f_15489 in k15486 in k15560 in lp in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15489(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_15489,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15493,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* match-once2457 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t2,t3,t4,t5);}

/* k15491 */
static void C_ccall f_15493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k15430 in k15560 in lp in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15432,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15434,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t4=(C_word)C_u_i_car(((C_word*)t0)[3]);
t5=(C_word)C_eqp(lf[83],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?((C_word*)((C_word*)t0)[4])[1]:(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15457,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp)));}

/* f_15457 in k15430 in k15560 in lp in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15457(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_15457,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15461,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* match-once2439 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t2,t3,t4,t5);}

/* k15459 */
static void C_ccall f_15461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* match-all2440 */
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_15434 in k15430 in k15560 in lp in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15434(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_15434,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_15438,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* match-once2439 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t2,t3,t4,t5);}

/* k15436 */
static void C_ccall f_15438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_i_lessp(((C_word*)t0)[7],t1):C_SCHEME_FALSE);
if(C_truep(t2)){
/* match-all2440 */
t3=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[7]);}}

/* k15380 in k15560 in lp in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15382,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15385,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15407,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
/* sre-count-submatches */
f_11217(t3,t4);}

/* k15405 in k15380 in k15560 in lp in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15407,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],t1);
/* lp2370 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_15238(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k15383 in k15380 in k15560 in lp in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15385,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15386,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp));}

/* f_15386 in k15383 in k15380 in k15560 in lp in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15386(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_15386,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_15390,a[2]=t5,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* match-first2427 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t2,t3,t4,t5);}

/* k15388 */
static void C_ccall f_15390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_eqvp(t1,((C_word*)t0)[7]))){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* match-rest2428 */
t2=((C_word*)t0)[5];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[7],((C_word*)t0)[2]);}}

/* k15287 in k15560 in lp in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15289,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15292,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15358,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
/* sre-count-submatches */
f_11217(t3,t4);}

/* k15356 in k15287 in k15560 in lp in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15358,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],t1);
/* lp2370 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_15238(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k15290 in k15287 in k15560 in lp in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15292,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15293,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp));}

/* f_15293 in k15290 in k15287 in k15560 in lp in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15293(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_15293,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_15299,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t7,a[7]=t4,a[8]=t3,tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t7)[1];
f_15299(t9,t1,t4,C_SCHEME_FALSE);}

/* lp */
static void C_fcall f_15299(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15299,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_lessp(t2,((C_word*)t0)[8]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_15309,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=t2,a[8]=t1,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* match-left2401 */
t5=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,((C_word*)t0)[4],((C_word*)t0)[8],t2,((C_word*)t0)[3]);}}

/* k15307 in lp */
static void C_ccall f_15309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15312,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
if(C_truep((C_word)C_i_eqvp(t1,((C_word*)t0)[7]))){
/* match-right2402 */
t3=((C_word*)t0)[4];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[3],t1,((C_word*)t0)[9],((C_word*)t0)[2]);}
else{
t3=t2;
f_15312(2,t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_15312(2,t3,C_SCHEME_FALSE);}}

/* k15310 in k15307 in lp */
static void C_ccall f_15312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15312,2,t0,t1);}
if(C_truep((C_word)C_i_eqvp(t1,((C_word*)t0)[6]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_i_not(((C_word*)t0)[3]);
t4=(C_truep(t3)?t3:(C_truep(t1)?(C_word)C_i_greaterp(t1,((C_word*)t0)[3]):C_SCHEME_FALSE));
t5=(C_truep(t4)?t1:((C_word*)t0)[3]);
/* lp2407 */
t6=((C_word*)((C_word*)t0)[2])[1];
f_15299(t6,((C_word*)t0)[5],t2,t5);}}

/* k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_10646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10649,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* sre-count-submatches */
f_11217(t2,((C_word*)t0)[8]);}

/* k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_10649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10652,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* sre-names */
f_12477(t2,((C_word*)t0)[9],C_fix(1),C_SCHEME_END_OF_LIST);}

/* k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_10652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10652,2,t0,t1);}
t2=((C_word*)t0)[10];
t3=(C_word)C_a_i_list(&a,1,t1);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_11280,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=t4;
f_11280(2,t5,(C_word)C_u_i_car(t3));}
else{
/* sre-names */
f_12477(t4,t2,C_fix(1),C_SCHEME_END_OF_LIST);}}

/* k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_11280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11280,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_11283,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12301,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* sre-count-submatches */
f_11217(t3,((C_word*)t0)[2]);}

/* k12299 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_12301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12301,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,C_fix(1),t1);
/* make-vector */
t3=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_SCHEME_FALSE);}

/* k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_11283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11283,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_11290,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11292,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_11292(t6,t2,((C_word*)t0)[2],C_fix(1),C_fix(0),C_fix(0),*((C_word*)lf[212]+1));}

/* lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_fcall f_11292(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word *a;
loop:
a=C_alloc(18);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_11292,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11295,a[2]=t6,a[3]=t5,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t8=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_stringp(t8))){
/* grow1464 */
t9=t7;
f_11295(t9,t1,C_fix(1));}
else{
t9=(C_word)C_u_i_car(t2);
t10=(C_word)C_eqp(t9,lf[25]);
t11=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_11337,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t6,a[6]=t5,a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[4],a[10]=t9,a[11]=t1,a[12]=t7,tmp=(C_word)a,a+=13,tmp);
if(C_truep(t10)){
t12=t11;
f_11337(t12,t10);}
else{
t12=(C_word)C_eqp(t9,lf[116]);
if(C_truep(t12)){
t13=t11;
f_11337(t13,t12);}
else{
t13=(C_word)C_eqp(t9,lf[183]);
t14=t11;
f_11337(t14,(C_truep(t13)?t13:(C_word)C_eqp(t9,lf[194])));}}}}
else{
if(C_truep((C_word)C_charp(t2))){
/* grow1464 */
t8=t7;
f_11295(t8,t1,C_fix(1));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t8=(C_word)C_fix((C_word)C_header_size(t2));
/* grow1464 */
t9=t7;
f_11295(t9,t1,t8);}
else{
t8=t2;
if(C_truep((C_truep((C_word)C_eqp(t8,lf[80]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t8,lf[81]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* grow1464 */
t9=t7;
f_11295(t9,t1,C_fix(1));}
else{
t9=t2;
if(C_truep((C_truep((C_word)C_eqp(t9,lf[75]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t9,lf[142]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t9,lf[143]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t9,lf[151]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t9,lf[152]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t9,lf[140]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t9,lf[139]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t9,lf[141]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t9,lf[210]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))))))))){
/* return1457 */
t10=t6;
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,t4,t5);}
else{
t10=(C_word)C_u_i_assq(t2,lf[195]);
if(C_truep(t10)){
t11=(C_word)C_slot(t10,C_fix(1));
/* lp1452 */
t20=t1;
t21=t11;
t22=t3;
t23=t4;
t24=t5;
t25=t6;
t1=t20;
t2=t21;
t3=t22;
t4=t23;
t5=t24;
t6=t25;
goto loop;}
else{
/* error */
t11=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[211],t2);}}}}}}}

/* k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_fcall f_11337(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11337,NULL,2,t0,t1);}
if(C_truep(t1)){
/* grow1464 */
t2=((C_word*)t0)[12];
f_11295(t2,((C_word*)t0)[11],C_fix(1));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[10],lf[184]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11353,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
/* string->sre */
t5=*((C_word*)lf[61]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[10],lf[74]);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_11366,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[4],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t3)){
t5=t4;
f_11366(t5,t3);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[10],lf[176]);
if(C_truep(t5)){
t6=t4;
f_11366(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[10],lf[174]);
if(C_truep(t6)){
t7=t4;
f_11366(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[10],lf[175]);
t8=t4;
f_11366(t8,(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[10],lf[187])));}}}}}}

/* k11364 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_fcall f_11366(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11366,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11375,a[2]=((C_word*)t0)[7],a[3]=t4,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_11375(t6,((C_word*)t0)[6],t2,((C_word*)t0)[5],C_fix(0),C_fix(0));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[62]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11457,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_11457(t7,((C_word*)t0)[6],t3,((C_word*)t0)[5],C_SCHEME_FALSE,C_fix(0));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[69]);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
t5=(C_word)C_i_nullp(t4);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11542,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t5)){
t7=t6;
f_11542(t7,t5);}
else{
t7=(C_word)C_u_i_cddr(((C_word*)t0)[11]);
t8=t6;
f_11542(t8,(C_word)C_i_nullp(t7));}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[192]);
if(C_truep(t4)){
t5=(C_word)C_u_i_cdddr(((C_word*)t0)[11]);
t6=f_12312(C_a_i(&a,3),t5);
t7=(C_word)C_u_i_cadr(((C_word*)t0)[11]);
t8=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],t7);
/* lp1452 */
t9=((C_word*)((C_word*)t0)[7])[1];
f_11292(t9,((C_word*)t0)[6],t6,t8,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[68]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[4],lf[77]));
if(C_truep(t6)){
t7=(C_word)C_u_i_car(((C_word*)t0)[11]);
t8=(C_word)C_eqp(lf[68],t7);
t9=(C_truep(t8)?(C_word)C_slot(((C_word*)t0)[11],C_fix(1)):(C_word)C_u_i_cddr(((C_word*)t0)[11]));
t10=f_12312(C_a_i(&a,3),t9);
t11=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1));
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11713,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* lp1452 */
t13=((C_word*)((C_word*)t0)[7])[1];
f_11292(t13,((C_word*)t0)[6],t10,t11,((C_word*)t0)[10],((C_word*)t0)[9],t12);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[147]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[146]));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11753,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t10=(C_word)C_u_i_cadr(((C_word*)t0)[11]);
if(C_truep((C_word)C_i_numberp(t10))){
t11=t9;
f_11753(2,t11,(C_word)C_u_i_cadr(((C_word*)t0)[11]));}
else{
t11=(C_word)C_u_i_cadr(((C_word*)t0)[11]);
t12=(C_word)C_u_i_assq(t11,((C_word*)t0)[2]);
if(C_truep(t12)){
t13=t9;
f_11753(2,t13,(C_word)C_slot(t12,C_fix(1)));}
else{
t13=(C_word)C_u_i_cadr(((C_word*)t0)[11]);
/* error */
t14=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t9,lf[205],t13);}}}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[83]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[4],lf[84]));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11866,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
t13=f_12312(C_a_i(&a,3),t12);
t14=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11875,tmp=(C_word)a,a+=2,tmp);
/* lp1452 */
t15=((C_word*)((C_word*)t0)[7])[1];
f_11292(t15,t11,t13,((C_word*)t0)[5],((C_word*)t0)[10],((C_word*)t0)[9],t14);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[89]);
t12=(C_truep(t11)?t11:(C_word)C_eqp(((C_word*)t0)[4],lf[86]));
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11895,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t14=(C_word)C_u_i_cadr(((C_word*)t0)[11]);
if(C_truep((C_word)C_i_numberp(t14))){
t15=(C_word)C_u_i_caddr(((C_word*)t0)[11]);
if(C_truep((C_word)C_i_numberp(t15))){
t16=(C_word)C_u_i_cadr(((C_word*)t0)[11]);
t17=(C_word)C_u_i_caddr(((C_word*)t0)[11]);
t18=t13;
f_11895(t18,(C_word)C_i_greaterp(t16,t17));}
else{
t16=t13;
f_11895(t16,C_SCHEME_FALSE);}}
else{
t15=t13;
f_11895(t15,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_eqp(((C_word*)t0)[4],lf[85]);
if(C_truep(t13)){
t14=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
t15=f_12312(C_a_i(&a,3),t14);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12039,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* lp1452 */
t17=((C_word*)((C_word*)t0)[7])[1];
f_11292(t17,((C_word*)t0)[6],t15,((C_word*)t0)[5],((C_word*)t0)[10],((C_word*)t0)[9],t16);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[4],lf[87]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(((C_word*)t0)[4],lf[88]));
if(C_truep(t15)){
t16=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
t17=f_12312(C_a_i(&a,3),t16);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12069,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* lp1452 */
t19=((C_word*)((C_word*)t0)[7])[1];
f_11292(t19,((C_word*)t0)[6],t17,((C_word*)t0)[5],((C_word*)t0)[10],((C_word*)t0)[9],t18);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[4],lf[90]);
t17=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12096,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t16)){
t18=t17;
f_12096(t18,t16);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[4],lf[208]);
if(C_truep(t18)){
t19=t17;
f_12096(t19,t18);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[4],lf[91]);
t20=t17;
f_12096(t20,(C_truep(t19)?t19:(C_word)C_eqp(((C_word*)t0)[4],lf[209])));}}}}}}}}}}}}}

/* k12094 in k11364 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_fcall f_12096(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12096,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
t3=(C_word)C_u_i_car(((C_word*)t0)[9]);
t4=(C_word)C_u_i_memq(t3,lf[206]);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_u_i_cadr(((C_word*)t0)[9]));
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12123,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=t5,tmp=(C_word)a,a+=10,tmp);
t7=(C_word)C_u_i_cddr(((C_word*)t0)[9]);
/* ##sys#append */
t8=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[2],lf[70]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12146,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_12146(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[2],lf[71]);
if(C_truep(t4)){
t5=t3;
f_12146(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[2],lf[72]);
t6=t3;
f_12146(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[2],lf[73])));}}}}

/* k12144 in k12094 in k11364 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_fcall f_12146(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* return1457 */
t2=((C_word*)t0)[6];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* error */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[5],lf[207],((C_word*)t0)[2]);}}

/* k12121 in k12094 in k11364 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_12123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12123,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[89],t3);
/* lp1452 */
t5=((C_word*)((C_word*)t0)[7])[1];
f_11292(t5,((C_word*)t0)[6],t4,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a12068 in k11364 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_12069(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12069,4,t0,t1,t2,t3);}
t4=(C_truep(((C_word*)t0)[4])?(C_truep(t3)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],t3):C_SCHEME_FALSE):C_SCHEME_FALSE);
/* return1457 */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,((C_word*)t0)[2],t4);}

/* a12038 in k11364 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_12039(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12039,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],t2);
/* return1457 */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,C_SCHEME_FALSE);}

/* k11893 in k11364 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_fcall f_11895(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11895,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11898,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
t3=t2;
f_11898(t3,t1);}
else{
t3=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t4=t2;
f_11898(t4,(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_u_i_caddr(((C_word*)t0)[4])));}}

/* k11896 in k11893 in k11364 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_fcall f_11898(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11898,NULL,2,t0,t1);}
if(C_truep(t1)){
/* return1457 */
t2=((C_word*)t0)[8];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_u_i_caddr(((C_word*)t0)[4]))){
t2=(C_word)C_u_i_cdddr(((C_word*)t0)[4]);
t3=f_12312(C_a_i(&a,3),t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11916,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* lp1452 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_11292(t5,((C_word*)t0)[7],t3,((C_word*)t0)[2],C_fix(0),C_fix(0),t4);}
else{
t2=(C_word)C_u_i_cdddr(((C_word*)t0)[4]);
t3=f_12312(C_a_i(&a,3),t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11963,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lp1452 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_11292(t5,((C_word*)t0)[7],t3,((C_word*)t0)[2],C_fix(0),C_fix(0),t4);}}}

/* a11962 in k11896 in k11893 in k11364 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_11963(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11963,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t5=(C_word)C_a_i_times(&a,2,t4,t2);
t6=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],t5);
/* return1457 */
t7=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,C_SCHEME_FALSE);}

/* a11915 in k11896 in k11893 in k11364 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_11916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11916,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_times(&a,2,t4,t2);
t6=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11928,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
if(C_truep(t3)){
t8=(C_word)C_u_i_caddr(((C_word*)t0)[5]);
t9=(C_word)C_a_i_times(&a,2,t8,t3);
t10=t7;
f_11928(t10,(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],t9));}
else{
t8=t7;
f_11928(t8,C_SCHEME_FALSE);}}
else{
t8=t7;
f_11928(t8,C_SCHEME_FALSE);}}

/* k11926 in a11915 in k11896 in k11893 in k11364 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_fcall f_11928(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* return1457 */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a11874 in k11364 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_11875(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11875,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}

/* k11864 in k11364 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_11866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* return1457 */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k11751 in k11364 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_11753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11753,2,t0,t1);}
t2=(C_word)C_i_integerp(t1);
t3=(C_word)C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11762,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t5=t4;
f_11762(t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11816,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[5]));
/* < */
C_lessp(5,0,t5,C_fix(0),t1,t6);}}

/* k11814 in k11751 in k11364 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_11816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_11762(t2,(C_word)C_i_not(t1));}

/* k11760 in k11751 in k11364 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_fcall f_11762(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11762,NULL,2,t0,t1);}
if(C_truep(t1)){
/* error */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[8],lf[203],((C_word*)t0)[7]);}
else{
if(C_truep((C_word)C_slot(((C_word*)t0)[6],((C_word*)t0)[5]))){
t2=(C_word)C_slot(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(((C_word*)t0)[6],((C_word*)t0)[5]);
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],t3);
t7=(C_truep(((C_word*)t0)[3])?(C_truep(t5)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],t5):C_SCHEME_FALSE):C_SCHEME_FALSE);
/* return1457 */
t8=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[8],t6,t7);}
else{
/* error */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[8],lf[204],((C_word*)t0)[7]);}}}

/* a11712 in k11364 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_11713(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11713,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t4);
/* return1457 */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t2,t3);}

/* k11540 in k11364 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_fcall f_11542(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11542,NULL,2,t0,t1);}
if(C_truep(t1)){
/* return1457 */
t2=((C_word*)t0)[8];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11548,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[4]);
/* sre-count-submatches */
f_11217(t2,t3);}}

/* k11546 in k11540 in k11364 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_11548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11551,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
/* sre-count-submatches */
f_11217(t2,t3);}

/* k11549 in k11546 in k11540 in k11364 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_11551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11551,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
t3=(C_word)C_i_numberp(t2);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11633,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t3)){
t5=t4;
f_11633(t5,t3);}
else{
t5=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
t6=t4;
f_11633(t6,(C_word)C_i_symbolp(t5));}}

/* k11631 in k11549 in k11546 in k11540 in k11364 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_fcall f_11633(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11633,NULL,2,t0,t1);}
t2=(C_truep(t1)?lf[75]:(C_word)C_u_i_cadr(((C_word*)t0)[10]));
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11560,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* lp1452 */
t4=((C_word*)((C_word*)t0)[6])[1];
f_11292(t4,((C_word*)t0)[4],t2,((C_word*)t0)[9],((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a11559 in k11631 in k11549 in k11546 in k11540 in k11364 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_11560(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11560,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11574,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=t2,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* lp1452 */
t7=((C_word*)((C_word*)t0)[3])[1];
f_11292(t7,t1,t4,t5,C_fix(0),C_fix(0),t6);}

/* a11573 in a11559 in k11631 in k11549 in k11546 in k11540 in k11364 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_11574(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11574,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_cdddr(((C_word*)t0)[9]);
t5=(C_word)C_i_pairp(t4);
t6=(C_truep(t5)?(C_word)C_u_i_cadddr(((C_word*)t0)[9]):lf[75]);
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11586,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=t3,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* + */
C_plus(5,0,t7,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11584 in a11573 in a11559 in k11631 in k11549 in k11546 in k11540 in k11364 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_11586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11588,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* lp1452 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_11292(t3,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_fix(0),C_fix(0),t2);}

/* a11587 in k11584 in a11573 in a11559 in k11631 in k11549 in k11546 in k11540 in k11364 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_11588(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11588,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11617,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* min */
t5=*((C_word*)lf[202]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],t2);}

/* k11615 in a11587 in k11584 in a11573 in a11559 in k11631 in k11549 in k11546 in k11540 in k11364 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_11617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11617,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11600,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
if(C_truep(((C_word*)t0)[3])){
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11613,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* max */
t5=*((C_word*)lf[201]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t4=t3;
f_11600(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_11600(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_11600(t4,C_SCHEME_FALSE);}}

/* k11611 in k11615 in a11587 in k11584 in a11573 in a11559 in k11631 in k11549 in k11546 in k11540 in k11364 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_11613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11613,2,t0,t1);}
t2=((C_word*)t0)[3];
f_11600(t2,(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],t1));}

/* k11598 in k11615 in a11587 in k11584 in a11573 in a11559 in k11631 in k11549 in k11546 in k11540 in k11364 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_fcall f_11600(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* return1457 */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* lp2 in k11364 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_fcall f_11457(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11457,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],t4);
t7=(C_truep(((C_word*)t0)[5])?(C_truep(t5)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],t5):C_SCHEME_FALSE):C_SCHEME_FALSE);
/* return1457 */
t8=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,t6,t7);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11490,a[2]=t4,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* lp1452 */
t8=((C_word*)((C_word*)t0)[2])[1];
f_11292(t8,t1,t6,t3,C_fix(0),C_fix(0),t7);}}

/* a11489 in lp2 in k11364 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_11490(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11490,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11523,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t4,a[7]=t1,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
t6=(C_word)C_u_i_car(((C_word*)t0)[6]);
/* sre-count-submatches */
f_11217(t5,t6);}

/* k11521 in a11489 in lp2 in k11364 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_11523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11523,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11506,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
/* min */
t4=*((C_word*)lf[202]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t4=t3;
f_11506(2,t4,((C_word*)t0)[2]);}}

/* k11504 in k11521 in a11489 in lp2 in k11364 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_11506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11506,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11510,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep(((C_word*)t0)[2])){
/* max */
t3=*((C_word*)lf[201]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=t2;
f_11510(2,t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_11510(2,t3,C_SCHEME_FALSE);}}

/* k11508 in k11504 in k11521 in a11489 in lp2 in k11364 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_11510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp21524 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_11457(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* lp2 in k11364 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_fcall f_11375(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11375,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],t4);
t7=(C_truep(((C_word*)t0)[5])?(C_truep(t5)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],t5):C_SCHEME_FALSE):C_SCHEME_FALSE);
/* return1457 */
t8=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,t6,t7);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11408,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* lp1452 */
t8=((C_word*)((C_word*)t0)[2])[1];
f_11292(t8,t1,t6,t3,C_fix(0),C_fix(0),t7);}}

/* a11407 in lp2 in k11364 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_11408(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11408,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11438,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t2,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
t6=(C_word)C_u_i_car(((C_word*)t0)[6]);
/* sre-count-submatches */
f_11217(t5,t6);}

/* k11436 in a11407 in lp2 in k11364 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_11438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11438,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[8],((C_word*)t0)[7]);
t4=(C_truep(((C_word*)t0)[6])?(C_truep(((C_word*)t0)[5])?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]):C_SCHEME_FALSE):C_SCHEME_FALSE);
/* lp21508 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_11375(t5,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3,t4);}

/* k11351 in k11335 in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_11353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp1452 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_11292(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* grow in lp in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_fcall f_11295(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11295,NULL,3,t0,t1,t2);}
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],t2);
t4=(C_truep(((C_word*)t0)[3])?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],t2):C_SCHEME_FALSE);
/* return1457 */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_11290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11290,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[11],C_fix(0),t1);
t3=((C_word*)t0)[11];
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10658,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10674,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_truep(((C_word*)t0)[2])?C_fix(1):C_SCHEME_FALSE);
/* flag-join */
t7=lf[47];
f_4987(4,t7,t5,C_fix(0),t6);}

/* k10672 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_10674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10674,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10681,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* sre-consumer? */
t3=lf[200];
f_11105(3,t3,t2,((C_word*)t0)[2]);}

/* k10679 in k10672 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_10681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?C_fix(2):C_SCHEME_FALSE);
/* flag-join */
t3=lf[47];
f_4987(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_10658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10658,2,t0,t1);}
if(C_truep(((C_word*)t0)[10])){
t2=((C_word*)t0)[9];
t3=((C_word*)t0)[10];
t4=((C_word*)t0)[8];
t5=((C_word*)t0)[7];
t6=t1;
t7=((C_word*)t0)[6];
t8=((C_word*)t0)[5];
t9=t2;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_vector(&a,9,lf[1],t3,t4,t5,C_SCHEME_FALSE,t6,t7,((C_word*)t0)[4],t8));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10667,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[3];
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],((C_word*)t0)[5]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15569,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17528,a[2]=t3,a[3]=t4,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t9=(C_word)C_slot(t4,C_fix(1));
t10=t8;
f_17528(t10,(C_word)C_i_pairp(t9));}
else{
t9=t8;
f_17528(t9,C_SCHEME_FALSE);}}}

/* k17526 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_fcall f_17528(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_15569(2,t2,(C_word)C_u_i_cadr(((C_word*)t0)[3]));}
else{
/* sre-names */
f_12477(((C_word*)t0)[4],((C_word*)t0)[2],C_fix(1),C_SCHEME_END_OF_LIST);}}

/* k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15569,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_i_pairp(((C_word*)t0)[4]);
t4=(C_truep(t3)?(C_word)C_u_i_car(((C_word*)t0)[4]):C_fix(0));
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15578,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15581,a[2]=((C_word*)t0)[5],a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_15581(t9,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(1),t4,t5);}

/* lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_fcall f_15581(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15581,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15584,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_stringp(t7))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15607,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_u_i_car(t2);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15615,a[2]=t9,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* flag-set? */
f_4977(t10,t4,C_fix(2));}
else{
t8=(C_word)C_u_i_car(t2);
t9=(C_word)C_eqp(t8,lf[116]);
t10=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_15627,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t6,a[6]=t8,a[7]=t4,a[8]=t2,a[9]=t5,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t9)){
t11=t10;
f_15627(t11,t9);}
else{
t11=(C_word)C_eqp(t8,lf[194]);
if(C_truep(t11)){
t12=t10;
f_15627(t12,t11);}
else{
t12=(C_word)C_eqp(t8,lf[183]);
t13=t10;
f_15627(t13,(C_truep(t12)?t12:(C_word)C_eqp(t8,lf[25])));}}}}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t7=t2;
t8=(C_word)C_eqp(t7,lf[80]);
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_17041,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t9=(C_word)C_eqp(t7,lf[81]);
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_17069,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t10=(C_word)C_eqp(t7,lf[142]);
if(C_truep(t10)){
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_17111,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t11=(C_word)C_eqp(t7,lf[151]);
if(C_truep(t11)){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_17131,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t12=(C_word)C_eqp(t7,lf[140]);
if(C_truep(t12)){
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_17165,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t13=(C_word)C_eqp(t7,lf[143]);
if(C_truep(t13)){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_17223,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t14=(C_word)C_eqp(t7,lf[152]);
if(C_truep(t14)){
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_17247,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t15=(C_word)C_eqp(t7,lf[139]);
if(C_truep(t15)){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_17281,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t16=(C_word)C_eqp(t7,lf[141]);
if(C_truep(t16)){
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_17339,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t17=(C_word)C_eqp(t7,lf[75]);
if(C_truep(t17)){
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,t5);}
else{
t18=(C_word)C_u_i_assq(t2,lf[195]);
if(C_truep(t18)){
t19=(C_word)C_slot(t18,C_fix(1));
/* rec2500 */
t20=t6;
f_15584(t20,t1,t19);}
else{
/* error */
t19=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t19+1)))(4,t19,t1,lf[196],t2);}}}}}}}}}}}}
else{
if(C_truep((C_word)C_charp(t2))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17435,a[2]=t2,a[3]=t5,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* flag-set? */
f_4977(t7,t4,C_fix(2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17516,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t8=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
/* error */
t7=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,lf[198],t2);}}}}}

/* k17514 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_17516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17516,2,t0,t1);}
t2=f_12312(C_a_i(&a,3),t1);
/* rec2500 */
t3=((C_word*)t0)[3];
f_15584(t3,((C_word*)t0)[2],t2);}

/* k17433 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_17435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17435,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17436,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17468,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp)));}

/* f_17468 in k17433 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_17468(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17468,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_17475,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_fix((C_word)C_header_size(t2));
if(C_truep((C_word)C_i_lessp(t3,t7))){
t8=(C_word)C_subchar(t2,t3);
t9=t6;
f_17475(t9,(C_word)C_i_eqvp(((C_word*)t0)[2],t8));}
else{
t8=t6;
f_17475(t8,C_SCHEME_FALSE);}}

/* k17473 */
static void C_fcall f_17475(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_17475,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
/* next2493 */
t3=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail2871 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}

/* f_17436 in k17433 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_17436(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17436,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_17443,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_fix((C_word)C_header_size(t2));
if(C_truep((C_word)C_i_lessp(t3,t7))){
t8=(C_word)C_subchar(t2,t3);
/* char-ci=? */
t9=*((C_word*)lf[197]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,((C_word*)t0)[2],t8);}
else{
t8=t6;
f_17443(2,t8,C_SCHEME_FALSE);}}

/* k17441 */
static void C_ccall f_17443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17443,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
/* next2493 */
t3=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail2865 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}

/* f_17339 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_17339(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17339,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_17346,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_zerop(t3))){
t7=t6;
f_17346(t7,C_SCHEME_FALSE);}
else{
t7=(C_word)C_fix((C_word)C_header_size(t2));
if(C_truep((C_word)C_i_lessp(t3,t7))){
t8=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
t9=(C_word)C_subchar(t2,t8);
t10=(C_word)C_u_i_char_alphabeticp(t9);
t11=(C_truep(t10)?t10:(C_word)C_u_i_char_numericp(t9));
if(C_truep(t11)){
t12=(C_word)C_subchar(t2,t3);
t13=(C_word)C_u_i_char_alphabeticp(t12);
t14=t6;
f_17346(t14,(C_truep(t13)?t13:(C_word)C_u_i_char_numericp(t12)));}
else{
t12=(C_word)C_subchar(t2,t3);
t13=(C_word)C_u_i_char_alphabeticp(t12);
t14=(C_truep(t13)?t13:(C_word)C_u_i_char_numericp(t12));
t15=t6;
f_17346(t15,(C_word)C_i_not(t14));}}
else{
t8=t6;
f_17346(t8,C_SCHEME_FALSE);}}}

/* k17344 */
static void C_fcall f_17346(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* next2493 */
t2=((C_word*)t0)[7];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail2856 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}}

/* f_17281 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_17281(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17281,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_17288,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_fix((C_word)C_header_size(t2));
t8=(C_word)C_i_greater_or_equalp(t3,t7);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17300,a[2]=t6,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t8)){
t10=t9;
f_17300(t10,t8);}
else{
t10=(C_word)C_subchar(t2,t3);
t11=(C_word)C_u_i_char_alphabeticp(t10);
t12=(C_truep(t11)?t11:(C_word)C_u_i_char_numericp(t10));
t13=t9;
f_17300(t13,(C_word)C_i_not(t12));}}

/* k17298 */
static void C_fcall f_17300(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_17300,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_greaterp(((C_word*)t0)[4],C_fix(0)))){
t2=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
t4=(C_word)C_u_i_char_alphabeticp(t3);
t5=((C_word*)t0)[2];
f_17288(t5,(C_truep(t4)?t4:(C_word)C_u_i_char_numericp(t3)));}
else{
t2=((C_word*)t0)[2];
f_17288(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
f_17288(t2,C_SCHEME_FALSE);}}

/* k17286 */
static void C_fcall f_17288(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* next2493 */
t2=((C_word*)t0)[7];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail2843 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}}

/* f_17247 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_17247(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17247,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_fix((C_word)C_header_size(t2));
t7=(C_word)C_i_greater_or_equalp(t3,t6);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_17257,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t7)){
t9=t8;
f_17257(t9,t7);}
else{
t9=(C_word)C_subchar(t2,t3);
t10=t8;
f_17257(t10,(C_word)C_eqp(C_make_character(10),t9));}}

/* k17255 */
static void C_fcall f_17257(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* next2493 */
t2=((C_word*)t0)[7];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail2834 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}}

/* f_17223 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_17223(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17223,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_fix((C_word)C_header_size(t2));
if(C_truep((C_word)C_i_greater_or_equalp(t3,t6))){
/* next2493 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t5);}
else{
/* fail2830 */
t7=t5;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t1);}}

/* f_17165 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_17165(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17165,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_17172,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_i_zerop(t3);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17184,a[2]=t6,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t7)){
t9=t8;
f_17184(t9,t7);}
else{
t9=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
t10=(C_word)C_subchar(t2,t9);
t11=(C_word)C_u_i_char_alphabeticp(t10);
t12=(C_truep(t11)?t11:(C_word)C_u_i_char_numericp(t10));
t13=t8;
f_17184(t13,(C_word)C_i_not(t12));}}

/* k17182 */
static void C_fcall f_17184(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[4]));
if(C_truep((C_word)C_i_lessp(((C_word*)t0)[3],t2))){
t3=(C_word)C_subchar(((C_word*)t0)[4],((C_word*)t0)[3]);
t4=(C_word)C_u_i_char_alphabeticp(t3);
t5=((C_word*)t0)[2];
f_17172(t5,(C_truep(t4)?t4:(C_word)C_u_i_char_numericp(t3)));}
else{
t3=((C_word*)t0)[2];
f_17172(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
f_17172(t2,C_SCHEME_FALSE);}}

/* k17170 */
static void C_fcall f_17172(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* next2493 */
t2=((C_word*)t0)[7];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail2817 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}}

/* f_17131 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_17131(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17131,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_zerop(t3);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_17141,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_17141(t8,t6);}
else{
t8=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
t9=(C_word)C_subchar(t2,t8);
t10=t7;
f_17141(t10,(C_word)C_eqp(C_make_character(10),t9));}}

/* k17139 */
static void C_fcall f_17141(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* next2493 */
t2=((C_word*)t0)[7];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail2808 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}}

/* f_17111 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_17111(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17111,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_zerop(t3))){
/* next2493 */
t6=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,t2,t3,t4,t5);}
else{
/* fail2804 */
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}}

/* f_17069 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_17069(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17069,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_17076,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[2],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_fix((C_word)C_header_size(t2));
if(C_truep((C_word)C_i_lessp(t3,t7))){
t8=(C_word)C_subchar(t2,t3);
t9=(C_word)C_eqp(C_make_character(10),t8);
t10=t6;
f_17076(t10,(C_word)C_i_not(t9));}
else{
t8=t6;
f_17076(t8,C_SCHEME_FALSE);}}

/* k17074 */
static void C_fcall f_17076(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_17076,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
/* next2493 */
t3=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail2798 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}

/* f_17041 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_17041(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17041,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_fix((C_word)C_header_size(t2));
if(C_truep((C_word)C_i_lessp(t3,t6))){
t7=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
/* next2493 */
t8=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t1,t2,t7,t4,t5);}
else{
/* fail2794 */
t7=t5;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t1);}}

/* k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_fcall f_15627(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15627,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15634,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15638,a[2]=((C_word*)t0)[8],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* flag-set? */
f_4977(t3,((C_word*)t0)[7],C_fix(2));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[62]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t4=(C_word)C_i_length(t3);
switch(t4){
case C_fix(0):
t5=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15654,tmp=(C_word)a,a+=2,tmp));
case C_fix(1):
t5=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
/* rec2500 */
t6=((C_word*)t0)[5];
f_15584(t6,((C_word*)t0)[10],t5);
default:
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_15674,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
/* rec2500 */
t7=((C_word*)t0)[5];
f_15584(t7,t5,t6);}}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],lf[174]);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t5=f_12312(C_a_i(&a,3),t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15733,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* flag-clear */
t7=lf[48];
f_4996(4,t7,t6,((C_word*)t0)[7],C_fix(2));}
else{
t4=(C_word)C_eqp(((C_word*)t0)[6],lf[175]);
if(C_truep(t4)){
t5=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t6=f_12312(C_a_i(&a,3),t5);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15754,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* flag-join */
t8=lf[47];
f_4987(4,t8,t7,((C_word*)t0)[7],C_fix(2));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[6],lf[110]);
if(C_truep(t5)){
t6=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t7=f_12312(C_a_i(&a,3),t6);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15775,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* flag-join */
t9=lf[47];
f_4987(4,t9,t8,((C_word*)t0)[7],C_fix(32));}
else{
t6=(C_word)C_eqp(((C_word*)t0)[6],lf[111]);
if(C_truep(t6)){
t7=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t8=f_12312(C_a_i(&a,3),t7);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15796,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=t8,a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* flag-clear */
t10=lf[48];
f_4996(4,t10,t9,((C_word*)t0)[7],C_fix(32));}
else{
t7=(C_word)C_eqp(((C_word*)t0)[6],lf[74]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[6],lf[176]));
if(C_truep(t8)){
t9=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t10=(C_word)C_i_length(t9);
switch(t10){
case C_fix(0):
t11=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,((C_word*)t0)[9]);
case C_fix(1):
t11=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
/* rec2500 */
t12=((C_word*)t0)[5];
f_15584(t12,((C_word*)t0)[10],t11);
default:
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15834,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t12=(C_word)C_u_i_cddr(((C_word*)t0)[8]);
t13=f_12312(C_a_i(&a,3),t12);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_15853,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[7],a[4]=t13,a[5]=t11,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t15=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
/* sre-count-submatches */
f_11217(t14,t15);}}
else{
t9=(C_word)C_eqp(((C_word*)t0)[6],lf[87]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15874,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t12=f_12312(C_a_i(&a,3),t11);
/* rec2500 */
t13=((C_word*)t0)[5];
f_15584(t13,t10,t12);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[6],lf[88]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15902,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t13=f_12312(C_a_i(&a,3),t12);
/* rec2500 */
t14=((C_word*)t0)[5];
f_15584(t14,t11,t13);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[6],lf[83]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_15933,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t13=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t14=f_12312(C_a_i(&a,3),t13);
/* sre-empty? */
t15=lf[95];
f_10759(3,t15,t12,t14);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[6],lf[84]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_15991,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t14=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t15=f_12312(C_a_i(&a,3),t14);
/* sre-empty? */
t16=lf[95];
f_10759(3,t16,t13,t15);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[6],lf[85]);
if(C_truep(t13)){
t14=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t15=f_12312(C_a_i(&a,3),t14);
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16054,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=t15,a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t17=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t18=f_12312(C_a_i(&a,3),t17);
t19=(C_word)C_a_i_list(&a,2,lf[83],t18);
/* rec2500 */
t20=((C_word*)t0)[5];
f_15584(t20,t16,t19);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[6],lf[90]);
if(C_truep(t14)){
t15=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t16=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16103,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[5],a[4]=t15,a[5]=t16,tmp=(C_word)a,a+=6,tmp);
t18=(C_word)C_u_i_cddr(((C_word*)t0)[8]);
/* ##sys#append */
t19=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t19+1)))(4,t19,t17,t18,C_SCHEME_END_OF_LIST);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[6],lf[91]);
if(C_truep(t15)){
t16=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16136,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[5],a[4]=t16,tmp=(C_word)a,a+=5,tmp);
t18=(C_word)C_u_i_cddr(((C_word*)t0)[8]);
/* ##sys#append */
t19=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t19+1)))(4,t19,t17,t18,C_SCHEME_END_OF_LIST);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[6],lf[89]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(((C_word*)t0)[6],lf[86]));
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_16155,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t19=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
if(C_truep((C_word)C_i_numberp(t19))){
t20=(C_word)C_u_i_caddr(((C_word*)t0)[8]);
if(C_truep((C_word)C_i_numberp(t20))){
t21=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t22=(C_word)C_u_i_caddr(((C_word*)t0)[8]);
t23=t18;
f_16155(t23,(C_word)C_i_greaterp(t21,t22));}
else{
t21=t18;
f_16155(t21,C_SCHEME_FALSE);}}
else{
t20=t18;
f_16155(t20,C_SCHEME_FALSE);}}
else{
t18=(C_word)C_eqp(((C_word*)t0)[6],lf[180]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16342,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t20=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t21=(C_word)C_a_i_cons(&a,2,lf[139],C_SCHEME_END_OF_LIST);
/* ##sys#append */
t22=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t22+1)))(4,t22,t19,t20,t21);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[6],lf[181]);
if(C_truep(t19)){
t20=(C_word)C_a_i_cons(&a,2,lf[182],C_SCHEME_END_OF_LIST);
t21=(C_word)C_a_i_cons(&a,2,lf[137],t20);
t22=(C_word)C_a_i_cons(&a,2,lf[62],t21);
t23=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16407,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[5],a[4]=t22,tmp=(C_word)a,a+=5,tmp);
t24=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
/* ##sys#append */
t25=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t25+1)))(4,t25,t23,t24,C_SCHEME_END_OF_LIST);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[6],lf[184]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16432,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t22=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
/* string->sre */
t23=*((C_word*)lf[61]+1);
((C_proc3)(void*)(*((C_word*)t23+1)))(3,t23,t21,t22);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[6],lf[70]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16445,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t23=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t24=f_12312(C_a_i(&a,3),t23);
t25=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16468,tmp=(C_word)a,a+=2,tmp);
/* lp2489 */
t26=((C_word*)((C_word*)t0)[3])[1];
f_15581(t26,t22,t24,((C_word*)t0)[4],((C_word*)t0)[7],t25);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[6],lf[71]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16482,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t24=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t25=f_12312(C_a_i(&a,3),t24);
t26=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16505,tmp=(C_word)a,a+=2,tmp);
/* lp2489 */
t27=((C_word*)((C_word*)t0)[3])[1];
f_15581(t27,t23,t25,((C_word*)t0)[4],((C_word*)t0)[7],t26);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[6],lf[72]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16519,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t25=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t26=(C_word)C_a_i_cons(&a,2,lf[185],t25);
t27=f_12312(C_a_i(&a,3),t26);
t28=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16550,tmp=(C_word)a,a+=2,tmp);
/* lp2489 */
t29=((C_word*)((C_word*)t0)[3])[1];
f_15581(t29,t24,t27,((C_word*)t0)[4],((C_word*)t0)[7],t28);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[6],lf[73]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16568,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t26=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t27=(C_word)C_a_i_cons(&a,2,lf[186],t26);
t28=f_12312(C_a_i(&a,3),t27);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16599,tmp=(C_word)a,a+=2,tmp);
/* lp2489 */
t30=((C_word*)((C_word*)t0)[3])[1];
f_15581(t30,t25,t28,((C_word*)t0)[4],((C_word*)t0)[7],t29);}
else{
t25=(C_word)C_eqp(((C_word*)t0)[6],lf[187]);
if(C_truep(t25)){
t26=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16617,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t27=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t28=f_12312(C_a_i(&a,3),t27);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16640,tmp=(C_word)a,a+=2,tmp);
/* lp2489 */
t30=((C_word*)((C_word*)t0)[3])[1];
f_15581(t30,t26,t28,((C_word*)t0)[4],((C_word*)t0)[7],t29);}
else{
t26=(C_word)C_eqp(((C_word*)t0)[6],lf[69]);
if(C_truep(t26)){
t27=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_16654,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t28=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
/* sre-count-submatches */
f_11217(t27,t28);}
else{
t27=(C_word)C_eqp(((C_word*)t0)[6],lf[147]);
t28=(C_truep(t27)?t27:(C_word)C_eqp(((C_word*)t0)[6],lf[146]));
if(C_truep(t28)){
t29=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16796,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t30=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
if(C_truep((C_word)C_i_numberp(t30))){
t31=t29;
f_16796(2,t31,(C_word)C_u_i_cadr(((C_word*)t0)[8]));}
else{
t31=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t32=(C_word)C_u_i_assq(t31,((C_word*)((C_word*)t0)[2])[1]);
if(C_truep(t32)){
t33=t29;
f_16796(2,t33,(C_word)C_slot(t32,C_fix(1)));}
else{
t33=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
/* error */
t34=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t34+1)))(4,t34,t29,lf[191],t33);}}}
else{
t29=(C_word)C_eqp(((C_word*)t0)[6],lf[192]);
if(C_truep(t29)){
t30=(C_word)C_u_i_cdddr(((C_word*)t0)[8]);
t31=f_12312(C_a_i(&a,3),t30);
t32=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t33=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],t32);
/* lp2489 */
t34=((C_word*)((C_word*)t0)[3])[1];
f_15581(t34,((C_word*)t0)[10],t31,t33,((C_word*)t0)[7],((C_word*)t0)[9]);}
else{
t30=(C_word)C_eqp(((C_word*)t0)[6],lf[68]);
if(C_truep(t30)){
t31=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16923,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t32=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t33=f_12312(C_a_i(&a,3),t32);
t34=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],C_fix(1));
t35=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16953,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lp2489 */
t36=((C_word*)((C_word*)t0)[3])[1];
f_15581(t36,t31,t33,t34,((C_word*)t0)[7],t35);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[6],lf[77]);
if(C_truep(t31)){
t32=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16993,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t33=(C_word)C_u_i_cddr(((C_word*)t0)[8]);
/* ##sys#append */
t34=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t34+1)))(4,t34,t32,t33,C_SCHEME_END_OF_LIST);}
else{
/* error */
t32=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t32+1)))(4,t32,((C_word*)t0)[10],lf[193],((C_word*)t0)[8]);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k16991 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16993,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[68],t1);
/* rec2500 */
t3=((C_word*)t0)[3];
f_15584(t3,((C_word*)t0)[2],t2);}

/* a16952 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16953(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16953,6,t0,t1,t2,t3,t4,t5);}
t6=t4;
t7=((C_word*)t0)[3];
t8=(C_word)C_a_i_times(&a,2,t7,C_fix(2));
t9=(C_word)C_a_i_plus(&a,2,C_fix(4),t8);
t10=(C_word)C_slot(t6,t9);
t11=t4;
t12=((C_word*)t0)[3];
t13=t3;
t14=(C_word)C_a_i_times(&a,2,t12,C_fix(2));
t15=(C_word)C_a_i_plus(&a,2,C_fix(4),t14);
t16=(C_word)C_i_setslot(t11,t15,t13);
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16965,a[2]=t5,a[3]=t10,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* next2493 */
t18=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t18+1)))(6,t18,t1,t2,t3,t4,t17);}

/* a16964 in a16952 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16965,2,t0,t1);}
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
t4=(C_word)C_a_i_times(&a,2,t3,C_fix(2));
t5=(C_word)C_a_i_plus(&a,2,C_fix(4),t4);
t6=(C_word)C_i_setslot(t2,t5,((C_word*)t0)[3]);
/* fail2771 */
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t1);}

/* k16921 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16923,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16924,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_16924 in k16921 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16924(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16924,6,t0,t1,t2,t3,t4,t5);}
t6=t4;
t7=((C_word*)t0)[3];
t8=(C_word)C_a_i_times(&a,2,t7,C_fix(2));
t9=(C_word)C_a_i_plus(&a,2,C_fix(3),t8);
t10=(C_word)C_slot(t6,t9);
t11=t4;
t12=((C_word*)t0)[3];
t13=t3;
t14=(C_word)C_a_i_times(&a,2,t12,C_fix(2));
t15=(C_word)C_a_i_plus(&a,2,C_fix(3),t14);
t16=(C_word)C_i_setslot(t11,t15,t13);
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16936,a[2]=t5,a[3]=t10,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* body2767 */
t18=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t18+1)))(6,t18,t1,t2,t3,t4,t17);}

/* a16935 */
static void C_ccall f_16936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16936,2,t0,t1);}
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
t4=(C_word)C_a_i_times(&a,2,t3,C_fix(2));
t5=(C_word)C_a_i_plus(&a,2,C_fix(3),t4);
t6=(C_word)C_i_setslot(t2,t5,((C_word*)t0)[3]);
/* fail2778 */
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t1);}

/* k16794 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16796,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(t2,lf[146]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16852,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=t4;
f_16852(2,t5,t3);}
else{
/* flag-set? */
f_4977(t4,((C_word*)t0)[2],C_fix(2));}}

/* k16850 in k16794 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16852,2,t0,t1);}
t2=(C_truep(t1)?*((C_word*)lf[189]+1):*((C_word*)lf[190]+1));
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16800,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_16800 in k16850 in k16794 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16800(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16800,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_16804,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=t4,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* irregex-match-substring */
t7=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t4,((C_word*)t0)[2]);}

/* k16802 */
static void C_ccall f_16804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16804,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(C_word)C_fix((C_word)C_header_size(t1));
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[8],t3);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_16822,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[5]));
if(C_truep((C_word)C_i_less_or_equalp(t4,t6))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16838,a[2]=t1,a[3]=t5,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* substring */
t8=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,((C_word*)t0)[5],((C_word*)t0)[8],t4);}
else{
t7=t5;
f_16822(2,t7,C_SCHEME_FALSE);}}
else{
/* fail2762 */
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[6]);}}

/* k16836 in k16802 */
static void C_ccall f_16838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compare2745 */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k16820 in k16802 */
static void C_ccall f_16822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* next2493 */
t2=((C_word*)t0)[7];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail2762 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}}

/* k16652 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16654,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_16657,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[8]);
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],t1);
/* lp2489 */
t5=((C_word*)((C_word*)t0)[5])[1];
f_15581(t5,t2,t3,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* k16655 in k16652 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_16660,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_u_i_cdddr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_cadddr(((C_word*)t0)[9]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16755,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t2,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16759,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_u_i_caddr(((C_word*)t0)[9]);
/* sre-count-submatches */
f_11217(t6,t7);}
else{
t4=t2;
f_16660(2,t4,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16764,tmp=(C_word)a,a+=2,tmp));}}

/* f_16764 in k16655 in k16652 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16764(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16764,6,t0,t1,t2,t3,t4,t5);}
/* fail2709 */
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* k16757 in k16655 in k16652 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* + */
C_plus(5,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k16753 in k16655 in k16652 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2489 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_15581(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k16658 in k16655 in k16652 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16660,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t3=(C_word)C_i_numberp(t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_16669,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t3)){
t5=t4;
f_16669(t5,t3);}
else{
t5=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t6=t4;
f_16669(t6,(C_word)C_i_symbolp(t5));}}

/* k16667 in k16658 in k16655 in k16652 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_fcall f_16669(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16669,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16672,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
t5=(C_word)C_u_i_assq(t4,((C_word*)((C_word*)t0)[5])[1]);
if(C_truep(t5)){
t6=t2;
f_16672(2,t6,(C_word)C_slot(t5,C_fix(1)));}
else{
/* error */
t6=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t2,lf[188],((C_word*)t0)[6]);}}
else{
t4=t2;
f_16672(2,t4,(C_word)C_u_i_cadr(((C_word*)t0)[6]));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16715,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
/* lp2489 */
t4=((C_word*)((C_word*)t0)[4])[1];
f_15581(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[8]);}}

/* k16713 in k16667 in k16658 in k16655 in k16652 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16715,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16716,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_16716 in k16713 in k16667 in k16658 in k16655 in k16652 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16716,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16722,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* test2734 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t6);}

/* a16721 */
static void C_ccall f_16722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16722,2,t0,t1);}
/* fail2705 */
t2=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k16670 in k16667 in k16658 in k16655 in k16652 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16672,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16673,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp));}

/* f_16673 in k16670 in k16667 in k16658 in k16655 in k16652 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16673(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16673,6,t0,t1,t2,t3,t4,t5);}
t6=t4;
t7=((C_word*)t0)[4];
t8=(C_word)C_a_i_times(&a,2,t7,C_fix(2));
t9=(C_word)C_a_i_plus(&a,2,C_fix(4),t8);
if(C_truep((C_word)C_slot(t6,t9))){
/* pass2704 */
t10=((C_word*)t0)[3];
((C_proc6)(void*)(*((C_word*)t10+1)))(6,t10,t1,t2,t3,t4,t5);}
else{
/* fail2705 */
t10=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t10+1)))(6,t10,t1,t2,t3,t4,t5);}}

/* a16639 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16640(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16640,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}

/* k16615 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16617,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16618,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_16618 in k16615 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16618(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16618,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16622,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16633,tmp=(C_word)a,a+=2,tmp);
/* once2692 */
t8=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,t2,t3,t4,t7);}

/* a16632 */
static void C_ccall f_16633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16633,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k16620 */
static void C_ccall f_16622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* next2493 */
t2=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail2700 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}

/* a16598 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16599(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16599,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}

/* k16566 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16568,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16569,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_16569 in k16566 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16569(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16569,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_16586,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t5,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16590,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* substring */
t8=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,t2,C_fix(0),t3);}

/* k16588 */
static void C_ccall f_16590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16590,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16592,tmp=(C_word)a,a+=2,tmp);
/* check2683 */
t3=((C_word*)t0)[4];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[3],t1,C_fix(0),((C_word*)t0)[2],t2);}

/* a16591 in k16588 */
static void C_ccall f_16592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16592,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k16584 */
static void C_ccall f_16586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_eqvp(((C_word*)t0)[7],t1))){
/* fail2691 */
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
/* next2493 */
t2=((C_word*)t0)[4];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[7],((C_word*)t0)[2],((C_word*)t0)[6]);}}

/* a16549 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16550(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16550,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}

/* k16517 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16519,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16520,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_16520 in k16517 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16520(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16520,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_16537,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16541,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* substring */
t8=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,t2,C_fix(0),t3);}

/* k16539 */
static void C_ccall f_16541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16541,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16543,tmp=(C_word)a,a+=2,tmp);
/* check2674 */
t3=((C_word*)t0)[4];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[3],t1,C_fix(0),((C_word*)t0)[2],t2);}

/* a16542 in k16539 */
static void C_ccall f_16543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16543,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k16535 */
static void C_ccall f_16537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_eqvp(((C_word*)t0)[7],t1))){
/* next2493 */
t2=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[7],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail2682 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}

/* a16504 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16505(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16505,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}

/* k16480 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16482,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16483,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_16483 in k16480 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16483(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16483,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_16490,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16498,tmp=(C_word)a,a+=2,tmp);
/* check2665 */
t8=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,t2,t3,t4,t7);}

/* a16497 */
static void C_ccall f_16498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16498,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k16488 */
static void C_ccall f_16490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* fail2673 */
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
/* next2493 */
t2=((C_word*)t0)[5];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7]);}}

/* a16467 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16468(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16468,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}

/* k16443 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16445,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16446,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_16446 in k16443 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16446(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16446,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_16453,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16461,tmp=(C_word)a,a+=2,tmp);
/* check2656 */
t8=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,t2,t3,t4,t7);}

/* a16460 */
static void C_ccall f_16461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16461,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k16451 */
static void C_ccall f_16453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* next2493 */
t2=((C_word*)t0)[7];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail2664 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}}

/* k16430 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* rec2500 */
t2=((C_word*)t0)[3];
f_15584(t2,((C_word*)t0)[2],t1);}

/* k16405 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16407,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[62],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_cons(&a,2,lf[183],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[85],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[139],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[140],t9);
t11=(C_word)C_a_i_cons(&a,2,lf[74],t10);
/* rec2500 */
t12=((C_word*)t0)[3];
f_15584(t12,((C_word*)t0)[2],t11);}

/* k16340 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16342,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[140],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[74],t2);
/* rec2500 */
t4=((C_word*)t0)[3];
f_15584(t4,((C_word*)t0)[2],t3);}

/* k16153 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_fcall f_16155(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16155,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_16158,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
t3=t2;
f_16158(t3,t1);}
else{
t3=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
t4=t2;
f_16158(t4,(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_u_i_caddr(((C_word*)t0)[7])));}}

/* k16156 in k16153 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_fcall f_16158(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16158,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16159,tmp=(C_word)a,a+=2,tmp));}
else{
t2=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
t5=(C_word)C_eqp(lf[89],t4);
t6=(C_truep(t5)?lf[87]:lf[88]);
t7=(C_word)C_u_i_car(((C_word*)t0)[7]);
t8=(C_word)C_eqp(lf[89],t7);
t9=(C_truep(t8)?lf[83]:lf[84]);
t10=(C_word)C_u_i_cdddr(((C_word*)t0)[7]);
t11=f_12312(C_a_i(&a,3),t10);
t12=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_16181,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=t6,a[5]=((C_word*)t0)[3],a[6]=t3,a[7]=t11,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[8],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
/* sre-strip-submatches */
t13=lf[179];
f_12362(3,t13,t12,t11);}}

/* k16179 in k16156 in k16153 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16181,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_16184,a[2]=t1,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[6])){
if(C_truep((C_word)C_i_nequalp(((C_word*)t0)[12],((C_word*)t0)[6]))){
t3=t2;
f_16184(2,t3,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16231,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16247,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[6],((C_word*)t0)[12]);
/* zero-to */
f_4475(t4,t5);}}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
/* rec2500 */
t5=((C_word*)t0)[2];
f_15584(t5,t2,t4);}}

/* k16245 in k16179 in k16156 in k16153 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* fold */
f_4741(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a16230 in k16179 in k16156 in k16153 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16231(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_16231,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
/* lp2489 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_15581(t6,t1,t5,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k16182 in k16179 in k16156 in k16153 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16184,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(((C_word*)t0)[8]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16201,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16205,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16211,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16216,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[8],C_fix(1));
/* zero-to */
f_4475(t5,t6);}}

/* k16214 in k16182 in k16179 in k16156 in k16153 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a16210 in k16182 in k16179 in k16156 in k16153 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16211(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_16211,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* k16203 in k16182 in k16179 in k16156 in k16153 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16205,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
/* ##sys#append */
t3=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k16199 in k16182 in k16179 in k16156 in k16153 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16201,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[74],t1);
/* lp2489 */
t3=((C_word*)((C_word*)t0)[6])[1];
f_15581(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_16159 in k16156 in k16153 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16159(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16159,6,t0,t1,t2,t3,t4,t5);}
/* fail2624 */
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* k16134 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16136,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[89],t3);
/* rec2500 */
t5=((C_word*)t0)[3];
f_15584(t5,((C_word*)t0)[2],t4);}

/* k16101 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16103,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[89],t3);
/* rec2500 */
t5=((C_word*)t0)[3];
f_15584(t5,((C_word*)t0)[2],t4);}

/* k16052 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2489 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_15581(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k15989 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15991,2,t0,t1);}
if(C_truep(t1)){
/* error */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[7],lf[178],((C_word*)t0)[6]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15998,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t6=f_12312(C_a_i(&a,3),t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16015,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* lp2489 */
t8=((C_word*)((C_word*)t0)[4])[1];
f_15581(t8,t4,t6,((C_word*)t0)[3],((C_word*)t0)[2],t7);}}

/* a16014 in k15989 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16015(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16015,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16021,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* next2493 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t6);}

/* a16020 in a16014 in k15989 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_16021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16021,2,t0,t1);}
/* body2581 */
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k15996 in k15989 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15998,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15999,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));}

/* f_15999 in k15996 in k15989 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15999(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_15999,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16005,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* next2493 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t6);}

/* a16004 */
static void C_ccall f_16005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16005,2,t0,t1);}
/* body2581 */
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k15931 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15933,2,t0,t1);}
if(C_truep(t1)){
/* error */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[7],lf[177],((C_word*)t0)[6]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15940,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t6=f_12312(C_a_i(&a,3),t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15957,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* lp2489 */
t8=((C_word*)((C_word*)t0)[4])[1];
f_15581(t8,t4,t6,((C_word*)t0)[3],((C_word*)t0)[2],t7);}}

/* a15956 in k15931 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15957(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_15957,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15963,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* body2565 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t6);}

/* a15962 in a15956 in k15931 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15963,2,t0,t1);}
/* next2493 */
t2=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k15938 in k15931 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15940,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15941,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_15941 in k15938 in k15931 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15941(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_15941,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15947,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* body2565 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t6);}

/* a15946 */
static void C_ccall f_15947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15947,2,t0,t1);}
/* next2493 */
t2=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k15900 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15902,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15903,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp));}

/* f_15903 in k15900 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15903(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_15903,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15909,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* next2493 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t6);}

/* a15908 */
static void C_ccall f_15909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15909,2,t0,t1);}
/* body2554 */
t2=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k15872 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15874,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15875,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_15875 in k15872 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15875(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_15875,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15881,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* body2549 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t6);}

/* a15880 */
static void C_ccall f_15881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15881,2,t0,t1);}
/* next2493 */
t2=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k15851 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15853,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],t1);
/* lp2489 */
t3=((C_word*)((C_word*)t0)[6])[1];
f_15581(t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k15832 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
/* lp2489 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_15581(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k15794 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2489 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_15581(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k15773 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2489 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_15581(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k15752 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2489 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_15581(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k15731 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2489 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_15581(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k15672 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15674,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15677,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[6]);
t4=f_12337(C_a_i(&a,3),t3);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_15700,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
/* sre-count-submatches */
f_11217(t5,t6);}

/* k15698 in k15672 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15700,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],t1);
/* lp2489 */
t3=((C_word*)((C_word*)t0)[6])[1];
f_15581(t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k15675 in k15672 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15677,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15678,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp));}

/* f_15678 in k15675 in k15672 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15678(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_15678,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15684,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* first2532 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t6);}

/* a15683 */
static void C_ccall f_15684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15684,2,t0,t1);}
/* rest2533 */
t2=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_15654 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15654(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_15654,6,t0,t1,t2,t3,t4,t5);}
/* fail2530 */
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* k15636 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15638,2,t0,t1);}
/* sre->cset */
f_17663(((C_word*)t0)[3],((C_word*)t0)[2],(C_word)C_a_i_list(&a,1,t1));}

/* k15632 in k15625 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* sre-cset->procedure */
f_17546(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k15613 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15615,2,t0,t1);}
/* sre->cset */
f_17663(((C_word*)t0)[3],((C_word*)t0)[2],(C_word)C_a_i_list(&a,1,t1));}

/* k15605 in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* sre-cset->procedure */
f_17546(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* rec in lp in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_fcall f_15584(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15584,NULL,3,t0,t1,t2);}
/* lp2489 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_15581(t3,t1,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a15577 in k15567 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_15578(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_15578,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}

/* k10665 in k10656 in k11288 in k11281 in k11278 in k10650 in k10647 in k10644 in k10641 in k10638 in k10635 in k10632 in k10629 in k10626 in k10623 in k10620 in sre->irregex in k3721 */
static void C_ccall f_10667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10667,2,t0,t1);}
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=t2;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_vector(&a,9,lf[1],C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,t1,t3,t4,((C_word*)t0)[2],t5));}

/* string->irregex in k3721 */
static void C_ccall f_10608(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_10608r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_10608r(t0,t1,t2,t3);}}

static void C_ccall f_10608r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10616,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t4,*((C_word*)lf[61]+1),t2,t3);}

/* k10614 in string->irregex in k3721 */
static void C_ccall f_10616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[3],*((C_word*)lf[171]+1),t1,((C_word*)t0)[2]);}

/* irregex in k3721 */
static void C_ccall f_10587(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_10587r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_10587r(t0,t1,t2,t3);}}

static void C_ccall f_10587r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10594,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* irregex? */
t5=*((C_word*)lf[0]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k10592 in irregex in k3721 */
static void C_ccall f_10594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[3]))){
C_apply(5,0,((C_word*)t0)[4],*((C_word*)lf[170]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
C_apply(5,0,((C_word*)t0)[4],*((C_word*)lf[171]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}}

/* cset->utf8-pattern in k3721 */
static void C_fcall f_10137(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10137,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10143,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_10143(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* lp in cset->utf8-pattern in k3721 */
static void C_fcall f_10143(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10143,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10157,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10161,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* reverse */
t7=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}
else{
t5=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_charp(t5))){
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_fix((C_word)C_character_code(t6));
if(C_truep((C_word)C_i_less_or_equalp(C_fix(128),t7))){
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_u_i_car(t2);
t10=(C_word)C_a_i_cons(&a,2,t9,t3);
/* lp1125 */
t23=t1;
t24=t8;
t25=t10;
t26=t4;
t1=t23;
t2=t24;
t3=t25;
t4=t26;
goto loop;}
else{
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_u_i_car(t2);
t10=(C_word)C_a_i_cons(&a,2,t9,t4);
/* lp1125 */
t23=t1;
t24=t8;
t25=t3;
t26=t10;
t1=t23;
t2=t24;
t3=t25;
t4=t26;
goto loop;}}
else{
t6=(C_word)C_u_i_caar(t2);
t7=(C_word)C_fix((C_word)C_character_code(t6));
t8=(C_word)C_i_less_or_equalp(C_fix(128),t7);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10234,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t8)){
t10=t9;
f_10234(t10,t8);}
else{
t10=(C_word)C_u_i_cdar(t2);
t11=(C_word)C_fix((C_word)C_character_code(t10));
t12=t9;
f_10234(t12,(C_word)C_i_less_or_equalp(C_fix(128),t11));}}}}

/* k10232 in lp in cset->utf8-pattern in k3721 */
static void C_fcall f_10234(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10234,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10249,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_u_i_caar(((C_word*)t0)[6]);
t5=(C_word)C_u_i_cdar(((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9296,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* char->utf8-list */
f_9163(t6,t4);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_u_i_cdar(((C_word*)t0)[6]);
t4=(C_word)C_u_i_caar(((C_word*)t0)[6]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[2]);
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
/* lp1125 */
t7=((C_word*)((C_word*)t0)[4])[1];
f_10143(t7,((C_word*)t0)[3],t2,((C_word*)t0)[5],t6);}}

/* k9294 in k10232 in lp in cset->utf8-pattern in k3721 */
static void C_ccall f_9296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9296,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9299,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* char->utf8-list */
f_9163(t2,((C_word*)t0)[2]);}

/* k9297 in k9294 in k10232 in lp in cset->utf8-pattern in k3721 */
static void C_ccall f_9299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9299,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[3]);
t3=(C_word)C_i_length(t1);
if(C_truep((C_word)C_i_nequalp(t2,t3))){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9325,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_9325(t7,((C_word*)t0)[2],((C_word*)t0)[3],t1);}
else{
t4=((C_word*)t0)[3];
t5=t1;
t6=(C_word)C_i_length(t4);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9792,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_u_i_car(t4);
t9=(C_word)C_make_character((C_word)C_unfix(t8));
t10=(C_word)C_u_i_car(t4);
t11=(C_word)C_i_less_or_equalp(t10,C_fix(127));
t12=(C_truep(t11)?C_fix(127):C_fix(255));
t13=(C_word)C_make_character((C_word)C_unfix(t12));
t14=(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,t9,t14);
t16=(C_word)C_a_i_cons(&a,2,lf[25],t15);
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9998,a[2]=t6,a[3]=t7,a[4]=t5,a[5]=t16,tmp=(C_word)a,a+=6,tmp);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10000,tmp=(C_word)a,a+=2,tmp);
t19=(C_word)C_slot(t4,C_fix(1));
/* map */
t20=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t17,t18,t19);}}

/* a9999 in k9297 in k9294 in k10232 in lp in cset->utf8-pattern in k3721 */
static void C_ccall f_10000(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10000,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,C_make_character(255),C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_make_character(128),t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[25],t4));}

/* k9996 in k9297 in k9294 in k10232 in lp in cset->utf8-pattern in k3721 */
static void C_ccall f_9998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9998,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=f_12312(C_a_i(&a,3),t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9800,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9892,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9974,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9978,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_length(((C_word*)t0)[4]);
/* - */
C_minus(5,0,t8,t9,((C_word*)t0)[2],C_fix(1));}

/* k9976 in k9996 in k9297 in k9294 in k10232 in lp in cset->utf8-pattern in k3721 */
static void C_ccall f_9978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* zero-to */
f_4475(((C_word*)t0)[2],t1);}

/* k9972 in k9996 in k9297 in k9294 in k10232 in lp in cset->utf8-pattern in k3721 */
static void C_ccall f_9974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a9891 in k9996 in k9297 in k9294 in k10232 in lp in cset->utf8-pattern in k3721 */
static void C_ccall f_9892(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9892,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9966,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9970,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* + */
C_plus(5,0,t4,t2,((C_word*)t0)[2],C_fix(1));}

/* k9968 in a9891 in k9996 in k9297 in k9294 in k10232 in lp in cset->utf8-pattern in k3721 */
static void C_ccall f_9970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utf8-lowest-digit-of-length */
f_9103(((C_word*)t0)[2],t1);}

/* k9964 in a9891 in k9996 in k9297 in k9294 in k10232 in lp in cset->utf8-pattern in k3721 */
static void C_ccall f_9966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9966,2,t0,t1);}
t2=(C_word)C_make_character((C_word)C_unfix(t1));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9958,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9962,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* + */
C_plus(5,0,t4,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(1));}

/* k9960 in k9964 in a9891 in k9996 in k9297 in k9294 in k10232 in lp in cset->utf8-pattern in k3721 */
static void C_ccall f_9962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
switch(t1){
case C_fix(1):
t2=((C_word*)t0)[2];
f_9958(2,t2,C_fix(127));
case C_fix(2):
t2=((C_word*)t0)[2];
f_9958(2,t2,C_fix(223));
case C_fix(3):
t2=((C_word*)t0)[2];
f_9958(2,t2,C_fix(239));
case C_fix(4):
t2=((C_word*)t0)[2];
f_9958(2,t2,C_fix(247));
default:
/* error */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[168],t1);}}

/* k9956 in k9964 in a9891 in k9996 in k9297 in k9294 in k10232 in lp in cset->utf8-pattern in k3721 */
static void C_ccall f_9958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9958,2,t0,t1);}
t2=(C_word)C_make_character((C_word)C_unfix(t1));
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,lf[25],t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9908,a[2]=((C_word*)t0)[4],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9910,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9934,a[2]=t7,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
/* zero-to */
f_4475(t8,t9);}

/* k9932 in k9956 in k9964 in a9891 in k9996 in k9297 in k9294 in k10232 in lp in cset->utf8-pattern in k3721 */
static void C_ccall f_9934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a9909 in k9956 in k9964 in a9891 in k9996 in k9297 in k9294 in k10232 in lp in cset->utf8-pattern in k3721 */
static void C_ccall f_9910(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9910,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,C_make_character(255),C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_make_character(128),t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[25],t4));}

/* k9906 in k9956 in k9964 in a9891 in k9996 in k9297 in k9294 in k10232 in lp in cset->utf8-pattern in k3721 */
static void C_ccall f_9908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9908,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* sre-sequence */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_12312(C_a_i(&a,3),t2));}

/* k9798 in k9996 in k9297 in k9294 in k10232 in lp in cset->utf8-pattern in k3721 */
static void C_ccall f_9800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9800,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9874,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[4]);
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
t5=(C_word)C_make_character((C_word)C_unfix(t4));
t6=(C_word)C_fix((C_word)C_character_code(t5));
t7=(C_word)C_slot(lf[125],t6);
/* utf8-lowest-digit-of-length */
f_9103(t2,t7);}

/* k9872 in k9798 in k9996 in k9297 in k9294 in k10232 in lp in cset->utf8-pattern in k3721 */
static void C_ccall f_9874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9874,2,t0,t1);}
t2=(C_word)C_make_character((C_word)C_unfix(t1));
t3=(C_word)C_u_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
t5=(C_word)C_make_character((C_word)C_unfix(t4));
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t2,t6);
t8=(C_word)C_a_i_cons(&a,2,lf[25],t7);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9820,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9822,tmp=(C_word)a,a+=2,tmp);
t11=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* map */
t12=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t9,t10,t11);}

/* a9821 in k9872 in k9798 in k9996 in k9297 in k9294 in k10232 in lp in cset->utf8-pattern in k3721 */
static void C_ccall f_9822(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9822,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,C_make_character(255),C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_make_character(128),t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[25],t4));}

/* k9818 in k9872 in k9798 in k9996 in k9297 in k9294 in k10232 in lp in cset->utf8-pattern in k3721 */
static void C_ccall f_9820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9820,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=f_12312(C_a_i(&a,3),t2);
t4=(C_word)C_a_i_list(&a,1,t3);
/* append */
t5=*((C_word*)lf[117]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t4);}

/* k9790 in k9297 in k9294 in k10232 in lp in cset->utf8-pattern in k3721 */
static void C_ccall f_9792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9792,2,t0,t1);}
t2=f_12337(C_a_i(&a,3),t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9320,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* unicode-range-up-to */
f_9653(t3,((C_word*)t0)[2]);}

/* k9318 in k9790 in k9297 in k9294 in k10232 in lp in cset->utf8-pattern in k3721 */
static void C_ccall f_9320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9320,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
/* sre-alternate */
t3=((C_word*)t0)[2];
f_10249(2,t3,f_12337(C_a_i(&a,3),t2));}

/* lp in k9297 in k9294 in k10232 in lp in cset->utf8-pattern in k3721 */
static void C_fcall f_9325(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9325,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_u_i_car(t3);
if(C_truep((C_word)C_i_nequalp(t4,t5))){
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_make_character((C_word)C_unfix(t6));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9353,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_slot(t2,C_fix(1));
t10=(C_word)C_slot(t3,C_fix(1));
/* lp1031 */
t17=t8;
t18=t9;
t19=t10;
t1=t17;
t2=t18;
t3=t19;
goto loop;}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_a_i_plus(&a,2,t6,C_fix(1));
t8=(C_word)C_u_i_car(t3);
if(C_truep((C_word)C_i_nequalp(t7,t8))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9382,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* unicode-range-up-from */
f_9525(t9,t2);}
else{
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9397,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* unicode-range-up-from */
f_9525(t9,t2);}}}}

/* k9395 in lp in k9297 in k9294 in k10232 in lp in cset->utf8-pattern in k3721 */
static void C_ccall f_9397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9397,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_a_i_plus(&a,2,t4,C_fix(1));
t6=(C_word)C_make_character((C_word)C_unfix(t5));
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_a_i_minus(&a,2,t7,C_fix(1));
t9=(C_word)C_make_character((C_word)C_unfix(t8));
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10075,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_eqp(t6,t9);
if(C_truep(t11)){
t12=t10;
f_10075(t12,t6);}
else{
t12=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,t6,t12);
t14=t10;
f_10075(t14,(C_word)C_a_i_cons(&a,2,lf[25],t13));}}

/* k10073 in k9395 in lp in k9297 in k9294 in k10232 in lp in cset->utf8-pattern in k3721 */
static void C_fcall f_10075(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10075,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10079,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10081,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* map */
t5=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a10080 in k10073 in k9395 in lp in k9297 in k9294 in k10232 in lp in cset->utf8-pattern in k3721 */
static void C_ccall f_10081(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10081,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,C_make_character(255),C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_make_character(128),t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[25],t4));}

/* k10077 in k10073 in k9395 in lp in k9297 in k9294 in k10232 in lp in cset->utf8-pattern in k3721 */
static void C_ccall f_10079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10079,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=f_12312(C_a_i(&a,3),t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9405,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* unicode-range-up-to */
f_9653(t4,((C_word*)t0)[2]);}

/* k9403 in k10077 in k10073 in k9395 in lp in k9297 in k9294 in k10232 in lp in cset->utf8-pattern in k3721 */
static void C_ccall f_9405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9405,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],((C_word*)t0)[3],t1);
/* sre-alternate */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_12337(C_a_i(&a,3),t2));}

/* k9380 in lp in k9297 in k9294 in k10232 in lp in cset->utf8-pattern in k3721 */
static void C_ccall f_9382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9382,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9386,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* unicode-range-up-to */
f_9653(t2,((C_word*)t0)[2]);}

/* k9384 in k9380 in lp in k9297 in k9294 in k10232 in lp in cset->utf8-pattern in k3721 */
static void C_ccall f_9386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9386,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
/* sre-alternate */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_12337(C_a_i(&a,3),t2));}

/* k9351 in lp in k9297 in k9294 in k10232 in lp in cset->utf8-pattern in k3721 */
static void C_ccall f_9353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9353,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
/* sre-sequence */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_12312(C_a_i(&a,3),t2));}

/* k10247 in k10232 in lp in cset->utf8-pattern in k3721 */
static void C_ccall f_10249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10249,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* lp1125 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_10143(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k10159 in lp in cset->utf8-pattern in k3721 */
static void C_ccall f_10161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10161,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10165,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[2]))){
t3=t2;
f_10165(t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10179,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* reverse */
t4=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}}

/* k10177 in k10159 in lp in cset->utf8-pattern in k3721 */
static void C_ccall f_10179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10179,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[25],t1);
t3=((C_word*)t0)[2];
f_10165(t3,(C_word)C_a_i_list(&a,1,t2));}

/* k10163 in k10159 in lp in cset->utf8-pattern in k3721 */
static void C_fcall f_10165(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[117]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10155 in lp in cset->utf8-pattern in k3721 */
static void C_ccall f_10157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10157,2,t0,t1);}
/* sre-alternate */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_12337(C_a_i(&a,3),t1));}

/* unicode-range-up-to in k3721 */
static void C_fcall f_9653(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9653,NULL,2,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9673,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9675,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9771,a[2]=t2,a[3]=t6,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_slot(t2,C_fix(1));
/* reverse */
t9=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* k9769 in unicode-range-up-to in k3721 */
static void C_ccall f_9771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9771,2,t0,t1);}
t2=(C_word)C_slot(t1,C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9719,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9723,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9755,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9763,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* reverse */
t8=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}

/* k9761 in k9769 in unicode-range-up-to in k3721 */
static void C_ccall f_9763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(t1,C_fix(1));
/* reverse */
t3=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k9753 in k9769 in unicode-range-up-to in k3721 */
static void C_ccall f_9755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[164]+1),t1);}

/* k9721 in k9769 in unicode-range-up-to in k3721 */
static void C_ccall f_9723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9723,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9751,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* last */
f_4601(t2,((C_word*)t0)[2]);}

/* k9749 in k9721 in k9769 in unicode-range-up-to in k3721 */
static void C_ccall f_9751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9751,2,t0,t1);}
t2=(C_word)C_make_character((C_word)C_unfix(t1));
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_make_character(128),t3);
t5=(C_word)C_a_i_cons(&a,2,lf[25],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
/* append */
t7=*((C_word*)lf[117]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[3],((C_word*)t0)[2],t6);}

/* k9717 in k9769 in unicode-range-up-to in k3721 */
static void C_ccall f_9719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9719,2,t0,t1);}
t2=f_12312(C_a_i(&a,3),t1);
t3=(C_word)C_a_i_list(&a,1,t2);
/* unicode-range-helper */
f_9439(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t3);}

/* a9674 in unicode-range-up-to in k3721 */
static void C_ccall f_9675(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9675,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(((C_word*)t0)[2]);
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
t5=(C_word)C_make_character((C_word)C_unfix(t4));
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,C_make_character(128),t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[25],t7));}

/* k9671 in unicode-range-up-to in k3721 */
static void C_ccall f_9673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9673,2,t0,t1);}
t2=f_12337(C_a_i(&a,3),t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t2);
/* sre-sequence */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_12312(C_a_i(&a,3),t3));}

/* unicode-range-up-from in k3721 */
static void C_fcall f_9525(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9525,NULL,2,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9545,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9547,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9643,a[2]=t2,a[3]=t6,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_slot(t2,C_fix(1));
/* reverse */
t9=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* k9641 in unicode-range-up-from in k3721 */
static void C_ccall f_9643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9643,2,t0,t1);}
t2=(C_word)C_slot(t1,C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9591,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9595,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9627,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9635,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* reverse */
t8=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}

/* k9633 in k9641 in unicode-range-up-from in k3721 */
static void C_ccall f_9635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(t1,C_fix(1));
/* reverse */
t3=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k9625 in k9641 in unicode-range-up-from in k3721 */
static void C_ccall f_9627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[164]+1),t1);}

/* k9593 in k9641 in unicode-range-up-from in k3721 */
static void C_ccall f_9595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9623,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* last */
f_4601(t2,((C_word*)t0)[2]);}

/* k9621 in k9593 in k9641 in unicode-range-up-from in k3721 */
static void C_ccall f_9623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9623,2,t0,t1);}
t2=(C_word)C_make_character((C_word)C_unfix(t1));
t3=(C_word)C_a_i_cons(&a,2,C_make_character(255),C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,lf[25],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
/* append */
t7=*((C_word*)lf[117]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[3],((C_word*)t0)[2],t6);}

/* k9589 in k9641 in unicode-range-up-from in k3721 */
static void C_ccall f_9591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9591,2,t0,t1);}
t2=f_12312(C_a_i(&a,3),t1);
t3=(C_word)C_a_i_list(&a,1,t2);
/* unicode-range-helper */
f_9439(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t3);}

/* a9546 in unicode-range-up-from in k3721 */
static void C_ccall f_9547(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9547,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(((C_word*)t0)[2]);
t4=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t5=(C_word)C_make_character((C_word)C_unfix(t4));
t6=(C_word)C_a_i_cons(&a,2,C_make_character(255),C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[25],t7));}

/* k9543 in unicode-range-up-from in k3721 */
static void C_ccall f_9545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9545,2,t0,t1);}
t2=f_12337(C_a_i(&a,3),t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t2);
/* sre-sequence */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_12312(C_a_i(&a,3),t3));}

/* unicode-range-helper in k3721 */
static void C_fcall f_9439(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9439,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t3))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_slot(t3,C_fix(1));
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_a_i_cons(&a,2,t7,t4);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9469,a[2]=t8,a[3]=t6,a[4]=t2,a[5]=t1,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9473,a[2]=t2,a[3]=t3,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* map */
t11=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,*((C_word*)lf[164]+1),t4);}}

/* k9471 in unicode-range-helper in k3721 */
static void C_ccall f_9473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9481,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[3]);
/* one1042 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* k9479 in k9471 in unicode-range-helper in k3721 */
static void C_ccall f_9481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9481,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9485,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9489,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9491,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* map */
t6=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a9490 in k9479 in k9471 in unicode-range-helper in k3721 */
static void C_ccall f_9491(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9491,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,C_make_character(255),C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_make_character(128),t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[25],t4));}

/* k9487 in k9479 in k9471 in unicode-range-helper in k3721 */
static void C_ccall f_9489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k9483 in k9479 in k9471 in unicode-range-helper in k3721 */
static void C_ccall f_9485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9485,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* ##sys#append */
t3=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9467 in unicode-range-helper in k3721 */
static void C_ccall f_9469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9469,2,t0,t1);}
t2=f_12312(C_a_i(&a,3),t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[6]);
/* unicode-range-helper */
f_9439(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* char->utf8-list in k3721 */
static void C_fcall f_9163(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9163,NULL,2,t1,t2);}
t3=(C_word)C_fix((C_word)C_character_code(t2));
if(C_truep((C_word)C_i_less_or_equalp(t3,C_fix(127)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,1,t3));}
else{
if(C_truep((C_word)C_i_less_or_equalp(t3,C_fix(2047)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9189,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9201,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* bit-shr */
f_4857(t5,t3,C_fix(6));}
else{
if(C_truep((C_word)C_i_less_or_equalp(t3,C_fix(65535)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9214,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9238,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* bit-shr */
f_4857(t5,t3,C_fix(12));}
else{
if(C_truep((C_word)C_i_less_or_equalp(t3,C_fix(2097151)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9251,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9287,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* bit-shr */
f_4857(t5,t3,C_fix(18));}
else{
/* error */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,lf[162],t3);}}}}}

/* k9285 in char->utf8-list in k3721 */
static void C_ccall f_9287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-ior */
f_4883(((C_word*)t0)[2],C_fix(240),t1);}

/* k9249 in char->utf8-list in k3721 */
static void C_ccall f_9251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9251,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9255,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9279,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9283,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* bit-shr */
f_4857(t4,((C_word*)t0)[2],C_fix(12));}

/* k9281 in k9249 in char->utf8-list in k3721 */
static void C_ccall f_9283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-and */
f_4930(((C_word*)t0)[2],t1,C_fix(63));}

/* k9277 in k9249 in char->utf8-list in k3721 */
static void C_ccall f_9279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-ior */
f_4883(((C_word*)t0)[2],C_fix(128),t1);}

/* k9253 in k9249 in char->utf8-list in k3721 */
static void C_ccall f_9255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9255,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9259,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9271,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9275,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* bit-shr */
f_4857(t4,((C_word*)t0)[2],C_fix(6));}

/* k9273 in k9253 in k9249 in char->utf8-list in k3721 */
static void C_ccall f_9275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-and */
f_4930(((C_word*)t0)[2],t1,C_fix(63));}

/* k9269 in k9253 in k9249 in char->utf8-list in k3721 */
static void C_ccall f_9271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-ior */
f_4883(((C_word*)t0)[2],C_fix(128),t1);}

/* k9257 in k9253 in k9249 in char->utf8-list in k3721 */
static void C_ccall f_9259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9259,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9263,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9267,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* bit-and */
f_4930(t3,((C_word*)t0)[2],C_fix(63));}

/* k9265 in k9257 in k9253 in k9249 in char->utf8-list in k3721 */
static void C_ccall f_9267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-ior */
f_4883(((C_word*)t0)[2],C_fix(128),t1);}

/* k9261 in k9257 in k9253 in k9249 in char->utf8-list in k3721 */
static void C_ccall f_9263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9263,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k9236 in char->utf8-list in k3721 */
static void C_ccall f_9238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-ior */
f_4883(((C_word*)t0)[2],C_fix(224),t1);}

/* k9212 in char->utf8-list in k3721 */
static void C_ccall f_9214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9214,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9218,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9230,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9234,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* bit-shr */
f_4857(t4,((C_word*)t0)[2],C_fix(6));}

/* k9232 in k9212 in char->utf8-list in k3721 */
static void C_ccall f_9234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-and */
f_4930(((C_word*)t0)[2],t1,C_fix(63));}

/* k9228 in k9212 in char->utf8-list in k3721 */
static void C_ccall f_9230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-ior */
f_4883(((C_word*)t0)[2],C_fix(128),t1);}

/* k9216 in k9212 in char->utf8-list in k3721 */
static void C_ccall f_9218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9218,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9222,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9226,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* bit-and */
f_4930(t3,((C_word*)t0)[2],C_fix(63));}

/* k9224 in k9216 in k9212 in char->utf8-list in k3721 */
static void C_ccall f_9226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-ior */
f_4883(((C_word*)t0)[2],C_fix(128),t1);}

/* k9220 in k9216 in k9212 in char->utf8-list in k3721 */
static void C_ccall f_9222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9222,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k9199 in char->utf8-list in k3721 */
static void C_ccall f_9201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-ior */
f_4883(((C_word*)t0)[2],C_fix(192),t1);}

/* k9187 in char->utf8-list in k3721 */
static void C_ccall f_9189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9189,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9193,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9197,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* bit-and */
f_4930(t3,((C_word*)t0)[2],C_fix(63));}

/* k9195 in k9187 in char->utf8-list in k3721 */
static void C_ccall f_9197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-ior */
f_4883(((C_word*)t0)[2],C_fix(128),t1);}

/* k9191 in k9187 in char->utf8-list in k3721 */
static void C_ccall f_9193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9193,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* utf8-lowest-digit-of-length in k3721 */
static void C_fcall f_9103(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9103,NULL,2,t1,t2);}
t3=t2;
switch(t3){
case C_fix(1):
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));
case C_fix(2):
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(192));
case C_fix(3):
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(224));
case C_fix(4):
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(240));
default:
/* error */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,lf[160],t2);}}

/* utf8-string-ref in k3721 */
static void C_fcall f_8878(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8878,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8881,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=t4;
switch(t6){
case C_fix(1):
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_subchar(t2,t3));
case C_fix(2):
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8915,a[2]=t5,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8931,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=f_8881(t5,t3);
/* bit-and */
f_4930(t8,t9,C_fix(31));
case C_fix(3):
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8948,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8952,a[2]=t5,a[3]=t3,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8984,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=f_8881(t5,t3);
/* bit-and */
f_4930(t9,t10,C_fix(15));
case C_fix(4):
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9001,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9005,a[2]=t5,a[3]=t3,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9053,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=f_8881(t5,t3);
/* bit-and */
f_4930(t9,t10,C_fix(7));
default:
/* error */
t7=*((C_word*)lf[18]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,lf[158],t2,t4,t3);}}

/* k9051 in utf8-string-ref in k3721 */
static void C_ccall f_9053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-shl */
f_4867(((C_word*)t0)[2],t1,C_fix(18));}

/* k9003 in utf8-string-ref in k3721 */
static void C_ccall f_9005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9005,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9009,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9041,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
t5=f_8881(((C_word*)t0)[2],t4);
/* bit-and */
f_4930(t3,t5,C_fix(63));}

/* k9039 in k9003 in utf8-string-ref in k3721 */
static void C_ccall f_9041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-shl */
f_4867(((C_word*)t0)[2],t1,C_fix(12));}

/* k9007 in k9003 in utf8-string-ref in k3721 */
static void C_ccall f_9009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9009,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9013,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9029,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(2));
t5=f_8881(((C_word*)t0)[2],t4);
/* bit-and */
f_4930(t3,t5,C_fix(63));}

/* k9027 in k9007 in k9003 in utf8-string-ref in k3721 */
static void C_ccall f_9029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-shl */
f_4867(((C_word*)t0)[2],t1,C_fix(6));}

/* k9011 in k9007 in k9003 in utf8-string-ref in k3721 */
static void C_ccall f_9013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9017,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(3));
t4=f_8881(((C_word*)t0)[2],t3);
/* bit-and */
f_4930(t2,t4,C_fix(63));}

/* k9015 in k9011 in k9007 in k9003 in utf8-string-ref in k3721 */
static void C_ccall f_9017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* + */
C_plus(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8999 in utf8-string-ref in k3721 */
static void C_ccall f_9001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_make_character((C_word)C_unfix(t1)));}

/* k8982 in utf8-string-ref in k3721 */
static void C_ccall f_8984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-shl */
f_4867(((C_word*)t0)[2],t1,C_fix(12));}

/* k8950 in utf8-string-ref in k3721 */
static void C_ccall f_8952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8956,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8972,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
t5=f_8881(((C_word*)t0)[2],t4);
/* bit-and */
f_4930(t3,t5,C_fix(63));}

/* k8970 in k8950 in utf8-string-ref in k3721 */
static void C_ccall f_8972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-shl */
f_4867(((C_word*)t0)[2],t1,C_fix(6));}

/* k8954 in k8950 in utf8-string-ref in k3721 */
static void C_ccall f_8956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8956,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8960,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(2));
t4=f_8881(((C_word*)t0)[2],t3);
/* bit-and */
f_4930(t2,t4,C_fix(63));}

/* k8958 in k8954 in k8950 in utf8-string-ref in k3721 */
static void C_ccall f_8960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* + */
C_plus(5,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8946 in utf8-string-ref in k3721 */
static void C_ccall f_8948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_make_character((C_word)C_unfix(t1)));}

/* k8929 in utf8-string-ref in k3721 */
static void C_ccall f_8931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-shl */
f_4867(((C_word*)t0)[2],t1,C_fix(6));}

/* k8913 in utf8-string-ref in k3721 */
static void C_ccall f_8915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8919,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
t4=f_8881(((C_word*)t0)[2],t3);
/* bit-and */
f_4930(t2,t4,C_fix(63));}

/* k8917 in k8913 in utf8-string-ref in k3721 */
static void C_ccall f_8919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8919,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_make_character((C_word)C_unfix(t2)));}

/* byte in utf8-string-ref in k3721 */
static C_word C_fcall f_8881(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_subchar(((C_word*)t0)[2],t1);
return((C_word)C_fix((C_word)C_character_code(t2)));}

/* high-char? in k3721 */
static void C_ccall f_8858(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8858,3,t0,t1,t2);}
t3=(C_word)C_fix((C_word)C_character_code(t2));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_less_or_equalp(C_fix(128),t3));}

/* string-parse-hex-escape in k3721 */
static void C_fcall f_8066(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8066,NULL,4,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_greater_or_equalp(t3,t4))){
/* error */
t5=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[153],t2,t3);}
else{
t5=(C_word)C_subchar(t2,t3);
t6=(C_word)C_eqp(C_make_character(123),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8085,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t9=t2;
t10=(C_word)C_a_i_list(&a,1,t8);
t11=(C_word)C_fix((C_word)C_header_size(t9));
t12=(C_word)C_i_pairp(t10);
t13=(C_truep(t12)?(C_word)C_u_i_car(t10):C_fix(0));
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4216,a[2]=t15,a[3]=t9,a[4]=t11,tmp=(C_word)a,a+=5,tmp));
t17=((C_word*)t15)[1];
f_4216(t17,t7,t13);}
else{
t7=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
if(C_truep((C_word)C_i_greater_or_equalp(t7,t4))){
/* error */
t8=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,lf[156],t2,t3);}
else{
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8133,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_a_i_plus(&a,2,t3,C_fix(2));
/* substring */
t10=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t8,t2,t3,t9);}}}}

/* k8131 in string-parse-hex-escape in k3721 */
static void C_ccall f_8133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8133,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8136,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* string->number */
C_string_to_number(4,0,t2,t1,C_fix(16));}

/* k8134 in k8131 in string-parse-hex-escape in k3721 */
static void C_ccall f_8136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8136,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_make_character((C_word)C_unfix(t1));
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],C_fix(2));
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t2,t3));}
else{
/* error */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],lf[157],((C_word*)t0)[2]);}}

/* scan in string-parse-hex-escape in k3721 */
static void C_fcall f_4216(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4216,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nequalp(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
t4=(C_word)C_eqp(C_make_character(125),t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
/* scan147 */
t7=t1;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}}

/* k8083 in string-parse-hex-escape in k3721 */
static void C_ccall f_8085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8085,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8097,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* substring */
t5=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,((C_word*)t0)[2],t4,t1);}
else{
/* error */
t3=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[4],lf[155],((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k8095 in k8083 in string-parse-hex-escape in k3721 */
static void C_ccall f_8097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8097,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8100,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* string->number */
C_string_to_number(4,0,t2,t1,C_fix(16));}

/* k8098 in k8095 in k8083 in string-parse-hex-escape in k3721 */
static void C_ccall f_8100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8100,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_make_character((C_word)C_unfix(t1));
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[3]));}
else{
/* error */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],lf[154],((C_word*)t0)[2]);}}

/* string->sre in k3721 */
static void C_ccall f_5115(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_5115r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5115r(t0,t1,t2,t3);}}

static void C_ccall f_5115r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_fix((C_word)C_header_size(t2));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5122,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* symbol-list->flags */
f_5015(t5,t3);}

/* k5120 in string->sre in k3721 */
static void C_ccall f_5122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5122,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5127,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_5127(t5,((C_word*)t0)[2],C_fix(0),C_fix(0),t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* lp in k5120 in string->sre in k3721 */
static void C_fcall f_5127(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word t149;
C_word t150;
C_word t151;
C_word t152;
C_word t153;
C_word t154;
C_word t155;
C_word t156;
C_word t157;
C_word t158;
C_word t159;
C_word t160;
C_word t161;
C_word t162;
C_word t163;
C_word t164;
C_word t165;
C_word t166;
C_word t167;
C_word t168;
C_word t169;
C_word t170;
C_word t171;
C_word t172;
C_word t173;
C_word t174;
C_word t175;
C_word t176;
C_word t177;
C_word t178;
C_word t179;
C_word t180;
C_word t181;
C_word t182;
C_word t183;
C_word t184;
C_word t185;
C_word t186;
C_word t187;
C_word t188;
C_word t189;
C_word t190;
C_word t191;
C_word t192;
C_word t193;
C_word t194;
C_word t195;
C_word t196;
C_word t197;
C_word t198;
C_word t199;
C_word t200;
C_word t201;
C_word t202;
C_word t203;
C_word t204;
C_word t205;
C_word t206;
C_word t207;
C_word t208;
C_word t209;
C_word t210;
C_word t211;
C_word t212;
C_word t213;
C_word t214;
C_word t215;
C_word t216;
C_word t217;
C_word t218;
C_word t219;
C_word *a;
loop:
a=C_alloc(78);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5127,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5130,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5160,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5180,a[2]=((C_word*)t0)[4],a[3]=t8,a[4]=t5,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5200,a[2]=t4,a[3]=t2,a[4]=t7,a[5]=((C_word*)t0)[4],a[6]=t8,a[7]=t5,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5272,a[2]=t9,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5572,a[2]=t9,a[3]=t6,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_greater_or_equalp(t2,((C_word*)t0)[3]))){
if(C_truep((C_word)C_i_pairp(t6))){
/* error */
t13=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,lf[79],((C_word*)t0)[4]);}
else{
/* collect/terms417 */
t13=t11;
f_5272(t13,t1);}}
else{
t13=(C_word)C_subchar(((C_word*)t0)[4],t2);
switch(t13){
case C_make_character(46):
t14=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t15=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t16=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5637,a[2]=t9,a[3]=t6,a[4]=t4,a[5]=t15,a[6]=t14,a[7]=t1,a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
/* flag-set? */
f_4977(t16,t4,C_fix(8));
case C_make_character(63):
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5646,a[2]=t6,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* collect/single416 */
t15=t10;
f_5200(t15,t14);
default:
t14=(C_word)C_eqp(t13,C_make_character(43));
t15=(C_truep(t14)?t14:(C_word)C_eqp(t13,C_make_character(42)));
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5843,a[2]=t13,a[3]=t6,a[4]=t4,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[4],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* collect/single416 */
t17=t10;
f_5200(t17,t16);}
else{
switch(t13){
case C_make_character(40):
t16=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
if(C_truep((C_word)C_i_greater_or_equalp(t16,((C_word*)t0)[3]))){
/* error */
t17=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t17+1)))(4,t17,t1,lf[97],((C_word*)t0)[4]);}
else{
t17=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t18=(C_word)C_subchar(((C_word*)t0)[4],t17);
t19=(C_word)C_eqp(C_make_character(63),t18);
if(C_truep(t19)){
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
if(C_truep((C_word)C_i_greater_or_equalp(t20,((C_word*)t0)[3]))){
/* error */
t21=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t21+1)))(4,t21,t1,lf[98],((C_word*)t0)[4]);}
else{
t21=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t22=(C_word)C_subchar(((C_word*)t0)[4],t21);
switch(t22){
case C_make_character(35):
t23=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5955,a[2]=t9,a[3]=t6,a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[2],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t24=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
/* string-scan-char */
f_4158(t23,((C_word*)t0)[4],C_make_character(41),(C_word)C_a_i_list(&a,1,t24));
case C_make_character(58):
t23=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
t24=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
t25=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5995,a[2]=t12,a[3]=t24,a[4]=t23,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* flag-clear */
t26=lf[48];
f_4996(4,t26,t25,t4,C_fix(1));
case C_make_character(61):
t23=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
t24=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
t25=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6020,a[2]=t12,a[3]=t24,a[4]=t23,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* flag-clear */
t26=lf[48];
f_4996(4,t26,t25,t4,C_fix(1));
case C_make_character(33):
t23=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
t24=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
t25=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6045,a[2]=t12,a[3]=t24,a[4]=t23,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* flag-clear */
t26=lf[48];
f_4996(4,t26,t25,t4,C_fix(1));
case C_make_character(60):
t23=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
if(C_truep((C_word)C_i_greater_or_equalp(t23,((C_word*)t0)[3]))){
/* error */
t24=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t24+1)))(4,t24,t1,lf[101],((C_word*)t0)[4]);}
else{
t24=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
t25=(C_word)C_subchar(((C_word*)t0)[4],t24);
switch(t25){
case C_make_character(61):
t26=(C_word)C_a_i_plus(&a,2,t2,C_fix(4));
t27=(C_word)C_a_i_plus(&a,2,t2,C_fix(4));
t28=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6088,a[2]=t12,a[3]=t27,a[4]=t26,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* flag-clear */
t29=lf[48];
f_4996(4,t29,t28,t4,C_fix(1));
case C_make_character(33):
t26=(C_word)C_a_i_plus(&a,2,t2,C_fix(4));
t27=(C_word)C_a_i_plus(&a,2,t2,C_fix(4));
t28=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6113,a[2]=t12,a[3]=t27,a[4]=t26,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* flag-clear */
t29=lf[48];
f_4996(4,t29,t28,t4,C_fix(1));
default:
t26=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6120,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t12,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t27=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
t28=(C_word)C_subchar(((C_word*)t0)[4],t27);
if(C_truep((C_word)C_u_i_char_alphabeticp(t28))){
t29=(C_word)C_a_i_plus(&a,2,t2,C_fix(4));
/* string-scan-char */
f_4158(t26,((C_word*)t0)[4],C_make_character(62),(C_word)C_a_i_list(&a,1,t29));}
else{
t29=t26;
f_6120(2,t29,C_SCHEME_FALSE);}}}
case C_make_character(62):
t23=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
t24=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
t25=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6212,a[2]=t12,a[3]=t24,a[4]=t23,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* flag-clear */
t26=lf[48];
f_4996(4,t26,t25,t4,C_fix(1));
case C_make_character(40):
t23=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
if(C_truep((C_word)C_i_greater_or_equalp(t23,((C_word*)t0)[3]))){
/* error */
t24=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t24+1)))(4,t24,t1,lf[106],((C_word*)t0)[4]);}
else{
t24=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
t25=(C_word)C_subchar(((C_word*)t0)[4],t24);
if(C_truep((C_word)C_u_i_char_numericp(t25))){
t26=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6240,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t12,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t27=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
/* string-scan-char */
f_4158(t26,((C_word*)t0)[4],C_make_character(41),(C_word)C_a_i_list(&a,1,t27));}
else{
t26=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
t27=(C_word)C_subchar(((C_word*)t0)[4],t26);
if(C_truep((C_word)C_u_i_char_alphabeticp(t27))){
t28=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6300,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t4,a[5]=t12,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t29=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
/* string-scan-char */
f_4158(t28,((C_word*)t0)[4],C_make_character(41),(C_word)C_a_i_list(&a,1,t29));}
else{
t28=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t29=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t30=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6357,a[2]=t12,a[3]=t29,a[4]=t28,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* flag-clear */
t31=lf[48];
f_4996(4,t31,t30,t4,C_fix(1));}}}
case C_make_character(123):
/* error */
t23=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t23+1)))(4,t23,t1,lf[109],((C_word*)t0)[4]);
default:
t23=t4;
t24=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_set_block_item(t26,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6399,a[2]=t9,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t26,a[6]=t2,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[3],a[9]=t23,tmp=(C_word)a,a+=10,tmp));
t28=((C_word*)t26)[1];
f_6399(t28,t1,t24,t4,C_SCHEME_FALSE);}}}
else{
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t21=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t22=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5930,a[2]=t12,a[3]=t21,a[4]=t20,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* flag-join */
t23=lf[47];
f_4987(4,t23,t22,t4,C_fix(1));}}
case C_make_character(41):
if(C_truep((C_word)C_i_nullp(t6))){
/* error */
t16=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t1,lf[114],((C_word*)t0)[4]);}
else{
t16=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t17=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t18=(C_word)C_u_i_caar(t6);
t19=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6665,a[2]=t18,a[3]=t17,a[4]=t16,a[5]=t1,a[6]=((C_word*)t0)[2],a[7]=t6,tmp=(C_word)a,a+=8,tmp);
/* collect/terms417 */
t20=t11;
f_5272(t20,t19);}
case C_make_character(91):
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6680,a[2]=t9,a[3]=t6,a[4]=t4,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t17=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6704,a[2]=t16,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t18=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t19=((C_word*)t0)[4];
t20=t4;
t21=(C_word)C_fix((C_word)C_header_size(t19));
t22=(C_word)C_subchar(t19,t18);
t23=(C_word)C_eqp(C_make_character(94),t22);
t24=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8177,a[2]=t17,a[3]=t18,a[4]=t20,a[5]=t23,a[6]=t19,a[7]=t21,tmp=(C_word)a,a+=8,tmp);
/* flag-set? */
f_4977(t24,t20,C_fix(32));
case C_make_character(123):
t16=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t17=(C_word)C_i_greater_or_equalp(t16,((C_word*)t0)[3]);
t18=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6723,a[2]=t10,a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=t5,a[6]=t4,a[7]=t3,a[8]=t1,a[9]=((C_word*)t0)[2],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t17)){
t19=t18;
f_6723(t19,t17);}
else{
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t20=(C_word)C_subchar(((C_word*)t0)[4],t19);
t21=(C_word)C_u_i_char_numericp(t20);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6904,a[2]=t18,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t21)){
t23=t22;
f_6904(t23,t21);}
else{
t23=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t24=(C_word)C_subchar(((C_word*)t0)[4],t23);
t25=t22;
f_6904(t25,(C_word)C_eqp(C_make_character(44),t24));}}
case C_make_character(92):
t16=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
if(C_truep((C_word)C_i_greater_or_equalp(t16,((C_word*)t0)[3]))){
/* error */
t17=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t17+1)))(4,t17,t1,lf[133],((C_word*)t0)[4]);}
else{
t17=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t18=(C_word)C_subchar(((C_word*)t0)[4],t17);
switch(t18){
case C_make_character(100):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6970,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6974,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
/* collect415 */
t23=t9;
f_5180(t23,t22);
case C_make_character(68):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(C_word)C_a_i_cons(&a,2,lf[134],C_SCHEME_END_OF_LIST);
t22=(C_word)C_a_i_cons(&a,2,lf[116],t21);
t23=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7003,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t22,tmp=(C_word)a,a+=9,tmp);
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7007,a[2]=t23,tmp=(C_word)a,a+=3,tmp);
/* collect415 */
t25=t9;
f_5180(t25,t24);
case C_make_character(115):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7036,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7040,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
/* collect415 */
t23=t9;
f_5180(t23,t22);
case C_make_character(83):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(C_word)C_a_i_cons(&a,2,lf[135],C_SCHEME_END_OF_LIST);
t22=(C_word)C_a_i_cons(&a,2,lf[116],t21);
t23=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7069,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t22,tmp=(C_word)a,a+=9,tmp);
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7073,a[2]=t23,tmp=(C_word)a,a+=3,tmp);
/* collect415 */
t25=t9;
f_5180(t25,t24);
case C_make_character(119):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(C_word)C_a_i_cons(&a,2,lf[136],C_SCHEME_END_OF_LIST);
t22=(C_word)C_a_i_cons(&a,2,t21,C_SCHEME_END_OF_LIST);
t23=(C_word)C_a_i_cons(&a,2,lf[137],t22);
t24=(C_word)C_a_i_cons(&a,2,lf[62],t23);
t25=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7106,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t24,tmp=(C_word)a,a+=9,tmp);
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7110,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
/* collect415 */
t27=t9;
f_5180(t27,t26);
case C_make_character(87):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(C_word)C_a_i_cons(&a,2,lf[138],C_SCHEME_END_OF_LIST);
t22=(C_word)C_a_i_cons(&a,2,t21,C_SCHEME_END_OF_LIST);
t23=(C_word)C_a_i_cons(&a,2,lf[137],t22);
t24=(C_word)C_a_i_cons(&a,2,lf[62],t23);
t25=(C_word)C_a_i_cons(&a,2,t24,C_SCHEME_END_OF_LIST);
t26=(C_word)C_a_i_cons(&a,2,lf[116],t25);
t27=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7151,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t26,tmp=(C_word)a,a+=9,tmp);
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7155,a[2]=t27,tmp=(C_word)a,a+=3,tmp);
/* collect415 */
t29=t9;
f_5180(t29,t28);
case C_make_character(98):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(C_word)C_a_i_cons(&a,2,lf[139],C_SCHEME_END_OF_LIST);
t22=(C_word)C_a_i_cons(&a,2,lf[140],t21);
t23=(C_word)C_a_i_cons(&a,2,lf[62],t22);
t24=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7204,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t23,tmp=(C_word)a,a+=9,tmp);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7208,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
/* collect415 */
t26=t9;
f_5180(t26,t25);
case C_make_character(66):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7241,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7245,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
/* collect415 */
t23=t9;
f_5180(t23,t22);
case C_make_character(65):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7270,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7274,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
/* collect415 */
t23=t9;
f_5180(t23,t22);
case C_make_character(90):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(C_word)C_a_i_cons(&a,2,C_make_character(10),C_SCHEME_END_OF_LIST);
t22=(C_word)C_a_i_cons(&a,2,lf[87],t21);
t23=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7307,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t22,tmp=(C_word)a,a+=9,tmp);
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7311,a[2]=t23,tmp=(C_word)a,a+=3,tmp);
/* collect415 */
t25=t9;
f_5180(t25,t24);
case C_make_character(122):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7340,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7344,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
/* collect415 */
t23=t9;
f_5180(t23,t22);
case C_make_character(82):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7369,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7373,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
/* collect415 */
t23=t9;
f_5180(t23,t22);
case C_make_character(75):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7398,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7402,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
/* collect415 */
t23=t9;
f_5180(t23,t22);
case C_make_character(60):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7427,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7431,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
/* collect415 */
t23=t9;
f_5180(t23,t22);
case C_make_character(62):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7456,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7460,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
/* collect415 */
t23=t9;
f_5180(t23,t22);
case C_make_character(120):
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7471,a[2]=t9,a[3]=t6,a[4]=t4,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7499,a[2]=t19,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t21=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
/* string-parse-hex-escape */
f_8066(t20,((C_word*)t0)[4],t21,((C_word*)t0)[3]);
case C_make_character(107):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_subchar(((C_word*)t0)[4],t19);
if(C_truep((C_truep((C_word)C_i_eqvp(t20,C_make_character(60)))?C_SCHEME_TRUE:(C_truep((C_word)C_i_eqvp(t20,C_make_character(123)))?C_SCHEME_TRUE:(C_truep((C_word)C_i_eqvp(t20,C_make_character(39)))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
t21=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7524,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t9,a[5]=t6,a[6]=t4,a[7]=t1,a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
switch(t20){
case C_make_character(60):
t22=t21;
f_7524(t22,C_make_character(62));
case C_make_character(123):
t22=t21;
f_7524(t22,C_make_character(125));
case C_make_character(40):
t22=t21;
f_7524(t22,C_make_character(41));
default:
t22=(C_word)C_eqp(t20,C_make_character(91));
t23=t21;
f_7524(t23,(C_truep(t22)?C_make_character(93):t20));}}
else{
/* error */
t21=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t21+1)))(4,t21,t1,lf[149],((C_word*)t0)[4]);}
case C_make_character(81):
t19=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7608,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=t4,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* collect415 */
t20=t9;
f_5180(t20,t19);
default:
if(C_truep((C_word)C_u_i_char_numericp(t18))){
t19=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7722,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t9,a[5]=t6,a[6]=t4,a[7]=t1,a[8]=((C_word*)t0)[2],a[9]=((C_word*)t0)[3],tmp=(C_word)a,a+=10,tmp);
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=((C_word*)t0)[4];
t22=(C_word)C_a_i_list(&a,1,t20);
t23=(C_word)C_fix((C_word)C_header_size(t21));
t24=(C_word)C_i_pairp(t22);
t25=(C_truep(t24)?(C_word)C_u_i_car(t22):C_fix(0));
t26=C_SCHEME_UNDEFINED;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_set_block_item(t27,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4274,a[2]=t27,a[3]=t21,a[4]=t23,tmp=(C_word)a,a+=5,tmp));
t29=((C_word*)t27)[1];
f_4274(t29,t19,t25);}
else{
if(C_truep((C_word)C_u_i_char_alphabeticp(t18))){
t19=(C_word)C_i_assv(t18,lf[123]);
if(C_truep(t19)){
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t22=(C_word)C_slot(t19,C_fix(1));
t23=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7814,a[2]=t6,a[3]=t4,a[4]=t21,a[5]=t20,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t22,tmp=(C_word)a,a+=9,tmp);
/* collect415 */
t24=t9;
f_5180(t24,t23);}
else{
/* error */
t20=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t20+1)))(5,t20,t1,lf[150],((C_word*)t0)[4],t18);}}
else{
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7832,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* collect415 */
t22=t9;
f_5180(t22,t21);}}}}
case C_make_character(124):
t16=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t17=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t18=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7865,a[2]=t6,a[3]=t4,a[4]=t17,a[5]=t16,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* collect415 */
t19=t9;
f_5180(t19,t18);
case C_make_character(94):
t16=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7896,a[2]=t9,a[3]=t6,a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[2],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* flag-set? */
f_4977(t16,t4,C_fix(4));
case C_make_character(36):
t16=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7927,a[2]=t9,a[3]=t6,a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[2],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* flag-set? */
f_4977(t16,t4,C_fix(4));
case C_make_character(32):
t16=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7939,a[2]=t5,a[3]=t3,a[4]=t9,a[5]=t6,a[6]=t4,a[7]=t1,a[8]=((C_word*)t0)[2],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* flag-set? */
f_4977(t16,t4,C_fix(16));
case C_make_character(35):
t16=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7973,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t9,a[7]=t6,a[8]=t4,a[9]=t1,a[10]=((C_word*)t0)[2],a[11]=((C_word*)t0)[3],tmp=(C_word)a,a+=12,tmp);
/* flag-set? */
f_4977(t16,t4,C_fix(16));
default:
t16=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
/* lp407 */
t214=t1;
t215=t16;
t216=t3;
t217=t4;
t218=t5;
t219=t6;
t1=t214;
t2=t215;
t3=t216;
t4=t217;
t5=t218;
t6=t219;
goto loop;}}}}}

/* k7971 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7973,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7976,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1));
/* string-scan-char */
f_4158(t2,((C_word*)t0)[4],C_make_character(10),(C_word)C_a_i_list(&a,1,t3));}
else{
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1));
/* lp407 */
t3=((C_word*)((C_word*)t0)[10])[1];
f_5127(t3,((C_word*)t0)[9],t2,((C_word*)t0)[3],((C_word*)t0)[8],((C_word*)t0)[2],((C_word*)t0)[7]);}}

/* k7974 in k7971 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7976,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_a_i_minus(&a,2,((C_word*)t0)[7],C_fix(1)));
t3=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t4=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7994,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* collect415 */
t6=((C_word*)t0)[2];
f_5180(t6,t5);}

/* k7992 in k7974 in k7971 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp407 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_5127(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7937 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7939,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7954,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* collect415 */
t5=((C_word*)t0)[4];
f_5180(t5,t4);}
else{
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
/* lp407 */
t3=((C_word*)((C_word*)t0)[8])[1];
f_5127(t3,((C_word*)t0)[7],t2,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[2],((C_word*)t0)[5]);}}

/* k7952 in k7937 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp407 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_5127(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7925 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7927,2,t0,t1);}
t2=(C_truep(t1)?lf[152]:lf[143]);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7924,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* collect415 */
t6=((C_word*)t0)[2];
f_5180(t6,t5);}

/* k7922 in k7925 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7924,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5127(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7894 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7896,2,t0,t1);}
t2=(C_truep(t1)?lf[151]:lf[142]);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7893,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* collect415 */
t6=((C_word*)t0)[2];
f_5180(t6,t5);}

/* k7891 in k7894 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7893,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5127(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7863 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7865,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[62],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5127(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7830 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp407 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_5127(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7812 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7814,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5127(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* scan in lp in k5120 in string->sre in k3721 */
static void C_fcall f_4274(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4274,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nequalp(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
if(C_truep((C_word)C_u_i_char_numericp(t3))){
t4=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
/* scan161 */
t6=t1;
t7=t4;
t1=t6;
t2=t7;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}}

/* k7720 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7722,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7765,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* flag-set? */
f_4977(t3,((C_word*)t0)[6],C_fix(2));}

/* k7763 in k7720 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7765,2,t0,t1);}
t2=(C_truep(t1)?lf[146]:lf[147]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7754,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7758,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* substring */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[2],t5,((C_word*)t0)[7]);}

/* k7756 in k7763 in k7720 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k7752 in k7763 in k7720 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7754,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7742,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7746,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* collect415 */
t6=((C_word*)t0)[2];
f_5180(t6,t5);}

/* k7744 in k7752 in k7763 in k7720 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7740 in k7752 in k7763 in k7720 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7742,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[6])[1];
f_5127(t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7606 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7608,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[8],C_fix(2));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7617,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_7617(t6,((C_word*)t0)[2],t2);}

/* lp2 in k7606 in lp in k5120 in string->sre in k3721 */
static void C_fcall f_7617(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(29);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7617,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_greater_or_equalp(t2,((C_word*)t0)[9]))){
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[8],C_fix(2));
/* lp407 */
t4=((C_word*)((C_word*)t0)[7])[1];
f_5127(t4,t1,t2,t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
t4=(C_word)C_eqp(C_make_character(92),t3);
if(C_truep(t4)){
t5=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
if(C_truep((C_word)C_i_greater_or_equalp(t5,((C_word*)t0)[9]))){
t6=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t7=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[8],C_fix(2));
/* lp407 */
t8=((C_word*)((C_word*)t0)[7])[1];
f_5127(t8,t1,t6,t7,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t6=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t7=(C_word)C_subchar(((C_word*)t0)[3],t6);
t8=(C_word)C_eqp(C_make_character(69),t7);
if(C_truep(t8)){
t9=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t10=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7679,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=t10,a[5]=t9,a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t12=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[8],C_fix(2));
/* substring */
t13=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t13+1)))(5,t13,t11,((C_word*)t0)[3],t12,t2);}
else{
t9=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
/* lp2761 */
t19=t1;
t20=t9;
t1=t19;
t2=t20;
goto loop;}}}
else{
t5=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
/* lp2761 */
t19=t1;
t20=t5;
t1=t19;
t2=t20;
goto loop;}}}

/* k7677 in lp2 in k7606 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7679,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[8]);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5127(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7522 in lp in k5120 in string->sre in k3721 */
static void C_fcall f_7524(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7524,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7527,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(2));
/* string-scan-char */
f_4158(t2,((C_word*)t0)[3],t1,(C_word)C_a_i_list(&a,1,t3));}

/* k7525 in k7522 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7527,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7530,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(3));
/* substring */
t4=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[3],t3,t1);}
else{
t3=t2;
f_7530(2,t3,C_SCHEME_FALSE);}}

/* k7528 in k7525 in k7522 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7580,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* flag-set? */
f_4977(t2,((C_word*)t0)[5],C_fix(2));}

/* k7578 in k7528 in k7525 in k7522 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7580,2,t0,t1);}
t2=(C_truep(t1)?lf[146]:lf[147]);
t3=((C_word*)t0)[9];
if(C_truep(t3)){
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7577,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t5,a[6]=t4,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* string->symbol */
t7=*((C_word*)lf[96]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[3]);}
else{
/* error */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[7],lf[148],((C_word*)t0)[2]);}}

/* k7575 in k7578 in k7528 in k7525 in k7522 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7577,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7565,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7569,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* collect415 */
t6=((C_word*)t0)[2];
f_5180(t6,t5);}

/* k7567 in k7575 in k7578 in k7528 in k7525 in k7522 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7563 in k7575 in k7578 in k7528 in k7525 in k7522 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7565,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5127(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7497 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a7470 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7471(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7471,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t5=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7491,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t4,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7495,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* collect415 */
t8=((C_word*)t0)[2];
f_5180(t8,t7);}

/* k7493 in a7470 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7489 in a7470 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7491,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5127(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7458 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7454 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7456,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[139],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5127(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7429 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7425 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7427,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[140],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5127(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7400 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7396 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7398,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[145],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5127(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7371 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7367 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7369,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[144],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5127(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7342 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7338 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7340,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[143],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5127(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7309 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7305 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7307,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[143],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
/* lp407 */
t4=((C_word*)((C_word*)t0)[7])[1];
f_5127(t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k7272 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7268 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7270,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[142],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5127(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7243 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7239 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7241,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[141],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5127(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7206 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7202 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7204,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5127(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7153 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7149 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7151,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5127(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7108 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7104 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7106,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5127(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7071 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7067 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7069,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5127(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7038 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7034 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7036,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[135],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5127(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7005 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7001 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_7003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7003,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5127(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k6972 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6968 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6970,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[134],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5127(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k6902 in lp in k5120 in string->sre in k3721 */
static void C_fcall f_6904(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6723(t2,(C_word)C_i_not(t1));}

/* k6721 in lp in k5120 in string->sre in k3721 */
static void C_fcall f_6723(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6723,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[10],C_fix(1));
/* lp407 */
t3=((C_word*)((C_word*)t0)[9])[1];
f_5127(t3,((C_word*)t0)[8],t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6733,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* collect/single416 */
t3=((C_word*)t0)[2];
f_5200(t3,t2);}}

/* k6731 in k6721 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6733,2,t0,t1);}
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_slot(t1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6742,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* string-scan-char */
f_4158(t4,((C_word*)t0)[2],C_make_character(125),(C_word)C_a_i_list(&a,1,t5));}

/* k6740 in k6731 in k6721 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6742,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6745,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6886,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* substring */
t5=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,((C_word*)t0)[2],t4,t1);}

/* k6884 in k6740 in k6731 in k6721 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6886,2,t0,t1);}
t2=(C_word)C_fix((C_word)C_header_size(t1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4315,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_4315(t6,((C_word*)t0)[2],C_fix(0),C_fix(0),C_SCHEME_END_OF_LIST);}

/* lp in k6884 in k6740 in k6731 in k6721 in lp in k5120 in string->sre in k3721 */
static void C_fcall f_4315(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(20);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4315,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4318,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_greater_or_equalp(t2,((C_word*)t0)[3]))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4339,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* collect184 */
t7=t5;
f_4318(t7,t6);}
else{
t6=(C_word)C_subchar(((C_word*)t0)[4],t2);
t7=(C_word)C_eqp(C_make_character(44),t6);
if(C_truep(t7)){
t8=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t9=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4360,a[2]=t9,a[3]=t8,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* collect184 */
t11=t5;
f_4318(t11,t10);}
else{
t8=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
/* lp174 */
t14=t1;
t15=t8;
t16=t3;
t17=t4;
t1=t14;
t2=t15;
t3=t16;
t4=t17;
goto loop;}}}

/* k4358 in lp in k6884 in k6740 in k6731 in k6721 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_4360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp174 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_4315(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4337 in lp in k6884 in k6740 in k6731 in k6721 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_4339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* reverse */
t2=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* collect in lp in k6884 in k6740 in k6731 in k6721 in lp in k5120 in string->sre in k3721 */
static void C_fcall f_4318(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4318,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4326,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* substring */
t3=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4324 in collect in lp in k6884 in k6740 in k6731 in k6721 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_4326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4326,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k6743 in k6740 in k6731 in k6721 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6745,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6748,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_u_i_car(t1);
/* string->number */
C_string_to_number(3,0,t2,t3);}

/* k6746 in k6743 in k6740 in k6731 in k6721 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6748,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6754,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t4=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
/* string->number */
C_string_to_number(3,0,t3,t5);}
else{
t5=t3;
f_6754(2,t5,C_SCHEME_FALSE);}}

/* k6752 in k6746 in k6743 in k6740 in k6731 in k6721 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6754,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[10],C_fix(1));
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[90],t6);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6783,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t7,tmp=(C_word)a,a+=9,tmp);
/* ##sys#append */
t9=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
if(C_truep(t1)){
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t1,t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[89],t7);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6817,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t8,tmp=(C_word)a,a+=9,tmp);
/* ##sys#append */
t10=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[91],t6);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6852,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t7,tmp=(C_word)a,a+=9,tmp);
/* ##sys#append */
t9=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}}}

/* k6850 in k6752 in k6746 in k6743 in k6740 in k6731 in k6721 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6852,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5127(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k6815 in k6752 in k6746 in k6743 in k6740 in k6731 in k6721 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6817,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5127(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k6781 in k6752 in k6746 in k6743 in k6740 in k6731 in k6721 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6783,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5127(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8177,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8179,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));
if(C_truep(((C_word*)t0)[5])){
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8849,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* flag-set? */
f_4977(t6,((C_word*)t0)[4],C_fix(4));}
else{
/* go849 */
t5=((C_word*)t3)[1];
f_8179(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* k8847 in k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?lf[132]:C_SCHEME_END_OF_LIST);
/* go849 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8179(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST);}

/* go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_fcall f_8179(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word *a;
loop:
a=C_alloc(24);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8179,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_greater_or_equalp(t2,((C_word*)t0)[8]))){
/* error */
t5=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,lf[115]);}
else{
t5=(C_word)C_subchar(((C_word*)t0)[7],t2);
switch(t5){
case C_make_character(93):
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?(C_word)C_i_nullp(t4):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t9=(C_word)C_a_i_cons(&a,2,C_make_character(93),t3);
/* go849 */
t39=t1;
t40=t8;
t41=t9;
t42=t4;
t1=t39;
t2=t40;
t3=t41;
t4=t42;
goto loop;}
else{
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8218,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* flag-set? */
f_4977(t8,((C_word*)t0)[3],C_fix(2));}
case C_make_character(45):
t6=(C_word)C_i_nequalp(t2,((C_word*)t0)[2]);
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8329,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[7],a[5]=t4,a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=t5,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t6)){
t8=t7;
f_8329(t8,t6);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8481,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
if(C_truep((C_word)C_i_nequalp(t2,t9))){
t10=(C_word)C_subchar(((C_word*)t0)[7],((C_word*)t0)[2]);
t11=t8;
f_8481(t11,(C_word)C_eqp(C_make_character(94),t10));}
else{
t10=t8;
f_8481(t10,C_SCHEME_FALSE);}}
case C_make_character(91):
t6=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t7=(C_word)C_subchar(((C_word*)t0)[7],t6);
t8=(C_word)C_eqp(C_make_character(94),t7);
t9=(C_truep(t8)?(C_word)C_a_i_plus(&a,2,t2,C_fix(2)):(C_word)C_a_i_plus(&a,2,t2,C_fix(1)));
t10=(C_word)C_subchar(((C_word*)t0)[7],t9);
t11=(C_word)C_eqp(t10,C_make_character(58));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8533,a[2]=t9,a[3]=t8,a[4]=t3,a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t13=(C_word)C_a_i_plus(&a,2,t9,C_fix(1));
/* string-scan-char */
f_4158(t12,((C_word*)t0)[7],C_make_character(58),(C_word)C_a_i_list(&a,1,t13));}
else{
t12=(C_word)C_eqp(t10,C_make_character(61));
t13=(C_truep(t12)?t12:(C_word)C_eqp(t10,C_make_character(46)));
if(C_truep(t13)){
/* error */
t14=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[131],((C_word*)t0)[7]);}
else{
t14=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t15=(C_word)C_a_i_cons(&a,2,C_make_character(91),t3);
/* go849 */
t39=t1;
t40=t14;
t41=t15;
t42=t4;
t1=t39;
t2=t40;
t3=t41;
t4=t42;
goto loop;}}
case C_make_character(92):
t6=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t7=(C_word)C_subchar(((C_word*)t0)[7],t6);
t8=(C_word)C_eqp(t7,C_make_character(100));
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8666,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[7],a[4]=t7,a[5]=t3,a[6]=t4,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t8)){
t10=t9;
f_8666(t10,t8);}
else{
t10=(C_word)C_eqp(t7,C_make_character(68));
if(C_truep(t10)){
t11=t9;
f_8666(t11,t10);}
else{
t11=(C_word)C_eqp(t7,C_make_character(115));
if(C_truep(t11)){
t12=t9;
f_8666(t12,t11);}
else{
t12=(C_word)C_eqp(t7,C_make_character(83));
if(C_truep(t12)){
t13=t9;
f_8666(t13,t12);}
else{
t13=(C_word)C_eqp(t7,C_make_character(119));
t14=t9;
f_8666(t14,(C_truep(t13)?t13:(C_word)C_eqp(t7,C_make_character(87))));}}}}
default:
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8796,a[2]=((C_word*)t0)[7],a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=t2,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[4])){
t7=(C_word)C_fix((C_word)C_character_code(t5));
/* <= */
C_less_or_equal_p(5,0,t6,C_fix(128),t7,C_fix(255));}
else{
t7=t6;
f_8796(2,t7,C_SCHEME_FALSE);}}}}

/* k8794 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8796,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[8]));
t3=(C_word)C_slot(lf[125],t2);
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8814,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* utf8-string-ref */
f_8878(t5,((C_word*)t0)[2],((C_word*)t0)[7],t3);}
else{
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)t0)[6]);
/* go849 */
t4=((C_word*)((C_word*)t0)[5])[1];
f_8179(t4,((C_word*)t0)[4],t2,t3,((C_word*)t0)[3]);}}

/* k8812 in k8794 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8814,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* go849 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_8179(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8664 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_fcall f_8666(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8666,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8669,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8696,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_string(&a,2,C_make_character(92),((C_word*)t0)[4]);
/* string->sre */
t5=*((C_word*)lf[61]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],C_make_character(120));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8711,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8723,a[2]=t3,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(2));
/* string-parse-hex-escape */
f_8066(t4,((C_word*)t0)[3],t5,((C_word*)t0)[2]);}
else{
t3=(C_word)C_i_assv(((C_word*)t0)[4],lf[123]);
t4=(C_truep(t3)?(C_word)C_slot(t3,C_fix(1)):((C_word*)t0)[4]);
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(2));
t6=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
t7=(C_word)C_subchar(((C_word*)t0)[3],t6);
t8=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[5]);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
/* go849 */
t10=((C_word*)((C_word*)t0)[8])[1];
f_8179(t10,((C_word*)t0)[7],t5,t9,((C_word*)t0)[6]);}}}

/* k8721 in k8664 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8710 in k8664 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8711(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8711,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
/* go849 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_8179(t5,t1,t3,t4,((C_word*)t0)[2]);}

/* k8694 in k8664 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* sre->cset */
f_17663(((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8667 in k8664 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8669,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8680,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8692,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* filter */
f_4771(t4,*((C_word*)lf[128]+1),t1);}

/* k8690 in k8667 in k8664 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[117]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8678 in k8667 in k8664 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8680,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8684,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8688,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* filter */
f_4771(t3,*((C_word*)lf[127]+1),((C_word*)t0)[2]);}

/* k8686 in k8678 in k8667 in k8664 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[117]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8682 in k8678 in k8667 in k8664 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* go849 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_8179(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8531 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8533,2,t0,t1);}
t2=(C_word)C_i_not(t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8542,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t2)){
t4=t3;
f_8542(t4,t2);}
else{
t4=(C_word)C_a_i_plus(&a,2,t1,C_fix(1));
t5=(C_word)C_subchar(((C_word*)t0)[7],t4);
t6=(C_word)C_eqp(C_make_character(93),t5);
t7=t3;
f_8542(t7,(C_word)C_i_not(t6));}}

/* k8540 in k8531 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_fcall f_8542(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8542,NULL,2,t0,t1);}
if(C_truep(t1)){
/* error */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[9],lf[126],((C_word*)t0)[8]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8548,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8581,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8585,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
/* substring */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[8],t5,((C_word*)t0)[7]);}}

/* k8583 in k8540 in k8531 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->symbol */
t2=*((C_word*)lf[96]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k8579 in k8540 in k8531 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* sre->cset */
f_17663(((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8546 in k8540 in k8531 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8551,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
/* cset-complement */
f_18465(t2,t1);}
else{
t3=t2;
f_8551(2,t3,t1);}}

/* k8549 in k8546 in k8540 in k8531 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8551,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8562,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8574,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* filter */
f_4771(t4,*((C_word*)lf[128]+1),t1);}

/* k8572 in k8549 in k8546 in k8540 in k8531 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[117]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8560 in k8549 in k8546 in k8540 in k8531 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8562,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8566,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8570,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* filter */
f_4771(t3,*((C_word*)lf[127]+1),((C_word*)t0)[2]);}

/* k8568 in k8560 in k8549 in k8546 in k8540 in k8531 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[117]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8564 in k8560 in k8549 in k8546 in k8540 in k8531 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* go849 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_8179(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8479 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_fcall f_8481(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8481,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8329(t2,t1);}
else{
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
t3=(C_word)C_subchar(((C_word*)t0)[2],t2);
t4=((C_word*)t0)[4];
f_8329(t4,(C_word)C_eqp(C_make_character(93),t3));}}

/* k8327 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_fcall f_8329(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8329,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[10],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],((C_word*)t0)[8]);
/* go849 */
t4=((C_word*)((C_word*)t0)[7])[1];
f_8179(t4,((C_word*)t0)[6],t2,t3,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[8]))){
/* error */
t2=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[6],lf[121]);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[8]);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[10],C_fix(1));
t4=(C_word)C_subchar(((C_word*)t0)[4],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8360,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_eqp(C_make_character(92),t4);
t7=(C_truep(t6)?(C_word)C_i_assv(t4,lf[123]):C_SCHEME_FALSE);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8392,a[2]=t5,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t7)){
t9=(C_word)C_slot(t7,C_fix(1));
t10=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[10],C_fix(3));
t11=t8;
f_8392(2,t11,(C_word)C_a_i_list(&a,2,t9,t10));}
else{
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8409,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t8,a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t10=(C_word)C_eqp(C_make_character(92),t4);
if(C_truep(t10)){
t11=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[10],C_fix(2));
t12=(C_word)C_subchar(((C_word*)t0)[4],t11);
t13=t9;
f_8409(t13,(C_word)C_eqp(t12,C_make_character(120)));}
else{
t11=t9;
f_8409(t11,C_SCHEME_FALSE);}}}}}

/* k8407 in k8327 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_fcall f_8409(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8409,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(3));
/* string-parse-hex-escape */
f_8066(((C_word*)t0)[6],((C_word*)t0)[5],t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8422,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[3]));
/* <= */
C_less_or_equal_p(5,0,t2,C_fix(128),t3,C_fix(255));}
else{
t3=t2;
f_8422(2,t3,C_SCHEME_FALSE);}}}

/* k8420 in k8407 in k8327 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8422,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[5]));
t3=(C_word)C_slot(lf[125],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8432,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* utf8-string-ref */
f_8878(t4,((C_word*)t0)[2],t5,t3);}
else{
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(2));
t3=((C_word*)t0)[4];
f_8392(2,t3,(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t2));}}

/* k8430 in k8420 in k8407 in k8327 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8432,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8436,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* + */
C_plus(5,0,t2,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2]);}

/* k8434 in k8430 in k8420 in k8407 in k8327 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8436,2,t0,t1);}
t2=((C_word*)t0)[3];
f_8392(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k8390 in k8327 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8359 in k8327 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8360(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8360,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t2,((C_word*)t0)[5]))){
/* error */
t4=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[122],((C_word*)t0)[5],t2);}
else{
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
/* go849 */
t7=((C_word*)((C_word*)t0)[2])[1];
f_8179(t7,t1,t3,t4,t6);}}

/* k8216 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8218,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8221,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
/* filter */
f_4771(t2,lf[120],((C_word*)t0)[2]);}
else{
t3=t2;
f_8221(2,t3,C_SCHEME_END_OF_LIST);}}

/* k8219 in k8216 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8221,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8224,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=lf[120];
t4=((C_word*)t0)[2];
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4820,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_4820(t8,t2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_8224(2,t3,((C_word*)t0)[2]);}}

/* lp in k8219 in k8216 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_fcall f_4820(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4820,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* reverse */
t4=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4841,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_fix((C_word)C_character_code(t6));
if(C_truep((C_word)C_i_less_or_equalp(C_fix(128),t7))){
t8=t5;
f_4841(t8,t3);}
else{
t8=(C_word)C_u_i_car(t2);
t9=t5;
f_4841(t9,(C_word)C_a_i_cons(&a,2,t8,t3));}}}

/* k4839 in lp in k8219 in k8216 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_fcall f_4841(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp315 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4820(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8222 in k8219 in k8216 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8224,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8231,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8244,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t1))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8289,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8293,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8297,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* reverse */
t7=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t1);}
else{
t4=t3;
f_8244(t4,C_SCHEME_END_OF_LIST);}}

/* k8295 in k8222 in k8219 in k8216 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8297,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[3])?lf[118]:(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8301,tmp=(C_word)a,a+=2,tmp));
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t1);}

/* f_8301 in k8295 in k8222 in k8219 in k8216 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8301(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8301,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8291 in k8222 in k8219 in k8216 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* list->string */
t2=*((C_word*)lf[119]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k8287 in k8222 in k8219 in k8216 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8289,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
f_8244(t3,(C_word)C_a_i_list(&a,1,t2));}

/* k8242 in k8222 in k8219 in k8216 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_fcall f_8244(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8244,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8248,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8254,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8272,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* reverse */
t5=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}
else{
/* reverse */
t4=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}}
else{
t3=t2;
f_8248(t3,C_SCHEME_END_OF_LIST);}}

/* k8270 in k8242 in k8222 in k8219 in k8216 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* cset-case-insensitive */
t2=lf[118];
f_18475(3,t2,((C_word*)t0)[2],t1);}

/* k8252 in k8242 in k8222 in k8219 in k8216 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8254,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8265,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_17628,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_17628(t6,t2,t1,C_SCHEME_END_OF_LIST);}

/* lp in k8252 in k8242 in k8222 in k8219 in k8216 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_fcall f_17628(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_17628,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* reverse */
t4=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_u_i_cdar(t2);
t6=(C_word)C_u_i_caar(t2);
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
t8=(C_word)C_a_i_cons(&a,2,t5,t7);
/* lp2898 */
t10=t1;
t11=t4;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* k8263 in k8252 in k8242 in k8222 in k8219 in k8216 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8265,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[25],t1);
t3=((C_word*)t0)[2];
f_8248(t3,(C_word)C_a_i_list(&a,1,t2));}

/* k8246 in k8242 in k8222 in k8219 in k8216 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_fcall f_8248(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[117]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8229 in k8222 in k8219 in k8216 in go in k8175 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_8231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8231,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_a_i_cons(&a,2,lf[116],t1):f_12337(C_a_i(&a,3),t1));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}

/* k6702 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a6679 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6680(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6680,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t5=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6700,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t4,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* collect415 */
t7=((C_word*)t0)[2];
f_5180(t7,t6);}

/* k6698 in a6679 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6700,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5127(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k6663 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6665,2,t0,t1);}
t2=(C_word)C_u_i_cdar(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* lp407 */
t5=((C_word*)((C_word*)t0)[6])[1];
f_5127(t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3,t4);}

/* k5928 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5934,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* save418 */
t3=((C_word*)t0)[2];
f_5572(t3,t2);}

/* k5932 in k5928 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp407 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_5127(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1);}

/* lp2 in lp in k5120 in string->sre in k3721 */
static void C_fcall f_6399(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word *a;
loop:
a=C_alloc(28);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6399,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6402,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6411,a[2]=((C_word*)t0)[9],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_greater_or_equalp(t2,((C_word*)t0)[8]))){
/* error */
t7=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,lf[112],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t7=(C_word)C_subchar(((C_word*)t0)[7],t2);
switch(t7){
case C_make_character(105):
t8=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6460,a[2]=t4,a[3]=t8,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* join611 */
t10=t5;
f_6402(t10,t9,C_fix(2));
case C_make_character(109):
t8=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6477,a[2]=t4,a[3]=t8,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* join611 */
t10=t5;
f_6402(t10,t9,C_fix(4));
case C_make_character(120):
t8=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6494,a[2]=t4,a[3]=t8,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* join611 */
t10=t5;
f_6402(t10,t9,C_fix(16));
case C_make_character(117):
t8=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6514,a[2]=t4,a[3]=t8,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* join611 */
t10=t5;
f_6402(t10,t9,C_fix(32));
case C_make_character(45):
t8=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t9=(C_word)C_i_not(t4);
/* lp2601 */
t26=t1;
t27=t8;
t28=t3;
t29=t9;
t1=t26;
t2=t27;
t3=t28;
t4=t29;
goto loop;
case C_make_character(41):
t8=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t9=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6559,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t9,a[5]=t8,a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6563,a[2]=t10,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* collect415 */
t12=((C_word*)t0)[2];
f_5180(t12,t11);
case C_make_character(58):
t8=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t9=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6584,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t9,a[5]=t8,a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* new-res612 */
t11=t6;
f_6411(t11,t10,C_SCHEME_END_OF_LIST);
default:
/* error */
t8=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,lf[113],((C_word*)t0)[7]);}}}

/* k6582 in lp2 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6584,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6596,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* collect415 */
t3=((C_word*)t0)[2];
f_5180(t3,t2);}

/* k6594 in k6582 in lp2 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6596,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
/* lp407 */
t4=((C_word*)((C_word*)t0)[7])[1];
f_5127(t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k6561 in lp2 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* new-res612 */
t2=((C_word*)t0)[3];
f_6411(t2,((C_word*)t0)[2],t1);}

/* k6557 in lp2 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp407 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_5127(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6512 in lp2 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2601 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_6399(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6492 in lp2 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2601 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_6399(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6475 in lp2 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2601 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_6399(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6458 in lp2 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2601 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_6399(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* new-res in lp2 in lp in k5120 in string->sre in k3721 */
static void C_fcall f_6411(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6411,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6415,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* flag-set? */
f_4977(t3,((C_word*)t0)[2],C_fix(32));}

/* k6413 in new-res in lp2 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6415,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6418,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* flag-set? */
f_4977(t2,((C_word*)t0)[2],C_fix(32));}

/* k6416 in k6413 in new-res in lp2 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6418,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}
else{
t3=(C_truep(t1)?lf[110]:lf[111]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]));}}

/* join in lp2 in lp in k5120 in string->sre in k3721 */
static void C_fcall f_6402(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6402,NULL,3,t0,t1,t2);}
t3=(C_truep(((C_word*)t0)[3])?lf[48]:lf[47]);
t4=t3;
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,((C_word*)t0)[2],t2);}

/* k6355 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6357,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6361,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* save418 */
t3=((C_word*)t0)[2];
f_5572(t3,t2);}

/* k6359 in k6355 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp407 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_5127(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[108],t1);}

/* k6298 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6303,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6334,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(3));
/* substring */
t5=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,((C_word*)t0)[2],t4,t1);}

/* k6332 in k6298 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->symbol */
t2=*((C_word*)lf[96]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6301 in k6298 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6303,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(1));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6318,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* flag-clear */
t5=lf[48];
f_4996(4,t5,t4,((C_word*)t0)[2],C_fix(1));}

/* k6316 in k6301 in k6298 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6318,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[69],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6326,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* save418 */
t5=((C_word*)t0)[2];
f_5572(t5,t4);}

/* k6324 in k6316 in k6301 in k6298 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp407 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_5127(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6238 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6243,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6283,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(3));
/* substring */
t5=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,((C_word*)t0)[3],t4,t1);}

/* k6281 in k6238 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k6241 in k6238 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6243,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6267,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* flag-clear */
t6=lf[48];
f_4996(4,t6,t5,((C_word*)t0)[3],C_fix(1));}
else{
/* error */
t3=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[5],lf[107],((C_word*)t0)[2]);}}

/* k6265 in k6241 in k6238 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6267,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[69],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6275,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* save418 */
t5=((C_word*)t0)[2];
f_5572(t5,t4);}

/* k6273 in k6265 in k6241 in k6238 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp407 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_5127(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6210 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6216,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* save418 */
t3=((C_word*)t0)[2];
f_5572(t3,t2);}

/* k6214 in k6210 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp407 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_5127(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[105],t1);}

/* k6118 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6120,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_plus(&a,2,t1,C_fix(1));
t3=(C_word)C_a_i_plus(&a,2,t1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6138,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* flag-clear */
t5=lf[48];
f_4996(4,t5,t4,((C_word*)t0)[2],C_fix(1));}
else{
/* error */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[6],lf[104],((C_word*)t0)[3]);}}

/* k6136 in k6118 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6138,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6150,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6158,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],C_fix(3));
/* substring */
t5=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* k6156 in k6136 in k6118 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->symbol */
t2=*((C_word*)lf[96]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6148 in k6136 in k6118 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6150,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[77],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6146,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* save418 */
t5=((C_word*)t0)[2];
f_5572(t5,t4);}

/* k6144 in k6148 in k6136 in k6118 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp407 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_5127(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6111 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6113,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6117,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* save418 */
t3=((C_word*)t0)[2];
f_5572(t3,t2);}

/* k6115 in k6111 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp407 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_5127(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[103],t1);}

/* k6086 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6088,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6092,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* save418 */
t3=((C_word*)t0)[2];
f_5572(t3,t2);}

/* k6090 in k6086 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp407 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_5127(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[102],t1);}

/* k6043 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6045,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6049,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* save418 */
t3=((C_word*)t0)[2];
f_5572(t3,t2);}

/* k6047 in k6043 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp407 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_5127(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[100],t1);}

/* k6018 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6020,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6024,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* save418 */
t3=((C_word*)t0)[2];
f_5572(t3,t2);}

/* k6022 in k6018 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_6024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp407 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_5127(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[99],t1);}

/* k5993 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5999,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* save418 */
t3=((C_word*)t0)[2];
f_5572(t3,t2);}

/* k5997 in k5993 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp407 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_5127(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1);}

/* k5953 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5955,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,t1,((C_word*)t0)[7]);
t3=(C_word)C_a_i_plus(&a,2,t1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5970,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* collect415 */
t5=((C_word*)t0)[2];
f_5180(t5,t4);}

/* k5968 in k5953 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp407 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_5127(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5841 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5843,2,t0,t1);}
t2=(C_word)C_u_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5849,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t4=(C_word)C_a_i_string(&a,1,((C_word*)t0)[2]);
/* string->symbol */
t5=*((C_word*)lf[96]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k5847 in k5841 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5849,2,t0,t1);}
t2=f_10963(((C_word*)t0)[9]);
if(C_truep(t2)){
/* error */
t3=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[8],lf[93],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[9],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* sre-empty? */
t4=lf[95];
f_10759(3,t4,t3,((C_word*)t0)[9]);}}

/* k5862 in k5847 in k5841 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5864,2,t0,t1);}
if(C_truep(t1)){
/* error */
t2=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[10],lf[94],((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t5=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
/* lp407 */
t7=((C_word*)((C_word*)t0)[4])[1];
f_5127(t7,((C_word*)t0)[10],t2,t3,((C_word*)t0)[3],t6,((C_word*)t0)[2]);}}

/* k5644 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5646,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
/* error */
t2=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[7],lf[82],((C_word*)t0)[6],t1);}
else{
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5677,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_eqp(t6,lf[83]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5700,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_slot(t2,C_fix(1));
/* ##sys#append */
t10=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,t9,C_SCHEME_END_OF_LIST);}
else{
t8=(C_word)C_eqp(t6,lf[85]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5725,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t10=(C_word)C_slot(t2,C_fix(1));
/* ##sys#append */
t11=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,C_SCHEME_END_OF_LIST);}
else{
t9=(C_word)C_eqp(t6,lf[87]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5742,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_slot(t2,C_fix(1));
/* ##sys#append */
t12=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t11,C_SCHEME_END_OF_LIST);}
else{
t10=(C_word)C_eqp(t6,lf[89]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5759,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_slot(t2,C_fix(1));
/* ##sys#append */
t13=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t11,t12,C_SCHEME_END_OF_LIST);}
else{
t11=(C_word)C_eqp(t6,lf[90]);
if(C_truep(t11)){
t12=(C_word)C_u_i_cadr(t2);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5784,a[2]=t5,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
t14=(C_word)C_slot(t2,C_fix(1));
/* ##sys#append */
t15=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,t14,C_SCHEME_END_OF_LIST);}
else{
t12=(C_word)C_eqp(t6,lf[91]);
if(C_truep(t12)){
t13=(C_word)C_u_i_cadr(t2);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5813,a[2]=t5,a[3]=t13,tmp=(C_word)a,a+=4,tmp);
t15=(C_word)C_u_i_cddr(t2);
/* ##sys#append */
t16=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t14,t15,C_SCHEME_END_OF_LIST);}
else{
t13=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t14=t5;
f_5677(t14,(C_word)C_a_i_cons(&a,2,lf[87],t13));}}}}}}}
else{
t6=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t7=t5;
f_5677(t7,(C_word)C_a_i_cons(&a,2,lf[87],t6));}}}

/* k5811 in k5644 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5813,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_5677(t4,(C_word)C_a_i_cons(&a,2,lf[86],t3));}

/* k5782 in k5644 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5784,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
f_5677(t3,(C_word)C_a_i_cons(&a,2,lf[86],t2));}

/* k5757 in k5644 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5759,2,t0,t1);}
t2=((C_word*)t0)[2];
f_5677(t2,(C_word)C_a_i_cons(&a,2,lf[86],t1));}

/* k5740 in k5644 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5742,2,t0,t1);}
t2=((C_word*)t0)[2];
f_5677(t2,(C_word)C_a_i_cons(&a,2,lf[88],t1));}

/* k5723 in k5644 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5725,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t1);
t3=(C_word)C_a_i_cons(&a,2,C_fix(1),t2);
t4=((C_word*)t0)[2];
f_5677(t4,(C_word)C_a_i_cons(&a,2,lf[86],t3));}

/* k5698 in k5644 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5700,2,t0,t1);}
t2=((C_word*)t0)[2];
f_5677(t2,(C_word)C_a_i_cons(&a,2,lf[84],t1));}

/* k5675 in k5644 in lp in k5120 in string->sre in k3721 */
static void C_fcall f_5677(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5677,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
/* lp407 */
t4=((C_word*)((C_word*)t0)[7])[1];
f_5127(t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k5635 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5637,2,t0,t1);}
t2=(C_truep(t1)?lf[80]:lf[81]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5634,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* collect415 */
t4=((C_word*)t0)[2];
f_5180(t4,t3);}

/* k5632 in k5635 in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5634,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5127(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* save in lp in k5120 in string->sre in k3721 */
static void C_fcall f_5572(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5572,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5584,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* collect415 */
t3=((C_word*)t0)[2];
f_5180(t3,t2);}

/* k5582 in save in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5584,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[2]));}

/* collect/terms in lp in k5120 in string->sre in k3721 */
static void C_fcall f_5272(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5272,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5276,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* collect415 */
t3=((C_word*)t0)[2];
f_5180(t3,t2);}

/* k5274 in collect/terms in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5279,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t1))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5570,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* last */
f_4601(t3,t1);}
else{
t3=t2;
f_5279(t3,C_SCHEME_FALSE);}}

/* k5568 in k5274 in collect/terms in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5279(t2,(C_word)C_u_i_memq(t1,lf[78]));}

/* k5277 in k5274 in collect/terms in lp in k5120 in string->sre in k3721 */
static void C_fcall f_5279(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5279,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5282,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5532,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t4=(C_word)C_u_i_car(t1);
t5=t3;
f_5532(t5,(C_word)C_eqp(lf[77],t4));}
else{
t4=t3;
f_5532(t4,C_SCHEME_FALSE);}}

/* k5530 in k5277 in k5274 in collect/terms in lp in k5120 in string->sre in k3721 */
static void C_fcall f_5532(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5532,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5543,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* reverse */
t3=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
if(C_truep(((C_word*)t0)[2])){
t2=(C_word)C_u_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[4];
f_5282(t3,(C_word)C_a_i_list(&a,1,t2));}
else{
t2=((C_word*)t0)[4];
f_5282(t2,C_SCHEME_FALSE);}}}

/* k5541 in k5530 in k5277 in k5274 in collect/terms in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5543,2,t0,t1);}
t2=(C_word)C_u_i_cadr(t1);
t3=((C_word*)t0)[2];
f_5282(t3,(C_word)C_a_i_list(&a,2,lf[77],t2));}

/* k5280 in k5277 in k5274 in collect/terms in lp in k5120 in string->sre in k3721 */
static void C_fcall f_5282(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5282,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5285,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_u_i_car(((C_word*)t0)[3]);
t4=(C_word)C_eqp(lf[77],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5514,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* reverse */
t6=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5525,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* reverse */
t6=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}}
else{
t3=t2;
f_5285(2,t3,((C_word*)t0)[2]);}}

/* k5523 in k5280 in k5277 in k5274 in collect/terms in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(t1,C_fix(1));
/* reverse */
t3=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k5512 in k5280 in k5277 in k5274 in collect/terms in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_cddr(t1);
/* reverse */
t3=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k5283 in k5280 in k5277 in k5274 in collect/terms in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5285,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5290,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_5290(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* lp in k5283 in k5280 in k5277 in k5274 in collect/terms in lp in k5120 in string->sre in k3721 */
static void C_fcall f_5290(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(18);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5290,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5293,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t6=f_5293(C_a_i(&a,6),t5);
t7=f_12337(C_a_i(&a,3),t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5454,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* flag-set? */
f_4977(t8,((C_word*)t0)[3],C_fix(1));}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_eqp(lf[62],t6);
if(C_truep(t7)){
t8=(C_word)C_slot(t2,C_fix(1));
t9=f_5293(C_a_i(&a,6),t5);
/* lp456 */
t17=t1;
t18=t8;
t19=C_SCHEME_END_OF_LIST;
t20=t9;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}
else{
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_u_i_car(t2);
t10=(C_word)C_a_i_cons(&a,2,t9,t3);
/* lp456 */
t17=t1;
t18=t8;
t19=t10;
t20=t4;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}}}

/* k5452 in lp in k5283 in k5280 in k5277 in k5274 in collect/terms in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5454,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_a_i_list(&a,2,lf[68],((C_word*)t0)[4]):((C_word*)t0)[4]);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_u_i_car(((C_word*)t0)[3]);
t4=(C_word)C_eqp(lf[69],t3);
if(C_truep(t4)){
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_u_i_car(t2);
if(C_truep((C_truep((C_word)C_eqp(t5,lf[70]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t5,lf[71]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t5,lf[72]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t5,lf[73]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))){
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_eqp(lf[74],t6);
if(C_truep(t7)){
t8=(C_word)C_u_i_cadr(t2);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5359,a[2]=((C_word*)t0)[2],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_u_i_cddr(t2);
/* sre-sequence */
t12=t9;
f_5359(t12,f_12312(C_a_i(&a,3),t11));}
else{
t11=t9;
f_5359(t11,lf[75]);}}
else{
t8=(C_word)C_u_i_cadadr(t2);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5392,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t10=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_u_i_cddadr(t2);
/* sre-sequence */
t12=t9;
f_5392(t12,f_12312(C_a_i(&a,3),t11));}
else{
t11=t9;
f_5392(t11,lf[75]);}}}}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[75]);}}
else{
t5=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t6=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[2],((C_word*)t0)[3],t5);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k5390 in k5452 in lp in k5283 in k5280 in k5277 in k5274 in collect/terms in lp in k5120 in string->sre in k3721 */
static void C_fcall f_5392(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5392,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_u_i_cddr(((C_word*)t0)[4]):C_SCHEME_END_OF_LIST);
t5=f_12337(C_a_i(&a,3),t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t1,t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t7);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[69],t8));}

/* k5357 in k5452 in lp in k5283 in k5280 in k5277 in k5274 in collect/terms in lp in k5120 in string->sre in k3721 */
static void C_fcall f_5359(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5359,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[69],t3));}

/* shift in lp in k5283 in k5280 in k5277 in k5274 in collect/terms in lp in k5120 in string->sre in k3721 */
static C_word C_fcall f_5293(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_word t2;
t1=f_12312(C_a_i(&a,3),((C_word*)t0)[3]);
return((C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* collect/single in lp in k5120 in string->sre in k3721 */
static void C_fcall f_5200(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5200,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5204,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* flag-set? */
f_4977(t2,((C_word*)t0)[2],C_fix(32));}

/* k5202 in collect/single in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5204,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5207,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(C_truep(t1)?(C_word)C_i_greaterp(((C_word*)t0)[2],C_fix(1)):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[2],C_fix(1));
t5=((C_word*)t0)[4];
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9068,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_9068(t9,t2,t4);}
else{
t4=t2;
f_5207(2,t4,(C_word)C_a_i_minus(&a,2,((C_word*)t0)[2],C_fix(1)));}}

/* lp in k5202 in collect/single in lp in k5120 in string->sre in k3721 */
static void C_fcall f_9068(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9068,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nequalp(t2,C_fix(0)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(0));}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
t4=(C_word)C_fix((C_word)C_character_code(t3));
t5=(C_word)C_i_lessp(t4,C_fix(128));
t6=(C_truep(t5)?t5:(C_word)C_i_greater_or_equalp(t4,C_fix(192)));
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t2);}
else{
t7=(C_word)C_a_i_minus(&a,2,t2,C_fix(1));
/* lp994 */
t9=t1;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}}

/* k5205 in k5202 in collect/single in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5207,2,t0,t1);}
if(C_truep((C_word)C_i_lessp(t1,((C_word*)t0)[9]))){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5216,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5244,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[2],t1);
/* utf8-string-ref */
f_8878(t3,((C_word*)t0)[5],t1,t4);}
else{
t4=t3;
f_5244(2,t4,(C_word)C_subchar(((C_word*)t0)[5],t1));}}}

/* k5242 in k5205 in k5202 in collect/single in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* cased-char413 */
t2=((C_word*)t0)[3];
f_5130(3,t2,((C_word*)t0)[2],t1);}

/* k5214 in k5205 in k5202 in collect/single in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5216,2,t0,t1);}
if(C_truep((C_word)C_i_nequalp(((C_word*)t0)[7],((C_word*)t0)[6]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5236,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5240,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* substring */
t4=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[6],((C_word*)t0)[7]);}}

/* k5238 in k5214 in k5205 in k5202 in collect/single in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* cased-string414 */
t2=((C_word*)t0)[3];
f_5160(t2,((C_word*)t0)[2],t1);}

/* k5234 in k5214 in k5205 in k5202 in collect/single in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5236,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* collect in lp in k5120 in string->sre in k3721 */
static void C_fcall f_5180(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5180,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_nequalp(((C_word*)t0)[6],((C_word*)t0)[5]))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5194,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5198,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* substring */
t4=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[6]);}}

/* k5196 in collect in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* cased-string414 */
t2=((C_word*)t0)[3];
f_5160(t2,((C_word*)t0)[2],t1);}

/* k5192 in collect in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5194,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* cased-string in lp in k5120 in string->sre in k3721 */
static void C_fcall f_5160(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5160,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5167,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* flag-set? */
f_4977(t3,((C_word*)t0)[2],C_fix(2));}

/* k5165 in cased-string in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5167,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5174,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5178,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t4=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k5176 in k5165 in cased-string in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5172 in k5165 in cased-string in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5174,2,t0,t1);}
/* sre-sequence */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_12312(C_a_i(&a,3),t1));}

/* cased-char in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5130(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5130,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5155,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* flag-set? */
f_4977(t3,((C_word*)t0)[2],C_fix(2));}

/* k5153 in cased-char in lp in k5120 in string->sre in k3721 */
static void C_ccall f_5155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5155,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_u_i_char_alphabeticp(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
t4=(C_word)C_u_i_char_upper_casep(t3);
t5=(C_truep(t4)?(C_word)C_u_i_char_downcase(t3):(C_word)C_u_i_char_upcase(t3));
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[62],t7));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* symbol-list->flags in k3721 */
static void C_fcall f_5015(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5015,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5021,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_5021(t6,t1,t2,C_fix(0));}

/* lp in symbol-list->flags in k3721 */
static void C_fcall f_5021(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5021,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5039,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5046,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_eqp(t6,lf[50]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5052,a[2]=t6,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t8)){
t10=t9;
f_5052(t10,t8);}
else{
t10=(C_word)C_eqp(t6,lf[59]);
t11=t9;
f_5052(t11,(C_truep(t10)?t10:(C_word)C_eqp(t6,lf[60])));}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5050 in lp in symbol-list->flags in k3721 */
static void C_fcall f_5052(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_5046(t2,C_fix(2));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[2],lf[51]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[2],lf[52]));
if(C_truep(t3)){
t4=((C_word*)t0)[3];
f_5046(t4,C_fix(4));}
else{
t4=(C_word)C_eqp(((C_word*)t0)[2],lf[53]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[2],lf[54]));
if(C_truep(t5)){
t6=((C_word*)t0)[3];
f_5046(t6,C_fix(8));}
else{
t6=(C_word)C_eqp(((C_word*)t0)[2],lf[55]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[2],lf[56]));
if(C_truep(t7)){
t8=((C_word*)t0)[3];
f_5046(t8,C_fix(16));}
else{
t8=(C_word)C_eqp(((C_word*)t0)[2],lf[57]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(((C_word*)t0)[2],lf[58]));
t10=((C_word*)t0)[3];
f_5046(t10,(C_truep(t9)?C_fix(32):C_SCHEME_FALSE));}}}}}

/* k5044 in lp in symbol-list->flags in k3721 */
static void C_fcall f_5046(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* flag-join */
t2=lf[47];
f_4987(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5037 in lp in symbol-list->flags in k3721 */
static void C_ccall f_5039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp363 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5021(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* flag-clear in k3721 */
static void C_ccall f_4996(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4996,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_minus(&a,2,C_fix(65535),t3);
/* bit-and */
f_4930(t1,t2,t4);}

/* flag-join in k3721 */
static void C_ccall f_4987(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4987,4,t0,t1,t2,t3);}
if(C_truep(t3)){
/* bit-ior */
f_4883(t1,t2,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* flag-set? in k3721 */
static void C_fcall f_4977(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4977,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4985,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* bit-and */
f_4930(t4,t2,t3);}

/* k4983 in flag-set? in k3721 */
static void C_ccall f_4985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_nequalp(((C_word*)t0)[2],t1));}

/* bit-and in k3721 */
static void C_fcall f_4930(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4930,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_zerop(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}
else{
if(C_truep((C_word)C_i_zerop(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}
else{
t4=(C_word)C_i_oddp(t2);
t5=(C_truep(t4)?(C_word)C_i_oddp(t3):C_SCHEME_FALSE);
t6=(C_truep(t5)?C_fix(1):C_fix(0));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4958,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4962,a[2]=t3,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
C_quotient(4,0,t8,t2,C_fix(2));}}}

/* k4960 in bit-and in k3721 */
static void C_ccall f_4962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4962,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4966,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_quotient(4,0,t2,((C_word*)t0)[2],C_fix(2));}

/* k4964 in k4960 in bit-and in k3721 */
static void C_ccall f_4966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-and */
f_4930(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4956 in bit-and in k3721 */
static void C_ccall f_4958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4958,2,t0,t1);}
t2=(C_word)C_a_i_times(&a,2,C_fix(2),t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],t2));}

/* bit-ior in k3721 */
static void C_fcall f_4883(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4883,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_zerop(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_zerop(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_i_oddp(t2);
t5=(C_truep(t4)?t4:(C_word)C_i_oddp(t3));
t6=(C_truep(t5)?C_fix(1):C_fix(0));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4911,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4915,a[2]=t3,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
C_quotient(4,0,t8,t2,C_fix(2));}}}

/* k4913 in bit-ior in k3721 */
static void C_ccall f_4915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4919,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_quotient(4,0,t2,((C_word*)t0)[2],C_fix(2));}

/* k4917 in k4913 in bit-ior in k3721 */
static void C_ccall f_4919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-ior */
f_4883(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4909 in bit-ior in k3721 */
static void C_ccall f_4911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4911,2,t0,t1);}
t2=(C_word)C_a_i_times(&a,2,C_fix(2),t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],t2));}

/* bit-shl in k3721 */
static void C_fcall f_4867(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4867,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4875,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expt */
t5=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_fix(2),t3);}

/* k4873 in bit-shl in k3721 */
static void C_ccall f_4875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4875,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_times(&a,2,((C_word*)t0)[2],t1));}

/* bit-shr in k3721 */
static void C_fcall f_4857(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4857,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4865,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expt */
t5=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_fix(2),t3);}

/* k4863 in bit-shr in k3721 */
static void C_ccall f_4865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_quotient(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* filter in k3721 */
static void C_fcall f_4771(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4771,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4777,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4777(t7,t1,t3,C_SCHEME_END_OF_LIST);}

/* lp in filter in k3721 */
static void C_fcall f_4777(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4777,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* reverse */
t4=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4798,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4801,a[2]=t3,a[3]=t5,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_u_i_car(t2);
/* pred306 */
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}}

/* k4799 in lp in filter in k3721 */
static void C_ccall f_4801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4801,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
f_4798(t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_4798(t2,((C_word*)t0)[2]);}}

/* k4796 in lp in filter in k3721 */
static void C_fcall f_4798(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp308 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4777(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* fold in k3721 */
static void C_fcall f_4741(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4741,NULL,4,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4747,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_4747(t8,t1,t4,t3);}

/* lp in fold in k3721 */
static void C_fcall f_4747(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4747,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4765,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_i_car(t2);
/* kons298 */
t7=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t3);}}

/* k4763 in lp in fold in k3721 */
static void C_ccall f_4765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp301 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4747(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* every in k3721 */
static void C_fcall f_4692(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4692,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_nullp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_slot(t3,C_fix(1));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4712,a[2]=t8,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_4712(t10,t1,t5,t6);}}

/* lp in every in k3721 */
static void C_fcall f_4712(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4712,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
/* pred284 */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4728,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* pred284 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* k4726 in lp in every in k3721 */
static void C_ccall f_4728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* lp291 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4712(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* any in k3721 */
static void C_fcall f_4643(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4643,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_car(t3);
t5=(C_word)C_slot(t3,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4663,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_4663(t9,t1,t4,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* lp in any in k3721 */
static void C_fcall f_4663(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4663,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
/* pred270 */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4676,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* pred270 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* k4674 in lp in any in k3721 */
static void C_ccall f_4676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[3]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* lp274 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4663(t4,((C_word*)t0)[4],t2,t3);}}

/* last in k3721 */
static void C_fcall f_4601(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4601,NULL,2,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4616,tmp=(C_word)a,a+=2,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_4616(t2));}
else{
/* error */
t3=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[37],t2);}}

/* lp in last in k3721 */
static C_word C_fcall f_4616(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
t2=(C_word)C_slot(t1,C_fix(1));
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}
else{
return((C_word)C_u_i_car(t1));}}

/* find-tail in k3721 */
static void C_fcall f_4569(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4569,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4575,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4575(t7,t1,t3);}

/* lp in find-tail in k3721 */
static void C_fcall f_4575(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4575,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4588,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_i_car(t2);
/* pred253 */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}}

/* k4586 in lp in find-tail in k3721 */
static void C_ccall f_4588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* lp255 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4575(t3,((C_word*)t0)[4],t2);}}

/* find in k3721 */
static void C_fcall f_4557(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4557,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4561,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* find-tail */
f_4569(t4,t2,t3);}

/* k4559 in find in k3721 */
static void C_ccall f_4561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_u_i_car(t1):C_SCHEME_FALSE));}

/* take-up-to in k3721 */
static void C_fcall f_4514(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4514,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4520,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4520(t7,t1,t2,C_SCHEME_END_OF_LIST);}

/* lp in take-up-to in k3721 */
static void C_fcall f_4520(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4520,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4527,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_eqp(t2,((C_word*)t0)[2]);
t6=t4;
f_4527(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_4527(t5,C_SCHEME_FALSE);}}

/* k4525 in lp in take-up-to in k3721 */
static void C_fcall f_4527(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4527,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[4]);
/* lp235 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4520(t5,((C_word*)t0)[2],t2,t4);}
else{
/* reverse */
t2=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[4]);}}

/* zero-to in k3721 */
static void C_fcall f_4475(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4475,NULL,2,t1,t2);}
if(C_truep((C_word)C_i_less_or_equalp(t2,C_fix(0)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_a_i_minus(&a,2,t2,C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4491,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_4491(t7,t1,t3,C_SCHEME_END_OF_LIST);}}

/* lp in zero-to in k3721 */
static void C_fcall f_4491(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4491,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_zerop(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,C_fix(0),t3));}
else{
t4=(C_word)C_a_i_minus(&a,2,t2,C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
/* lp228 */
t7=t1;
t8=t4;
t9=t5;
t1=t7;
t2=t8;
t3=t9;
goto loop;}}

/* string-cat-reverse in k3721 */
static void C_fcall f_4418(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4418,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4426,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4428,tmp=(C_word)a,a+=2,tmp);
/* fold */
f_4741(t3,t4,C_fix(0),t2);}

/* a4427 in string-cat-reverse in k3721 */
static void C_ccall f_4428(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4428,4,t0,t1,t2,t3);}
t4=(C_word)C_fix((C_word)C_header_size(t2));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_plus(&a,2,t4,t3));}

/* k4424 in string-cat-reverse in k3721 */
static void C_ccall f_4426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4426,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4442,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* make-string */
t5=*((C_word*)lf[29]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t1);}

/* k4440 in k4424 in string-cat-reverse in k3721 */
static void C_ccall f_4442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4445,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4447,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4447(t6,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k4440 in k4424 in string-cat-reverse in k3721 */
static void C_fcall f_4447(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4447,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_car(t3);
t5=(C_word)C_fix((C_word)C_header_size(t4));
t6=(C_word)C_a_i_minus(&a,2,t2,t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4466,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t8=((C_word*)t0)[2];
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4391,a[2]=t10,a[3]=t8,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_4391(t12,t7,C_fix(0),t6);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* doloop200 in lp in k4440 in k4424 in string-cat-reverse in k3721 */
static void C_fcall f_4391(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4391,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_greater_or_equalp(t2,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_subchar(((C_word*)t0)[4],t2);
t5=(C_word)C_setsubchar(((C_word*)t0)[3],t3,t4);
t6=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t7=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t9=t1;
t10=t6;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}

/* k4464 in lp in k4440 in k4424 in string-cat-reverse in k3721 */
static void C_ccall f_4466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* lp216 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4447(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4443 in k4440 in k4424 in string-cat-reverse in k3721 */
static void C_ccall f_4445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* string-scan-char in k3721 */
static void C_fcall f_4158(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4158,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_fix((C_word)C_header_size(t2));
t6=(C_word)C_i_pairp(t4);
t7=(C_truep(t6)?(C_word)C_u_i_car(t4):C_fix(0));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4171,a[2]=t9,a[3]=t3,a[4]=t2,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_4171(t11,t1,t7);}

/* scan in string-scan-char in k3721 */
static void C_fcall f_4171(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4171,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nequalp(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[4],t2);
if(C_truep((C_word)C_i_eqvp(((C_word*)t0)[3],t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
/* scan133 */
t6=t1;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}}

/* irregex-match-end in k3721 */
static void C_ccall f_4143(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4143r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4143r(t0,t1,t2,t3);}}

static void C_ccall f_4143r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4151,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* irregex-match-index */
f_3999(t4,t2,t3);}

/* k4149 in irregex-match-end in k3721 */
static void C_ccall f_4151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4151,2,t0,t1);}
/* irregex-match-valid-index? */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_4045(C_a_i(&a,16),((C_word*)t0)[2],t1));}

/* irregex-match-start in k3721 */
static void C_ccall f_4120(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4120r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4120r(t0,t1,t2,t3);}}

static void C_ccall f_4120r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4124,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* irregex-match-index */
f_3999(t4,t2,t3);}

/* k4122 in irregex-match-start in k3721 */
static void C_ccall f_4124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4124,2,t0,t1);}
t2=f_4045(C_a_i(&a,16),((C_word*)t0)[3],t1);
if(C_truep(t2)){
t3=(C_word)C_a_i_times(&a,2,t1,C_fix(2));
t4=(C_word)C_a_i_plus(&a,2,C_fix(3),t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_slot(((C_word*)t0)[3],t4));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* irregex-match-substring in k3721 */
static void C_ccall f_4077(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4077r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4077r(t0,t1,t2,t3);}}

static void C_ccall f_4077r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4081,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* irregex-match-index */
f_3999(t4,t2,t3);}

/* k4079 in irregex-match-substring in k3721 */
static void C_ccall f_4081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4081,2,t0,t1);}
t2=f_4045(C_a_i(&a,16),((C_word*)t0)[3],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4094,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* irregex-match-string */
t4=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k4092 in k4079 in irregex-match-substring in k3721 */
static void C_ccall f_4094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4094,2,t0,t1);}
t2=(C_word)C_a_i_times(&a,2,((C_word*)t0)[4],C_fix(2));
t3=(C_word)C_a_i_plus(&a,2,C_fix(3),t2);
t4=(C_word)C_slot(((C_word*)t0)[3],t3);
t5=(C_word)C_a_i_times(&a,2,((C_word*)t0)[4],C_fix(2));
t6=(C_word)C_a_i_plus(&a,2,C_fix(4),t5);
t7=(C_word)C_slot(((C_word*)t0)[3],t6);
/* substring */
t8=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,((C_word*)t0)[2],t1,t4,t7);}

/* irregex-match-valid-index? in k3721 */
static C_word C_fcall f_4045(C_word *a,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
t3=(C_word)C_a_i_times(&a,2,t2,C_fix(2));
t4=(C_word)C_a_i_plus(&a,2,C_fix(3),t3);
t5=(C_word)C_fix((C_word)C_header_size(t1));
if(C_truep((C_word)C_i_lessp(t4,t5))){
t6=(C_word)C_a_i_times(&a,2,t2,C_fix(2));
t7=(C_word)C_a_i_plus(&a,2,C_fix(4),t6);
return((C_word)C_slot(t1,t7));}
else{
return(C_SCHEME_FALSE);}}

/* irregex-match-index in k3721 */
static void C_fcall f_3999(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3999,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_car(t3);
if(C_truep((C_word)C_i_numberp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_u_i_car(t3));}
else{
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_slot(t2,C_fix(2));
t7=(C_word)C_u_i_assq(t5,t6);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_slot(t7,C_fix(1)));}
else{
t8=(C_word)C_u_i_car(t3);
/* error */
t9=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t1,lf[19],t8);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}}

/* irregex-match-string in k3721 */
static void C_ccall f_3925(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3925,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* irregex-match-num-submatches in k3721 */
static void C_ccall f_3907(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3907,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3915,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_fix((C_word)C_header_size(t2));
t5=(C_word)C_a_i_minus(&a,2,t4,C_fix(3));
C_quotient(4,0,t3,t5,C_fix(2));}

/* k3913 in irregex-match-num-submatches in k3721 */
static void C_ccall f_3915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3915,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_minus(&a,2,t1,C_fix(1)));}

/* irregex-match-data? in k3721 */
static void C_ccall f_3854(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3854,3,t0,t1,t2);}
if(C_truep((C_word)C_i_vectorp(t2))){
t3=(C_word)C_fix((C_word)C_header_size(t2));
if(C_truep((C_word)C_i_greater_or_equalp(t3,C_fix(5)))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(lf[11],t4));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* irregex-reset-matches! in k3721 */
static void C_ccall f_3820(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3820,3,t0,t1,t2);}
t3=(C_word)C_fix((C_word)C_header_size(t2));
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3830,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_3830(t8,t1,t4);}

/* doloop49 in irregex-reset-matches! in k3721 */
static void C_fcall f_3830(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3830,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_less_or_equalp(t2,C_fix(3)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[3],t2,C_SCHEME_FALSE);
t4=(C_word)C_a_i_minus(&a,2,t2,C_fix(1));
t6=t1;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* irregex-new-matches in k3721 */
static void C_ccall f_3806(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3806,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3814,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* irregex-submatches */
t4=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k3812 in irregex-new-matches in k3721 */
static void C_ccall f_3814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3814,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3818,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* irregex-names */
t3=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3816 in k3812 in irregex-new-matches in k3721 */
static void C_ccall f_3818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3818,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3884,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_a_i_plus(&a,2,C_fix(1),t3);
t6=(C_word)C_a_i_times(&a,2,C_fix(2),t5);
t7=(C_word)C_a_i_plus(&a,2,t6,C_fix(3));
/* make-vector */
t8=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,t7,C_SCHEME_FALSE);}

/* k3882 in k3816 in k3812 in irregex-new-matches in k3721 */
static void C_ccall f_3884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_setslot(t1,C_fix(0),lf[11]);
t3=(C_word)C_i_set_i_slot(t1,C_fix(1),C_SCHEME_FALSE);
t4=(C_word)C_i_setslot(t1,C_fix(2),((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* irregex-names in k3721 */
static void C_ccall f_3800(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3800,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(8)));}

/* irregex-lengths in k3721 */
static void C_ccall f_3794(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3794,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(7)));}

/* irregex-submatches in k3721 */
static void C_ccall f_3788(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3788,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(6)));}

/* irregex-flags in k3721 */
static void C_ccall f_3782(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3782,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(5)));}

/* irregex-nfa in k3721 */
static void C_ccall f_3776(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3776,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(4)));}

/* irregex-dfa/extract in k3721 */
static void C_ccall f_3770(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3770,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* irregex-dfa/search in k3721 */
static void C_ccall f_3764(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3764,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* irregex-dfa in k3721 */
static void C_ccall f_3758(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3758,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* irregex? in k3721 */
static void C_ccall f_3732(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3732,3,t0,t1,t2);}
if(C_truep((C_word)C_i_vectorp(t2))){
t3=(C_word)C_fix((C_word)C_header_size(t2));
if(C_truep((C_word)C_i_nequalp(C_fix(9),t3))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(lf[1],t4));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[1064] = {
{"toplevel:regex_scm",(void*)C_regex_toplevel},
{"f_3723:regex_scm",(void*)f_3723},
{"f_20437:regex_scm",(void*)f_20437},
{"f_20444:regex_scm",(void*)f_20444},
{"f_20452:regex_scm",(void*)f_20452},
{"f_20484:regex_scm",(void*)f_20484},
{"f_20471:regex_scm",(void*)f_20471},
{"f_20474:regex_scm",(void*)f_20474},
{"f_20376:regex_scm",(void*)f_20376},
{"f_20388:regex_scm",(void*)f_20388},
{"f_20421:regex_scm",(void*)f_20421},
{"f_20407:regex_scm",(void*)f_20407},
{"f_20414:regex_scm",(void*)f_20414},
{"f_20425:regex_scm",(void*)f_20425},
{"f_20099:regex_scm",(void*)f_20099},
{"f_20114:regex_scm",(void*)f_20114},
{"f_20116:regex_scm",(void*)f_20116},
{"f_20371:regex_scm",(void*)f_20371},
{"f_20367:regex_scm",(void*)f_20367},
{"f_20356:regex_scm",(void*)f_20356},
{"f_20178:regex_scm",(void*)f_20178},
{"f_20208:regex_scm",(void*)f_20208},
{"f_20237:regex_scm",(void*)f_20237},
{"f_20285:regex_scm",(void*)f_20285},
{"f_20264:regex_scm",(void*)f_20264},
{"f_20260:regex_scm",(void*)f_20260},
{"f_20227:regex_scm",(void*)f_20227},
{"f_20223:regex_scm",(void*)f_20223},
{"f_20198:regex_scm",(void*)f_20198},
{"f_20176:regex_scm",(void*)f_20176},
{"f_20163:regex_scm",(void*)f_20163},
{"f_20150:regex_scm",(void*)f_20150},
{"f_20146:regex_scm",(void*)f_20146},
{"f_20110:regex_scm",(void*)f_20110},
{"f_20014:regex_scm",(void*)f_20014},
{"f_20027:regex_scm",(void*)f_20027},
{"f_20046:regex_scm",(void*)f_20046},
{"f_19962:regex_scm",(void*)f_19962},
{"f_19977:regex_scm",(void*)f_19977},
{"f_19994:regex_scm",(void*)f_19994},
{"f_19707:regex_scm",(void*)f_19707},
{"f_19849:regex_scm",(void*)f_19849},
{"f_19853:regex_scm",(void*)f_19853},
{"f_19944:regex_scm",(void*)f_19944},
{"f_19940:regex_scm",(void*)f_19940},
{"f_19911:regex_scm",(void*)f_19911},
{"f_19893:regex_scm",(void*)f_19893},
{"f_19886:regex_scm",(void*)f_19886},
{"f_19743:regex_scm",(void*)f_19743},
{"f_19749:regex_scm",(void*)f_19749},
{"f_19816:regex_scm",(void*)f_19816},
{"f_19804:regex_scm",(void*)f_19804},
{"f_19763:regex_scm",(void*)f_19763},
{"f_19728:regex_scm",(void*)f_19728},
{"f_19525:regex_scm",(void*)f_19525},
{"f_19689:regex_scm",(void*)f_19689},
{"f_19663:regex_scm",(void*)f_19663},
{"f_19688:regex_scm",(void*)f_19688},
{"f_19643:regex_scm",(void*)f_19643},
{"f_19544:regex_scm",(void*)f_19544},
{"f_19552:regex_scm",(void*)f_19552},
{"f_19556:regex_scm",(void*)f_19556},
{"f_19617:regex_scm",(void*)f_19617},
{"f_19598:regex_scm",(void*)f_19598},
{"f_19632:regex_scm",(void*)f_19632},
{"f_19627:regex_scm",(void*)f_19627},
{"f_19405:regex_scm",(void*)f_19405},
{"f_19480:regex_scm",(void*)f_19480},
{"f_19471:regex_scm",(void*)f_19471},
{"f_19407:regex_scm",(void*)f_19407},
{"f_19411:regex_scm",(void*)f_19411},
{"f_19466:regex_scm",(void*)f_19466},
{"f_19420:regex_scm",(void*)f_19420},
{"f_19430:regex_scm",(void*)f_19430},
{"f_19432:regex_scm",(void*)f_19432},
{"f_19293:regex_scm",(void*)f_19293},
{"f_19360:regex_scm",(void*)f_19360},
{"f_19351:regex_scm",(void*)f_19351},
{"f_19295:regex_scm",(void*)f_19295},
{"f_19299:regex_scm",(void*)f_19299},
{"f_19346:regex_scm",(void*)f_19346},
{"f_19308:regex_scm",(void*)f_19308},
{"f_19318:regex_scm",(void*)f_19318},
{"f_19320:regex_scm",(void*)f_19320},
{"f_19342:regex_scm",(void*)f_19342},
{"f_19231:regex_scm",(void*)f_19231},
{"f_19235:regex_scm",(void*)f_19235},
{"f_19238:regex_scm",(void*)f_19238},
{"f_19248:regex_scm",(void*)f_19248},
{"f_19250:regex_scm",(void*)f_19250},
{"f_19185:regex_scm",(void*)f_19185},
{"f_19189:regex_scm",(void*)f_19189},
{"f_19192:regex_scm",(void*)f_19192},
{"f_19202:regex_scm",(void*)f_19202},
{"f_19204:regex_scm",(void*)f_19204},
{"f_19229:regex_scm",(void*)f_19229},
{"f_19164:regex_scm",(void*)f_19164},
{"f_19171:regex_scm",(void*)f_19171},
{"f_19180:regex_scm",(void*)f_19180},
{"f_19061:regex_scm",(void*)f_19061},
{"f_19104:regex_scm",(void*)f_19104},
{"f_19099:regex_scm",(void*)f_19099},
{"f_19094:regex_scm",(void*)f_19094},
{"f_19063:regex_scm",(void*)f_19063},
{"f_19075:regex_scm",(void*)f_19075},
{"f_19078:regex_scm",(void*)f_19078},
{"f_19081:regex_scm",(void*)f_19081},
{"f_19071:regex_scm",(void*)f_19071},
{"f_19043:regex_scm",(void*)f_19043},
{"f_18861:regex_scm",(void*)f_18861},
{"f_18867:regex_scm",(void*)f_18867},
{"f_18989:regex_scm",(void*)f_18989},
{"f_18993:regex_scm",(void*)f_18993},
{"f_19001:regex_scm",(void*)f_19001},
{"f_18985:regex_scm",(void*)f_18985},
{"f_18960:regex_scm",(void*)f_18960},
{"f_18964:regex_scm",(void*)f_18964},
{"f_18956:regex_scm",(void*)f_18956},
{"f_18923:regex_scm",(void*)f_18923},
{"f_18895:regex_scm",(void*)f_18895},
{"f_18805:regex_scm",(void*)f_18805},
{"f_18838:regex_scm",(void*)f_18838},
{"f_18859:regex_scm",(void*)f_18859},
{"f_18849:regex_scm",(void*)f_18849},
{"f_18811:regex_scm",(void*)f_18811},
{"f_18815:regex_scm",(void*)f_18815},
{"f_18822:regex_scm",(void*)f_18822},
{"f_18836:regex_scm",(void*)f_18836},
{"f_18826:regex_scm",(void*)f_18826},
{"f_18753:regex_scm",(void*)f_18753},
{"f_18803:regex_scm",(void*)f_18803},
{"f_18757:regex_scm",(void*)f_18757},
{"f_18795:regex_scm",(void*)f_18795},
{"f_18771:regex_scm",(void*)f_18771},
{"f_18779:regex_scm",(void*)f_18779},
{"f_18791:regex_scm",(void*)f_18791},
{"f_18787:regex_scm",(void*)f_18787},
{"f_18775:regex_scm",(void*)f_18775},
{"f_18640:regex_scm",(void*)f_18640},
{"f_18644:regex_scm",(void*)f_18644},
{"f_18647:regex_scm",(void*)f_18647},
{"f_18730:regex_scm",(void*)f_18730},
{"f_18701:regex_scm",(void*)f_18701},
{"f_18664:regex_scm",(void*)f_18664},
{"f_18677:regex_scm",(void*)f_18677},
{"f_18689:regex_scm",(void*)f_18689},
{"f_18692:regex_scm",(void*)f_18692},
{"f_18695:regex_scm",(void*)f_18695},
{"f_18750:regex_scm",(void*)f_18750},
{"f_18475:regex_scm",(void*)f_18475},
{"f_18481:regex_scm",(void*)f_18481},
{"f_18497:regex_scm",(void*)f_18497},
{"f_18534:regex_scm",(void*)f_18534},
{"f_18592:regex_scm",(void*)f_18592},
{"f_18549:regex_scm",(void*)f_18549},
{"f_18545:regex_scm",(void*)f_18545},
{"f_18517:regex_scm",(void*)f_18517},
{"f_18465:regex_scm",(void*)f_18465},
{"f_18473:regex_scm",(void*)f_18473},
{"f_18347:regex_scm",(void*)f_18347},
{"f_18353:regex_scm",(void*)f_18353},
{"f_18455:regex_scm",(void*)f_18455},
{"f_18363:regex_scm",(void*)f_18363},
{"f_18430:regex_scm",(void*)f_18430},
{"f_18371:regex_scm",(void*)f_18371},
{"f_18422:regex_scm",(void*)f_18422},
{"f_18375:regex_scm",(void*)f_18375},
{"f_18384:regex_scm",(void*)f_18384},
{"f_18387:regex_scm",(void*)f_18387},
{"f_18394:regex_scm",(void*)f_18394},
{"f_18226:regex_scm",(void*)f_18226},
{"f_18333:regex_scm",(void*)f_18333},
{"f_18249:regex_scm",(void*)f_18249},
{"f_18308:regex_scm",(void*)f_18308},
{"f_18257:regex_scm",(void*)f_18257},
{"f_18300:regex_scm",(void*)f_18300},
{"f_18261:regex_scm",(void*)f_18261},
{"f_18270:regex_scm",(void*)f_18270},
{"f_18273:regex_scm",(void*)f_18273},
{"f_18139:regex_scm",(void*)f_18139},
{"f_18216:regex_scm",(void*)f_18216},
{"f_18149:regex_scm",(void*)f_18149},
{"f_18195:regex_scm",(void*)f_18195},
{"f_18167:regex_scm",(void*)f_18167},
{"f_18159:regex_scm",(void*)f_18159},
{"f_17994:regex_scm",(void*)f_17994},
{"f_18010:regex_scm",(void*)f_18010},
{"f_17944:regex_scm",(void*)f_17944},
{"f_17950:regex_scm",(void*)f_17950},
{"f_17663:regex_scm",(void*)f_17663},
{"f_17673:regex_scm",(void*)f_17673},
{"f_17837:regex_scm",(void*)f_17837},
{"f_17841:regex_scm",(void*)f_17841},
{"f_12421:regex_scm",(void*)f_12421},
{"f_12448:regex_scm",(void*)f_12448},
{"f_12444:regex_scm",(void*)f_12444},
{"f_17820:regex_scm",(void*)f_17820},
{"f_17587:regex_scm",(void*)f_17587},
{"f_17810:regex_scm",(void*)f_17810},
{"f_17789:regex_scm",(void*)f_17789},
{"f_17793:regex_scm",(void*)f_17793},
{"f_17781:regex_scm",(void*)f_17781},
{"f_17758:regex_scm",(void*)f_17758},
{"f_17762:regex_scm",(void*)f_17762},
{"f_17733:regex_scm",(void*)f_17733},
{"f_17737:regex_scm",(void*)f_17737},
{"f_17729:regex_scm",(void*)f_17729},
{"f_17702:regex_scm",(void*)f_17702},
{"f_17676:regex_scm",(void*)f_17676},
{"f_17546:regex_scm",(void*)f_17546},
{"f_17548:regex_scm",(void*)f_17548},
{"f_17555:regex_scm",(void*)f_17555},
{"f_15182:regex_scm",(void*)f_15182},
{"f_15222:regex_scm",(void*)f_15222},
{"f_15101:regex_scm",(void*)f_15101},
{"f_15107:regex_scm",(void*)f_15107},
{"f_15156:regex_scm",(void*)f_15156},
{"f_15154:regex_scm",(void*)f_15154},
{"f_15146:regex_scm",(void*)f_15146},
{"f_15134:regex_scm",(void*)f_15134},
{"f_15138:regex_scm",(void*)f_15138},
{"f_14985:regex_scm",(void*)f_14985},
{"f_15018:regex_scm",(void*)f_15018},
{"f_15022:regex_scm",(void*)f_15022},
{"f_15030:regex_scm",(void*)f_15030},
{"f_14999:regex_scm",(void*)f_14999},
{"f_14911:regex_scm",(void*)f_14911},
{"f_14919:regex_scm",(void*)f_14919},
{"f_14923:regex_scm",(void*)f_14923},
{"f_14437:regex_scm",(void*)f_14437},
{"f_14646:regex_scm",(void*)f_14646},
{"f_14674:regex_scm",(void*)f_14674},
{"f_14831:regex_scm",(void*)f_14831},
{"f_14732:regex_scm",(void*)f_14732},
{"f_14802:regex_scm",(void*)f_14802},
{"f_14737:regex_scm",(void*)f_14737},
{"f_14790:regex_scm",(void*)f_14790},
{"f_14750:regex_scm",(void*)f_14750},
{"f_14753:regex_scm",(void*)f_14753},
{"f_14760:regex_scm",(void*)f_14760},
{"f_14718:regex_scm",(void*)f_14718},
{"f_14679:regex_scm",(void*)f_14679},
{"f_14706:regex_scm",(void*)f_14706},
{"f_14690:regex_scm",(void*)f_14690},
{"f_14468:regex_scm",(void*)f_14468},
{"f_14517:regex_scm",(void*)f_14517},
{"f_14584:regex_scm",(void*)f_14584},
{"f_14522:regex_scm",(void*)f_14522},
{"f_14572:regex_scm",(void*)f_14572},
{"f_14538:regex_scm",(void*)f_14538},
{"f_14542:regex_scm",(void*)f_14542},
{"f_14534:regex_scm",(void*)f_14534},
{"f_14503:regex_scm",(void*)f_14503},
{"f_14440:regex_scm",(void*)f_14440},
{"f_14140:regex_scm",(void*)f_14140},
{"f_14255:regex_scm",(void*)f_14255},
{"f_14153:regex_scm",(void*)f_14153},
{"f_14348:regex_scm",(void*)f_14348},
{"f_14427:regex_scm",(void*)f_14427},
{"f_14366:regex_scm",(void*)f_14366},
{"f_14378:regex_scm",(void*)f_14378},
{"f_14186:regex_scm",(void*)f_14186},
{"f_14198:regex_scm",(void*)f_14198},
{"f_14233:regex_scm",(void*)f_14233},
{"f_14205:regex_scm",(void*)f_14205},
{"f_14229:regex_scm",(void*)f_14229},
{"f_14221:regex_scm",(void*)f_14221},
{"f_14167:regex_scm",(void*)f_14167},
{"f_14332:regex_scm",(void*)f_14332},
{"f_14336:regex_scm",(void*)f_14336},
{"f_14275:regex_scm",(void*)f_14275},
{"f_14294:regex_scm",(void*)f_14294},
{"f_14308:regex_scm",(void*)f_14308},
{"f_14306:regex_scm",(void*)f_14306},
{"f_14292:regex_scm",(void*)f_14292},
{"f_14277:regex_scm",(void*)f_14277},
{"f_13350:regex_scm",(void*)f_13350},
{"f_13368:regex_scm",(void*)f_13368},
{"f_13631:regex_scm",(void*)f_13631},
{"f_13685:regex_scm",(void*)f_13685},
{"f_13945:regex_scm",(void*)f_13945},
{"f_14033:regex_scm",(void*)f_14033},
{"f_13951:regex_scm",(void*)f_13951},
{"f_14029:regex_scm",(void*)f_14029},
{"f_13954:regex_scm",(void*)f_13954},
{"f_14009:regex_scm",(void*)f_14009},
{"f_13960:regex_scm",(void*)f_13960},
{"f_13979:regex_scm",(void*)f_13979},
{"f_13885:regex_scm",(void*)f_13885},
{"f_13929:regex_scm",(void*)f_13929},
{"f_13891:regex_scm",(void*)f_13891},
{"f_13913:regex_scm",(void*)f_13913},
{"f_13782:regex_scm",(void*)f_13782},
{"f_13864:regex_scm",(void*)f_13864},
{"f_13785:regex_scm",(void*)f_13785},
{"f_13849:regex_scm",(void*)f_13849},
{"f_13788:regex_scm",(void*)f_13788},
{"f_13814:regex_scm",(void*)f_13814},
{"f_13806:regex_scm",(void*)f_13806},
{"f_13810:regex_scm",(void*)f_13810},
{"f_13802:regex_scm",(void*)f_13802},
{"f_13773:regex_scm",(void*)f_13773},
{"f_13688:regex_scm",(void*)f_13688},
{"f_13715:regex_scm",(void*)f_13715},
{"f_13743:regex_scm",(void*)f_13743},
{"f_13741:regex_scm",(void*)f_13741},
{"f_13729:regex_scm",(void*)f_13729},
{"f_13733:regex_scm",(void*)f_13733},
{"f_13704:regex_scm",(void*)f_13704},
{"f_13634:regex_scm",(void*)f_13634},
{"f_13637:regex_scm",(void*)f_13637},
{"f_13651:regex_scm",(void*)f_13651},
{"f_13614:regex_scm",(void*)f_13614},
{"f_13591:regex_scm",(void*)f_13591},
{"f_13514:regex_scm",(void*)f_13514},
{"f_13481:regex_scm",(void*)f_13481},
{"f_13503:regex_scm",(void*)f_13503},
{"f_13488:regex_scm",(void*)f_13488},
{"f_13458:regex_scm",(void*)f_13458},
{"f_13437:regex_scm",(void*)f_13437},
{"f_13433:regex_scm",(void*)f_13433},
{"f_13385:regex_scm",(void*)f_13385},
{"f_13400:regex_scm",(void*)f_13400},
{"f_13406:regex_scm",(void*)f_13406},
{"f_13404:regex_scm",(void*)f_13404},
{"f_13371:regex_scm",(void*)f_13371},
{"f_13243:regex_scm",(void*)f_13243},
{"f_13257:regex_scm",(void*)f_13257},
{"f_13295:regex_scm",(void*)f_13295},
{"f_13270:regex_scm",(void*)f_13270},
{"f_13065:regex_scm",(void*)f_13065},
{"f_13069:regex_scm",(void*)f_13069},
{"f_13072:regex_scm",(void*)f_13072},
{"f_13084:regex_scm",(void*)f_13084},
{"f_13112:regex_scm",(void*)f_13112},
{"f_13129:regex_scm",(void*)f_13129},
{"f_13115:regex_scm",(void*)f_13115},
{"f_13109:regex_scm",(void*)f_13109},
{"f_13087:regex_scm",(void*)f_13087},
{"f_13105:regex_scm",(void*)f_13105},
{"f_13102:regex_scm",(void*)f_13102},
{"f_12906:regex_scm",(void*)f_12906},
{"f_12913:regex_scm",(void*)f_12913},
{"f_13029:regex_scm",(void*)f_13029},
{"f_13034:regex_scm",(void*)f_13034},
{"f_13062:regex_scm",(void*)f_13062},
{"f_13044:regex_scm",(void*)f_13044},
{"f_13026:regex_scm",(void*)f_13026},
{"f_12919:regex_scm",(void*)f_12919},
{"f_13022:regex_scm",(void*)f_13022},
{"f_13164:regex_scm",(void*)f_13164},
{"f_13199:regex_scm",(void*)f_13199},
{"f_13183:regex_scm",(void*)f_13183},
{"f_12944:regex_scm",(void*)f_12944},
{"f_13018:regex_scm",(void*)f_13018},
{"f_12953:regex_scm",(void*)f_12953},
{"f_12959:regex_scm",(void*)f_12959},
{"f_12964:regex_scm",(void*)f_12964},
{"f_12974:regex_scm",(void*)f_12974},
{"f_12989:regex_scm",(void*)f_12989},
{"f_12986:regex_scm",(void*)f_12986},
{"f_12941:regex_scm",(void*)f_12941},
{"f_12922:regex_scm",(void*)f_12922},
{"f_12937:regex_scm",(void*)f_12937},
{"f_12934:regex_scm",(void*)f_12934},
{"f_12860:regex_scm",(void*)f_12860},
{"f_12864:regex_scm",(void*)f_12864},
{"f_12882:regex_scm",(void*)f_12882},
{"f_12873:regex_scm",(void*)f_12873},
{"f_12743:regex_scm",(void*)f_12743},
{"f_12762:regex_scm",(void*)f_12762},
{"f_12833:regex_scm",(void*)f_12833},
{"f_12800:regex_scm",(void*)f_12800},
{"f_12707:regex_scm",(void*)f_12707},
{"f_12737:regex_scm",(void*)f_12737},
{"f_12729:regex_scm",(void*)f_12729},
{"f_12477:regex_scm",(void*)f_12477},
{"f_12575:regex_scm",(void*)f_12575},
{"f_12362:regex_scm",(void*)f_12362},
{"f_12337:regex_scm",(void*)f_12337},
{"f_12312:regex_scm",(void*)f_12312},
{"f_11217:regex_scm",(void*)f_11217},
{"f_11223:regex_scm",(void*)f_11223},
{"f_11248:regex_scm",(void*)f_11248},
{"f_11191:regex_scm",(void*)f_11191},
{"f_11105:regex_scm",(void*)f_11105},
{"f_11144:regex_scm",(void*)f_11144},
{"f_11157:regex_scm",(void*)f_11157},
{"f_11019:regex_scm",(void*)f_11019},
{"f_11058:regex_scm",(void*)f_11058},
{"f_10963:regex_scm",(void*)f_10963},
{"f_10887:regex_scm",(void*)f_10887},
{"f_10912:regex_scm",(void*)f_10912},
{"f_10759:regex_scm",(void*)f_10759},
{"f_10778:regex_scm",(void*)f_10778},
{"f_10827:regex_scm",(void*)f_10827},
{"f_10618:regex_scm",(void*)f_10618},
{"f_10622:regex_scm",(void*)f_10622},
{"f_10305:regex_scm",(void*)f_10305},
{"f_10309:regex_scm",(void*)f_10309},
{"f_10311:regex_scm",(void*)f_10311},
{"f_10565:regex_scm",(void*)f_10565},
{"f_10576:regex_scm",(void*)f_10576},
{"f_10572:regex_scm",(void*)f_10572},
{"f_10424:regex_scm",(void*)f_10424},
{"f_10528:regex_scm",(void*)f_10528},
{"f_10509:regex_scm",(void*)f_10509},
{"f_10433:regex_scm",(void*)f_10433},
{"f_10454:regex_scm",(void*)f_10454},
{"f_10439:regex_scm",(void*)f_10439},
{"f_10449:regex_scm",(void*)f_10449},
{"f_10407:regex_scm",(void*)f_10407},
{"f_10405:regex_scm",(void*)f_10405},
{"f_10380:regex_scm",(void*)f_10380},
{"f_10378:regex_scm",(void*)f_10378},
{"f_10314:regex_scm",(void*)f_10314},
{"f_10625:regex_scm",(void*)f_10625},
{"f_10628:regex_scm",(void*)f_10628},
{"f_10631:regex_scm",(void*)f_10631},
{"f_10634:regex_scm",(void*)f_10634},
{"f_10708:regex_scm",(void*)f_10708},
{"f_10637:regex_scm",(void*)f_10637},
{"f_10640:regex_scm",(void*)f_10640},
{"f_10643:regex_scm",(void*)f_10643},
{"f_15238:regex_scm",(void*)f_15238},
{"f_15562:regex_scm",(void*)f_15562},
{"f_15252:regex_scm",(void*)f_15252},
{"f_15265:regex_scm",(void*)f_15265},
{"f_15256:regex_scm",(void*)f_15256},
{"f_15257:regex_scm",(void*)f_15257},
{"f_15513:regex_scm",(void*)f_15513},
{"f_15514:regex_scm",(void*)f_15514},
{"f_15518:regex_scm",(void*)f_15518},
{"f_15521:regex_scm",(void*)f_15521},
{"f_15488:regex_scm",(void*)f_15488},
{"f_15489:regex_scm",(void*)f_15489},
{"f_15493:regex_scm",(void*)f_15493},
{"f_15432:regex_scm",(void*)f_15432},
{"f_15457:regex_scm",(void*)f_15457},
{"f_15461:regex_scm",(void*)f_15461},
{"f_15434:regex_scm",(void*)f_15434},
{"f_15438:regex_scm",(void*)f_15438},
{"f_15382:regex_scm",(void*)f_15382},
{"f_15407:regex_scm",(void*)f_15407},
{"f_15385:regex_scm",(void*)f_15385},
{"f_15386:regex_scm",(void*)f_15386},
{"f_15390:regex_scm",(void*)f_15390},
{"f_15289:regex_scm",(void*)f_15289},
{"f_15358:regex_scm",(void*)f_15358},
{"f_15292:regex_scm",(void*)f_15292},
{"f_15293:regex_scm",(void*)f_15293},
{"f_15299:regex_scm",(void*)f_15299},
{"f_15309:regex_scm",(void*)f_15309},
{"f_15312:regex_scm",(void*)f_15312},
{"f_10646:regex_scm",(void*)f_10646},
{"f_10649:regex_scm",(void*)f_10649},
{"f_10652:regex_scm",(void*)f_10652},
{"f_11280:regex_scm",(void*)f_11280},
{"f_12301:regex_scm",(void*)f_12301},
{"f_11283:regex_scm",(void*)f_11283},
{"f_11292:regex_scm",(void*)f_11292},
{"f_11337:regex_scm",(void*)f_11337},
{"f_11366:regex_scm",(void*)f_11366},
{"f_12096:regex_scm",(void*)f_12096},
{"f_12146:regex_scm",(void*)f_12146},
{"f_12123:regex_scm",(void*)f_12123},
{"f_12069:regex_scm",(void*)f_12069},
{"f_12039:regex_scm",(void*)f_12039},
{"f_11895:regex_scm",(void*)f_11895},
{"f_11898:regex_scm",(void*)f_11898},
{"f_11963:regex_scm",(void*)f_11963},
{"f_11916:regex_scm",(void*)f_11916},
{"f_11928:regex_scm",(void*)f_11928},
{"f_11875:regex_scm",(void*)f_11875},
{"f_11866:regex_scm",(void*)f_11866},
{"f_11753:regex_scm",(void*)f_11753},
{"f_11816:regex_scm",(void*)f_11816},
{"f_11762:regex_scm",(void*)f_11762},
{"f_11713:regex_scm",(void*)f_11713},
{"f_11542:regex_scm",(void*)f_11542},
{"f_11548:regex_scm",(void*)f_11548},
{"f_11551:regex_scm",(void*)f_11551},
{"f_11633:regex_scm",(void*)f_11633},
{"f_11560:regex_scm",(void*)f_11560},
{"f_11574:regex_scm",(void*)f_11574},
{"f_11586:regex_scm",(void*)f_11586},
{"f_11588:regex_scm",(void*)f_11588},
{"f_11617:regex_scm",(void*)f_11617},
{"f_11613:regex_scm",(void*)f_11613},
{"f_11600:regex_scm",(void*)f_11600},
{"f_11457:regex_scm",(void*)f_11457},
{"f_11490:regex_scm",(void*)f_11490},
{"f_11523:regex_scm",(void*)f_11523},
{"f_11506:regex_scm",(void*)f_11506},
{"f_11510:regex_scm",(void*)f_11510},
{"f_11375:regex_scm",(void*)f_11375},
{"f_11408:regex_scm",(void*)f_11408},
{"f_11438:regex_scm",(void*)f_11438},
{"f_11353:regex_scm",(void*)f_11353},
{"f_11295:regex_scm",(void*)f_11295},
{"f_11290:regex_scm",(void*)f_11290},
{"f_10674:regex_scm",(void*)f_10674},
{"f_10681:regex_scm",(void*)f_10681},
{"f_10658:regex_scm",(void*)f_10658},
{"f_17528:regex_scm",(void*)f_17528},
{"f_15569:regex_scm",(void*)f_15569},
{"f_15581:regex_scm",(void*)f_15581},
{"f_17516:regex_scm",(void*)f_17516},
{"f_17435:regex_scm",(void*)f_17435},
{"f_17468:regex_scm",(void*)f_17468},
{"f_17475:regex_scm",(void*)f_17475},
{"f_17436:regex_scm",(void*)f_17436},
{"f_17443:regex_scm",(void*)f_17443},
{"f_17339:regex_scm",(void*)f_17339},
{"f_17346:regex_scm",(void*)f_17346},
{"f_17281:regex_scm",(void*)f_17281},
{"f_17300:regex_scm",(void*)f_17300},
{"f_17288:regex_scm",(void*)f_17288},
{"f_17247:regex_scm",(void*)f_17247},
{"f_17257:regex_scm",(void*)f_17257},
{"f_17223:regex_scm",(void*)f_17223},
{"f_17165:regex_scm",(void*)f_17165},
{"f_17184:regex_scm",(void*)f_17184},
{"f_17172:regex_scm",(void*)f_17172},
{"f_17131:regex_scm",(void*)f_17131},
{"f_17141:regex_scm",(void*)f_17141},
{"f_17111:regex_scm",(void*)f_17111},
{"f_17069:regex_scm",(void*)f_17069},
{"f_17076:regex_scm",(void*)f_17076},
{"f_17041:regex_scm",(void*)f_17041},
{"f_15627:regex_scm",(void*)f_15627},
{"f_16993:regex_scm",(void*)f_16993},
{"f_16953:regex_scm",(void*)f_16953},
{"f_16965:regex_scm",(void*)f_16965},
{"f_16923:regex_scm",(void*)f_16923},
{"f_16924:regex_scm",(void*)f_16924},
{"f_16936:regex_scm",(void*)f_16936},
{"f_16796:regex_scm",(void*)f_16796},
{"f_16852:regex_scm",(void*)f_16852},
{"f_16800:regex_scm",(void*)f_16800},
{"f_16804:regex_scm",(void*)f_16804},
{"f_16838:regex_scm",(void*)f_16838},
{"f_16822:regex_scm",(void*)f_16822},
{"f_16654:regex_scm",(void*)f_16654},
{"f_16657:regex_scm",(void*)f_16657},
{"f_16764:regex_scm",(void*)f_16764},
{"f_16759:regex_scm",(void*)f_16759},
{"f_16755:regex_scm",(void*)f_16755},
{"f_16660:regex_scm",(void*)f_16660},
{"f_16669:regex_scm",(void*)f_16669},
{"f_16715:regex_scm",(void*)f_16715},
{"f_16716:regex_scm",(void*)f_16716},
{"f_16722:regex_scm",(void*)f_16722},
{"f_16672:regex_scm",(void*)f_16672},
{"f_16673:regex_scm",(void*)f_16673},
{"f_16640:regex_scm",(void*)f_16640},
{"f_16617:regex_scm",(void*)f_16617},
{"f_16618:regex_scm",(void*)f_16618},
{"f_16633:regex_scm",(void*)f_16633},
{"f_16622:regex_scm",(void*)f_16622},
{"f_16599:regex_scm",(void*)f_16599},
{"f_16568:regex_scm",(void*)f_16568},
{"f_16569:regex_scm",(void*)f_16569},
{"f_16590:regex_scm",(void*)f_16590},
{"f_16592:regex_scm",(void*)f_16592},
{"f_16586:regex_scm",(void*)f_16586},
{"f_16550:regex_scm",(void*)f_16550},
{"f_16519:regex_scm",(void*)f_16519},
{"f_16520:regex_scm",(void*)f_16520},
{"f_16541:regex_scm",(void*)f_16541},
{"f_16543:regex_scm",(void*)f_16543},
{"f_16537:regex_scm",(void*)f_16537},
{"f_16505:regex_scm",(void*)f_16505},
{"f_16482:regex_scm",(void*)f_16482},
{"f_16483:regex_scm",(void*)f_16483},
{"f_16498:regex_scm",(void*)f_16498},
{"f_16490:regex_scm",(void*)f_16490},
{"f_16468:regex_scm",(void*)f_16468},
{"f_16445:regex_scm",(void*)f_16445},
{"f_16446:regex_scm",(void*)f_16446},
{"f_16461:regex_scm",(void*)f_16461},
{"f_16453:regex_scm",(void*)f_16453},
{"f_16432:regex_scm",(void*)f_16432},
{"f_16407:regex_scm",(void*)f_16407},
{"f_16342:regex_scm",(void*)f_16342},
{"f_16155:regex_scm",(void*)f_16155},
{"f_16158:regex_scm",(void*)f_16158},
{"f_16181:regex_scm",(void*)f_16181},
{"f_16247:regex_scm",(void*)f_16247},
{"f_16231:regex_scm",(void*)f_16231},
{"f_16184:regex_scm",(void*)f_16184},
{"f_16216:regex_scm",(void*)f_16216},
{"f_16211:regex_scm",(void*)f_16211},
{"f_16205:regex_scm",(void*)f_16205},
{"f_16201:regex_scm",(void*)f_16201},
{"f_16159:regex_scm",(void*)f_16159},
{"f_16136:regex_scm",(void*)f_16136},
{"f_16103:regex_scm",(void*)f_16103},
{"f_16054:regex_scm",(void*)f_16054},
{"f_15991:regex_scm",(void*)f_15991},
{"f_16015:regex_scm",(void*)f_16015},
{"f_16021:regex_scm",(void*)f_16021},
{"f_15998:regex_scm",(void*)f_15998},
{"f_15999:regex_scm",(void*)f_15999},
{"f_16005:regex_scm",(void*)f_16005},
{"f_15933:regex_scm",(void*)f_15933},
{"f_15957:regex_scm",(void*)f_15957},
{"f_15963:regex_scm",(void*)f_15963},
{"f_15940:regex_scm",(void*)f_15940},
{"f_15941:regex_scm",(void*)f_15941},
{"f_15947:regex_scm",(void*)f_15947},
{"f_15902:regex_scm",(void*)f_15902},
{"f_15903:regex_scm",(void*)f_15903},
{"f_15909:regex_scm",(void*)f_15909},
{"f_15874:regex_scm",(void*)f_15874},
{"f_15875:regex_scm",(void*)f_15875},
{"f_15881:regex_scm",(void*)f_15881},
{"f_15853:regex_scm",(void*)f_15853},
{"f_15834:regex_scm",(void*)f_15834},
{"f_15796:regex_scm",(void*)f_15796},
{"f_15775:regex_scm",(void*)f_15775},
{"f_15754:regex_scm",(void*)f_15754},
{"f_15733:regex_scm",(void*)f_15733},
{"f_15674:regex_scm",(void*)f_15674},
{"f_15700:regex_scm",(void*)f_15700},
{"f_15677:regex_scm",(void*)f_15677},
{"f_15678:regex_scm",(void*)f_15678},
{"f_15684:regex_scm",(void*)f_15684},
{"f_15654:regex_scm",(void*)f_15654},
{"f_15638:regex_scm",(void*)f_15638},
{"f_15634:regex_scm",(void*)f_15634},
{"f_15615:regex_scm",(void*)f_15615},
{"f_15607:regex_scm",(void*)f_15607},
{"f_15584:regex_scm",(void*)f_15584},
{"f_15578:regex_scm",(void*)f_15578},
{"f_10667:regex_scm",(void*)f_10667},
{"f_10608:regex_scm",(void*)f_10608},
{"f_10616:regex_scm",(void*)f_10616},
{"f_10587:regex_scm",(void*)f_10587},
{"f_10594:regex_scm",(void*)f_10594},
{"f_10137:regex_scm",(void*)f_10137},
{"f_10143:regex_scm",(void*)f_10143},
{"f_10234:regex_scm",(void*)f_10234},
{"f_9296:regex_scm",(void*)f_9296},
{"f_9299:regex_scm",(void*)f_9299},
{"f_10000:regex_scm",(void*)f_10000},
{"f_9998:regex_scm",(void*)f_9998},
{"f_9978:regex_scm",(void*)f_9978},
{"f_9974:regex_scm",(void*)f_9974},
{"f_9892:regex_scm",(void*)f_9892},
{"f_9970:regex_scm",(void*)f_9970},
{"f_9966:regex_scm",(void*)f_9966},
{"f_9962:regex_scm",(void*)f_9962},
{"f_9958:regex_scm",(void*)f_9958},
{"f_9934:regex_scm",(void*)f_9934},
{"f_9910:regex_scm",(void*)f_9910},
{"f_9908:regex_scm",(void*)f_9908},
{"f_9800:regex_scm",(void*)f_9800},
{"f_9874:regex_scm",(void*)f_9874},
{"f_9822:regex_scm",(void*)f_9822},
{"f_9820:regex_scm",(void*)f_9820},
{"f_9792:regex_scm",(void*)f_9792},
{"f_9320:regex_scm",(void*)f_9320},
{"f_9325:regex_scm",(void*)f_9325},
{"f_9397:regex_scm",(void*)f_9397},
{"f_10075:regex_scm",(void*)f_10075},
{"f_10081:regex_scm",(void*)f_10081},
{"f_10079:regex_scm",(void*)f_10079},
{"f_9405:regex_scm",(void*)f_9405},
{"f_9382:regex_scm",(void*)f_9382},
{"f_9386:regex_scm",(void*)f_9386},
{"f_9353:regex_scm",(void*)f_9353},
{"f_10249:regex_scm",(void*)f_10249},
{"f_10161:regex_scm",(void*)f_10161},
{"f_10179:regex_scm",(void*)f_10179},
{"f_10165:regex_scm",(void*)f_10165},
{"f_10157:regex_scm",(void*)f_10157},
{"f_9653:regex_scm",(void*)f_9653},
{"f_9771:regex_scm",(void*)f_9771},
{"f_9763:regex_scm",(void*)f_9763},
{"f_9755:regex_scm",(void*)f_9755},
{"f_9723:regex_scm",(void*)f_9723},
{"f_9751:regex_scm",(void*)f_9751},
{"f_9719:regex_scm",(void*)f_9719},
{"f_9675:regex_scm",(void*)f_9675},
{"f_9673:regex_scm",(void*)f_9673},
{"f_9525:regex_scm",(void*)f_9525},
{"f_9643:regex_scm",(void*)f_9643},
{"f_9635:regex_scm",(void*)f_9635},
{"f_9627:regex_scm",(void*)f_9627},
{"f_9595:regex_scm",(void*)f_9595},
{"f_9623:regex_scm",(void*)f_9623},
{"f_9591:regex_scm",(void*)f_9591},
{"f_9547:regex_scm",(void*)f_9547},
{"f_9545:regex_scm",(void*)f_9545},
{"f_9439:regex_scm",(void*)f_9439},
{"f_9473:regex_scm",(void*)f_9473},
{"f_9481:regex_scm",(void*)f_9481},
{"f_9491:regex_scm",(void*)f_9491},
{"f_9489:regex_scm",(void*)f_9489},
{"f_9485:regex_scm",(void*)f_9485},
{"f_9469:regex_scm",(void*)f_9469},
{"f_9163:regex_scm",(void*)f_9163},
{"f_9287:regex_scm",(void*)f_9287},
{"f_9251:regex_scm",(void*)f_9251},
{"f_9283:regex_scm",(void*)f_9283},
{"f_9279:regex_scm",(void*)f_9279},
{"f_9255:regex_scm",(void*)f_9255},
{"f_9275:regex_scm",(void*)f_9275},
{"f_9271:regex_scm",(void*)f_9271},
{"f_9259:regex_scm",(void*)f_9259},
{"f_9267:regex_scm",(void*)f_9267},
{"f_9263:regex_scm",(void*)f_9263},
{"f_9238:regex_scm",(void*)f_9238},
{"f_9214:regex_scm",(void*)f_9214},
{"f_9234:regex_scm",(void*)f_9234},
{"f_9230:regex_scm",(void*)f_9230},
{"f_9218:regex_scm",(void*)f_9218},
{"f_9226:regex_scm",(void*)f_9226},
{"f_9222:regex_scm",(void*)f_9222},
{"f_9201:regex_scm",(void*)f_9201},
{"f_9189:regex_scm",(void*)f_9189},
{"f_9197:regex_scm",(void*)f_9197},
{"f_9193:regex_scm",(void*)f_9193},
{"f_9103:regex_scm",(void*)f_9103},
{"f_8878:regex_scm",(void*)f_8878},
{"f_9053:regex_scm",(void*)f_9053},
{"f_9005:regex_scm",(void*)f_9005},
{"f_9041:regex_scm",(void*)f_9041},
{"f_9009:regex_scm",(void*)f_9009},
{"f_9029:regex_scm",(void*)f_9029},
{"f_9013:regex_scm",(void*)f_9013},
{"f_9017:regex_scm",(void*)f_9017},
{"f_9001:regex_scm",(void*)f_9001},
{"f_8984:regex_scm",(void*)f_8984},
{"f_8952:regex_scm",(void*)f_8952},
{"f_8972:regex_scm",(void*)f_8972},
{"f_8956:regex_scm",(void*)f_8956},
{"f_8960:regex_scm",(void*)f_8960},
{"f_8948:regex_scm",(void*)f_8948},
{"f_8931:regex_scm",(void*)f_8931},
{"f_8915:regex_scm",(void*)f_8915},
{"f_8919:regex_scm",(void*)f_8919},
{"f_8881:regex_scm",(void*)f_8881},
{"f_8858:regex_scm",(void*)f_8858},
{"f_8066:regex_scm",(void*)f_8066},
{"f_8133:regex_scm",(void*)f_8133},
{"f_8136:regex_scm",(void*)f_8136},
{"f_4216:regex_scm",(void*)f_4216},
{"f_8085:regex_scm",(void*)f_8085},
{"f_8097:regex_scm",(void*)f_8097},
{"f_8100:regex_scm",(void*)f_8100},
{"f_5115:regex_scm",(void*)f_5115},
{"f_5122:regex_scm",(void*)f_5122},
{"f_5127:regex_scm",(void*)f_5127},
{"f_7973:regex_scm",(void*)f_7973},
{"f_7976:regex_scm",(void*)f_7976},
{"f_7994:regex_scm",(void*)f_7994},
{"f_7939:regex_scm",(void*)f_7939},
{"f_7954:regex_scm",(void*)f_7954},
{"f_7927:regex_scm",(void*)f_7927},
{"f_7924:regex_scm",(void*)f_7924},
{"f_7896:regex_scm",(void*)f_7896},
{"f_7893:regex_scm",(void*)f_7893},
{"f_7865:regex_scm",(void*)f_7865},
{"f_7832:regex_scm",(void*)f_7832},
{"f_7814:regex_scm",(void*)f_7814},
{"f_4274:regex_scm",(void*)f_4274},
{"f_7722:regex_scm",(void*)f_7722},
{"f_7765:regex_scm",(void*)f_7765},
{"f_7758:regex_scm",(void*)f_7758},
{"f_7754:regex_scm",(void*)f_7754},
{"f_7746:regex_scm",(void*)f_7746},
{"f_7742:regex_scm",(void*)f_7742},
{"f_7608:regex_scm",(void*)f_7608},
{"f_7617:regex_scm",(void*)f_7617},
{"f_7679:regex_scm",(void*)f_7679},
{"f_7524:regex_scm",(void*)f_7524},
{"f_7527:regex_scm",(void*)f_7527},
{"f_7530:regex_scm",(void*)f_7530},
{"f_7580:regex_scm",(void*)f_7580},
{"f_7577:regex_scm",(void*)f_7577},
{"f_7569:regex_scm",(void*)f_7569},
{"f_7565:regex_scm",(void*)f_7565},
{"f_7499:regex_scm",(void*)f_7499},
{"f_7471:regex_scm",(void*)f_7471},
{"f_7495:regex_scm",(void*)f_7495},
{"f_7491:regex_scm",(void*)f_7491},
{"f_7460:regex_scm",(void*)f_7460},
{"f_7456:regex_scm",(void*)f_7456},
{"f_7431:regex_scm",(void*)f_7431},
{"f_7427:regex_scm",(void*)f_7427},
{"f_7402:regex_scm",(void*)f_7402},
{"f_7398:regex_scm",(void*)f_7398},
{"f_7373:regex_scm",(void*)f_7373},
{"f_7369:regex_scm",(void*)f_7369},
{"f_7344:regex_scm",(void*)f_7344},
{"f_7340:regex_scm",(void*)f_7340},
{"f_7311:regex_scm",(void*)f_7311},
{"f_7307:regex_scm",(void*)f_7307},
{"f_7274:regex_scm",(void*)f_7274},
{"f_7270:regex_scm",(void*)f_7270},
{"f_7245:regex_scm",(void*)f_7245},
{"f_7241:regex_scm",(void*)f_7241},
{"f_7208:regex_scm",(void*)f_7208},
{"f_7204:regex_scm",(void*)f_7204},
{"f_7155:regex_scm",(void*)f_7155},
{"f_7151:regex_scm",(void*)f_7151},
{"f_7110:regex_scm",(void*)f_7110},
{"f_7106:regex_scm",(void*)f_7106},
{"f_7073:regex_scm",(void*)f_7073},
{"f_7069:regex_scm",(void*)f_7069},
{"f_7040:regex_scm",(void*)f_7040},
{"f_7036:regex_scm",(void*)f_7036},
{"f_7007:regex_scm",(void*)f_7007},
{"f_7003:regex_scm",(void*)f_7003},
{"f_6974:regex_scm",(void*)f_6974},
{"f_6970:regex_scm",(void*)f_6970},
{"f_6904:regex_scm",(void*)f_6904},
{"f_6723:regex_scm",(void*)f_6723},
{"f_6733:regex_scm",(void*)f_6733},
{"f_6742:regex_scm",(void*)f_6742},
{"f_6886:regex_scm",(void*)f_6886},
{"f_4315:regex_scm",(void*)f_4315},
{"f_4360:regex_scm",(void*)f_4360},
{"f_4339:regex_scm",(void*)f_4339},
{"f_4318:regex_scm",(void*)f_4318},
{"f_4326:regex_scm",(void*)f_4326},
{"f_6745:regex_scm",(void*)f_6745},
{"f_6748:regex_scm",(void*)f_6748},
{"f_6754:regex_scm",(void*)f_6754},
{"f_6852:regex_scm",(void*)f_6852},
{"f_6817:regex_scm",(void*)f_6817},
{"f_6783:regex_scm",(void*)f_6783},
{"f_8177:regex_scm",(void*)f_8177},
{"f_8849:regex_scm",(void*)f_8849},
{"f_8179:regex_scm",(void*)f_8179},
{"f_8796:regex_scm",(void*)f_8796},
{"f_8814:regex_scm",(void*)f_8814},
{"f_8666:regex_scm",(void*)f_8666},
{"f_8723:regex_scm",(void*)f_8723},
{"f_8711:regex_scm",(void*)f_8711},
{"f_8696:regex_scm",(void*)f_8696},
{"f_8669:regex_scm",(void*)f_8669},
{"f_8692:regex_scm",(void*)f_8692},
{"f_8680:regex_scm",(void*)f_8680},
{"f_8688:regex_scm",(void*)f_8688},
{"f_8684:regex_scm",(void*)f_8684},
{"f_8533:regex_scm",(void*)f_8533},
{"f_8542:regex_scm",(void*)f_8542},
{"f_8585:regex_scm",(void*)f_8585},
{"f_8581:regex_scm",(void*)f_8581},
{"f_8548:regex_scm",(void*)f_8548},
{"f_8551:regex_scm",(void*)f_8551},
{"f_8574:regex_scm",(void*)f_8574},
{"f_8562:regex_scm",(void*)f_8562},
{"f_8570:regex_scm",(void*)f_8570},
{"f_8566:regex_scm",(void*)f_8566},
{"f_8481:regex_scm",(void*)f_8481},
{"f_8329:regex_scm",(void*)f_8329},
{"f_8409:regex_scm",(void*)f_8409},
{"f_8422:regex_scm",(void*)f_8422},
{"f_8432:regex_scm",(void*)f_8432},
{"f_8436:regex_scm",(void*)f_8436},
{"f_8392:regex_scm",(void*)f_8392},
{"f_8360:regex_scm",(void*)f_8360},
{"f_8218:regex_scm",(void*)f_8218},
{"f_8221:regex_scm",(void*)f_8221},
{"f_4820:regex_scm",(void*)f_4820},
{"f_4841:regex_scm",(void*)f_4841},
{"f_8224:regex_scm",(void*)f_8224},
{"f_8297:regex_scm",(void*)f_8297},
{"f_8301:regex_scm",(void*)f_8301},
{"f_8293:regex_scm",(void*)f_8293},
{"f_8289:regex_scm",(void*)f_8289},
{"f_8244:regex_scm",(void*)f_8244},
{"f_8272:regex_scm",(void*)f_8272},
{"f_8254:regex_scm",(void*)f_8254},
{"f_17628:regex_scm",(void*)f_17628},
{"f_8265:regex_scm",(void*)f_8265},
{"f_8248:regex_scm",(void*)f_8248},
{"f_8231:regex_scm",(void*)f_8231},
{"f_6704:regex_scm",(void*)f_6704},
{"f_6680:regex_scm",(void*)f_6680},
{"f_6700:regex_scm",(void*)f_6700},
{"f_6665:regex_scm",(void*)f_6665},
{"f_5930:regex_scm",(void*)f_5930},
{"f_5934:regex_scm",(void*)f_5934},
{"f_6399:regex_scm",(void*)f_6399},
{"f_6584:regex_scm",(void*)f_6584},
{"f_6596:regex_scm",(void*)f_6596},
{"f_6563:regex_scm",(void*)f_6563},
{"f_6559:regex_scm",(void*)f_6559},
{"f_6514:regex_scm",(void*)f_6514},
{"f_6494:regex_scm",(void*)f_6494},
{"f_6477:regex_scm",(void*)f_6477},
{"f_6460:regex_scm",(void*)f_6460},
{"f_6411:regex_scm",(void*)f_6411},
{"f_6415:regex_scm",(void*)f_6415},
{"f_6418:regex_scm",(void*)f_6418},
{"f_6402:regex_scm",(void*)f_6402},
{"f_6357:regex_scm",(void*)f_6357},
{"f_6361:regex_scm",(void*)f_6361},
{"f_6300:regex_scm",(void*)f_6300},
{"f_6334:regex_scm",(void*)f_6334},
{"f_6303:regex_scm",(void*)f_6303},
{"f_6318:regex_scm",(void*)f_6318},
{"f_6326:regex_scm",(void*)f_6326},
{"f_6240:regex_scm",(void*)f_6240},
{"f_6283:regex_scm",(void*)f_6283},
{"f_6243:regex_scm",(void*)f_6243},
{"f_6267:regex_scm",(void*)f_6267},
{"f_6275:regex_scm",(void*)f_6275},
{"f_6212:regex_scm",(void*)f_6212},
{"f_6216:regex_scm",(void*)f_6216},
{"f_6120:regex_scm",(void*)f_6120},
{"f_6138:regex_scm",(void*)f_6138},
{"f_6158:regex_scm",(void*)f_6158},
{"f_6150:regex_scm",(void*)f_6150},
{"f_6146:regex_scm",(void*)f_6146},
{"f_6113:regex_scm",(void*)f_6113},
{"f_6117:regex_scm",(void*)f_6117},
{"f_6088:regex_scm",(void*)f_6088},
{"f_6092:regex_scm",(void*)f_6092},
{"f_6045:regex_scm",(void*)f_6045},
{"f_6049:regex_scm",(void*)f_6049},
{"f_6020:regex_scm",(void*)f_6020},
{"f_6024:regex_scm",(void*)f_6024},
{"f_5995:regex_scm",(void*)f_5995},
{"f_5999:regex_scm",(void*)f_5999},
{"f_5955:regex_scm",(void*)f_5955},
{"f_5970:regex_scm",(void*)f_5970},
{"f_5843:regex_scm",(void*)f_5843},
{"f_5849:regex_scm",(void*)f_5849},
{"f_5864:regex_scm",(void*)f_5864},
{"f_5646:regex_scm",(void*)f_5646},
{"f_5813:regex_scm",(void*)f_5813},
{"f_5784:regex_scm",(void*)f_5784},
{"f_5759:regex_scm",(void*)f_5759},
{"f_5742:regex_scm",(void*)f_5742},
{"f_5725:regex_scm",(void*)f_5725},
{"f_5700:regex_scm",(void*)f_5700},
{"f_5677:regex_scm",(void*)f_5677},
{"f_5637:regex_scm",(void*)f_5637},
{"f_5634:regex_scm",(void*)f_5634},
{"f_5572:regex_scm",(void*)f_5572},
{"f_5584:regex_scm",(void*)f_5584},
{"f_5272:regex_scm",(void*)f_5272},
{"f_5276:regex_scm",(void*)f_5276},
{"f_5570:regex_scm",(void*)f_5570},
{"f_5279:regex_scm",(void*)f_5279},
{"f_5532:regex_scm",(void*)f_5532},
{"f_5543:regex_scm",(void*)f_5543},
{"f_5282:regex_scm",(void*)f_5282},
{"f_5525:regex_scm",(void*)f_5525},
{"f_5514:regex_scm",(void*)f_5514},
{"f_5285:regex_scm",(void*)f_5285},
{"f_5290:regex_scm",(void*)f_5290},
{"f_5454:regex_scm",(void*)f_5454},
{"f_5392:regex_scm",(void*)f_5392},
{"f_5359:regex_scm",(void*)f_5359},
{"f_5293:regex_scm",(void*)f_5293},
{"f_5200:regex_scm",(void*)f_5200},
{"f_5204:regex_scm",(void*)f_5204},
{"f_9068:regex_scm",(void*)f_9068},
{"f_5207:regex_scm",(void*)f_5207},
{"f_5244:regex_scm",(void*)f_5244},
{"f_5216:regex_scm",(void*)f_5216},
{"f_5240:regex_scm",(void*)f_5240},
{"f_5236:regex_scm",(void*)f_5236},
{"f_5180:regex_scm",(void*)f_5180},
{"f_5198:regex_scm",(void*)f_5198},
{"f_5194:regex_scm",(void*)f_5194},
{"f_5160:regex_scm",(void*)f_5160},
{"f_5167:regex_scm",(void*)f_5167},
{"f_5178:regex_scm",(void*)f_5178},
{"f_5174:regex_scm",(void*)f_5174},
{"f_5130:regex_scm",(void*)f_5130},
{"f_5155:regex_scm",(void*)f_5155},
{"f_5015:regex_scm",(void*)f_5015},
{"f_5021:regex_scm",(void*)f_5021},
{"f_5052:regex_scm",(void*)f_5052},
{"f_5046:regex_scm",(void*)f_5046},
{"f_5039:regex_scm",(void*)f_5039},
{"f_4996:regex_scm",(void*)f_4996},
{"f_4987:regex_scm",(void*)f_4987},
{"f_4977:regex_scm",(void*)f_4977},
{"f_4985:regex_scm",(void*)f_4985},
{"f_4930:regex_scm",(void*)f_4930},
{"f_4962:regex_scm",(void*)f_4962},
{"f_4966:regex_scm",(void*)f_4966},
{"f_4958:regex_scm",(void*)f_4958},
{"f_4883:regex_scm",(void*)f_4883},
{"f_4915:regex_scm",(void*)f_4915},
{"f_4919:regex_scm",(void*)f_4919},
{"f_4911:regex_scm",(void*)f_4911},
{"f_4867:regex_scm",(void*)f_4867},
{"f_4875:regex_scm",(void*)f_4875},
{"f_4857:regex_scm",(void*)f_4857},
{"f_4865:regex_scm",(void*)f_4865},
{"f_4771:regex_scm",(void*)f_4771},
{"f_4777:regex_scm",(void*)f_4777},
{"f_4801:regex_scm",(void*)f_4801},
{"f_4798:regex_scm",(void*)f_4798},
{"f_4741:regex_scm",(void*)f_4741},
{"f_4747:regex_scm",(void*)f_4747},
{"f_4765:regex_scm",(void*)f_4765},
{"f_4692:regex_scm",(void*)f_4692},
{"f_4712:regex_scm",(void*)f_4712},
{"f_4728:regex_scm",(void*)f_4728},
{"f_4643:regex_scm",(void*)f_4643},
{"f_4663:regex_scm",(void*)f_4663},
{"f_4676:regex_scm",(void*)f_4676},
{"f_4601:regex_scm",(void*)f_4601},
{"f_4616:regex_scm",(void*)f_4616},
{"f_4569:regex_scm",(void*)f_4569},
{"f_4575:regex_scm",(void*)f_4575},
{"f_4588:regex_scm",(void*)f_4588},
{"f_4557:regex_scm",(void*)f_4557},
{"f_4561:regex_scm",(void*)f_4561},
{"f_4514:regex_scm",(void*)f_4514},
{"f_4520:regex_scm",(void*)f_4520},
{"f_4527:regex_scm",(void*)f_4527},
{"f_4475:regex_scm",(void*)f_4475},
{"f_4491:regex_scm",(void*)f_4491},
{"f_4418:regex_scm",(void*)f_4418},
{"f_4428:regex_scm",(void*)f_4428},
{"f_4426:regex_scm",(void*)f_4426},
{"f_4442:regex_scm",(void*)f_4442},
{"f_4447:regex_scm",(void*)f_4447},
{"f_4391:regex_scm",(void*)f_4391},
{"f_4466:regex_scm",(void*)f_4466},
{"f_4445:regex_scm",(void*)f_4445},
{"f_4158:regex_scm",(void*)f_4158},
{"f_4171:regex_scm",(void*)f_4171},
{"f_4143:regex_scm",(void*)f_4143},
{"f_4151:regex_scm",(void*)f_4151},
{"f_4120:regex_scm",(void*)f_4120},
{"f_4124:regex_scm",(void*)f_4124},
{"f_4077:regex_scm",(void*)f_4077},
{"f_4081:regex_scm",(void*)f_4081},
{"f_4094:regex_scm",(void*)f_4094},
{"f_4045:regex_scm",(void*)f_4045},
{"f_3999:regex_scm",(void*)f_3999},
{"f_3925:regex_scm",(void*)f_3925},
{"f_3907:regex_scm",(void*)f_3907},
{"f_3915:regex_scm",(void*)f_3915},
{"f_3854:regex_scm",(void*)f_3854},
{"f_3820:regex_scm",(void*)f_3820},
{"f_3830:regex_scm",(void*)f_3830},
{"f_3806:regex_scm",(void*)f_3806},
{"f_3814:regex_scm",(void*)f_3814},
{"f_3818:regex_scm",(void*)f_3818},
{"f_3884:regex_scm",(void*)f_3884},
{"f_3800:regex_scm",(void*)f_3800},
{"f_3794:regex_scm",(void*)f_3794},
{"f_3788:regex_scm",(void*)f_3788},
{"f_3782:regex_scm",(void*)f_3782},
{"f_3776:regex_scm",(void*)f_3776},
{"f_3770:regex_scm",(void*)f_3770},
{"f_3764:regex_scm",(void*)f_3764},
{"f_3758:regex_scm",(void*)f_3758},
{"f_3732:regex_scm",(void*)f_3732},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
