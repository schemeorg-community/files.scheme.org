/* Generated from optimizer.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-12-14 09:04
   Version 4.2.0 - SVN rev. 16023
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-12-14 on galinha (Linux)
   command line: optimizer.scm -optimize-level 2 -include-path . -include-path ./ -inline -no-lambda-info -local -no-trace -extend private-namespace.scm -no-trace -output-file optimizer.c
   unit: optimizer
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[265];
static double C_possibly_force_alignment;


C_noret_decl(C_optimizer_toplevel)
C_externexport void C_ccall C_optimizer_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2708)
static void C_ccall f_2708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2711)
static void C_ccall f_2711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2714)
static void C_ccall f_2714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2717)
static void C_ccall f_2717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2720)
static void C_ccall f_2720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2723)
static void C_ccall f_2723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2992)
static void C_ccall f_2992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11686)
static void C_ccall f_11686(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_11694)
static void C_ccall f_11694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11699)
static void C_fcall f_11699(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11744)
static void C_ccall f_11744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11748)
static void C_ccall f_11748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11709)
static void C_ccall f_11709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11733)
static void C_ccall f_11733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11718)
static void C_fcall f_11718(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4854)
static void C_ccall f_4854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10683)
static void C_ccall f_10683(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_10717)
static void C_ccall f_10717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10819)
static void C_ccall f_10819(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10829)
static void C_fcall f_10829(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11103)
static void C_ccall f_11103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11095)
static void C_ccall f_11095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10905)
static void C_ccall f_10905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10934)
static void C_fcall f_10934(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11071)
static void C_ccall f_11071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11063)
static void C_ccall f_11063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10950)
static void C_fcall f_10950(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10997)
static void C_ccall f_10997(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10987)
static void C_ccall f_10987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10995)
static void C_ccall f_10995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11157)
static void C_ccall f_11157(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10) C_noret;
C_noret_decl(f_11170)
static void C_ccall f_11170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11205)
static void C_ccall f_11205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11189)
static void C_ccall f_11189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11193)
static void C_ccall f_11193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11182)
static void C_ccall f_11182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11371)
static void C_ccall f_11371(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13) C_noret;
C_noret_decl(f_11384)
static void C_ccall f_11384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11390)
static void C_ccall f_11390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11436)
static void C_ccall f_11436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11428)
static void C_ccall f_11428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11412)
static void C_ccall f_11412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11416)
static void C_ccall f_11416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11420)
static void C_ccall f_11420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4857)
static void C_ccall f_4857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10361)
static void C_ccall f_10361(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_10383)
static void C_ccall f_10383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10438)
static void C_ccall f_10438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10408)
static void C_ccall f_10408(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10430)
static void C_ccall f_10430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10434)
static void C_ccall f_10434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10426)
static void C_ccall f_10426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10406)
static void C_ccall f_10406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10532)
static void C_ccall f_10532(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9) C_noret;
C_noret_decl(f_10546)
static void C_ccall f_10546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4860)
static void C_ccall f_4860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5220)
static void C_ccall f_5220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8306)
static void C_ccall f_8306(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10240)
static void C_ccall f_10240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10243)
static void C_ccall f_10243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10246)
static void C_ccall f_10246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10249)
static void C_ccall f_10249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10252)
static void C_ccall f_10252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10255)
static void C_ccall f_10255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10332)
static void C_ccall f_10332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10258)
static void C_ccall f_10258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10261)
static void C_ccall f_10261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10264)
static void C_ccall f_10264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10326)
static void C_ccall f_10326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10267)
static void C_ccall f_10267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10270)
static void C_ccall f_10270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10323)
static void C_ccall f_10323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8979)
static void C_fcall f_8979(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8997)
static void C_ccall f_8997(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9003)
static void C_ccall f_9003(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8983)
static void C_ccall f_8983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10273)
static void C_ccall f_10273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10315)
static void C_ccall f_10315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10313)
static void C_ccall f_10313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10276)
static void C_ccall f_10276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10279)
static void C_ccall f_10279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10282)
static void C_ccall f_10282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10306)
static void C_ccall f_10306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10285)
static void C_ccall f_10285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10288)
static void C_ccall f_10288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10291)
static void C_ccall f_10291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10294)
static void C_ccall f_10294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10297)
static void C_ccall f_10297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10300)
static void C_ccall f_10300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10024)
static void C_fcall f_10024(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10030)
static void C_fcall f_10030(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10216)
static void C_fcall f_10216(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10226)
static void C_ccall f_10226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10190)
static void C_fcall f_10190(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10200)
static void C_ccall f_10200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10165)
static void C_ccall f_10165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10174)
static void C_ccall f_10174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10177)
static void C_ccall f_10177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10135)
static void C_fcall f_10135(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10145)
static void C_ccall f_10145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10049)
static void C_ccall f_10049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10054)
static void C_fcall f_10054(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10095)
static void C_fcall f_10095(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10092)
static void C_ccall f_10092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10077)
static void C_ccall f_10077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10088)
static void C_ccall f_10088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10084)
static void C_ccall f_10084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9891)
static void C_fcall f_9891(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9897)
static void C_fcall f_9897(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10001)
static void C_fcall f_10001(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10011)
static void C_ccall f_10011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9976)
static void C_ccall f_9976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9972)
static void C_ccall f_9972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9919)
static void C_ccall f_9919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9928)
static void C_fcall f_9928(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9938)
static void C_ccall f_9938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9573)
static void C_fcall f_9573(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9587)
static void C_ccall f_9587(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9594)
static void C_ccall f_9594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9597)
static void C_ccall f_9597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9606)
static void C_ccall f_9606(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9613)
static void C_ccall f_9613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9616)
static void C_ccall f_9616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9712)
static void C_fcall f_9712(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9868)
static void C_fcall f_9868(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9878)
static void C_ccall f_9878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9844)
static void C_ccall f_9844(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9863)
static void C_ccall f_9863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9859)
static void C_ccall f_9859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9825)
static void C_ccall f_9825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9791)
static void C_ccall f_9791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9796)
static void C_fcall f_9796(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9806)
static void C_ccall f_9806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9778)
static void C_ccall f_9778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9761)
static void C_ccall f_9761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9731)
static void C_ccall f_9731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9736)
static void C_fcall f_9736(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9746)
static void C_ccall f_9746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9697)
static void C_ccall f_9697(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9619)
static void C_ccall f_9619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9668)
static void C_ccall f_9668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9656)
static void C_ccall f_9656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9652)
static void C_ccall f_9652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9585)
static void C_ccall f_9585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9287)
static void C_fcall f_9287(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9559)
static void C_ccall f_9559(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9398)
static void C_ccall f_9398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9536)
static void C_fcall f_9536(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9546)
static void C_ccall f_9546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9491)
static void C_ccall f_9491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9496)
static void C_ccall f_9496(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9534)
static void C_ccall f_9534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9296)
static void C_fcall f_9296(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9374)
static void C_fcall f_9374(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9384)
static void C_ccall f_9384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9357)
static void C_ccall f_9357(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9362)
static void C_ccall f_9362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9316)
static void C_ccall f_9316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9321)
static void C_fcall f_9321(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9331)
static void C_ccall f_9331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9294)
static void C_ccall f_9294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9526)
static void C_ccall f_9526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9512)
static void C_ccall f_9512(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9510)
static void C_ccall f_9510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9400)
static void C_fcall f_9400(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9484)
static void C_ccall f_9484(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9482)
static void C_ccall f_9482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9454)
static void C_fcall f_9454(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9467)
static void C_ccall f_9467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9420)
static void C_ccall f_9420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9444)
static void C_ccall f_9444(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9442)
static void C_ccall f_9442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9438)
static void C_ccall f_9438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9430)
static void C_ccall f_9430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9013)
static void C_fcall f_9013(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9019)
static void C_fcall f_9019(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9038)
static void C_fcall f_9038(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9244)
static void C_fcall f_9244(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9257)
static void C_ccall f_9257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9151)
static void C_ccall f_9151(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9167)
static void C_fcall f_9167(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9220)
static void C_ccall f_9220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9224)
static void C_ccall f_9224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9187)
static void C_ccall f_9187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9196)
static void C_fcall f_9196(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9206)
static void C_ccall f_9206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9124)
static void C_ccall f_9124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9129)
static void C_fcall f_9129(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9142)
static void C_ccall f_9142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9100)
static void C_ccall f_9100(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9112)
static void C_ccall f_9112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9049)
static void C_fcall f_9049(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9070)
static void C_ccall f_9070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9067)
static void C_ccall f_9067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9017)
static void C_ccall f_9017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8753)
static void C_fcall f_8753(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8759)
static void C_fcall f_8759(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8778)
static void C_fcall f_8778(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8880)
static void C_fcall f_8880(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8893)
static void C_ccall f_8893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8871)
static void C_ccall f_8871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8837)
static void C_fcall f_8837(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8846)
static void C_ccall f_8846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8858)
static void C_ccall f_8858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8789)
static void C_fcall f_8789(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8810)
static void C_ccall f_8810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8807)
static void C_ccall f_8807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8757)
static void C_ccall f_8757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8654)
static void C_fcall f_8654(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8660)
static void C_ccall f_8660(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8704)
static void C_ccall f_8704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8709)
static void C_fcall f_8709(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8716)
static void C_ccall f_8716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8743)
static void C_ccall f_8743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8739)
static void C_ccall f_8739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8731)
static void C_ccall f_8731(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8729)
static void C_ccall f_8729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8694)
static void C_ccall f_8694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8672)
static void C_ccall f_8672(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8679)
static void C_ccall f_8679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8409)
static void C_fcall f_8409(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8595)
static void C_fcall f_8595(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8636)
static void C_ccall f_8636(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8619)
static void C_ccall f_8619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8623)
static void C_ccall f_8623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8593)
static void C_ccall f_8593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8412)
static void C_fcall f_8412(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8567)
static void C_fcall f_8567(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8580)
static void C_ccall f_8580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8550)
static void C_ccall f_8550(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8562)
static void C_ccall f_8562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8496)
static void C_fcall f_8496(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8520)
static void C_ccall f_8520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8514)
static void C_ccall f_8514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8478)
static void C_ccall f_8478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8437)
static void C_fcall f_8437(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8440)
static void C_fcall f_8440(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8445)
static void C_fcall f_8445(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8458)
static void C_ccall f_8458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8309)
static void C_fcall f_8309(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8315)
static void C_ccall f_8315(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8346)
static void C_fcall f_8346(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8350)
static void C_ccall f_8350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8354)
static void C_ccall f_8354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8313)
static void C_ccall f_8313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7114)
static void C_ccall f_7114(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8301)
static void C_ccall f_8301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8304)
static void C_ccall f_8304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7117)
static void C_fcall f_7117(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7273)
static void C_fcall f_7273(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7286)
static void C_ccall f_7286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7253)
static void C_ccall f_7253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7227)
static void C_ccall f_7227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7173)
static void C_ccall f_7173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7179)
static void C_ccall f_7179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7185)
static void C_ccall f_7185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7142)
static void C_ccall f_7142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7295)
static void C_fcall f_7295(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_7705)
static void C_ccall f_7705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7712)
static void C_ccall f_7712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7298)
static void C_fcall f_7298(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7692)
static void C_ccall f_7692(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7668)
static void C_ccall f_7668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7679)
static void C_ccall f_7679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7635)
static void C_ccall f_7635(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7574)
static void C_fcall f_7574(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7546)
static void C_fcall f_7546(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7551)
static void C_ccall f_7551(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7493)
static void C_ccall f_7493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7499)
static void C_fcall f_7499(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7504)
static void C_ccall f_7504(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7452)
static void C_ccall f_7452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7458)
static void C_fcall f_7458(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7463)
static void C_ccall f_7463(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7436)
static void C_ccall f_7436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7432)
static void C_ccall f_7432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7402)
static void C_ccall f_7402(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7365)
static void C_ccall f_7365(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7381)
static void C_ccall f_7381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7347)
static void C_ccall f_7347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7714)
static void C_fcall f_7714(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_8291)
static void C_ccall f_8291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8289)
static void C_ccall f_8289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7718)
static void C_ccall f_7718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7728)
static void C_ccall f_7728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7737)
static void C_fcall f_7737(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7743)
static void C_ccall f_7743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7746)
static void C_ccall f_7746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7752)
static void C_ccall f_7752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7960)
static void C_fcall f_7960(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8223)
static void C_fcall f_8223(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8233)
static void C_ccall f_8233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8197)
static void C_fcall f_8197(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8207)
static void C_ccall f_8207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8182)
static void C_ccall f_8182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8185)
static void C_ccall f_8185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8135)
static void C_ccall f_8135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8138)
static void C_ccall f_8138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8004)
static void C_ccall f_8004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8059)
static void C_ccall f_8059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8062)
static void C_ccall f_8062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8089)
static void C_ccall f_8089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8065)
static void C_ccall f_8065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8068)
static void C_ccall f_8068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8013)
static void C_ccall f_8013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8016)
static void C_ccall f_8016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8019)
static void C_ccall f_8019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7755)
static void C_ccall f_7755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7942)
static void C_ccall f_7942(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7869)
static void C_ccall f_7869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7871)
static void C_fcall f_7871(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7890)
static void C_ccall f_7890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7893)
static void C_ccall f_7893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7758)
static void C_ccall f_7758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7770)
static void C_ccall f_7770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7825)
static void C_ccall f_7825(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7773)
static void C_ccall f_7773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7776)
static void C_ccall f_7776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7781)
static void C_fcall f_7781(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7823)
static void C_ccall f_7823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7797)
static void C_ccall f_7797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5242)
static void C_ccall f_5242(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_6988)
static void C_ccall f_6988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7010)
static void C_ccall f_7010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7022)
static void C_ccall f_7022(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7036)
static void C_fcall f_7036(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7085)
static void C_ccall f_7085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5267)
static void C_fcall f_5267(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7056)
static void C_ccall f_7056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7060)
static void C_ccall f_7060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7030)
static void C_ccall f_7030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7016)
static void C_ccall f_7016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7014)
static void C_ccall f_7014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7003)
static void C_ccall f_7003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6931)
static void C_ccall f_6931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6963)
static void C_ccall f_6963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6950)
static void C_fcall f_6950(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6783)
static void C_ccall f_6783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6789)
static void C_ccall f_6789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6873)
static void C_ccall f_6873(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6798)
static void C_ccall f_6798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6842)
static void C_ccall f_6842(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6840)
static void C_ccall f_6840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6814)
static void C_ccall f_6814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6716)
static void C_ccall f_6716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6744)
static void C_ccall f_6744(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6756)
static void C_ccall f_6756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6734)
static void C_ccall f_6734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6729)
static void C_ccall f_6729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6574)
static void C_ccall f_6574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6655)
static void C_ccall f_6655(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6583)
static void C_ccall f_6583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6636)
static void C_ccall f_6636(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6634)
static void C_ccall f_6634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6599)
static void C_ccall f_6599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6545)
static void C_ccall f_6545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6555)
static void C_ccall f_6555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6483)
static void C_ccall f_6483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6503)
static void C_fcall f_6503(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6410)
static void C_ccall f_6410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6440)
static void C_fcall f_6440(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6323)
static void C_ccall f_6323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6342)
static void C_ccall f_6342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6335)
static void C_ccall f_6335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6246)
static void C_ccall f_6246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6187)
static void C_ccall f_6187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6202)
static void C_fcall f_6202(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6205)
static void C_ccall f_6205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6117)
static void C_ccall f_6117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6160)
static void C_ccall f_6160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6153)
static void C_ccall f_6153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6058)
static void C_ccall f_6058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6070)
static void C_fcall f_6070(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6083)
static void C_ccall f_6083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6076)
static void C_ccall f_6076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5971)
static void C_ccall f_5971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5993)
static void C_ccall f_5993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6001)
static void C_ccall f_6001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6005)
static void C_ccall f_6005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5827)
static void C_ccall f_5827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5849)
static void C_fcall f_5849(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5852)
static void C_fcall f_5852(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5911)
static void C_ccall f_5911(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5855)
static void C_ccall f_5855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5858)
static void C_ccall f_5858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5889)
static void C_ccall f_5889(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5887)
static void C_ccall f_5887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5863)
static void C_ccall f_5863(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5843)
static void C_ccall f_5843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5806)
static void C_ccall f_5806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5751)
static void C_ccall f_5751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5775)
static void C_ccall f_5775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5764)
static void C_ccall f_5764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5686)
static void C_ccall f_5686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5599)
static void C_ccall f_5599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5641)
static void C_ccall f_5641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5543)
static void C_ccall f_5543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5556)
static void C_ccall f_5556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5564)
static void C_ccall f_5564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5505)
static void C_ccall f_5505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5515)
static void C_ccall f_5515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5407)
static void C_ccall f_5407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5464)
static void C_ccall f_5464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5435)
static void C_fcall f_5435(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5432)
static void C_fcall f_5432(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5299)
static void C_ccall f_5299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5362)
static void C_ccall f_5362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5302)
static void C_fcall f_5302(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5222)
static void C_ccall f_5222(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5222)
static void C_ccall f_5222r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5226)
static void C_ccall f_5226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5236)
static void C_ccall f_5236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4862)
static void C_ccall f_4862(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4866)
static void C_ccall f_4866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5207)
static void C_ccall f_5207(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5216)
static void C_ccall f_5216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5212)
static void C_ccall f_5212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4913)
static void C_ccall f_4913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5133)
static void C_fcall f_5133(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5181)
static void C_ccall f_5181(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5194)
static void C_ccall f_5194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5159)
static void C_ccall f_5159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5175)
static void C_ccall f_5175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5163)
static void C_ccall f_5163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5167)
static void C_ccall f_5167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5146)
static void C_fcall f_5146(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4916)
static void C_ccall f_4916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5058)
static void C_fcall f_5058(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5117)
static void C_ccall f_5117(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5123)
static void C_ccall f_5123(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5074)
static void C_ccall f_5074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5091)
static void C_ccall f_5091(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5104)
static void C_ccall f_5104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5089)
static void C_ccall f_5089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5078)
static void C_ccall f_5078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4919)
static void C_ccall f_4919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4922)
static void C_ccall f_4922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4942)
static void C_ccall f_4942(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4955)
static void C_fcall f_4955(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4998)
static void C_ccall f_4998(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5030)
static void C_ccall f_5030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4996)
static void C_ccall f_4996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4978)
static void C_ccall f_4978(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4925)
static void C_ccall f_4925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4934)
static void C_ccall f_4934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4868)
static void C_fcall f_4868(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4874)
static void C_fcall f_4874(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4898)
static void C_ccall f_4898(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4847)
static void C_ccall f_4847(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4847)
static void C_ccall f_4847r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4590)
static void C_ccall f_4590(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4604)
static void C_ccall f_4604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4619)
static void C_ccall f_4619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4626)
static void C_ccall f_4626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4631)
static void C_fcall f_4631(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4838)
static void C_ccall f_4838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4653)
static void C_ccall f_4653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4656)
static void C_ccall f_4656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4669)
static void C_fcall f_4669(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4684)
static void C_fcall f_4684(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4690)
static void C_ccall f_4690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4696)
static void C_fcall f_4696(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4705)
static void C_fcall f_4705(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4712)
static void C_ccall f_4712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4715)
static void C_ccall f_4715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4733)
static void C_ccall f_4733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4718)
static void C_ccall f_4718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4659)
static void C_fcall f_4659(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4607)
static void C_ccall f_4607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4610)
static void C_ccall f_4610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4597)
static void C_fcall f_4597(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4593)
static C_word C_fcall f_4593(C_word t0);
C_noret_decl(f_2995)
static void C_ccall f_2995(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4478)
static void C_ccall f_4478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4484)
static void C_ccall f_4484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4488)
static void C_ccall f_4488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4491)
static void C_ccall f_4491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4527)
static void C_ccall f_4527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4532)
static void C_fcall f_4532(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4545)
static void C_ccall f_4545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4548)
static void C_ccall f_4548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4494)
static void C_ccall f_4494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4497)
static void C_ccall f_4497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4500)
static void C_ccall f_4500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4503)
static void C_ccall f_4503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4453)
static void C_fcall f_4453(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_4468)
static void C_ccall f_4468(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4457)
static void C_ccall f_4457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4463)
static void C_ccall f_4463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3334)
static void C_fcall f_3334(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4359)
static void C_ccall f_4359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4362)
static void C_ccall f_4362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4445)
static void C_ccall f_4445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4441)
static void C_ccall f_4441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4403)
static void C_fcall f_4403(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4434)
static void C_ccall f_4434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4430)
static void C_ccall f_4430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4422)
static void C_ccall f_4422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4374)
static void C_fcall f_4374(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4393)
static void C_ccall f_4393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4380)
static void C_ccall f_4380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4333)
static void C_ccall f_4333(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4328)
static void C_ccall f_4328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4303)
static void C_ccall f_4303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4293)
static void C_ccall f_4293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3670)
static void C_ccall f_3670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3679)
static void C_ccall f_3679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3885)
static void C_fcall f_3885(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3896)
static void C_ccall f_3896(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4245)
static void C_ccall f_4245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4277)
static void C_ccall f_4277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4254)
static void C_ccall f_4254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3906)
static void C_fcall f_3906(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3978)
static void C_ccall f_3978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4232)
static void C_ccall f_4232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4143)
static void C_fcall f_4143(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4146)
static void C_ccall f_4146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4158)
static void C_ccall f_4158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4169)
static void C_ccall f_4169(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4202)
static void C_ccall f_4202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4194)
static void C_ccall f_4194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4182)
static void C_ccall f_4182(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4173)
static void C_ccall f_4173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4163)
static void C_ccall f_4163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3992)
static void C_fcall f_3992(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4031)
static void C_ccall f_4031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4037)
static void C_ccall f_4037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4043)
static void C_ccall f_4043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4080)
static void C_ccall f_4080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4056)
static void C_ccall f_4056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4060)
static void C_ccall f_4060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4025)
static void C_ccall f_4025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4013)
static void C_ccall f_4013(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4008)
static void C_ccall f_4008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3969)
static void C_ccall f_3969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3909)
static void C_ccall f_3909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3938)
static void C_fcall f_3938(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3951)
static void C_ccall f_3951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3912)
static void C_ccall f_3912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3915)
static void C_ccall f_3915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3918)
static void C_ccall f_3918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3928)
static void C_ccall f_3928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3871)
static void C_ccall f_3871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3767)
static void C_ccall f_3767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3788)
static void C_ccall f_3788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3845)
static void C_ccall f_3845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3837)
static void C_ccall f_3837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3791)
static void C_fcall f_3791(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3816)
static void C_ccall f_3816(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3814)
static void C_ccall f_3814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3800)
static void C_ccall f_3800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3746)
static void C_fcall f_3746(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3688)
static void C_ccall f_3688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3691)
static void C_ccall f_3691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3714)
static void C_fcall f_3714(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3727)
static void C_ccall f_3727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3697)
static void C_ccall f_3697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3704)
static void C_ccall f_3704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3494)
static void C_ccall f_3494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3586)
static void C_ccall f_3586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3591)
static void C_ccall f_3591(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3598)
static void C_ccall f_3598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3631)
static void C_ccall f_3631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3611)
static void C_ccall f_3611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3499)
static void C_ccall f_3499(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3517)
static void C_ccall f_3517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3524)
static void C_ccall f_3524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3564)
static void C_ccall f_3564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3567)
static void C_ccall f_3567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3557)
static void C_ccall f_3557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3537)
static void C_ccall f_3537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3505)
static void C_ccall f_3505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3511)
static void C_ccall f_3511(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3434)
static void C_ccall f_3434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3469)
static void C_ccall f_3469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3476)
static void C_ccall f_3476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3437)
static void C_fcall f_3437(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3459)
static void C_ccall f_3459(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3454)
static void C_ccall f_3454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3359)
static void C_fcall f_3359(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3363)
static void C_ccall f_3363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3375)
static void C_ccall f_3375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3398)
static void C_fcall f_3398(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3381)
static void C_ccall f_3381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3392)
static void C_ccall f_3392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3120)
static void C_fcall f_3120(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3134)
static void C_ccall f_3134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3305)
static void C_ccall f_3305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3311)
static void C_ccall f_3311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3204)
static void C_ccall f_3204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3286)
static void C_ccall f_3286(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3284)
static void C_ccall f_3284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3215)
static void C_ccall f_3215(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3238)
static void C_ccall f_3238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3270)
static void C_ccall f_3270(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3270)
static void C_ccall f_3270r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3276)
static void C_ccall f_3276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3244)
static void C_ccall f_3244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3248)
static void C_ccall f_3248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3251)
static void C_ccall f_3251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3268)
static void C_ccall f_3268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3221)
static void C_ccall f_3221(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3227)
static void C_ccall f_3227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3231)
static void C_fcall f_3231(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3235)
static void C_ccall f_3235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3213)
static void C_ccall f_3213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3143)
static void C_ccall f_3143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3028)
static void C_fcall f_3028(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3032)
static void C_ccall f_3032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3043)
static void C_ccall f_3043(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3053)
static void C_ccall f_3053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3102)
static void C_ccall f_3102(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3100)
static void C_ccall f_3100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3059)
static void C_ccall f_3059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3065)
static void C_ccall f_3065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3092)
static void C_ccall f_3092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3071)
static void C_fcall f_3071(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3035)
static void C_ccall f_3035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3024)
static C_word C_fcall f_3024(C_word t0);
C_noret_decl(f_3004)
static void C_ccall f_3004(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2998)
static void C_fcall f_2998(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2725)
static void C_ccall f_2725(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2746)
static void C_ccall f_2746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2806)
static void C_ccall f_2806(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2837)
static void C_fcall f_2837(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2889)
static void C_fcall f_2889(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2908)
static void C_ccall f_2908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2919)
static void C_ccall f_2919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2892)
static void C_ccall f_2892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2862)
static void C_fcall f_2862(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2809)
static void C_fcall f_2809(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2815)
static void C_fcall f_2815(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2828)
static void C_ccall f_2828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2749)
static void C_ccall f_2749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2752)
static void C_ccall f_2752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2757)
static void C_fcall f_2757(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2772)
static void C_ccall f_2772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2797)
static void C_ccall f_2797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2728)
static C_word C_fcall f_2728(C_word *a,C_word t0,C_word t1);

C_noret_decl(trf_11699)
static void C_fcall trf_11699(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11699(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11699(t0,t1,t2);}

C_noret_decl(trf_11718)
static void C_fcall trf_11718(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11718(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11718(t0,t1);}

C_noret_decl(trf_10829)
static void C_fcall trf_10829(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10829(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10829(t0,t1,t2,t3);}

C_noret_decl(trf_10934)
static void C_fcall trf_10934(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10934(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_10934(t0,t1,t2,t3,t4);}

C_noret_decl(trf_10950)
static void C_fcall trf_10950(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10950(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10950(t0,t1);}

C_noret_decl(trf_8979)
static void C_fcall trf_8979(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8979(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8979(t0,t1,t2,t3);}

C_noret_decl(trf_10024)
static void C_fcall trf_10024(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10024(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10024(t0,t1,t2);}

C_noret_decl(trf_10030)
static void C_fcall trf_10030(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10030(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10030(t0,t1,t2);}

C_noret_decl(trf_10216)
static void C_fcall trf_10216(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10216(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10216(t0,t1,t2);}

C_noret_decl(trf_10190)
static void C_fcall trf_10190(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10190(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10190(t0,t1,t2);}

C_noret_decl(trf_10135)
static void C_fcall trf_10135(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10135(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10135(t0,t1,t2);}

C_noret_decl(trf_10054)
static void C_fcall trf_10054(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10054(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10054(t0,t1,t2,t3);}

C_noret_decl(trf_10095)
static void C_fcall trf_10095(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10095(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10095(t0,t1);}

C_noret_decl(trf_9891)
static void C_fcall trf_9891(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9891(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9891(t0,t1,t2);}

C_noret_decl(trf_9897)
static void C_fcall trf_9897(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9897(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9897(t0,t1,t2);}

C_noret_decl(trf_10001)
static void C_fcall trf_10001(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10001(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10001(t0,t1,t2);}

C_noret_decl(trf_9928)
static void C_fcall trf_9928(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9928(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9928(t0,t1,t2);}

C_noret_decl(trf_9573)
static void C_fcall trf_9573(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9573(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9573(t0,t1,t2,t3);}

C_noret_decl(trf_9712)
static void C_fcall trf_9712(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9712(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9712(t0,t1,t2);}

C_noret_decl(trf_9868)
static void C_fcall trf_9868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9868(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9868(t0,t1,t2);}

C_noret_decl(trf_9796)
static void C_fcall trf_9796(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9796(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9796(t0,t1,t2);}

C_noret_decl(trf_9736)
static void C_fcall trf_9736(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9736(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9736(t0,t1,t2);}

C_noret_decl(trf_9287)
static void C_fcall trf_9287(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9287(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9287(t0,t1,t2);}

C_noret_decl(trf_9536)
static void C_fcall trf_9536(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9536(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9536(t0,t1,t2);}

C_noret_decl(trf_9296)
static void C_fcall trf_9296(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9296(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9296(t0,t1,t2);}

C_noret_decl(trf_9374)
static void C_fcall trf_9374(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9374(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9374(t0,t1,t2);}

C_noret_decl(trf_9321)
static void C_fcall trf_9321(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9321(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9321(t0,t1,t2);}

C_noret_decl(trf_9400)
static void C_fcall trf_9400(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9400(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9400(t0,t1,t2);}

C_noret_decl(trf_9454)
static void C_fcall trf_9454(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9454(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9454(t0,t1,t2);}

C_noret_decl(trf_9013)
static void C_fcall trf_9013(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9013(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9013(t0,t1,t2);}

C_noret_decl(trf_9019)
static void C_fcall trf_9019(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9019(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9019(t0,t1,t2,t3);}

C_noret_decl(trf_9038)
static void C_fcall trf_9038(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9038(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9038(t0,t1);}

C_noret_decl(trf_9244)
static void C_fcall trf_9244(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9244(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9244(t0,t1,t2);}

C_noret_decl(trf_9167)
static void C_fcall trf_9167(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9167(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9167(t0,t1,t2);}

C_noret_decl(trf_9196)
static void C_fcall trf_9196(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9196(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9196(t0,t1,t2);}

C_noret_decl(trf_9129)
static void C_fcall trf_9129(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9129(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9129(t0,t1,t2);}

C_noret_decl(trf_9049)
static void C_fcall trf_9049(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9049(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9049(t0,t1,t2,t3);}

C_noret_decl(trf_8753)
static void C_fcall trf_8753(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8753(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8753(t0,t1,t2);}

C_noret_decl(trf_8759)
static void C_fcall trf_8759(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8759(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8759(t0,t1,t2,t3);}

C_noret_decl(trf_8778)
static void C_fcall trf_8778(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8778(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8778(t0,t1);}

C_noret_decl(trf_8880)
static void C_fcall trf_8880(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8880(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8880(t0,t1,t2);}

C_noret_decl(trf_8837)
static void C_fcall trf_8837(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8837(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8837(t0,t1);}

C_noret_decl(trf_8789)
static void C_fcall trf_8789(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8789(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8789(t0,t1,t2,t3);}

C_noret_decl(trf_8654)
static void C_fcall trf_8654(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8654(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8654(t0,t1,t2,t3);}

C_noret_decl(trf_8709)
static void C_fcall trf_8709(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8709(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8709(t0,t1,t2,t3);}

C_noret_decl(trf_8409)
static void C_fcall trf_8409(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8409(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8409(t0,t1,t2);}

C_noret_decl(trf_8595)
static void C_fcall trf_8595(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8595(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8595(t0,t1,t2);}

C_noret_decl(trf_8412)
static void C_fcall trf_8412(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8412(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8412(t0,t1,t2,t3);}

C_noret_decl(trf_8567)
static void C_fcall trf_8567(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8567(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8567(t0,t1,t2);}

C_noret_decl(trf_8496)
static void C_fcall trf_8496(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8496(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8496(t0,t1,t2,t3);}

C_noret_decl(trf_8437)
static void C_fcall trf_8437(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8437(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8437(t0,t1);}

C_noret_decl(trf_8440)
static void C_fcall trf_8440(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8440(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8440(t0,t1);}

C_noret_decl(trf_8445)
static void C_fcall trf_8445(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8445(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8445(t0,t1,t2);}

C_noret_decl(trf_8309)
static void C_fcall trf_8309(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8309(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8309(t0,t1);}

C_noret_decl(trf_8346)
static void C_fcall trf_8346(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8346(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8346(t0,t1);}

C_noret_decl(trf_7117)
static void C_fcall trf_7117(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7117(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7117(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7273)
static void C_fcall trf_7273(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7273(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7273(t0,t1,t2);}

C_noret_decl(trf_7295)
static void C_fcall trf_7295(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7295(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_7295(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_7298)
static void C_fcall trf_7298(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7298(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7298(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7574)
static void C_fcall trf_7574(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7574(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7574(t0,t1);}

C_noret_decl(trf_7546)
static void C_fcall trf_7546(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7546(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7546(t0,t1);}

C_noret_decl(trf_7499)
static void C_fcall trf_7499(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7499(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7499(t0,t1);}

C_noret_decl(trf_7458)
static void C_fcall trf_7458(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7458(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7458(t0,t1);}

C_noret_decl(trf_7714)
static void C_fcall trf_7714(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7714(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_7714(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_7737)
static void C_fcall trf_7737(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7737(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7737(t0,t1);}

C_noret_decl(trf_7960)
static void C_fcall trf_7960(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7960(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7960(t0,t1,t2);}

C_noret_decl(trf_8223)
static void C_fcall trf_8223(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8223(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8223(t0,t1,t2);}

C_noret_decl(trf_8197)
static void C_fcall trf_8197(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8197(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8197(t0,t1,t2);}

C_noret_decl(trf_7871)
static void C_fcall trf_7871(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7871(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7871(t0,t1,t2);}

C_noret_decl(trf_7781)
static void C_fcall trf_7781(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7781(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7781(t0,t1,t2);}

C_noret_decl(trf_7036)
static void C_fcall trf_7036(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7036(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7036(t0,t1,t2,t3);}

C_noret_decl(trf_5267)
static void C_fcall trf_5267(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5267(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5267(t0,t1);}

C_noret_decl(trf_6950)
static void C_fcall trf_6950(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6950(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6950(t0,t1);}

C_noret_decl(trf_6503)
static void C_fcall trf_6503(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6503(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6503(t0,t1);}

C_noret_decl(trf_6440)
static void C_fcall trf_6440(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6440(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6440(t0,t1);}

C_noret_decl(trf_6202)
static void C_fcall trf_6202(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6202(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6202(t0,t1);}

C_noret_decl(trf_6070)
static void C_fcall trf_6070(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6070(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6070(t0,t1);}

C_noret_decl(trf_5849)
static void C_fcall trf_5849(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5849(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5849(t0,t1);}

C_noret_decl(trf_5852)
static void C_fcall trf_5852(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5852(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5852(t0,t1);}

C_noret_decl(trf_5435)
static void C_fcall trf_5435(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5435(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5435(t0,t1);}

C_noret_decl(trf_5432)
static void C_fcall trf_5432(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5432(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5432(t0,t1);}

C_noret_decl(trf_5302)
static void C_fcall trf_5302(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5302(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5302(t0,t1);}

C_noret_decl(trf_5133)
static void C_fcall trf_5133(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5133(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5133(t0,t1,t2);}

C_noret_decl(trf_5146)
static void C_fcall trf_5146(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5146(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5146(t0,t1);}

C_noret_decl(trf_5058)
static void C_fcall trf_5058(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5058(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5058(t0,t1,t2);}

C_noret_decl(trf_4955)
static void C_fcall trf_4955(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4955(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4955(t0,t1);}

C_noret_decl(trf_4868)
static void C_fcall trf_4868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4868(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4868(t0,t1,t2,t3);}

C_noret_decl(trf_4874)
static void C_fcall trf_4874(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4874(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4874(t0,t1,t2,t3);}

C_noret_decl(trf_4631)
static void C_fcall trf_4631(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4631(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4631(t0,t1,t2);}

C_noret_decl(trf_4669)
static void C_fcall trf_4669(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4669(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4669(t0,t1);}

C_noret_decl(trf_4684)
static void C_fcall trf_4684(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4684(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4684(t0,t1);}

C_noret_decl(trf_4696)
static void C_fcall trf_4696(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4696(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4696(t0,t1);}

C_noret_decl(trf_4705)
static void C_fcall trf_4705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4705(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4705(t0,t1);}

C_noret_decl(trf_4659)
static void C_fcall trf_4659(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4659(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4659(t0,t1);}

C_noret_decl(trf_4597)
static void C_fcall trf_4597(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4597(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4597(t0,t1,t2,t3);}

C_noret_decl(trf_4532)
static void C_fcall trf_4532(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4532(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4532(t0,t1,t2);}

C_noret_decl(trf_4453)
static void C_fcall trf_4453(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4453(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_4453(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3334)
static void C_fcall trf_3334(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3334(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3334(t0,t1,t2,t3);}

C_noret_decl(trf_4403)
static void C_fcall trf_4403(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4403(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4403(t0,t1);}

C_noret_decl(trf_4374)
static void C_fcall trf_4374(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4374(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4374(t0,t1);}

C_noret_decl(trf_3885)
static void C_fcall trf_3885(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3885(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3885(t0,t1);}

C_noret_decl(trf_3906)
static void C_fcall trf_3906(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3906(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3906(t0,t1);}

C_noret_decl(trf_4143)
static void C_fcall trf_4143(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4143(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4143(t0,t1);}

C_noret_decl(trf_3992)
static void C_fcall trf_3992(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3992(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3992(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3938)
static void C_fcall trf_3938(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3938(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3938(t0,t1,t2);}

C_noret_decl(trf_3791)
static void C_fcall trf_3791(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3791(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3791(t0,t1);}

C_noret_decl(trf_3746)
static void C_fcall trf_3746(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3746(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3746(t0,t1);}

C_noret_decl(trf_3714)
static void C_fcall trf_3714(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3714(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3714(t0,t1,t2);}

C_noret_decl(trf_3437)
static void C_fcall trf_3437(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3437(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3437(t0,t1);}

C_noret_decl(trf_3359)
static void C_fcall trf_3359(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3359(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3359(t0,t1,t2);}

C_noret_decl(trf_3398)
static void C_fcall trf_3398(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3398(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3398(t0,t1);}

C_noret_decl(trf_3120)
static void C_fcall trf_3120(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3120(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3120(t0,t1,t2,t3);}

C_noret_decl(trf_3231)
static void C_fcall trf_3231(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3231(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3231(t0,t1);}

C_noret_decl(trf_3028)
static void C_fcall trf_3028(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3028(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3028(t0,t1,t2);}

C_noret_decl(trf_3071)
static void C_fcall trf_3071(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3071(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3071(t0,t1);}

C_noret_decl(trf_2998)
static void C_fcall trf_2998(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2998(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2998(t0,t1,t2,t3);}

C_noret_decl(trf_2837)
static void C_fcall trf_2837(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2837(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2837(t0,t1,t2,t3);}

C_noret_decl(trf_2889)
static void C_fcall trf_2889(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2889(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2889(t0,t1);}

C_noret_decl(trf_2862)
static void C_fcall trf_2862(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2862(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2862(t0,t1);}

C_noret_decl(trf_2809)
static void C_fcall trf_2809(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2809(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2809(t0,t1,t2,t3);}

C_noret_decl(trf_2815)
static void C_fcall trf_2815(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2815(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2815(t0,t1,t2);}

C_noret_decl(trf_2757)
static void C_fcall trf_2757(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2757(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2757(t0,t1,t2);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr10)
static void C_fcall tr10(C_proc10 k) C_regparm C_noret;
C_regparm static void C_fcall tr10(C_proc10 k){
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
(k)(10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(tr14)
static void C_fcall tr14(C_proc14 k) C_regparm C_noret;
C_regparm static void C_fcall tr14(C_proc14 k){
C_word t13=C_pick(0);
C_word t12=C_pick(1);
C_word t11=C_pick(2);
C_word t10=C_pick(3);
C_word t9=C_pick(4);
C_word t8=C_pick(5);
C_word t7=C_pick(6);
C_word t6=C_pick(7);
C_word t5=C_pick(8);
C_word t4=C_pick(9);
C_word t3=C_pick(10);
C_word t2=C_pick(11);
C_word t1=C_pick(12);
C_word t0=C_pick(13);
C_adjust_stack(-14);
(k)(14,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13);}

C_noret_decl(tr11)
static void C_fcall tr11(C_proc11 k) C_regparm C_noret;
C_regparm static void C_fcall tr11(C_proc11 k){
C_word t10=C_pick(0);
C_word t9=C_pick(1);
C_word t8=C_pick(2);
C_word t7=C_pick(3);
C_word t6=C_pick(4);
C_word t5=C_pick(5);
C_word t4=C_pick(6);
C_word t3=C_pick(7);
C_word t2=C_pick(8);
C_word t1=C_pick(9);
C_word t0=C_pick(10);
C_adjust_stack(-11);
(k)(11,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_optimizer_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_optimizer_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("optimizer_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1971)){
C_save(t1);
C_rereclaim2(1971*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,265);
lf[0]=C_h_intern(&lf[0],34,"\010compilerscan-toplevel-assignments");
lf[1]=C_h_intern(&lf[1],8,"\003sysput!");
lf[2]=C_h_intern(&lf[2],21,"\010compileralways-bound");
lf[3]=C_h_intern(&lf[3],9,"\003syserror");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[5]=C_h_intern(&lf[5],18,"\010compilerdebugging");
lf[6]=C_h_intern(&lf[6],1,"o");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000\014safe globals");
lf[8]=C_h_intern(&lf[8],13,"\004corevariable");
lf[9]=C_h_intern(&lf[9],2,"if");
lf[10]=C_h_intern(&lf[10],3,"let");
lf[11]=C_h_intern(&lf[11],6,"append");
lf[12]=C_h_intern(&lf[12],6,"lambda");
lf[13]=C_h_intern(&lf[13],13,"\004corecallunit");
lf[14]=C_h_intern(&lf[14],9,"\004corecall");
lf[15]=C_h_intern(&lf[15],4,"set!");
lf[16]=C_h_intern(&lf[16],9,"\004corecond");
lf[17]=C_h_intern(&lf[17],11,"\004coreswitch");
lf[18]=C_h_intern(&lf[18],30,"call-with-current-continuation");
lf[19]=C_h_intern(&lf[19],1,"p");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000 scanning toplevel assignments...");
lf[21]=C_h_intern(&lf[21],24,"\010compilersimplifications");
lf[22]=C_h_intern(&lf[22],23,"\010compilersimplified-ops");
lf[23]=C_h_intern(&lf[23],41,"\010compilerperform-high-level-optimizations");
lf[24]=C_h_intern(&lf[24],12,"\010compilerget");
lf[25]=C_h_intern(&lf[25],5,"quote");
lf[26]=C_h_intern(&lf[26],10,"alist-cons");
lf[27]=C_h_intern(&lf[27],4,"caar");
lf[28]=C_h_intern(&lf[28],7,"\003sysmap");
lf[29]=C_h_intern(&lf[29],19,"\010compilermatch-node");
lf[30]=C_h_intern(&lf[30],3,"any");
lf[31]=C_h_intern(&lf[31],18,"\003syshash-table-ref");
lf[32]=C_h_intern(&lf[32],30,"\010compilerbroken-constant-nodes");
lf[33]=C_h_intern(&lf[33],11,"lset-adjoin");
lf[34]=C_h_intern(&lf[34],3,"eq\077");
lf[35]=C_h_intern(&lf[35],4,"node");
lf[36]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[37]=C_h_intern(&lf[37],14,"\010compilerqnode");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\033folding constant expression");
lf[39]=C_h_intern(&lf[39],4,"eval");
lf[40]=C_h_intern(&lf[40],22,"with-exception-handler");
lf[41]=C_h_intern(&lf[41],5,"every");
lf[42]=C_h_intern(&lf[42],9,"foldable\077");
lf[43]=C_h_intern(&lf[43],7,"\003sysget");
lf[44]=C_h_intern(&lf[44],18,"\010compilerintrinsic");
lf[45]=C_h_intern(&lf[45],5,"value");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\035substituted constant variable");
lf[47]=C_h_intern(&lf[47],16,"\010compilervarnode");
lf[48]=C_h_intern(&lf[48],11,"collapsable");
lf[49]=C_h_intern(&lf[49],10,"replacable");
lf[50]=C_h_intern(&lf[50],9,"replacing");
lf[51]=C_h_intern(&lf[51],12,"contractable");
lf[52]=C_h_intern(&lf[52],9,"removable");
lf[53]=C_h_intern(&lf[53],11,"\004corelambda");
lf[54]=C_h_intern(&lf[54],6,"unused");
lf[55]=C_h_intern(&lf[55],9,"partition");
lf[56]=C_h_intern(&lf[56],26,"\010compilerbuild-lambda-list");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\047merged explicitly consed rest parameter");
lf[58]=C_h_intern(&lf[58],13,"explicit-rest");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000 removed unused formal parameters");
lf[60]=C_h_intern(&lf[60],30,"\010compilerdecompose-lambda-list");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\047merged explicitly consed rest parameter");
lf[62]=C_h_intern(&lf[62],21,"has-unused-parameters");
lf[63]=C_h_intern(&lf[63],31,"\010compilerinline-lambda-bindings");
lf[64]=C_h_intern(&lf[64],13,"\010compilerput!");
lf[65]=C_h_intern(&lf[65],13,"inline-target");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\024contracted procedure");
lf[67]=C_h_intern(&lf[67],24,"\010compilercheck-signature");
lf[68]=C_h_intern(&lf[68],30,"\010compilerconstant-declarations");
lf[69]=C_h_intern(&lf[69],14,"\004coreundefined");
lf[70]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[71]=C_h_intern(&lf[71],1,"x");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\0005removed call to constant procedure with unused result");
lf[73]=C_h_intern(&lf[73],37,"\010compilerexpression-has-side-effects\077");
lf[74]=C_h_intern(&lf[74],8,"assigned");
lf[75]=C_h_intern(&lf[75],10,"references");
lf[76]=C_h_intern(&lf[76],7,"unknown");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\022inlining procedure");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\017global inlining");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\010inlining");
lf[80]=C_h_intern(&lf[80],1,"i");
lf[81]=C_h_intern(&lf[81],22,"\010compilerinline-global");
lf[82]=C_h_intern(&lf[82],14,"append-reverse");
lf[83]=C_h_intern(&lf[83],6,"gensym");
lf[84]=C_h_intern(&lf[84],1,"t");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000+removed unused parameter to known procedure");
lf[86]=C_h_intern(&lf[86],8,"split-at");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[88]=C_h_intern(&lf[88],20,"\004coreinline_allocate");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\042consed rest parameter at call site");
lf[90]=C_h_intern(&lf[90],21,"\010compilerllist-length");
lf[91]=C_h_intern(&lf[91],23,"\010compilerinline-locally");
lf[92]=C_h_intern(&lf[92],3,"yes");
lf[93]=C_h_intern(&lf[93],2,"no");
lf[94]=C_h_intern(&lf[94],24,"\010compilerinline-max-size");
lf[95]=C_h_intern(&lf[95],15,"\010compilerinline");
lf[96]=C_h_intern(&lf[96],9,"inlinable");
lf[97]=C_h_intern(&lf[97],11,"local-value");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\0006removed side-effect free assignment to unused variable");
lf[99]=C_h_intern(&lf[99],16,"inline-transient");
lf[100]=C_h_intern(&lf[100],26,"\010compilervariable-visible\077");
lf[101]=C_h_intern(&lf[101],6,"global");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\031removed conditional forms");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\025removed binding forms");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\022replaced variables");
lf[105]=C_h_intern(&lf[105],5,"print");
lf[106]=C_h_intern(&lf[106],7,"newline");
lf[107]=C_h_intern(&lf[107],6,"print*");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\027  call simplifications:");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\017simplifications");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\022traversal phase...");
lf[111]=C_h_intern(&lf[111],34,"\010compilerperform-pre-optimization!");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\023Removed `not\047 forms");
lf[113]=C_h_intern(&lf[113],24,"node-subexpressions-set!");
lf[114]=C_h_intern(&lf[114],7,"reverse");
lf[115]=C_h_intern(&lf[115],20,"node-parameters-set!");
lf[116]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[117]=C_h_intern(&lf[117],17,"\010compilerget-list");
lf[118]=C_h_intern(&lf[118],3,"not");
lf[119]=C_h_intern(&lf[119],10,"call-sites");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\031pre-optimization phase...");
lf[121]=C_h_intern(&lf[121],24,"register-simplifications");
lf[122]=C_h_intern(&lf[122],19,"\003syshash-table-set!");
lf[123]=C_h_intern(&lf[123],38,"\010compilerreorganize-recursive-bindings");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000!converted assignments to bindings");
lf[125]=C_h_intern(&lf[125],10,"fold-right");
lf[126]=C_h_intern(&lf[126],4,"fold");
lf[127]=C_h_intern(&lf[127],16,"topological-sort");
lf[128]=C_h_intern(&lf[128],6,"lset<=");
lf[129]=C_h_intern(&lf[129],10,"filter-map");
lf[130]=C_h_intern(&lf[130],6,"filter");
lf[131]=C_h_intern(&lf[131],10,"append-map");
lf[132]=C_h_intern(&lf[132],28,"\010compilerscan-used-variables");
lf[133]=C_h_intern(&lf[133],8,"for-each");
lf[134]=C_h_intern(&lf[134],3,"map");
lf[135]=C_h_intern(&lf[135],4,"cons");
lf[136]=C_h_intern(&lf[136],27,"\010compilersubstitution-table");
lf[137]=C_h_intern(&lf[137],16,"\010compilerrewrite");
lf[138]=C_h_intern(&lf[138],28,"\010compilersimplify-named-call");
lf[139]=C_h_intern(&lf[139],37,"\010compilerinline-substitutions-enabled");
lf[140]=C_h_intern(&lf[140],11,"\004coreinline");
lf[141]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[142]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[143]=C_h_intern(&lf[143],6,"unsafe");
lf[144]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[145]=C_h_intern(&lf[145],6,"vector");
lf[146]=C_h_intern(&lf[146],14,"rest-parameter");
lf[147]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[148]=C_h_intern(&lf[148],11,"number-type");
lf[149]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[150]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[151]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[152]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[153]=C_h_intern(&lf[153],6,"fixnum");
lf[154]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[155]=C_h_intern(&lf[155],21,"\010compilerfold-boolean");
lf[156]=C_h_intern(&lf[156],6,"flonum");
lf[157]=C_h_intern(&lf[157],7,"generic");
lf[158]=C_h_intern(&lf[158],5,"cons*");
lf[159]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[160]=C_h_intern(&lf[160],9,"\004coreproc");
lf[161]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[162]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[163]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[164]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[165]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[166]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[167]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[168]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[169]=C_h_intern(&lf[169],19,"\010compilerfold-inner");
lf[170]=C_h_intern(&lf[170],6,"remove");
lf[171]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[172]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[173]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[174]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[175]=C_h_intern(&lf[175],5,"fifth");
lf[176]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[177]=C_h_intern(&lf[177],13,"\010compilerbomb");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\023bad type (optimize)");
lf[179]=C_h_intern(&lf[179],34,"\010compilertransform-direct-lambdas!");
lf[180]=C_h_intern(&lf[180],19,"\010compilercopy-node!");
lf[181]=C_h_intern(&lf[181],16,"\004coredirect_call");
lf[182]=C_h_intern(&lf[182],4,"quit");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000;known procedure called with wrong number of arguments: `~A\047");
lf[184]=C_h_intern(&lf[184],15,"lset-difference");
lf[185]=C_h_intern(&lf[185],15,"node-class-set!");
lf[186]=C_h_intern(&lf[186],12,"\004corerecurse");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000Gknown procedure called recursively with wrong number of arguments: `~A\047");
lf[188]=C_h_intern(&lf[188],4,"take");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000Gknown procedure called recursively with wrong number of arguments: `~A\047");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\014missing kvar");
lf[191]=C_h_intern(&lf[191],11,"\004corereturn");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\017bad call (leaf)");
lf[193]=C_h_intern(&lf[193],18,"\004coredirect_lambda");
lf[194]=C_h_intern(&lf[194],6,"cdaddr");
lf[195]=C_h_intern(&lf[195],6,"caaddr");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid parameter list");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\0006direct leaf routine with hoistable closures/allocation");
lf[198]=C_h_intern(&lf[198],6,"unzip1");
lf[199]=C_h_intern(&lf[199],16,"\003sysmake-promise");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\036direct leaf routine/allocation");
lf[201]=C_h_intern(&lf[201],5,"boxed");
lf[202]=C_h_intern(&lf[202],15,"\004coreinline_ref");
lf[203]=C_h_intern(&lf[203],37,"\010compilerestimate-foreign-result-size");
lf[204]=C_h_intern(&lf[204],19,"\004coreinline_loc_ref");
lf[205]=C_h_intern(&lf[205],5,"lset=");
lf[206]=C_h_intern(&lf[206],6,"delete");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000(direct leaf routine optimization pass...");
lf[208]=C_h_intern(&lf[208],32,"\010compilerperform-lambda-lifting!");
lf[209]=C_h_intern(&lf[209],23,"\003syshash-table-for-each");
lf[210]=C_h_intern(&lf[210],1,"+");
lf[211]=C_h_intern(&lf[211],17,"delete-duplicates");
lf[212]=C_h_intern(&lf[212],14,"\004coreprimitive");
lf[213]=C_h_intern(&lf[213],7,"delete!");
lf[214]=C_h_intern(&lf[214],11,"concatenate");
lf[215]=C_h_intern(&lf[215],5,"count");
lf[216]=C_h_intern(&lf[216],22,"\010compilerhide-variable");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\037moving liftables to toplevel...");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\032removing local bindings...");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\026changing call sites...");
lf[220]=C_h_intern(&lf[220],12,"pretty-print");
lf[221]=C_h_intern(&lf[221],1,"l");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\026additional parameters:");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\035gathering extra parameters...");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\031liftable local procedures");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000Aeliminating liftables by access-lists and non-liftable callees...");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\014accessibles:");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\031computing access-lists...");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\013call-graph:");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\034eliminating non-liftables...");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\026building call graph...");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\026gathering liftables...");
lf[232]=C_h_intern(&lf[232],11,"make-vector");
lf[233]=C_h_intern(&lf[233],3,"var");
lf[234]=C_h_intern(&lf[234],1,"y");
lf[235]=C_h_intern(&lf[235],2,"d2");
lf[236]=C_h_intern(&lf[236],1,"z");
lf[237]=C_h_intern(&lf[237],2,"d3");
lf[238]=C_h_intern(&lf[238],2,"d1");
lf[239]=C_h_intern(&lf[239],2,"op");
lf[240]=C_h_intern(&lf[240],5,"clist");
lf[241]=C_h_intern(&lf[241],34,"\010compilermembership-test-operators");
lf[242]=C_h_intern(&lf[242],32,"\010compilermembership-unfold-limit");
lf[243]=C_h_intern(&lf[243],4,"var1");
lf[244]=C_h_intern(&lf[244],4,"var0");
lf[245]=C_h_intern(&lf[245],6,"const1");
lf[246]=C_h_intern(&lf[246],4,"var2");
lf[247]=C_h_intern(&lf[247],6,"const2");
lf[248]=C_h_intern(&lf[248],4,"rest");
lf[249]=C_h_intern(&lf[249],5,"body2");
lf[250]=C_h_intern(&lf[250],5,"body1");
lf[251]=C_h_intern(&lf[251],27,"\010compilereq-inline-operator");
lf[252]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\002\376\377\016");
lf[253]=C_h_intern(&lf[253],19,"\010compilerimmediate\077");
lf[254]=C_h_intern(&lf[254],5,"const");
lf[255]=C_h_intern(&lf[255],1,"n");
lf[256]=C_h_intern(&lf[256],7,"clauses");
lf[257]=C_h_intern(&lf[257],4,"body");
lf[258]=C_h_intern(&lf[258],1,"d");
lf[259]=C_h_intern(&lf[259],4,"more");
lf[260]=C_h_intern(&lf[260],4,"args");
lf[261]=C_h_intern(&lf[261],1,"a");
lf[262]=C_h_intern(&lf[262],1,"b");
lf[263]=C_h_intern(&lf[263],1,"c");
lf[264]=C_h_intern(&lf[264],4,"cdar");
C_register_lf2(lf,265,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2708,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2706 */
static void C_ccall f_2708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2708,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2711,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2709 in k2706 */
static void C_ccall f_2711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2711,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2714,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2712 in k2709 in k2706 */
static void C_ccall f_2714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2714,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2717,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_2717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2720,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_2720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2723,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_2723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2723,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! scan-toplevel-assignments ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2725,tmp=(C_word)a,a+=2,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2992,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 105  make-vector */
((C_proc4)C_retrieve_proc(*((C_word*)lf[232]+1)))(4,*((C_word*)lf[232]+1),t3,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_2992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2992,2,t0,t1);}
t2=C_mutate((C_word*)lf[21]+1 /* (set! simplifications ...) */,t1);
t3=C_set_block_item(lf[22] /* simplified-ops */,0,C_SCHEME_END_OF_LIST);
t4=C_mutate((C_word*)lf[23]+1 /* (set! perform-high-level-optimizations ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2995,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[111]+1 /* (set! perform-pre-optimization! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4590,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[121]+1 /* (set! register-simplifications ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4847,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4854,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_a_i_cons(&a,2,lf[261],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[8],t9);
t11=(C_word)C_a_i_cons(&a,2,lf[262],lf[263]);
t12=(C_word)C_a_i_cons(&a,2,t10,t11);
t13=(C_word)C_a_i_cons(&a,2,lf[258],t12);
t14=(C_word)C_a_i_cons(&a,2,lf[14],t13);
t15=(C_word)C_a_i_cons(&a,2,lf[258],C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,lf[263],t15);
t17=(C_word)C_a_i_cons(&a,2,lf[262],t16);
t18=(C_word)C_a_i_cons(&a,2,lf[261],t17);
t19=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11686,tmp=(C_word)a,a+=2,tmp);
t20=(C_word)C_a_i_cons(&a,2,t19,C_SCHEME_END_OF_LIST);
t21=(C_word)C_a_i_cons(&a,2,t18,t20);
t22=(C_word)C_a_i_cons(&a,2,t14,t21);
/* optimizer.scm: 477  register-simplifications */
((C_proc4)C_retrieve_symbol_proc(lf[121]))(4,*((C_word*)lf[121]+1),t7,lf[14],t22);}

/* a11685 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_11686(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_11686,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11694,a[2]=t1,a[3]=t5,a[4]=t4,a[5]=t6,a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 483  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[31]))(4,*((C_word*)lf[31]+1),t7,C_retrieve(lf[136]),t3);}

/* k11692 in a11685 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_11694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11694,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11699,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_11699(t6,((C_word*)t0)[2],t2);}

/* loop in k11692 in a11685 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_11699(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11699,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11709,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11744,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 485  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[27]+1)))(3,*((C_word*)lf[27]+1),t4,t2);}}

/* k11742 in loop in k11692 in a11685 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_11744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11744,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11748,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 485  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[264]+1)))(3,*((C_word*)lf[264]+1),t2,((C_word*)t0)[2]);}

/* k11746 in k11742 in loop in k11692 in a11685 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_11748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 485  simplify-named-call */
((C_proc9)C_retrieve_symbol_proc(lf[138]))(9,*((C_word*)lf[138]+1),((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k11707 in loop in k11692 in a11685 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_11709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11709,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[5],C_retrieve(lf[22]));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11718,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_fixnum_increase(t4);
t6=t3;
f_11718(t6,(C_word)C_i_set_cdr(t2,t5));}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11733,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 490  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t4,((C_word*)t0)[5],C_fix(1),C_retrieve(lf[22]));}}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 492  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_11699(t3,((C_word*)t0)[4],t2);}}

/* k11731 in k11707 in loop in k11692 in a11685 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_11733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[22]+1 /* (set! simplified-ops ...) */,t1);
t3=((C_word*)t0)[2];
f_11718(t3,t2);}

/* k11716 in k11707 in loop in k11692 in a11685 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_11718(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word ab[434],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4857,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_cons(&a,2,lf[243],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[239],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[244],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[8],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[245],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[25],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t7,t11);
t13=(C_word)C_a_i_cons(&a,2,t4,t12);
t14=(C_word)C_a_i_cons(&a,2,lf[140],t13);
t15=(C_word)C_a_i_cons(&a,2,lf[243],C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,lf[8],t16);
t18=(C_word)C_a_i_cons(&a,2,lf[246],C_SCHEME_END_OF_LIST);
t19=(C_word)C_a_i_cons(&a,2,lf[239],C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,lf[244],C_SCHEME_END_OF_LIST);
t21=(C_word)C_a_i_cons(&a,2,t20,C_SCHEME_END_OF_LIST);
t22=(C_word)C_a_i_cons(&a,2,lf[8],t21);
t23=(C_word)C_a_i_cons(&a,2,lf[247],C_SCHEME_END_OF_LIST);
t24=(C_word)C_a_i_cons(&a,2,t23,C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,lf[25],t24);
t26=(C_word)C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,t22,t26);
t28=(C_word)C_a_i_cons(&a,2,t19,t27);
t29=(C_word)C_a_i_cons(&a,2,lf[140],t28);
t30=(C_word)C_a_i_cons(&a,2,lf[246],C_SCHEME_END_OF_LIST);
t31=(C_word)C_a_i_cons(&a,2,t30,C_SCHEME_END_OF_LIST);
t32=(C_word)C_a_i_cons(&a,2,lf[8],t31);
t33=(C_word)C_a_i_cons(&a,2,lf[248],C_SCHEME_END_OF_LIST);
t34=(C_word)C_a_i_cons(&a,2,lf[249],t33);
t35=(C_word)C_a_i_cons(&a,2,t32,t34);
t36=(C_word)C_a_i_cons(&a,2,lf[235],t35);
t37=(C_word)C_a_i_cons(&a,2,lf[9],t36);
t38=(C_word)C_a_i_cons(&a,2,t37,C_SCHEME_END_OF_LIST);
t39=(C_word)C_a_i_cons(&a,2,t29,t38);
t40=(C_word)C_a_i_cons(&a,2,t18,t39);
t41=(C_word)C_a_i_cons(&a,2,lf[10],t40);
t42=(C_word)C_a_i_cons(&a,2,t41,C_SCHEME_END_OF_LIST);
t43=(C_word)C_a_i_cons(&a,2,lf[250],t42);
t44=(C_word)C_a_i_cons(&a,2,t17,t43);
t45=(C_word)C_a_i_cons(&a,2,lf[238],t44);
t46=(C_word)C_a_i_cons(&a,2,lf[9],t45);
t47=(C_word)C_a_i_cons(&a,2,t46,C_SCHEME_END_OF_LIST);
t48=(C_word)C_a_i_cons(&a,2,t14,t47);
t49=(C_word)C_a_i_cons(&a,2,t3,t48);
t50=(C_word)C_a_i_cons(&a,2,lf[10],t49);
t51=(C_word)C_a_i_cons(&a,2,lf[248],C_SCHEME_END_OF_LIST);
t52=(C_word)C_a_i_cons(&a,2,lf[235],t51);
t53=(C_word)C_a_i_cons(&a,2,lf[238],t52);
t54=(C_word)C_a_i_cons(&a,2,lf[249],t53);
t55=(C_word)C_a_i_cons(&a,2,lf[250],t54);
t56=(C_word)C_a_i_cons(&a,2,lf[247],t55);
t57=(C_word)C_a_i_cons(&a,2,lf[245],t56);
t58=(C_word)C_a_i_cons(&a,2,lf[239],t57);
t59=(C_word)C_a_i_cons(&a,2,lf[246],t58);
t60=(C_word)C_a_i_cons(&a,2,lf[243],t59);
t61=(C_word)C_a_i_cons(&a,2,lf[244],t60);
t62=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11371,tmp=(C_word)a,a+=2,tmp);
t63=(C_word)C_a_i_cons(&a,2,t62,C_SCHEME_END_OF_LIST);
t64=(C_word)C_a_i_cons(&a,2,t61,t63);
t65=(C_word)C_a_i_cons(&a,2,t50,t64);
t66=(C_word)C_a_i_cons(&a,2,lf[233],C_SCHEME_END_OF_LIST);
t67=(C_word)C_a_i_cons(&a,2,lf[239],C_SCHEME_END_OF_LIST);
t68=(C_word)C_a_i_cons(&a,2,lf[244],C_SCHEME_END_OF_LIST);
t69=(C_word)C_a_i_cons(&a,2,t68,C_SCHEME_END_OF_LIST);
t70=(C_word)C_a_i_cons(&a,2,lf[8],t69);
t71=(C_word)C_a_i_cons(&a,2,lf[254],C_SCHEME_END_OF_LIST);
t72=(C_word)C_a_i_cons(&a,2,t71,C_SCHEME_END_OF_LIST);
t73=(C_word)C_a_i_cons(&a,2,lf[25],t72);
t74=(C_word)C_a_i_cons(&a,2,t73,C_SCHEME_END_OF_LIST);
t75=(C_word)C_a_i_cons(&a,2,t70,t74);
t76=(C_word)C_a_i_cons(&a,2,t67,t75);
t77=(C_word)C_a_i_cons(&a,2,lf[140],t76);
t78=(C_word)C_a_i_cons(&a,2,lf[233],C_SCHEME_END_OF_LIST);
t79=(C_word)C_a_i_cons(&a,2,t78,C_SCHEME_END_OF_LIST);
t80=(C_word)C_a_i_cons(&a,2,lf[8],t79);
t81=(C_word)C_a_i_cons(&a,2,lf[255],C_SCHEME_END_OF_LIST);
t82=(C_word)C_a_i_cons(&a,2,lf[244],C_SCHEME_END_OF_LIST);
t83=(C_word)C_a_i_cons(&a,2,t82,C_SCHEME_END_OF_LIST);
t84=(C_word)C_a_i_cons(&a,2,lf[8],t83);
t85=(C_word)C_a_i_cons(&a,2,t84,lf[256]);
t86=(C_word)C_a_i_cons(&a,2,t81,t85);
t87=(C_word)C_a_i_cons(&a,2,lf[17],t86);
t88=(C_word)C_a_i_cons(&a,2,t87,C_SCHEME_END_OF_LIST);
t89=(C_word)C_a_i_cons(&a,2,lf[257],t88);
t90=(C_word)C_a_i_cons(&a,2,t80,t89);
t91=(C_word)C_a_i_cons(&a,2,lf[258],t90);
t92=(C_word)C_a_i_cons(&a,2,lf[9],t91);
t93=(C_word)C_a_i_cons(&a,2,t92,C_SCHEME_END_OF_LIST);
t94=(C_word)C_a_i_cons(&a,2,t77,t93);
t95=(C_word)C_a_i_cons(&a,2,t66,t94);
t96=(C_word)C_a_i_cons(&a,2,lf[10],t95);
t97=(C_word)C_a_i_cons(&a,2,lf[256],C_SCHEME_END_OF_LIST);
t98=(C_word)C_a_i_cons(&a,2,lf[255],t97);
t99=(C_word)C_a_i_cons(&a,2,lf[257],t98);
t100=(C_word)C_a_i_cons(&a,2,lf[258],t99);
t101=(C_word)C_a_i_cons(&a,2,lf[254],t100);
t102=(C_word)C_a_i_cons(&a,2,lf[244],t101);
t103=(C_word)C_a_i_cons(&a,2,lf[239],t102);
t104=(C_word)C_a_i_cons(&a,2,lf[233],t103);
t105=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11157,tmp=(C_word)a,a+=2,tmp);
t106=(C_word)C_a_i_cons(&a,2,t105,C_SCHEME_END_OF_LIST);
t107=(C_word)C_a_i_cons(&a,2,t104,t106);
t108=(C_word)C_a_i_cons(&a,2,t96,t107);
t109=(C_word)C_a_i_cons(&a,2,lf[243],C_SCHEME_END_OF_LIST);
t110=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t111=(C_word)C_a_i_cons(&a,2,lf[69],t110);
t112=(C_word)C_a_i_cons(&a,2,lf[259],C_SCHEME_END_OF_LIST);
t113=(C_word)C_a_i_cons(&a,2,t111,t112);
t114=(C_word)C_a_i_cons(&a,2,t109,t113);
t115=(C_word)C_a_i_cons(&a,2,lf[10],t114);
t116=(C_word)C_a_i_cons(&a,2,lf[259],C_SCHEME_END_OF_LIST);
t117=(C_word)C_a_i_cons(&a,2,lf[243],t116);
t118=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10819,tmp=(C_word)a,a+=2,tmp);
t119=(C_word)C_a_i_cons(&a,2,t118,C_SCHEME_END_OF_LIST);
t120=(C_word)C_a_i_cons(&a,2,t117,t119);
t121=(C_word)C_a_i_cons(&a,2,t115,t120);
t122=(C_word)C_a_i_cons(&a,2,lf[233],C_SCHEME_END_OF_LIST);
t123=(C_word)C_a_i_cons(&a,2,lf[239],C_SCHEME_END_OF_LIST);
t124=(C_word)C_a_i_cons(&a,2,t123,lf[260]);
t125=(C_word)C_a_i_cons(&a,2,lf[140],t124);
t126=(C_word)C_a_i_cons(&a,2,lf[233],C_SCHEME_END_OF_LIST);
t127=(C_word)C_a_i_cons(&a,2,t126,C_SCHEME_END_OF_LIST);
t128=(C_word)C_a_i_cons(&a,2,lf[8],t127);
t129=(C_word)C_a_i_cons(&a,2,lf[234],C_SCHEME_END_OF_LIST);
t130=(C_word)C_a_i_cons(&a,2,lf[71],t129);
t131=(C_word)C_a_i_cons(&a,2,t128,t130);
t132=(C_word)C_a_i_cons(&a,2,lf[258],t131);
t133=(C_word)C_a_i_cons(&a,2,lf[9],t132);
t134=(C_word)C_a_i_cons(&a,2,t133,C_SCHEME_END_OF_LIST);
t135=(C_word)C_a_i_cons(&a,2,t125,t134);
t136=(C_word)C_a_i_cons(&a,2,t122,t135);
t137=(C_word)C_a_i_cons(&a,2,lf[10],t136);
t138=(C_word)C_a_i_cons(&a,2,lf[234],C_SCHEME_END_OF_LIST);
t139=(C_word)C_a_i_cons(&a,2,lf[71],t138);
t140=(C_word)C_a_i_cons(&a,2,lf[258],t139);
t141=(C_word)C_a_i_cons(&a,2,lf[260],t140);
t142=(C_word)C_a_i_cons(&a,2,lf[239],t141);
t143=(C_word)C_a_i_cons(&a,2,lf[233],t142);
t144=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10683,tmp=(C_word)a,a+=2,tmp);
t145=(C_word)C_a_i_cons(&a,2,t144,C_SCHEME_END_OF_LIST);
t146=(C_word)C_a_i_cons(&a,2,t143,t145);
t147=(C_word)C_a_i_cons(&a,2,t137,t146);
/* optimizer.scm: 495  register-simplifications */
((C_proc7)C_retrieve_symbol_proc(lf[121]))(7,*((C_word*)lf[121]+1),t2,lf[10],t65,t108,t121,t147);}

/* a10682 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10683(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_10683,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
if(C_truep((C_word)C_i_equalp(t4,C_retrieve(lf[251])))){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10717,a[2]=t1,a[3]=t8,a[4]=t7,a[5]=t5,a[6]=t4,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 633  get-list */
((C_proc5)C_retrieve_symbol_proc(lf[117]))(5,*((C_word*)lf[117]+1),t9,t2,t3,lf[75]);}}

/* k10715 in a10682 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10717,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=((C_word*)t0)[7];
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
t6=((C_word*)t0)[5];
t7=(C_word)C_a_i_record(&a,4,lf[35],lf[140],t5,t6);
t8=(C_word)C_a_i_list(&a,3,t7,((C_word*)t0)[4],((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_record(&a,4,lf[35],lf[9],t4,t8));}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* a10818 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10819(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10819,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t3);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10829,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_10829(t9,t1,t5,t4);}

/* loop1 in a10818 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_10829(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10829,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t3;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(t5,lf[10]);
if(C_truep(t10)){
t11=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t11))){
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11103,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t7,a[6]=t9,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t13=(C_word)C_i_car(t7);
/* optimizer.scm: 572  get */
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),t12,((C_word*)t0)[2],t13,lf[99]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}

/* k11101 in loop1 in a10818 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_11103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11103,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11095,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 573  get */
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),t2,((C_word*)t0)[2],t3,lf[75]);}}

/* k11093 in k11101 in loop1 in a10818 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_11095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11095,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_slot(t2,C_fix(2));
t4=(C_word)C_slot(t2,C_fix(3));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_eqp(t5,lf[69]);
if(C_truep(t6)){
t7=(C_word)C_i_car(((C_word*)t0)[5]);
t8=(C_word)C_a_i_cons(&a,2,t7,((C_word*)t0)[4]);
t9=(C_word)C_i_cadr(((C_word*)t0)[6]);
/* optimizer.scm: 578  loop1 */
t10=((C_word*)((C_word*)t0)[3])[1];
f_10829(t10,((C_word*)t0)[7],t8,t9);}
else{
t7=(C_word)C_eqp(t5,lf[15]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10905,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 580  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[114]+1)))(3,*((C_word*)lf[114]+1),t8,((C_word*)t0)[4]);}
else{
t8=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}}

/* k10903 in k11093 in k11101 in loop1 in a10818 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10905,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_car(t1);
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_i_cdr(t1);
t8=(C_word)C_i_cadr(((C_word*)t0)[4]);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10934,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t10,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_10934(t12,((C_word*)t0)[2],t6,t7,t8);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop2 in k10903 in k11093 in k11101 in loop1 in a10818 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_10934(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10934,NULL,5,t0,t1,t2,t3,t4);}
t5=t4;
t6=(C_word)C_slot(t5,C_fix(1));
t7=t4;
t8=(C_word)C_slot(t7,C_fix(2));
t9=t4;
t10=(C_word)C_slot(t9,C_fix(3));
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10950,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=t2,a[8]=t10,tmp=(C_word)a,a+=9,tmp);
t12=(C_word)C_eqp(t6,lf[10]);
if(C_truep(t12)){
t13=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t13))){
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11071,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t10,a[5]=t3,a[6]=t11,tmp=(C_word)a,a+=7,tmp);
t15=(C_word)C_i_car(t8);
/* optimizer.scm: 591  get */
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),t14,((C_word*)t0)[2],t15,lf[99]);}
else{
t14=t11;
f_10950(t14,C_SCHEME_FALSE);}}
else{
t13=t11;
f_10950(t13,C_SCHEME_FALSE);}}

/* k11069 in loop2 in k10903 in k11093 in k11101 in loop1 in a10818 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_11071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11071,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
f_10950(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11063,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 592  get */
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),t2,((C_word*)t0)[2],t3,lf[75]);}}

/* k11061 in k11069 in loop2 in k10903 in k11093 in k11101 in loop1 in a10818 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_11063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_10950(t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_eqp(lf[15],t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(C_word)C_i_car(((C_word*)t0)[2]);
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=((C_word*)t0)[4];
f_10950(t9,(C_word)C_eqp(t5,t8));}
else{
t5=((C_word*)t0)[4];
f_10950(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
f_10950(t2,C_SCHEME_FALSE);}}}

/* k10948 in loop2 in k10903 in k11093 in k11101 in loop1 in a10818 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_10950(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10950,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(C_word)C_slot(t2,C_fix(3));
t4=(C_word)C_i_car(t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[7]);
t6=(C_word)C_i_cdr(((C_word*)t0)[6]);
t7=(C_word)C_i_cadr(((C_word*)t0)[8]);
/* optimizer.scm: 596  loop2 */
t8=((C_word*)((C_word*)t0)[5])[1];
f_10934(t8,((C_word*)t0)[4],t5,t6,t7);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10987,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10997,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[4],t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* a10996 in k10948 in loop2 in k10903 in k11093 in k11101 in loop1 in a10818 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10997(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10997,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t2:C_SCHEME_FALSE));}

/* a10986 in k10948 in loop2 in k10903 in k11093 in k11101 in loop1 in a10818 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10995,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 601  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[114]+1)))(3,*((C_word*)lf[114]+1),t2,((C_word*)t0)[2]);}

/* k10993 in a10986 in k10948 in loop2 in k10903 in k11093 in k11101 in loop1 in a10818 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 601  reorganize-recursive-bindings */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a11156 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_11157(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10){
C_word tmp;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(c!=11) C_bad_argc_2(c,11,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr11,(void*)f_11157,11,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}
if(C_truep((C_word)C_i_equalp(t4,C_retrieve(lf[251])))){
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11170,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t6,a[6]=t10,a[7]=t8,a[8]=t1,a[9]=t9,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 542  immediate? */
((C_proc3)C_retrieve_symbol_proc(lf[253]))(3,*((C_word*)lf[253]+1),t11,t6);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}

/* k11168 in a11156 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_11170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11170,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11205,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 543  get-list */
((C_proc5)C_retrieve_symbol_proc(lf[117]))(5,*((C_word*)lf[117]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[75]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k11203 in k11168 in a11156 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_11205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11205,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11182,a[2]=t5,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11189,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 547  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[47]))(3,*((C_word*)lf[47]+1),t7,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k11187 in k11203 in k11168 in a11156 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_11189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11189,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11193,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 548  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t2,((C_word*)t0)[2]);}

/* k11191 in k11187 in k11203 in k11168 in a11156 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_11193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 547  cons* */
((C_proc6)C_retrieve_symbol_proc(lf[158]))(6,*((C_word*)lf[158]+1),((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11180 in k11203 in k11168 in a11156 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_11182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11182,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[35],lf[17],((C_word*)t0)[2],t1));}

/* a11370 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_11371(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13){
C_word tmp;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(c!=14) C_bad_argc_2(c,14,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr14,(void*)f_11371,14,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13);}
if(C_truep((C_word)C_i_equalp(t6,C_retrieve(lf[251])))){
t14=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_11384,a[2]=t4,a[3]=t5,a[4]=t2,a[5]=t3,a[6]=t7,a[7]=t8,a[8]=t1,a[9]=t13,a[10]=t10,a[11]=t9,tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 515  immediate? */
((C_proc3)C_retrieve_symbol_proc(lf[253]))(3,*((C_word*)lf[253]+1),t14,t7);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}

/* k11382 in a11370 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_11384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11384,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_11390,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 516  immediate? */
((C_proc3)C_retrieve_symbol_proc(lf[253]))(3,*((C_word*)lf[253]+1),t2,((C_word*)t0)[7]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k11388 in k11382 in a11370 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_11390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11390,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11436,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 517  get-list */
((C_proc5)C_retrieve_symbol_proc(lf[117]))(5,*((C_word*)lf[117]+1),t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[75]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k11434 in k11388 in k11382 in a11370 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_11436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11436,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11428,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 518  get-list */
((C_proc5)C_retrieve_symbol_proc(lf[117]))(5,*((C_word*)lf[117]+1),t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[75]);}
else{
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k11426 in k11434 in k11388 in k11382 in a11370 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_11428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11428,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11412,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 522  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[47]))(3,*((C_word*)lf[47]+1),t4,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k11410 in k11426 in k11434 in k11388 in k11382 in a11370 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_11412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11412,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11416,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 523  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t2,((C_word*)t0)[2]);}

/* k11414 in k11410 in k11426 in k11434 in k11388 in k11382 in a11370 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_11416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11420,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 525  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t2,((C_word*)t0)[2]);}

/* k11418 in k11414 in k11410 in k11426 in k11434 in k11388 in k11382 in a11370 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_11420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11420,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,6,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[35],lf[17],lf[252],t2));}

/* k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word ab[160],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4857,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4860,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_cons(&a,2,lf[233],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[8],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[234],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,lf[235],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[14],t8);
t10=(C_word)C_a_i_cons(&a,2,lf[233],C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,lf[8],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[236],C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t12,t13);
t15=(C_word)C_a_i_cons(&a,2,lf[237],t14);
t16=(C_word)C_a_i_cons(&a,2,lf[14],t15);
t17=(C_word)C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=(C_word)C_a_i_cons(&a,2,t9,t17);
t19=(C_word)C_a_i_cons(&a,2,lf[71],t18);
t20=(C_word)C_a_i_cons(&a,2,lf[238],t19);
t21=(C_word)C_a_i_cons(&a,2,lf[9],t20);
t22=(C_word)C_a_i_cons(&a,2,lf[233],C_SCHEME_END_OF_LIST);
t23=(C_word)C_a_i_cons(&a,2,lf[236],t22);
t24=(C_word)C_a_i_cons(&a,2,lf[234],t23);
t25=(C_word)C_a_i_cons(&a,2,lf[71],t24);
t26=(C_word)C_a_i_cons(&a,2,lf[237],t25);
t27=(C_word)C_a_i_cons(&a,2,lf[235],t26);
t28=(C_word)C_a_i_cons(&a,2,lf[238],t27);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10532,tmp=(C_word)a,a+=2,tmp);
t30=(C_word)C_a_i_cons(&a,2,t29,C_SCHEME_END_OF_LIST);
t31=(C_word)C_a_i_cons(&a,2,t28,t30);
t32=(C_word)C_a_i_cons(&a,2,t21,t31);
t33=(C_word)C_a_i_cons(&a,2,lf[239],C_SCHEME_END_OF_LIST);
t34=(C_word)C_a_i_cons(&a,2,lf[240],C_SCHEME_END_OF_LIST);
t35=(C_word)C_a_i_cons(&a,2,t34,C_SCHEME_END_OF_LIST);
t36=(C_word)C_a_i_cons(&a,2,lf[25],t35);
t37=(C_word)C_a_i_cons(&a,2,t36,C_SCHEME_END_OF_LIST);
t38=(C_word)C_a_i_cons(&a,2,lf[71],t37);
t39=(C_word)C_a_i_cons(&a,2,t33,t38);
t40=(C_word)C_a_i_cons(&a,2,lf[140],t39);
t41=(C_word)C_a_i_cons(&a,2,lf[236],C_SCHEME_END_OF_LIST);
t42=(C_word)C_a_i_cons(&a,2,lf[234],t41);
t43=(C_word)C_a_i_cons(&a,2,t40,t42);
t44=(C_word)C_a_i_cons(&a,2,lf[238],t43);
t45=(C_word)C_a_i_cons(&a,2,lf[9],t44);
t46=(C_word)C_a_i_cons(&a,2,lf[236],C_SCHEME_END_OF_LIST);
t47=(C_word)C_a_i_cons(&a,2,lf[234],t46);
t48=(C_word)C_a_i_cons(&a,2,lf[240],t47);
t49=(C_word)C_a_i_cons(&a,2,lf[71],t48);
t50=(C_word)C_a_i_cons(&a,2,lf[239],t49);
t51=(C_word)C_a_i_cons(&a,2,lf[238],t50);
t52=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10361,tmp=(C_word)a,a+=2,tmp);
t53=(C_word)C_a_i_cons(&a,2,t52,C_SCHEME_END_OF_LIST);
t54=(C_word)C_a_i_cons(&a,2,t51,t53);
t55=(C_word)C_a_i_cons(&a,2,t45,t54);
/* optimizer.scm: 640  register-simplifications */
((C_proc5)C_retrieve_symbol_proc(lf[121]))(5,*((C_word*)lf[121]+1),t2,lf[9],t32,t55);}

/* a10360 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10361(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_10361,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(C_word)C_i_assoc(t4,C_retrieve(lf[241]));
if(C_truep(t9)){
if(C_truep((C_word)C_i_listp(t6))){
t10=(C_word)C_i_length(t6);
t11=C_retrieve(lf[242]);
if(C_truep((C_word)C_fixnum_lessp(t10,t11))){
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10383,a[2]=t6,a[3]=t1,a[4]=t5,a[5]=t8,a[6]=t7,a[7]=t3,a[8]=t9,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 671  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[83]))(2,*((C_word*)lf[83]+1),t12);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k10381 in a10360 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10383,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,1,t1);
t5=((C_word*)t0)[7];
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10406,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10408,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10438,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 688  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t8,C_SCHEME_FALSE);}

/* k10436 in k10381 in a10360 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 680  fold-right */
((C_proc5)C_retrieve_symbol_proc(lf[125]))(5,*((C_word*)lf[125]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a10407 in k10381 in a10360 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10408(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10408,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10430,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 685  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[47]))(3,*((C_word*)lf[47]+1),t4,((C_word*)t0)[2]);}

/* k10428 in a10407 in k10381 in a10360 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10434,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 685  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t2,((C_word*)t0)[2]);}

/* k10432 in k10428 in a10407 in k10381 in a10360 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10434,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_record(&a,4,lf[35],lf[140],((C_word*)t0)[4],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10426,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 686  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t4,C_SCHEME_TRUE);}

/* k10424 in k10432 in k10428 in a10407 in k10381 in a10360 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10426,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[35],lf[16],C_SCHEME_END_OF_LIST,t2));}

/* k10404 in k10381 in a10360 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10406,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,t1,((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(C_word)C_a_i_record(&a,4,lf[35],lf[9],((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[35],lf[10],((C_word*)t0)[2],t4));}

/* a10531 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10532(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(c!=10) C_bad_argc_2(c,10,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr10,(void*)f_10532,10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}
if(C_truep(C_retrieve(lf[139]))){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10546,a[2]=t4,a[3]=t1,a[4]=t8,a[5]=t7,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 656  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[47]))(3,*((C_word*)lf[47]+1),t10,t9);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k10544 in a10531 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10546,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_a_i_record(&a,4,lf[35],lf[16],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_list(&a,2,t1,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[35],lf[14],((C_word*)t0)[2],t4));}

/* k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4860,2,t0,t1);}
t2=C_mutate((C_word*)lf[123]+1 /* (set! reorganize-recursive-bindings ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4862,tmp=(C_word)a,a+=2,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5220,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 783  make-vector */
((C_proc4)C_retrieve_proc(*((C_word*)lf[232]+1)))(4,*((C_word*)lf[232]+1),t3,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5220,2,t0,t1);}
t2=C_mutate((C_word*)lf[136]+1 /* (set! substitution-table ...) */,t1);
t3=C_mutate((C_word*)lf[137]+1 /* (set! rewrite ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5222,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[138]+1 /* (set! simplify-named-call ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5242,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[179]+1 /* (set! transform-direct-lambdas! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7114,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[208]+1 /* (set! perform-lambda-lifting! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8306,tmp=(C_word)a,a+=2,tmp));
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}

/* ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8306(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[44],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8306,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8309,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8409,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8654,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8753,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9013,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9287,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9573,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9891,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10024,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10240,a[2]=t6,a[3]=t7,a[4]=t8,a[5]=t9,a[6]=t10,a[7]=t11,a[8]=t13,a[9]=t14,a[10]=t1,a[11]=t12,tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1759 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t15,lf[19],lf[231]);}

/* k10238 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10243,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1760 find-lifting-candidates */
t3=((C_word*)t0)[2];
f_8309(t3,t2);}

/* k10241 in k10238 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10246,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1761 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t2,lf[19],lf[230]);}

/* k10244 in k10241 in k10238 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10246,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10249,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1762 build-call-graph */
t3=((C_word*)t0)[2];
f_8409(t3,t2,((C_word*)t0)[3]);}

/* k10247 in k10244 in k10241 in k10238 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10249,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10252,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1763 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t2,lf[19],lf[229]);}

/* k10250 in k10247 in k10244 in k10241 in k10238 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10252,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10255,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1764 eliminate */
t3=((C_word*)t0)[4];
f_8654(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10253 in k10250 in k10247 in k10244 in k10241 in k10238 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10255,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10258,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10332,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1765 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t3,lf[221],lf[228]);}

/* k10330 in k10253 in k10250 in k10247 in k10244 in k10241 in k10238 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1765 pretty-print */
((C_proc3)C_retrieve_symbol_proc(lf[220]))(3,*((C_word*)lf[220]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10258(2,t2,C_SCHEME_UNDEFINED);}}

/* k10256 in k10253 in k10250 in k10247 in k10244 in k10241 in k10238 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10258,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10261,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 1766 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t2,lf[19],lf[227]);}

/* k10259 in k10256 in k10253 in k10250 in k10247 in k10244 in k10241 in k10238 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10264,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1767 collect-accessibles */
t3=((C_word*)t0)[2];
f_8753(t3,t2,((C_word*)t0)[3]);}

/* k10262 in k10259 in k10256 in k10253 in k10250 in k10247 in k10244 in k10241 in k10238 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10264,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10267,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10326,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1768 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t3,lf[221],lf[226]);}

/* k10324 in k10262 in k10259 in k10256 in k10253 in k10250 in k10247 in k10244 in k10241 in k10238 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1768 pretty-print */
((C_proc3)C_retrieve_symbol_proc(lf[220]))(3,*((C_word*)lf[220]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10267(2,t2,C_SCHEME_UNDEFINED);}}

/* k10265 in k10262 in k10259 in k10256 in k10253 in k10250 in k10247 in k10244 in k10241 in k10238 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10270,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1769 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t2,lf[19],lf[225]);}

/* k10268 in k10265 in k10262 in k10259 in k10256 in k10253 in k10250 in k10247 in k10244 in k10241 in k10238 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10270,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10273,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10323,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1770 eliminate4 */
t4=((C_word*)t0)[3];
f_9013(t4,t3,((C_word*)t0)[2]);}

/* k10321 in k10268 in k10265 in k10262 in k10259 in k10256 in k10253 in k10250 in k10247 in k10244 in k10241 in k10238 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10323,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8979,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_8979(t6,((C_word*)t0)[2],t1,t2);}

/* loop in k10321 in k10268 in k10265 in k10262 in k10259 in k10256 in k10253 in k10250 in k10247 in k10244 in k10241 in k10238 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_8979(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8979,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8983,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8997,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1564 filter */
((C_proc4)C_retrieve_symbol_proc(lf[130]))(4,*((C_word*)lf[130]+1),t4,t5,t2);}

/* a8996 in loop in k10321 in k10268 in k10265 in k10262 in k10259 in k10256 in k10253 in k10250 in k10247 in k10244 in k10241 in k10238 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8997(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8997,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9003,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cddr(t2);
/* optimizer.scm: 1564 every */
((C_proc4)C_retrieve_symbol_proc(lf[41]))(4,*((C_word*)lf[41]+1),t1,t3,t4);}

/* a9002 in a8996 in loop in k10321 in k10268 in k10265 in k10262 in k10259 in k10256 in k10253 in k10250 in k10247 in k10244 in k10241 in k10238 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9003(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9003,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k8981 in loop in k10321 in k10268 in k10265 in k10262 in k10259 in k10256 in k10253 in k10250 in k10247 in k10244 in k10241 in k10238 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_length(t1);
t3=((C_word*)t0)[4];
t4=(C_word)C_eqp(t3,t2);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}
else{
/* optimizer.scm: 1568 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_8979(t5,((C_word*)t0)[3],t1,t2);}}

/* k10271 in k10268 in k10265 in k10262 in k10259 in k10256 in k10253 in k10250 in k10247 in k10244 in k10241 in k10238 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10273,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10276,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10313,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10315,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#make-promise */
t5=*((C_word*)lf[199]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a10314 in k10271 in k10268 in k10265 in k10262 in k10259 in k10256 in k10253 in k10250 in k10247 in k10244 in k10241 in k10238 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10315,2,t0,t1);}
/* optimizer.scm: 1771 unzip1 */
((C_proc3)C_retrieve_symbol_proc(lf[198]))(3,*((C_word*)lf[198]+1),t1,((C_word*)t0)[2]);}

/* k10311 in k10271 in k10268 in k10265 in k10262 in k10259 in k10256 in k10253 in k10250 in k10247 in k10244 in k10241 in k10238 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1771 debugging */
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),((C_word*)t0)[2],lf[6],lf[224],t1);}

/* k10274 in k10271 in k10268 in k10265 in k10262 in k10259 in k10256 in k10253 in k10250 in k10247 in k10244 in k10241 in k10238 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10279,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1772 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t2,lf[19],lf[223]);}

/* k10277 in k10274 in k10271 in k10268 in k10265 in k10262 in k10259 in k10256 in k10253 in k10250 in k10247 in k10244 in k10241 in k10238 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10279,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10282,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1773 compute-extra-variables */
t3=((C_word*)t0)[2];
f_9287(t3,t2,((C_word*)t0)[5]);}

/* k10280 in k10277 in k10274 in k10271 in k10268 in k10265 in k10262 in k10259 in k10256 in k10253 in k10250 in k10247 in k10244 in k10241 in k10238 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10282,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10285,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10306,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1774 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t3,lf[221],lf[222]);}

/* k10304 in k10280 in k10277 in k10274 in k10271 in k10268 in k10265 in k10262 in k10259 in k10256 in k10253 in k10250 in k10247 in k10244 in k10241 in k10238 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1774 pretty-print */
((C_proc3)C_retrieve_symbol_proc(lf[220]))(3,*((C_word*)lf[220]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10285(2,t2,C_SCHEME_UNDEFINED);}}

/* k10283 in k10280 in k10277 in k10274 in k10271 in k10268 in k10265 in k10262 in k10259 in k10256 in k10253 in k10250 in k10247 in k10244 in k10241 in k10238 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10288,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1775 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t2,lf[19],lf[219]);}

/* k10286 in k10283 in k10280 in k10277 in k10274 in k10271 in k10268 in k10265 in k10262 in k10259 in k10256 in k10253 in k10250 in k10247 in k10244 in k10241 in k10238 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10291,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1776 extend-call-sites! */
t3=((C_word*)t0)[2];
f_9891(t3,t2,((C_word*)t0)[4]);}

/* k10289 in k10286 in k10283 in k10280 in k10277 in k10274 in k10271 in k10268 in k10265 in k10262 in k10259 in k10256 in k10253 in k10250 in k10247 in k10244 in k10241 in k10238 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10294,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1777 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t2,lf[19],lf[218]);}

/* k10292 in k10289 in k10286 in k10283 in k10280 in k10277 in k10274 in k10271 in k10268 in k10265 in k10262 in k10259 in k10256 in k10253 in k10250 in k10247 in k10244 in k10241 in k10238 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10297,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1778 remove-local-bindings! */
t3=((C_word*)t0)[2];
f_10024(t3,t2,((C_word*)t0)[4]);}

/* k10295 in k10292 in k10289 in k10286 in k10283 in k10280 in k10277 in k10274 in k10271 in k10268 in k10265 in k10262 in k10259 in k10256 in k10253 in k10250 in k10247 in k10244 in k10241 in k10238 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10300,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1779 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t2,lf[19],lf[217]);}

/* k10298 in k10295 in k10292 in k10289 in k10286 in k10283 in k10280 in k10277 in k10274 in k10271 in k10268 in k10265 in k10262 in k10259 in k10256 in k10253 in k10250 in k10247 in k10244 in k10241 in k10238 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1780 reconstruct! */
t2=((C_word*)t0)[5];
f_9573(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_10024(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10024,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10030,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_10030(t6,t1,((C_word*)t0)[2]);}

/* walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_10030(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10030,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_eqp(t4,lf[10]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10049,a[2]=t8,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t11=t2;
t12=(C_word)C_slot(t11,C_fix(3));
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10135,a[2]=((C_word*)t0)[2],a[3]=t14,tmp=(C_word)a,a+=4,tmp));
t16=((C_word*)t14)[1];
f_10135(t16,t10,t12);}
else{
t10=(C_word)C_eqp(t4,lf[15]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10165,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t12=t2;
t13=(C_word)C_slot(t12,C_fix(3));
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10190,a[2]=((C_word*)t0)[2],a[3]=t15,tmp=(C_word)a,a+=4,tmp));
t17=((C_word*)t15)[1];
f_10190(t17,t11,t13);}
else{
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10216,a[2]=((C_word*)t0)[2],a[3]=t12,tmp=(C_word)a,a+=4,tmp));
t14=((C_word*)t12)[1];
f_10216(t14,t1,t8);}}}

/* loop2632 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_10216(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10216,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10226,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* walk2571 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_10030(t5,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k10224 in loop2632 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10216(t3,((C_word*)t0)[2],t2);}

/* loop2617 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_10190(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10190,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10200,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* walk2571 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_10030(t5,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k10198 in loop2617 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10190(t3,((C_word*)t0)[2],t2);}

/* k10163 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10165,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_assq(t2,((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10174,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1754 node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[185]))(4,*((C_word*)lf[185]+1),t3,((C_word*)t0)[2],lf[69]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k10172 in k10163 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10174,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10177,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1755 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k10175 in k10172 in k10163 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1756 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* loop2586 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_10135(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10135,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10145,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* walk2571 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_10030(t5,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k10143 in loop2586 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10135(t3,((C_word*)t0)[2],t2);}

/* k10047 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10049,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10054,a[2]=((C_word*)t0)[5],a[3]=t7,a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_10054(t9,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* doloop2596 in k10047 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_10054(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10054,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[6])[1]))){
t4=(C_word)C_i_car(t3);
/* optimizer.scm: 1744 copy-node! */
((C_proc4)C_retrieve_symbol_proc(lf[180]))(4,*((C_word*)lf[180]+1),t1,t4,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10077,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10092,a[2]=((C_word*)t0)[5],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1746 reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[114]+1)))(3,*((C_word*)lf[114]+1),t5,((C_word*)((C_word*)t0)[6])[1]);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10095,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_assq(t5,((C_word*)t0)[2]))){
t6=t4;
f_10095(t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)((C_word*)t0)[6])[1]);
t8=C_mutate(((C_word *)((C_word*)t0)[6])+1,t7);
t9=(C_word)C_i_car(t3);
t10=(C_word)C_a_i_cons(&a,2,t9,((C_word*)((C_word*)t0)[4])[1]);
t11=C_mutate(((C_word *)((C_word*)t0)[4])+1,t10);
t12=t4;
f_10095(t12,t11);}}}

/* k10093 in doloop2596 in k10047 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_10095(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_10054(t4,((C_word*)t0)[2],t2,t3);}

/* k10090 in doloop2596 in k10047 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1746 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10075 in doloop2596 in k10047 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10077,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10084,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10088,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1747 reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[114]+1)))(3,*((C_word*)lf[114]+1),t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k10086 in k10075 in doloop2596 in k10047 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1747 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k10082 in k10075 in doloop2596 in k10047 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1747 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* extend-call-sites! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_9891(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9891,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9897,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_9897(t6,t1,((C_word*)t0)[2]);}

/* walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_9897(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9897,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_eqp(t4,lf[14]);
if(C_truep(t9)){
t10=(C_word)C_i_car(t8);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9919,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_slot(t10,C_fix(1));
t13=(C_word)C_eqp(lf[8],t12);
if(C_truep(t13)){
t14=(C_word)C_slot(t10,C_fix(2));
t15=(C_word)C_i_car(t14);
t16=(C_word)C_i_assq(t15,((C_word*)t0)[2]);
if(C_truep(t16)){
t17=(C_word)C_i_set_car(t6,C_SCHEME_TRUE);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9972,a[2]=t2,a[3]=t11,a[4]=t10,tmp=(C_word)a,a+=5,tmp);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9976,a[2]=t18,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t20=(C_word)C_i_cdr(t16);
/* map */
t21=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t21+1)))(4,t21,t19,C_retrieve(lf[47]),t20);}
else{
t17=t11;
f_9919(2,t17,C_SCHEME_UNDEFINED);}}
else{
t14=t11;
f_9919(2,t14,C_SCHEME_UNDEFINED);}}
else{
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10001,a[2]=((C_word*)t0)[3],a[3]=t11,tmp=(C_word)a,a+=4,tmp));
t13=((C_word*)t11)[1];
f_10001(t13,t1,t8);}}

/* loop2562 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_10001(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10001,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10011,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* walk2527 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_9897(t5,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k10009 in loop2562 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_10011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10001(t3,((C_word*)t0)[2],t2);}

/* k9974 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1726 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[2],t1,t2);}

/* k9970 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9972,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* optimizer.scm: 1724 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9917 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9919,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(C_word)C_slot(t2,C_fix(3));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9928,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_9928(t7,((C_word*)t0)[2],t3);}

/* loop2551 in k9917 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_9928(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9928,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9938,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* walk2527 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_9897(t5,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9936 in loop2551 in k9917 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9928(t3,((C_word*)t0)[2],t2);}

/* reconstruct! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_9573(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9573,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9585,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9587,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=((C_word*)t0)[3];
t7=(C_word)C_slot(t6,C_fix(3));
t8=(C_word)C_i_car(t7);
/* optimizer.scm: 1660 fold-right */
((C_proc5)C_retrieve_symbol_proc(lf[125]))(5,*((C_word*)lf[125]+1),t4,t5,t8,t2);}

/* a9586 in reconstruct! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9587(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9587,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9594,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1663 get */
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),t5,((C_word*)t0)[2],t4,lf[45]);}

/* k9592 in a9586 in reconstruct! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9594,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9597,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1664 hide-variable */
((C_proc3)C_retrieve_symbol_proc(lf[216]))(3,*((C_word*)lf[216]+1),t2,((C_word*)t0)[5]);}

/* k9595 in k9592 in a9586 in reconstruct! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9597,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9606,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1665 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[60]))(4,*((C_word*)lf[60]+1),((C_word*)t0)[2],t3,t4);}

/* a9605 in k9595 in k9592 in a9586 in reconstruct! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9606(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9606,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t6=(C_word)C_i_cdr(t5);
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9613,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=t6,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
/* map */
t8=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_retrieve(lf[83]),t6);}

/* k9611 in a9605 in k9595 in k9592 in a9586 in reconstruct! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9613,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9616,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1670 map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[134]+1)))(5,*((C_word*)lf[134]+1),t2,*((C_word*)lf[135]+1),((C_word*)t0)[5],t1);}

/* k9614 in k9611 in a9605 in k9595 in k9592 in a9586 in reconstruct! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9619,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_slot(((C_word*)t0)[9],C_fix(3));
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9697,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9712,a[2]=t5,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_9712(t9,t2,t4);}

/* walk in k9614 in k9611 in a9605 in k9595 in k9592 in a9586 in reconstruct! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_9712(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9712,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_eqp(t4,lf[10]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9731,a[2]=t8,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9761,a[2]=t2,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
/* map */
t12=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,((C_word*)t0)[2],t6);}
else{
t10=(C_word)C_eqp(t4,lf[8]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9778,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_i_car(t6);
/* optimizer.scm: 1699 rename */
t13=((C_word*)t0)[2];
f_9697(3,t13,t11,t12);}
else{
t11=(C_word)C_eqp(t4,lf[15]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9791,a[2]=t8,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9825,a[2]=t2,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
t14=(C_word)C_i_car(t6);
/* optimizer.scm: 1701 rename */
t15=((C_word*)t0)[2];
f_9697(3,t15,t13,t14);}
else{
t12=(C_word)C_eqp(t4,lf[12]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t6);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9844,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t8,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1704 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[60]))(4,*((C_word*)lf[60]+1),t1,t13,t14);}
else{
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9868,a[2]=((C_word*)t0)[3],a[3]=t14,tmp=(C_word)a,a+=4,tmp));
t16=((C_word*)t14)[1];
f_9868(t16,t1,t8);}}}}}

/* loop2517 in walk in k9614 in k9611 in a9605 in k9595 in k9592 in a9586 in reconstruct! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_9868(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9868,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9878,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* walk2478 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_9712(t5,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9876 in loop2517 in walk in k9614 in k9611 in a9605 in k9595 in k9592 in a9586 in reconstruct! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9868(t3,((C_word*)t0)[2],t2);}

/* a9843 in walk in k9614 in k9611 in a9605 in k9595 in k9592 in a9586 in reconstruct! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9844(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9844,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9859,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9863,a[2]=t4,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* map */
t7=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[2],t2);}

/* k9861 in a9843 in walk in k9614 in k9611 in a9605 in k9595 in k9592 in a9586 in reconstruct! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1707 build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[56]))(5,*((C_word*)lf[56]+1),((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9857 in a9843 in walk in k9614 in k9611 in a9605 in k9595 in k9592 in a9586 in reconstruct! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_car(((C_word*)t0)[5],t1);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* optimizer.scm: 1708 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_9712(t4,((C_word*)t0)[2],t3);}

/* k9823 in walk in k9614 in k9611 in a9605 in k9595 in k9592 in a9586 in reconstruct! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9825,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1701 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9789 in walk in k9614 in k9611 in a9605 in k9595 in k9592 in a9586 in reconstruct! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9791,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9796,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_9796(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2503 in k9789 in walk in k9614 in k9611 in a9605 in k9595 in k9592 in a9586 in reconstruct! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_9796(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9796,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9806,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* walk2478 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_9712(t5,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9804 in loop2503 in k9789 in walk in k9614 in k9611 in a9605 in k9595 in k9592 in a9586 in reconstruct! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9796(t3,((C_word*)t0)[2],t2);}

/* k9776 in walk in k9614 in k9611 in a9605 in k9595 in k9592 in a9586 in reconstruct! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9778,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1699 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9759 in walk in k9614 in k9611 in a9605 in k9595 in k9592 in a9586 in reconstruct! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1696 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9729 in walk in k9614 in k9611 in a9605 in k9595 in k9592 in a9586 in reconstruct! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9731,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9736,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_9736(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2493 in k9729 in walk in k9614 in k9611 in a9605 in k9595 in k9592 in a9586 in reconstruct! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_9736(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9736,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9746,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* walk2478 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_9712(t5,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9744 in loop2493 in k9729 in walk in k9614 in k9611 in a9605 in k9595 in k9592 in a9586 in reconstruct! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9736(t3,((C_word*)t0)[2],t2);}

/* rename in k9614 in k9611 in a9605 in k9595 in k9592 in a9586 in reconstruct! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9697(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9697,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_i_cdr(t3):t2));}

/* k9617 in k9614 in k9611 in a9605 in k9595 in k9592 in a9586 in reconstruct! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9668,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1673 gensym */
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t2,lf[84]);}

/* k9666 in k9617 in k9614 in k9611 in a9605 in k9595 in k9592 in a9586 in reconstruct! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9668,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9652,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t3,a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9656,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1679 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9654 in k9666 in k9617 in k9614 in k9611 in a9605 in k9595 in k9592 in a9586 in reconstruct! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],t2);
/* optimizer.scm: 1679 build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[56]))(5,*((C_word*)lf[56]+1),((C_word*)t0)[3],t1,t3,((C_word*)t0)[2]);}

/* k9650 in k9666 in k9617 in k9614 in k9611 in a9605 in k9595 in k9592 in a9586 in reconstruct! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9652,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
t4=(C_word)C_a_i_record(&a,4,lf[35],lf[12],t2,t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_record(&a,4,lf[35],lf[15],((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_list(&a,2,t6,((C_word*)t0)[4]);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_record(&a,4,lf[35],lf[10],((C_word*)t0)[2],t7));}

/* k9583 in reconstruct! in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9585,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1657 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* compute-extra-variables in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_9287(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9287,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9398,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9559,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* a9558 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9559(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9559,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,t3,t4));}

/* k9396 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9398,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9400,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9491,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9536,a[2]=t5,a[3]=t9,tmp=(C_word)a,a+=4,tmp));
t11=((C_word*)t9)[1];
f_9536(t11,t7,((C_word*)t0)[4]);}

/* loop2397 in k9396 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_9536(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9536,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9546,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* walk2400 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_9400(t5,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9544 in loop2397 in k9396 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9536(t3,((C_word*)t0)[2],t2);}

/* k9489 in k9396 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9491,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9496,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a9495 in k9489 in k9396 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9496(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9496,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9534,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1646 get */
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),t4,((C_word*)t0)[2],t3,lf[45]);}

/* k9532 in a9495 in k9489 in k9396 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9534,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9294,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9296,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_9296(t8,t4,t1);}

/* walk in k9532 in a9495 in k9489 in k9396 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_9296(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9296,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_eqp(t4,lf[10]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9316,a[2]=t8,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1622 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t10,t6,((C_word*)((C_word*)t0)[3])[1]);}
else{
t10=(C_word)C_eqp(t4,lf[12]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t6);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9357,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1625 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[60]))(4,*((C_word*)lf[60]+1),t1,t11,t12);}
else{
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9374,a[2]=((C_word*)t0)[2],a[3]=t12,tmp=(C_word)a,a+=4,tmp));
t14=((C_word*)t12)[1];
f_9374(t14,t1,t8);}}}

/* loop2383 in walk in k9532 in a9495 in k9489 in k9396 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_9374(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9374,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9384,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* walk2354 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_9296(t5,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9382 in loop2383 in walk in k9532 in a9495 in k9489 in k9396 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9374(t3,((C_word*)t0)[2],t2);}

/* a9356 in walk in k9532 in a9495 in k9489 in k9396 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9357(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9357,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9362,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1628 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t5,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k9360 in a9356 in walk in k9532 in a9495 in k9489 in k9396 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* optimizer.scm: 1629 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_9296(t4,((C_word*)t0)[2],t3);}

/* k9314 in walk in k9532 in a9495 in k9489 in k9396 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9316,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9321,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_9321(t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2369 in k9314 in walk in k9532 in a9495 in k9489 in k9396 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_9321(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9321,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9331,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* walk2354 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_9296(t5,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9329 in loop2369 in k9314 in walk in k9532 in a9495 in k9489 in k9396 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9321(t3,((C_word*)t0)[2],t2);}

/* k9292 in k9532 in a9495 in k9489 in k9396 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9294,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9510,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9512,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9526,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* optimizer.scm: 1652 delete-duplicates */
((C_proc4)C_retrieve_symbol_proc(lf[211]))(4,*((C_word*)lf[211]+1),t5,t6,*((C_word*)lf[34]+1));}

/* k9524 in k9292 in k9532 in a9495 in k9489 in k9396 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1648 remove */
((C_proc4)C_retrieve_symbol_proc(lf[170]))(4,*((C_word*)lf[170]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a9511 in k9292 in k9532 in a9495 in k9489 in k9396 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9512(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9512,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_i_memq(t2,((C_word*)t0)[2])));}

/* k9508 in k9292 in k9532 in a9495 in k9489 in k9396 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9510,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* walk in k9396 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_9400(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9400,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9482,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9484,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1637 count */
((C_proc4)C_retrieve_symbol_proc(lf[215]))(4,*((C_word*)lf[215]+1),t4,t5,((C_word*)((C_word*)t0)[5])[1]);}

/* a9483 in walk in k9396 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9484(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9484,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(((C_word*)t0)[2],t2));}

/* k9480 in walk in k9396 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9482,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greaterp(t1,C_fix(1)))){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9420,a[2]=t4,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9454,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_9454(t9,t5,t4);}}

/* loop2415 in k9480 in walk in k9396 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_9454(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9454,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9467,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_assq(t3,((C_word*)t0)[3]);
/* optimizer.scm: 1640 walk */
t6=((C_word*)((C_word*)t0)[2])[1];
f_9400(t6,t4,t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9465 in loop2415 in k9480 in walk in k9396 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9454(t3,((C_word*)t0)[2],t2);}

/* k9418 in k9480 in walk in k9396 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9420,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9430,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9438,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9442,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9444,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* map */
t8=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[2]);}

/* a9443 in k9418 in k9480 in walk in k9396 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9444(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9444,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k9440 in k9418 in k9480 in walk in k9396 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1642 concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[214]))(3,*((C_word*)lf[214]+1),((C_word*)t0)[2],t1);}

/* k9436 in k9418 in k9480 in walk in k9396 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1642 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9428 in k9418 in k9480 in walk in k9396 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_cdr(((C_word*)t0)[2],t1));}

/* eliminate4 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_9013(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9013,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9017,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9019,a[2]=t3,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_9019(t8,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_9019(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9019,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(t5,lf[8]);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9038,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=t3,a[5]=t7,a[6]=((C_word*)t0)[3],a[7]=t5,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t10)){
t12=t11;
f_9038(t12,t10);}
else{
t12=(C_word)C_eqp(t5,lf[25]);
if(C_truep(t12)){
t13=t11;
f_9038(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[69]);
if(C_truep(t13)){
t14=t11;
f_9038(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[212]);
t15=t11;
f_9038(t15,(C_truep(t14)?t14:(C_word)C_eqp(t5,lf[160])));}}}}

/* k9036 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_9038(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9038,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[10]);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9049,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_9049(t6,((C_word*)t0)[8],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[12]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9100,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1587 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[60]))(4,*((C_word*)lf[60]+1),((C_word*)t0)[8],t4,t5);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[7],lf[14]);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9124,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9151,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1593 call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[18]+1)))(3,*((C_word*)lf[18]+1),t6,t7);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9244,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_9244(t8,((C_word*)t0)[8],((C_word*)t0)[3]);}}}}}

/* loop2340 in k9036 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_9244(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9244,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9257,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1608 walk */
t5=((C_word*)((C_word*)t0)[3])[1];
f_9019(t5,t4,t3,((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9255 in loop2340 in k9036 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9244(t3,((C_word*)t0)[2],t2);}

/* a9150 in k9036 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9151(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9151,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_eqp(lf[8],t3);
if(C_truep(t4)){
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(C_word)C_slot(((C_word*)t0)[4],C_fix(2));
t8=(C_word)C_i_car(t7);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9167,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t10,a[5]=((C_word*)t0)[3],a[6]=t6,tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_9167(t12,t1,t8);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* loop in a9150 in k9036 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_9167(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9167,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[6])[1]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[6])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[5])[1]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9187,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9220,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cadr(t5);
/* optimizer.scm: 1602 lset<= */
((C_proc5)C_retrieve_symbol_proc(lf[128]))(5,*((C_word*)lf[128]+1),t7,*((C_word*)lf[34]+1),t8,((C_word*)t0)[2]);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}}

/* k9218 in loop in a9150 in k9036 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9220,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_9187(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9224,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1604 delete! */
((C_proc5)C_retrieve_symbol_proc(lf[213]))(5,*((C_word*)lf[213]+1),t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1],*((C_word*)lf[34]+1));}}

/* k9222 in k9218 in loop in a9150 in k9036 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* optimizer.scm: 1605 return */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k9185 in loop in a9150 in k9036 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9187,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9196,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_9196(t6,((C_word*)t0)[2],t2);}

/* loop2316 in k9185 in loop in a9150 in k9036 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_9196(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9196,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9206,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* loop2304 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_9167(t5,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9204 in loop2316 in k9185 in loop in a9150 in k9036 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9196(t3,((C_word*)t0)[2],t2);}

/* k9122 in k9036 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9124,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9129,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_9129(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2329 in k9122 in k9036 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_9129(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9129,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9142,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1607 walk */
t5=((C_word*)((C_word*)t0)[3])[1];
f_9019(t5,t4,t3,((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9140 in loop2329 in k9122 in k9036 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9129(t3,((C_word*)t0)[2],t2);}

/* a9099 in k9036 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9100(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9100,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9112,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1590 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t6,t2,((C_word*)t0)[2]);}

/* k9110 in a9099 in k9036 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1590 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9019(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k9036 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_9049(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9049,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9067,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1582 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9070,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* optimizer.scm: 1584 walk */
t6=((C_word*)((C_word*)t0)[5])[1];
f_9019(t6,t4,t5,((C_word*)t0)[3]);}}

/* k9068 in loop in k9036 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1585 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_9049(t4,((C_word*)t0)[2],t2,t3);}

/* k9065 in loop in k9036 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1582 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9019(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9015 in eliminate4 in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_9017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* collect-accessibles in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_8753(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8753,NULL,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8757,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8759,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_8759(t9,t5,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_8759(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8759,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(t5,lf[8]);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8778,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t9,a[7]=t3,a[8]=t7,a[9]=((C_word*)t0)[5],a[10]=t5,a[11]=t1,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t10)){
t12=t11;
f_8778(t12,t10);}
else{
t12=(C_word)C_eqp(t5,lf[25]);
if(C_truep(t12)){
t13=t11;
f_8778(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[69]);
if(C_truep(t13)){
t14=t11;
f_8778(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[212]);
t15=t11;
f_8778(t15,(C_truep(t14)?t14:(C_word)C_eqp(t5,lf[160])));}}}}

/* k8776 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_8778(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8778,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[10],lf[10]);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8789,a[2]=t4,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_8789(t6,((C_word*)t0)[11],((C_word*)t0)[8],((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[10],lf[12]);
if(C_truep(t3)){
t4=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8837,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t4)){
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_assq(t6,((C_word*)t0)[3]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8871,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(t4);
/* optimizer.scm: 1539 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t7,t8,((C_word*)t0)[7],((C_word*)((C_word*)t0)[2])[1]);}
else{
t7=t5;
f_8837(t7,C_SCHEME_UNDEFINED);}}
else{
t6=t5;
f_8837(t6,C_SCHEME_UNDEFINED);}}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8880,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_8880(t7,((C_word*)t0)[11],((C_word*)t0)[6]);}}}}

/* loop2226 in k8776 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_8880(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8880,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8893,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1545 walk */
t5=((C_word*)((C_word*)t0)[3])[1];
f_8759(t5,t4,t3,((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k8891 in loop2226 in k8776 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8880(t3,((C_word*)t0)[2],t2);}

/* k8869 in k8776 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_8837(t3,t2);}

/* k8835 in k8776 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_8837(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8837,NULL,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8846,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1540 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[60]))(4,*((C_word*)lf[60]+1),((C_word*)t0)[2],t2,t3);}

/* a8845 in k8835 in k8776 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8846,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8858,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1543 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t6,t2,((C_word*)t0)[2]);}

/* k8856 in a8845 in k8835 in k8776 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1543 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8759(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k8776 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_8789(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8789,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8807,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1530 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8810,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* optimizer.scm: 1532 walk */
t6=((C_word*)((C_word*)t0)[5])[1];
f_8759(t6,t4,t5,((C_word*)t0)[3]);}}

/* k8808 in loop in k8776 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1533 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_8789(t4,((C_word*)t0)[2],t2,t3);}

/* k8805 in loop in k8776 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1530 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8759(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8755 in collect-accessibles in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* eliminate in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_8654(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8654,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8660,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1500 remove */
((C_proc4)C_retrieve_symbol_proc(lf[170]))(4,*((C_word*)lf[170]+1),t1,t4,t3);}

/* a8659 in eliminate in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8660(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8660,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8694,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(t2);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8704,a[2]=t4,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1510 unzip1 */
((C_proc3)C_retrieve_symbol_proc(lf[198]))(3,*((C_word*)lf[198]+1),t6,t5);}

/* k8702 in a8659 in eliminate in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8704,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8709,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_8709(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* count in k8702 in a8659 in eliminate in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_8709(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8709,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8716,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_cddr(t4);
/* optimizer.scm: 1513 lset-difference */
((C_proc6)C_retrieve_symbol_proc(lf[184]))(6,*((C_word*)lf[184]+1),t5,*((C_word*)lf[34]+1),t6,t3,((C_word*)t0)[2]);}

/* k8714 in count in k8702 in a8659 in eliminate in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8716,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8743,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 1514 delete-duplicates */
((C_proc4)C_retrieve_symbol_proc(lf[211]))(4,*((C_word*)lf[211]+1),t2,t3,*((C_word*)lf[34]+1));}

/* k8741 in k8714 in count in k8702 in a8659 in eliminate in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8743,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8739,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1515 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8737 in k8741 in k8714 in count in k8702 in a8659 in eliminate in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8739,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8729,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8731,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a8730 in k8737 in k8741 in k8714 in count in k8702 in a8659 in eliminate in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8731(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8731,3,t0,t1,t2);}
/* optimizer.scm: 1516 count */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8709(t3,t1,t2,((C_word*)t0)[2]);}

/* k8727 in k8737 in k8741 in k8714 in count in k8702 in a8659 in eliminate in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1516 fold */
((C_proc5)C_retrieve_symbol_proc(lf[126]))(5,*((C_word*)lf[126]+1),((C_word*)t0)[3],*((C_word*)lf[210]+1),((C_word*)t0)[2],t1);}

/* k8692 in a8659 in eliminate in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8694,2,t0,t1);}
t2=(C_word)C_fixnum_greaterp(t1,C_fix(16));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8672,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 1503 any */
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),((C_word*)t0)[5],t3,t4);}}

/* a8671 in k8692 in a8659 in eliminate in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8672(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8672,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8679,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1504 get */
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),t3,((C_word*)t0)[2],t2,lf[74]);}

/* k8677 in a8671 in k8692 in a8659 in eliminate in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* build-call-graph in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_8409(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8409,NULL,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8412,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t8,a[5]=t2,a[6]=t10,tmp=(C_word)a,a+=7,tmp));
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8593,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8595,a[2]=t10,a[3]=t14,a[4]=t4,a[5]=t8,a[6]=t6,tmp=(C_word)a,a+=7,tmp));
t16=((C_word*)t14)[1];
f_8595(t16,t12,t2);}

/* loop2067 in build-call-graph in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_8595(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8595,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_i_car(t3);
t5=(C_word)C_i_cdr(t3);
t6=(C_word)C_slot(t5,C_fix(2));
t7=(C_word)C_i_car(t6);
t8=C_set_block_item(((C_word*)t0)[6],0,C_SCHEME_END_OF_LIST);
t9=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_END_OF_LIST);
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8619,a[2]=t4,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t2,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8636,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1489 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[60]))(4,*((C_word*)lf[60]+1),t10,t7,t11);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a8635 in loop2067 in build-call-graph in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8636(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8636,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(3));
t6=(C_word)C_i_car(t5);
/* optimizer.scm: 1492 walk */
t7=((C_word*)((C_word*)t0)[2])[1];
f_8412(t7,t1,t6,t2);}

/* k8617 in loop2067 in build-call-graph in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8623,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
/* optimizer.scm: 1493 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t2,((C_word*)t0)[2],t3,((C_word*)((C_word*)t0)[8])[1]);}

/* k8621 in k8617 in loop2067 in build-call-graph in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_8595(t4,((C_word*)t0)[2],t3);}

/* k8591 in build-call-graph in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_8412(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8412,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(t5,lf[8]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t5,lf[15]));
if(C_truep(t11)){
t12=(C_word)C_i_car(t7);
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8437,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t12,a[5]=t9,a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t14=(C_word)C_i_memq(t12,t3);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8478,a[2]=((C_word*)t0)[3],a[3]=t12,a[4]=t13,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t14)){
t16=t15;
f_8478(2,t16,t14);}
else{
/* optimizer.scm: 1465 get */
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),t15,((C_word*)t0)[2],t12,lf[101]);}}
else{
t12=(C_word)C_eqp(t5,lf[10]);
if(C_truep(t12)){
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8496,a[2]=t14,a[3]=t3,a[4]=t7,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_8496(t16,t1,t7,t9);}
else{
t13=(C_word)C_eqp(t5,lf[12]);
if(C_truep(t13)){
t14=(C_word)C_i_car(t7);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8550,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1477 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[60]))(4,*((C_word*)lf[60]+1),t1,t14,t15);}
else{
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8567,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t15,tmp=(C_word)a,a+=5,tmp));
t17=((C_word*)t15)[1];
f_8567(t17,t1,t9);}}}}

/* loop2122 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_8567(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8567,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8580,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1480 walk */
t5=((C_word*)((C_word*)t0)[3])[1];
f_8412(t5,t4,t3,((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k8578 in loop2122 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8567(t3,((C_word*)t0)[2],t2);}

/* a8549 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8550(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8550,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8562,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1479 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t6,t2,((C_word*)t0)[2]);}

/* k8560 in a8549 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1479 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8412(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_8496(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8496,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8514,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1472 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8520,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t3);
/* optimizer.scm: 1474 walk */
t7=((C_word*)((C_word*)t0)[5])[1];
f_8412(t7,t5,t6,((C_word*)t0)[3]);}}

/* k8518 in loop in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1475 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_8496(t4,((C_word*)t0)[2],t2,t3);}

/* k8512 in loop in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1472 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8412(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8476 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8478,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8437(t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=((C_word*)t0)[4];
f_8437(t4,t3);}}

/* k8435 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_8437(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8437,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8440,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[3]))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_8440(t5,t4);}
else{
t3=t2;
f_8440(t3,C_SCHEME_UNDEFINED);}}

/* k8438 in k8435 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_8440(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8440,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8445,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_8445(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2101 in k8438 in k8435 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_8445(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8445,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8458,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1468 walk */
t5=((C_word*)((C_word*)t0)[3])[1];
f_8412(t5,t4,t3,((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k8456 in loop2101 in k8438 in k8435 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8445(t3,((C_word*)t0)[2],t2);}

/* find-lifting-candidates in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_8309(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8309,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8313,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8315,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1436 ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[209]))(4,*((C_word*)lf[209]+1),t4,t5,((C_word*)t0)[2]);}

/* a8314 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8315(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8315,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(lf[45],t3);
if(C_truep(t4)){
t5=(C_word)C_i_assq(lf[75],t3);
if(C_truep(t5)){
t6=(C_word)C_i_assq(lf[119],t3);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t5);
t8=(C_word)C_i_length(t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8346,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_assq(lf[76],t3))){
t10=t9;
f_8346(t10,C_SCHEME_FALSE);}
else{
t10=(C_word)C_i_cdr(t4);
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(lf[12],t11);
if(C_truep(t12)){
if(C_truep((C_word)C_i_assq(lf[101],t3))){
t13=t9;
f_8346(t13,C_SCHEME_FALSE);}
else{
t13=(C_word)C_i_cdr(t6);
t14=(C_word)C_i_length(t13);
t15=t9;
f_8346(t15,(C_word)C_eqp(t8,t14));}}
else{
t13=t9;
f_8346(t13,C_SCHEME_FALSE);}}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k8344 in a8314 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_8346(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8346,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8350,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1447 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t2,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[6])[1]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k8348 in k8344 in a8314 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8350,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8354,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1448 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t3,((C_word*)t0)[2],t4,((C_word*)((C_word*)t0)[5])[1]);}

/* k8352 in k8348 in k8344 in a8314 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8311 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7114(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[35],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7114,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_fix(0);
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7714,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7295,a[2]=t7,a[3]=t9,a[4]=t3,a[5]=t11,tmp=(C_word)a,a+=6,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7117,a[2]=t3,a[3]=t13,a[4]=t15,a[5]=t11,a[6]=t9,a[7]=t7,a[8]=t12,tmp=(C_word)a,a+=9,tmp));
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8301,a[2]=t2,a[3]=t15,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1415 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t17,lf[19],lf[207]);}

/* k8299 in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8304,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1416 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7117(t3,t2,C_SCHEME_FALSE,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k8302 in k8299 in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* walk in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_7117(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word *a;
loop:
a=C_alloc(22);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7117,NULL,5,t0,t1,t2,t3,t4);}
t5=t3;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t3;
t8=(C_word)C_slot(t7,C_fix(3));
t9=t3;
t10=(C_word)C_slot(t9,C_fix(1));
t11=(C_word)C_eqp(t10,lf[53]);
if(C_truep(t11)){
t12=(C_word)C_i_caddr(t6);
t13=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7142,a[2]=((C_word*)t0)[4],a[3]=t8,a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=t3,a[10]=t1,a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t2)){
if(C_truep((C_word)C_i_cadr(t6))){
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7227,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t8,a[7]=t3,a[8]=t12,a[9]=t13,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 1207 get */
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),t14,((C_word*)t0)[2],t2,lf[76]);}
else{
t14=t13;
f_7142(2,t14,C_SCHEME_FALSE);}}
else{
t14=t13;
f_7142(2,t14,C_SCHEME_FALSE);}}
else{
t12=(C_word)C_eqp(t10,lf[15]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t6);
t14=(C_word)C_i_car(t8);
/* optimizer.scm: 1217 walk */
t26=t1;
t27=t13;
t28=t14;
t29=C_SCHEME_FALSE;
t1=t26;
t2=t27;
t3=t28;
t4=t29;
goto loop;}
else{
t13=(C_word)C_eqp(t10,lf[10]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7253,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t15=(C_word)C_i_car(t6);
t16=(C_word)C_i_car(t8);
/* optimizer.scm: 1219 walk */
t26=t14;
t27=t15;
t28=t16;
t29=t3;
t1=t26;
t2=t27;
t3=t28;
t4=t29;
goto loop;}
else{
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7273,a[2]=((C_word*)t0)[4],a[3]=t15,tmp=(C_word)a,a+=4,tmp));
t17=((C_word*)t15)[1];
f_7273(t17,t1,t8);}}}}

/* loop1707 in walk in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_7273(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7273,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7286,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1221 walk */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7117(t5,t4,C_SCHEME_FALSE,t3,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k7284 in loop1707 in walk in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7273(t3,((C_word*)t0)[2],t2);}

/* k7251 in walk in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* optimizer.scm: 1220 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7117(t3,((C_word*)t0)[2],C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}

/* k7225 in walk in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7227,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
f_7142(2,t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[8]))){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7173,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 1209 get */
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),t2,((C_word*)t0)[2],((C_word*)t0)[5],lf[45]);}
else{
t2=((C_word*)t0)[9];
f_7142(2,t2,C_SCHEME_FALSE);}}}

/* k7171 in k7225 in walk in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7173,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7179,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1210 get-list */
((C_proc5)C_retrieve_symbol_proc(lf[117]))(5,*((C_word*)lf[117]+1),t2,((C_word*)t0)[2],((C_word*)t0)[6],lf[75]);}
else{
t2=((C_word*)t0)[4];
f_7142(2,t2,C_SCHEME_FALSE);}}

/* k7177 in k7171 in k7225 in walk in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7179,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7185,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1211 get-list */
((C_proc5)C_retrieve_symbol_proc(lf[117]))(5,*((C_word*)lf[117]+1),t2,((C_word*)t0)[2],((C_word*)t0)[6],lf[119]);}
else{
t2=((C_word*)t0)[4];
f_7142(2,t2,C_SCHEME_FALSE);}}

/* k7183 in k7177 in k7171 in k7225 in walk in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7185,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[10],((C_word*)t0)[9]);
if(C_truep(t2)){
t3=(C_word)C_i_length(((C_word*)t0)[8]);
t4=(C_word)C_i_length(t1);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[7]);
t7=(C_word)C_i_car(((C_word*)t0)[6]);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
/* optimizer.scm: 1214 scan */
t9=((C_word*)t0)[4];
f_7295(t9,((C_word*)t0)[3],t6,t7,((C_word*)t0)[5],((C_word*)t0)[2],t8);}
else{
t6=((C_word*)t0)[3];
f_7142(2,t6,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[3];
f_7142(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_7142(2,t2,C_SCHEME_FALSE);}}

/* k7140 in walk in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1215 transform */
t2=((C_word*)t0)[11];
f_7714(t2,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 1216 walk */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7117(t3,((C_word*)t0)[10],C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}}

/* scan in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_7295(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7295,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7298,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=t5,a[7]=t12,a[8]=t8,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=t10,a[12]=t6,tmp=(C_word)a,a+=13,tmp));
t14=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_END_OF_LIST);
t15=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_END_OF_LIST);
t16=C_set_block_item(((C_word*)t0)[5],0,C_fix(0));
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7705,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t8,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1300 rec */
t18=((C_word*)t12)[1];
f_7298(t18,t17,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,t6);}

/* k7703 in scan in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7705,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7712,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1301 delete */
((C_proc5)C_retrieve_symbol_proc(lf[206]))(5,*((C_word*)lf[206]+1),t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[34]+1));}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7710 in k7703 in scan in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1301 lset= */
((C_proc5)C_retrieve_symbol_proc(lf[205]))(5,*((C_word*)lf[205]+1),((C_word*)t0)[3],*((C_word*)lf[34]+1),((C_word*)((C_word*)t0)[2])[1],t1);}

/* rec in scan in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_7298(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word *a;
loop:
a=C_alloc(13);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7298,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(3));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(t11,lf[8]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t7);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7347,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=t13,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1232 get */
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),t14,((C_word*)t0)[9],t13,lf[201]);}
else{
t13=(C_word)C_eqp(t11,lf[53]);
if(C_truep(t13)){
if(C_truep(t3)){
t14=(C_word)C_i_caddr(t7);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7365,a[2]=t5,a[3]=((C_word*)t0)[7],a[4]=t9,a[5]=((C_word*)t0)[8],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1240 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[60]))(4,*((C_word*)lf[60]+1),t1,t14,t15);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t14=(C_word)C_eqp(t11,lf[88]);
if(C_truep(t14)){
t15=((C_word*)((C_word*)t0)[11])[1];
if(C_truep(t15)){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}
else{
t16=(C_word)C_i_cadr(t7);
t17=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[10])[1],t16);
t18=C_mutate(((C_word *)((C_word*)t0)[10])+1,t17);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7402,a[2]=t5,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1249 every */
((C_proc4)C_retrieve_symbol_proc(lf[41]))(4,*((C_word*)lf[41]+1),t1,t19,t9);}}
else{
t15=(C_word)C_eqp(t11,lf[193]);
if(C_truep(t15)){
if(C_truep(t4)){
if(C_truep(((C_word*)t0)[6])){
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7436,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t17=(C_word)C_i_car(t9);
/* optimizer.scm: 1252 scan-used-variables */
((C_proc4)C_retrieve_symbol_proc(lf[132]))(4,*((C_word*)lf[132]+1),t16,t17,t5);}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}}
else{
t16=(C_word)C_eqp(t11,lf[202]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7452,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=t9,a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t18=(C_word)C_i_cadr(t7);
/* optimizer.scm: 1257 estimate-foreign-result-size */
((C_proc3)C_retrieve_symbol_proc(lf[203]))(3,*((C_word*)lf[203]+1),t17,t18);}
else{
t17=(C_word)C_eqp(t11,lf[204]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7493,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=t9,a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t19=(C_word)C_i_car(t7);
/* optimizer.scm: 1265 estimate-foreign-result-size */
((C_proc3)C_retrieve_symbol_proc(lf[203]))(3,*((C_word*)lf[203]+1),t18,t19);}
else{
t18=(C_word)C_eqp(t11,lf[14]);
if(C_truep(t18)){
t19=(C_word)C_i_car(t9);
t20=(C_word)C_slot(t19,C_fix(1));
t21=(C_word)C_eqp(lf[8],t20);
if(C_truep(t21)){
t22=(C_word)C_slot(t19,C_fix(2));
t23=(C_word)C_i_car(t22);
t24=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7546,a[2]=t1,a[3]=t9,a[4]=t5,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t25=(C_word)C_eqp(t23,((C_word*)t0)[4]);
if(C_truep(t25)){
t26=(C_word)C_eqp(((C_word*)((C_word*)t0)[10])[1],C_fix(0));
if(C_truep(t26)){
t27=(C_word)C_i_cadr(t9);
t28=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7574,a[2]=t24,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t29=(C_word)C_slot(t27,C_fix(1));
t30=(C_word)C_eqp(lf[8],t29);
if(C_truep(t30)){
t31=(C_word)C_slot(t27,C_fix(2));
t32=(C_word)C_i_car(t31);
t33=(C_word)C_a_i_cons(&a,2,t32,((C_word*)((C_word*)t0)[3])[1]);
t34=C_mutate(((C_word *)((C_word*)t0)[3])+1,t33);
t35=t28;
f_7574(t35,t34);}
else{
t31=t28;
f_7574(t31,C_SCHEME_UNDEFINED);}}
else{
t27=t24;
f_7546(t27,C_SCHEME_FALSE);}}
else{
t26=t24;
f_7546(t26,(C_word)C_eqp(t23,((C_word*)t0)[2]));}}
else{
t22=t1;
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,C_SCHEME_FALSE);}}
else{
t19=(C_word)C_eqp(t11,lf[181]);
if(C_truep(t19)){
t20=(C_word)C_i_cadddr(t7);
t21=(C_word)C_eqp(t20,C_fix(0));
if(C_truep(t21)){
t22=t1;
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,t21);}
else{
t22=((C_word*)((C_word*)t0)[11])[1];
if(C_truep(t22)){
t23=t1;
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,C_SCHEME_FALSE);}
else{
t23=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[10])[1],t20);
t24=C_mutate(((C_word *)((C_word*)t0)[10])+1,t23);
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7635,a[2]=t5,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1291 every */
((C_proc4)C_retrieve_symbol_proc(lf[41]))(4,*((C_word*)lf[41]+1),t1,t25,t9);}}}
else{
t20=(C_word)C_eqp(t11,lf[15]);
if(C_truep(t20)){
t21=(C_word)C_i_car(t9);
t22=(C_word)C_i_car(t7);
/* optimizer.scm: 1292 rec */
t66=t1;
t67=t21;
t68=t22;
t69=C_SCHEME_FALSE;
t70=t5;
t1=t66;
t2=t67;
t3=t68;
t4=t69;
t5=t70;
goto loop;}
else{
t21=(C_word)C_eqp(t11,lf[10]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7668,a[2]=t5,a[3]=t7,a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=t9,tmp=(C_word)a,a+=7,tmp);
t23=(C_word)C_i_car(t9);
t24=(C_word)C_i_car(t7);
/* optimizer.scm: 1294 rec */
t66=t22;
t67=t23;
t68=t24;
t69=t2;
t70=t5;
t1=t66;
t2=t67;
t3=t68;
t4=t69;
t5=t70;
goto loop;}
else{
t22=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7692,a[2]=t5,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1296 every */
((C_proc4)C_retrieve_symbol_proc(lf[41]))(4,*((C_word*)lf[41]+1),t1,t22,t9);}}}}}}}}}}}

/* a7691 in rec in scan in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7692(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7692,3,t0,t1,t2);}
/* optimizer.scm: 1296 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7298(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k7666 in rec in scan in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7668,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7679,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1295 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7677 in k7666 in rec in scan in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1295 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7298(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE,t1);}

/* a7634 in rec in scan in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7635(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7635,3,t0,t1,t2);}
/* optimizer.scm: 1291 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7298(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k7572 in rec in scan in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_7574(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_7546(t3,C_SCHEME_TRUE);}

/* k7544 in rec in scan in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_7546(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7546,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7551,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1284 every */
((C_proc4)C_retrieve_symbol_proc(lf[41]))(4,*((C_word*)lf[41]+1),((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a7550 in k7544 in rec in scan in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7551(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7551,3,t0,t1,t2);}
/* optimizer.scm: 1284 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7298(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k7491 in rec in scan in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7493,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7499,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_7499(t4,t2);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=t3;
f_7499(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t1);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t3;
f_7499(t7,C_SCHEME_TRUE);}}}

/* k7497 in k7491 in rec in scan in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_7499(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7499,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7504,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1271 every */
((C_proc4)C_retrieve_symbol_proc(lf[41]))(4,*((C_word*)lf[41]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a7503 in k7497 in k7491 in rec in scan in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7504(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7504,3,t0,t1,t2);}
/* optimizer.scm: 1271 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7298(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k7450 in rec in scan in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7452,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7458,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_7458(t4,t2);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=t3;
f_7458(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t1);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t3;
f_7458(t7,C_SCHEME_TRUE);}}}

/* k7456 in k7450 in rec in scan in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_7458(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7458,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7463,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1263 every */
((C_proc4)C_retrieve_symbol_proc(lf[41]))(4,*((C_word*)lf[41]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a7462 in k7456 in k7450 in rec in scan in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7463(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7463,3,t0,t1,t2);}
/* optimizer.scm: 1263 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7298(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k7434 in rec in scan in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7436,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7432,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1254 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7430 in k7434 in rec in scan in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* a7401 in rec in scan in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7402(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7402,3,t0,t1,t2);}
/* optimizer.scm: 1249 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7298(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* a7364 in rec in scan in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7365(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7365,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[5])+1,t5);
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7381,a[2]=t7,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1244 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t8,t2,((C_word*)t0)[2]);}

/* k7379 in a7364 in rec in scan in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1244 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7298(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE,t1);}

/* k7345 in rec in scan in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_i_not(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(C_word)C_i_not(t3);
if(C_truep(t4)){
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t5)){
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(2));
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_TRUE);}}}}

/* transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_7714(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7714,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7718,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t7,a[6]=t1,a[7]=t5,a[8]=t6,a[9]=t2,a[10]=((C_word*)t0)[3],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8289,a[2]=t7,a[3]=t3,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8291,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#make-promise */
t11=*((C_word*)lf[199]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t9,t10);}
else{
/* optimizer.scm: 1306 debugging */
((C_proc6)C_retrieve_symbol_proc(lf[5]))(6,*((C_word*)lf[5]+1),t8,lf[6],lf[200],t3,t7);}}

/* a8290 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8291,2,t0,t1);}
/* optimizer.scm: 1305 unzip1 */
((C_proc3)C_retrieve_symbol_proc(lf[198]))(3,*((C_word*)lf[198]+1),t1,((C_word*)t0)[2]);}

/* k8287 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1305 debugging */
((C_proc7)C_retrieve_symbol_proc(lf[5]))(7,*((C_word*)lf[5]+1),((C_word*)t0)[4],lf[6],lf[197],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7718,2,t0,t1);}
t2=C_set_block_item(((C_word*)t0)[10],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[9];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_caddr(t4);
t6=(C_word)C_i_length(t5);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7728,a[2]=((C_word*)t0)[3],a[3]=t8,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=t4,tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1311 get */
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),t9,((C_word*)t0)[2],((C_word*)t0)[4],lf[119]);}

/* k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7728,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7737,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[11]))){
t6=(C_word)C_i_length(((C_word*)t0)[11]);
t7=(C_word)C_eqp(t6,C_fix(4));
if(C_truep(t7)){
t8=(C_word)C_i_caddr(((C_word*)t0)[11]);
t9=t5;
f_7737(t9,(C_word)C_i_listp(t8));}
else{
t8=t5;
f_7737(t8,C_SCHEME_FALSE);}}
else{
t6=t5;
f_7737(t6,C_SCHEME_FALSE);}}

/* k7735 in k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_7737(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7737,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_7743,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* optimizer.scm: 1315 caaddr */
((C_proc3)C_retrieve_proc(*((C_word*)lf[195]+1)))(3,*((C_word*)lf[195]+1),t3,((C_word*)t0)[13]);}
else{
/* optimizer.scm: 1413 bomb */
((C_proc4)C_retrieve_symbol_proc(lf[177]))(4,*((C_word*)lf[177]+1),((C_word*)t0)[10],lf[196],((C_word*)t0)[13]);}}

/* k7741 in k7735 in k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7743,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_7746,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* optimizer.scm: 1316 cdaddr */
((C_proc3)C_retrieve_proc(*((C_word*)lf[194]+1)))(3,*((C_word*)lf[194]+1),t2,((C_word*)t0)[14]);}

/* k7744 in k7741 in k7735 in k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7746,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[15]);
t3=(C_word)C_i_set_car(t2,t1);
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_7752,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* optimizer.scm: 1320 node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[185]))(4,*((C_word*)lf[185]+1),t4,((C_word*)t0)[5],lf[193]);}

/* k7750 in k7744 in k7741 in k7735 in k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7752,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7755,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
t3=((C_word*)t0)[5];
t4=(C_word)C_slot(t3,C_fix(3));
t5=(C_word)C_i_car(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7960,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_7960(t9,t2,t5);}

/* rec in k7750 in k7744 in k7741 in k7735 in k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_7960(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7960,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(2));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(3));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(t8,lf[14]);
if(C_truep(t9)){
t10=(C_word)C_i_car(t6);
t11=(C_word)C_i_cadr(t6);
t12=(C_word)C_slot(t10,C_fix(2));
t13=(C_word)C_slot(t11,C_fix(2));
t14=(C_word)C_slot(t10,C_fix(1));
t15=(C_word)C_eqp(lf[8],t14);
if(C_truep(t15)){
t16=(C_word)C_i_car(t12);
t17=(C_word)C_eqp(((C_word*)t0)[9],t16);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8004,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=t1,a[9]=t6,a[10]=((C_word*)t0)[7],a[11]=t13,a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
/* optimizer.scm: 1334 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t18,C_SCHEME_FALSE,t2,((C_word*)((C_word*)t0)[8])[1]);}
else{
t18=(C_word)C_i_car(t12);
t19=(C_word)C_eqp(((C_word*)t0)[7],t18);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8135,a[2]=t2,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1359 node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[185]))(4,*((C_word*)lf[185]+1),t20,t2,lf[191]);}
else{
/* optimizer.scm: 1362 bomb */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t1,lf[192]);}}}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_UNDEFINED);}}
else{
t10=(C_word)C_eqp(t8,lf[10]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t4);
t12=(C_word)C_i_car(t6);
if(C_truep((C_word)C_i_memq(t11,((C_word*)t0)[2]))){
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8182,a[2]=t6,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1367 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t13,t11,t12,((C_word*)((C_word*)t0)[4])[1]);}
else{
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8197,a[2]=((C_word*)t0)[3],a[3]=t14,tmp=(C_word)a,a+=4,tmp));
t16=((C_word*)t14)[1];
f_8197(t16,t1,t6);}}
else{
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8223,a[2]=((C_word*)t0)[3],a[3]=t12,tmp=(C_word)a,a+=4,tmp));
t14=((C_word*)t12)[1];
f_8223(t14,t1,t6);}}}

/* loop1940 in rec in k7750 in k7744 in k7741 in k7735 in k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_8223(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8223,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8233,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* rec1860 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7960(t5,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k8231 in loop1940 in rec in k7750 in k7744 in k7741 in k7735 in k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8223(t3,((C_word*)t0)[2],t2);}

/* loop1931 in rec in k7750 in k7744 in k7741 in k7735 in k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_8197(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8197,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8207,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* rec1860 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7960(t5,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k8205 in loop1931 in rec in k7750 in k7744 in k7741 in k7735 in k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8197(t3,((C_word*)t0)[2],t2);}

/* k8180 in rec in k7750 in k7744 in k7741 in k7735 in k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8182,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8185,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 1368 copy-node! */
((C_proc4)C_retrieve_symbol_proc(lf[180]))(4,*((C_word*)lf[180]+1),t3,t4,((C_word*)t0)[3]);}

/* k8183 in k8180 in rec in k7750 in k7744 in k7741 in k7735 in k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1369 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7960(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8133 in rec in k7750 in k7744 in k7741 in k7735 in k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8135,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8138,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1360 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k8136 in k8133 in rec in k7750 in k7744 in k7741 in k7735 in k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1361 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8002 in rec in k7750 in k7744 in k7741 in k7735 in k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8004,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[12])+1,t1);
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=(C_word)C_eqp(((C_word*)t0)[10],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8013,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[9]);
t7=(C_word)C_i_length(t6);
t8=(C_word)C_eqp(((C_word*)t0)[5],t7);
if(C_truep(t8)){
t9=t5;
f_8013(2,t9,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 1337 quit */
((C_proc4)C_retrieve_symbol_proc(lf[182]))(4,*((C_word*)lf[182]+1),t5,lf[187],((C_word*)t0)[4]);}}
else{
t5=(C_word)C_i_car(((C_word*)t0)[11]);
t6=(C_word)C_i_assq(t5,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t6);
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_i_car(t8);
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8059,a[2]=t7,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[6],a[6]=t9,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
t11=(C_word)C_i_cdr(((C_word*)t0)[9]);
t12=(C_word)C_i_length(t11);
t13=(C_word)C_eqp(((C_word*)t0)[5],t12);
if(C_truep(t13)){
t14=t10;
f_8059(2,t14,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 1348 quit */
((C_proc4)C_retrieve_symbol_proc(lf[182]))(4,*((C_word*)lf[182]+1),t10,lf[189],((C_word*)t0)[4]);}}
else{
/* optimizer.scm: 1357 bomb */
((C_proc4)C_retrieve_symbol_proc(lf[177]))(4,*((C_word*)lf[177]+1),((C_word*)t0)[8],lf[190],((C_word*)t0)[11]);}}}

/* k8057 in k8002 in rec in k7750 in k7744 in k7741 in k7735 in k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8059,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8062,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1351 node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[185]))(4,*((C_word*)lf[185]+1),t2,((C_word*)t0)[3],lf[10]);}

/* k8060 in k8057 in k8002 in rec in k7750 in k7744 in k7741 in k7735 in k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8062,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8065,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8089,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(2));
t5=(C_word)C_i_caddr(t4);
/* optimizer.scm: 1352 take */
((C_proc4)C_retrieve_symbol_proc(lf[188]))(4,*((C_word*)lf[188]+1),t3,t5,C_fix(1));}

/* k8087 in k8060 in k8057 in k8002 in rec in k7750 in k7744 in k7741 in k7735 in k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1352 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8063 in k8060 in k8057 in k8002 in rec in k7750 in k7744 in k7741 in k7735 in k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8065,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8068,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,((C_word*)t0)[4]);
t4=(C_word)C_i_cddr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_record(&a,4,lf[35],lf[186],t3,t4);
t6=(C_word)C_a_i_list(&a,2,t5,((C_word*)t0)[5]);
/* optimizer.scm: 1353 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),t2,((C_word*)t0)[2],t6);}

/* k8066 in k8063 in k8060 in k8057 in k8002 in rec in k7750 in k7744 in k7741 in k7735 in k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1356 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7960(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8011 in k8002 in rec in k7750 in k7744 in k7741 in k7735 in k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8016,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1340 node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[185]))(4,*((C_word*)lf[185]+1),t2,((C_word*)t0)[3],lf[186]);}

/* k8014 in k8011 in k8002 in rec in k7750 in k7744 in k7741 in k7735 in k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8019,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,((C_word*)t0)[2]);
/* optimizer.scm: 1341 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),t2,((C_word*)t0)[3],t3);}

/* k8017 in k8014 in k8011 in k8002 in rec in k7750 in k7744 in k7741 in k7735 in k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_8019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* optimizer.scm: 1342 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k7753 in k7750 in k7744 in k7741 in k7735 in k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7755,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7758,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7869,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7942,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm: 1390 lset-difference */
((C_proc5)C_retrieve_symbol_proc(lf[184]))(5,*((C_word*)lf[184]+1),t3,t4,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* a7941 in k7753 in k7750 in k7744 in k7741 in k7735 in k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7942(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7942,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_cdr(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t4,t5));}

/* k7867 in k7753 in k7750 in k7744 in k7741 in k7735 in k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7869,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7871,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_7871(t5,((C_word*)t0)[2],t1);}

/* loop1951 in k7867 in k7753 in k7750 in k7744 in k7741 in k7735 in k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_7871(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7871,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_i_cdr(t3);
t5=(C_word)C_slot(t4,C_fix(3));
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7890,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t7=(C_word)C_i_cdr(t5);
t8=(C_word)C_i_length(t7);
t9=(C_word)C_eqp(((C_word*)t0)[3],t8);
if(C_truep(t9)){
t10=t6;
f_7890(2,t10,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 1380 quit */
((C_proc4)C_retrieve_symbol_proc(lf[182]))(4,*((C_word*)lf[182]+1),t6,lf[183],((C_word*)t0)[2]);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k7888 in loop1951 in k7867 in k7753 in k7750 in k7744 in k7741 in k7735 in k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7893,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
t4=(C_word)C_a_i_list(&a,4,C_SCHEME_TRUE,C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3]);
t5=(C_word)C_i_car(((C_word*)t0)[5]);
t6=(C_word)C_i_cddr(((C_word*)t0)[5]);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_record(&a,4,lf[35],lf[181],t4,t7);
t9=(C_word)C_a_i_list(&a,2,t3,t8);
/* optimizer.scm: 1383 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),t2,((C_word*)t0)[2],t9);}

/* k7891 in k7888 in loop1951 in k7867 in k7753 in k7750 in k7744 in k7741 in k7735 in k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7871(t3,((C_word*)t0)[2],t2);}

/* k7756 in k7753 in k7750 in k7744 in k7741 in k7735 in k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7758,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_i_pairp(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(C_word)C_a_i_record(&a,4,lf[35],C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7770,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1395 copy-node! */
((C_proc4)C_retrieve_symbol_proc(lf[180]))(4,*((C_word*)lf[180]+1),t4,((C_word*)t0)[4],t3);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k7768 in k7756 in k7753 in k7750 in k7744 in k7741 in k7735 in k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7770,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7773,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7825,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm: 1397 fold-right */
((C_proc5)C_retrieve_symbol_proc(lf[125]))(5,*((C_word*)lf[125]+1),t2,t3,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* a7824 in k7768 in k7756 in k7753 in k7750 in k7744 in k7741 in k7735 in k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7825(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7825,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_slot(t6,C_fix(3));
t8=(C_word)C_i_car(t7);
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_slot(t8,C_fix(2));
t11=(C_word)C_slot(t8,C_fix(3));
t12=(C_word)C_a_i_record(&a,4,lf[35],t9,t10,t11);
t13=(C_word)C_a_i_list(&a,2,t12,t3);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_record(&a,4,lf[35],lf[10],t5,t13));}

/* k7771 in k7768 in k7756 in k7753 in k7750 in k7744 in k7741 in k7735 in k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7776,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1406 copy-node! */
((C_proc4)C_retrieve_symbol_proc(lf[180]))(4,*((C_word*)lf[180]+1),t2,t1,((C_word*)t0)[2]);}

/* k7774 in k7771 in k7768 in k7756 in k7753 in k7750 in k7744 in k7741 in k7735 in k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7776,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7781,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_7781(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop1995 in k7774 in k7771 in k7768 in k7756 in k7753 in k7750 in k7744 in k7741 in k7735 in k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_7781(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7781,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_i_cdr(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7797,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7823,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1410 gensym */
((C_proc2)C_retrieve_symbol_proc(lf[83]))(2,*((C_word*)lf[83]+1),t6);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k7821 in loop1995 in k7774 in k7771 in k7768 in k7756 in k7753 in k7750 in k7744 in k7741 in k7735 in k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7823,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1410 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k7795 in loop1995 in k7774 in k7771 in k7768 in k7756 in k7753 in k7750 in k7744 in k7741 in k7735 in k7726 in k7716 in transform in ##compiler#transform-direct-lambdas! in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7797,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(3));
t3=(C_word)C_a_i_record(&a,4,lf[35],lf[69],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t4=(C_word)C_i_set_car(t2,t3);
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t6=((C_word*)((C_word*)t0)[3])[1];
f_7781(t6,((C_word*)t0)[2],t5);}

/* ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5242(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word ab[8],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_5242,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
switch(t6){
case C_fix(1):
t9=t4;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5299,a[2]=t5,a[3]=t8,a[4]=t7,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t10,t9,lf[44]);
case C_fix(2):
if(C_truep(C_retrieve(lf[139]))){
t9=(C_word)C_i_length(t8);
t10=(C_word)C_i_car(t7);
t11=(C_word)C_eqp(t9,t10);
if(C_truep(t11)){
t12=t4;
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5407,a[2]=t2,a[3]=t1,a[4]=t5,a[5]=t8,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t13,t12,lf[44]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(3):
if(C_truep(C_retrieve(lf[139]))){
if(C_truep((C_word)C_i_nullp(t8))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5505,a[2]=t7,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t10,t9,lf[44]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(4):
if(C_truep(C_retrieve(lf[139]))){
if(C_truep(C_retrieve(lf[143]))){
t9=(C_word)C_i_length(t8);
t10=(C_word)C_eqp(C_fix(2),t9);
if(C_truep(t10)){
t11=t4;
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5543,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t12,t11,lf[44]);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(5):
if(C_truep(C_retrieve(lf[139]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5599,a[2]=t1,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t10,t9,lf[44]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(6):
t9=(C_word)C_i_caddr(t7);
t10=(C_truep(t9)?t9:C_retrieve(lf[143]));
if(C_truep(t10)){
if(C_truep(C_retrieve(lf[139]))){
t11=(C_word)C_i_length(t8);
t12=(C_word)C_eqp(C_fix(1),t11);
if(C_truep(t12)){
t13=t4;
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5686,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t14,t13,lf[44]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}
case C_fix(7):
t9=(C_word)C_i_cadddr(t7);
t10=(C_truep(t9)?t9:C_retrieve(lf[143]));
if(C_truep(t10)){
if(C_truep(C_retrieve(lf[139]))){
t11=(C_word)C_i_length(t8);
t12=(C_word)C_i_car(t7);
t13=(C_word)C_eqp(t11,t12);
if(C_truep(t13)){
t14=t4;
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5751,a[2]=t8,a[3]=t1,a[4]=t5,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t15,t14,lf[44]);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}
case C_fix(8):
if(C_truep(C_retrieve(lf[139]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5806,a[2]=t8,a[3]=t5,a[4]=t2,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t10,t9,lf[44]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(9):
if(C_truep(C_retrieve(lf[139]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5827,a[2]=t7,a[3]=t1,a[4]=t5,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t10,t9,lf[44]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(10):
if(C_truep(C_retrieve(lf[139]))){
t9=(C_word)C_i_cadddr(t7);
t10=(C_truep(t9)?t9:C_retrieve(lf[143]));
if(C_truep(t10)){
t11=t4;
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5971,a[2]=t1,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t12,t11,lf[44]);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(11):
if(C_truep(C_retrieve(lf[139]))){
t9=(C_word)C_i_caddr(t7);
t10=(C_truep(t9)?t9:C_retrieve(lf[143]));
if(C_truep(t10)){
t11=t4;
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6058,a[2]=t8,a[3]=t5,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t12,t11,lf[44]);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(12):
if(C_truep(C_retrieve(lf[139]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6117,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t10,t9,lf[44]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(13):
if(C_truep(C_retrieve(lf[139]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6187,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t10,t9,lf[44]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(14):
if(C_truep(C_retrieve(lf[139]))){
t9=(C_word)C_i_cadr(t7);
t10=(C_word)C_i_length(t8);
t11=(C_word)C_eqp(t9,t10);
if(C_truep(t11)){
t12=t4;
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6246,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t13,t12,lf[44]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(15):
if(C_truep(C_retrieve(lf[139]))){
t9=(C_word)C_i_length(t8);
t10=(C_word)C_eqp(C_fix(1),t9);
if(C_truep(t10)){
t11=C_retrieve(lf[143]);
t12=(C_truep(t11)?t11:(C_word)C_i_cadddr(t7));
if(C_truep(t12)){
t13=t4;
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6323,a[2]=t8,a[3]=t5,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t14,t13,lf[44]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(16):
t9=(C_word)C_i_car(t7);
t10=(C_word)C_i_length(t8);
t11=(C_word)C_i_cadddr(t7);
if(C_truep(C_retrieve(lf[139]))){
t12=(C_word)C_i_not(t9);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t10,t9));
if(C_truep(t13)){
t14=t4;
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6410,a[2]=t10,a[3]=t11,a[4]=t1,a[5]=t5,a[6]=t8,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t15,t14,lf[44]);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}
case C_fix(17):
if(C_truep(C_retrieve(lf[139]))){
t9=(C_word)C_i_length(t8);
t10=(C_word)C_i_car(t7);
t11=(C_word)C_eqp(t9,t10);
if(C_truep(t11)){
t12=t4;
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6483,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t13,t12,lf[44]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(18):
if(C_truep(C_retrieve(lf[139]))){
if(C_truep((C_word)C_i_nullp(t8))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6545,a[2]=t7,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t10,t9,lf[44]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(19):
if(C_truep(C_retrieve(lf[139]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6574,a[2]=t8,a[3]=t1,a[4]=t5,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t10,t9,lf[44]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(20):
t9=(C_word)C_i_length(t8);
t10=(C_word)C_i_cadddr(t7);
t11=(C_truep(t10)?t10:C_retrieve(lf[143]));
if(C_truep(t11)){
if(C_truep(C_retrieve(lf[139]))){
t12=(C_word)C_i_car(t7);
t13=(C_word)C_eqp(t9,t12);
if(C_truep(t13)){
t14=t4;
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6716,a[2]=t8,a[3]=t9,a[4]=t1,a[5]=t5,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t15,t14,lf[44]);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}
case C_fix(21):
if(C_truep(C_retrieve(lf[139]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6783,a[2]=t8,a[3]=t1,a[4]=t5,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t10,t9,lf[44]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(22):
t9=(C_word)C_i_car(t7);
t10=(C_word)C_i_length(t8);
t11=(C_word)C_i_cadddr(t7);
if(C_truep(C_retrieve(lf[139]))){
t12=(C_word)C_eqp(t10,t9);
if(C_truep(t12)){
t13=t4;
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6931,a[2]=t11,a[3]=t8,a[4]=t1,a[5]=t5,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t14,t13,lf[44]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}
case C_fix(23):
if(C_truep(C_retrieve(lf[139]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6988,a[2]=t5,a[3]=t1,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t10,t9,lf[44]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
default:
/* optimizer.scm: 1182 bomb */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t1,lf[178]);}}

/* k6986 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6988,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_length(((C_word*)t0)[4]);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(C_word)C_i_cadr(((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7003,a[2]=t6,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7010,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* optimizer.scm: 1168 varnode */
((C_proc3)C_retrieve_symbol_proc(lf[47]))(3,*((C_word*)lf[47]+1),t8,t9);}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7008 in k6986 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7010,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7014,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7016,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7022,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}

/* a7021 in k7008 in k6986 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7022(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7022,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7030,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7036,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_7036(t9,t4,t3,t5);}

/* loop in a7021 in k7008 in k6986 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_7036(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7036,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7056,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_symbolp(t5))){
/* optimizer.scm: 792  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[47]))(3,*((C_word*)lf[47]+1),t4,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5267,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t7=(C_word)C_i_car(t5);
t8=t6;
f_5267(t8,(C_word)C_eqp(lf[25],t7));}
else{
t7=t6;
f_5267(t7,C_SCHEME_FALSE);}}}}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7085,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_cdr(t3);
/* optimizer.scm: 1180 loop */
t13=t5;
t14=t6;
t15=t7;
t1=t13;
t2=t14;
t3=t15;
goto loop;}}}

/* k7083 in loop in a7021 in k7008 in k6986 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7085,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5265 in loop in a7021 in k7008 in k6986 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_5267(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* optimizer.scm: 793  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),((C_word*)t0)[2],t2);}
else{
/* optimizer.scm: 794  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k7054 in loop in a7021 in k7008 in k6986 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7056,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7060,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1178 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7036(t4,t2,C_SCHEME_END_OF_LIST,t3);}

/* k7058 in k7054 in loop in a7021 in k7008 in k6986 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7060,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7028 in a7021 in k7008 in k6986 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1171 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a7015 in k7008 in k6986 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7016,2,t0,t1);}
/* optimizer.scm: 1170 split-at */
((C_proc4)C_retrieve_symbol_proc(lf[86]))(4,*((C_word*)lf[86]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7012 in k7008 in k6986 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1167 cons* */
((C_proc5)C_retrieve_symbol_proc(lf[158]))(5,*((C_word*)lf[158]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7001 in k6986 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_7003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7003,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[35],lf[14],((C_word*)t0)[2],t1));}

/* k6929 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6931,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[143]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6950,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(C_retrieve(lf[148]),lf[153]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6963,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1149 fifth */
((C_proc3)C_retrieve_symbol_proc(lf[175]))(3,*((C_word*)lf[175]+1),t6,((C_word*)t0)[6]);}
else{
t6=(C_word)C_i_cadr(((C_word*)t0)[6]);
t7=(C_word)C_a_i_list(&a,2,t6,((C_word*)t0)[2]);
t8=((C_word*)t0)[3];
t9=t4;
f_6950(t9,(C_word)C_a_i_record(&a,4,lf[35],lf[88],t7,t8));}}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6961 in k6929 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6963,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
f_6950(t4,(C_word)C_a_i_record(&a,4,lf[35],lf[140],t2,t3));}

/* k6948 in k6929 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_6950(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6950,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[176],t2));}

/* k6781 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6783,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6789,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1109 fifth */
((C_proc3)C_retrieve_symbol_proc(lf[175]))(3,*((C_word*)lf[175]+1),t3,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6787 in k6781 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6789,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[6]);
t3=(C_truep(C_retrieve(lf[143]))?(C_word)C_i_caddr(((C_word*)t0)[6]):(C_word)C_i_cadr(((C_word*)t0)[6]));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6798,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6873,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1113 remove */
((C_proc4)C_retrieve_symbol_proc(lf[170]))(4,*((C_word*)lf[170]+1),t4,t5,((C_word*)t0)[2]);}

/* a6872 in k6787 in k6781 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6873(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6873,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(lf[25],t4);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_eqp(((C_word*)t0)[2],t8));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k6796 in k6787 in k6781 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6798,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6814,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1118 qnode */
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(t1);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],t3);
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[173],t4));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6840,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6842,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1126 fold-inner */
((C_proc4)C_retrieve_symbol_proc(lf[169]))(4,*((C_word*)lf[169]+1),t3,t4,t1);}}}

/* a6841 in k6796 in k6787 in k6781 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6842(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6842,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_retrieve(lf[148]),lf[153]);
if(C_truep(t4)){
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t6=(C_word)C_a_i_list(&a,2,t2,t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[35],lf[140],t5,t6));}
else{
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t6=(C_word)C_a_i_list(&a,2,t2,t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[35],lf[88],t5,t6));}}

/* k6838 in k6796 in k6787 in k6781 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6840,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[174],t2));}

/* k6812 in k6796 in k6787 in k6781 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6814,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[172],t2));}

/* k6714 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6716,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6729,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6734,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6744,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a6743 in k6714 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6744(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6744,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6756,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_caddr(((C_word*)t0)[2]);
/* optimizer.scm: 1097 qnode */
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t4,t5);}

/* k6754 in a6743 in k6714 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6756,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1096 append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[11]+1)))(5,*((C_word*)lf[11]+1),((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a6733 in k6714 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6734,2,t0,t1);}
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[3]);
/* optimizer.scm: 1095 split-at */
((C_proc4)C_retrieve_symbol_proc(lf[86]))(4,*((C_word*)lf[86]+1),t1,((C_word*)t0)[2],t2);}

/* k6727 in k6714 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6729,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,4,lf[35],lf[140],((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[171],t3));}

/* k6572 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6574,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_truep(C_retrieve(lf[143]))?(C_word)C_i_caddr(((C_word*)t0)[5]):(C_word)C_i_cadr(((C_word*)t0)[5]));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6583,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6655,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1064 remove */
((C_proc4)C_retrieve_symbol_proc(lf[170]))(4,*((C_word*)lf[170]+1),t4,t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a6654 in k6572 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6655(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6655,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(lf[25],t4);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_eqp(((C_word*)t0)[2],t8));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k6581 in k6572 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6583,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6599,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1069 qnode */
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(t1);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t3);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[167],t4));}
else{
t3=(C_word)C_i_cadddr(((C_word*)t0)[3]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(C_retrieve(lf[148]),lf[153]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6634,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6636,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1077 fold-inner */
((C_proc4)C_retrieve_symbol_proc(lf[169]))(4,*((C_word*)lf[169]+1),t5,t6,t1);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}}}

/* a6635 in k6581 in k6572 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6636(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6636,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
t5=(C_word)C_a_i_list(&a,2,t2,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_record(&a,4,lf[35],lf[140],t4,t5));}

/* k6632 in k6581 in k6572 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6634,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[168],t2));}

/* k6597 in k6581 in k6572 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6599,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[166],t2));}

/* k6543 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6545,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6555,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* optimizer.scm: 1051 qnode */
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6553 in k6543 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6555,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[165],t2));}

/* k6481 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6483,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6503,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve(lf[143]))){
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
t4=t2;
f_6503(t4,(C_word)C_i_pairp(t3));}
else{
t3=t2;
f_6503(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6501 in k6481 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_6503(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6503,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_caddr(((C_word*)t0)[5]):(C_word)C_i_cadr(((C_word*)t0)[5]));
t3=(C_word)C_a_i_list(&a,1,t2);
t4=((C_word*)t0)[4];
t5=(C_word)C_a_i_record(&a,4,lf[35],lf[140],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[164],t6));}

/* k6408 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6410,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[7]);
t3=(C_truep(t2)?t2:C_retrieve(lf[143]));
if(C_truep(t3)){
t4=(C_word)C_i_cadr(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6440,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
if(C_truep(t6)){
t7=t5;
f_6440(t7,(C_word)C_fixnum_increase(((C_word*)t0)[2]));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t7=(C_word)C_i_car(((C_word*)t0)[3]);
t8=t5;
f_6440(t8,(C_word)C_fixnum_times(((C_word*)t0)[2],t7));}
else{
t7=t5;
f_6440(t7,((C_word*)t0)[3]);}}}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6438 in k6408 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_6440(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6440,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
t4=(C_word)C_a_i_record(&a,4,lf[35],lf[88],t2,t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[163],t5));}

/* k6321 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6323,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_retrieve(lf[148]),t2);
if(C_truep(t3)){
t4=(C_word)C_i_caddr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6335,a[2]=t5,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6342,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* optimizer.scm: 1002 varnode */
((C_proc3)C_retrieve_symbol_proc(lf[47]))(3,*((C_word*)lf[47]+1),t7,t8);}
else{
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_eqp(C_retrieve(lf[148]),t4);
if(C_truep(t5)){
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[162],t6));}
else{
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6340 in k6321 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1002 cons* */
((C_proc5)C_retrieve_symbol_proc(lf[158]))(5,*((C_word*)lf[158]+1),((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6333 in k6321 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6335,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[35],lf[14],((C_word*)t0)[2],t1));}

/* k6244 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6246,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_retrieve(lf[148]),t2);
if(C_truep(t3)){
t4=(C_word)C_i_cadddr(((C_word*)t0)[5]);
t5=(C_truep(t4)?t4:C_retrieve(lf[143]));
if(C_truep(t5)){
t6=(C_truep(C_retrieve(lf[143]))?(C_word)C_i_cadddr(((C_word*)t0)[5]):(C_word)C_i_caddr(((C_word*)t0)[5]));
t7=(C_word)C_a_i_list(&a,1,t6);
t8=((C_word*)t0)[4];
t9=(C_word)C_a_i_record(&a,4,lf[35],lf[140],t7,t8);
t10=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[161],t10));}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6185 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6187,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[143]));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6202,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
t7=t5;
f_6202(t7,(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,t6));}
else{
t6=t5;
f_6202(t6,((C_word*)t0)[2]);}}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6200 in k6185 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_6202(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6202,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6205,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],C_SCHEME_TRUE);
t4=(C_word)C_a_i_record(&a,4,lf[35],lf[160],t3,C_SCHEME_END_OF_LIST);
/* optimizer.scm: 975  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[158]))(5,*((C_word*)lf[158]+1),t2,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6203 in k6200 in k6185 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6205,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[35],lf[14],((C_word*)t0)[2],t1));}

/* k6115 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6117,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_truep(t2)?t2:C_retrieve(lf[143]));
if(C_truep(t3)){
t4=(C_word)C_i_length(((C_word*)t0)[4]);
t5=(C_word)C_i_caddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t4,t5))){
t6=(C_word)C_eqp(t4,C_fix(1));
if(C_truep(t6)){
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[159],t7));}
else{
t7=(C_word)C_i_car(((C_word*)t0)[5]);
t8=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t7);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6153,a[2]=t8,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6160,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
t11=(C_word)C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 965  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[47]))(3,*((C_word*)lf[47]+1),t10,t11);}}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6158 in k6115 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 965  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[158]))(5,*((C_word*)lf[158]+1),((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6151 in k6115 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6153,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[35],lf[14],((C_word*)t0)[2],t1));}

/* k6056 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6058,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6070,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_6070(t5,t3);}
else{
t5=(C_word)C_i_length(((C_word*)t0)[2]);
t6=(C_word)C_i_car(((C_word*)t0)[5]);
t7=t4;
f_6070(t7,(C_word)C_eqp(t5,t6));}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6068 in k6056 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_6070(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6070,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6076,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6083,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* optimizer.scm: 950  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[47]))(3,*((C_word*)lf[47]+1),t5,t6);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6081 in k6068 in k6056 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 950  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[158]))(5,*((C_word*)lf[158]+1),((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6074 in k6068 in k6056 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6076,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[35],lf[14],((C_word*)t0)[2],t1));}

/* k5969 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5971,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
if(C_truep((C_word)C_and((C_word)C_fixnum_lessp(C_fix(0),t2),(C_word)C_fixnum_lessp(t2,C_fix(3))))){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5993,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
/* optimizer.scm: 932  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[47]))(3,*((C_word*)lf[47]+1),t5,t6);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5991 in k5969 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5993,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6001,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 935  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t3,t4);}

/* k5999 in k5991 in k5969 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6005,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_i_caddr(((C_word*)t0)[2]);
/* optimizer.scm: 937  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[47]))(3,*((C_word*)lf[47]+1),t2,t4);}
else{
t4=t2;
f_6005(2,t4,(C_word)C_i_cadr(((C_word*)t0)[3]));}}

/* k6003 in k5999 in k5991 in k5969 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_6005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6005,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,5,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[35],lf[14],((C_word*)t0)[2],t2));}

/* k5825 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5827,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5843,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 903  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t3,C_SCHEME_TRUE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5849,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve(lf[143]))){
t4=(C_word)C_eqp(C_retrieve(lf[148]),lf[157]);
t5=t3;
f_5849(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_5849(t4,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5847 in k5825 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_5849(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5849,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5852,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_5852(t3,t1);}
else{
t3=(C_word)C_eqp(C_retrieve(lf[148]),lf[153]);
t4=(C_truep(t3)?(C_word)C_i_caddr(((C_word*)t0)[5]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t2;
f_5852(t5,t4);}
else{
t5=(C_word)C_eqp(C_retrieve(lf[148]),lf[156]);
t6=t2;
f_5852(t6,(C_truep(t5)?(C_word)C_i_cadddr(((C_word*)t0)[5]):C_SCHEME_FALSE));}}}

/* k5850 in k5847 in k5825 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_5852(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5852,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5855,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5911,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a5910 in k5850 in k5847 in k5825 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5911(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5911,3,t0,t1,t2);}
/* optimizer.scm: 907  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[83]))(2,*((C_word*)lf[83]+1),t1);}

/* k5853 in k5850 in k5847 in k5825 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5858,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* map */
t3=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[47]),t1);}

/* k5856 in k5853 in k5850 in k5847 in k5825 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5863,tmp=(C_word)a,a+=2,tmp);
t3=(C_word)C_eqp(C_retrieve(lf[148]),lf[153]);
t4=(C_truep(t3)?(C_word)C_i_car(((C_word*)t0)[6]):(C_word)C_i_cadr(((C_word*)t0)[6]));
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5887,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5889,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 919  fold-boolean */
((C_proc4)C_retrieve_symbol_proc(lf[155]))(4,*((C_word*)lf[155]+1),t6,t7,t1);}

/* a5888 in k5856 in k5853 in k5850 in k5847 in k5825 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5889(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5889,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[35],lf[140],((C_word*)t0)[2],t4));}

/* k5885 in k5856 in k5853 in k5850 in k5847 in k5825 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5887,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[154],t2);
/* optimizer.scm: 909  fold-right */
((C_proc6)C_retrieve_symbol_proc(lf[125]))(6,*((C_word*)lf[125]+1),((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5862 in k5856 in k5853 in k5850 in k5847 in k5825 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5863(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5863,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t3);
t6=(C_word)C_a_i_list(&a,2,t2,t4);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[35],lf[10],t5,t6));}

/* k5841 in k5825 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5843,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[152],t2));}

/* k5804 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=t2;
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5749 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5751,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5764,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5775,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* optimizer.scm: 889  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t5,t6);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5773 in k5749 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5775,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 888  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5762 in k5749 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5764,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,4,lf[35],lf[140],((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[151],t3));}

/* k5684 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5686,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=((C_word*)t0)[4];
t7=(C_word)C_a_i_record(&a,4,lf[35],lf[140],t5,t6);
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(C_word)C_a_i_record(&a,4,lf[35],lf[140],t3,t8);
t10=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[150],t10));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5597 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5599,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_i_not(t4);
t6=(C_truep(t5)?t5:(C_word)C_eqp(t4,C_retrieve(lf[148])));
if(C_truep(t6)){
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(C_word)C_i_car(((C_word*)t0)[5]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5641,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t8,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* optimizer.scm: 865  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t10,t11);}
else{
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5639 in k5597 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5641,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_record(&a,4,lf[35],lf[140],((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[149],t4));}

/* k5541 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5543,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5556,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 847  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[47]))(3,*((C_word*)lf[47]+1),t4,t5);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5554 in k5541 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5556,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5564,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 850  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t3,t4);}

/* k5562 in k5554 in k5541 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5564,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[35],lf[14],((C_word*)t0)[2],t3));}

/* k5503 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5505,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5515,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* optimizer.scm: 838  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[47]))(3,*((C_word*)lf[47]+1),t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5513 in k5503 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5515,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[147],t2));}

/* k5405 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5407,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[143]));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(C_word)C_i_cadddr(((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5432,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5435,a[2]=((C_word*)t0)[6],a[3]=t6,a[4]=((C_word*)t0)[5],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t8=(C_word)C_slot(t4,C_fix(1));
t9=(C_word)C_eqp(lf[8],t8);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5464,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_slot(t4,C_fix(2));
t12=(C_word)C_i_car(t11);
/* optimizer.scm: 829  get */
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),t10,((C_word*)t0)[2],t12,lf[146]);}
else{
t10=t7;
f_5435(t10,C_SCHEME_FALSE);}}
else{
t8=t7;
f_5435(t8,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5462 in k5405 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5435(t2,(C_word)C_eqp(lf[145],t1));}

/* k5433 in k5405 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_5435(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5435,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
f_5432(t4,(C_word)C_a_i_record(&a,4,lf[35],lf[140],t2,t3));}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[2]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
f_5432(t5,(C_word)C_a_i_record(&a,4,lf[35],lf[140],t3,t4));}}

/* k5430 in k5405 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_5432(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5432,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[144],t2));}

/* k5297 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5299,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5302,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_length(((C_word*)t0)[3]);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[3]);
t7=(C_word)C_i_cadr(((C_word*)t0)[3]);
t8=(C_word)C_slot(t6,C_fix(1));
t9=(C_word)C_eqp(lf[8],t8);
if(C_truep(t9)){
t10=(C_word)C_slot(t7,C_fix(1));
t11=(C_word)C_eqp(lf[8],t10);
if(C_truep(t11)){
t12=(C_word)C_slot(t6,C_fix(2));
t13=(C_word)C_slot(t7,C_fix(2));
if(C_truep((C_word)C_i_equalp(t12,t13))){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5362,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 808  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t14,C_SCHEME_TRUE);}
else{
t14=t2;
f_5302(t14,C_SCHEME_FALSE);}}
else{
t12=t2;
f_5302(t12,C_SCHEME_FALSE);}}
else{
t10=t2;
f_5302(t10,C_SCHEME_FALSE);}}
else{
t6=t2;
f_5302(t6,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5360 in k5297 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5362,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
f_5302(t3,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[142],t2));}

/* k5300 in k5297 in ##compiler#simplify-named-call in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_5302(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5302,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep(C_retrieve(lf[139]))){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=((C_word*)t0)[3];
t5=(C_word)C_a_i_record(&a,4,lf[35],lf[140],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t5);
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[141],t6));}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* ##compiler#rewrite in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5222(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_5222r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5222r(t0,t1,t2,t3);}}

static void C_ccall f_5222r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5226,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 786  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[31]))(4,*((C_word*)lf[31]+1),t4,C_retrieve(lf[136]),t2);}

/* k5224 in ##compiler#rewrite in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5226,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5236,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* optimizer.scm: 787  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t3,t2,t4);}

/* k5234 in k5224 in ##compiler#rewrite in k5218 in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 787  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),((C_word*)t0)[3],C_retrieve(lf[136]),((C_word*)t0)[2],t1);}

/* ##compiler#reorganize-recursive-bindings in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4862(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4862,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4866,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t1,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 698  map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[134]+1)))(5,*((C_word*)lf[134]+1),t7,*((C_word*)lf[135]+1),t2,t3);}

/* k4864 in ##compiler#reorganize-recursive-bindings in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4868,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4913,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5207,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 709  for-each */
((C_proc5)C_retrieve_proc(*((C_word*)lf[133]+1)))(5,*((C_word*)lf[133]+1),t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5206 in k4864 in ##compiler#reorganize-recursive-bindings in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5207(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5207,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5212,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5216,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 710  scan-used-variables */
((C_proc4)C_retrieve_symbol_proc(lf[132]))(4,*((C_word*)lf[132]+1),t5,t3,((C_word*)t0)[2]);}

/* k5214 in a5206 in k4864 in ##compiler#reorganize-recursive-bindings in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 710  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k5210 in a5206 in k4864 in ##compiler#reorganize-recursive-bindings in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4911 in k4864 in ##compiler#reorganize-recursive-bindings in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4913,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4916,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5133,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t5,a[6]=t8,tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_5133(t10,t6,((C_word*)t0)[2]);}

/* loop976 in k4911 in k4864 in ##compiler#reorganize-recursive-bindings in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_5133(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5133,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5146,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t3,((C_word*)((C_word*)t0)[5])[1]))){
t5=t4;
f_5146(t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5159,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5181,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 719  filter */
((C_proc4)C_retrieve_symbol_proc(lf[130]))(4,*((C_word*)lf[130]+1),t5,t6,((C_word*)t0)[2]);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a5180 in loop976 in k4911 in k4864 in ##compiler#reorganize-recursive-bindings in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5181(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5181,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5194,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 720  find-path */
t5=((C_word*)t0)[2];
f_4868(t5,t4,((C_word*)t0)[3],t2);}}

/* k5192 in a5180 in loop976 in k4911 in k4864 in ##compiler#reorganize-recursive-bindings in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 720  find-path */
t2=((C_word*)t0)[5];
f_4868(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5157 in loop976 in k4911 in k4864 in ##compiler#reorganize-recursive-bindings in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5159,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5163,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5175,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 722  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[83]))(2,*((C_word*)lf[83]+1),t3);}

/* k5173 in k5157 in loop976 in k4911 in k4864 in ##compiler#reorganize-recursive-bindings in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5175,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* optimizer.scm: 722  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),((C_word*)t0)[3],t1,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k5161 in k5157 in loop976 in k4911 in k4864 in ##compiler#reorganize-recursive-bindings in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5163,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5167,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
/* optimizer.scm: 723  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[11]+1)))(5,*((C_word*)lf[11]+1),t3,t4,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}

/* k5165 in k5161 in k5157 in loop976 in k4911 in k4864 in ##compiler#reorganize-recursive-bindings in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5146(t3,t2);}

/* k5144 in loop976 in k4911 in k4864 in ##compiler#reorganize-recursive-bindings in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_5146(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5133(t3,((C_word*)t0)[2],t2);}

/* k4914 in k4911 in k4864 in ##compiler#reorganize-recursive-bindings in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4916,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4919,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5058,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=t6,a[6]=t3,tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_5058(t8,t4,((C_word*)((C_word*)t0)[7])[1]);}

/* loop996 in k4914 in k4911 in k4864 in ##compiler#reorganize-recursive-bindings in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_5058(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5058,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5074,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5117,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(t3);
/* optimizer.scm: 732  append-map */
((C_proc4)C_retrieve_symbol_proc(lf[131]))(4,*((C_word*)lf[131]+1),t5,t6,t7);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a5116 in loop996 in k4914 in k4911 in k4864 in ##compiler#reorganize-recursive-bindings in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5117(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5117,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5123,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 733  filter */
((C_proc4)C_retrieve_symbol_proc(lf[130]))(4,*((C_word*)lf[130]+1),t1,t3,((C_word*)t0)[2]);}

/* a5122 in a5116 in loop996 in k4914 in k4911 in k4864 in ##compiler#reorganize-recursive-bindings in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5123(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5123,3,t0,t1,t2);}
/* optimizer.scm: 733  find-path */
t3=((C_word*)t0)[3];
f_4868(t3,t1,((C_word*)t0)[2],t2);}

/* k5072 in loop996 in k4914 in k4911 in k4864 in ##compiler#reorganize-recursive-bindings in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5074,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5078,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5089,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5091,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 738  filter-map */
((C_proc4)C_retrieve_symbol_proc(lf[129]))(4,*((C_word*)lf[129]+1),t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* a5090 in k5072 in loop996 in k4914 in k4911 in k4864 in ##compiler#reorganize-recursive-bindings in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5091(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5091,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5104,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t2);
/* optimizer.scm: 739  lset<= */
((C_proc5)C_retrieve_symbol_proc(lf[128]))(5,*((C_word*)lf[128]+1),t4,*((C_word*)lf[34]+1),t5,((C_word*)t0)[2]);}}

/* k5102 in a5090 in k5072 in loop996 in k4914 in k4911 in k4864 in ##compiler#reorganize-recursive-bindings in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_i_car(((C_word*)t0)[2]):C_SCHEME_FALSE));}

/* k5087 in k5072 in loop996 in k4914 in k4911 in k4864 in ##compiler#reorganize-recursive-bindings in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 736  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k5076 in k5072 in loop996 in k4914 in k4911 in k4864 in ##compiler#reorganize-recursive-bindings in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_5058(t4,((C_word*)t0)[2],t3);}

/* k4917 in k4914 in k4911 in k4864 in ##compiler#reorganize-recursive-bindings in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4922,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 745  topological-sort */
((C_proc4)C_retrieve_symbol_proc(lf[127]))(4,*((C_word*)lf[127]+1),t2,((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[34]+1));}

/* k4920 in k4917 in k4914 in k4911 in k4864 in ##compiler#reorganize-recursive-bindings in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4922,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4925,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4942,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 750  fold */
((C_proc5)C_retrieve_symbol_proc(lf[126]))(5,*((C_word*)lf[126]+1),t4,t5,((C_word*)t0)[2],t1);}

/* a4941 in k4920 in k4917 in k4914 in k4911 in k4864 in ##compiler#reorganize-recursive-bindings in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4942(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4942,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[5])[1]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_i_car(t5);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4955,a[2]=t5,a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t8))){
t9=(C_word)C_i_assq(t6,((C_word*)((C_word*)t0)[2])[1]);
t10=(C_word)C_i_cdr(t9);
t11=(C_word)C_i_memq(t6,t10);
t12=t7;
f_4955(t12,(C_word)C_i_not(t11));}
else{
t9=t7;
f_4955(t9,C_SCHEME_FALSE);}}

/* k4953 in a4941 in k4920 in k4917 in k4914 in k4911 in k4864 in ##compiler#reorganize-recursive-bindings in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_4955(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4955,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_assq(((C_word*)t0)[7],((C_word*)t0)[5]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_a_i_list(&a,2,t5,((C_word*)t0)[4]);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[35],lf[10],((C_word*)t0)[2],t6));}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4978,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4996,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4998,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 764  fold-right */
((C_proc5)C_retrieve_symbol_proc(lf[125]))(5,*((C_word*)lf[125]+1),t3,t4,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* a4997 in k4953 in a4941 in k4920 in k4917 in k4914 in k4911 in k4864 in ##compiler#reorganize-recursive-bindings in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4998(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4998,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5030,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 767  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[83]))(2,*((C_word*)lf[83]+1),t4);}

/* k5028 in a4997 in k4953 in a4941 in k4920 in k4917 in k4914 in k4911 in k4864 in ##compiler#reorganize-recursive-bindings in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_5030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5030,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t4=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_record(&a,4,lf[35],lf[15],t3,t6);
t8=(C_word)C_a_i_list(&a,2,t7,((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_record(&a,4,lf[35],lf[10],t2,t8));}

/* k4994 in k4953 in a4941 in k4920 in k4917 in k4914 in k4911 in k4864 in ##compiler#reorganize-recursive-bindings in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 759  fold-right */
((C_proc5)C_retrieve_symbol_proc(lf[125]))(5,*((C_word*)lf[125]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a4977 in k4953 in a4941 in k4920 in k4917 in k4914 in k4911 in k4864 in ##compiler#reorganize-recursive-bindings in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4978(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4978,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,t2);
t5=(C_word)C_a_i_record(&a,4,lf[35],lf[69],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_list(&a,2,t5,t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[35],lf[10],t4,t6));}

/* k4923 in k4920 in k4917 in k4914 in k4911 in k4864 in ##compiler#reorganize-recursive-bindings in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4925,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[3])[1]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4934,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 776  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),t2,lf[6],lf[124],((C_word*)((C_word*)t0)[3])[1]);}
else{
/* optimizer.scm: 778  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}}

/* k4932 in k4923 in k4920 in k4917 in k4914 in k4911 in k4864 in ##compiler#reorganize-recursive-bindings in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 777  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE);}

/* find-path in k4864 in ##compiler#reorganize-recursive-bindings in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_4868(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4868,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4874,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4874(t7,t1,t2,C_SCHEME_END_OF_LIST);}

/* find in find-path in k4864 in ##compiler#reorganize-recursive-bindings in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_4874(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4874,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_memq(t2,t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[4])[1]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_i_memq(((C_word*)t0)[3],t5);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_a_i_cons(&a,2,t2,t3);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4898,a[2]=t7,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 706  any */
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),t1,t8,t5);}}}

/* a4897 in find in find-path in k4864 in ##compiler#reorganize-recursive-bindings in k4858 in k4855 in k4852 in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4898(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4898,3,t0,t1,t2);}
/* optimizer.scm: 706  find */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4874(t3,t1,t2,((C_word*)t0)[2]);}

/* register-simplifications in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4847(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_4847r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4847r(t0,t1,t2,t3);}}

static void C_ccall f_4847r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
/* optimizer.scm: 474  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),t1,C_retrieve(lf[21]),t2,t3);}

/* ##compiler#perform-pre-optimization! in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4590(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4590,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4593,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4597,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4604,a[2]=t9,a[3]=t3,a[4]=t8,a[5]=t7,a[6]=t5,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 426  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t10,lf[19],lf[120]);}

/* k4602 in ##compiler#perform-pre-optimization! in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4604,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4607,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4619,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t3,lf[118],lf[44]);}

/* k4617 in k4602 in ##compiler#perform-pre-optimization! in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4619,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4626,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 465  test */
t3=((C_word*)t0)[3];
f_4597(t3,t2,lf[118],lf[119]);}
else{
t2=((C_word*)t0)[2];
f_4607(2,t2,C_SCHEME_UNDEFINED);}}

/* k4624 in k4617 in k4602 in ##compiler#perform-pre-optimization! in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4626,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4631,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t4,tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_4631(t6,((C_word*)t0)[2],t2);}

/* loop635 in k4624 in k4617 in k4602 in ##compiler#perform-pre-optimization! in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_4631(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4631,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_i_cdr(t3);
t5=(C_word)C_slot(t4,C_fix(3));
t6=(C_word)C_i_cadr(t5);
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4653,a[2]=t8,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t5,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=((C_word*)t0)[6],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4838,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 435  test */
t11=((C_word*)t0)[2];
f_4597(t11,t10,t8,lf[76]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k4836 in loop635 in k4624 in k4617 in k4602 in ##compiler#perform-pre-optimization! in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4653(2,t2,C_SCHEME_FALSE);}
else{
/* optimizer.scm: 435  test */
t2=((C_word*)t0)[3];
f_4597(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[45]);}}

/* k4651 in loop635 in k4624 in k4617 in k4602 in ##compiler#perform-pre-optimization! in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4653,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4656,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 436  get-list */
((C_proc5)C_retrieve_symbol_proc(lf[117]))(5,*((C_word*)lf[117]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[75]);}

/* k4654 in k4651 in loop635 in k4624 in k4617 in k4602 in ##compiler#perform-pre-optimization! in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4656,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4659,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4669,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[7])){
if(C_truep(t1)){
t4=(C_word)C_i_length(t1);
t5=(C_word)C_eqp(C_fix(1),t4);
if(C_truep(t5)){
t6=(C_word)C_i_length(((C_word*)t0)[4]);
t7=(C_word)C_eqp(C_fix(3),t6);
if(C_truep(t7)){
t8=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t9=t3;
f_4669(t9,(C_word)C_eqp(lf[53],t8));}
else{
t8=t3;
f_4669(t8,C_SCHEME_FALSE);}}
else{
t6=t3;
f_4669(t6,C_SCHEME_FALSE);}}
else{
t4=t3;
f_4669(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_4669(t4,C_SCHEME_FALSE);}}

/* k4667 in k4654 in k4651 in loop635 in k4624 in k4617 in k4602 in ##compiler#perform-pre-optimization! in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_4669(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4669,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t5=(C_word)C_i_car(t4);
t6=(C_word)C_slot(t5,C_fix(3));
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4684,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t6,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t5,a[10]=t3,tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(t3))){
t8=(C_word)C_i_cdr(t3);
t9=t7;
f_4684(t9,(C_word)C_i_nullp(t8));}
else{
t8=t7;
f_4684(t8,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
f_4659(t2,C_SCHEME_UNDEFINED);}}

/* k4682 in k4667 in k4654 in k4651 in loop635 in k4624 in k4617 in k4602 in ##compiler#perform-pre-optimization! in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_4684(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4684,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4690,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 447  get-list */
((C_proc5)C_retrieve_symbol_proc(lf[117]))(5,*((C_word*)lf[117]+1),t3,((C_word*)t0)[2],t2,lf[75]);}
else{
t2=((C_word*)t0)[7];
f_4659(t2,C_SCHEME_UNDEFINED);}}

/* k4688 in k4682 in k4667 in k4654 in k4651 in loop635 in k4624 in k4617 in k4602 in ##compiler#perform-pre-optimization! in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4696,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_length(t1);
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
t6=t2;
f_4696(t6,(C_word)C_eqp(lf[9],t5));}
else{
t5=t2;
f_4696(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_4696(t3,C_SCHEME_FALSE);}}

/* k4694 in k4688 in k4682 in k4667 in k4654 in k4651 in loop635 in k4624 in k4617 in k4602 in ##compiler#perform-pre-optimization! in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_4696(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4696,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[9],C_fix(3));
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4705,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_eqp(lf[8],t5);
if(C_truep(t6)){
t7=(C_word)C_slot(t3,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=t4;
f_4705(t9,(C_word)C_eqp(((C_word*)t0)[2],t8));}
else{
t7=t4;
f_4705(t7,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[7];
f_4659(t2,C_SCHEME_UNDEFINED);}}

/* k4703 in k4694 in k4688 in k4682 in k4667 in k4654 in k4651 in loop635 in k4624 in k4617 in k4602 in ##compiler#perform-pre-optimization! in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_4705(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4705,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[8])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4712,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 459  node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),t4,((C_word*)t0)[2],lf[116]);}
else{
t2=((C_word*)t0)[7];
f_4659(t2,C_SCHEME_UNDEFINED);}}

/* k4710 in k4703 in k4694 in k4688 in k4682 in k4667 in k4654 in k4651 in loop635 in k4624 in k4617 in k4602 in ##compiler#perform-pre-optimization! in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4712,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4715,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 460  node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),t2,((C_word*)t0)[2],t3);}

/* k4713 in k4710 in k4703 in k4694 in k4688 in k4682 in k4667 in k4654 in k4651 in loop635 in k4624 in k4617 in k4602 in ##compiler#perform-pre-optimization! in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4718,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4733,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 463  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[114]+1)))(3,*((C_word*)lf[114]+1),t4,t5);}

/* k4731 in k4713 in k4710 in k4703 in k4694 in k4688 in k4682 in k4667 in k4654 in k4651 in loop635 in k4624 in k4617 in k4602 in ##compiler#perform-pre-optimization! in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4733,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* optimizer.scm: 461  node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4716 in k4713 in k4710 in k4703 in k4694 in k4688 in k4682 in k4667 in k4654 in k4651 in loop635 in k4624 in k4617 in k4602 in ##compiler#perform-pre-optimization! in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 464  touch */
t2=((C_word*)t0)[3];
f_4659(t2,f_4593(((C_word*)t0)[2]));}

/* k4657 in k4654 in k4651 in loop635 in k4624 in k4617 in k4602 in ##compiler#perform-pre-optimization! in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_4659(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4631(t3,((C_word*)t0)[2],t2);}

/* k4605 in k4602 in ##compiler#perform-pre-optimization! in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4610,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 467  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),t2,lf[6],lf[112],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_4610(2,t4,C_SCHEME_UNDEFINED);}}

/* k4608 in k4605 in k4602 in ##compiler#perform-pre-optimization! in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* test in ##compiler#perform-pre-optimization! in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_4597(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4597,NULL,4,t0,t1,t2,t3);}
/* optimizer.scm: 424  get */
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),t1,((C_word*)t0)[2],t2,t3);}

/* touch in ##compiler#perform-pre-optimization! in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static C_word C_fcall f_4593(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
return(C_SCHEME_TRUE);}

/* ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_2995(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word ab[66],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2995,4,t0,t1,t2,t3);}
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_fix(0);
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_FALSE;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2998,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3004,tmp=(C_word)a,a+=2,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3024,a[2]=t15,tmp=(C_word)a,a+=3,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3028,a[2]=t3,a[3]=t20,a[4]=t18,a[5]=t13,tmp=(C_word)a,a+=6,tmp));
t22=C_SCHEME_UNDEFINED;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_SCHEME_UNDEFINED;
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_SCHEME_UNDEFINED;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_set_block_item(t23,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3120,a[2]=t25,a[3]=t17,a[4]=t23,a[5]=t18,a[6]=t7,a[7]=t20,a[8]=t15,tmp=(C_word)a,a+=9,tmp));
t29=C_set_block_item(t25,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3334,a[2]=t11,a[3]=t3,a[4]=t27,a[5]=t23,a[6]=t5,a[7]=t9,a[8]=t16,a[9]=t18,tmp=(C_word)a,a+=10,tmp));
t30=C_set_block_item(t27,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4453,a[2]=t23,tmp=(C_word)a,a+=3,tmp));
t31=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4478,a[2]=t23,a[3]=t13,a[4]=t9,a[5]=t5,a[6]=t7,a[7]=t15,a[8]=t2,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 392  perform-pre-optimization! */
((C_proc4)C_retrieve_symbol_proc(lf[111]))(4,*((C_word*)lf[111]+1),t31,t2,t3);}

/* k4476 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4478,2,t0,t1);}
if(C_truep(t1)){
/* optimizer.scm: 393  values */
C_values(4,0,((C_word*)t0)[9],((C_word*)t0)[8],C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4484,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 395  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t2,lf[19],lf[110]);}}

/* k4482 in k4476 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4484,2,t0,t1);}
t2=C_set_block_item(lf[22] /* simplified-ops */,0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4488,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 397  walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3120(t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4486 in k4482 in k4476 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4488,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4491,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
/* optimizer.scm: 398  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),t2,lf[6],lf[109],((C_word*)((C_word*)t0)[2])[1]);}
else{
t3=t2;
f_4491(2,t3,C_SCHEME_UNDEFINED);}}

/* k4489 in k4486 in k4482 in k4476 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4491,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4494,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4527,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve(lf[22])))){
/* optimizer.scm: 399  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t3,lf[6],lf[108]);}
else{
t4=t3;
f_4527(2,t4,C_SCHEME_FALSE);}}

/* k4525 in k4489 in k4486 in k4482 in k4476 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4527,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4532,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4532(t5,((C_word*)t0)[2],C_retrieve(lf[22]));}
else{
t2=((C_word*)t0)[2];
f_4494(2,t2,C_SCHEME_UNDEFINED);}}

/* loop592 in k4525 in k4489 in k4486 in k4482 in k4476 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_4532(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4532,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4545,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* optimizer.scm: 402  print* */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t4,C_make_character(9),t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k4543 in loop592 in k4525 in k4489 in k4486 in k4482 in k4476 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4548,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(1)))){
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* optimizer.scm: 404  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[105]+1)))(4,*((C_word*)lf[105]+1),t2,C_make_character(9),t4);}
else{
/* optimizer.scm: 405  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[106]+1)))(2,*((C_word*)lf[106]+1),t2);}}

/* k4546 in k4543 in loop592 in k4525 in k4489 in k4486 in k4482 in k4476 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4532(t3,((C_word*)t0)[2],t2);}

/* k4492 in k4489 in k4486 in k4482 in k4476 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4494,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4497,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 407  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),t2,lf[6],lf[104],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_4497(2,t4,C_SCHEME_UNDEFINED);}}

/* k4495 in k4492 in k4489 in k4486 in k4482 in k4476 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4497,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4500,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 408  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),t2,lf[6],lf[103],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_4500(2,t4,C_SCHEME_UNDEFINED);}}

/* k4498 in k4495 in k4492 in k4489 in k4486 in k4482 in k4476 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4503,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 409  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),t2,lf[6],lf[102],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_4503(2,t4,C_SCHEME_UNDEFINED);}}

/* k4501 in k4498 in k4495 in k4492 in k4489 in k4486 in k4482 in k4476 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 410  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* walk-generic in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_4453(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4453,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4457,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4468,a[2]=t6,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* map */
t9=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,t5);}

/* a4467 in walk-generic in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4468(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4468,3,t0,t1,t2);}
/* walk137 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3120(t3,t1,t2,((C_word*)t0)[2]);}

/* k4455 in walk-generic in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4463,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 388  every */
((C_proc5)C_retrieve_symbol_proc(lf[41]))(5,*((C_word*)lf[41]+1),t2,*((C_word*)lf[34]+1),((C_word*)t0)[2],t1);}

/* k4461 in k4455 in walk-generic in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4463,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[35],t2,t3,((C_word*)t0)[2]));}}

/* walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_3334(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3334,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[8]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t7);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3359,a[2]=((C_word*)t0)[7],a[3]=t7,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t13,tmp=(C_word)a,a+=7,tmp));
t15=((C_word*)t13)[1];
f_3359(t15,t1,t11);}
else{
t11=(C_word)C_eqp(t9,lf[10]);
if(C_truep(t11)){
t12=(C_word)C_i_car(t7);
t13=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3434,a[2]=t12,a[3]=((C_word*)t0)[8],a[4]=t7,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 204  test */
t14=((C_word*)t0)[8];
f_2998(t14,t13,t12,lf[52]);}
else{
t12=(C_word)C_eqp(t9,lf[53]);
if(C_truep(t12)){
t13=(C_word)C_i_caddr(t7);
t14=(C_word)C_i_car(t7);
t15=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3494,a[2]=t9,a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t13,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t3,a[9]=t14,a[10]=t5,a[11]=t7,a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[8],tmp=(C_word)a,a+=14,tmp);
/* optimizer.scm: 214  test */
t16=((C_word*)t0)[8];
f_2998(t16,t15,t14,lf[62]);}
else{
t13=(C_word)C_eqp(t9,lf[14]);
if(C_truep(t13)){
t14=(C_word)C_i_car(t5);
t15=(C_word)C_slot(t14,C_fix(1));
t16=(C_word)C_eqp(t15,lf[8]);
if(C_truep(t16)){
t17=(C_word)C_slot(t14,C_fix(2));
t18=(C_word)C_i_car(t17);
t19=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3670,a[2]=((C_word*)t0)[2],a[3]=t14,a[4]=((C_word*)t0)[8],a[5]=t7,a[6]=t9,a[7]=t2,a[8]=((C_word*)t0)[4],a[9]=t18,a[10]=((C_word*)t0)[3],a[11]=t3,a[12]=t1,a[13]=((C_word*)t0)[5],a[14]=((C_word*)t0)[9],a[15]=t5,tmp=(C_word)a,a+=16,tmp);
t20=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4303,a[2]=t18,a[3]=((C_word*)t0)[8],a[4]=t19,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 252  test */
t21=((C_word*)t0)[8];
f_2998(t21,t20,t18,lf[76]);}
else{
t17=(C_word)C_eqp(t15,lf[53]);
if(C_truep(t17)){
if(C_truep((C_word)C_i_car(t7))){
/* optimizer.scm: 365  walk-generic */
t18=((C_word*)((C_word*)t0)[4])[1];
f_4453(t18,t1,t2,t9,t7,t5,t3);}
else{
t18=(C_word)C_i_cdr(t7);
t19=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,t18);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4328,a[2]=t19,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t21=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4333,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* map */
t22=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t22+1)))(4,t22,t20,t21,t5);}}
else{
/* optimizer.scm: 367  walk-generic */
t18=((C_word*)((C_word*)t0)[4])[1];
f_4453(t18,t1,t2,t9,t7,t5,t3);}}}
else{
t14=(C_word)C_eqp(t9,lf[15]);
if(C_truep(t14)){
t15=(C_word)C_i_car(t7);
t16=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4359,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=t5,a[7]=t7,a[8]=t15,a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 371  test */
t17=((C_word*)t0)[8];
f_2998(t17,t16,t15,lf[51]);}
else{
/* optimizer.scm: 384  walk-generic */
t15=((C_word*)((C_word*)t0)[4])[1];
f_4453(t15,t1,t2,t9,t7,t5,t3);}}}}}}

/* k4357 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4359,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4362,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t1)){
t3=t2;
f_4362(2,t3,t1);}
else{
/* optimizer.scm: 371  test */
t3=((C_word*)t0)[2];
f_2998(t3,t2,((C_word*)t0)[8],lf[49]);}}

/* k4360 in k4357 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4362,2,t0,t1);}
if(C_truep(t1)){
t2=f_3024(((C_word*)t0)[10]);
t3=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[35],lf[69],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4374,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4445,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 374  test */
t4=((C_word*)t0)[2];
f_2998(t4,t3,((C_word*)t0)[8],lf[101]);}}

/* k4443 in k4360 in k4357 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4445,2,t0,t1);}
t2=(C_word)C_i_not(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4403,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_4403(t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4441,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 375  variable-visible? */
((C_proc3)C_retrieve_symbol_proc(lf[100]))(3,*((C_word*)lf[100]+1),t4,((C_word*)t0)[2]);}}

/* k4439 in k4443 in k4360 in k4357 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4403(t2,(C_word)C_i_not(t1));}

/* k4401 in k4443 in k4360 in k4357 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_4403(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4403,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4434,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 376  test */
t3=((C_word*)t0)[3];
f_2998(t3,t2,((C_word*)t0)[2],lf[99]);}
else{
t2=((C_word*)t0)[6];
f_4374(t2,C_SCHEME_FALSE);}}

/* k4432 in k4401 in k4443 in k4360 in k4357 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4434,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
f_4374(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4430,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 377  test */
t3=((C_word*)t0)[3];
f_2998(t3,t2,((C_word*)t0)[2],lf[75]);}}

/* k4428 in k4432 in k4401 in k4443 in k4360 in k4357 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4430,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4374(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4422,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 378  expression-has-side-effects? */
((C_proc4)C_retrieve_symbol_proc(lf[73]))(4,*((C_word*)lf[73]+1),t2,t3,((C_word*)t0)[2]);}}

/* k4420 in k4428 in k4432 in k4401 in k4443 in k4360 in k4357 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4374(t2,(C_word)C_i_not(t1));}

/* k4372 in k4360 in k4357 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_4374(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4374,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_3024(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4380,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 380  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),t3,lf[6],lf[98],((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4393,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* optimizer.scm: 382  walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3120(t4,t2,t3,((C_word*)t0)[2]);}}

/* k4391 in k4372 in k4360 in k4357 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4393,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[35],lf[15],((C_word*)t0)[2],t2));}

/* k4378 in k4372 in k4360 in k4357 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4380,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[35],lf[69],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}

/* a4332 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4333(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4333,3,t0,t1,t2);}
/* walk137 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3120(t3,t1,t2,((C_word*)t0)[2]);}

/* k4326 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4328,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[35],lf[14],((C_word*)t0)[2],t1));}

/* k4301 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4303,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3670(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4293,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 253  test */
t3=((C_word*)t0)[3];
f_2998(t3,t2,((C_word*)t0)[2],lf[45]);}}

/* k4291 in k4301 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3670(2,t2,t1);}
else{
/* optimizer.scm: 254  test */
t2=((C_word*)t0)[3];
f_2998(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[97]);}}

/* k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3670,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[15]);
t3=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_3679,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t2,a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=t1,tmp=(C_word)a,a+=18,tmp);
/* optimizer.scm: 256  test */
t4=((C_word*)t0)[4];
f_2998(t4,t3,((C_word*)t0)[9],lf[51]);}

/* k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3679,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[17],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3688,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=t3,a[6]=((C_word*)t0)[17],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],a[10]=((C_word*)t0)[16],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 259  check-signature */
((C_proc5)C_retrieve_symbol_proc(lf[67]))(5,*((C_word*)lf[67]+1),t4,((C_word*)t0)[10],((C_word*)t0)[12],t3);}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[10],C_retrieve(lf[68])))){
t2=(C_word)C_i_car(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3746,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t2)){
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_eqp(lf[8],t4);
if(C_truep(t5)){
t6=(C_word)C_slot(t2,C_fix(2));
t7=(C_word)C_i_car(t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3767,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[10],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3871,a[2]=t7,a[3]=((C_word*)t0)[4],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 270  test */
t10=((C_word*)t0)[4];
f_2998(t10,t9,t7,lf[76]);}
else{
t8=t3;
f_3746(t8,C_SCHEME_FALSE);}}
else{
t6=t3;
f_3746(t6,C_SCHEME_FALSE);}}
else{
t4=t3;
f_3746(t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_3885,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
if(C_truep(((C_word*)t0)[17])){
t3=(C_word)C_slot(((C_word*)t0)[17],C_fix(1));
t4=t2;
f_3885(t4,(C_word)C_eqp(lf[53],t3));}
else{
t3=t2;
f_3885(t3,C_SCHEME_FALSE);}}}}

/* k3883 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_3885(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3885,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[17],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_3896,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t3,a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=t2,tmp=(C_word)a,a+=19,tmp);
/* optimizer.scm: 286  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[60]))(4,*((C_word*)lf[60]+1),((C_word*)t0)[2],t3,t4);}
else{
/* optimizer.scm: 362  walk-generic */
t2=((C_word*)((C_word*)t0)[10])[1];
f_4453(t2,((C_word*)t0)[2],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[14]);}}

/* a3895 in k3883 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3896(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[30],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3896,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[18]);
t6=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3906,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t3,a[12]=t5,a[13]=((C_word*)t0)[18],a[14]=((C_word*)t0)[10],a[15]=((C_word*)t0)[11],a[16]=((C_word*)t0)[12],a[17]=((C_word*)t0)[13],a[18]=((C_word*)t0)[14],a[19]=((C_word*)t0)[15],a[20]=t1,a[21]=((C_word*)t0)[16],a[22]=((C_word*)t0)[17],tmp=(C_word)a,a+=23,tmp);
if(C_truep(C_retrieve(lf[91]))){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4245,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[18],a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 291  test */
t8=((C_word*)t0)[3];
f_2998(t8,t7,((C_word*)t0)[10],lf[96]);}
else{
t7=t6;
f_3906(t7,C_SCHEME_FALSE);}}

/* k4243 in a3895 in k3883 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4245,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4277,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 292  test */
t3=((C_word*)t0)[3];
f_2998(t3,t2,((C_word*)t0)[2],lf[65]);}
else{
t2=((C_word*)t0)[6];
f_3906(t2,C_SCHEME_FALSE);}}

/* k4275 in k4243 in a3895 in k3883 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4277,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3906(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4254,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t2,((C_word*)t0)[2],lf[95]);}}

/* k4252 in k4275 in k4243 in a3895 in k3883 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_eqp(t1,lf[92]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_3906(t3,C_SCHEME_TRUE);}
else{
t3=(C_word)C_eqp(t1,lf[93]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
f_3906(t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cadddr(((C_word*)t0)[2]);
t5=C_retrieve(lf[94]);
t6=((C_word*)t0)[3];
f_3906(t6,(C_word)C_fixnum_lessp(t4,t5));}}}

/* k3904 in a3895 in k3883 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_3906(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3906,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3909,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[16],a[5]=((C_word*)t0)[17],a[6]=((C_word*)t0)[18],a[7]=((C_word*)t0)[19],a[8]=((C_word*)t0)[20],a[9]=((C_word*)t0)[21],a[10]=((C_word*)t0)[22],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3969,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[14],a[4]=t2,a[5]=((C_word*)t0)[13],tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t3,((C_word*)t0)[14],lf[81]);}
else{
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_3978,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[17],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[14],a[8]=((C_word*)t0)[15],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[21],a[11]=((C_word*)t0)[22],a[12]=((C_word*)t0)[19],a[13]=((C_word*)t0)[6],a[14]=((C_word*)t0)[7],a[15]=((C_word*)t0)[8],a[16]=((C_word*)t0)[9],a[17]=((C_word*)t0)[20],a[18]=((C_word*)t0)[10],a[19]=((C_word*)t0)[11],a[20]=((C_word*)t0)[16],tmp=(C_word)a,a+=21,tmp);
/* optimizer.scm: 311  test */
t3=((C_word*)t0)[4];
f_2998(t3,t2,((C_word*)t0)[12],lf[62]);}}

/* k3976 in k3904 in a3895 in k3883 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3978,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[20]);
t3=((C_word*)t0)[19];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
/* optimizer.scm: 313  walk-generic */
t4=((C_word*)((C_word*)t0)[18])[1];
f_4453(t4,((C_word*)t0)[17],((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14],((C_word*)t0)[13],((C_word*)t0)[12]);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3992,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t5,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp));
t7=((C_word*)t5)[1];
f_3992(t7,((C_word*)t0)[17],((C_word*)t0)[5],((C_word*)t0)[19],((C_word*)t0)[20],C_SCHEME_END_OF_LIST);}}
else{
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4143,a[2]=((C_word*)t0)[16],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[15],a[12]=((C_word*)t0)[17],a[13]=((C_word*)t0)[18],a[14]=((C_word*)t0)[20],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4232,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[16],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 337  test */
t4=((C_word*)t0)[6];
f_2998(t4,t3,((C_word*)t0)[2],lf[58]);}}

/* k4230 in k3976 in k3904 in a3895 in k3883 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_memq(((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=((C_word*)t0)[2];
f_4143(t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
f_4143(t2,C_SCHEME_FALSE);}}

/* k4141 in k3976 in k3904 in a3895 in k3883 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_4143(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4143,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4146,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
/* optimizer.scm: 339  llist-length */
((C_proc3)C_retrieve_symbol_proc(lf[90]))(3,*((C_word*)lf[90]+1),t2,((C_word*)t0)[3]);}
else{
/* optimizer.scm: 361  walk-generic */
t2=((C_word*)((C_word*)t0)[13])[1];
f_4453(t2,((C_word*)t0)[12],((C_word*)t0)[2],((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}}

/* k4144 in k4141 in k3976 in k3904 in a3895 in k3883 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4146,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[12]);
t3=t1;
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
/* optimizer.scm: 341  walk-generic */
t4=((C_word*)((C_word*)t0)[11])[1];
f_4453(t4,((C_word*)t0)[10],t1,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4158,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 343  debugging */
((C_proc6)C_retrieve_symbol_proc(lf[5]))(6,*((C_word*)lf[5]+1),t4,lf[6],lf[89],((C_word*)t0)[2],t1);}}

/* k4156 in k4144 in k4141 in k3976 in k3904 in a3895 in k3883 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4158,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4163,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4169,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a4168 in k4156 in k4144 in k4141 in k3976 in k3904 in a3895 in k3883 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4169(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[29],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4169,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4173,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4182,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4194,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4202,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* optimizer.scm: 354  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t7,C_SCHEME_END_OF_LIST);}
else{
t8=(C_word)C_i_length(t3);
t9=(C_word)C_fixnum_times(C_fix(3),t8);
t10=(C_word)C_a_i_list(&a,2,lf[87],t9);
t11=t7;
f_4202(2,t11,(C_word)C_a_i_record(&a,4,lf[35],lf[88],t10,t3));}}

/* k4200 in a4168 in k4156 in k4144 in k4141 in k3976 in k3904 in a3895 in k3883 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4202,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 350  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4192 in a4168 in k4156 in k4144 in k4141 in k3976 in k3904 in a3895 in k3883 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4194,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* map */
t3=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a4181 in a4168 in k4156 in k4144 in k4141 in k3976 in k3904 in a3895 in k3883 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4182(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4182,3,t0,t1,t2);}
/* walk137 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3120(t3,t1,t2,((C_word*)t0)[2]);}

/* k4171 in a4168 in k4156 in k4144 in k4141 in k3976 in k3904 in a3895 in k3883 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4173,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,4,lf[35],lf[14],((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* a4162 in k4156 in k4144 in k4141 in k3976 in k3904 in a3895 in k3883 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4163,2,t0,t1);}
/* optimizer.scm: 344  split-at */
((C_proc4)C_retrieve_symbol_proc(lf[86]))(4,*((C_word*)lf[86]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k3976 in k3904 in a3895 in k3883 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_3992(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3992,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_nullp(t2);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t3,C_fix(0)));
if(C_truep(t7)){
t8=f_3024(((C_word*)t0)[10]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4008,a[2]=((C_word*)t0)[9],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4013,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4025,a[2]=t10,a[3]=t9,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 320  append-reverse */
((C_proc4)C_retrieve_symbol_proc(lf[82]))(4,*((C_word*)lf[82]+1),t11,t5,t4);}
else{
t8=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4031,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t5,a[7]=((C_word*)t0)[5],a[8]=t4,a[9]=t3,a[10]=t2,a[11]=t1,a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
t9=(C_word)C_i_car(t2);
/* optimizer.scm: 321  test */
t10=((C_word*)t0)[2];
f_2998(t10,t8,t9,lf[54]);}}

/* k4029 in loop in k3976 in k3904 in a3895 in k3883 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4031,2,t0,t1);}
if(C_truep(t1)){
t2=f_3024(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4037,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[10]);
/* optimizer.scm: 323  debugging */
((C_proc6)C_retrieve_symbol_proc(lf[5]))(6,*((C_word*)lf[5]+1),t3,lf[6],lf[85],t4,((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[10]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[9]);
t4=(C_word)C_i_cdr(((C_word*)t0)[8]);
t5=(C_word)C_i_car(((C_word*)t0)[8]);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[6]);
/* optimizer.scm: 333  loop */
t7=((C_word*)((C_word*)t0)[7])[1];
f_3992(t7,((C_word*)t0)[11],t2,t3,t4,t6);}}

/* k4035 in k4029 in loop in k3976 in k3904 in a3895 in k3883 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4037,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4043,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
/* optimizer.scm: 326  expression-has-side-effects? */
((C_proc4)C_retrieve_symbol_proc(lf[73]))(4,*((C_word*)lf[73]+1),t2,t3,((C_word*)t0)[2]);}

/* k4041 in k4035 in k4029 in loop in k3976 in k3904 in a3895 in k3883 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4043,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4080,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 329  gensym */
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t2,lf[84]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[7]);
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* optimizer.scm: 332  loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_3992(t5,((C_word*)t0)[9],t2,t3,t4,((C_word*)t0)[4]);}}

/* k4078 in k4041 in k4035 in k4029 in loop in k3976 in k3904 in a3895 in k3883 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4080,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4056,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t2,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[6]);
/* optimizer.scm: 330  walk */
t5=((C_word*)((C_word*)t0)[3])[1];
f_3120(t5,t3,t4,((C_word*)t0)[2]);}

/* k4054 in k4078 in k4041 in k4035 in k4029 in loop in k3976 in k3904 in a3895 in k3883 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4056,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4060,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 331  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_3992(t6,t2,t3,t4,t5,((C_word*)t0)[2]);}

/* k4058 in k4054 in k4078 in k4041 in k4035 in k4029 in loop in k3976 in k3904 in a3895 in k3883 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4060,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[35],lf[10],((C_word*)t0)[2],t2));}

/* k4023 in loop in k3976 in k3904 in a3895 in k3883 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4025,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* map */
t3=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a4012 in loop in k3976 in k3904 in a3895 in k3883 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4013(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4013,3,t0,t1,t2);}
/* walk137 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3120(t3,t1,t2,((C_word*)t0)[2]);}

/* k4006 in loop in k3976 in k3904 in a3895 in k3883 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_4008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4008,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[35],lf[14],((C_word*)t0)[2],t1));}

/* k3967 in k3904 in a3895 in k3883 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_structurep(t1,lf[35]);
t3=(C_truep(t2)?lf[78]:lf[79]);
t4=(C_word)C_i_cadddr(((C_word*)t0)[5]);
/* optimizer.scm: 298  debugging */
((C_proc7)C_retrieve_symbol_proc(lf[5]))(7,*((C_word*)lf[5]+1),((C_word*)t0)[4],lf[80],t3,((C_word*)t0)[3],((C_word*)t0)[2],t4);}

/* k3907 in k3904 in a3895 in k3883 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3909,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3912,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3938,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_3938(t6,t2,((C_word*)t0)[7]);}

/* loop440 in k3907 in k3904 in a3895 in k3883 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_3938(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3938,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3951,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##compiler#put! */
((C_proc6)C_retrieve_symbol_proc(lf[64]))(6,*((C_word*)lf[64]+1),t4,((C_word*)t0)[2],t3,lf[65],C_SCHEME_TRUE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k3949 in loop440 in k3907 in k3904 in a3895 in k3883 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3938(t3,((C_word*)t0)[2],t2);}

/* k3910 in k3907 in k3904 in a3895 in k3883 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3912,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3915,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 305  check-signature */
((C_proc5)C_retrieve_symbol_proc(lf[67]))(5,*((C_word*)lf[67]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k3913 in k3910 in k3907 in k3904 in a3895 in k3883 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3918,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 306  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),t2,lf[6],lf[77],((C_word*)t0)[2]);}

/* k3916 in k3913 in k3910 in k3907 in k3904 in a3895 in k3883 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3918,2,t0,t1);}
t2=f_3024(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3928,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(3));
t5=(C_word)C_i_car(t4);
/* optimizer.scm: 309  inline-lambda-bindings */
((C_proc7)C_retrieve_symbol_proc(lf[63]))(7,*((C_word*)lf[63]+1),t3,((C_word*)t0)[4],((C_word*)t0)[3],t5,C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* k3926 in k3916 in k3913 in k3910 in k3907 in k3904 in a3895 in k3883 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 308  walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3120(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3869 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3767(2,t2,C_SCHEME_FALSE);}
else{
/* optimizer.scm: 270  test */
t2=((C_word*)t0)[3];
f_2998(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[45]);}}

/* k3765 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3767,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(1));
t3=(C_word)C_eqp(lf[53],t2);
if(C_truep(t3)){
t4=(C_word)C_slot(t1,C_fix(2));
t5=(C_word)C_i_caddr(t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3788,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t7=(C_word)C_i_car(t5);
/* optimizer.scm: 273  test */
t8=((C_word*)t0)[2];
f_2998(t8,t6,t7,lf[54]);}
else{
t6=((C_word*)t0)[7];
f_3746(t6,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[7];
f_3746(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[7];
f_3746(t2,C_SCHEME_FALSE);}}

/* k3786 in k3765 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3788,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3791,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_3791(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3845,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 274  test */
t5=((C_word*)t0)[2];
f_2998(t5,t3,t4,lf[75]);}}

/* k3843 in k3786 in k3765 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3845,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3791(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3837,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 275  test */
t4=((C_word*)t0)[2];
f_2998(t4,t2,t3,lf[74]);}}

/* k3835 in k3843 in k3786 in k3765 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3791(t2,(C_word)C_i_not(t1));}

/* k3789 in k3786 in k3765 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_3791(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3791,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3814,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3816,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* optimizer.scm: 276  any */
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),t2,t3,t4);}
else{
t2=((C_word*)t0)[6];
f_3746(t2,C_SCHEME_FALSE);}}

/* a3815 in k3789 in k3786 in k3765 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3816(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3816,3,t0,t1,t2);}
/* ##compiler#expression-has-side-effects? */
((C_proc4)C_retrieve_symbol_proc(lf[73]))(4,*((C_word*)lf[73]+1),t1,t2,((C_word*)t0)[2]);}

/* k3812 in k3789 in k3786 in k3765 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3814,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3746(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3800,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 277  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),t2,lf[71],lf[72],((C_word*)t0)[2]);}}

/* k3798 in k3812 in k3789 in k3786 in k3765 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3800,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,4,lf[35],lf[69],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_3746(t4,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[70],t3));}

/* k3744 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_3746(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* optimizer.scm: 281  walk-generic */
t2=((C_word*)((C_word*)t0)[7])[1];
f_4453(t2,((C_word*)t0)[8],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k3686 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3688,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3691,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 260  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),t2,lf[6],lf[66],((C_word*)t0)[2]);}

/* k3689 in k3686 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3691,2,t0,t1);}
t2=f_3024(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3697,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3714,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_3714(t7,t3,((C_word*)t0)[6]);}

/* loop347 in k3689 in k3686 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_3714(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3714,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3727,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##compiler#put! */
((C_proc6)C_retrieve_symbol_proc(lf[64]))(6,*((C_word*)lf[64]+1),t4,((C_word*)t0)[2],t3,lf[65],C_SCHEME_TRUE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k3725 in loop347 in k3689 in k3686 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3714(t3,((C_word*)t0)[2],t2);}

/* k3695 in k3689 in k3686 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3697,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3704,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(3));
t4=(C_word)C_i_car(t3);
/* optimizer.scm: 264  inline-lambda-bindings */
((C_proc7)C_retrieve_symbol_proc(lf[63]))(7,*((C_word*)lf[63]+1),t2,((C_word*)t0)[4],((C_word*)t0)[3],t4,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k3702 in k3695 in k3689 in k3686 in k3677 in k3668 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 263  walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3120(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3492 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3494,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3499,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 215  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[60]))(4,*((C_word*)lf[60]+1),((C_word*)t0)[6],((C_word*)t0)[5],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3586,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* optimizer.scm: 230  test */
t3=((C_word*)t0)[13];
f_2998(t3,t2,((C_word*)t0)[9],lf[58]);}}

/* k3584 in k3492 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3586,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3591,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 231  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[60]))(4,*((C_word*)lf[60]+1),((C_word*)t0)[6],((C_word*)t0)[5],t2);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],((C_word*)t0)[8]);
/* optimizer.scm: 243  walk-generic */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4453(t3,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[11],((C_word*)t0)[10],t2);}}

/* a3590 in k3584 in k3492 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3591(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3591,5,t0,t1,t2,t3,t4);}
t5=f_3024(((C_word*)t0)[7]);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3598,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 235  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),t6,lf[6],lf[61],t4);}

/* k3596 in a3590 in k3584 in k3492 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3598,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(C_word)C_i_cadr(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3631,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t3,a[8]=t2,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t5=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
/* optimizer.scm: 240  build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[56]))(5,*((C_word*)lf[56]+1),t4,((C_word*)t0)[2],t5,C_SCHEME_FALSE);}

/* k3629 in k3596 in a3590 in k3584 in k3492 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3631,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[9]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[8],((C_word*)t0)[7],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3611,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[5]);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
/* optimizer.scm: 242  walk */
t7=((C_word*)((C_word*)t0)[2])[1];
f_3120(t7,t4,t5,t6);}

/* k3609 in k3629 in k3596 in a3590 in k3584 in k3492 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3611,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[35],lf[53],((C_word*)t0)[2],t2));}

/* a3498 in k3492 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3499(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3499,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3505,a[2]=t2,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3517,a[2]=((C_word*)t0)[8],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a3516 in a3498 in k3492 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3517,4,t0,t1,t2,t3);}
t4=f_3024(((C_word*)t0)[10]);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3524,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 220  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),t5,lf[6],lf[59],t2);}

/* k3522 in a3516 in a3498 in k3492 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3524,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[11]);
t3=(C_word)C_i_cadr(((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3557,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=t3,a[8]=t2,a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3564,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* optimizer.scm: 224  test */
t6=((C_word*)t0)[2];
f_2998(t6,t5,((C_word*)t0)[8],lf[58]);}
else{
t6=t5;
f_3564(2,t6,C_SCHEME_FALSE);}}

/* k3562 in k3522 in a3516 in a3498 in k3492 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3564,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3567,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 225  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),t2,lf[6],lf[57],((C_word*)t0)[2]);}
else{
/* optimizer.scm: 227  build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[56]))(5,*((C_word*)lf[56]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k3565 in k3562 in k3522 in a3516 in a3498 in k3492 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
/* optimizer.scm: 226  build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[56]))(5,*((C_word*)lf[56]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_FALSE);}

/* k3555 in k3522 in a3516 in a3498 in k3492 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3557,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[9]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[8],((C_word*)t0)[7],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3537,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[5]);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
/* optimizer.scm: 229  walk */
t7=((C_word*)((C_word*)t0)[2])[1];
f_3120(t7,t4,t5,t6);}

/* k3535 in k3555 in k3522 in a3516 in a3498 in k3492 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3537,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[35],lf[53],((C_word*)t0)[2],t2));}

/* a3504 in a3498 in k3492 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3511,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 218  partition */
((C_proc4)C_retrieve_symbol_proc(lf[55]))(4,*((C_word*)lf[55]+1),t1,t2,((C_word*)t0)[2]);}

/* a3510 in a3504 in a3498 in k3492 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3511(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3511,3,t0,t1,t2);}
/* optimizer.scm: 218  test */
t3=((C_word*)t0)[2];
f_2998(t3,t1,t2,lf[54]);}

/* k3432 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3434,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3437,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
t3=t2;
f_3437(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3469,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 205  test */
t4=((C_word*)t0)[3];
f_2998(t4,t3,((C_word*)t0)[2],lf[51]);}}

/* k3467 in k3432 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3469,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3476,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 205  test */
t3=((C_word*)t0)[3];
f_2998(t3,t2,((C_word*)t0)[2],lf[50]);}
else{
t2=((C_word*)t0)[4];
f_3437(t2,C_SCHEME_FALSE);}}

/* k3474 in k3467 in k3432 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3437(t2,(C_word)C_i_not(t1));}

/* k3435 in k3432 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_3437(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3437,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_3024(((C_word*)t0)[8]);
t3=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[7])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,t3);
t5=(C_word)C_i_cadr(((C_word*)t0)[6]);
/* optimizer.scm: 208  walk */
t6=((C_word*)((C_word*)t0)[5])[1];
f_3120(t6,((C_word*)t0)[4],t5,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3454,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3459,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[6]);}}

/* a3458 in k3435 in k3432 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3459(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3459,3,t0,t1,t2);}
/* walk137 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3120(t3,t1,t2,((C_word*)t0)[2]);}

/* k3452 in k3435 in k3432 in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3454,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[35],lf[10],((C_word*)t0)[2],t1));}

/* replace in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_3359(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3359,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3363,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 190  test */
t4=((C_word*)t0)[4];
f_2998(t4,t3,t2,lf[49]);}

/* k3361 in replace in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3363,2,t0,t1);}
if(C_truep(t1)){
/* replace234 */
t2=((C_word*)((C_word*)t0)[8])[1];
f_3359(t2,((C_word*)t0)[7],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3375,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 191  test */
t3=((C_word*)t0)[5];
f_2998(t3,t2,((C_word*)t0)[4],lf[48]);}}

/* k3373 in k3361 in replace in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3375,2,t0,t1);}
if(C_truep(t1)){
t2=f_3024(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3381,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 193  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),t3,lf[6],lf[46],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3398,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_eqp(((C_word*)t0)[4],t3);
if(C_truep(t4)){
t5=t2;
f_3398(t5,C_SCHEME_UNDEFINED);}
else{
t5=f_3024(((C_word*)t0)[7]);
t6=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=t2;
f_3398(t8,t7);}}}

/* k3396 in k3373 in k3361 in replace in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_3398(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 200  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[47]))(3,*((C_word*)lf[47]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3379 in k3373 in k3361 in replace in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3381,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3392,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 194  test */
t3=((C_word*)t0)[3];
f_2998(t3,t2,((C_word*)t0)[2],lf[45]);}

/* k3390 in k3379 in k3373 in k3361 in replace in walk1 in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(t1,C_fix(2));
t3=(C_word)C_i_car(t2);
/* optimizer.scm: 194  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),((C_word*)t0)[2],t3);}

/* walk in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_3120(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3120,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[32])))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=((C_word*)((C_word*)t0)[8])[1];
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3134,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t1,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 143  walk1 */
t6=((C_word*)((C_word*)t0)[2])[1];
f_3334(t6,t5,t2,t3);}}

/* k3132 in walk in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3134,2,t0,t1);}
t2=(C_word)C_slot(t1,C_fix(3));
t3=(C_word)C_slot(t1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3143,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t3,lf[9]);
if(C_truep(t5)){
t6=(C_word)C_i_car(t2);
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[25],t7);
if(C_truep(t8)){
t9=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[8])[1],C_fix(1));
t10=C_mutate(((C_word *)((C_word*)t0)[8])+1,t9);
t11=f_3024(((C_word*)t0)[7]);
t12=(C_word)C_i_car(t2);
t13=(C_word)C_slot(t12,C_fix(2));
t14=(C_word)C_i_car(t13);
t15=(C_truep(t14)?(C_word)C_i_cadr(t2):(C_word)C_i_caddr(t2));
/* optimizer.scm: 151  walk */
t16=((C_word*)((C_word*)t0)[6])[1];
f_3120(t16,t4,t15,((C_word*)t0)[5]);}
else{
t9=t4;
f_3143(2,t9,t1);}}
else{
t6=(C_word)C_eqp(t3,lf[14]);
if(C_truep(t6)){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(lf[8],t8);
if(C_truep(t9)){
t10=(C_word)C_i_car(t2);
t11=(C_word)C_slot(t10,C_fix(2));
t12=(C_word)C_i_car(t11);
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3204,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t4,a[8]=t12,tmp=(C_word)a,a+=9,tmp);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3305,a[2]=t12,a[3]=((C_word*)t0)[2],a[4]=t13,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t14,t12,lf[44]);}
else{
t10=t4;
f_3143(2,t10,t1);}}
else{
t7=t4;
f_3143(2,t7,t1);}}}

/* k3303 in k3132 in walk in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3305,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3311,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 161  foldable? */
((C_proc3)C_retrieve_symbol_proc(lf[42]))(3,*((C_word*)lf[42]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_3204(2,t2,C_SCHEME_FALSE);}}

/* k3309 in k3303 in k3132 in walk in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* optimizer.scm: 162  every */
((C_proc4)C_retrieve_symbol_proc(lf[41]))(4,*((C_word*)lf[41]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[3];
f_3204(2,t2,C_SCHEME_FALSE);}}

/* k3202 in k3132 in walk in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3204,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3284,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3286,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* map */
t5=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}
else{
t2=((C_word*)t0)[7];
f_3143(2,t2,((C_word*)t0)[6]);}}

/* a3285 in k3202 in k3132 in walk in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3286(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3286,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(2));
t4=(C_word)C_i_car(t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[25],t5));}

/* k3282 in k3202 in k3132 in walk in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3284,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3213,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3215,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[18]+1)))(3,*((C_word*)lf[18]+1),t3,t4);}

/* a3214 in k3282 in k3202 in k3132 in walk in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3215(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3215,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3221,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3238,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[40]))(4,*((C_word*)lf[40]+1),t1,t3,t4);}

/* a3237 in a3214 in k3282 in k3202 in k3132 in walk in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3244,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3270,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a3269 in a3237 in a3214 in k3282 in k3202 in k3132 in walk in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3270(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3270r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3270r(t0,t1,t2);}}

static void C_ccall f_3270r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3276,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k205208 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3275 in a3269 in a3237 in a3214 in k3282 in k3202 in k3132 in walk in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3276,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3243 in a3237 in a3214 in k3282 in k3202 in k3132 in walk in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3244,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3248,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 170  eval */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t2,((C_word*)t0)[2]);}

/* k3246 in a3243 in a3237 in a3214 in k3282 in k3202 in k3132 in walk in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3248,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3251,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 171  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),t2,lf[6],lf[38],((C_word*)t0)[2]);}

/* k3249 in k3246 in a3243 in a3237 in a3214 in k3282 in k3202 in k3132 in walk in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3251,2,t0,t1);}
t2=f_3024(((C_word*)t0)[5]);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3268,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 176  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t4,((C_word*)t0)[2]);}

/* k3266 in k3249 in k3246 in a3243 in a3237 in a3214 in k3282 in k3202 in k3132 in walk in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3268,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[36],t2));}

/* a3220 in a3214 in k3282 in k3202 in k3132 in walk in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3221(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3221,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3227,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* k205208 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3226 in a3220 in a3214 in k3282 in k3202 in k3132 in walk in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3227,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3231,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3231(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t4=t2;
f_3231(t4,t3);}}

/* k3229 in a3226 in a3220 in a3214 in k3282 in k3202 in k3132 in walk in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_3231(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3231,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3235,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 168  lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[33]))(5,*((C_word*)lf[33]+1),t2,*((C_word*)lf[34]+1),C_retrieve(lf[32]),((C_word*)t0)[2]);}

/* k3233 in k3229 in a3226 in a3220 in a3214 in k3282 in k3202 in k3132 in walk in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[32]+1 /* (set! broken-constant-nodes ...) */,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* k3211 in k3282 in k3202 in k3132 in walk in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k3141 in k3132 in walk in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 141  simplify */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3028(t2,((C_word*)t0)[2],t1);}

/* simplify in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_3028(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3028,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3032,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
/* optimizer.scm: 122  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[31]))(4,*((C_word*)lf[31]+1),t3,C_retrieve(lf[21]),t5);}

/* k3030 in simplify in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3032,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3035,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3043,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 123  any */
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),t2,t3,t1);}
else{
t3=t2;
f_3035(2,t3,C_SCHEME_FALSE);}}

/* a3042 in k3030 in simplify in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3043(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3043,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3053,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_i_car(t2);
/* optimizer.scm: 125  match-node */
((C_proc5)C_retrieve_symbol_proc(lf[29]))(5,*((C_word*)lf[29]+1),t4,((C_word*)t0)[2],t5,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k3051 in a3042 in k3030 in simplify in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3053,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3059,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3100,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3102,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a3101 in k3051 in a3042 in k3030 in simplify in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3102(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3102,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k3098 in k3051 in a3042 in k3030 in simplify in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3057 in k3051 in a3042 in k3030 in simplify in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3059,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3065,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 128  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[27]+1)))(3,*((C_word*)lf[27]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3063 in k3057 in k3051 in a3042 in k3030 in simplify in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3065,2,t0,t1);}
t2=(C_word)C_i_assq(t1,((C_word*)((C_word*)t0)[6])[1]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3071,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_fixnum_increase(t4);
t6=t3;
f_3071(t6,(C_word)C_i_set_cdr(t2,t5));}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3092,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 132  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t4,t1,C_fix(1),((C_word*)((C_word*)t0)[6])[1]);}}

/* k3090 in k3063 in k3057 in k3051 in a3042 in k3030 in simplify in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3071(t3,t2);}

/* k3069 in k3063 in k3057 in k3051 in a3042 in k3030 in simplify in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_3071(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_3024(((C_word*)t0)[5]);
/* optimizer.scm: 134  simplify */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3028(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3033 in k3030 in simplify in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* touch in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static C_word C_fcall f_3024(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
return(t1);}

/* constant-node? in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_3004(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3004,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[25],t3));}

/* test in ##compiler#perform-high-level-optimizations in k2990 in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_2998(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2998,NULL,4,t0,t1,t2,t3);}
/* optimizer.scm: 116  get */
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),t1,((C_word*)t0)[2],t2,t3);}

/* ##compiler#scan-toplevel-assignments in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_2725(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2725,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2728,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2746,a[2]=t2,a[3]=t7,a[4]=t6,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 48   debugging */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t8,lf[19],lf[20]);}

/* k2744 in ##compiler#scan-toplevel-assignments in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_2746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2746,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2749,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2806,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 49   call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[18]+1)))(3,*((C_word*)lf[18]+1),t2,t3);}

/* a2805 in k2744 in ##compiler#scan-toplevel-assignments in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_2806(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2806,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2809,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2837,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
/* optimizer.scm: 84   scan */
t9=((C_word*)t6)[1];
f_2837(t9,t1,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* scan in a2805 in k2744 in ##compiler#scan-toplevel-assignments in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_2837(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2837,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(2));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[8]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t5);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2862,a[2]=t1,a[3]=((C_word*)t0)[7],a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t11,t3))){
t13=t12;
f_2862(t13,C_SCHEME_FALSE);}
else{
t13=(C_word)C_i_memq(t11,((C_word*)((C_word*)t0)[6])[1]);
t14=t12;
f_2862(t14,(C_word)C_i_not(t13));}}
else{
t11=(C_word)C_eqp(t9,lf[9]);
t12=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2889,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t9,a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=t7,a[9]=t1,a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t11)){
t13=t12;
f_2889(t13,t11);}
else{
t13=(C_word)C_eqp(t9,lf[16]);
t14=t12;
f_2889(t14,(C_truep(t13)?t13:(C_word)C_eqp(t9,lf[17])));}}}

/* k2887 in scan in a2805 in k2744 in ##compiler#scan-toplevel-assignments in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_2889(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2889,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2892,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[8]);
/* optimizer.scm: 66   scan */
t4=((C_word*)((C_word*)t0)[7])[1];
f_2837(t4,t2,t3,((C_word*)t0)[6]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[10]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2908,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[8]);
/* optimizer.scm: 70   scan */
t5=((C_word*)((C_word*)t0)[7])[1];
f_2837(t5,t3,t4,((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[12]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[13]));
if(C_truep(t4)){
t5=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[14]);
if(C_truep(t5)){
/* optimizer.scm: 75   return */
t6=((C_word*)t0)[10];
((C_proc3)C_retrieve_proc(t6))(3,t6,((C_word*)t0)[9],C_SCHEME_FALSE);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[15]);
if(C_truep(t6)){
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(C_truep((C_word)C_i_memq(t7,((C_word*)t0)[6]))?C_SCHEME_UNDEFINED:f_2728(C_a_i(&a,3),((C_word*)t0)[3],t7));
t9=(C_word)C_i_car(((C_word*)t0)[8]);
/* optimizer.scm: 80   scan */
t10=((C_word*)((C_word*)t0)[7])[1];
f_2837(t10,((C_word*)t0)[9],t9,((C_word*)t0)[6]);}
else{
/* optimizer.scm: 82   scan-each */
t7=((C_word*)((C_word*)t0)[2])[1];
f_2809(t7,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[6]);}}}}}}

/* k2906 in k2887 in scan in a2805 in k2744 in ##compiler#scan-toplevel-assignments in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_2908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2908,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2919,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 71   append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2917 in k2906 in k2887 in scan in a2805 in k2744 in ##compiler#scan-toplevel-assignments in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_2919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 71   scan */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2837(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2890 in k2887 in scan in a2805 in k2744 in ##compiler#scan-toplevel-assignments in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_2892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 67   return */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2860 in scan in a2805 in k2744 in ##compiler#scan-toplevel-assignments in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_2862(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2862,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* scan-each in a2805 in k2744 in ##compiler#scan-toplevel-assignments in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_2809(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2809,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2815,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_2815(t7,t1,t2);}

/* loop43 in scan-each in a2805 in k2744 in ##compiler#scan-toplevel-assignments in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_2815(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2815,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2828,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 53   scan */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2837(t5,t4,t3,((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2826 in loop43 in scan-each in a2805 in k2744 in ##compiler#scan-toplevel-assignments in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_2828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2815(t3,((C_word*)t0)[2],t2);}

/* k2747 in k2744 in ##compiler#scan-toplevel-assignments in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_2749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2749,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2752,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 85   debugging */
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),t2,lf[6],lf[7],((C_word*)((C_word*)t0)[2])[1]);}

/* k2750 in k2747 in k2744 in ##compiler#scan-toplevel-assignments in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_2752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2752,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2757,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2757(t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* loop89 in k2750 in k2747 in k2744 in ##compiler#scan-toplevel-assignments in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_fcall f_2757(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2757,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2797,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2772,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
t7=t6;
f_2772(2,t7,C_SCHEME_TRUE);}
else{
t7=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t7))){
t8=t6;
f_2772(2,t8,(C_word)C_i_car(t5));}
else{
/* ##sys#error */
t8=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,lf[4],t5);}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2770 in loop89 in k2750 in k2747 in k2744 in ##compiler#scan-toplevel-assignments in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_2772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[2],t1);}

/* k2795 in loop89 in k2750 in k2747 in k2744 in ##compiler#scan-toplevel-assignments in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static void C_ccall f_2797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2757(t3,((C_word*)t0)[2],t2);}

/* mark in ##compiler#scan-toplevel-assignments in k2721 in k2718 in k2715 in k2712 in k2709 in k2706 */
static C_word C_fcall f_2728(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
if(C_truep((C_word)C_i_memq(t1,((C_word*)((C_word*)t0)[3])[1]))){
return(C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t3);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[638] = {
{"toplevel:optimizer_scm",(void*)C_optimizer_toplevel},
{"f_2708:optimizer_scm",(void*)f_2708},
{"f_2711:optimizer_scm",(void*)f_2711},
{"f_2714:optimizer_scm",(void*)f_2714},
{"f_2717:optimizer_scm",(void*)f_2717},
{"f_2720:optimizer_scm",(void*)f_2720},
{"f_2723:optimizer_scm",(void*)f_2723},
{"f_2992:optimizer_scm",(void*)f_2992},
{"f_11686:optimizer_scm",(void*)f_11686},
{"f_11694:optimizer_scm",(void*)f_11694},
{"f_11699:optimizer_scm",(void*)f_11699},
{"f_11744:optimizer_scm",(void*)f_11744},
{"f_11748:optimizer_scm",(void*)f_11748},
{"f_11709:optimizer_scm",(void*)f_11709},
{"f_11733:optimizer_scm",(void*)f_11733},
{"f_11718:optimizer_scm",(void*)f_11718},
{"f_4854:optimizer_scm",(void*)f_4854},
{"f_10683:optimizer_scm",(void*)f_10683},
{"f_10717:optimizer_scm",(void*)f_10717},
{"f_10819:optimizer_scm",(void*)f_10819},
{"f_10829:optimizer_scm",(void*)f_10829},
{"f_11103:optimizer_scm",(void*)f_11103},
{"f_11095:optimizer_scm",(void*)f_11095},
{"f_10905:optimizer_scm",(void*)f_10905},
{"f_10934:optimizer_scm",(void*)f_10934},
{"f_11071:optimizer_scm",(void*)f_11071},
{"f_11063:optimizer_scm",(void*)f_11063},
{"f_10950:optimizer_scm",(void*)f_10950},
{"f_10997:optimizer_scm",(void*)f_10997},
{"f_10987:optimizer_scm",(void*)f_10987},
{"f_10995:optimizer_scm",(void*)f_10995},
{"f_11157:optimizer_scm",(void*)f_11157},
{"f_11170:optimizer_scm",(void*)f_11170},
{"f_11205:optimizer_scm",(void*)f_11205},
{"f_11189:optimizer_scm",(void*)f_11189},
{"f_11193:optimizer_scm",(void*)f_11193},
{"f_11182:optimizer_scm",(void*)f_11182},
{"f_11371:optimizer_scm",(void*)f_11371},
{"f_11384:optimizer_scm",(void*)f_11384},
{"f_11390:optimizer_scm",(void*)f_11390},
{"f_11436:optimizer_scm",(void*)f_11436},
{"f_11428:optimizer_scm",(void*)f_11428},
{"f_11412:optimizer_scm",(void*)f_11412},
{"f_11416:optimizer_scm",(void*)f_11416},
{"f_11420:optimizer_scm",(void*)f_11420},
{"f_4857:optimizer_scm",(void*)f_4857},
{"f_10361:optimizer_scm",(void*)f_10361},
{"f_10383:optimizer_scm",(void*)f_10383},
{"f_10438:optimizer_scm",(void*)f_10438},
{"f_10408:optimizer_scm",(void*)f_10408},
{"f_10430:optimizer_scm",(void*)f_10430},
{"f_10434:optimizer_scm",(void*)f_10434},
{"f_10426:optimizer_scm",(void*)f_10426},
{"f_10406:optimizer_scm",(void*)f_10406},
{"f_10532:optimizer_scm",(void*)f_10532},
{"f_10546:optimizer_scm",(void*)f_10546},
{"f_4860:optimizer_scm",(void*)f_4860},
{"f_5220:optimizer_scm",(void*)f_5220},
{"f_8306:optimizer_scm",(void*)f_8306},
{"f_10240:optimizer_scm",(void*)f_10240},
{"f_10243:optimizer_scm",(void*)f_10243},
{"f_10246:optimizer_scm",(void*)f_10246},
{"f_10249:optimizer_scm",(void*)f_10249},
{"f_10252:optimizer_scm",(void*)f_10252},
{"f_10255:optimizer_scm",(void*)f_10255},
{"f_10332:optimizer_scm",(void*)f_10332},
{"f_10258:optimizer_scm",(void*)f_10258},
{"f_10261:optimizer_scm",(void*)f_10261},
{"f_10264:optimizer_scm",(void*)f_10264},
{"f_10326:optimizer_scm",(void*)f_10326},
{"f_10267:optimizer_scm",(void*)f_10267},
{"f_10270:optimizer_scm",(void*)f_10270},
{"f_10323:optimizer_scm",(void*)f_10323},
{"f_8979:optimizer_scm",(void*)f_8979},
{"f_8997:optimizer_scm",(void*)f_8997},
{"f_9003:optimizer_scm",(void*)f_9003},
{"f_8983:optimizer_scm",(void*)f_8983},
{"f_10273:optimizer_scm",(void*)f_10273},
{"f_10315:optimizer_scm",(void*)f_10315},
{"f_10313:optimizer_scm",(void*)f_10313},
{"f_10276:optimizer_scm",(void*)f_10276},
{"f_10279:optimizer_scm",(void*)f_10279},
{"f_10282:optimizer_scm",(void*)f_10282},
{"f_10306:optimizer_scm",(void*)f_10306},
{"f_10285:optimizer_scm",(void*)f_10285},
{"f_10288:optimizer_scm",(void*)f_10288},
{"f_10291:optimizer_scm",(void*)f_10291},
{"f_10294:optimizer_scm",(void*)f_10294},
{"f_10297:optimizer_scm",(void*)f_10297},
{"f_10300:optimizer_scm",(void*)f_10300},
{"f_10024:optimizer_scm",(void*)f_10024},
{"f_10030:optimizer_scm",(void*)f_10030},
{"f_10216:optimizer_scm",(void*)f_10216},
{"f_10226:optimizer_scm",(void*)f_10226},
{"f_10190:optimizer_scm",(void*)f_10190},
{"f_10200:optimizer_scm",(void*)f_10200},
{"f_10165:optimizer_scm",(void*)f_10165},
{"f_10174:optimizer_scm",(void*)f_10174},
{"f_10177:optimizer_scm",(void*)f_10177},
{"f_10135:optimizer_scm",(void*)f_10135},
{"f_10145:optimizer_scm",(void*)f_10145},
{"f_10049:optimizer_scm",(void*)f_10049},
{"f_10054:optimizer_scm",(void*)f_10054},
{"f_10095:optimizer_scm",(void*)f_10095},
{"f_10092:optimizer_scm",(void*)f_10092},
{"f_10077:optimizer_scm",(void*)f_10077},
{"f_10088:optimizer_scm",(void*)f_10088},
{"f_10084:optimizer_scm",(void*)f_10084},
{"f_9891:optimizer_scm",(void*)f_9891},
{"f_9897:optimizer_scm",(void*)f_9897},
{"f_10001:optimizer_scm",(void*)f_10001},
{"f_10011:optimizer_scm",(void*)f_10011},
{"f_9976:optimizer_scm",(void*)f_9976},
{"f_9972:optimizer_scm",(void*)f_9972},
{"f_9919:optimizer_scm",(void*)f_9919},
{"f_9928:optimizer_scm",(void*)f_9928},
{"f_9938:optimizer_scm",(void*)f_9938},
{"f_9573:optimizer_scm",(void*)f_9573},
{"f_9587:optimizer_scm",(void*)f_9587},
{"f_9594:optimizer_scm",(void*)f_9594},
{"f_9597:optimizer_scm",(void*)f_9597},
{"f_9606:optimizer_scm",(void*)f_9606},
{"f_9613:optimizer_scm",(void*)f_9613},
{"f_9616:optimizer_scm",(void*)f_9616},
{"f_9712:optimizer_scm",(void*)f_9712},
{"f_9868:optimizer_scm",(void*)f_9868},
{"f_9878:optimizer_scm",(void*)f_9878},
{"f_9844:optimizer_scm",(void*)f_9844},
{"f_9863:optimizer_scm",(void*)f_9863},
{"f_9859:optimizer_scm",(void*)f_9859},
{"f_9825:optimizer_scm",(void*)f_9825},
{"f_9791:optimizer_scm",(void*)f_9791},
{"f_9796:optimizer_scm",(void*)f_9796},
{"f_9806:optimizer_scm",(void*)f_9806},
{"f_9778:optimizer_scm",(void*)f_9778},
{"f_9761:optimizer_scm",(void*)f_9761},
{"f_9731:optimizer_scm",(void*)f_9731},
{"f_9736:optimizer_scm",(void*)f_9736},
{"f_9746:optimizer_scm",(void*)f_9746},
{"f_9697:optimizer_scm",(void*)f_9697},
{"f_9619:optimizer_scm",(void*)f_9619},
{"f_9668:optimizer_scm",(void*)f_9668},
{"f_9656:optimizer_scm",(void*)f_9656},
{"f_9652:optimizer_scm",(void*)f_9652},
{"f_9585:optimizer_scm",(void*)f_9585},
{"f_9287:optimizer_scm",(void*)f_9287},
{"f_9559:optimizer_scm",(void*)f_9559},
{"f_9398:optimizer_scm",(void*)f_9398},
{"f_9536:optimizer_scm",(void*)f_9536},
{"f_9546:optimizer_scm",(void*)f_9546},
{"f_9491:optimizer_scm",(void*)f_9491},
{"f_9496:optimizer_scm",(void*)f_9496},
{"f_9534:optimizer_scm",(void*)f_9534},
{"f_9296:optimizer_scm",(void*)f_9296},
{"f_9374:optimizer_scm",(void*)f_9374},
{"f_9384:optimizer_scm",(void*)f_9384},
{"f_9357:optimizer_scm",(void*)f_9357},
{"f_9362:optimizer_scm",(void*)f_9362},
{"f_9316:optimizer_scm",(void*)f_9316},
{"f_9321:optimizer_scm",(void*)f_9321},
{"f_9331:optimizer_scm",(void*)f_9331},
{"f_9294:optimizer_scm",(void*)f_9294},
{"f_9526:optimizer_scm",(void*)f_9526},
{"f_9512:optimizer_scm",(void*)f_9512},
{"f_9510:optimizer_scm",(void*)f_9510},
{"f_9400:optimizer_scm",(void*)f_9400},
{"f_9484:optimizer_scm",(void*)f_9484},
{"f_9482:optimizer_scm",(void*)f_9482},
{"f_9454:optimizer_scm",(void*)f_9454},
{"f_9467:optimizer_scm",(void*)f_9467},
{"f_9420:optimizer_scm",(void*)f_9420},
{"f_9444:optimizer_scm",(void*)f_9444},
{"f_9442:optimizer_scm",(void*)f_9442},
{"f_9438:optimizer_scm",(void*)f_9438},
{"f_9430:optimizer_scm",(void*)f_9430},
{"f_9013:optimizer_scm",(void*)f_9013},
{"f_9019:optimizer_scm",(void*)f_9019},
{"f_9038:optimizer_scm",(void*)f_9038},
{"f_9244:optimizer_scm",(void*)f_9244},
{"f_9257:optimizer_scm",(void*)f_9257},
{"f_9151:optimizer_scm",(void*)f_9151},
{"f_9167:optimizer_scm",(void*)f_9167},
{"f_9220:optimizer_scm",(void*)f_9220},
{"f_9224:optimizer_scm",(void*)f_9224},
{"f_9187:optimizer_scm",(void*)f_9187},
{"f_9196:optimizer_scm",(void*)f_9196},
{"f_9206:optimizer_scm",(void*)f_9206},
{"f_9124:optimizer_scm",(void*)f_9124},
{"f_9129:optimizer_scm",(void*)f_9129},
{"f_9142:optimizer_scm",(void*)f_9142},
{"f_9100:optimizer_scm",(void*)f_9100},
{"f_9112:optimizer_scm",(void*)f_9112},
{"f_9049:optimizer_scm",(void*)f_9049},
{"f_9070:optimizer_scm",(void*)f_9070},
{"f_9067:optimizer_scm",(void*)f_9067},
{"f_9017:optimizer_scm",(void*)f_9017},
{"f_8753:optimizer_scm",(void*)f_8753},
{"f_8759:optimizer_scm",(void*)f_8759},
{"f_8778:optimizer_scm",(void*)f_8778},
{"f_8880:optimizer_scm",(void*)f_8880},
{"f_8893:optimizer_scm",(void*)f_8893},
{"f_8871:optimizer_scm",(void*)f_8871},
{"f_8837:optimizer_scm",(void*)f_8837},
{"f_8846:optimizer_scm",(void*)f_8846},
{"f_8858:optimizer_scm",(void*)f_8858},
{"f_8789:optimizer_scm",(void*)f_8789},
{"f_8810:optimizer_scm",(void*)f_8810},
{"f_8807:optimizer_scm",(void*)f_8807},
{"f_8757:optimizer_scm",(void*)f_8757},
{"f_8654:optimizer_scm",(void*)f_8654},
{"f_8660:optimizer_scm",(void*)f_8660},
{"f_8704:optimizer_scm",(void*)f_8704},
{"f_8709:optimizer_scm",(void*)f_8709},
{"f_8716:optimizer_scm",(void*)f_8716},
{"f_8743:optimizer_scm",(void*)f_8743},
{"f_8739:optimizer_scm",(void*)f_8739},
{"f_8731:optimizer_scm",(void*)f_8731},
{"f_8729:optimizer_scm",(void*)f_8729},
{"f_8694:optimizer_scm",(void*)f_8694},
{"f_8672:optimizer_scm",(void*)f_8672},
{"f_8679:optimizer_scm",(void*)f_8679},
{"f_8409:optimizer_scm",(void*)f_8409},
{"f_8595:optimizer_scm",(void*)f_8595},
{"f_8636:optimizer_scm",(void*)f_8636},
{"f_8619:optimizer_scm",(void*)f_8619},
{"f_8623:optimizer_scm",(void*)f_8623},
{"f_8593:optimizer_scm",(void*)f_8593},
{"f_8412:optimizer_scm",(void*)f_8412},
{"f_8567:optimizer_scm",(void*)f_8567},
{"f_8580:optimizer_scm",(void*)f_8580},
{"f_8550:optimizer_scm",(void*)f_8550},
{"f_8562:optimizer_scm",(void*)f_8562},
{"f_8496:optimizer_scm",(void*)f_8496},
{"f_8520:optimizer_scm",(void*)f_8520},
{"f_8514:optimizer_scm",(void*)f_8514},
{"f_8478:optimizer_scm",(void*)f_8478},
{"f_8437:optimizer_scm",(void*)f_8437},
{"f_8440:optimizer_scm",(void*)f_8440},
{"f_8445:optimizer_scm",(void*)f_8445},
{"f_8458:optimizer_scm",(void*)f_8458},
{"f_8309:optimizer_scm",(void*)f_8309},
{"f_8315:optimizer_scm",(void*)f_8315},
{"f_8346:optimizer_scm",(void*)f_8346},
{"f_8350:optimizer_scm",(void*)f_8350},
{"f_8354:optimizer_scm",(void*)f_8354},
{"f_8313:optimizer_scm",(void*)f_8313},
{"f_7114:optimizer_scm",(void*)f_7114},
{"f_8301:optimizer_scm",(void*)f_8301},
{"f_8304:optimizer_scm",(void*)f_8304},
{"f_7117:optimizer_scm",(void*)f_7117},
{"f_7273:optimizer_scm",(void*)f_7273},
{"f_7286:optimizer_scm",(void*)f_7286},
{"f_7253:optimizer_scm",(void*)f_7253},
{"f_7227:optimizer_scm",(void*)f_7227},
{"f_7173:optimizer_scm",(void*)f_7173},
{"f_7179:optimizer_scm",(void*)f_7179},
{"f_7185:optimizer_scm",(void*)f_7185},
{"f_7142:optimizer_scm",(void*)f_7142},
{"f_7295:optimizer_scm",(void*)f_7295},
{"f_7705:optimizer_scm",(void*)f_7705},
{"f_7712:optimizer_scm",(void*)f_7712},
{"f_7298:optimizer_scm",(void*)f_7298},
{"f_7692:optimizer_scm",(void*)f_7692},
{"f_7668:optimizer_scm",(void*)f_7668},
{"f_7679:optimizer_scm",(void*)f_7679},
{"f_7635:optimizer_scm",(void*)f_7635},
{"f_7574:optimizer_scm",(void*)f_7574},
{"f_7546:optimizer_scm",(void*)f_7546},
{"f_7551:optimizer_scm",(void*)f_7551},
{"f_7493:optimizer_scm",(void*)f_7493},
{"f_7499:optimizer_scm",(void*)f_7499},
{"f_7504:optimizer_scm",(void*)f_7504},
{"f_7452:optimizer_scm",(void*)f_7452},
{"f_7458:optimizer_scm",(void*)f_7458},
{"f_7463:optimizer_scm",(void*)f_7463},
{"f_7436:optimizer_scm",(void*)f_7436},
{"f_7432:optimizer_scm",(void*)f_7432},
{"f_7402:optimizer_scm",(void*)f_7402},
{"f_7365:optimizer_scm",(void*)f_7365},
{"f_7381:optimizer_scm",(void*)f_7381},
{"f_7347:optimizer_scm",(void*)f_7347},
{"f_7714:optimizer_scm",(void*)f_7714},
{"f_8291:optimizer_scm",(void*)f_8291},
{"f_8289:optimizer_scm",(void*)f_8289},
{"f_7718:optimizer_scm",(void*)f_7718},
{"f_7728:optimizer_scm",(void*)f_7728},
{"f_7737:optimizer_scm",(void*)f_7737},
{"f_7743:optimizer_scm",(void*)f_7743},
{"f_7746:optimizer_scm",(void*)f_7746},
{"f_7752:optimizer_scm",(void*)f_7752},
{"f_7960:optimizer_scm",(void*)f_7960},
{"f_8223:optimizer_scm",(void*)f_8223},
{"f_8233:optimizer_scm",(void*)f_8233},
{"f_8197:optimizer_scm",(void*)f_8197},
{"f_8207:optimizer_scm",(void*)f_8207},
{"f_8182:optimizer_scm",(void*)f_8182},
{"f_8185:optimizer_scm",(void*)f_8185},
{"f_8135:optimizer_scm",(void*)f_8135},
{"f_8138:optimizer_scm",(void*)f_8138},
{"f_8004:optimizer_scm",(void*)f_8004},
{"f_8059:optimizer_scm",(void*)f_8059},
{"f_8062:optimizer_scm",(void*)f_8062},
{"f_8089:optimizer_scm",(void*)f_8089},
{"f_8065:optimizer_scm",(void*)f_8065},
{"f_8068:optimizer_scm",(void*)f_8068},
{"f_8013:optimizer_scm",(void*)f_8013},
{"f_8016:optimizer_scm",(void*)f_8016},
{"f_8019:optimizer_scm",(void*)f_8019},
{"f_7755:optimizer_scm",(void*)f_7755},
{"f_7942:optimizer_scm",(void*)f_7942},
{"f_7869:optimizer_scm",(void*)f_7869},
{"f_7871:optimizer_scm",(void*)f_7871},
{"f_7890:optimizer_scm",(void*)f_7890},
{"f_7893:optimizer_scm",(void*)f_7893},
{"f_7758:optimizer_scm",(void*)f_7758},
{"f_7770:optimizer_scm",(void*)f_7770},
{"f_7825:optimizer_scm",(void*)f_7825},
{"f_7773:optimizer_scm",(void*)f_7773},
{"f_7776:optimizer_scm",(void*)f_7776},
{"f_7781:optimizer_scm",(void*)f_7781},
{"f_7823:optimizer_scm",(void*)f_7823},
{"f_7797:optimizer_scm",(void*)f_7797},
{"f_5242:optimizer_scm",(void*)f_5242},
{"f_6988:optimizer_scm",(void*)f_6988},
{"f_7010:optimizer_scm",(void*)f_7010},
{"f_7022:optimizer_scm",(void*)f_7022},
{"f_7036:optimizer_scm",(void*)f_7036},
{"f_7085:optimizer_scm",(void*)f_7085},
{"f_5267:optimizer_scm",(void*)f_5267},
{"f_7056:optimizer_scm",(void*)f_7056},
{"f_7060:optimizer_scm",(void*)f_7060},
{"f_7030:optimizer_scm",(void*)f_7030},
{"f_7016:optimizer_scm",(void*)f_7016},
{"f_7014:optimizer_scm",(void*)f_7014},
{"f_7003:optimizer_scm",(void*)f_7003},
{"f_6931:optimizer_scm",(void*)f_6931},
{"f_6963:optimizer_scm",(void*)f_6963},
{"f_6950:optimizer_scm",(void*)f_6950},
{"f_6783:optimizer_scm",(void*)f_6783},
{"f_6789:optimizer_scm",(void*)f_6789},
{"f_6873:optimizer_scm",(void*)f_6873},
{"f_6798:optimizer_scm",(void*)f_6798},
{"f_6842:optimizer_scm",(void*)f_6842},
{"f_6840:optimizer_scm",(void*)f_6840},
{"f_6814:optimizer_scm",(void*)f_6814},
{"f_6716:optimizer_scm",(void*)f_6716},
{"f_6744:optimizer_scm",(void*)f_6744},
{"f_6756:optimizer_scm",(void*)f_6756},
{"f_6734:optimizer_scm",(void*)f_6734},
{"f_6729:optimizer_scm",(void*)f_6729},
{"f_6574:optimizer_scm",(void*)f_6574},
{"f_6655:optimizer_scm",(void*)f_6655},
{"f_6583:optimizer_scm",(void*)f_6583},
{"f_6636:optimizer_scm",(void*)f_6636},
{"f_6634:optimizer_scm",(void*)f_6634},
{"f_6599:optimizer_scm",(void*)f_6599},
{"f_6545:optimizer_scm",(void*)f_6545},
{"f_6555:optimizer_scm",(void*)f_6555},
{"f_6483:optimizer_scm",(void*)f_6483},
{"f_6503:optimizer_scm",(void*)f_6503},
{"f_6410:optimizer_scm",(void*)f_6410},
{"f_6440:optimizer_scm",(void*)f_6440},
{"f_6323:optimizer_scm",(void*)f_6323},
{"f_6342:optimizer_scm",(void*)f_6342},
{"f_6335:optimizer_scm",(void*)f_6335},
{"f_6246:optimizer_scm",(void*)f_6246},
{"f_6187:optimizer_scm",(void*)f_6187},
{"f_6202:optimizer_scm",(void*)f_6202},
{"f_6205:optimizer_scm",(void*)f_6205},
{"f_6117:optimizer_scm",(void*)f_6117},
{"f_6160:optimizer_scm",(void*)f_6160},
{"f_6153:optimizer_scm",(void*)f_6153},
{"f_6058:optimizer_scm",(void*)f_6058},
{"f_6070:optimizer_scm",(void*)f_6070},
{"f_6083:optimizer_scm",(void*)f_6083},
{"f_6076:optimizer_scm",(void*)f_6076},
{"f_5971:optimizer_scm",(void*)f_5971},
{"f_5993:optimizer_scm",(void*)f_5993},
{"f_6001:optimizer_scm",(void*)f_6001},
{"f_6005:optimizer_scm",(void*)f_6005},
{"f_5827:optimizer_scm",(void*)f_5827},
{"f_5849:optimizer_scm",(void*)f_5849},
{"f_5852:optimizer_scm",(void*)f_5852},
{"f_5911:optimizer_scm",(void*)f_5911},
{"f_5855:optimizer_scm",(void*)f_5855},
{"f_5858:optimizer_scm",(void*)f_5858},
{"f_5889:optimizer_scm",(void*)f_5889},
{"f_5887:optimizer_scm",(void*)f_5887},
{"f_5863:optimizer_scm",(void*)f_5863},
{"f_5843:optimizer_scm",(void*)f_5843},
{"f_5806:optimizer_scm",(void*)f_5806},
{"f_5751:optimizer_scm",(void*)f_5751},
{"f_5775:optimizer_scm",(void*)f_5775},
{"f_5764:optimizer_scm",(void*)f_5764},
{"f_5686:optimizer_scm",(void*)f_5686},
{"f_5599:optimizer_scm",(void*)f_5599},
{"f_5641:optimizer_scm",(void*)f_5641},
{"f_5543:optimizer_scm",(void*)f_5543},
{"f_5556:optimizer_scm",(void*)f_5556},
{"f_5564:optimizer_scm",(void*)f_5564},
{"f_5505:optimizer_scm",(void*)f_5505},
{"f_5515:optimizer_scm",(void*)f_5515},
{"f_5407:optimizer_scm",(void*)f_5407},
{"f_5464:optimizer_scm",(void*)f_5464},
{"f_5435:optimizer_scm",(void*)f_5435},
{"f_5432:optimizer_scm",(void*)f_5432},
{"f_5299:optimizer_scm",(void*)f_5299},
{"f_5362:optimizer_scm",(void*)f_5362},
{"f_5302:optimizer_scm",(void*)f_5302},
{"f_5222:optimizer_scm",(void*)f_5222},
{"f_5226:optimizer_scm",(void*)f_5226},
{"f_5236:optimizer_scm",(void*)f_5236},
{"f_4862:optimizer_scm",(void*)f_4862},
{"f_4866:optimizer_scm",(void*)f_4866},
{"f_5207:optimizer_scm",(void*)f_5207},
{"f_5216:optimizer_scm",(void*)f_5216},
{"f_5212:optimizer_scm",(void*)f_5212},
{"f_4913:optimizer_scm",(void*)f_4913},
{"f_5133:optimizer_scm",(void*)f_5133},
{"f_5181:optimizer_scm",(void*)f_5181},
{"f_5194:optimizer_scm",(void*)f_5194},
{"f_5159:optimizer_scm",(void*)f_5159},
{"f_5175:optimizer_scm",(void*)f_5175},
{"f_5163:optimizer_scm",(void*)f_5163},
{"f_5167:optimizer_scm",(void*)f_5167},
{"f_5146:optimizer_scm",(void*)f_5146},
{"f_4916:optimizer_scm",(void*)f_4916},
{"f_5058:optimizer_scm",(void*)f_5058},
{"f_5117:optimizer_scm",(void*)f_5117},
{"f_5123:optimizer_scm",(void*)f_5123},
{"f_5074:optimizer_scm",(void*)f_5074},
{"f_5091:optimizer_scm",(void*)f_5091},
{"f_5104:optimizer_scm",(void*)f_5104},
{"f_5089:optimizer_scm",(void*)f_5089},
{"f_5078:optimizer_scm",(void*)f_5078},
{"f_4919:optimizer_scm",(void*)f_4919},
{"f_4922:optimizer_scm",(void*)f_4922},
{"f_4942:optimizer_scm",(void*)f_4942},
{"f_4955:optimizer_scm",(void*)f_4955},
{"f_4998:optimizer_scm",(void*)f_4998},
{"f_5030:optimizer_scm",(void*)f_5030},
{"f_4996:optimizer_scm",(void*)f_4996},
{"f_4978:optimizer_scm",(void*)f_4978},
{"f_4925:optimizer_scm",(void*)f_4925},
{"f_4934:optimizer_scm",(void*)f_4934},
{"f_4868:optimizer_scm",(void*)f_4868},
{"f_4874:optimizer_scm",(void*)f_4874},
{"f_4898:optimizer_scm",(void*)f_4898},
{"f_4847:optimizer_scm",(void*)f_4847},
{"f_4590:optimizer_scm",(void*)f_4590},
{"f_4604:optimizer_scm",(void*)f_4604},
{"f_4619:optimizer_scm",(void*)f_4619},
{"f_4626:optimizer_scm",(void*)f_4626},
{"f_4631:optimizer_scm",(void*)f_4631},
{"f_4838:optimizer_scm",(void*)f_4838},
{"f_4653:optimizer_scm",(void*)f_4653},
{"f_4656:optimizer_scm",(void*)f_4656},
{"f_4669:optimizer_scm",(void*)f_4669},
{"f_4684:optimizer_scm",(void*)f_4684},
{"f_4690:optimizer_scm",(void*)f_4690},
{"f_4696:optimizer_scm",(void*)f_4696},
{"f_4705:optimizer_scm",(void*)f_4705},
{"f_4712:optimizer_scm",(void*)f_4712},
{"f_4715:optimizer_scm",(void*)f_4715},
{"f_4733:optimizer_scm",(void*)f_4733},
{"f_4718:optimizer_scm",(void*)f_4718},
{"f_4659:optimizer_scm",(void*)f_4659},
{"f_4607:optimizer_scm",(void*)f_4607},
{"f_4610:optimizer_scm",(void*)f_4610},
{"f_4597:optimizer_scm",(void*)f_4597},
{"f_4593:optimizer_scm",(void*)f_4593},
{"f_2995:optimizer_scm",(void*)f_2995},
{"f_4478:optimizer_scm",(void*)f_4478},
{"f_4484:optimizer_scm",(void*)f_4484},
{"f_4488:optimizer_scm",(void*)f_4488},
{"f_4491:optimizer_scm",(void*)f_4491},
{"f_4527:optimizer_scm",(void*)f_4527},
{"f_4532:optimizer_scm",(void*)f_4532},
{"f_4545:optimizer_scm",(void*)f_4545},
{"f_4548:optimizer_scm",(void*)f_4548},
{"f_4494:optimizer_scm",(void*)f_4494},
{"f_4497:optimizer_scm",(void*)f_4497},
{"f_4500:optimizer_scm",(void*)f_4500},
{"f_4503:optimizer_scm",(void*)f_4503},
{"f_4453:optimizer_scm",(void*)f_4453},
{"f_4468:optimizer_scm",(void*)f_4468},
{"f_4457:optimizer_scm",(void*)f_4457},
{"f_4463:optimizer_scm",(void*)f_4463},
{"f_3334:optimizer_scm",(void*)f_3334},
{"f_4359:optimizer_scm",(void*)f_4359},
{"f_4362:optimizer_scm",(void*)f_4362},
{"f_4445:optimizer_scm",(void*)f_4445},
{"f_4441:optimizer_scm",(void*)f_4441},
{"f_4403:optimizer_scm",(void*)f_4403},
{"f_4434:optimizer_scm",(void*)f_4434},
{"f_4430:optimizer_scm",(void*)f_4430},
{"f_4422:optimizer_scm",(void*)f_4422},
{"f_4374:optimizer_scm",(void*)f_4374},
{"f_4393:optimizer_scm",(void*)f_4393},
{"f_4380:optimizer_scm",(void*)f_4380},
{"f_4333:optimizer_scm",(void*)f_4333},
{"f_4328:optimizer_scm",(void*)f_4328},
{"f_4303:optimizer_scm",(void*)f_4303},
{"f_4293:optimizer_scm",(void*)f_4293},
{"f_3670:optimizer_scm",(void*)f_3670},
{"f_3679:optimizer_scm",(void*)f_3679},
{"f_3885:optimizer_scm",(void*)f_3885},
{"f_3896:optimizer_scm",(void*)f_3896},
{"f_4245:optimizer_scm",(void*)f_4245},
{"f_4277:optimizer_scm",(void*)f_4277},
{"f_4254:optimizer_scm",(void*)f_4254},
{"f_3906:optimizer_scm",(void*)f_3906},
{"f_3978:optimizer_scm",(void*)f_3978},
{"f_4232:optimizer_scm",(void*)f_4232},
{"f_4143:optimizer_scm",(void*)f_4143},
{"f_4146:optimizer_scm",(void*)f_4146},
{"f_4158:optimizer_scm",(void*)f_4158},
{"f_4169:optimizer_scm",(void*)f_4169},
{"f_4202:optimizer_scm",(void*)f_4202},
{"f_4194:optimizer_scm",(void*)f_4194},
{"f_4182:optimizer_scm",(void*)f_4182},
{"f_4173:optimizer_scm",(void*)f_4173},
{"f_4163:optimizer_scm",(void*)f_4163},
{"f_3992:optimizer_scm",(void*)f_3992},
{"f_4031:optimizer_scm",(void*)f_4031},
{"f_4037:optimizer_scm",(void*)f_4037},
{"f_4043:optimizer_scm",(void*)f_4043},
{"f_4080:optimizer_scm",(void*)f_4080},
{"f_4056:optimizer_scm",(void*)f_4056},
{"f_4060:optimizer_scm",(void*)f_4060},
{"f_4025:optimizer_scm",(void*)f_4025},
{"f_4013:optimizer_scm",(void*)f_4013},
{"f_4008:optimizer_scm",(void*)f_4008},
{"f_3969:optimizer_scm",(void*)f_3969},
{"f_3909:optimizer_scm",(void*)f_3909},
{"f_3938:optimizer_scm",(void*)f_3938},
{"f_3951:optimizer_scm",(void*)f_3951},
{"f_3912:optimizer_scm",(void*)f_3912},
{"f_3915:optimizer_scm",(void*)f_3915},
{"f_3918:optimizer_scm",(void*)f_3918},
{"f_3928:optimizer_scm",(void*)f_3928},
{"f_3871:optimizer_scm",(void*)f_3871},
{"f_3767:optimizer_scm",(void*)f_3767},
{"f_3788:optimizer_scm",(void*)f_3788},
{"f_3845:optimizer_scm",(void*)f_3845},
{"f_3837:optimizer_scm",(void*)f_3837},
{"f_3791:optimizer_scm",(void*)f_3791},
{"f_3816:optimizer_scm",(void*)f_3816},
{"f_3814:optimizer_scm",(void*)f_3814},
{"f_3800:optimizer_scm",(void*)f_3800},
{"f_3746:optimizer_scm",(void*)f_3746},
{"f_3688:optimizer_scm",(void*)f_3688},
{"f_3691:optimizer_scm",(void*)f_3691},
{"f_3714:optimizer_scm",(void*)f_3714},
{"f_3727:optimizer_scm",(void*)f_3727},
{"f_3697:optimizer_scm",(void*)f_3697},
{"f_3704:optimizer_scm",(void*)f_3704},
{"f_3494:optimizer_scm",(void*)f_3494},
{"f_3586:optimizer_scm",(void*)f_3586},
{"f_3591:optimizer_scm",(void*)f_3591},
{"f_3598:optimizer_scm",(void*)f_3598},
{"f_3631:optimizer_scm",(void*)f_3631},
{"f_3611:optimizer_scm",(void*)f_3611},
{"f_3499:optimizer_scm",(void*)f_3499},
{"f_3517:optimizer_scm",(void*)f_3517},
{"f_3524:optimizer_scm",(void*)f_3524},
{"f_3564:optimizer_scm",(void*)f_3564},
{"f_3567:optimizer_scm",(void*)f_3567},
{"f_3557:optimizer_scm",(void*)f_3557},
{"f_3537:optimizer_scm",(void*)f_3537},
{"f_3505:optimizer_scm",(void*)f_3505},
{"f_3511:optimizer_scm",(void*)f_3511},
{"f_3434:optimizer_scm",(void*)f_3434},
{"f_3469:optimizer_scm",(void*)f_3469},
{"f_3476:optimizer_scm",(void*)f_3476},
{"f_3437:optimizer_scm",(void*)f_3437},
{"f_3459:optimizer_scm",(void*)f_3459},
{"f_3454:optimizer_scm",(void*)f_3454},
{"f_3359:optimizer_scm",(void*)f_3359},
{"f_3363:optimizer_scm",(void*)f_3363},
{"f_3375:optimizer_scm",(void*)f_3375},
{"f_3398:optimizer_scm",(void*)f_3398},
{"f_3381:optimizer_scm",(void*)f_3381},
{"f_3392:optimizer_scm",(void*)f_3392},
{"f_3120:optimizer_scm",(void*)f_3120},
{"f_3134:optimizer_scm",(void*)f_3134},
{"f_3305:optimizer_scm",(void*)f_3305},
{"f_3311:optimizer_scm",(void*)f_3311},
{"f_3204:optimizer_scm",(void*)f_3204},
{"f_3286:optimizer_scm",(void*)f_3286},
{"f_3284:optimizer_scm",(void*)f_3284},
{"f_3215:optimizer_scm",(void*)f_3215},
{"f_3238:optimizer_scm",(void*)f_3238},
{"f_3270:optimizer_scm",(void*)f_3270},
{"f_3276:optimizer_scm",(void*)f_3276},
{"f_3244:optimizer_scm",(void*)f_3244},
{"f_3248:optimizer_scm",(void*)f_3248},
{"f_3251:optimizer_scm",(void*)f_3251},
{"f_3268:optimizer_scm",(void*)f_3268},
{"f_3221:optimizer_scm",(void*)f_3221},
{"f_3227:optimizer_scm",(void*)f_3227},
{"f_3231:optimizer_scm",(void*)f_3231},
{"f_3235:optimizer_scm",(void*)f_3235},
{"f_3213:optimizer_scm",(void*)f_3213},
{"f_3143:optimizer_scm",(void*)f_3143},
{"f_3028:optimizer_scm",(void*)f_3028},
{"f_3032:optimizer_scm",(void*)f_3032},
{"f_3043:optimizer_scm",(void*)f_3043},
{"f_3053:optimizer_scm",(void*)f_3053},
{"f_3102:optimizer_scm",(void*)f_3102},
{"f_3100:optimizer_scm",(void*)f_3100},
{"f_3059:optimizer_scm",(void*)f_3059},
{"f_3065:optimizer_scm",(void*)f_3065},
{"f_3092:optimizer_scm",(void*)f_3092},
{"f_3071:optimizer_scm",(void*)f_3071},
{"f_3035:optimizer_scm",(void*)f_3035},
{"f_3024:optimizer_scm",(void*)f_3024},
{"f_3004:optimizer_scm",(void*)f_3004},
{"f_2998:optimizer_scm",(void*)f_2998},
{"f_2725:optimizer_scm",(void*)f_2725},
{"f_2746:optimizer_scm",(void*)f_2746},
{"f_2806:optimizer_scm",(void*)f_2806},
{"f_2837:optimizer_scm",(void*)f_2837},
{"f_2889:optimizer_scm",(void*)f_2889},
{"f_2908:optimizer_scm",(void*)f_2908},
{"f_2919:optimizer_scm",(void*)f_2919},
{"f_2892:optimizer_scm",(void*)f_2892},
{"f_2862:optimizer_scm",(void*)f_2862},
{"f_2809:optimizer_scm",(void*)f_2809},
{"f_2815:optimizer_scm",(void*)f_2815},
{"f_2828:optimizer_scm",(void*)f_2828},
{"f_2749:optimizer_scm",(void*)f_2749},
{"f_2752:optimizer_scm",(void*)f_2752},
{"f_2757:optimizer_scm",(void*)f_2757},
{"f_2772:optimizer_scm",(void*)f_2772},
{"f_2797:optimizer_scm",(void*)f_2797},
{"f_2728:optimizer_scm",(void*)f_2728},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
