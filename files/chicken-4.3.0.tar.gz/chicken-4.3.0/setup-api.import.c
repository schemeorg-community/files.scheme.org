/* Generated from ./setup-api.import.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-12-14 09:04
   Version 4.2.0 - SVN rev. 16023
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-12-14 on galinha (Linux)
   command line: ./setup-api.import.scm -optimize-level 2 -include-path . -include-path ./ -inline -feature chicken-compile-shared -dynamic -ignore-repository -output-file setup-api.import.c
   used units: library eval data_structures ports extras srfi_69
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[30];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,18),40,102,111,114,109,45,101,114,114,111,114,32,115,55,32,112,56,41,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,13),40,97,51,50,53,32,108,105,110,101,52,51,41,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,13),40,97,52,48,50,32,108,105,110,101,50,51,41,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,18),40,97,50,54,49,32,102,111,114,109,48,32,114,49,32,99,50,41,0,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,39),40,97,50,50,55,32,105,110,112,117,116,54,48,55,51,32,114,101,110,97,109,101,54,57,55,52,32,99,111,109,112,97,114,101,53,55,55,53,41,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,13),40,97,50,49,48,32,101,120,112,49,49,53,41,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,42),40,97,49,55,53,32,105,110,112,117,116,57,48,49,48,51,32,114,101,110,97,109,101,57,57,49,48,52,32,99,111,109,112,97,114,101,56,55,49,48,53,41,0,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_129)
static void C_ccall f_129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_132)
static void C_ccall f_132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_135)
static void C_ccall f_135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_138)
static void C_ccall f_138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_141)
static void C_ccall f_141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_144)
static void C_ccall f_144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_147)
static void C_ccall f_147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_176)
static void C_ccall f_176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_186)
static void C_ccall f_186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_193)
static void C_ccall f_193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_205)
static void C_ccall f_205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_211)
static void C_ccall f_211(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_219)
static void C_ccall f_219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_209)
static void C_ccall f_209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_228)
static void C_ccall f_228(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_238)
static void C_ccall f_238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_245)
static void C_ccall f_245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_257)
static void C_ccall f_257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_262)
static void C_ccall f_262(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_266)
static void C_ccall f_266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_272)
static void C_ccall f_272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_275)
static void C_ccall f_275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_389)
static void C_ccall f_389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_398)
static void C_ccall f_398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_403)
static void C_ccall f_403(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_410)
static void C_fcall f_410(C_word t0,C_word t1) C_noret;
C_noret_decl(f_413)
static void C_ccall f_413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_283)
static void C_ccall f_283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_290)
static void C_ccall f_290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_326)
static void C_ccall f_326(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_379)
static void C_ccall f_379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_375)
static void C_ccall f_375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_357)
static void C_fcall f_357(C_word t0,C_word t1) C_noret;
C_noret_decl(f_350)
static void C_ccall f_350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_324)
static void C_ccall f_324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_320)
static void C_ccall f_320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_302)
static void C_ccall f_302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_276)
static void C_fcall f_276(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_150)
static void C_ccall f_150(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_410)
static void C_fcall trf_410(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_410(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_410(t0,t1);}

C_noret_decl(trf_357)
static void C_fcall trf_357(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_357(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_357(t0,t1);}

C_noret_decl(trf_276)
static void C_fcall trf_276(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_276(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_276(t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1501)){
C_save(t1);
C_rereclaim2(1501*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,30);
lf[0]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007execute\376\001\000\000\021setup-api#execute");
lf[1]=C_h_intern(&lf[1],5,"error");
lf[2]=C_h_intern(&lf[2],4,"list");
lf[3]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016\376\377\016");
lf[4]=C_h_intern(&lf[4],10,"\003sysappend");
lf[5]=C_h_intern(&lf[5],7,"\003sysmap");
lf[6]=C_h_intern(&lf[6],9,"make/proc");
lf[7]=C_h_intern(&lf[7],15,"make:line-error");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\047second part of clause is not a sequence");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000%clause does not have at least 2 parts");
lf[10]=C_h_intern(&lf[10],5,"every");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000\023empty specification");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000&illegal specification (not a sequence)");
lf[13]=C_h_intern(&lf[13],6,"lambda");
lf[14]=C_h_intern(&lf[14],16,"\003syscheck-syntax");
lf[15]=C_h_intern(&lf[15],4,"make");
lf[16]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[17]=C_h_intern(&lf[17],3,"csc");
lf[18]=C_h_intern(&lf[18],3,"run");
lf[19]=C_h_intern(&lf[19],25,"\003syssyntax-rules-mismatch");
lf[20]=C_h_intern(&lf[20],9,"\003syslist\077");
lf[21]=C_h_intern(&lf[21],7,"compile");
lf[22]=C_h_intern(&lf[22],10,"quasiquote");
lf[23]=C_h_intern(&lf[23],9,"\003sysmap-n");
lf[24]=C_h_intern(&lf[24],7,"execute");
lf[25]=C_h_intern(&lf[25],28,"\003sysregister-compiled-module");
lf[26]=C_h_intern(&lf[26],9,"setup-api");
lf[27]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011move-file\376\001\000\000\023setup-api#move-file\376\003\000\000\002\376\003\000\000\002\376\001\000\000\022standard-extensio"
"n\376\001\000\000\034setup-api#standard-extension\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011make/proc\376\001\000\000\023setup-api#make/pr"
"oc\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016host-extension\376\001\000\000\030setup-api#host-extension\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021insta"
"ll-extension\376\001\000\000\033setup-api#install-extension\376\003\000\000\002\376\003\000\000\002\376\001\000\000\017install-program\376\001\000\000\031s"
"etup-api#install-program\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016install-script\376\001\000\000\030setup-api#install-scri"
"pt\376\003\000\000\002\376\003\000\000\002\376\001\000\000\022setup-verbose-mode\376\001\000\000\034setup-api#setup-verbose-mode\376\003\000\000\002\376\003\000\000\002\376\001"
"\000\000\022setup-install-mode\376\001\000\000\034setup-api#setup-install-mode\376\003\000\000\002\376\003\000\000\002\376\001\000\000\022setup-verbo"
"se-flag\376\001\000\000\034setup-api#setup-verbose-flag\376\003\000\000\002\376\003\000\000\002\376\001\000\000\022setup-install-flag\376\001\000\000\034se"
"tup-api#setup-install-flag\376\003\000\000\002\376\003\000\000\002\376\001\000\000\023installation-prefix\376\001\000\000\035setup-api#insta"
"llation-prefix\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016chicken-prefix\376\001\000\000\030setup-api#chicken-prefix\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\014find-library\376\001\000\000\026setup-api#find-library\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013find-header\376\001\000\000\025set"
"up-api#find-header\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014program-path\376\001\000\000\026setup-api#program-path\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\014remove-file*\376\001\000\000\026setup-api#remove-file*\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005patch\376\001\000\000\017setup-api"
"#patch\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012yes-or-no\077\376\001\000\000\024setup-api#yes-or-no\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013abort-set"
"up\376\001\000\000\025setup-api#abort-setup\376\003\000\000\002\376\003\000\000\002\376\001\000\000\024setup-root-directory\376\001\000\000\036setup-api#se"
"tup-root-directory\376\003\000\000\002\376\003\000\000\002\376\001\000\000\030create-directory/parents\376\001\000\000\042setup-api#create-d"
"irectory/parents\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014test-compile\376\001\000\000\026setup-api#test-compile\376\003\000\000\002\376\003\000\000\002"
"\376\001\000\000\013try-compile\376\001\000\000\025setup-api#try-compile\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011copy-file\376\001\000\000\023setup-api"
"#copy-file\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013run-verbose\376\001\000\000\025setup-api#run-verbose\376\003\000\000\002\376\003\000\000\002\376\001\000\000\030req"
"uired-chicken-version\376\001\000\000\042setup-api#required-chicken-version\376\003\000\000\002\376\003\000\000\002\376\001\000\000\032requi"
"red-extension-version\376\001\000\000$setup-api#required-extension-version\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015cro"
"ss-chicken\376\001\000\000\027setup-api#cross-chicken\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014sudo-install\376\001\000\000\026setup-api#"
"sudo-install\376\003\000\000\002\376\003\000\000\002\376\001\000\000\022keep-intermediates\376\001\000\000\034setup-api#keep-intermediates\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\012version>=\077\376\001\000\000\024setup-api#version>=\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\032extension-name-an"
"d-version\376\001\000\000$setup-api#extension-name-and-version\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016extension-name\376"
"\001\000\000\030setup-api#extension-name\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021extension-version\376\001\000\000\033setup-api#exten"
"sion-version\376\003\000\000\002\376\003\000\000\002\376\001\000\000\032create-temporary-directory\376\001\000\000$setup-api#create-tempo"
"rary-directory\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020remove-directory\376\001\000\000\032setup-api#remove-directory\376\003\000\000"
"\002\376\003\000\000\002\376\001\000\000\020remove-extension\376\001\000\000\032setup-api#remove-extension\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011read-in"
"fo\376\001\000\000\023setup-api#read-info\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011shellpath\376\001\000\000\023setup-api#shellpath\376\377\016");
lf[28]=C_h_intern(&lf[28],4,"eval");
lf[29]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006import\376\003\000\000\002\376\001\000\000\006scheme\376\003\000\000\002\376\001\000\000\007chicken\376\003\000\000\002\376\001\000\000\007foreign\376\003\000\000\002\376\001\000\000\005rege"
"x\376\003\000\000\002\376\001\000\000\005utils\376\003\000\000\002\376\001\000\000\005posix\376\003\000\000\002\376\001\000\000\005ports\376\003\000\000\002\376\001\000\000\006extras\376\003\000\000\002\376\001\000\000\017data-str"
"uctures\376\003\000\000\002\376\001\000\000\006srfi-1\376\003\000\000\002\376\001\000\000\007srfi-13\376\003\000\000\002\376\001\000\000\005files\376\377\016");
C_register_lf2(lf,30,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_129,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k127 */
static void C_ccall f_129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_129,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_132,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k130 in k127 */
static void C_ccall f_132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_132,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_135,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k133 in k130 in k127 */
static void C_ccall f_135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_135,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_138,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k136 in k133 in k130 in k127 */
static void C_ccall f_138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_138,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_141,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k139 in k136 in k133 in k130 in k127 */
static void C_ccall f_141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_141,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_144,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k142 in k139 in k136 in k133 in k130 in k127 */
static void C_ccall f_144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_147,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("./setup-api.import.scm: 1    eval");
((C_proc3)C_retrieve_symbol_proc(lf[28]))(3,*((C_word*)lf[28]+1),t2,lf[29]);}

/* k145 in k142 in k139 in k136 in k133 in k130 in k127 */
static void C_ccall f_147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[33],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_147,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_150,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,lf[0]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_262,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_a_i_cons(&a,2,lf[15],t4);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_228,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_a_i_cons(&a,2,lf[21],t6);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_176,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_a_i_cons(&a,2,lf[18],t8);
t10=(C_word)C_a_i_list(&a,3,t5,t7,t9);
C_trace("./setup-api.import.scm: 14   ##sys#register-compiled-module");
((C_proc7)C_retrieve_symbol_proc(lf[25]))(7,*((C_word*)lf[25]+1),t2,lf[26],t3,lf[27],t10,C_SCHEME_END_OF_LIST);}

/* a175 in k145 in k142 in k139 in k136 in k133 in k130 in k127 */
static void C_ccall f_176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_176,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_186,a[2]=t2,a[3]=t5,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#list?");
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t6,t5);}

/* k184 in a175 in k145 in k142 in k139 in k136 in k133 in k130 in k127 */
static void C_ccall f_186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_186,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_193,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("rename99104");
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[24]);}
else{
C_trace("##sys#syntax-rules-mismatch");
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k191 in k184 in a175 in k145 in k142 in k139 in k136 in k133 in k130 in k127 */
static void C_ccall f_193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_193,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_205,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("rename99104");
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[2]);}

/* k203 in k191 in k184 in a175 in k145 in k142 in k139 in k136 in k133 in k130 in k127 */
static void C_ccall f_205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_205,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_209,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_211,a[2]=((C_word*)t0)[3],a[3]=((C_word)li5),tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#map-n");
((C_proc4)C_retrieve_symbol_proc(lf[23]))(4,*((C_word*)lf[23]+1),t2,t3,((C_word*)t0)[2]);}

/* a210 in k203 in k191 in k184 in a175 in k145 in k142 in k139 in k136 in k133 in k130 in k127 */
static void C_ccall f_211(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_211,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_219,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("rename99104");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[22]);}

/* k217 in a210 in k203 in k191 in k184 in a175 in k145 in k142 in k139 in k136 in k133 in k130 in k127 */
static void C_ccall f_219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_219,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,t1,t2));}

/* k207 in k203 in k191 in k184 in a175 in k145 in k142 in k139 in k136 in k133 in k130 in k127 */
static void C_ccall f_209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_209,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* a227 in k145 in k142 in k139 in k136 in k133 in k130 in k127 */
static void C_ccall f_228(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_228,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_238,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#list?");
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t6,t5);}

/* k236 in a227 in k145 in k142 in k139 in k136 in k133 in k130 in k127 */
static void C_ccall f_238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_238,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_245,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("rename6974");
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[18]);}
else{
C_trace("##sys#syntax-rules-mismatch");
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k243 in k236 in a227 in k145 in k142 in k139 in k136 in k133 in k130 in k127 */
static void C_ccall f_245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_245,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_257,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("rename6974");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[17]);}

/* k255 in k243 in k236 in a227 in k145 in k142 in k139 in k136 in k133 in k130 in k127 */
static void C_ccall f_257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_257,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* a261 in k145 in k142 in k139 in k136 in k133 in k130 in k127 */
static void C_ccall f_262(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_262,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_266,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("./setup-api.import.scm: 59   ##sys#check-syntax");
((C_proc5)C_retrieve_symbol_proc(lf[14]))(5,*((C_word*)lf[14]+1),t5,lf[15],t2,lf[16]);}

/* k264 in a261 in k145 in k142 in k139 in k136 in k133 in k130 in k127 */
static void C_ccall f_266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_266,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_272,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("./setup-api.import.scm: 61   r");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[2]);}

/* k270 in k264 in a261 in k145 in k142 in k139 in k136 in k133 in k130 in k127 */
static void C_ccall f_272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_272,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_275,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("./setup-api.import.scm: 62   r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[13]);}

/* k273 in k270 in k264 in a261 in k145 in k142 in k139 in k136 in k133 in k130 in k127 */
static void C_ccall f_275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_275,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_276,a[2]=((C_word*)t0)[6],a[3]=((C_word)li0),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_283,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_listp(((C_word*)t0)[6]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_389,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_389(2,t6,t4);}
else{
C_trace("./setup-api.import.scm: 65   form-error");
t6=t2;
f_276(t6,t5,lf[12],C_SCHEME_END_OF_LIST);}}

/* k387 in k273 in k270 in k264 in a261 in k145 in k142 in k139 in k136 in k133 in k130 in k127 */
static void C_ccall f_389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_389,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_pairp(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_398,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_398(2,t4,t2);}
else{
C_trace("./setup-api.import.scm: 67   form-error");
t4=((C_word*)t0)[3];
f_276(t4,t3,lf[11],C_SCHEME_END_OF_LIST);}}
else{
t2=((C_word*)t0)[2];
f_283(2,t2,C_SCHEME_FALSE);}}

/* k396 in k387 in k273 in k270 in k264 in a261 in k145 in k142 in k139 in k136 in k133 in k130 in k127 */
static void C_ccall f_398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_398,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_403,a[2]=((C_word*)t0)[4],a[3]=((C_word)li2),tmp=(C_word)a,a+=4,tmp);
C_trace("./setup-api.import.scm: 68   every");
((C_proc4)C_retrieve_symbol_proc(lf[10]))(4,*((C_word*)lf[10]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_283(2,t2,C_SCHEME_FALSE);}}

/* a402 in k396 in k387 in k273 in k270 in k264 in a261 in k145 in k142 in k139 in k136 in k133 in k130 in k127 */
static void C_ccall f_403(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_403,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_410,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=(C_word)C_i_length(t2);
t5=t3;
f_410(t5,(C_word)C_i_greater_or_equalp(t4,C_fix(2)));}
else{
t4=t3;
f_410(t4,C_SCHEME_FALSE);}}

/* k408 in a402 in k396 in k387 in k273 in k270 in k264 in a261 in k145 in k142 in k139 in k136 in k133 in k130 in k127 */
static void C_fcall f_410(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_410,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_413,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_413(2,t3,t1);}
else{
C_trace("./setup-api.import.scm: 70   form-error");
t3=((C_word*)t0)[2];
f_276(t3,t2,lf[9],(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]));}}

/* k411 in k408 in a402 in k396 in k387 in k273 in k270 in k264 in a261 in k145 in k142 in k139 in k136 in k133 in k130 in k127 */
static void C_ccall f_413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(C_word)C_i_listp(t3);
if(C_truep(t4)){
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_cadr(((C_word*)t0)[3]);
C_trace("./setup-api.import.scm: 75   make:line-error");
((C_proc5)C_retrieve_symbol_proc(lf[7]))(5,*((C_word*)lf[7]+1),((C_word*)t0)[2],lf[8],t5,t2);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k281 in k273 in k270 in k264 in a261 in k145 in k142 in k139 in k136 in k133 in k130 in k127 */
static void C_ccall f_283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_283,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_290,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("./setup-api.import.scm: 80   r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[6]);}

/* k288 in k281 in k273 in k270 in k264 in a261 in k145 in k142 in k139 in k136 in k133 in k130 in k127 */
static void C_ccall f_290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_290,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_320,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_324,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_326,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li1),tmp=(C_word)a,a+=5,tmp);
C_trace("map");
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a325 in k288 in k281 in k273 in k270 in k264 in a261 in k145 in k142 in k139 in k136 in k133 in k130 in k127 */
static void C_ccall f_326(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_326,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_379,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_cadr(t2);
C_trace("##sys#append");
t6=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_SCHEME_END_OF_LIST);}

/* k377 in a325 in k288 in k281 in k273 in k270 in k264 in a261 in k145 in k142 in k139 in k136 in k133 in k130 in k127 */
static void C_ccall f_379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_379,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_350,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_357,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_357(t6,C_SCHEME_END_OF_LIST);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_375,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#append");
t7=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t4,C_SCHEME_END_OF_LIST);}}

/* k373 in k377 in a325 in k288 in k281 in k273 in k270 in k264 in a261 in k145 in k142 in k139 in k136 in k133 in k130 in k127 */
static void C_ccall f_375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_375,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_357(t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}

/* k355 in k377 in a325 in k288 in k281 in k273 in k270 in k264 in a261 in k145 in k142 in k139 in k136 in k133 in k130 in k127 */
static void C_fcall f_357(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k348 in k377 in a325 in k288 in k281 in k273 in k270 in k264 in a261 in k145 in k142 in k139 in k136 in k133 in k130 in k127 */
static void C_ccall f_350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_350,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k322 in k288 in k281 in k273 in k270 in k264 in a261 in k145 in k142 in k139 in k136 in k133 in k130 in k127 */
static void C_ccall f_324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k318 in k288 in k281 in k273 in k270 in k264 in a261 in k145 in k142 in k139 in k136 in k133 in k130 in k127 */
static void C_ccall f_320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_320,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[2],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_302,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[2]);
t5=(C_word)C_i_nullp(t4);
t6=(C_truep(t5)?lf[3]:(C_word)C_i_cddr(((C_word*)t0)[2]));
C_trace("##sys#append");
t7=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,t6,C_SCHEME_END_OF_LIST);}

/* k300 in k318 in k288 in k281 in k273 in k270 in k264 in a261 in k145 in k142 in k139 in k136 in k133 in k130 in k127 */
static void C_ccall f_302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_302,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* form-error in k273 in k270 in k264 in a261 in k145 in k142 in k139 in k136 in k133 in k130 in k127 */
static void C_fcall f_276(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_276,NULL,4,t0,t1,t2,t3);}
C_apply(6,0,t1,*((C_word*)lf[1]+1),t2,((C_word*)t0)[2],t3);}

/* k148 in k145 in k142 in k139 in k136 in k133 in k130 in k127 */
static void C_ccall f_150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[41] = {
{"toplevel:__setup_api_import_scm",(void*)C_toplevel},
{"f_129:__setup_api_import_scm",(void*)f_129},
{"f_132:__setup_api_import_scm",(void*)f_132},
{"f_135:__setup_api_import_scm",(void*)f_135},
{"f_138:__setup_api_import_scm",(void*)f_138},
{"f_141:__setup_api_import_scm",(void*)f_141},
{"f_144:__setup_api_import_scm",(void*)f_144},
{"f_147:__setup_api_import_scm",(void*)f_147},
{"f_176:__setup_api_import_scm",(void*)f_176},
{"f_186:__setup_api_import_scm",(void*)f_186},
{"f_193:__setup_api_import_scm",(void*)f_193},
{"f_205:__setup_api_import_scm",(void*)f_205},
{"f_211:__setup_api_import_scm",(void*)f_211},
{"f_219:__setup_api_import_scm",(void*)f_219},
{"f_209:__setup_api_import_scm",(void*)f_209},
{"f_228:__setup_api_import_scm",(void*)f_228},
{"f_238:__setup_api_import_scm",(void*)f_238},
{"f_245:__setup_api_import_scm",(void*)f_245},
{"f_257:__setup_api_import_scm",(void*)f_257},
{"f_262:__setup_api_import_scm",(void*)f_262},
{"f_266:__setup_api_import_scm",(void*)f_266},
{"f_272:__setup_api_import_scm",(void*)f_272},
{"f_275:__setup_api_import_scm",(void*)f_275},
{"f_389:__setup_api_import_scm",(void*)f_389},
{"f_398:__setup_api_import_scm",(void*)f_398},
{"f_403:__setup_api_import_scm",(void*)f_403},
{"f_410:__setup_api_import_scm",(void*)f_410},
{"f_413:__setup_api_import_scm",(void*)f_413},
{"f_283:__setup_api_import_scm",(void*)f_283},
{"f_290:__setup_api_import_scm",(void*)f_290},
{"f_326:__setup_api_import_scm",(void*)f_326},
{"f_379:__setup_api_import_scm",(void*)f_379},
{"f_375:__setup_api_import_scm",(void*)f_375},
{"f_357:__setup_api_import_scm",(void*)f_357},
{"f_350:__setup_api_import_scm",(void*)f_350},
{"f_324:__setup_api_import_scm",(void*)f_324},
{"f_320:__setup_api_import_scm",(void*)f_320},
{"f_302:__setup_api_import_scm",(void*)f_302},
{"f_276:__setup_api_import_scm",(void*)f_276},
{"f_150:__setup_api_import_scm",(void*)f_150},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
