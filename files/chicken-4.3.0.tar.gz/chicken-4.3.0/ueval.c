/* Generated from eval.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-12-14 09:03
   Version 4.2.0 - SVN rev. 16023
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-12-14 on galinha (Linux)
   command line: eval.scm -optimize-level 2 -include-path . -include-path ./ -inline -explicit-use -no-trace -unsafe -no-lambda-info -output-file ueval.c
   unit: eval
*/

#include "chicken.h"


#ifndef C_INSTALL_EGG_HOME
# define C_INSTALL_EGG_HOME    "."
#endif

#ifndef C_INSTALL_SHARE_HOME
# define C_INSTALL_SHARE_HOME NULL
#endif

#ifndef C_BINARY_VERSION
# define C_BINARY_VERSION      0
#endif


#define C_store_result(x, ptr)   (*((C_word *)C_block_item(ptr, 0)) = (x), C_SCHEME_TRUE)


#define C_copy_result_string(str, buf, n)  (C_memcpy((char *)C_block_item(buf, 0), C_c_string(str), C_unfix(n)), ((char *)C_block_item(buf, 0))[ C_unfix(n) ] = '\0', C_SCHEME_TRUE)


C_externexport  void  CHICKEN_get_error_message(char *t0,int t1);

C_externexport  int  CHICKEN_load(char * t0);

C_externexport  int  CHICKEN_read(char * t0,C_word *t1);

C_externexport  int  CHICKEN_apply_to_string(C_word t0,C_word t1,char *t2,int t3);

C_externexport  int  CHICKEN_apply(C_word t0,C_word t1,C_word *t2);

C_externexport  int  CHICKEN_eval_string_to_string(char * t0,char *t1,int t2);

C_externexport  int  CHICKEN_eval_to_string(C_word t0,char *t1,int t2);

C_externexport  int  CHICKEN_eval_string(char * t0,C_word *t1);

C_externexport  int  CHICKEN_eval(C_word t0,C_word *t1);

C_externexport  int  CHICKEN_yield();

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_expand_toplevel)
C_externimport void C_ccall C_expand_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[411];
static double C_possibly_force_alignment;


/* from ##sys#clear-trace-buffer in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static C_word C_fcall stub2048(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2048(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_clear_trace_buffer();
return C_r;}

C_noret_decl(C_eval_toplevel)
C_externexport void C_ccall C_eval_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2480)
static void C_ccall f_2480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2513)
static void C_ccall f_2513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2516)
static void C_ccall f_2516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9618)
static void C_ccall f_9618(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_9618)
static void C_ccall f_9618r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_9622)
static void C_fcall f_9622(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9647)
static void C_ccall f_9647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9637)
static void C_ccall f_9637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9645)
static void C_ccall f_9645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9630)
static void C_ccall f_9630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9628)
static void C_ccall f_9628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5799)
static void C_ccall f_5799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5894)
static void C_ccall f_5894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5975)
static void C_ccall f_5975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9612)
static void C_ccall f_9612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9608)
static void C_ccall f_9608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9604)
static void C_ccall f_9604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9600)
static void C_ccall f_9600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9590)
static void C_fcall f_9590(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6519)
static void C_fcall f_6519(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6524)
static void C_ccall f_6524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9572)
static void C_ccall f_9572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9551)
static void C_fcall f_9551(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9558)
static void C_ccall f_9558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6531)
static void C_ccall f_6531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9542)
static void C_ccall f_9542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9544)
static void C_ccall f_9544(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6540)
static void C_ccall f_6540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9511)
static void C_ccall f_9511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9531)
static void C_ccall f_9531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9527)
static void C_ccall f_9527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9517)
static void C_ccall f_9517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9514)
static void C_ccall f_9514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6894)
static void C_ccall f_6894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9457)
static void C_ccall f_9457(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9471)
static void C_fcall f_9471(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9507)
static void C_ccall f_9507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9503)
static void C_ccall f_9503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9491)
static void C_ccall f_9491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9495)
static void C_ccall f_9495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9465)
static void C_ccall f_9465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7797)
static void C_ccall f_7797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9360)
static void C_ccall f_9360(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9397)
static void C_fcall f_9397(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9400)
static void C_ccall f_9400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9423)
static void C_ccall f_9423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9427)
static void C_ccall f_9427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9409)
static void C_ccall f_9409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9406)
static void C_ccall f_9406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9363)
static void C_fcall f_9363(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7800)
static void C_ccall f_7800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7858)
static void C_ccall f_7858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9334)
static void C_fcall f_9334(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9358)
static void C_ccall f_9358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9344)
static void C_ccall f_9344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8209)
static void C_ccall f_8209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8213)
static void C_ccall f_8213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9308)
static void C_fcall f_9308(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9332)
static void C_ccall f_9332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9318)
static void C_ccall f_9318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8216)
static void C_ccall f_8216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8220)
static void C_ccall f_8220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8487)
static void C_ccall f_8487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9302)
static void C_ccall f_9302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8509)
static void C_ccall f_8509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8920)
static void C_ccall f_8920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9293)
static void C_ccall f_9293(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9300)
static void C_ccall f_9300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9283)
static void C_ccall f_9283(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9268)
static void C_ccall f_9268(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9272)
static void C_ccall f_9272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9277)
static void C_ccall f_9277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9281)
static void C_ccall f_9281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9246)
static void C_ccall f_9246(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9250)
static void C_ccall f_9250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9255)
static void C_ccall f_9255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9259)
static void C_ccall f_9259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9266)
static void C_ccall f_9266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9220)
static void C_ccall f_9220(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9226)
static void C_ccall f_9226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9230)
static void C_ccall f_9230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9244)
static void C_ccall f_9244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9233)
static void C_ccall f_9233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9240)
static void C_ccall f_9240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9204)
static void C_ccall f_9204(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9210)
static void C_ccall f_9210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9218)
static void C_ccall f_9218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9167)
static void C_ccall f_9167(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9171)
static void C_ccall f_9171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9176)
static void C_ccall f_9176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9180)
static void C_ccall f_9180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9202)
static void C_ccall f_9202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9198)
static void C_ccall f_9198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9194)
static void C_ccall f_9194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9183)
static void C_ccall f_9183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9190)
static void C_ccall f_9190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9141)
static void C_ccall f_9141(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9147)
static void C_ccall f_9147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9151)
static void C_ccall f_9151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9165)
static void C_ccall f_9165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9154)
static void C_ccall f_9154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9161)
static void C_ccall f_9161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9128)
static C_word C_fcall f_9128(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_9102)
static void C_ccall f_9102(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9106)
static void C_ccall f_9106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9111)
static void C_ccall f_9111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9115)
static void C_ccall f_9115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9126)
static void C_ccall f_9126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9122)
static void C_ccall f_9122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9086)
static void C_ccall f_9086(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9092)
static void C_ccall f_9092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9100)
static void C_ccall f_9100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9074)
static void C_ccall f_9074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9080)
static void C_ccall f_9080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9084)
static void C_ccall f_9084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9065)
static void C_fcall f_9065(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9069)
static void C_ccall f_9069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9006)
static void C_fcall f_9006(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9016)
static void C_ccall f_9016(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9041)
static void C_ccall f_9041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9053)
static void C_ccall f_9053(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_9053)
static void C_ccall f_9053r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_9059)
static void C_ccall f_9059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9047)
static void C_ccall f_9047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9022)
static void C_ccall f_9022(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9028)
static void C_ccall f_9028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9032)
static void C_ccall f_9032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9035)
static void C_ccall f_9035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9039)
static void C_ccall f_9039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9014)
static void C_ccall f_9014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8931)
static void C_ccall f_8931(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8941)
static void C_ccall f_8941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8944)
static void C_ccall f_8944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8958)
static void C_fcall f_8958(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8976)
static void C_ccall f_8976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8945)
static void C_fcall f_8945(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8922)
static void C_ccall f_8922(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8530)
static void C_ccall f_8530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8606)
static void C_ccall f_8606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8609)
static void C_ccall f_8609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8905)
static void C_ccall f_8905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8909)
static void C_ccall f_8909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8913)
static void C_ccall f_8913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8691)
static void C_ccall f_8691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8697)
static void C_fcall f_8697(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8888)
static void C_ccall f_8888(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8894)
static void C_ccall f_8894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8704)
static void C_ccall f_8704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8707)
static void C_ccall f_8707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8710)
static void C_ccall f_8710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8883)
static void C_ccall f_8883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8719)
static void C_ccall f_8719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8722)
static void C_ccall f_8722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8737)
static void C_ccall f_8737(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8737)
static void C_ccall f_8737r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8755)
static void C_fcall f_8755(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8837)
static void C_ccall f_8837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8771)
static void C_ccall f_8771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8779)
static void C_fcall f_8779(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8792)
static void C_ccall f_8792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8795)
static void C_ccall f_8795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8814)
static void C_ccall f_8814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8817)
static void C_ccall f_8817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8798)
static void C_ccall f_8798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8801)
static void C_ccall f_8801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8774)
static void C_ccall f_8774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8759)
static void C_ccall f_8759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8741)
static void C_ccall f_8741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8571)
static void C_fcall f_8571(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8576)
static void C_fcall f_8576(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8589)
static void C_ccall f_8589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8744)
static void C_ccall f_8744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8728)
static void C_ccall f_8728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8626)
static void C_ccall f_8626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8631)
static void C_ccall f_8631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8634)
static void C_ccall f_8634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8639)
static void C_ccall f_8639(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8639)
static void C_ccall f_8639r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8646)
static void C_ccall f_8646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8686)
static void C_ccall f_8686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8649)
static void C_ccall f_8649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8661)
static void C_fcall f_8661(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8670)
static void C_ccall f_8670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8664)
static void C_ccall f_8664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8652)
static void C_ccall f_8652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8655)
static void C_ccall f_8655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8617)
static C_word C_fcall f_8617(C_word t0);
C_noret_decl(f_8611)
static C_word C_fcall f_8611(C_word t0);
C_noret_decl(f_8533)
static void C_fcall f_8533(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8539)
static void C_fcall f_8539(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8552)
static void C_ccall f_8552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8527)
static void C_ccall f_8527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8511)
static void C_ccall f_8511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8525)
static void C_ccall f_8525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8522)
static void C_ccall f_8522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8515)
static void C_ccall f_8515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8492)
static void C_ccall f_8492(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8501)
static void C_ccall f_8501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8496)
static void C_ccall f_8496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8432)
static void C_ccall f_8432(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8436)
static void C_ccall f_8436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8439)
static void C_ccall f_8439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8442)
static void C_ccall f_8442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8445)
static void C_ccall f_8445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8448)
static void C_ccall f_8448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8451)
static void C_ccall f_8451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8454)
static void C_ccall f_8454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8457)
static void C_ccall f_8457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8460)
static void C_ccall f_8460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8411)
static void C_fcall f_8411(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8415)
static void C_ccall f_8415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8418)
static void C_ccall f_8418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8387)
static void C_fcall f_8387(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8393)
static void C_fcall f_8393(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8403)
static void C_ccall f_8403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8245)
static void C_ccall f_8245(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_8245)
static void C_ccall f_8245r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_8316)
static void C_ccall f_8316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8363)
static void C_ccall f_8363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8373)
static void C_ccall f_8373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8366)
static void C_fcall f_8366(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8326)
static void C_ccall f_8326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8328)
static void C_fcall f_8328(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8352)
static void C_ccall f_8352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8338)
static void C_ccall f_8338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8286)
static void C_fcall f_8286(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8251)
static void C_fcall f_8251(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8267)
static void C_ccall f_8267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8273)
static void C_ccall f_8273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8264)
static void C_ccall f_8264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8226)
static void C_fcall f_8226(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8230)
static void C_ccall f_8230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8193)
static void C_fcall f_8193(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8195)
static void C_ccall f_8195(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8199)
static void C_ccall f_8199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8155)
static void C_ccall f_8155(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8155)
static void C_ccall f_8155r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8162)
static void C_ccall f_8162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8169)
static void C_ccall f_8169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8111)
static void C_ccall f_8111(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8111)
static void C_ccall f_8111r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8144)
static void C_ccall f_8144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8131)
static void C_ccall f_8131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8108)
static void C_ccall f_8108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7989)
static void C_ccall f_7989(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7989)
static void C_ccall f_7989r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8083)
static void C_ccall f_8083(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8093)
static void C_ccall f_8093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8081)
static void C_ccall f_8081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8010)
static void C_fcall f_8010(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8034)
static void C_fcall f_8034(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8053)
static void C_ccall f_8053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8028)
static void C_ccall f_8028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7881)
static void C_ccall f_7881(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_7881)
static void C_ccall f_7881r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_7891)
static void C_ccall f_7891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7896)
static void C_fcall f_7896(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7923)
static void C_fcall f_7923(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7956)
static void C_ccall f_7956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7917)
static void C_ccall f_7917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7865)
static void C_ccall f_7865(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7802)
static void C_ccall f_7802(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7806)
static void C_ccall f_7806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7814)
static void C_fcall f_7814(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7834)
static void C_fcall f_7834(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7758)
static void C_ccall f_7758(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7790)
static void C_ccall f_7790(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7776)
static void C_ccall f_7776(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7236)
static void C_ccall f_7236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7626)
static void C_fcall f_7626(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7635)
static void C_ccall f_7635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7665)
static void C_ccall f_7665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7667)
static void C_fcall f_7667(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7704)
static void C_ccall f_7704(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7694)
static void C_ccall f_7694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7689)
static void C_ccall f_7689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7685)
static void C_ccall f_7685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7305)
static void C_fcall f_7305(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7315)
static void C_ccall f_7315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7477)
static void C_ccall f_7477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7588)
static void C_ccall f_7588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7595)
static void C_ccall f_7595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7492)
static void C_ccall f_7492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7511)
static void C_fcall f_7511(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7539)
static void C_ccall f_7539(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7537)
static void C_ccall f_7537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7533)
static void C_ccall f_7533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7519)
static void C_fcall f_7519(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7515)
static void C_ccall f_7515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7507)
static void C_ccall f_7507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7499)
static void C_ccall f_7499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7382)
static void C_ccall f_7382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7403)
static void C_fcall f_7403(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7415)
static void C_fcall f_7415(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7411)
static void C_ccall f_7411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7399)
static void C_ccall f_7399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7339)
static void C_fcall f_7339(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7335)
static void C_ccall f_7335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7322)
static void C_ccall f_7322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7264)
static void C_fcall f_7264(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7283)
static void C_ccall f_7283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7280)
static void C_fcall f_7280(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7276)
static void C_ccall f_7276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7239)
static void C_fcall f_7239(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7258)
static void C_ccall f_7258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7252)
static void C_ccall f_7252(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7187)
static void C_ccall f_7187(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7193)
static void C_fcall f_7193(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7207)
static void C_ccall f_7207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7210)
static void C_fcall f_7210(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7217)
static void C_ccall f_7217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7181)
static void C_ccall f_7181(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7153)
static void C_ccall f_7153(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7157)
static void C_ccall f_7157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7163)
static void C_ccall f_7163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7166)
static void C_ccall f_7166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7179)
static void C_ccall f_7179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7169)
static void C_ccall f_7169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7124)
static void C_ccall f_7124(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7124)
static void C_ccall f_7124r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7130)
static void C_fcall f_7130(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7143)
static void C_ccall f_7143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7110)
static void C_ccall f_7110(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7121)
static void C_ccall f_7121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7074)
static void C_ccall f_7074(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7074)
static void C_ccall f_7074r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7080)
static void C_fcall f_7080(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7096)
static void C_ccall f_7096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6997)
static void C_ccall f_6997(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6997)
static void C_ccall f_6997r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7057)
static void C_ccall f_7057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7004)
static void C_fcall f_7004(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7007)
static void C_ccall f_7007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7034)
static void C_ccall f_7034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7040)
static void C_ccall f_7040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7022)
static void C_ccall f_7022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6898)
static void C_ccall f_6898(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6902)
static void C_ccall f_6902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6950)
static void C_ccall f_6950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6952)
static void C_fcall f_6952(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6965)
static void C_ccall f_6965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6904)
static void C_fcall f_6904(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6908)
static void C_ccall f_6908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6943)
static void C_ccall f_6943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6914)
static void C_ccall f_6914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6924)
static void C_ccall f_6924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6917)
static void C_ccall f_6917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6734)
static void C_ccall f_6734(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6839)
static void C_fcall f_6839(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6856)
static void C_ccall f_6856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6864)
static void C_ccall f_6864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6756)
static void C_ccall f_6756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6761)
static void C_fcall f_6761(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6800)
static void C_ccall f_6800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6787)
static void C_ccall f_6787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6737)
static void C_fcall f_6737(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6648)
static void C_ccall f_6648(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6648)
static void C_ccall f_6648r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6655)
static void C_ccall f_6655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6665)
static void C_ccall f_6665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6542)
static void C_ccall f_6542(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6546)
static void C_ccall f_6546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6638)
static void C_ccall f_6638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6642)
static void C_ccall f_6642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6555)
static void C_fcall f_6555(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6624)
static void C_ccall f_6624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6620)
static void C_ccall f_6620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6558)
static void C_ccall f_6558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6607)
static void C_ccall f_6607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6610)
static void C_ccall f_6610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6613)
static void C_ccall f_6613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6561)
static void C_ccall f_6561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6566)
static void C_fcall f_6566(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6600)
static void C_ccall f_6600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6579)
static void C_ccall f_6579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6582)
static void C_fcall f_6582(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6533)
static void C_ccall f_6533(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6493)
static void C_ccall f_6493(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6493)
static void C_ccall f_6493r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6514)
static void C_ccall f_6514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6497)
static void C_ccall f_6497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6511)
static void C_ccall f_6511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6500)
static void C_ccall f_6500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6508)
static void C_ccall f_6508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6503)
static void C_ccall f_6503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6457)
static void C_ccall f_6457(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6457)
static void C_ccall f_6457r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6465)
static void C_ccall f_6465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6435)
static void C_ccall f_6435(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6435)
static void C_ccall f_6435r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6023)
static void C_ccall f_6023(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6023)
static void C_ccall f_6023r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6390)
static void C_fcall f_6390(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6385)
static void C_fcall f_6385(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6025)
static void C_fcall f_6025(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6384)
static void C_ccall f_6384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6029)
static void C_fcall f_6029(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6306)
static void C_ccall f_6306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6321)
static void C_ccall f_6321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6324)
static void C_fcall f_6324(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6327)
static void C_ccall f_6327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6333)
static void C_ccall f_6333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6336)
static void C_ccall f_6336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6342)
static void C_ccall f_6342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6032)
static void C_ccall f_6032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6297)
static void C_ccall f_6297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6285)
static void C_ccall f_6285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6288)
static void C_ccall f_6288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6291)
static void C_ccall f_6291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6038)
static void C_ccall f_6038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6270)
static void C_ccall f_6270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6242)
static void C_ccall f_6242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6266)
static void C_ccall f_6266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6262)
static void C_ccall f_6262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6258)
static void C_ccall f_6258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6041)
static void C_ccall f_6041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6049)
static void C_ccall f_6049(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6229)
static void C_ccall f_6229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6053)
static void C_ccall f_6053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6217)
static void C_ccall f_6217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6074)
static void C_ccall f_6074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6078)
static void C_ccall f_6078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6208)
static void C_ccall f_6208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6086)
static void C_ccall f_6086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6090)
static void C_ccall f_6090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6202)
static void C_ccall f_6202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6093)
static void C_ccall f_6093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6096)
static void C_ccall f_6096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6101)
static void C_fcall f_6101(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6111)
static void C_ccall f_6111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6157)
static void C_ccall f_6157(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6157)
static void C_ccall f_6157r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6166)
static void C_fcall f_6166(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6179)
static void C_ccall f_6179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6182)
static void C_ccall f_6182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6123)
static void C_ccall f_6123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6130)
static void C_ccall f_6130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6141)
static void C_ccall f_6141(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6141)
static void C_ccall f_6141r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6152)
static void C_ccall f_6152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6145)
static void C_ccall f_6145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6135)
static void C_ccall f_6135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6114)
static void C_ccall f_6114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6121)
static void C_ccall f_6121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6083)
static void C_ccall f_6083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6063)
static void C_ccall f_6063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6054)
static void C_ccall f_6054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6044)
static void C_ccall f_6044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5977)
static void C_fcall f_5977(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5987)
static C_word C_fcall f_5987(C_word t0,C_word t1);
C_noret_decl(f_5902)
static void C_ccall f_5902(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5914)
static void C_fcall f_5914(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5927)
static void C_ccall f_5927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5909)
static void C_ccall f_5909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5896)
static void C_ccall f_5896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5812)
static void C_ccall f_5812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5825)
static void C_fcall f_5825(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5858)
static void C_ccall f_5858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5839)
static void C_ccall f_5839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5815)
static void C_fcall f_5815(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5802)
static void C_ccall f_5802(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5802)
static void C_ccall f_5802r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5810)
static void C_ccall f_5810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2872)
static void C_ccall f_2872(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_2872)
static void C_ccall f_2872r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5551)
static void C_fcall f_5551(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5555)
static void C_ccall f_5555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5768)
static void C_ccall f_5768(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5744)
static void C_ccall f_5744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5745)
static void C_ccall f_5745(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5756)
static void C_ccall f_5756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5762)
static void C_ccall f_5762(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5760)
static void C_ccall f_5760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5701)
static void C_ccall f_5701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5704)
static void C_ccall f_5704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5707)
static void C_ccall f_5707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5710)
static void C_ccall f_5710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5711)
static void C_ccall f_5711(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5722)
static void C_ccall f_5722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5726)
static void C_ccall f_5726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5730)
static void C_ccall f_5730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5734)
static void C_ccall f_5734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5737)
static void C_ccall f_5737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5659)
static void C_ccall f_5659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5662)
static void C_ccall f_5662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5665)
static void C_ccall f_5665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5666)
static void C_ccall f_5666(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5677)
static void C_ccall f_5677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5681)
static void C_ccall f_5681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5685)
static void C_ccall f_5685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5688)
static void C_ccall f_5688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5624)
static void C_ccall f_5624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5627)
static void C_ccall f_5627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5628)
static void C_ccall f_5628(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5639)
static void C_ccall f_5639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5643)
static void C_ccall f_5643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5646)
static void C_ccall f_5646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5596)
static void C_ccall f_5596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5597)
static void C_ccall f_5597(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5608)
static void C_ccall f_5608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5611)
static void C_ccall f_5611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5577)
static void C_ccall f_5577(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5587)
static void C_ccall f_5587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5525)
static C_word C_fcall f_5525(C_word t0,C_word t1);
C_noret_decl(f_3085)
static void C_fcall f_3085(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_3092)
static void C_ccall f_3092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3212)
static void C_ccall f_3212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3268)
static void C_fcall f_3268(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3291)
static void C_ccall f_3291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3306)
static void C_ccall f_3306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5322)
static void C_fcall f_5322(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5305)
static void C_ccall f_5305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5309)
static void C_ccall f_5309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5262)
static void C_fcall f_5262(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5275)
static void C_ccall f_5275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5247)
static void C_ccall f_5247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5206)
static void C_ccall f_5206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5152)
static void C_fcall f_5152(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5174)
static void C_ccall f_5174(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5190)
static void C_ccall f_5190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5164)
static void C_ccall f_5164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5146)
static void C_ccall f_5146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5122)
static void C_ccall f_5122(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5083)
static void C_ccall f_5083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5086)
static void C_ccall f_5086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5089)
static void C_ccall f_5089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5112)
static void C_ccall f_5112(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5110)
static void C_ccall f_5110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5106)
static void C_ccall f_5106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5096)
static void C_fcall f_5096(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5066)
static void C_ccall f_5066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5070)
static void C_ccall f_5070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5037)
static void C_ccall f_5037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5041)
static void C_ccall f_5041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4814)
static void C_ccall f_4814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5008)
static void C_ccall f_5008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4956)
static void C_ccall f_4956(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4980)
static C_word C_fcall f_4980(C_word t0);
C_noret_decl(f_4969)
static void C_fcall f_4969(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4820)
static void C_ccall f_4820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4948)
static void C_ccall f_4948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4823)
static void C_ccall f_4823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4826)
static void C_ccall f_4826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4854)
static void C_ccall f_4854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4864)
static void C_fcall f_4864(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4945)
static void C_ccall f_4945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4937)
static void C_ccall f_4937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4874)
static void C_ccall f_4874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4922)
static void C_ccall f_4922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4877)
static void C_ccall f_4877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4878)
static void C_ccall f_4878(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4884)
static void C_fcall f_4884(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4906)
static void C_ccall f_4906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4827)
static void C_ccall f_4827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4831)
static void C_ccall f_4831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4834)
static void C_ccall f_4834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4838)
static void C_ccall f_4838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4841)
static void C_ccall f_4841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4845)
static void C_ccall f_4845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4848)
static void C_ccall f_4848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4801)
static void C_ccall f_4801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4765)
static void C_fcall f_4765(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4678)
static void C_ccall f_4678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4681)
static void C_ccall f_4681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4722)
static void C_ccall f_4722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4734)
static void C_ccall f_4734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4684)
static void C_fcall f_4684(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4687)
static void C_ccall f_4687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4712)
static void C_ccall f_4712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4690)
static void C_ccall f_4690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4700)
static void C_ccall f_4700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4708)
static void C_ccall f_4708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4704)
static void C_ccall f_4704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4693)
static void C_ccall f_4693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4594)
static void C_ccall f_4594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4642)
static void C_ccall f_4642(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4658)
static void C_ccall f_4658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4654)
static void C_ccall f_4654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4597)
static void C_ccall f_4597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4600)
static void C_ccall f_4600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4610)
static void C_ccall f_4610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4616)
static C_word C_fcall f_4616(C_word t0,C_word t1);
C_noret_decl(f_4541)
static void C_ccall f_4541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4561)
static void C_ccall f_4561(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4577)
static void C_ccall f_4577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4573)
static void C_ccall f_4573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4559)
static void C_ccall f_4559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4544)
static void C_ccall f_4544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4551)
static void C_ccall f_4551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4177)
static void C_ccall f_4177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4514)
static void C_ccall f_4514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4525)
static void C_ccall f_4525(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4519)
static void C_ccall f_4519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4189)
static void C_ccall f_4189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4194)
static void C_ccall f_4194(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4198)
static void C_ccall f_4198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4511)
static void C_ccall f_4511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4201)
static void C_ccall f_4201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4503)
static void C_ccall f_4503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4207)
static void C_ccall f_4207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4465)
static void C_ccall f_4465(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4471)
static void C_ccall f_4471(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4471)
static void C_ccall f_4471r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4495)
static void C_ccall f_4495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4442)
static void C_ccall f_4442(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4448)
static void C_ccall f_4448(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4448)
static void C_ccall f_4448r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5479)
static void C_fcall f_5479(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5508)
static void C_ccall f_5508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4464)
static void C_ccall f_4464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4460)
static void C_ccall f_4460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4420)
static void C_ccall f_4420(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4426)
static void C_ccall f_4426(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4438)
static void C_ccall f_4438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4401)
static void C_ccall f_4401(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4407)
static void C_ccall f_4407(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_4407)
static void C_ccall f_4407r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_4373)
static void C_ccall f_4373(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4379)
static void C_ccall f_4379(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4354)
static void C_ccall f_4354(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4360)
static void C_ccall f_4360(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_4360)
static void C_ccall f_4360r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_4326)
static void C_ccall f_4326(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4332)
static void C_ccall f_4332(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4307)
static void C_ccall f_4307(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4313)
static void C_ccall f_4313(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4313)
static void C_ccall f_4313r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4279)
static void C_ccall f_4279(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4285)
static void C_ccall f_4285(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4260)
static void C_ccall f_4260(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4266)
static void C_ccall f_4266(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4266)
static void C_ccall f_4266r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4236)
static void C_ccall f_4236(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4242)
static void C_ccall f_4242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4217)
static void C_ccall f_4217(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4223)
static void C_ccall f_4223(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4223)
static void C_ccall f_4223r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4088)
static void C_ccall f_4088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4157)
static void C_ccall f_4157(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4109)
static void C_ccall f_4109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4135)
static void C_ccall f_4135(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4117)
static void C_ccall f_4117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4133)
static void C_ccall f_4133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4113)
static void C_ccall f_4113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3743)
static void C_ccall f_3743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4072)
static void C_ccall f_4072(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3752)
static void C_ccall f_3752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3755)
static void C_ccall f_3755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4070)
static void C_ccall f_4070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3761)
static void C_ccall f_3761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4062)
static void C_ccall f_4062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3764)
static void C_ccall f_3764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4046)
static void C_ccall f_4046(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3999)
static void C_ccall f_3999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4000)
static void C_ccall f_4000(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4004)
static void C_ccall f_4004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4016)
static void C_fcall f_4016(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4041)
static void C_ccall f_4041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4007)
static void C_ccall f_4007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3923)
static void C_ccall f_3923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3926)
static void C_ccall f_3926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3932)
static void C_ccall f_3932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3935)
static void C_ccall f_3935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3936)
static void C_ccall f_3936(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3952)
static void C_ccall f_3952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3956)
static void C_ccall f_3956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3960)
static void C_ccall f_3960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3964)
static void C_ccall f_3964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3856)
static void C_ccall f_3856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3859)
static void C_ccall f_3859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3865)
static void C_ccall f_3865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3866)
static void C_ccall f_3866(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3882)
static void C_ccall f_3882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3886)
static void C_ccall f_3886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3890)
static void C_ccall f_3890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3807)
static void C_ccall f_3807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3810)
static void C_ccall f_3810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3811)
static void C_ccall f_3811(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3827)
static void C_ccall f_3827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3831)
static void C_ccall f_3831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3773)
static void C_ccall f_3773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3774)
static void C_ccall f_3774(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3790)
static void C_ccall f_3790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3631)
static void C_ccall f_3631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3645)
static void C_ccall f_3645(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3649)
static void C_ccall f_3649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3658)
static void C_ccall f_3658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3691)
static void C_ccall f_3691(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3699)
static void C_ccall f_3699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3664)
static void C_ccall f_3664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3667)
static void C_ccall f_3667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3683)
static void C_ccall f_3683(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3674)
static void C_ccall f_3674(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3682)
static void C_ccall f_3682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3719)
static void C_ccall f_3719(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3727)
static void C_ccall f_3727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3706)
static void C_ccall f_3706(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3718)
static void C_ccall f_3718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3639)
static void C_ccall f_3639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3519)
static void C_ccall f_3519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3578)
static void C_ccall f_3578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3581)
static void C_ccall f_3581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3603)
static void C_ccall f_3603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3584)
static void C_ccall f_3584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3585)
static void C_ccall f_3585(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3589)
static void C_ccall f_3589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3592)
static void C_ccall f_3592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3556)
static void C_ccall f_3556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3559)
static void C_ccall f_3559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3560)
static void C_ccall f_3560(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3564)
static void C_ccall f_3564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3459)
static void C_ccall f_3459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3462)
static void C_ccall f_3462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3465)
static void C_ccall f_3465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3468)
static void C_ccall f_3468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3469)
static void C_ccall f_3469(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3476)
static void C_ccall f_3476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3449)
static void C_ccall f_3449(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3415)
static void C_ccall f_3415(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3409)
static void C_ccall f_3409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3410)
static void C_ccall f_3410(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3393)
static void C_ccall f_3393(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3315)
static void C_ccall f_3315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3318)
static void C_ccall f_3318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3375)
static void C_ccall f_3375(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3373)
static void C_ccall f_3373(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3365)
static void C_ccall f_3365(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3357)
static void C_ccall f_3357(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3349)
static void C_ccall f_3349(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3341)
static void C_ccall f_3341(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3333)
static void C_ccall f_3333(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3325)
static void C_ccall f_3325(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3269)
static void C_ccall f_3269(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3258)
static void C_ccall f_3258(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3256)
static void C_ccall f_3256(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3245)
static void C_ccall f_3245(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3243)
static void C_ccall f_3243(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3235)
static void C_ccall f_3235(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3227)
static void C_ccall f_3227(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3219)
static void C_ccall f_3219(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3111)
static void C_ccall f_3111(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3179)
static void C_ccall f_3179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3121)
static void C_ccall f_3121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3170)
static void C_ccall f_3170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3155)
static void C_fcall f_3155(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3150)
static void C_fcall f_3150(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3151)
static void C_ccall f_3151(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3127)
static void C_ccall f_3127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3130)
static void C_ccall f_3130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3131)
static void C_ccall f_3131(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3202)
static void C_ccall f_3202(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3193)
static void C_ccall f_3193(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3105)
static void C_ccall f_3105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3093)
static void C_ccall f_3093(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3034)
static void C_fcall f_3034(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3038)
static void C_ccall f_3038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3059)
static void C_ccall f_3059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3070)
static void C_ccall f_3070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3066)
static void C_ccall f_3066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3039)
static void C_ccall f_3039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3043)
static void C_ccall f_3043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3046)
static void C_ccall f_3046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3050)
static void C_ccall f_3050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3053)
static void C_ccall f_3053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3028)
static void C_fcall f_3028(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2932)
static void C_fcall f_2932(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2936)
static void C_ccall f_2936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2944)
static void C_fcall f_2944(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2986)
static C_word C_fcall f_2986(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_2917)
static void C_fcall f_2917(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2921)
static void C_ccall f_2921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2927)
static void C_ccall f_2927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2878)
static void C_fcall f_2878(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2891)
static void C_fcall f_2891(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2828)
static void C_ccall f_2828(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2847)
static void C_ccall f_2847(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2859)
static void C_ccall f_2859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2862)
static void C_ccall f_2862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2865)
static void C_ccall f_2865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2855)
static void C_ccall f_2855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2834)
static void C_ccall f_2834(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2768)
static void C_ccall f_2768(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2772)
static void C_ccall f_2772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2780)
static void C_fcall f_2780(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2706)
static void C_ccall f_2706(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2712)
static void C_fcall f_2712(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2735)
static void C_fcall f_2735(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2748)
static void C_ccall f_2748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2722)
static void C_ccall f_2722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2686)
static void C_ccall f_2686(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2698)
static void C_ccall f_2698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2701)
static void C_ccall f_2701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2694)
static void C_ccall f_2694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2626)
static void C_ccall f_2626(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2630)
static void C_ccall f_2630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2638)
static void C_fcall f_2638(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2571)
static void C_ccall f_2571(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2624)
static void C_ccall f_2624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2581)
static C_word C_fcall f_2581(C_word t0,C_word t1);
C_noret_decl(f_2556)
static void C_ccall f_2556(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2544)
static void C_ccall f_2544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2548)
static void C_ccall f_2548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2517)
static void C_ccall f_2517(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2517)
static void C_ccall f_2517r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2482)
static void C_ccall f_2482(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2482)
static void C_ccall f_2482r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;

/* from CHICKEN_get_error_message */
 void  CHICKEN_get_error_message(char *t0,int t1){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer_or_false(&a,(void*)t0);
C_save(x);
x=C_fix((C_word)t1);
C_save(x);C_callback_wrapper((void *)f_9283,2);}

/* from CHICKEN_load */
 int  CHICKEN_load(char * t0){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0))),*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9268,1));}

/* from CHICKEN_read */
 int  CHICKEN_read(char * t0,C_word *t1){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9246,2));}

/* from CHICKEN_apply_to_string */
 int  CHICKEN_apply_to_string(C_word t0,C_word t1,char *t2,int t3){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=((C_word)t1);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t2);
C_save(x);
x=C_fix((C_word)t3);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9220,4));}

/* from CHICKEN_apply */
 int  CHICKEN_apply(C_word t0,C_word t1,C_word *t2){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=((C_word)t1);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9204,3));}

/* from CHICKEN_eval_string_to_string */
 int  CHICKEN_eval_string_to_string(char * t0,char *t1,int t2){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
x=C_fix((C_word)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9167,3));}

/* from CHICKEN_eval_to_string */
 int  CHICKEN_eval_to_string(C_word t0,char *t1,int t2){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
x=C_fix((C_word)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9141,3));}

/* from CHICKEN_eval_string */
 int  CHICKEN_eval_string(char * t0,C_word *t1){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9102,2));}

/* from CHICKEN_eval */
 int  CHICKEN_eval(C_word t0,C_word *t1){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9086,2));}

/* from CHICKEN_yield */
 int  CHICKEN_yield(){
C_word x,s=0,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
return C_truep(C_callback_wrapper((void *)f_9074,0));}

C_noret_decl(trf_9622)
static void C_fcall trf_9622(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9622(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9622(t0,t1);}

C_noret_decl(trf_9590)
static void C_fcall trf_9590(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9590(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9590(t0,t1);}

C_noret_decl(trf_6519)
static void C_fcall trf_6519(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6519(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6519(t0,t1);}

C_noret_decl(trf_9551)
static void C_fcall trf_9551(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9551(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9551(t0,t1);}

C_noret_decl(trf_9471)
static void C_fcall trf_9471(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9471(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9471(t0,t1,t2);}

C_noret_decl(trf_9397)
static void C_fcall trf_9397(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9397(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9397(t0,t1);}

C_noret_decl(trf_9363)
static void C_fcall trf_9363(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9363(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9363(t0,t1);}

C_noret_decl(trf_9334)
static void C_fcall trf_9334(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9334(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9334(t0,t1,t2);}

C_noret_decl(trf_9308)
static void C_fcall trf_9308(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9308(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9308(t0,t1,t2);}

C_noret_decl(trf_9065)
static void C_fcall trf_9065(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9065(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9065(t0,t1,t2);}

C_noret_decl(trf_9006)
static void C_fcall trf_9006(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9006(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9006(t0,t1);}

C_noret_decl(trf_8958)
static void C_fcall trf_8958(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8958(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8958(t0,t1);}

C_noret_decl(trf_8945)
static void C_fcall trf_8945(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8945(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8945(t0,t1);}

C_noret_decl(trf_8697)
static void C_fcall trf_8697(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8697(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8697(t0,t1);}

C_noret_decl(trf_8755)
static void C_fcall trf_8755(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8755(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8755(t0,t1,t2,t3);}

C_noret_decl(trf_8779)
static void C_fcall trf_8779(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8779(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8779(t0,t1,t2);}

C_noret_decl(trf_8571)
static void C_fcall trf_8571(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8571(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8571(t0,t1);}

C_noret_decl(trf_8576)
static void C_fcall trf_8576(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8576(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8576(t0,t1,t2);}

C_noret_decl(trf_8661)
static void C_fcall trf_8661(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8661(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8661(t0,t1);}

C_noret_decl(trf_8533)
static void C_fcall trf_8533(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8533(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8533(t0,t1);}

C_noret_decl(trf_8539)
static void C_fcall trf_8539(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8539(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8539(t0,t1,t2);}

C_noret_decl(trf_8411)
static void C_fcall trf_8411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8411(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8411(t0,t1,t2,t3);}

C_noret_decl(trf_8387)
static void C_fcall trf_8387(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8387(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8387(t0,t1,t2);}

C_noret_decl(trf_8393)
static void C_fcall trf_8393(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8393(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8393(t0,t1,t2);}

C_noret_decl(trf_8366)
static void C_fcall trf_8366(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8366(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8366(t0,t1);}

C_noret_decl(trf_8328)
static void C_fcall trf_8328(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8328(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8328(t0,t1,t2);}

C_noret_decl(trf_8286)
static void C_fcall trf_8286(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8286(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8286(t0,t1,t2);}

C_noret_decl(trf_8251)
static void C_fcall trf_8251(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8251(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8251(t0,t1,t2,t3);}

C_noret_decl(trf_8226)
static void C_fcall trf_8226(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8226(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8226(t0,t1);}

C_noret_decl(trf_8193)
static void C_fcall trf_8193(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8193(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8193(t0,t1);}

C_noret_decl(trf_8010)
static void C_fcall trf_8010(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8010(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8010(t0,t1,t2,t3);}

C_noret_decl(trf_8034)
static void C_fcall trf_8034(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8034(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8034(t0,t1,t2,t3);}

C_noret_decl(trf_7896)
static void C_fcall trf_7896(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7896(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7896(t0,t1,t2);}

C_noret_decl(trf_7923)
static void C_fcall trf_7923(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7923(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7923(t0,t1,t2);}

C_noret_decl(trf_7814)
static void C_fcall trf_7814(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7814(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7814(t0,t1,t2);}

C_noret_decl(trf_7834)
static void C_fcall trf_7834(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7834(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7834(t0,t1);}

C_noret_decl(trf_7626)
static void C_fcall trf_7626(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7626(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7626(t0,t1);}

C_noret_decl(trf_7667)
static void C_fcall trf_7667(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7667(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7667(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7305)
static void C_fcall trf_7305(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7305(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7305(t0,t1,t2);}

C_noret_decl(trf_7511)
static void C_fcall trf_7511(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7511(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7511(t0,t1);}

C_noret_decl(trf_7519)
static void C_fcall trf_7519(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7519(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7519(t0,t1);}

C_noret_decl(trf_7403)
static void C_fcall trf_7403(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7403(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7403(t0,t1);}

C_noret_decl(trf_7415)
static void C_fcall trf_7415(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7415(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7415(t0,t1);}

C_noret_decl(trf_7339)
static void C_fcall trf_7339(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7339(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7339(t0,t1);}

C_noret_decl(trf_7264)
static void C_fcall trf_7264(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7264(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7264(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7280)
static void C_fcall trf_7280(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7280(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7280(t0,t1);}

C_noret_decl(trf_7239)
static void C_fcall trf_7239(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7239(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7239(t0,t1,t2,t3);}

C_noret_decl(trf_7193)
static void C_fcall trf_7193(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7193(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7193(t0,t1,t2);}

C_noret_decl(trf_7210)
static void C_fcall trf_7210(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7210(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7210(t0,t1);}

C_noret_decl(trf_7130)
static void C_fcall trf_7130(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7130(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7130(t0,t1,t2);}

C_noret_decl(trf_7080)
static void C_fcall trf_7080(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7080(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7080(t0,t1,t2);}

C_noret_decl(trf_7004)
static void C_fcall trf_7004(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7004(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7004(t0,t1);}

C_noret_decl(trf_6952)
static void C_fcall trf_6952(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6952(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6952(t0,t1,t2);}

C_noret_decl(trf_6904)
static void C_fcall trf_6904(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6904(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6904(t0,t1,t2);}

C_noret_decl(trf_6839)
static void C_fcall trf_6839(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6839(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6839(t0,t1,t2);}

C_noret_decl(trf_6761)
static void C_fcall trf_6761(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6761(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6761(t0,t1,t2);}

C_noret_decl(trf_6737)
static void C_fcall trf_6737(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6737(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6737(t0,t1);}

C_noret_decl(trf_6555)
static void C_fcall trf_6555(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6555(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6555(t0,t1);}

C_noret_decl(trf_6566)
static void C_fcall trf_6566(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6566(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6566(t0,t1,t2);}

C_noret_decl(trf_6582)
static void C_fcall trf_6582(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6582(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6582(t0,t1);}

C_noret_decl(trf_6390)
static void C_fcall trf_6390(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6390(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6390(t0,t1);}

C_noret_decl(trf_6385)
static void C_fcall trf_6385(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6385(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6385(t0,t1,t2);}

C_noret_decl(trf_6025)
static void C_fcall trf_6025(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6025(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6025(t0,t1,t2,t3);}

C_noret_decl(trf_6029)
static void C_fcall trf_6029(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6029(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6029(t0,t1);}

C_noret_decl(trf_6324)
static void C_fcall trf_6324(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6324(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6324(t0,t1);}

C_noret_decl(trf_6101)
static void C_fcall trf_6101(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6101(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6101(t0,t1,t2);}

C_noret_decl(trf_6166)
static void C_fcall trf_6166(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6166(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6166(t0,t1,t2);}

C_noret_decl(trf_5977)
static void C_fcall trf_5977(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5977(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5977(t0,t1);}

C_noret_decl(trf_5914)
static void C_fcall trf_5914(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5914(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5914(t0,t1,t2);}

C_noret_decl(trf_5825)
static void C_fcall trf_5825(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5825(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5825(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5815)
static void C_fcall trf_5815(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5815(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5815(t0,t1);}

C_noret_decl(trf_5551)
static void C_fcall trf_5551(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5551(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5551(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3085)
static void C_fcall trf_3085(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3085(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_3085(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_3268)
static void C_fcall trf_3268(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3268(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3268(t0,t1);}

C_noret_decl(trf_5322)
static void C_fcall trf_5322(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5322(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5322(t0,t1);}

C_noret_decl(trf_5262)
static void C_fcall trf_5262(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5262(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5262(t0,t1,t2);}

C_noret_decl(trf_5152)
static void C_fcall trf_5152(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5152(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5152(t0,t1,t2);}

C_noret_decl(trf_5096)
static void C_fcall trf_5096(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5096(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5096(t0,t1);}

C_noret_decl(trf_4969)
static void C_fcall trf_4969(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4969(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4969(t0,t1);}

C_noret_decl(trf_4864)
static void C_fcall trf_4864(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4864(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4864(t0,t1,t2,t3);}

C_noret_decl(trf_4884)
static void C_fcall trf_4884(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4884(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4884(t0,t1,t2);}

C_noret_decl(trf_4765)
static void C_fcall trf_4765(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4765(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4765(t0,t1);}

C_noret_decl(trf_4684)
static void C_fcall trf_4684(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4684(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4684(t0,t1);}

C_noret_decl(trf_5479)
static void C_fcall trf_5479(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5479(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5479(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4016)
static void C_fcall trf_4016(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4016(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4016(t0,t1,t2,t3);}

C_noret_decl(trf_3155)
static void C_fcall trf_3155(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3155(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3155(t0,t1);}

C_noret_decl(trf_3150)
static void C_fcall trf_3150(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3150(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3150(t0,t1);}

C_noret_decl(trf_3034)
static void C_fcall trf_3034(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3034(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3034(t0,t1);}

C_noret_decl(trf_3028)
static void C_fcall trf_3028(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3028(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3028(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2932)
static void C_fcall trf_2932(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2932(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2932(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2944)
static void C_fcall trf_2944(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2944(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2944(t0,t1,t2,t3);}

C_noret_decl(trf_2917)
static void C_fcall trf_2917(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2917(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2917(t0,t1,t2,t3);}

C_noret_decl(trf_2878)
static void C_fcall trf_2878(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2878(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2878(t0,t1,t2,t3);}

C_noret_decl(trf_2891)
static void C_fcall trf_2891(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2891(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2891(t0,t1);}

C_noret_decl(trf_2780)
static void C_fcall trf_2780(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2780(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2780(t0,t1,t2);}

C_noret_decl(trf_2712)
static void C_fcall trf_2712(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2712(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2712(t0,t1,t2);}

C_noret_decl(trf_2735)
static void C_fcall trf_2735(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2735(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2735(t0,t1,t2);}

C_noret_decl(trf_2638)
static void C_fcall trf_2638(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2638(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2638(t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr5rv)
static void C_fcall tr5rv(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5rv(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n+1);
t5=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_eval_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_eval_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("eval_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(6621)){
C_save(t1);
C_rereclaim2(6621*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,411);
lf[0]=C_h_intern(&lf[0],1,"d");
lf[1]=C_h_intern(&lf[1],2,"pp");
lf[2]=C_h_intern(&lf[2],5,"print");
lf[3]=C_h_intern(&lf[3],24,"\003syscore-library-modules");
lf[4]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006extras\376\003\000\000\002\376\001\000\000\007lolevel\376\003\000\000\002\376\001\000\000\005utils\376\003\000\000\002\376\001\000\000\005files\376\003\000\000\002\376\001\000\000\003tcp\376\003\000\000"
"\002\376\001\000\000\005regex\376\003\000\000\002\376\001\000\000\005posix\376\003\000\000\002\376\001\000\000\006srfi-1\376\003\000\000\002\376\001\000\000\006srfi-4\376\003\000\000\002\376\001\000\000\007srfi-13\376\003\000\000\002"
"\376\001\000\000\007srfi-14\376\003\000\000\002\376\001\000\000\007srfi-18\376\003\000\000\002\376\001\000\000\007srfi-69\376\003\000\000\002\376\001\000\000\017data-structures\376\003\000\000\002\376\001\000\000"
"\005ports\376\003\000\000\002\376\001\000\000\016chicken-syntax\376\377\016");
lf[5]=C_h_intern(&lf[5],28,"\003sysexplicit-library-modules");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000\003.so");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\004.scm");
lf[10]=C_h_intern(&lf[10],18,"\003syschicken-prefix");
lf[11]=C_h_intern(&lf[11],17,"\003sysstring-append");
lf[12]=C_h_intern(&lf[12],12,"chicken-home");
lf[13]=C_h_intern(&lf[13],17,"\003syspeek-c-string");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\015share/chicken");
lf[15]=C_h_intern(&lf[15],15,"\003syshash-symbol");
lf[16]=C_h_intern(&lf[16],18,"\003syshash-table-ref");
lf[17]=C_h_intern(&lf[17],19,"\003syshash-table-set!");
lf[18]=C_h_intern(&lf[18],22,"\003syshash-table-update!");
lf[19]=C_h_intern(&lf[19],23,"\003syshash-table-for-each");
lf[20]=C_h_intern(&lf[20],28,"\003sysarbitrary-unbound-symbol");
lf[21]=C_h_intern(&lf[21],23,"\003syshash-table-location");
lf[22]=C_h_intern(&lf[22],20,"\003syseval-environment");
lf[23]=C_h_intern(&lf[23],26,"\003sysenvironment-is-mutable");
lf[24]=C_h_intern(&lf[24],18,"\003syseval-decorator");
lf[25]=C_h_intern(&lf[25],20,"\003sysmake-lambda-info");
lf[26]=C_h_intern(&lf[26],17,"get-output-string");
lf[27]=C_h_intern(&lf[27],5,"write");
lf[28]=C_h_intern(&lf[28],18,"open-output-string");
lf[29]=C_h_intern(&lf[29],19,"\003sysdecorate-lambda");
lf[30]=C_h_intern(&lf[30],19,"\003sysunbound-in-eval");
lf[31]=C_h_intern(&lf[31],20,"\003syseval-debug-level");
lf[32]=C_h_intern(&lf[32],7,"reverse");
lf[33]=C_h_intern(&lf[33],20,"with-input-from-file");
lf[34]=C_h_intern(&lf[34],7,"display");
lf[35]=C_h_intern(&lf[35],22,"\003syscompile-to-closure");
lf[36]=C_h_intern(&lf[36],7,"\003sysget");
lf[37]=C_h_intern(&lf[37],16,"\004coremacro-alias");
lf[38]=C_h_intern(&lf[38],19,"\003sysundefined-value");
lf[39]=C_h_intern(&lf[39],18,"\003syscurrent-module");
lf[40]=C_h_intern(&lf[40],21,"\003sysmacro-environment");
lf[41]=C_h_intern(&lf[41],28,"\003syscurrent-meta-environment");
lf[42]=C_h_intern(&lf[42],16,"\003sysdynamic-wind");
lf[43]=C_h_intern(&lf[43],26,"\003sysmeta-macro-environment");
lf[44]=C_h_intern(&lf[44],9,"\003syserror");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\020unbound variable");
lf[46]=C_h_intern(&lf[46],21,"\003syssyntax-error-hook");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000!reference to undefined identifier");
lf[48]=C_h_intern(&lf[48],32,"\003syssymbol-has-toplevel-binding\077");
lf[49]=C_h_intern(&lf[49],14,"\004coreprimitive");
lf[50]=C_h_intern(&lf[50],21,"\003sysalias-global-hook");
lf[51]=C_h_intern(&lf[51],18,"\003syscurrent-thread");
lf[52]=C_h_intern(&lf[52],5,"quote");
lf[53]=C_h_intern(&lf[53],16,"\003sysstrip-syntax");
lf[54]=C_h_intern(&lf[54],16,"\003syscheck-syntax");
lf[55]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[56]=C_h_intern(&lf[56],6,"syntax");
lf[57]=C_h_intern(&lf[57],11,"\004coresyntax");
lf[58]=C_h_intern(&lf[58],15,"\004coreglobal-ref");
lf[59]=C_h_intern(&lf[59],10,"\004corecheck");
lf[60]=C_h_intern(&lf[60],14,"\004coreimmutable");
lf[61]=C_h_intern(&lf[61],14,"\004coreundefined");
lf[62]=C_h_intern(&lf[62],2,"if");
lf[63]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[64]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002if\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_");
lf[65]=C_h_intern(&lf[65],5,"begin");
lf[66]=C_h_intern(&lf[66],10,"\004corebegin");
lf[67]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[68]=C_h_intern(&lf[68],10,"\003sysappend");
lf[69]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[70]=C_h_intern(&lf[70],4,"set!");
lf[71]=C_h_intern(&lf[71],9,"\004coreset!");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000 assignment to immutable variable");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\042assignment of undefined identifier");
lf[74]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[75]=C_h_intern(&lf[75],3,"let");
lf[76]=C_h_intern(&lf[76],8,"\004corelet");
lf[77]=C_h_intern(&lf[77],15,"\003sysmake-vector");
lf[78]=C_h_intern(&lf[78],7,"\003sysmap");
lf[79]=C_h_intern(&lf[79],21,"\003syscanonicalize-body");
lf[80]=C_h_intern(&lf[80],6,"append");
lf[81]=C_h_intern(&lf[81],3,"map");
lf[82]=C_h_intern(&lf[82],4,"cons");
lf[83]=C_h_intern(&lf[83],6,"gensym");
lf[84]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[85]=C_h_intern(&lf[85],6,"letrec");
lf[86]=C_h_intern(&lf[86],11,"\004coreletrec");
lf[87]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[88]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[89]=C_h_intern(&lf[89],6,"lambda");
lf[90]=C_h_intern(&lf[90],11,"\004corelambda");
lf[91]=C_h_intern(&lf[91],1,"\077");
lf[92]=C_h_intern(&lf[92],10,"\003sysvector");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\022bad argument count");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\022bad argument count");
lf[95]=C_h_intern(&lf[95],25,"\003sysdecompose-lambda-list");
lf[96]=C_h_intern(&lf[96],31,"\003sysexpand-extended-lambda-list");
lf[97]=C_h_intern(&lf[97],25,"\003sysextended-lambda-list\077");
lf[98]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[99]=C_h_intern(&lf[99],10,"let-syntax");
lf[100]=C_h_intern(&lf[100],18,"\003syser-transformer");
lf[101]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012let-syntax\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_"
"\376\377\001\000\000\000\001");
lf[102]=C_h_intern(&lf[102],13,"letrec-syntax");
lf[103]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015letrec-syntax\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000"
"\000\001_\376\377\001\000\000\000\001");
lf[104]=C_h_intern(&lf[104],13,"define-syntax");
lf[105]=C_h_intern(&lf[105],22,"define-compiled-syntax");
lf[106]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[107]=C_h_intern(&lf[107],28,"\003sysextend-macro-environment");
lf[108]=C_h_intern(&lf[108],23,"\003syscurrent-environment");
lf[109]=C_h_intern(&lf[109],26,"\003sysregister-syntax-export");
lf[110]=C_h_intern(&lf[110],5,"caadr");
lf[111]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[112]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[113]=C_h_intern(&lf[113],27,"\004coredefine-compiler-syntax");
lf[114]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[115]=C_h_intern(&lf[115],24,"\004corelet-compiler-syntax");
lf[116]=C_h_intern(&lf[116],11,"\004coremodule");
lf[117]=C_h_intern(&lf[117],29,"\003sysinitial-macro-environment");
lf[118]=C_h_intern(&lf[118],19,"\003sysfinalize-module");
lf[119]=C_h_intern(&lf[119],19,"\003sysregister-module");
lf[120]=C_h_intern(&lf[120],6,"module");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\031modules may not be nested");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid export syntax");
lf[123]=C_h_intern(&lf[123],16,"\004coreloop-lambda");
lf[124]=C_h_intern(&lf[124],17,"\004corenamed-lambda");
lf[125]=C_h_intern(&lf[125],23,"\004corerequire-for-syntax");
lf[126]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[127]=C_h_intern(&lf[127],11,"\003sysrequire");
lf[128]=C_h_intern(&lf[128],31,"\003syslookup-runtime-requirements");
lf[129]=C_h_intern(&lf[129],22,"\004corerequire-extension");
lf[130]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[131]=C_h_intern(&lf[131],22,"\003sysdo-the-right-thing");
lf[132]=C_h_intern(&lf[132],24,"\004coreelaborationtimeonly");
lf[133]=C_h_intern(&lf[133],23,"\004coreelaborationtimetoo");
lf[134]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[135]=C_h_intern(&lf[135],19,"\004corecompiletimetoo");
lf[136]=C_h_intern(&lf[136],20,"\004corecompiletimeonly");
lf[137]=C_h_intern(&lf[137],13,"\004corecallunit");
lf[138]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[139]=C_h_intern(&lf[139],12,"\004coredeclare");
lf[140]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[141]=C_h_intern(&lf[141],10,"\000compiling");
lf[142]=C_h_intern(&lf[142],12,"\003sysfeatures");
lf[143]=C_h_intern(&lf[143],28,"\010compilerprocess-declaration");
lf[144]=C_h_intern(&lf[144],8,"\003syswarn");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000,declarations are ignored in interpreted code");
lf[146]=C_h_intern(&lf[146],13,"define-inline");
lf[147]=C_h_intern(&lf[147],15,"define-constant");
lf[148]=C_h_intern(&lf[148],6,"define");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000%cannot evaluate compiler-special-form");
lf[150]=C_h_intern(&lf[150],8,"\004coreapp");
lf[151]=C_h_intern(&lf[151],8,"location");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000%cannot evaluate compiler-special-form");
lf[153]=C_h_intern(&lf[153],11,"\004coreinline");
lf[154]=C_h_intern(&lf[154],20,"\004coreinline_allocate");
lf[155]=C_h_intern(&lf[155],19,"\004coreforeign-lambda");
lf[156]=C_h_intern(&lf[156],28,"\004coredefine-foreign-variable");
lf[157]=C_h_intern(&lf[157],29,"\004coredefine-external-variable");
lf[158]=C_h_intern(&lf[158],17,"\004corelet-location");
lf[159]=C_h_intern(&lf[159],22,"\004coreforeign-primitive");
lf[160]=C_h_intern(&lf[160],20,"\004coreforeign-lambda*");
lf[161]=C_h_intern(&lf[161],24,"\004coredefine-foreign-type");
lf[162]=C_h_intern(&lf[162],10,"\003sysexpand");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal non-atomic object");
lf[164]=C_h_intern(&lf[164],11,"\003sysnumber\077");
lf[165]=C_h_intern(&lf[165],8,"keyword\077");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\024malformed expression");
lf[167]=C_h_intern(&lf[167],16,"\003syseval-handler");
lf[168]=C_h_intern(&lf[168],12,"eval-handler");
lf[169]=C_h_intern(&lf[169],4,"eval");
lf[170]=C_h_intern(&lf[170],24,"\003syssyntax-error-culprit");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\032illegal lambda-list syntax");
lf[172]=C_h_intern(&lf[172],12,"load-verbose");
lf[173]=C_h_intern(&lf[173],14,"\003sysabort-load");
lf[174]=C_h_intern(&lf[174],27,"\003syscurrent-source-filename");
lf[175]=C_h_intern(&lf[175],21,"\003syscurrent-load-path");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[177]=C_h_intern(&lf[177],18,"\003sysdload-disabled");
lf[178]=C_h_intern(&lf[178],22,"set-dynamic-load-mode!");
lf[179]=C_h_intern(&lf[179],21,"\003sysset-dlopen-flags!");
lf[180]=C_h_intern(&lf[180],6,"global");
lf[181]=C_h_intern(&lf[181],5,"local");
lf[182]=C_h_intern(&lf[182],4,"lazy");
lf[183]=C_h_intern(&lf[183],3,"now");
lf[184]=C_h_intern(&lf[184],15,"\003syssignal-hook");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\031invalid dynamic-load mode");
lf[186]=C_h_intern(&lf[186],4,"read");
lf[187]=C_h_intern(&lf[187],7,"newline");
lf[188]=C_h_intern(&lf[188],12,"flush-output");
lf[189]=C_h_intern(&lf[189],15,"open-input-file");
lf[190]=C_h_intern(&lf[190],16,"close-input-port");
lf[191]=C_h_intern(&lf[191],13,"string-append");
lf[192]=C_h_intern(&lf[192],8,"\003sysload");
lf[193]=C_h_intern(&lf[193],31,"\003sysread-error-with-line-number");
lf[194]=C_h_intern(&lf[194],17,"\003sysdisplay-times");
lf[195]=C_h_intern(&lf[195],14,"\003sysstop-timer");
lf[196]=C_h_intern(&lf[196],15,"\003sysstart-timer");
lf[197]=C_h_intern(&lf[197],4,"load");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\036unable to load compiled module");
lf[199]=C_h_intern(&lf[199],9,"peek-char");
lf[200]=C_h_intern(&lf[200],13,"\003syssubstring");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[202]=C_h_intern(&lf[202],30,"call-with-current-continuation");
lf[203]=C_h_intern(&lf[203],9,"\003sysdload");
lf[204]=C_h_intern(&lf[204],17,"\003sysmake-c-string");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\002./");
lf[206]=C_h_intern(&lf[206],11,"\000file-error");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\005 ...\012");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\012; loading ");
lf[210]=C_h_intern(&lf[210],13,"\003sysfile-info");
lf[211]=C_h_intern(&lf[211],26,"\003sysload-dynamic-extension");
lf[212]=C_h_intern(&lf[212],11,"\000type-error");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a port or string");
lf[214]=C_h_intern(&lf[214],5,"port\077");
lf[215]=C_h_intern(&lf[215],20,"\003sysexpand-home-path");
lf[216]=C_h_intern(&lf[216],13,"load-relative");
lf[217]=C_h_intern(&lf[217],12,"load-noisily");
lf[218]=C_h_intern(&lf[218],15,"\003sysget-keyword");
lf[219]=C_h_intern(&lf[219],8,"\000printer");
lf[220]=C_h_intern(&lf[220],5,"\000time");
lf[221]=C_h_intern(&lf[221],10,"\000evaluator");
lf[222]=C_h_intern(&lf[222],26,"\003sysload-library-extension");
lf[223]=C_h_intern(&lf[223],6,"cygwin");
lf[224]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014cygchicken-0\376\377\016");
lf[225]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012libchicken\376\377\016");
lf[226]=C_h_intern(&lf[226],34,"\003sysdefault-dynamic-load-libraries");
lf[227]=C_h_intern(&lf[227],22,"dynamic-load-libraries");
lf[228]=C_h_intern(&lf[228],18,"\003sysload-library-0");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\005 ...\012");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\022; loading library ");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[233]=C_h_intern(&lf[233],24,"\003sysstring->c-identifier");
lf[234]=C_h_intern(&lf[234],16,"\003sys->feature-id");
lf[235]=C_h_intern(&lf[235],16,"\003sysload-library");
lf[236]=C_h_intern(&lf[236],12,"load-library");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\026unable to load library");
lf[238]=C_h_intern(&lf[238],31,"\003syscanonicalize-extension-path");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid extension path");
lf[240]=C_h_intern(&lf[240],18,"\003syssymbol->string");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[244]=C_h_intern(&lf[244],19,"\003sysrepository-path");
lf[245]=C_h_intern(&lf[245],15,"repository-path");
lf[246]=C_h_intern(&lf[246],14,"\003syssetup-mode");
lf[247]=C_h_intern(&lf[247],12,"file-exists\077");
lf[248]=C_h_intern(&lf[248],18,"\003sysfind-extension");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[250]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\001.\376\377\016");
lf[251]=C_h_intern(&lf[251],21,"\003sysinclude-pathnames");
lf[252]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\001.\376\377\016");
lf[253]=C_h_intern(&lf[253],21,"\003sysloaded-extensions");
lf[254]=C_h_intern(&lf[254],14,"string->symbol");
lf[255]=C_h_intern(&lf[255],18,"\003sysload-extension");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot load core library");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot load extension");
lf[258]=C_h_intern(&lf[258],11,"\003sysprovide");
lf[259]=C_h_intern(&lf[259],7,"provide");
lf[260]=C_h_intern(&lf[260],13,"\003sysprovided\077");
lf[261]=C_h_intern(&lf[261],9,"provided\077");
lf[262]=C_h_intern(&lf[262],7,"require");
lf[263]=C_h_intern(&lf[263],25,"\003sysextension-information");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[267]=C_h_intern(&lf[267],21,"extension-information");
lf[268]=C_h_intern(&lf[268],18,"require-at-runtime");
lf[269]=C_h_intern(&lf[269],12,"vector->list");
lf[270]=C_h_intern(&lf[270],14,"dynamic/syntax");
lf[271]=C_h_intern(&lf[271],7,"dynamic");
lf[272]=C_h_intern(&lf[272],11,"lset-adjoin");
lf[273]=C_h_intern(&lf[273],3,"eq\077");
lf[274]=C_h_intern(&lf[274],26,"\010compilerfile-requirements");
lf[275]=C_h_intern(&lf[275],6,"import");
lf[276]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007chicken\376\003\000\000\002\376\001\000\000\006srfi-2\376\003\000\000\002\376\001\000\000\006srfi-6\376\003\000\000\002\376\001\000\000\007srfi-10\376\003\000\000\002\376\001\000\000\007srfi"
"-12\376\003\000\000\002\376\001\000\000\007srfi-23\376\003\000\000\002\376\001\000\000\007srfi-28\376\003\000\000\002\376\001\000\000\007srfi-30\376\003\000\000\002\376\001\000\000\007srfi-31\376\003\000\000\002\376\001\000\000"
"\007srfi-39\376\003\000\000\002\376\001\000\000\007srfi-88\376\003\000\000\002\376\001\000\000\007srfi-98\376\377\016");
lf[277]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[278]=C_h_intern(&lf[278],4,"uses");
lf[279]=C_h_intern(&lf[279],11,"import-only");
lf[280]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[281]=C_h_intern(&lf[281],17,"require-extension");
lf[282]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006srfi-6\376\003\000\000\002\376\001\000\000\006srfi-8\376\003\000\000\002\376\001\000\000\006srfi-9\376\003\000\000\002\376\001\000\000\007srfi-11\376\003\000\000\002\376\001\000\000\007srfi-"
"15\376\003\000\000\002\376\001\000\000\007srfi-16\376\003\000\000\002\376\001\000\000\007srfi-17\376\003\000\000\002\376\001\000\000\007srfi-26\376\003\000\000\002\376\001\000\000\007srfi-55\376\377\016");
lf[283]=C_h_intern(&lf[283],12,"\003sysfeature\077");
lf[284]=C_h_intern(&lf[284],24,"\003sysextension-specifiers");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\035undefined extension specifier");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid extension specifier");
lf[287]=C_h_intern(&lf[287],24,"set-extension-specifier!");
lf[288]=C_h_intern(&lf[288],11,"string-copy");
lf[291]=C_h_intern(&lf[291],11,"environment");
lf[293]=C_h_intern(&lf[293],16,"\003sysenvironment\077");
lf[294]=C_h_intern(&lf[294],18,"\003syscopy-env-table");
lf[295]=C_h_intern(&lf[295],23,"\003sysenvironment-symbols");
lf[296]=C_h_intern(&lf[296],18,"\003syswalk-namespace");
lf[297]=C_h_intern(&lf[297],23,"interaction-environment");
lf[298]=C_h_intern(&lf[298],25,"scheme-report-environment");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\026no support for version");
lf[300]=C_h_intern(&lf[300],11,"make-vector");
lf[301]=C_h_intern(&lf[301],16,"null-environment");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\026no support for version");
lf[303]=C_h_intern(&lf[303],28,"\003sysresolve-include-filename");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\013 major GCs\012");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\013 minor GCs\012");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\013 mutations\012");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\027 seconds in (major) GC\012");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\021 seconds elapsed\012");
lf[311]=C_h_intern(&lf[311],18,"\003sysrepl-eval-hook");
lf[312]=C_h_intern(&lf[312],27,"\003sysrepl-print-length-limit");
lf[313]=C_h_intern(&lf[313],18,"\003sysrepl-read-hook");
lf[314]=C_h_intern(&lf[314],19,"\003sysrepl-print-hook");
lf[315]=C_h_intern(&lf[315],16,"\003syswrite-char-0");
lf[316]=C_h_intern(&lf[316],9,"\003sysprint");
lf[317]=C_h_intern(&lf[317],27,"\003syswith-print-length-limit");
lf[318]=C_h_intern(&lf[318],11,"repl-prompt");
lf[319]=C_h_intern(&lf[319],20,"\003sysread-prompt-hook");
lf[320]=C_h_intern(&lf[320],16,"\003sysflush-output");
lf[321]=C_h_intern(&lf[321],19,"\003sysstandard-output");
lf[322]=C_h_intern(&lf[322],22,"\003sysclear-trace-buffer");
lf[323]=C_h_intern(&lf[323],16,"print-call-chain");
lf[324]=C_h_intern(&lf[324],5,"reset");
lf[325]=C_h_intern(&lf[325],4,"repl");
lf[326]=C_h_intern(&lf[326],18,"\003sysstandard-error");
lf[327]=C_h_intern(&lf[327],18,"\003sysstandard-input");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\006\012Error");
lf[331]=C_h_intern(&lf[331],17,"\003syserror-handler");
lf[332]=C_h_intern(&lf[332],20,"\003syswarnings-enabled");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\005 (in ");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000FWarning: the following toplevel variables are referenced but unbound:\012");
lf[336]=C_h_intern(&lf[336],15,"\003sysread-char-0");
lf[337]=C_h_intern(&lf[337],15,"\003syspeek-char-0");
lf[338]=C_h_intern(&lf[338],21,"\003sysenable-qualifiers");
lf[339]=C_h_intern(&lf[339],17,"\003sysreset-handler");
lf[340]=C_h_intern(&lf[340],28,"\003syssharp-comma-reader-ctors");
lf[341]=C_h_intern(&lf[341],18,"define-reader-ctor");
lf[342]=C_h_intern(&lf[342],18,"\003sysuser-read-hook");
lf[343]=C_h_intern(&lf[343],9,"read-char");
lf[344]=C_h_intern(&lf[344],14,"\003sysread-error");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000!invalid sharp-comma external form");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000!undefined sharp-comma constructor");
lf[349]=C_h_intern(&lf[349],19,"print-error-message");
lf[350]=C_h_intern(&lf[350],22,"with-exception-handler");
lf[352]=C_h_intern(&lf[352],6,"\003sysgc");
lf[354]=C_h_intern(&lf[354],17,"\003systhread-yield!");
lf[357]=C_h_intern(&lf[357],17,"open-input-string");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000(Error: not enough room for result string");
lf[367]=C_decode_literal(C_heaptop,"\376B\000\000\010No error");
lf[368]=C_h_intern(&lf[368],15,"\003sysmake-string");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000\004#;> ");
lf[370]=C_h_intern(&lf[370],14,"make-parameter");
lf[371]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007\000srfi-8\376\003\000\000\002\376\001\000\000\007\000srfi-6\376\003\000\000\002\376\001\000\000\007\000srfi-2\376\003\000\000\002\376\001\000\000\007\000srfi-0\376\003\000\000\002\376\001\000\000\010\000s"
"rfi-10\376\003\000\000\002\376\001\000\000\007\000srfi-9\376\003\000\000\002\376\001\000\000\010\000srfi-55\376\003\000\000\002\376\001\000\000\010\000srfi-61\376\377\016");
lf[372]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\014dynamic-wind\376\003\000\000\002\376\001\000\000\006values\376\003\000\000\002\376\001\000\000\020call-with-values\376\003\000\000\002\376\001\000\000\004eval\376\003"
"\000\000\002\376\001\000\000\031scheme-report-environment\376\003\000\000\002\376\001\000\000\020null-environment\376\003\000\000\002\376\001\000\000\027interaction"
"-environment\376\377\016");
lf[373]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003not\376\003\000\000\002\376\001\000\000\010boolean\077\376\003\000\000\002\376\001\000\000\003eq\077\376\003\000\000\002\376\001\000\000\004eqv\077\376\003\000\000\002\376\001\000\000\006equal\077\376\003\000\000\002\376"
"\001\000\000\005pair\077\376\003\000\000\002\376\001\000\000\004cons\376\003\000\000\002\376\001\000\000\003car\376\003\000\000\002\376\001\000\000\003cdr\376\003\000\000\002\376\001\000\000\004caar\376\003\000\000\002\376\001\000\000\004cadr\376\003\000"
"\000\002\376\001\000\000\004cdar\376\003\000\000\002\376\001\000\000\004cddr\376\003\000\000\002\376\001\000\000\005caaar\376\003\000\000\002\376\001\000\000\005caadr\376\003\000\000\002\376\001\000\000\005cadar\376\003\000\000\002\376\001\000\000\005"
"caddr\376\003\000\000\002\376\001\000\000\005cdaar\376\003\000\000\002\376\001\000\000\005cdadr\376\003\000\000\002\376\001\000\000\005cddar\376\003\000\000\002\376\001\000\000\005cdddr\376\003\000\000\002\376\001\000\000\006caaaa"
"r\376\003\000\000\002\376\001\000\000\006caaadr\376\003\000\000\002\376\001\000\000\006caadar\376\003\000\000\002\376\001\000\000\006caaddr\376\003\000\000\002\376\001\000\000\006cadaar\376\003\000\000\002\376\001\000\000\006cadad"
"r\376\003\000\000\002\376\001\000\000\006cadddr\376\003\000\000\002\376\001\000\000\006cdaaar\376\003\000\000\002\376\001\000\000\006cdaadr\376\003\000\000\002\376\001\000\000\006cdadar\376\003\000\000\002\376\001\000\000\006cdadd"
"r\376\003\000\000\002\376\001\000\000\006cddaar\376\003\000\000\002\376\001\000\000\006cddadr\376\003\000\000\002\376\001\000\000\006cdddar\376\003\000\000\002\376\001\000\000\006cddddr\376\003\000\000\002\376\001\000\000\010set-c"
"ar!\376\003\000\000\002\376\001\000\000\010set-cdr!\376\003\000\000\002\376\001\000\000\005null\077\376\003\000\000\002\376\001\000\000\005list\077\376\003\000\000\002\376\001\000\000\004list\376\003\000\000\002\376\001\000\000\006lengt"
"h\376\003\000\000\002\376\001\000\000\011list-tail\376\003\000\000\002\376\001\000\000\010list-ref\376\003\000\000\002\376\001\000\000\006append\376\003\000\000\002\376\001\000\000\007reverse\376\003\000\000\002\376\001\000\000"
"\004memq\376\003\000\000\002\376\001\000\000\004memv\376\003\000\000\002\376\001\000\000\006member\376\003\000\000\002\376\001\000\000\004assq\376\003\000\000\002\376\001\000\000\004assv\376\003\000\000\002\376\001\000\000\005assoc\376\003"
"\000\000\002\376\001\000\000\007symbol\077\376\003\000\000\002\376\001\000\000\016symbol->string\376\003\000\000\002\376\001\000\000\016string->symbol\376\003\000\000\002\376\001\000\000\007number\077"
"\376\003\000\000\002\376\001\000\000\010integer\077\376\003\000\000\002\376\001\000\000\006exact\077\376\003\000\000\002\376\001\000\000\005real\077\376\003\000\000\002\376\001\000\000\010complex\077\376\003\000\000\002\376\001\000\000\010ine"
"xact\077\376\003\000\000\002\376\001\000\000\011rational\077\376\003\000\000\002\376\001\000\000\005zero\077\376\003\000\000\002\376\001\000\000\004odd\077\376\003\000\000\002\376\001\000\000\005even\077\376\003\000\000\002\376\001\000\000\011po"
"sitive\077\376\003\000\000\002\376\001\000\000\011negative\077\376\003\000\000\002\376\001\000\000\003max\376\003\000\000\002\376\001\000\000\003min\376\003\000\000\002\376\001\000\000\001+\376\003\000\000\002\376\001\000\000\001-\376\003\000\000\002\376"
"\001\000\000\001*\376\003\000\000\002\376\001\000\000\001/\376\003\000\000\002\376\001\000\000\001=\376\003\000\000\002\376\001\000\000\001>\376\003\000\000\002\376\001\000\000\001<\376\003\000\000\002\376\001\000\000\002>=\376\003\000\000\002\376\001\000\000\002<=\376\003\000\000\002\376\001"
"\000\000\010quotient\376\003\000\000\002\376\001\000\000\011remainder\376\003\000\000\002\376\001\000\000\006modulo\376\003\000\000\002\376\001\000\000\003gcd\376\003\000\000\002\376\001\000\000\003lcm\376\003\000\000\002\376\001\000"
"\000\003abs\376\003\000\000\002\376\001\000\000\005floor\376\003\000\000\002\376\001\000\000\007ceiling\376\003\000\000\002\376\001\000\000\010truncate\376\003\000\000\002\376\001\000\000\005round\376\003\000\000\002\376\001\000\000\016"
"exact->inexact\376\003\000\000\002\376\001\000\000\016inexact->exact\376\003\000\000\002\376\001\000\000\003exp\376\003\000\000\002\376\001\000\000\003log\376\003\000\000\002\376\001\000\000\004expt\376\003"
"\000\000\002\376\001\000\000\004sqrt\376\003\000\000\002\376\001\000\000\003sin\376\003\000\000\002\376\001\000\000\003cos\376\003\000\000\002\376\001\000\000\003tan\376\003\000\000\002\376\001\000\000\004asin\376\003\000\000\002\376\001\000\000\004acos\376"
"\003\000\000\002\376\001\000\000\004atan\376\003\000\000\002\376\001\000\000\016number->string\376\003\000\000\002\376\001\000\000\016string->number\376\003\000\000\002\376\001\000\000\005char\077\376\003\000\000"
"\002\376\001\000\000\006char=\077\376\003\000\000\002\376\001\000\000\006char>\077\376\003\000\000\002\376\001\000\000\006char<\077\376\003\000\000\002\376\001\000\000\007char>=\077\376\003\000\000\002\376\001\000\000\007char<=\077\376\003"
"\000\000\002\376\001\000\000\011char-ci=\077\376\003\000\000\002\376\001\000\000\011char-ci<\077\376\003\000\000\002\376\001\000\000\011char-ci>\077\376\003\000\000\002\376\001\000\000\012char-ci>=\077\376\003\000\000\002"
"\376\001\000\000\012char-ci<=\077\376\003\000\000\002\376\001\000\000\020char-alphabetic\077\376\003\000\000\002\376\001\000\000\020char-whitespace\077\376\003\000\000\002\376\001\000\000\015cha"
"r-numeric\077\376\003\000\000\002\376\001\000\000\020char-upper-case\077\376\003\000\000\002\376\001\000\000\020char-lower-case\077\376\003\000\000\002\376\001\000\000\013char-upc"
"ase\376\003\000\000\002\376\001\000\000\015char-downcase\376\003\000\000\002\376\001\000\000\015char->integer\376\003\000\000\002\376\001\000\000\015integer->char\376\003\000\000\002\376\001\000"
"\000\007string\077\376\003\000\000\002\376\001\000\000\010string=\077\376\003\000\000\002\376\001\000\000\010string>\077\376\003\000\000\002\376\001\000\000\010string<\077\376\003\000\000\002\376\001\000\000\011string>"
"=\077\376\003\000\000\002\376\001\000\000\011string<=\077\376\003\000\000\002\376\001\000\000\013string-ci=\077\376\003\000\000\002\376\001\000\000\013string-ci<\077\376\003\000\000\002\376\001\000\000\013string-"
"ci>\077\376\003\000\000\002\376\001\000\000\014string-ci>=\077\376\003\000\000\002\376\001\000\000\014string-ci<=\077\376\003\000\000\002\376\001\000\000\013make-string\376\003\000\000\002\376\001\000\000\015s"
"tring-length\376\003\000\000\002\376\001\000\000\012string-ref\376\003\000\000\002\376\001\000\000\013string-set!\376\003\000\000\002\376\001\000\000\015string-append\376\003\000\000"
"\002\376\001\000\000\013string-copy\376\003\000\000\002\376\001\000\000\014string->list\376\003\000\000\002\376\001\000\000\014list->string\376\003\000\000\002\376\001\000\000\011substring"
"\376\003\000\000\002\376\001\000\000\014string-fill!\376\003\000\000\002\376\001\000\000\007vector\077\376\003\000\000\002\376\001\000\000\013make-vector\376\003\000\000\002\376\001\000\000\012vector-ref"
"\376\003\000\000\002\376\001\000\000\013vector-set!\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\001\000\000\006vector\376\003\000\000\002\376\001\000\000\015vector-length\376\003\000\000"
"\002\376\001\000\000\014vector->list\376\003\000\000\002\376\001\000\000\014list->vector\376\003\000\000\002\376\001\000\000\014vector-fill!\376\003\000\000\002\376\001\000\000\012procedur"
"e\077\376\003\000\000\002\376\001\000\000\003map\376\003\000\000\002\376\001\000\000\010for-each\376\003\000\000\002\376\001\000\000\005apply\376\003\000\000\002\376\001\000\000\005force\376\003\000\000\002\376\001\000\000\036call-wi"
"th-current-continuation\376\003\000\000\002\376\001\000\000\013input-port\077\376\003\000\000\002\376\001\000\000\014output-port\077\376\003\000\000\002\376\001\000\000\022curr"
"ent-input-port\376\003\000\000\002\376\001\000\000\023current-output-port\376\003\000\000\002\376\001\000\000\024call-with-input-file\376\003\000\000\002\376\001"
"\000\000\025call-with-output-file\376\003\000\000\002\376\001\000\000\017open-input-file\376\003\000\000\002\376\001\000\000\020open-output-file\376\003\000\000\002"
"\376\001\000\000\020close-input-port\376\003\000\000\002\376\001\000\000\021close-output-port\376\003\000\000\002\376\001\000\000\004load\376\003\000\000\002\376\001\000\000\004read\376\003\000\000"
"\002\376\001\000\000\013eof-object\077\376\003\000\000\002\376\001\000\000\011read-char\376\003\000\000\002\376\001\000\000\011peek-char\376\003\000\000\002\376\001\000\000\005write\376\003\000\000\002\376\001\000\000\007"
"display\376\003\000\000\002\376\001\000\000\012write-char\376\003\000\000\002\376\001\000\000\007newline\376\003\000\000\002\376\001\000\000\024with-input-from-file\376\003\000\000\002\376"
"\001\000\000\023with-output-to-file\376\003\000\000\002\376\001\000\000\024\003syscall-with-values\376\003\000\000\002\376\001\000\000\012\003sysvalues\376\003\000\000\002\376\001"
"\000\000\020\003sysdynamic-wind\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\003\000\000\002\376\001\000\000\020\003syslist->vector\376\003\000\000\002\376\001\000\000\010\003syslis"
"t\376\003\000\000\002\376\001\000\000\012\003sysappend\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\020\003sysmake-promise\376\377\016");
lf[374]=C_h_intern(&lf[374],18,"\003sysnumber->string");
lf[375]=C_h_intern(&lf[375],5,"error");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000\031invalid extension version");
lf[377]=C_h_intern(&lf[377],7,"version");
lf[378]=C_h_intern(&lf[378],2,"id");
lf[379]=C_decode_literal(C_heaptop,"\376B\000\0003installed extension does not match required version");
lf[380]=C_h_intern(&lf[380],9,"string>=\077");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000\035invalid version specification");
lf[382]=C_h_intern(&lf[382],12,"list->vector");
lf[383]=C_h_intern(&lf[383],18,"\003sysstring->symbol");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000\005srfi-");
lf[385]=C_h_intern(&lf[385],4,"srfi");
lf[386]=C_decode_literal(C_heaptop,"\376B\000\000\014lib/chicken/");
lf[387]=C_h_intern(&lf[387],22,"default-binary-version");
lf[388]=C_h_intern(&lf[388],24,"get-environment-variable");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000\022CHICKEN_REPOSITORY");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[391]=C_h_intern(&lf[391],5,"linux");
lf[392]=C_h_intern(&lf[392],6,"netbsd");
lf[393]=C_h_intern(&lf[393],7,"openbsd");
lf[394]=C_h_intern(&lf[394],7,"freebsd");
lf[395]=C_h_intern(&lf[395],16,"software-version");
lf[396]=C_h_intern(&lf[396],14,"build-platform");
lf[397]=C_h_intern(&lf[397],7,"windows");
lf[398]=C_decode_literal(C_heaptop,"\376B\000\000\004.dll");
lf[399]=C_h_intern(&lf[399],6,"macosx");
lf[400]=C_decode_literal(C_heaptop,"\376B\000\000\006.dylib");
lf[401]=C_decode_literal(C_heaptop,"\376B\000\000\003.sl");
lf[402]=C_h_intern(&lf[402],4,"hpux");
lf[403]=C_h_intern(&lf[403],4,"hppa");
lf[404]=C_h_intern(&lf[404],12,"machine-type");
lf[405]=C_h_intern(&lf[405],13,"software-type");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\012C_toplevel");
lf[407]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[408]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[410]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
C_register_lf2(lf,411,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2480,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_expand_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2478 */
static void C_ccall f_2480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2480,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! d ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2482,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[3]+1 /* (set! core-library-modules ...) */,lf[4]);
t4=C_set_block_item(lf[5] /* explicit-library-modules */,0,C_SCHEME_END_OF_LIST);
t5=C_mutate(&lf[6] /* (set! constant62 ...) */,lf[7]);
t6=C_mutate(&lf[8] /* (set! constant70 ...) */,lf[9]);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2513,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 137  get-environment-variable */
t8=*((C_word*)lf[388]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,lf[410]);}

/* k2511 in k2478 */
static void C_ccall f_2513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2513,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2516,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=(C_word)C_block_size(t1);
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(C_word)C_subchar(t1,t4);
t6=(C_word)C_u_i_memq(t5,lf[407]);
t7=(C_truep(t6)?lf[408]:lf[409]);
/* eval.scm: 138  ##sys#string-append */
t8=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t2,t1,t7);}
else{
t3=t2;
f_2516(2,t3,C_SCHEME_FALSE);}}

/* k2514 in k2511 in k2478 */
static void C_ccall f_2516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[35],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2516,2,t0,t1);}
t2=C_mutate((C_word*)lf[10]+1 /* (set! chicken-prefix ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2517,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[12]+1 /* (set! chicken-home ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2544,tmp=(C_word)a,a+=2,tmp));
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_mutate((C_word*)lf[15]+1 /* (set! hash-symbol ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2556,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=C_mutate((C_word*)lf[16]+1 /* (set! hash-table-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2571,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[17]+1 /* (set! hash-table-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2626,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[18]+1 /* (set! hash-table-update! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2686,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[19]+1 /* (set! hash-table-for-each ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2706,tmp=(C_word)a,a+=2,tmp));
t13=(C_word)C_slot(lf[20],C_fix(0));
t14=C_mutate((C_word*)lf[21]+1 /* (set! hash-table-location ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2768,a[2]=t13,tmp=(C_word)a,a+=3,tmp));
t15=C_set_block_item(lf[22] /* eval-environment */,0,C_SCHEME_FALSE);
t16=C_set_block_item(lf[23] /* environment-is-mutable */,0,C_SCHEME_FALSE);
t17=C_mutate((C_word*)lf[24]+1 /* (set! eval-decorator ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2828,tmp=(C_word)a,a+=2,tmp));
t18=C_set_block_item(lf[30] /* unbound-in-eval */,0,C_SCHEME_FALSE);
t19=C_set_block_item(lf[31] /* eval-debug-level */,0,C_fix(1));
t20=*((C_word*)lf[27]+1);
t21=*((C_word*)lf[32]+1);
t22=*((C_word*)lf[28]+1);
t23=*((C_word*)lf[26]+1);
t24=*((C_word*)lf[33]+1);
t25=(C_word)C_slot(lf[20],C_fix(0));
t26=*((C_word*)lf[34]+1);
t27=C_mutate((C_word*)lf[35]+1 /* (set! compile-to-closure ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2872,a[2]=t21,a[3]=t25,tmp=(C_word)a,a+=4,tmp));
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5799,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9618,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 824  make-parameter */
t30=*((C_word*)lf[370]+1);
((C_proc3)(void*)(*((C_word*)t30+1)))(3,t30,t28,t29);}

/* a9617 in k2514 in k2511 in k2478 */
static void C_ccall f_9618(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3rv,(void*)f_9618r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_9618r(t0,t1,t2,t3);}}

static void C_ccall f_9618r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(10);
t4=*((C_word*)lf[23]+1);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9622,a[2]=t2,a[3]=t1,a[4]=t7,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t9=(C_word)C_slot(t3,C_fix(0));
if(C_truep(t9)){
t10=(C_word)C_i_check_structure(t9,lf[291]);
t11=(C_word)C_slot(t9,C_fix(1));
t12=C_set_block_item(t7,0,t11);
t13=(C_word)C_slot(t9,C_fix(2));
t14=C_set_block_item(t5,0,t13);
t15=t8;
f_9622(t15,t14);}
else{
t10=t8;
f_9622(t10,C_SCHEME_UNDEFINED);}}
else{
t9=t8;
f_9622(t9,C_SCHEME_UNDEFINED);}}

/* k9620 in a9617 in k2514 in k2511 in k2478 */
static void C_fcall f_9622(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9622,NULL,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[5])[1];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9628,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9630,a[2]=t5,a[3]=t3,a[4]=t9,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9637,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9647,a[2]=t9,a[3]=t7,a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* ##sys#dynamic-wind */
t14=*((C_word*)lf[42]+1);
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,t10,t11,t12,t13);}

/* a9646 in k9620 in a9617 in k2514 in k2511 in k2478 */
static void C_ccall f_9647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9647,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,*((C_word*)lf[23]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[22]+1));
t4=C_mutate((C_word*)lf[23]+1 /* (set! environment-is-mutable ...) */,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate((C_word*)lf[22]+1 /* (set! eval-environment ...) */,((C_word*)((C_word*)t0)[2])[1]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}

/* a9636 in k9620 in a9617 in k2514 in k2511 in k2478 */
static void C_ccall f_9637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9645,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 836  ##sys#current-environment */
t3=*((C_word*)lf[108]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9643 in a9636 in k9620 in a9617 in k2514 in k2511 in k2478 */
static void C_ccall f_9645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 836  ##sys#compile-to-closure */
t2=*((C_word*)lf[35]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1);}

/* a9629 in k9620 in a9617 in k2514 in k2511 in k2478 */
static void C_ccall f_9630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9630,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,*((C_word*)lf[23]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[22]+1));
t4=C_mutate((C_word*)lf[23]+1 /* (set! environment-is-mutable ...) */,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate((C_word*)lf[22]+1 /* (set! eval-environment ...) */,((C_word*)((C_word*)t0)[2])[1]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}

/* k9626 in k9620 in a9617 in k2514 in k2511 in k2478 */
static void C_ccall f_9628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_5799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5799,2,t0,t1);}
t2=C_mutate((C_word*)lf[167]+1 /* (set! eval-handler ...) */,t1);
t3=C_mutate((C_word*)lf[168]+1 /* (set! eval-handler ...) */,*((C_word*)lf[167]+1));
t4=C_mutate((C_word*)lf[169]+1 /* (set! eval ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5802,tmp=(C_word)a,a+=2,tmp));
t5=*((C_word*)lf[32]+1);
t6=C_mutate((C_word*)lf[95]+1 /* (set! decompose-lambda-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5812,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5894,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fudge(C_fix(13));
/* eval.scm: 868  make-parameter */
t9=*((C_word*)lf[370]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_5894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5894,2,t0,t1);}
t2=C_mutate((C_word*)lf[172]+1 /* (set! load-verbose ...) */,t1);
t3=C_mutate((C_word*)lf[173]+1 /* (set! abort-load ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5896,tmp=(C_word)a,a+=2,tmp));
t4=C_set_block_item(lf[174] /* current-source-filename */,0,C_SCHEME_FALSE);
t5=C_mutate((C_word*)lf[175]+1 /* (set! current-load-path ...) */,lf[176]);
t6=C_set_block_item(lf[177] /* dload-disabled */,0,C_SCHEME_FALSE);
t7=C_mutate((C_word*)lf[178]+1 /* (set! set-dynamic-load-mode! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5902,tmp=(C_word)a,a+=2,tmp));
t8=*((C_word*)lf[186]+1);
t9=*((C_word*)lf[27]+1);
t10=*((C_word*)lf[34]+1);
t11=*((C_word*)lf[187]+1);
t12=*((C_word*)lf[188]+1);
t13=*((C_word*)lf[169]+1);
t14=*((C_word*)lf[189]+1);
t15=*((C_word*)lf[190]+1);
t16=*((C_word*)lf[191]+1);
t17=*((C_word*)lf[172]+1);
t18=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5975,a[2]=((C_word*)t0)[2],a[3]=t17,a[4]=t10,a[5]=t12,a[6]=t14,a[7]=t15,a[8]=t9,a[9]=t11,a[10]=t8,a[11]=t13,tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 902  ##sys#make-c-string */
t19=*((C_word*)lf[204]+1);
((C_proc3)(void*)(*((C_word*)t19+1)))(3,t19,t18,lf[406]);}

/* k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_5975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5975,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5977,tmp=(C_word)a,a+=2,tmp);
t3=C_mutate((C_word*)lf[192]+1 /* (set! load ...) */,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6023,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp));
t4=C_mutate((C_word*)lf[197]+1 /* (set! load ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6435,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[216]+1 /* (set! load-relative ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6457,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[217]+1 /* (set! load-noisily ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6493,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6519,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9612,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 995  software-type */
t9=*((C_word*)lf[405]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}

/* k9610 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9612,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[397]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_6519(t3,lf[398]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9608,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 996  software-version */
t4=*((C_word*)lf[395]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9606 in k9610 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9608,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[399]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_6519(t3,lf[400]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9590,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9604,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 997  software-version */
t5=*((C_word*)lf[395]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k9602 in k9606 in k9610 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9604,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[402]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9600,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 998  machine-type */
t4=*((C_word*)lf[404]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[2];
f_9590(t3,C_SCHEME_FALSE);}}

/* k9598 in k9602 in k9606 in k9610 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_9590(t2,(C_word)C_eqp(t1,lf[403]));}

/* k9588 in k9606 in k9610 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_9590(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6519(t2,(C_truep(t1)?lf[401]:lf[6]));}

/* k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_6519(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6519,NULL,2,t0,t1);}
t2=C_mutate((C_word*)lf[222]+1 /* (set! load-library-extension ...) */,t1);
t3=C_mutate((C_word*)lf[211]+1 /* (set! load-dynamic-extension ...) */,lf[6]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6524,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1004 build-platform */
t5=*((C_word*)lf[396]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6524,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[223]);
t3=(C_truep(t2)?lf[224]:lf[225]);
t4=C_mutate((C_word*)lf[226]+1 /* (set! default-dynamic-load-libraries ...) */,t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6531,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9551,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9572,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1010 software-version */
t8=*((C_word*)lf[395]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}

/* k9570 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_truep((C_word)C_eqp(t1,lf[391]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t1,lf[392]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t1,lf[393]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t1,lf[394]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))){
t2=(C_word)C_i_zerop(C_fix((C_word)C_BINARY_VERSION));
t3=((C_word*)t0)[2];
f_9551(t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
f_9551(t2,C_SCHEME_FALSE);}}

/* k9549 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_9551(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9551,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9558,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1015 number->string */
C_number_to_string(3,0,t2,C_fix((C_word)C_BINARY_VERSION));}
else{
t2=((C_word*)t0)[2];
f_6531(2,t2,*((C_word*)lf[222]+1));}}

/* k9556 in k9549 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1012 string-append */
t2=*((C_word*)lf[191]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],*((C_word*)lf[222]+1),lf[390],t1);}

/* k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6531,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6533,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6540,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9542,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,*((C_word*)lf[226]+1));}

/* k9540 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9542,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9544,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1019 make-parameter */
t3=*((C_word*)lf[370]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a9543 in k9540 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9544(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9544,3,t0,t1,t2);}
t3=(C_word)C_i_check_list(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}

/* k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6540,2,t0,t1);}
t2=C_mutate((C_word*)lf[227]+1 /* (set! dynamic-load-libraries ...) */,t1);
t3=*((C_word*)lf[172]+1);
t4=*((C_word*)lf[191]+1);
t5=*((C_word*)lf[227]+1);
t6=*((C_word*)lf[34]+1);
t7=C_mutate((C_word*)lf[228]+1 /* (set! load-library-0 ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6542,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t8=C_mutate((C_word*)lf[235]+1 /* (set! load-library ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6648,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[236]+1 /* (set! load-library ...) */,*((C_word*)lf[235]+1));
t10=*((C_word*)lf[32]+1);
t11=*((C_word*)lf[191]+1);
t12=C_mutate((C_word*)lf[238]+1 /* (set! canonicalize-extension-path ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6734,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6894,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9511,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1109 get-environment-variable */
t15=*((C_word*)lf[388]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t14,lf[389]);}

/* k9509 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9514,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_9514(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9517,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9527,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9531,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_fudge(C_fix(42));
t7=(C_truep(t6)?t6:*((C_word*)lf[387]+1));
/* eval.scm: 1113 ##sys#number->string */
t8=*((C_word*)lf[374]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t5,t7);}}

/* k9529 in k9509 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1111 ##sys#string-append */
t2=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[386],t1);}

/* k9525 in k9509 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1110 ##sys#chicken-prefix */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9515 in k9509 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9517,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_9514(2,t2,t1);}
else{
/* ##sys#peek-c-string */
t2=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_mpointer(&a,(void*)C_INSTALL_EGG_HOME),C_fix(0));}}

/* k9512 in k9509 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1108 make-parameter */
t2=*((C_word*)lf[370]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6894,2,t0,t1);}
t2=C_mutate((C_word*)lf[244]+1 /* (set! repository-path ...) */,t1);
t3=C_mutate((C_word*)lf[245]+1 /* (set! repository-path ...) */,*((C_word*)lf[244]+1));
t4=C_set_block_item(lf[246] /* setup-mode */,0,C_SCHEME_FALSE);
t5=*((C_word*)lf[247]+1);
t6=*((C_word*)lf[191]+1);
t7=C_mutate((C_word*)lf[248]+1 /* (set! find-extension ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6898,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t8=C_set_block_item(lf[253] /* loaded-extensions */,0,C_SCHEME_END_OF_LIST);
t9=*((C_word*)lf[254]+1);
t10=C_mutate((C_word*)lf[255]+1 /* (set! load-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6997,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[258]+1 /* (set! provide ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7074,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[259]+1 /* (set! provide ...) */,*((C_word*)lf[258]+1));
t13=C_mutate((C_word*)lf[260]+1 /* (set! provided? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7110,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[261]+1 /* (set! provided? ...) */,*((C_word*)lf[260]+1));
t15=C_mutate((C_word*)lf[127]+1 /* (set! require ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7124,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[262]+1 /* (set! require ...) */,*((C_word*)lf[127]+1));
t17=*((C_word*)lf[33]+1);
t18=*((C_word*)lf[247]+1);
t19=*((C_word*)lf[191]+1);
t20=*((C_word*)lf[186]+1);
t21=C_mutate((C_word*)lf[263]+1 /* (set! extension-information ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7153,a[2]=t19,a[3]=t18,a[4]=t20,a[5]=t17,tmp=(C_word)a,a+=6,tmp));
t22=C_mutate((C_word*)lf[267]+1 /* (set! extension-information ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7181,tmp=(C_word)a,a+=2,tmp));
t23=*((C_word*)lf[33]+1);
t24=*((C_word*)lf[186]+1);
t25=C_mutate((C_word*)lf[128]+1 /* (set! lookup-runtime-requirements ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7187,tmp=(C_word)a,a+=2,tmp));
t26=*((C_word*)lf[269]+1);
t27=C_mutate((C_word*)lf[131]+1 /* (set! do-the-right-thing ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7236,a[2]=t26,tmp=(C_word)a,a+=3,tmp));
t28=C_set_block_item(lf[284] /* extension-specifiers */,0,C_SCHEME_END_OF_LIST);
t29=C_mutate((C_word*)lf[287]+1 /* (set! set-extension-specifier! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7758,tmp=(C_word)a,a+=2,tmp));
t30=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7797,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t31=*((C_word*)lf[382]+1);
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9457,a[2]=t31,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1326 set-extension-specifier! */
t33=*((C_word*)lf[287]+1);
((C_proc4)(void*)(*((C_word*)t33+1)))(4,t33,t30,lf[385],t32);}

/* a9456 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9457(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9457,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9465,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9471,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_9471(t9,t4,t5);}

/* loop in a9456 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_9471(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9471,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_i_check_exact_2(t3,lf[281]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9491,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9503,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9507,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1336 number->string */
C_number_to_string(3,0,t7,t3);}}

/* k9505 in loop in a9456 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1336 ##sys#string-append */
t2=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[384],t1);}

/* k9501 in loop in a9456 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1336 ##sys#string->symbol */
t2=*((C_word*)lf[383]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9489 in loop in a9456 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9491,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9495,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1337 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_9471(t4,t2,t3);}

/* k9493 in k9489 in loop in a9456 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9495,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k9463 in a9456 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1330 list->vector */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7797,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7800,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9360,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1342 set-extension-specifier! */
t4=*((C_word*)lf[287]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[377],t3);}

/* a9359 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9360(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9360,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9363,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9397,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t6=(C_word)C_i_length(t2);
t7=t5;
f_9397(t7,(C_word)C_eqp(C_fix(3),t6));}
else{
t6=t5;
f_9397(t6,C_SCHEME_FALSE);}}

/* k9395 in a9359 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_9397(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9397,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9400,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[3]);
/* eval.scm: 1351 extension-information */
t4=*((C_word*)lf[267]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
/* eval.scm: 1356 ##sys#syntax-error-hook */
t2=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],lf[381],((C_word*)t0)[3]);}}

/* k9398 in k9395 in a9359 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9400,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_u_i_assq(lf[377],t1):C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9406,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9409,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9423,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_i_car(t2);
/* eval.scm: 1353 ->string */
f_9363(t5,t6);}
else{
t5=t4;
f_9409(2,t5,C_SCHEME_FALSE);}}

/* k9421 in k9398 in k9395 in a9359 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9427,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[3]);
/* eval.scm: 1353 ->string */
f_9363(t2,t3);}

/* k9425 in k9421 in k9398 in k9395 in a9359 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1353 string>=? */
t2=*((C_word*)lf[380]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9407 in k9398 in k9395 in a9359 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_9406(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_u_i_caddr(((C_word*)t0)[3]);
/* eval.scm: 1354 error */
t3=*((C_word*)lf[375]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[4],lf[379],*((C_word*)lf[378]+1),((C_word*)t0)[2],t2);}}

/* k9404 in k9398 in k9395 in a9359 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[378]+1));}

/* ->string in a9359 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_9363(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9363,NULL,2,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}
else{
if(C_truep((C_word)C_i_numberp(t2))){
/* eval.scm: 1348 ##sys#number->string */
t3=*((C_word*)lf[374]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
/* eval.scm: 1349 error */
t3=*((C_word*)lf[375]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[376],t2);}}}}

/* k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7800,2,t0,t1);}
t2=*((C_word*)lf[288]+1);
t3=C_mutate((C_word*)lf[233]+1 /* (set! string->c-identifier ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7802,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7858,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1375 make-vector */
t5=*((C_word*)lf[300]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[29],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7858,2,t0,t1);}
t2=C_mutate(&lf[289] /* (set! r4rs-environment ...) */,t1);
t3=lf[290] /* r5rs-environment */ =C_SCHEME_FALSE;;
t4=(C_word)C_a_i_record(&a,3,lf[291],C_SCHEME_FALSE,C_SCHEME_TRUE);
t5=C_mutate(&lf[292] /* (set! interaction-environment ...) */,t4);
t6=C_mutate((C_word*)lf[293]+1 /* (set! environment? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7865,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[294]+1 /* (set! copy-env-table ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7881,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[295]+1 /* (set! environment-symbols ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7989,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[297]+1 /* (set! interaction-environment ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8108,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[298]+1 /* (set! scheme-report-environment ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8111,tmp=(C_word)a,a+=2,tmp));
t11=*((C_word*)lf[300]+1);
t12=C_mutate((C_word*)lf[301]+1 /* (set! null-environment ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8155,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8193,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8209,a[2]=t13,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9334,a[2]=t13,a[3]=t16,tmp=(C_word)a,a+=4,tmp));
t18=((C_word*)t16)[1];
f_9334(t18,t14,lf[373]);}

/* loop1929 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_9334(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9334,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9344,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9358,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1459 initb */
f_8193(t5,lf[289]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9356 in loop1929 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9342 in loop1929 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9334(t3,((C_word*)t0)[2],t2);}

/* k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8209,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8213,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1480 ##sys#copy-env-table */
t3=*((C_word*)lf[294]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[289],C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8213,2,t0,t1);}
t2=C_mutate(&lf[290] /* (set! r5rs-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8216,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9308,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_9308(t7,t3,lf[372]);}

/* loop1942 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_9308(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9308,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9318,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9332,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1482 initb */
f_8193(t5,lf[290]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9330 in loop1942 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9316 in loop1942 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9308(t3,((C_word*)t0)[2],t2);}

/* k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8216,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8220,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1489 chicken-home */
t3=*((C_word*)lf[12]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8220,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_a_i_list(&a,1,t1):C_SCHEME_END_OF_LIST);
t3=C_mutate((C_word*)lf[251]+1 /* (set! include-pathnames ...) */,t2);
t4=*((C_word*)lf[191]+1);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8226,tmp=(C_word)a,a+=2,tmp);
t6=C_mutate((C_word*)lf[303]+1 /* (set! resolve-include-filename ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8245,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=*((C_word*)lf[34]+1);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8387,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8411,a[2]=t8,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t10=C_mutate((C_word*)lf[194]+1 /* (set! display-times ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8432,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8487,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1558 append */
t12=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,lf[371],*((C_word*)lf[142]+1));}

/* k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8487,2,t0,t1);}
t2=C_mutate((C_word*)lf[142]+1 /* (set! features ...) */,t1);
t3=C_set_block_item(lf[311] /* repl-eval-hook */,0,C_SCHEME_FALSE);
t4=C_set_block_item(lf[312] /* repl-print-length-limit */,0,C_SCHEME_FALSE);
t5=C_set_block_item(lf[313] /* repl-read-hook */,0,C_SCHEME_FALSE);
t6=C_mutate((C_word*)lf[314]+1 /* (set! repl-print-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8492,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8509,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9302,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1572 make-parameter */
t9=*((C_word*)lf[370]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* a9301 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9302,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[369]);}

/* k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8509,2,t0,t1);}
t2=C_mutate((C_word*)lf[318]+1 /* (set! repl-prompt ...) */,t1);
t3=*((C_word*)lf[318]+1);
t4=C_mutate((C_word*)lf[319]+1 /* (set! read-prompt-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8511,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[322]+1 /* (set! clear-trace-buffer ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8527,tmp=(C_word)a,a+=2,tmp));
t6=*((C_word*)lf[169]+1);
t7=*((C_word*)lf[186]+1);
t8=*((C_word*)lf[202]+1);
t9=*((C_word*)lf[323]+1);
t10=*((C_word*)lf[188]+1);
t11=*((C_word*)lf[172]+1);
t12=*((C_word*)lf[324]+1);
t13=C_mutate((C_word*)lf[325]+1 /* (set! repl ...) */,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8530,a[2]=t8,a[3]=t7,a[4]=t6,a[5]=t11,a[6]=t9,a[7]=t10,tmp=(C_word)a,a+=8,tmp));
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8920,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1689 make-vector */
t15=*((C_word*)lf[300]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[35],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8920,2,t0,t1);}
t2=C_mutate((C_word*)lf[340]+1 /* (set! sharp-comma-reader-ctors ...) */,t1);
t3=C_mutate((C_word*)lf[341]+1 /* (set! define-reader-ctor ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8922,tmp=(C_word)a,a+=2,tmp));
t4=*((C_word*)lf[342]+1);
t5=*((C_word*)lf[343]+1);
t6=*((C_word*)lf[186]+1);
t7=C_mutate((C_word*)lf[342]+1 /* (set! user-read-hook ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8931,a[2]=t4,a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=lf[347] /* last-error */ =C_SCHEME_FALSE;;
t9=C_mutate(&lf[348] /* (set! run-safe ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9006,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate(&lf[351] /* (set! store-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9065,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate(&lf[353] /* (set! CHICKEN_yield ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9074,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate(&lf[355] /* (set! CHICKEN_eval ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9086,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate(&lf[356] /* (set! CHICKEN_eval_string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9102,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate(&lf[358] /* (set! store-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9128,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate(&lf[360] /* (set! CHICKEN_eval_to_string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9141,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate(&lf[361] /* (set! CHICKEN_eval_string_to_string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9167,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate(&lf[362] /* (set! CHICKEN_apply ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9204,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate(&lf[363] /* (set! CHICKEN_apply_to_string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9220,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[364] /* (set! CHICKEN_read ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9246,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate(&lf[365] /* (set! CHICKEN_load ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9268,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate(&lf[366] /* (set! CHICKEN_get_error_message ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9283,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[25]+1 /* (set! make-lambda-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9293,tmp=(C_word)a,a+=2,tmp));
t23=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,C_SCHEME_UNDEFINED);}

/* ##sys#make-lambda-info in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9293(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9293,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9300,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1820 ##sys#make-string */
t5=*((C_word*)lf[368]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k9298 in ##sys#make-lambda-info in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_copy_memory(t1,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(C_word)C_string_to_lambdainfo(t1);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}

/* CHICKEN_get_error_message in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9283(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9283,4,t0,t1,t2,t3);}
t4=lf[347];
t5=(C_truep(t4)?t4:lf[367]);
/* eval.scm: 1813 store-string */
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_9128(t5,t3,t2));}

/* CHICKEN_load in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9268(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9268,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9272,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,C_fix(0));}

/* k9270 in CHICKEN_load in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9272,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9277,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1810 run-safe */
f_9006(((C_word*)t0)[2],t2);}

/* a9276 in k9270 in CHICKEN_load in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9277,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9281,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1810 load */
t3=*((C_word*)lf[197]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9279 in a9276 in k9270 in CHICKEN_load in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* CHICKEN_read in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9246(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9246,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9250,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_fix(0));}

/* k9248 in CHICKEN_read in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9250,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9255,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1804 run-safe */
f_9006(((C_word*)t0)[2],t3);}

/* a9254 in k9248 in CHICKEN_read in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9255,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9259,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1806 open-input-string */
t3=*((C_word*)lf[357]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9257 in a9254 in k9248 in CHICKEN_read in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9259,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9266,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1807 read */
t3=*((C_word*)lf[186]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k9264 in k9257 in a9254 in k9248 in CHICKEN_read in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1807 store-result */
f_9065(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_apply_to_string in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9220(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_9220,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9226,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1797 run-safe */
f_9006(t1,t6);}

/* a9225 in CHICKEN_apply_to_string in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9226,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9230,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1799 open-output-string */
t3=*((C_word*)lf[28]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9228 in a9225 in CHICKEN_apply_to_string in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9230,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9233,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9244,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9242 in k9228 in a9225 in CHICKEN_apply_to_string in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1800 write */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9231 in k9228 in a9225 in CHICKEN_apply_to_string in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9233,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9240,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1801 get-output-string */
t3=*((C_word*)lf[26]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9238 in k9231 in k9228 in a9225 in CHICKEN_apply_to_string in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1801 store-string */
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_9128(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* CHICKEN_apply in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9204(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9204,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9210,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1792 run-safe */
f_9006(t1,t5);}

/* a9209 in CHICKEN_apply in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9210,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9218,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9216 in a9209 in CHICKEN_apply in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1792 store-result */
f_9065(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_eval_string_to_string in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9167(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9167,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9171,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,C_fix(0));}

/* k9169 in CHICKEN_eval_string_to_string in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9171,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9176,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1783 run-safe */
f_9006(((C_word*)t0)[2],t4);}

/* a9175 in k9169 in CHICKEN_eval_string_to_string in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9176,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9180,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1785 open-output-string */
t3=*((C_word*)lf[28]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9178 in a9175 in k9169 in CHICKEN_eval_string_to_string in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9183,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9194,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9198,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9202,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1786 open-input-string */
t6=*((C_word*)lf[357]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k9200 in k9178 in a9175 in k9169 in CHICKEN_eval_string_to_string in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1786 read */
t2=*((C_word*)lf[186]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9196 in k9178 in a9175 in k9169 in CHICKEN_eval_string_to_string in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1786 eval */
t2=*((C_word*)lf[169]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9192 in k9178 in a9175 in k9169 in CHICKEN_eval_string_to_string in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1786 write */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9181 in k9178 in a9175 in k9169 in CHICKEN_eval_string_to_string in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9183,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9190,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1787 get-output-string */
t3=*((C_word*)lf[26]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9188 in k9181 in k9178 in a9175 in k9169 in CHICKEN_eval_string_to_string in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1787 store-string */
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_9128(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* CHICKEN_eval_to_string in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9141(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9141,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9147,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1774 run-safe */
f_9006(t1,t5);}

/* a9146 in CHICKEN_eval_to_string in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9147,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9151,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1776 open-output-string */
t3=*((C_word*)lf[28]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9149 in a9146 in CHICKEN_eval_to_string in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9151,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9154,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9165,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1777 eval */
t4=*((C_word*)lf[169]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k9163 in k9149 in a9146 in CHICKEN_eval_to_string in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1777 write */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9152 in k9149 in a9146 in CHICKEN_eval_to_string in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9154,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9161,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1778 get-output-string */
t3=*((C_word*)lf[26]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9159 in k9152 in k9149 in a9146 in CHICKEN_eval_to_string in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1778 store-string */
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_9128(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* store-string in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static C_word C_fcall f_9128(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_block_size(t1);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t2))){
t5=C_mutate(&lf[347] /* (set! last-error ...) */,lf[359]);
return(C_SCHEME_FALSE);}
else{
return((C_word)C_copy_result_string(t1,t3,t4));}}

/* CHICKEN_eval_string in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9102(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9102,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9106,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_fix(0));}

/* k9104 in CHICKEN_eval_string in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9106,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9111,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1755 run-safe */
f_9006(((C_word*)t0)[2],t3);}

/* a9110 in k9104 in CHICKEN_eval_string in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9111,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9115,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1757 open-input-string */
t3=*((C_word*)lf[357]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9113 in a9110 in k9104 in CHICKEN_eval_string in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9115,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9122,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9126,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1758 read */
t4=*((C_word*)lf[186]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k9124 in k9113 in a9110 in k9104 in CHICKEN_eval_string in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1758 eval */
t2=*((C_word*)lf[169]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9120 in k9113 in a9110 in k9104 in CHICKEN_eval_string in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1758 store-result */
f_9065(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_eval in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9086(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9086,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9092,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1750 run-safe */
f_9006(t1,t4);}

/* a9091 in CHICKEN_eval in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9092,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9100,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1752 eval */
t3=*((C_word*)lf[169]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9098 in a9091 in CHICKEN_eval in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1752 store-result */
f_9065(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_yield in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9074,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9080,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1747 run-safe */
f_9006(t1,t2);}

/* a9079 in CHICKEN_yield in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9080,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9084,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1747 ##sys#thread-yield! */
t3=*((C_word*)lf[354]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9082 in a9079 in CHICKEN_yield in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* store-result in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_9065(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9065,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9069,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1741 ##sys#gc */
t5=*((C_word*)lf[352]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,C_SCHEME_FALSE);}

/* k9067 in store-result in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_store_result(((C_word*)t0)[3],((C_word*)t0)[4]):C_SCHEME_UNDEFINED);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* run-safe in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_9006(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9006,NULL,2,t1,t2);}
t3=lf[347] /* last-error */ =C_SCHEME_FALSE;;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9014,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9016,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* call-with-current-continuation */
t6=*((C_word*)lf[202]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* a9015 in run-safe in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9016(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9016,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9022,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9041,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[350]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a9040 in a9015 in run-safe in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9047,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9053,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}

/* a9052 in a9040 in a9015 in run-safe in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9053(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_9053r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_9053r(t0,t1,t2);}}

static void C_ccall f_9053r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9059,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k22372240 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a9058 in a9052 in a9040 in a9015 in run-safe in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9059,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a9046 in a9040 in a9015 in run-safe in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9047,2,t0,t1);}
/* eval.scm: 1734 thunk */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* a9021 in a9015 in run-safe in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9022(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9022,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9028,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k22372240 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a9027 in a9021 in a9015 in run-safe in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9032,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1730 open-output-string */
t3=*((C_word*)lf[28]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9030 in a9027 in a9021 in a9015 in run-safe in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9032,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9035,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1731 print-error-message */
t3=*((C_word*)lf[349]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k9033 in k9030 in a9027 in a9021 in a9015 in run-safe in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9035,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9039,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1732 get-output-string */
t3=*((C_word*)lf[26]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9037 in k9033 in k9030 in a9027 in a9021 in a9015 in run-safe in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[347] /* (set! last-error ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* k9012 in run-safe in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_9014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8931(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8931,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_make_character(44));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8941,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1701 read-char */
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
/* eval.scm: 1713 old */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}}

/* k8939 in ##sys#user-read-hook in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8941,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8944,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1702 read */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k8942 in k8939 in ##sys#user-read-hook in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8944,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8945,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_nullp(t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8958,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_8958(t5,t3);}
else{
t5=(C_word)C_i_listp(t1);
t6=t4;
f_8958(t6,(C_word)C_i_not(t5));}}

/* k8956 in k8942 in k8939 in ##sys#user-read-hook in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_8958(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8958,NULL,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 1705 err */
t2=((C_word*)t0)[5];
f_8945(t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8976,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1709 ##sys#hash-table-ref */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[340]+1),t2);}
else{
/* eval.scm: 1708 err */
t3=((C_word*)t0)[5];
f_8945(t3,((C_word*)t0)[4]);}}}

/* k8974 in k8956 in k8942 in k8939 in ##sys#user-read-hook in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
C_apply(4,0,((C_word*)t0)[4],t1,t2);}
else{
/* eval.scm: 1712 ##sys#read-error */
t2=*((C_word*)lf[344]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[346],((C_word*)t0)[2]);}}

/* err in k8942 in k8939 in ##sys#user-read-hook in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_8945(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8945,NULL,2,t0,t1);}
/* eval.scm: 1703 ##sys#read-error */
t2=*((C_word*)lf[344]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],lf[345],((C_word*)t0)[2]);}

/* define-reader-ctor in k8918 in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8922(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8922,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_symbol_2(t2,lf[341]);
/* eval.scm: 1693 ##sys#hash-table-set! */
t5=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,*((C_word*)lf[340]+1),t2,t3);}

/* repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8533,tmp=(C_word)a,a+=2,tmp);
t3=*((C_word*)lf[327]+1);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=*((C_word*)lf[321]+1);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=*((C_word*)lf[326]+1);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8606,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t8,a[11]=t6,a[12]=t4,tmp=(C_word)a,a+=13,tmp);
/* eval.scm: 1602 ##sys#error-handler */
t10=*((C_word*)lf[331]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}

/* k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8606,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8609,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* eval.scm: 1603 ##sys#reset-handler */
t3=*((C_word*)lf[339]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8609,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=*((C_word*)lf[30]+1);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8611,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8617,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8626,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t6,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8691,a[2]=((C_word*)t0)[4],a[3]=t6,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8905,a[2]=t3,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1617 ##sys#dynamic-wind */
t10=*((C_word*)lf[42]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,((C_word*)t0)[2],t7,t8,t9);}

/* a8904 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8905,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8909,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1681 load-verbose */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k8907 in a8904 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8909,2,t0,t1);}
t2=C_mutate((C_word*)lf[30]+1 /* (set! unbound-in-eval ...) */,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8913,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1683 ##sys#error-handler */
t4=*((C_word*)lf[331]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k8911 in k8907 in a8904 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1684 ##sys#reset-handler */
t2=*((C_word*)lf[339]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8690 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8691,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8697,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_8697(t5,t1);}

/* loop in a8690 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_8697(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8697,NULL,2,t0,t1);}
t2=f_8611(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8704,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8888,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1640 call-with-current-continuation */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a8887 in loop in a8690 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8888(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8888,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8894,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1642 ##sys#reset-handler */
t4=*((C_word*)lf[339]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a8893 in a8887 in loop in a8690 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8894,2,t0,t1);}
t2=C_set_block_item(lf[193] /* read-error-with-line-number */,0,C_SCHEME_FALSE);
t3=C_set_block_item(lf[338] /* enable-qualifiers */,0,C_SCHEME_TRUE);
t4=f_8617(((C_word*)t0)[3]);
/* eval.scm: 1647 c */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,C_SCHEME_FALSE);}

/* k8702 in loop in a8690 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8704,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8707,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1648 ##sys#read-prompt-hook */
t3=*((C_word*)lf[319]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8705 in k8702 in loop in a8690 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8707,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8710,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[313]+1);
t4=(C_truep(t3)?t3:((C_word*)t0)[2]);
t5=t4;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* k8708 in k8705 in k8702 in loop in a8690 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8710,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8719,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8883,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1651 ##sys#peek-char-0 */
t4=*((C_word*)lf[337]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[327]+1));}}

/* k8881 in k8708 in k8705 in k8702 in loop in a8690 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_make_character(10),t1);
if(C_truep(t2)){
/* eval.scm: 1652 ##sys#read-char-0 */
t3=*((C_word*)lf[336]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],*((C_word*)lf[327]+1));}
else{
t3=((C_word*)t0)[2];
f_8719(2,t3,C_SCHEME_UNDEFINED);}}

/* k8717 in k8708 in k8705 in k8702 in loop in a8690 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8719,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8722,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1653 ##sys#clear-trace-buffer */
t3=*((C_word*)lf[322]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8720 in k8717 in k8708 in k8705 in k8702 in loop in a8690 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8722,2,t0,t1);}
t2=C_set_block_item(lf[30] /* unbound-in-eval */,0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8728,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8737,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a8736 in k8720 in k8717 in k8708 in k8705 in k8702 in loop in a8690 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8737(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr2r,(void*)f_8737r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8737r(t0,t1,t2);}}

static void C_ccall f_8737r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8741,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(*((C_word*)lf[332]+1))?(C_word)C_i_pairp(*((C_word*)lf[30]+1)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8755,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_8755(t8,t3,*((C_word*)lf[30]+1),C_SCHEME_END_OF_LIST);}
else{
t5=t3;
f_8741(2,t5,C_SCHEME_UNDEFINED);}}

/* loop in a8736 in k8720 in k8717 in k8708 in k8705 in k8702 in loop in a8690 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_8755(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8755,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8759,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_pairp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8771,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1660 ##sys#print */
t6=*((C_word*)lf[316]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[335],C_SCHEME_FALSE,*((C_word*)lf[326]+1));}
else{
t5=t4;
f_8759(2,t5,C_SCHEME_UNDEFINED);}}
else{
t5=(C_word)C_u_i_caar(t2);
t6=(C_word)C_u_i_memq(t5,t3);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8837,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t8=t7;
f_8837(2,t8,t6);}
else{
t8=(C_word)C_u_i_caar(t2);
/* eval.scm: 1675 ##sys#symbol-has-toplevel-binding? */
t9=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}}}

/* k8835 in loop in a8736 in k8720 in k8717 in k8708 in k8705 in k8702 in loop in a8690 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8837,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* eval.scm: 1676 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8755(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]);
/* eval.scm: 1677 loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_8755(t5,((C_word*)t0)[3],t2,t4);}}

/* k8769 in loop in a8736 in k8720 in k8717 in k8708 in k8705 in k8702 in loop in a8690 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8771,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8774,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8779,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_8779(t6,t2,((C_word*)t0)[2]);}

/* loop2169 in k8769 in loop in a8736 in k8720 in k8717 in k8708 in k8705 in k8702 in loop in a8690 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_8779(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8779,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8792,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1665 ##sys#print */
t5=*((C_word*)lf[316]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,lf[334],C_SCHEME_FALSE,*((C_word*)lf[326]+1));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k8790 in loop2169 in k8769 in loop in a8736 in k8720 in k8717 in k8708 in k8705 in k8702 in loop in a8690 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8792,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8795,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[2]);
/* eval.scm: 1666 ##sys#print */
t4=*((C_word*)lf[316]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_TRUE,*((C_word*)lf[326]+1));}

/* k8793 in k8790 in loop2169 in k8769 in loop in a8736 in k8720 in k8717 in k8708 in k8705 in k8702 in loop in a8690 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8798,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_slot(((C_word*)t0)[2],C_fix(1)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8814,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1668 ##sys#print */
t4=*((C_word*)lf[316]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[333],C_SCHEME_FALSE,*((C_word*)lf[326]+1));}
else{
t3=t2;
f_8798(2,t3,C_SCHEME_UNDEFINED);}}

/* k8812 in k8793 in k8790 in loop2169 in k8769 in loop in a8736 in k8720 in k8717 in k8708 in k8705 in k8702 in loop in a8690 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8814,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8817,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* eval.scm: 1669 ##sys#print */
t4=*((C_word*)lf[316]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_TRUE,*((C_word*)lf[326]+1));}

/* k8815 in k8812 in k8793 in k8790 in loop2169 in k8769 in loop in a8736 in k8720 in k8717 in k8708 in k8705 in k8702 in loop in a8690 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1670 ##sys#write-char-0 */
t2=*((C_word*)lf[315]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(41),*((C_word*)lf[326]+1));}

/* k8796 in k8793 in k8790 in loop2169 in k8769 in loop in a8736 in k8720 in k8717 in k8708 in k8705 in k8702 in loop in a8690 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8798,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8801,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1671 ##sys#write-char-0 */
t3=*((C_word*)lf[315]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),*((C_word*)lf[326]+1));}

/* k8799 in k8796 in k8793 in k8790 in loop2169 in k8769 in loop in a8736 in k8720 in k8717 in k8708 in k8705 in k8702 in loop in a8690 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8779(t3,((C_word*)t0)[2],t2);}

/* k8772 in k8769 in loop in a8736 in k8720 in k8717 in k8708 in k8705 in k8702 in loop in a8690 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1673 ##sys#flush-output */
t2=*((C_word*)lf[320]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],*((C_word*)lf[326]+1));}

/* k8757 in loop in a8736 in k8720 in k8717 in k8708 in k8705 in k8702 in loop in a8690 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(9));}

/* k8739 in a8736 in k8720 in k8717 in k8708 in k8705 in k8702 in loop in a8690 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8741,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8744,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_i_nullp(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8571,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_8571(t6,t4);}
else{
t6=(C_word)C_u_i_car(t3);
t7=t5;
f_8571(t7,(C_word)C_eqp(C_SCHEME_UNDEFINED,t6));}}

/* k8569 in k8739 in a8736 in k8720 in k8717 in k8708 in k8705 in k8702 in loop in a8690 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_8571(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8571,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_8744(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8576,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_8576(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* loop2086 in k8569 in k8739 in a8736 in k8720 in k8717 in k8708 in k8705 in k8702 in loop in a8690 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_8576(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8576,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8589,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#repl-print-hook */
t5=*((C_word*)lf[314]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,*((C_word*)lf[321]+1));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k8587 in loop2086 in k8569 in k8739 in a8736 in k8720 in k8717 in k8708 in k8705 in k8702 in loop in a8690 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8576(t3,((C_word*)t0)[2],t2);}

/* k8742 in k8739 in a8736 in k8720 in k8717 in k8708 in k8705 in k8702 in loop in a8690 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1679 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_8697(t2,((C_word*)t0)[2]);}

/* a8727 in k8720 in k8717 in k8708 in k8705 in k8702 in loop in a8690 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8728,2,t0,t1);}
t2=*((C_word*)lf[311]+1);
t3=(C_truep(t2)?t2:((C_word*)t0)[3]);
t4=t3;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,((C_word*)t0)[2]);}

/* a8625 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8626,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8631,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 1619 load-verbose */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8629 in a8625 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8631,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8634,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1620 load-verbose */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_SCHEME_TRUE);}

/* k8632 in k8629 in a8625 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8639,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1621 ##sys#error-handler */
t3=*((C_word*)lf[331]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* a8638 in k8632 in k8629 in a8625 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8639(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_8639r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8639r(t0,t1,t2,t3);}}

static void C_ccall f_8639r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=f_8617(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8646,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 1624 ##sys#print */
t6=*((C_word*)lf[316]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[330],C_SCHEME_FALSE,*((C_word*)lf[326]+1));}

/* k8644 in a8638 in k8632 in k8629 in a8625 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8649,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8686,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1626 ##sys#print */
t4=*((C_word*)lf[316]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[329],C_SCHEME_FALSE,*((C_word*)lf[326]+1));}
else{
t3=t2;
f_8649(2,t3,C_SCHEME_UNDEFINED);}}

/* k8684 in k8644 in a8638 in k8632 in k8629 in a8625 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1627 ##sys#print */
t2=*((C_word*)lf[316]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,*((C_word*)lf[326]+1));}

/* k8647 in k8644 in a8638 in k8632 in k8629 in a8625 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8652,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8661,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t5=t3;
f_8661(t5,(C_word)C_i_nullp(t4));}
else{
t4=t3;
f_8661(t4,C_SCHEME_FALSE);}}

/* k8659 in k8647 in k8644 in a8638 in k8632 in k8629 in a8625 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_8661(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8661,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8664,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1630 ##sys#print */
t3=*((C_word*)lf[316]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[328],C_SCHEME_FALSE,*((C_word*)lf[326]+1));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8670,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1633 ##sys#write-char-0 */
t3=*((C_word*)lf[315]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),*((C_word*)lf[326]+1));}}

/* k8668 in k8659 in k8647 in k8644 in a8638 in k8632 in k8629 in a8625 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1634 write-err */
f_8533(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8662 in k8659 in k8647 in k8644 in a8638 in k8632 in k8629 in a8625 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1631 write-err */
f_8533(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8650 in k8647 in k8644 in a8638 in k8632 in k8629 in a8625 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8652,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8655,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1635 print-call-chain */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[326]+1));}

/* k8653 in k8650 in k8647 in k8644 in a8638 in k8632 in k8629 in a8625 in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1636 flush-output */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],*((C_word*)lf[326]+1));}

/* resetports in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static C_word C_fcall f_8617(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
t1=C_mutate((C_word*)lf[327]+1 /* (set! standard-input ...) */,((C_word*)((C_word*)t0)[4])[1]);
t2=C_mutate((C_word*)lf[321]+1 /* (set! standard-output ...) */,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate((C_word*)lf[326]+1 /* (set! standard-error ...) */,((C_word*)((C_word*)t0)[2])[1]);
return(t3);}

/* saveports in k8607 in k8604 in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static C_word C_fcall f_8611(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
t1=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[327]+1));
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[321]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,*((C_word*)lf[326]+1));
return(t3);}

/* write-err in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_8533(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8533,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8539,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_8539(t6,t1,t2);}

/* loop2062 in write-err in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_8539(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8539,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8552,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#repl-print-hook */
t5=*((C_word*)lf[314]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,*((C_word*)lf[326]+1));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k8550 in loop2062 in write-err in repl in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8539(t3,((C_word*)t0)[2],t2);}

/* ##sys#clear-trace-buffer in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8527,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub2048(C_SCHEME_UNDEFINED));}

/* ##sys#read-prompt-hook in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8515,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8522,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8525,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1577 repl-prompt */
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k8523 in ##sys#read-prompt-hook in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k8520 in ##sys#read-prompt-hook in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1577 ##sys#print */
t2=*((C_word*)lf[316]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,*((C_word*)lf[321]+1));}

/* k8513 in ##sys#read-prompt-hook in k8507 in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1578 ##sys#flush-output */
t2=*((C_word*)lf[320]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],*((C_word*)lf[321]+1));}

/* ##sys#repl-print-hook in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8492(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8492,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8496,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8501,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1569 ##sys#with-print-length-limit */
t6=*((C_word*)lf[317]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[312]+1),t5);}

/* a8500 in ##sys#repl-print-hook in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8501,2,t0,t1);}
/* ##sys#print */
t2=*((C_word*)lf[316]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* k8494 in ##sys#repl-print-hook in k8485 in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1570 ##sys#write-char-0 */
t2=*((C_word*)lf[315]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* ##sys#display-times in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8432(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8432,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8436,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1543 display-rj */
t5=((C_word*)t0)[2];
f_8411(t5,t3,t4,C_fix(8));}

/* k8434 in ##sys#display-times in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8436,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8439,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1544 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[310]);}

/* k8437 in k8434 in ##sys#display-times in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8442,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1545 display-rj */
t4=((C_word*)t0)[2];
f_8411(t4,t2,t3,C_fix(8));}

/* k8440 in k8437 in k8434 in ##sys#display-times in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8445,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1546 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[309]);}

/* k8443 in k8440 in k8437 in k8434 in ##sys#display-times in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8448,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(2));
/* eval.scm: 1547 display-rj */
t4=((C_word*)t0)[2];
f_8411(t4,t2,t3,C_fix(8));}

/* k8446 in k8443 in k8440 in k8437 in k8434 in ##sys#display-times in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8451,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1548 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[308]);}

/* k8449 in k8446 in k8443 in k8440 in k8437 in k8434 in ##sys#display-times in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8454,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(3));
/* eval.scm: 1549 display-rj */
t4=((C_word*)t0)[2];
f_8411(t4,t2,t3,C_fix(8));}

/* k8452 in k8449 in k8446 in k8443 in k8440 in k8437 in k8434 in ##sys#display-times in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8457,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1550 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[307]);}

/* k8455 in k8452 in k8449 in k8446 in k8443 in k8440 in k8437 in k8434 in ##sys#display-times in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8460,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
/* eval.scm: 1551 display-rj */
t4=((C_word*)t0)[2];
f_8411(t4,t2,t3,C_fix(8));}

/* k8458 in k8455 in k8452 in k8449 in k8446 in k8443 in k8440 in k8437 in k8434 in ##sys#display-times in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1552 display */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[306]);}

/* display-rj in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_8411(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8411,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8415,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_zerop(t2))){
t5=t4;
f_8415(2,t5,lf[305]);}
else{
/* eval.scm: 1538 number->string */
C_number_to_string(3,0,t4,t2);}}

/* k8413 in display-rj in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8415,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8418,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],t2);
/* eval.scm: 1540 spaces */
t5=((C_word*)t0)[2];
f_8387(t5,t3,t4);}

/* k8416 in k8413 in display-rj in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1541 display */
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* spaces in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_8387(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8387,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8393,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_8393(t6,t1,t2);}

/* doloop2014 in spaces in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_8393(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8393,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8403,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1535 display */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_make_character(32));}}

/* k8401 in doloop2014 in spaces in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8393(t3,((C_word*)t0)[2],t2);}

/* ##sys#resolve-include-filename in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8245(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4rv,(void*)f_8245r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_8245r(t0,t1,t2,t3,t4);}}

static void C_ccall f_8245r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(17);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_slot(t4,C_fix(0)));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8251,a[2]=t8,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8286,a[2]=t8,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8316,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t10,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1511 test */
t12=t10;
f_8286(t12,t11,t2);}

/* k8314 in ##sys#resolve-include-filename in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8316,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8326,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8363,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1515 ##sys#repository-path */
t4=*((C_word*)lf[244]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_8326(2,t3,*((C_word*)lf[251]+1));}}}

/* k8361 in k8314 in ##sys#resolve-include-filename in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8366,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8373,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1517 ##sys#repository-path */
t4=*((C_word*)lf[244]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_8366(t3,C_SCHEME_END_OF_LIST);}}

/* k8371 in k8361 in k8314 in ##sys#resolve-include-filename in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8373,2,t0,t1);}
t2=((C_word*)t0)[2];
f_8366(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k8364 in k8361 in k8314 in ##sys#resolve-include-filename in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_8366(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1513 ##sys#append */
t2=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[251]+1),t1);}

/* k8324 in k8314 in ##sys#resolve-include-filename in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8326,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8328,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_8328(t5,((C_word*)t0)[2],t1);}

/* loop in k8324 in k8314 in ##sys#resolve-include-filename in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_8328(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8328,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8338,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8352,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1521 string-append */
t7=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,t6,lf[304],((C_word*)t0)[5]);}}

/* k8350 in loop in k8324 in k8314 in ##sys#resolve-include-filename in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1521 test */
t2=((C_word*)t0)[3];
f_8286(t2,((C_word*)t0)[2],t1);}

/* k8336 in loop in k8324 in k8314 in ##sys#resolve-include-filename in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1524 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_8328(t3,((C_word*)t0)[4],t2);}}

/* test in ##sys#resolve-include-filename in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_8286(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8286,NULL,3,t0,t1,t2);}
t3=(C_word)C_fudge(C_fix(24));
t4=(C_truep(t3)?(C_truep(((C_word*)t0)[3])?(C_word)C_a_i_list(&a,2,lf[8],*((C_word*)lf[211]+1)):(C_word)C_a_i_list(&a,2,*((C_word*)lf[211]+1),lf[8])):(C_word)C_a_i_list(&a,1,lf[8]));
/* eval.scm: 1506 test2 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_8251(t5,t1,t2,t4);}

/* test2 in ##sys#resolve-include-filename in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_8251(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8251,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8264,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1500 exists? */
f_8226(t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8267,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_u_i_car(t3);
/* eval.scm: 1501 ##sys#string-append */
t6=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t2,t5);}}

/* k8265 in test2 in ##sys#resolve-include-filename in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8273,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1502 exists? */
f_8226(t2,t1);}

/* k8271 in k8265 in test2 in ##sys#resolve-include-filename in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1504 test2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8251(t3,((C_word*)t0)[6],((C_word*)t0)[2],t2);}}

/* k8262 in test2 in ##sys#resolve-include-filename in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* exists? in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_8226(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8226,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8230,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1495 ##sys#file-info */
t4=*((C_word*)lf[210]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k8228 in exists? in k8218 in k8214 in k8211 in k8207 in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=(C_word)C_eqp(C_fix(1),t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_not(t3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* initb in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_8193(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8193,NULL,2,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8195,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_8195 in initb in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8195(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8195,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8199,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1456 ##sys#hash-table-location */
t4=*((C_word*)lf[21]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k8197 */
static void C_ccall f_8199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(t1,C_fix(1),t2));}

/* null-environment in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8155(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8155r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8155r(t0,t1,t2,t3);}}

static void C_ccall f_8155r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[301]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8162,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_lessp(t2,C_fix(4));
t7=(C_truep(t6)?t6:(C_word)C_fixnum_greaterp(t2,C_fix(5)));
if(C_truep(t7)){
/* eval.scm: 1447 ##sys#error */
t8=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t5,lf[301],lf[302],t2);}
else{
t8=t5;
f_8162(2,t8,C_SCHEME_UNDEFINED);}}

/* k8160 in null-environment in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8162,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8169,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1450 make-vector */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k8167 in k8160 in null-environment in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8169,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[3]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(0)):C_SCHEME_FALSE);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,3,lf[291],t1,t3));}

/* scheme-report-environment in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8111(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8111r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8111r(t0,t1,t2,t3);}}

static void C_ccall f_8111r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,lf[298]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t7=t2;
switch(t7){
case C_fix(4):
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8131,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1438 ##sys#copy-env-table */
t9=*((C_word*)lf[294]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[289],C_SCHEME_TRUE,t6);
case C_fix(5):
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8144,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1439 ##sys#copy-env-table */
t9=*((C_word*)lf[294]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[290],C_SCHEME_TRUE,t6);
default:
/* eval.scm: 1440 ##sys#error */
t8=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,lf[298],lf[299],t2);}}

/* k8142 in scheme-report-environment in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8144,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[291],t1,((C_word*)t0)[2]));}

/* k8129 in scheme-report-environment in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8131,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[291],t1,((C_word*)t0)[2]));}

/* interaction-environment in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8108,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[292]);}

/* ##sys#environment-symbols in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7989(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7989r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7989r(t0,t1,t2,t3);}}

static void C_ccall f_7989r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(10);
t4=(C_word)C_i_check_structure(t2,lf[291]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep(t7)){
t8=(C_word)C_fix((C_word)C_header_size(t7));
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8010,a[2]=t6,a[3]=t7,a[4]=t10,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_8010(t12,t1,C_fix(0),C_SCHEME_END_OF_LIST);}
else{
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8081,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8083,a[2]=t9,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1425 ##sys#walk-namespace */
t12=*((C_word*)lf[296]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}}

/* a8082 in ##sys#environment-symbols in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8083(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8083,3,t0,t1,t2);}
t3=(C_word)C_i_not(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8093,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=t4;
f_8093(2,t5,t3);}
else{
/* eval.scm: 1427 pred */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* k8091 in a8082 in ##sys#environment-symbols in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8093,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k8079 in ##sys#environment-symbols in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* doloop1873 in ##sys#environment-symbols in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_8010(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8010,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8028,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_slot(((C_word*)t0)[3],t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8034,a[2]=t8,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_8034(t10,t5,t6,t3);}}

/* loop in doloop1873 in ##sys#environment-symbols in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_8034(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8034,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_i_not(((C_word*)t0)[3]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8053,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t5,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_8053(2,t8,t6);}
else{
/* eval.scm: 1419 pred */
t8=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t5);}}}

/* k8051 in loop in doloop1873 in ##sys#environment-symbols in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8053,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* eval.scm: 1420 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_8034(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* eval.scm: 1421 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8034(t3,((C_word*)t0)[2],t2,((C_word*)t0)[4]);}}

/* k8026 in doloop1873 in ##sys#environment-symbols in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_8028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_8010(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#copy-env-table in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7881(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5rv,(void*)f_7881r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_7881r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_7881r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t6=(C_word)C_notvemptyp(t5);
t7=(C_truep(t6)?(C_word)C_slot(t5,C_fix(0)):C_SCHEME_FALSE);
t8=(C_word)C_block_size(t2);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7891,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t7,a[6]=t2,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 1386 ##sys#make-vector */
t10=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t8,C_SCHEME_END_OF_LIST);}

/* k7889 in ##sys#copy-env-table in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7891,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7896,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_7896(t5,((C_word*)t0)[2],C_fix(0));}

/* doloop1849 in k7889 in ##sys#copy-env-table in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_7896(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7896,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[8]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[7]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7917,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7923,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_7923(t8,t3,t4);}}

/* copy in doloop1849 in k7889 in ##sys#copy-env-table in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_7923(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(8);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7923,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_i_not(((C_word*)t0)[5]);
t6=(C_truep(t5)?t5:(C_word)C_u_i_memq(t4,((C_word*)t0)[5]));
if(C_truep(t6)){
t7=(C_word)C_slot(t3,C_fix(1));
t8=(C_truep(((C_word*)t0)[4])?((C_word*)t0)[3]:(C_word)C_slot(t3,C_fix(2)));
t9=(C_word)C_a_i_vector(&a,3,t4,t7,t8);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7956,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1401 copy */
t14=t10;
t15=t11;
t1=t14;
t2=t15;
goto loop;}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1402 copy */
t14=t1;
t15=t7;
t1=t14;
t2=t15;
goto loop;}}}

/* k7954 in copy in doloop1849 in k7889 in ##sys#copy-env-table in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7956,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7915 in doloop1849 in k7889 in ##sys#copy-env-table in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_7896(t4,((C_word*)t0)[2],t3);}

/* ##sys#environment? in k7856 in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7865(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7865,3,t0,t1,t2);}
if(C_truep((C_word)C_i_structurep(t2,lf[291]))){
t3=(C_word)C_block_size(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(C_fix(3),t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* ##sys#string->c-identifier in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7802(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7802,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7806,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1364 string-copy */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k7804 in ##sys#string->c-identifier in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7806,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7814,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7814(t6,((C_word*)t0)[2],C_fix(0));}

/* doloop1818 in k7804 in ##sys#string->c-identifier in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_7814(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7814,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7834,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_u_i_char_alphabeticp(t3))){
t5=t4;
f_7834(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_u_i_char_numericp(t3);
t6=(C_word)C_i_not(t5);
t7=t4;
f_7834(t7,(C_truep(t6)?t6:(C_word)C_eqp(t2,C_fix(0))));}}}

/* k7832 in doloop1818 in k7804 in ##sys#string->c-identifier in k7798 in k7795 in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_7834(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(t1)?(C_word)C_setsubchar(((C_word*)t0)[5],((C_word*)t0)[4],C_make_character(95)):C_SCHEME_UNDEFINED);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_7814(t4,((C_word*)t0)[2],t3);}

/* set-extension-specifier! in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7758(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7758,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_symbol_2(t2,lf[287]);
t5=(C_word)C_u_i_assq(t2,*((C_word*)lf[284]+1));
if(C_truep(t5)){
t6=(C_word)C_slot(t5,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7776,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_setslot(t5,C_fix(1),t7));}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7790,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_a_i_cons(&a,2,t2,t6);
t8=(C_word)C_a_i_cons(&a,2,t7,*((C_word*)lf[284]+1));
t9=C_mutate((C_word*)lf[284]+1 /* (set! extension-specifiers ...) */,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}}

/* a7789 in set-extension-specifier! in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7790(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7790,3,t0,t1,t2);}
/* eval.scm: 1320 proc */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,C_SCHEME_FALSE);}

/* a7775 in set-extension-specifier! in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7776(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7776,3,t0,t1,t2);}
/* eval.scm: 1318 proc */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7236,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7239,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7264,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7305,a[2]=t5,a[3]=t3,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7626,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t9=(C_word)C_u_i_car(t2);
t10=t8;
f_7626(t10,(C_word)C_i_symbolp(t9));}
else{
t9=t8;
f_7626(t9,C_SCHEME_FALSE);}}

/* k7624 in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_7626(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7626,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(0));
t3=(C_word)C_u_i_assq(t2,*((C_word*)lf[284]+1));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7635,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
t6=t5;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[7]);}
else{
/* eval.scm: 1306 ##sys#error */
t4=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[6],lf[285],((C_word*)t0)[7]);}}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[7]))){
/* eval.scm: 1308 doit */
t2=((C_word*)t0)[2];
f_7305(t2,((C_word*)t0)[6],((C_word*)t0)[7]);}
else{
/* eval.scm: 1309 ##sys#error */
t2=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[6],lf[286],((C_word*)t0)[7]);}}}

/* k7633 in k7624 in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7635,2,t0,t1);}
if(C_truep((C_word)C_i_stringp(t1))){
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[197],t2);
/* eval.scm: 1294 values */
C_values(4,0,((C_word*)t0)[5],t3,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7665,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1296 vector->list */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}
else{
/* eval.scm: 1305 ##sys#do-the-right-thing */
t2=*((C_word*)lf[131]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3]);}}}

/* k7663 in k7633 in k7624 in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7665,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7667,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_7667(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in k7663 in k7633 in k7624 in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_7667(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7667,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7685,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7689,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1300 reverse */
t7=*((C_word*)lf[32]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7694,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7704,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}}

/* a7703 in loop in k7663 in k7633 in k7624 in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7704(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7704,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t6=(C_truep(t3)?t3:((C_word*)t0)[3]);
/* eval.scm: 1302 loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_7667(t7,t1,t4,t5,t6);}

/* a7693 in loop in k7663 in k7633 in k7624 in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7694,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
/* eval.scm: 1301 ##sys#do-the-right-thing */
t3=*((C_word*)lf[131]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7687 in loop in k7663 in k7633 in k7624 in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7683 in loop in k7663 in k7633 in k7624 in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7685,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[66],t1);
/* eval.scm: 1300 values */
C_values(4,0,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* doit in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_7305(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7305,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_i_memq(t2,lf[276]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7315,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t3)){
t5=t4;
f_7315(2,t5,t3);}
else{
if(C_truep(((C_word*)t0)[3])){
t5=t4;
f_7315(2,t5,(C_word)C_u_i_memq(t2,lf[282]));}
else{
/* eval.scm: 1239 ##sys#feature? */
t5=*((C_word*)lf[283]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}}

/* k7313 in doit in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7315,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7322,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1240 impform */
t3=((C_word*)t0)[5];
f_7264(t3,t2,lf[277],((C_word*)t0)[4],C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],*((C_word*)lf[3]+1)))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7335,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7339,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[278],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=t3;
f_7339(t7,(C_word)C_a_i_cons(&a,2,lf[139],t6));}
else{
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[52],t4);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=t3;
f_7339(t8,(C_word)C_a_i_cons(&a,2,lf[235],t7));}}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],*((C_word*)lf[5]+1)))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7382,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1250 ##sys#extension-information */
t3=*((C_word*)lf[263]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],lf[281]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7477,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1265 ##sys#extension-information */
t3=*((C_word*)lf[263]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],lf[281]);}}}}

/* k7475 in k7313 in doit in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7477,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_assq(lf[56],t1);
t3=(C_word)C_u_i_assq(lf[279],t1);
t4=(C_word)C_u_i_assq(lf[268],t1);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7492,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
/* eval.scm: 1270 add-req */
t6=((C_word*)t0)[2];
f_7239(t6,t5,((C_word*)t0)[3],C_SCHEME_TRUE);}
else{
t6=t5;
f_7492(2,t6,C_SCHEME_UNDEFINED);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7588,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1284 add-req */
t3=((C_word*)t0)[2];
f_7239(t3,t2,((C_word*)t0)[3],C_SCHEME_FALSE);}}

/* k7586 in k7475 in k7313 in doit in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7588,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7595,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[52],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[127],t5);
/* eval.scm: 1286 impform */
t7=((C_word*)t0)[2];
f_7264(t7,t2,t6,((C_word*)t0)[3],C_SCHEME_FALSE);}

/* k7593 in k7586 in k7475 in k7313 in doit in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1285 values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k7490 in k7475 in k7313 in doit in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[30],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7492,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7499,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7507,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7511,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[52],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[125],t7);
t9=t4;
f_7511(t9,(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST));}
else{
t5=t4;
f_7511(t5,C_SCHEME_END_OF_LIST);}}

/* k7509 in k7490 in k7475 in k7313 in doit in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_7511(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7511,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7515,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7519,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:(C_truep(((C_word*)t0)[4])?C_SCHEME_FALSE:((C_word*)t0)[3]));
if(C_truep(t4)){
t5=t3;
f_7519(t5,C_SCHEME_END_OF_LIST);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7533,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7537,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7539,tmp=(C_word)a,a+=2,tmp);
t8=(C_truep(((C_word*)t0)[4])?(C_word)C_slot(((C_word*)t0)[4],C_fix(1)):(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));
/* map */
t9=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,t7,t8);}}

/* a7538 in k7509 in k7490 in k7475 in k7313 in doit in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7539(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7539,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[52],t3));}

/* k7535 in k7509 in k7490 in k7475 in k7313 in doit in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7531 in k7509 in k7490 in k7475 in k7313 in doit in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7533,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[127],t1);
t3=((C_word*)t0)[2];
f_7519(t3,(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}

/* k7517 in k7509 in k7490 in k7475 in k7313 in doit in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_7519(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7513 in k7509 in k7490 in k7475 in k7313 in doit in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7505 in k7490 in k7475 in k7313 in doit in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7507,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[66],t1);
/* eval.scm: 1272 impform */
t3=((C_word*)t0)[4];
f_7264(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k7497 in k7490 in k7475 in k7313 in doit in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1271 values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k7380 in k7313 in doit in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7382,2,t0,t1);}
t2=(C_word)C_u_i_assq(lf[279],t1);
t3=(C_word)C_u_i_assq(lf[56],t1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7399,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7403,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t3)){
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[52],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,lf[125],t8);
t10=t5;
f_7403(t10,(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST));}
else{
t6=t5;
f_7403(t6,C_SCHEME_END_OF_LIST);}}

/* k7401 in k7380 in k7313 in doit in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_7403(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7403,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7411,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7415,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=t3;
f_7415(t4,lf[280]);}
else{
if(C_truep(((C_word*)t0)[2])){
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[278],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=t3;
f_7415(t7,(C_word)C_a_i_cons(&a,2,lf[139],t6));}
else{
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[52],t4);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=t3;
f_7415(t8,(C_word)C_a_i_cons(&a,2,lf[235],t7));}}}

/* k7413 in k7401 in k7380 in k7313 in doit in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_7415(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1256 impform */
t2=((C_word*)t0)[4];
f_7264(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k7409 in k7401 in k7380 in k7313 in doit in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7411,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t3=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k7397 in k7380 in k7313 in doit in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7399,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[66],t1);
/* eval.scm: 1253 values */
C_values(4,0,((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k7337 in k7313 in doit in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_7339(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1243 impform */
t2=((C_word*)t0)[4];
f_7264(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k7333 in k7313 in doit in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1242 values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k7320 in k7313 in doit in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1240 values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* impform in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_7264(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7264,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7276,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7280,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7283,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
t8=(C_word)C_i_not(t4);
if(C_truep(t8)){
t9=t7;
f_7283(2,t9,t8);}
else{
/* eval.scm: 1232 ##sys#current-module */
t9=*((C_word*)lf[39]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t7);}}
else{
t8=t7;
f_7283(2,t8,C_SCHEME_FALSE);}}

/* k7281 in impform in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7283,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[275],t2);
t4=((C_word*)t0)[2];
f_7280(t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}
else{
t2=((C_word*)t0)[2];
f_7280(t2,C_SCHEME_END_OF_LIST);}}

/* k7278 in impform in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_7280(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7274 in impform in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7276,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[66],t2));}

/* add-req in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_7239(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7239,NULL,4,t0,t1,t2,t3);}
if(C_truep(((C_word*)t0)[2])){
t4=(C_truep(t3)?lf[270]:lf[271]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7252,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7258,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1224 ##sys#hash-table-update! */
t7=*((C_word*)lf[18]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,*((C_word*)lf[274]+1),t4,t5,t6);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* a7257 in add-req in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7258,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}

/* a7251 in add-req in ##sys#do-the-right-thing in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7252(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7252,3,t0,t1,t2);}
/* lset-adjoin */
t3=*((C_word*)lf[272]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,*((C_word*)lf[273]+1),t2,((C_word*)t0)[2]);}

/* ##sys#lookup-runtime-requirements in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7187(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7187,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7193,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7193(t6,t1,t2);}

/* loop1 in ##sys#lookup-runtime-requirements in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_7193(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7193,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7207,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_i_car(t2);
/* eval.scm: 1213 ##sys#extension-information */
t5=*((C_word*)lf[263]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_FALSE);}}

/* k7205 in loop1 in ##sys#lookup-runtime-requirements in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7207,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7210,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_u_i_assq(lf[268],t1);
t4=t2;
f_7210(t4,(C_truep(t3)?(C_word)C_slot(t3,C_fix(1)):C_SCHEME_FALSE));}
else{
t3=t2;
f_7210(t3,C_SCHEME_FALSE);}}

/* k7208 in k7205 in loop1 in ##sys#lookup-runtime-requirements in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_7210(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7210,NULL,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7217,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1217 loop1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7193(t5,t3,t4);}

/* k7215 in k7208 in k7205 in loop1 in ##sys#lookup-runtime-requirements in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1212 append */
t2=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* extension-information in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7181(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7181,3,t0,t1,t2);}
/* eval.scm: 1203 ##sys#extension-information */
t3=*((C_word*)lf[263]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[267]);}

/* ##sys#extension-information in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7153(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7153,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7157,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 1195 ##sys#repository-path */
t5=*((C_word*)lf[244]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k7155 in ##sys#extension-information in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7157,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7163,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 1196 ##sys#canonicalize-extension-path */
t3=*((C_word*)lf[238]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7161 in k7155 in ##sys#extension-information in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7163,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7166,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1197 string-append */
t3=((C_word*)t0)[3];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],lf[265],t1,lf[266]);}

/* k7164 in k7161 in k7155 in ##sys#extension-information in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7166,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7169,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7179,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1198 string-append */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,lf[264]);}

/* k7177 in k7164 in k7161 in k7155 in ##sys#extension-information in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1198 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7167 in k7164 in k7161 in k7155 in ##sys#extension-information in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* with-input-from-file1563 */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#require in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7124(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_7124r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7124r(t0,t1,t2);}}

static void C_ccall f_7124r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7130,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7130(t6,t1,t2);}

/* loop1549 in ##sys#require in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_7130(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7130,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7143,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#load-extension */
t5=*((C_word*)lf[255]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,lf[262]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k7141 in loop1549 in ##sys#require in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7130(t3,((C_word*)t0)[2],t2);}

/* ##sys#provided? in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7110(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7110,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7121,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1176 ##sys#canonicalize-extension-path */
t4=*((C_word*)lf[238]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[261]);}

/* k7119 in ##sys#provided? in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_member(t1,*((C_word*)lf[253]+1));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* ##sys#provide in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7074(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_7074r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7074r(t0,t1,t2);}}

static void C_ccall f_7074r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7080,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7080(t6,t1,t2);}

/* loop1532 in ##sys#provide in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_7080(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7080,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_i_check_symbol_2(t3,lf[259]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7096,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1169 ##sys#canonicalize-extension-path */
t6=*((C_word*)lf[238]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[259]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k7094 in loop1532 in ##sys#provide in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7096,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,*((C_word*)lf[253]+1));
t3=C_mutate((C_word*)lf[253]+1 /* (set! loaded-extensions ...) */,t2);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_7080(t5,((C_word*)t0)[2],t4);}

/* ##sys#load-extension in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6997(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4rv,(void*)f_6997r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_6997r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6997r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(12);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t6=(C_word)C_vemptyp(t4);
t7=(C_truep(t6)?C_SCHEME_TRUE:(C_word)C_slot(t4,C_fix(0)));
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7004,a[2]=t3,a[3]=t7,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)t5)[1]))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7057,a[2]=t8,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1148 string->symbol */
t10=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,((C_word*)t5)[1]);}
else{
t9=t8;
f_7004(t9,(C_word)C_i_check_symbol_2(((C_word*)t5)[1],t3));}}

/* k7055 in ##sys#load-extension in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_7004(t3,t2);}

/* k7002 in ##sys#load-extension in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_7004(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7004,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7007,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1150 ##sys#canonicalize-extension-path */
t3=*((C_word*)lf[238]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[2]);}

/* k7005 in k7002 in ##sys#load-extension in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7007,2,t0,t1);}
t2=(C_word)C_i_member(t1,*((C_word*)lf[253]+1));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)((C_word*)t0)[4])[1],*((C_word*)lf[3]+1)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7022,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1153 ##sys#load-library-0 */
t4=*((C_word*)lf[228]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[4])[1],C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7034,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1157 ##sys#find-extension */
t4=*((C_word*)lf[248]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_SCHEME_TRUE);}}}

/* k7032 in k7005 in k7002 in ##sys#load-extension in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7034,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7040,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1159 ##sys#load */
t3=*((C_word*)lf[192]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,t1,C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
if(C_truep(((C_word*)t0)[4])){
/* eval.scm: 1162 ##sys#error */
t2=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[3],lf[257],((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* k7038 in k7032 in k7005 in k7002 in ##sys#load-extension in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7040,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],*((C_word*)lf[253]+1));
t3=C_mutate((C_word*)lf[253]+1 /* (set! loaded-extensions ...) */,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}

/* k7020 in k7005 in k7002 in ##sys#load-extension in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_7022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep(((C_word*)t0)[4])){
/* eval.scm: 1155 ##sys#error */
t2=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[3],lf[256],((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* ##sys#find-extension in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6898(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6898,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6902,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1124 ##sys#repository-path */
t5=*((C_word*)lf[244]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k6900 in ##sys#find-extension in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6902,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6904,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6950,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_truep(*((C_word*)lf[246]+1))?lf[250]:C_SCHEME_END_OF_LIST);
t5=(C_truep(t1)?(C_word)C_a_i_list(&a,1,t1):C_SCHEME_END_OF_LIST);
t6=(C_truep(((C_word*)t0)[2])?*((C_word*)lf[251]+1):C_SCHEME_END_OF_LIST);
t7=(C_truep(*((C_word*)lf[246]+1))?C_SCHEME_END_OF_LIST:lf[252]);
/* eval.scm: 1133 ##sys#append */
t8=*((C_word*)lf[68]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t3,t4,t5,t6,t7);}

/* k6948 in k6900 in ##sys#find-extension in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6950,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6952,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_6952(t5,((C_word*)t0)[2],t1);}

/* loop in k6948 in k6900 in ##sys#find-extension in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_6952(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6952,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6965,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1140 check */
t5=((C_word*)t0)[2];
f_6904(t5,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k6963 in loop in k6948 in k6900 in ##sys#find-extension in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1141 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6952(t3,((C_word*)t0)[4],t2);}}

/* check in k6900 in ##sys#find-extension in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_6904(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6904,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6908,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1126 string-append */
t4=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,lf[249],((C_word*)t0)[2]);}

/* k6906 in check in k6900 in ##sys#find-extension in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6908,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6914,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=*((C_word*)lf[177]+1);
if(C_truep(t3)){
t4=t2;
f_6914(2,t4,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_fudge(C_fix(24)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6943,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1130 ##sys#string-append */
t5=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t1,*((C_word*)lf[211]+1));}
else{
t4=t2;
f_6914(2,t4,C_SCHEME_FALSE);}}}
else{
t3=t2;
f_6914(2,t3,C_SCHEME_FALSE);}}

/* k6941 in k6906 in check in k6900 in ##sys#find-extension in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1130 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6912 in k6906 in check in k6900 in ##sys#find-extension in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6914,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6917,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_6917(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6924,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1131 ##sys#string-append */
t4=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],lf[8]);}}

/* k6922 in k6912 in k6906 in check in k6900 in ##sys#find-extension in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1131 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6915 in k6912 in k6906 in check in k6900 in ##sys#find-extension in k6892 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* ##sys#canonicalize-extension-path in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6734(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6734,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6737,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6756,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t6=t5;
f_6756(2,t6,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* eval.scm: 1084 ##sys#symbol->string */
t6=*((C_word*)lf[240]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
if(C_truep((C_word)C_i_listp(t2))){
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6839,a[2]=t4,a[3]=t7,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_6839(t9,t5,t2);}
else{
t6=t5;
f_6756(2,t6,C_SCHEME_UNDEFINED);}}}}

/* loop in ##sys#canonicalize-extension-path in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_6839(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6839,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[241]);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6856,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
/* eval.scm: 1091 ##sys#symbol->string */
t5=*((C_word*)lf[240]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}
else{
if(C_truep((C_word)C_i_stringp(t3))){
t5=t4;
f_6856(2,t5,t3);}
else{
/* eval.scm: 1093 err */
t5=((C_word*)t0)[2];
f_6737(t5,t4);}}}}

/* k6854 in loop in ##sys#canonicalize-extension-path in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6856,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?lf[242]:lf[243]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6864,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* eval.scm: 1097 loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_6839(t7,t5,t6);}

/* k6862 in k6854 in loop in ##sys#canonicalize-extension-path in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1089 string-append */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6754 in ##sys#canonicalize-extension-path in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6756,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6761,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_6761(t5,((C_word*)t0)[2],t1);}

/* check in k6754 in ##sys#canonicalize-extension-path in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_6761(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6761,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(C_word)C_eqp(C_fix(0),t3);
if(C_truep(t4)){
/* eval.scm: 1100 err */
t5=((C_word*)t0)[3];
f_6737(t5,t1);}
else{
t5=(C_word)C_subchar(t2,C_fix(0));
t6=(C_word)C_eqp(C_make_character(92),t5);
t7=(C_truep(t6)?t6:(C_word)C_eqp(C_make_character(47),t5));
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6787,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1102 ##sys#substring */
t9=*((C_word*)lf[200]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,t2,C_fix(1),t3);}
else{
t8=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t9=(C_word)C_subchar(t2,t8);
t10=(C_word)C_eqp(C_make_character(92),t9);
t11=(C_truep(t10)?t10:(C_word)C_eqp(C_make_character(47),t9));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6800,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t13=(C_word)C_u_fixnum_difference(t3,C_fix(1));
/* eval.scm: 1104 ##sys#substring */
t14=*((C_word*)lf[200]+1);
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,t12,t2,C_fix(0),t13);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,t2);}}}}

/* k6798 in check in k6754 in ##sys#canonicalize-extension-path in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1104 check */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6761(t2,((C_word*)t0)[2],t1);}

/* k6785 in check in k6754 in ##sys#canonicalize-extension-path in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1102 check */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6761(t2,((C_word*)t0)[2],t1);}

/* err in ##sys#canonicalize-extension-path in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_6737(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6737,NULL,2,t0,t1);}
/* eval.scm: 1081 ##sys#error */
t2=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],lf[239],((C_word*)t0)[2]);}

/* ##sys#load-library in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6648(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6648r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6648r(t0,t1,t2,t3);}}

static void C_ccall f_6648r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_symbol_2(t2,lf[236]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6655,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_notvemptyp(t3);
t7=(C_truep(t6)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
/* eval.scm: 1058 ##sys#load-library-0 */
t8=*((C_word*)lf[228]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,t2,t7);}

/* k6653 in ##sys#load-library in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6655,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6665,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_dlerror),C_fix(0));}}

/* k6663 in k6653 in ##sys#load-library in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1059 ##sys#error */
t2=*((C_word*)lf[44]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[236],lf[237],((C_word*)t0)[2],t1);}

/* ##sys#load-library-0 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6542(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6542,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6546,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 1031 ##sys#->feature-id */
t5=*((C_word*)lf[234]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6544 in ##sys#load-library-0 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6546,2,t0,t1);}
t2=(C_word)C_u_i_memq(t1,*((C_word*)lf[142]+1));
if(C_truep(t2)){
t3=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6555,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=t3;
f_6555(t4,(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6638,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* eval.scm: 1036 ##sys#string-append */
t6=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,*((C_word*)lf[222]+1));}}}

/* k6636 in k6544 in ##sys#load-library-0 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6642,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1037 dynamic-load-libraries */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k6640 in k6636 in k6544 in ##sys#load-library-0 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6642,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6555(t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6553 in k6544 in ##sys#load-library-0 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_6555(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6555,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6558,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6620,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6624,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1042 ##sys#string->c-identifier */
t6=*((C_word*)lf[233]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k6622 in k6553 in k6544 in ##sys#load-library-0 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1040 string-append */
t2=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[231],t1,lf[232]);}

/* k6618 in k6553 in k6544 in ##sys#load-library-0 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1039 ##sys#make-c-string */
t2=*((C_word*)lf[204]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6556 in k6553 in k6544 in ##sys#load-library-0 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6561,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6607,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1044 load-verbose */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6605 in k6556 in k6553 in k6544 in ##sys#load-library-0 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6607,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6610,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1045 display */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[230]);}
else{
t2=((C_word*)t0)[3];
f_6561(2,t2,C_SCHEME_UNDEFINED);}}

/* k6608 in k6605 in k6556 in k6553 in k6544 in ##sys#load-library-0 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6610,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6613,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1046 display */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6611 in k6608 in k6605 in k6556 in k6553 in k6544 in ##sys#load-library-0 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1047 display */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[229]);}

/* k6559 in k6556 in k6553 in k6544 in ##sys#load-library-0 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6561,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6566,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_6566(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k6559 in k6556 in k6553 in k6544 in ##sys#load-library-0 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_6566(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6566,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6579,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6600,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1050 ##sys#make-c-string */
t6=*((C_word*)lf[204]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}

/* k6598 in loop in k6559 in k6556 in k6553 in k6544 in ##sys#load-library-0 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1050 ##sys#dload */
t2=*((C_word*)lf[203]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k6577 in loop in k6559 in k6556 in k6553 in k6544 in ##sys#load-library-0 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6579,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6582,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],*((C_word*)lf[142]+1)))){
t3=t2;
f_6582(t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],*((C_word*)lf[142]+1));
t4=C_mutate((C_word*)lf[142]+1 /* (set! features ...) */,t3);
t5=t2;
f_6582(t5,t4);}}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1053 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6566(t3,((C_word*)t0)[5],t2);}}

/* k6580 in k6577 in loop in k6559 in k6556 in k6553 in k6544 in ##sys#load-library-0 in k6538 in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_6582(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* complete in k6529 in k6522 in k6517 in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6533(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6533,3,t0,t1,t2);}
/* ##sys#string-append */
t3=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* load-noisily in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6493(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_6493r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6493r(t0,t1,t2,t3);}}

static void C_ccall f_6493r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6497,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6514,tmp=(C_word)a,a+=2,tmp);
/* ##sys#get-keyword */
t6=*((C_word*)lf[218]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[221],t3,t5);}

/* a6513 in load-noisily in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6514,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k6495 in load-noisily in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6497,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6500,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6511,tmp=(C_word)a,a+=2,tmp);
/* ##sys#get-keyword */
t4=*((C_word*)lf[218]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[220],((C_word*)t0)[2],t3);}

/* a6510 in k6495 in load-noisily in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6511,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k6498 in k6495 in load-noisily in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6503,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6508,tmp=(C_word)a,a+=2,tmp);
/* ##sys#get-keyword */
t4=*((C_word*)lf[218]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[219],((C_word*)t0)[2],t3);}

/* a6507 in k6498 in k6495 in load-noisily in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6508,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k6501 in k6498 in k6495 in load-noisily in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 992  ##sys#load */
t2=*((C_word*)lf[192]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2],t1);}

/* load-relative in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6457(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_6457r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6457r(t0,t1,t2,t3);}}

static void C_ccall f_6457r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6465,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_subchar(t2,C_fix(0));
if(C_truep((C_truep((C_word)C_eqp(t5,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t5,C_make_character(47)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t6=t4;
f_6465(2,t6,t2);}
else{
/* eval.scm: 988  ##sys#string-append */
t6=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[175]+1),t2);}}

/* k6463 in load-relative in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_u_i_car(t2));
/* eval.scm: 985  ##sys#load */
t5=*((C_word*)lf[192]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[2],t1,t4,C_SCHEME_FALSE);}

/* load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6435(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6435r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6435r(t0,t1,t2,t3);}}

static void C_ccall f_6435r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
/* eval.scm: 982  ##sys#load */
t6=*((C_word*)lf[192]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,t5,C_SCHEME_FALSE);}

/* ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6023(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+24)){
C_save_and_reclaim((void*)tr5r,(void*)f_6023r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6023r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6023r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(24);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_6025,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t6,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t4,a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=t3,tmp=(C_word)a,a+=16,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6385,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6390,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-timer11181272 */
t10=t9;
f_6390(t10,t1);}
else{
t10=(C_word)C_u_i_car(t5);
t11=(C_word)C_slot(t5,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-printer11191270 */
t12=t8;
f_6385(t12,t1,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body11161124 */
t14=t7;
f_6025(t14,t1,t10,t12);}}}

/* def-timer1118 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_6390(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6390,NULL,2,t0,t1);}
/* def-printer11191270 */
t2=((C_word*)t0)[2];
f_6385(t2,t1,C_SCHEME_FALSE);}

/* def-printer1119 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_6385(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6385,NULL,3,t0,t1,t2);}
/* body11161124 */
t3=((C_word*)t0)[2];
f_6025(t3,t1,t2,C_SCHEME_FALSE);}

/* body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_6025(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6025,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_6029,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t3,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t2,a[15]=((C_word*)t0)[13],a[16]=t1,a[17]=((C_word*)t0)[14],a[18]=((C_word*)t0)[15],tmp=(C_word)a,a+=19,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[7])[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6384,a[2]=t4,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 914  ##sys#expand-home-path */
t6=*((C_word*)lf[215]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)((C_word*)t0)[7])[1]);}
else{
t5=t4;
f_6029(t5,C_SCHEME_UNDEFINED);}}

/* k6382 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_6029(t3,t2);}

/* k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_6029(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6029,NULL,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_6032,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6306,a[2]=t3,a[3]=((C_word*)t0)[7],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 917  port? */
t6=*((C_word*)lf[214]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)((C_word*)t0)[7])[1]);}

/* k6304 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6306,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_6032(2,t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[3])[1]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6321,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 919  ##sys#file-info */
t3=*((C_word*)lf[210]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[3])[1]);}
else{
t2=((C_word*)((C_word*)t0)[3])[1];
/* eval.scm: 910  ##sys#signal-hook */
t3=*((C_word*)lf[184]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[4],lf[212],lf[197],lf[213],t2);}}}

/* k6319 in k6304 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6324,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_slot(t1,C_fix(4));
if(C_truep(t3)){
t4=(C_word)C_eqp(C_fix(1),t3);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t2;
f_6324(t6,(C_word)C_i_not(((C_word*)((C_word*)t0)[2])[1]));}
else{
t4=t2;
f_6324(t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_6324(t3,C_SCHEME_FALSE);}}

/* k6322 in k6319 in k6304 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_6324(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6324,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_6032(2,t2,((C_word*)((C_word*)t0)[3])[1]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6327,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 925  ##sys#string-append */
t3=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[3])[1],*((C_word*)lf[211]+1));}}

/* k6325 in k6322 in k6319 in k6304 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6333,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=*((C_word*)lf[177]+1);
if(C_truep(t3)){
t4=t2;
f_6333(2,t4,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_fudge(C_fix(24)))){
/* eval.scm: 928  ##sys#file-info */
t4=*((C_word*)lf[210]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t1);}
else{
t4=t2;
f_6333(2,t4,C_SCHEME_FALSE);}}}

/* k6331 in k6325 in k6322 in k6319 in k6304 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6333,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_6032(2,t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6336,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 930  ##sys#string-append */
t3=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],lf[8]);}}

/* k6334 in k6331 in k6325 in k6322 in k6319 in k6304 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6342,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 931  ##sys#file-info */
t3=*((C_word*)lf[210]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k6340 in k6334 in k6331 in k6325 in k6322 in k6319 in k6304 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_6032(2,t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)((C_word*)t0)[3])[1];
t3=((C_word*)t0)[5];
f_6032(2,t3,(C_truep(t2)?C_SCHEME_FALSE:((C_word*)((C_word*)t0)[2])[1]));}}

/* k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6032,2,t0,t1);}
t2=((C_word*)t0)[18];
t3=(C_truep(t2)?t2:((C_word*)t0)[17]);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_6038,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=t3,a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=t1,a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
t5=(C_word)C_i_stringp(((C_word*)((C_word*)t0)[7])[1]);
t6=(C_truep(t5)?(C_word)C_i_not(t1):C_SCHEME_FALSE);
if(C_truep(t6)){
/* eval.scm: 936  ##sys#signal-hook */
t7=*((C_word*)lf[184]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t4,lf[206],lf[197],lf[207],((C_word*)((C_word*)t0)[7])[1]);}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6297,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 937  load-verbose */
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* k6295 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6297,2,t0,t1);}
t2=(C_truep(t1)?((C_word*)t0)[5]:C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6285,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 938  display */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[209]);}
else{
t3=((C_word*)t0)[3];
f_6038(2,t3,C_SCHEME_UNDEFINED);}}

/* k6283 in k6295 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6288,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 939  display */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6286 in k6283 in k6295 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6291,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 940  display */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[208]);}

/* k6289 in k6286 in k6283 in k6295 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 941  flush-output */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6038,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6041,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
if(C_truep(((C_word*)t0)[14])){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6242,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6270,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 943  ##sys#make-c-string */
t5=*((C_word*)lf[204]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[14]);}
else{
t3=t2;
f_6041(2,t3,C_SCHEME_FALSE);}}

/* k6268 in k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 943  ##sys#dload */
t2=*((C_word*)lf[203]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k6240 in k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6242,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_6041(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6266,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 944  has-sep? */
f_5977(t2,((C_word*)t0)[3]);}}

/* k6264 in k6240 in k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6266,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_6041(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6258,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6262,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 945  ##sys#string-append */
t4=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[205],((C_word*)t0)[2]);}}

/* k6260 in k6264 in k6240 in k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 945  ##sys#make-c-string */
t2=*((C_word*)lf[204]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6256 in k6264 in k6240 in k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 945  ##sys#dload */
t2=*((C_word*)lf[203]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k6039 in k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6044,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_6044(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6049,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* eval.scm: 946  call-with-current-continuation */
t4=*((C_word*)lf[202]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}}

/* a6048 in k6039 in k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6049(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6049,3,t0,t1,t2);}
t3=C_SCHEME_TRUE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t0)[13];
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_6053,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t6,a[15]=t4,a[16]=t2,tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[13])){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6229,a[2]=((C_word*)t0)[13],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 952  has-sep? */
f_5977(t8,((C_word*)t0)[13]);}
else{
t8=t7;
f_6053(2,t8,C_SCHEME_FALSE);}}

/* k6227 in a6048 in k6039 in k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(t1,C_fix(1));
/* eval.scm: 953  ##sys#substring */
t3=*((C_word*)lf[200]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2);}
else{
t2=((C_word*)t0)[3];
f_6053(2,t2,lf[201]);}}

/* k6051 in a6048 in k6039 in k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[48],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6053,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6054,a[2]=((C_word*)t0)[16],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6063,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=t13,a[7]=t11,a[8]=t9,a[9]=t7,tmp=(C_word)a,a+=10,tmp);
t15=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6074,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
t16=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6217,a[2]=t13,a[3]=t11,a[4]=t9,a[5]=t7,a[6]=t5,a[7]=t3,a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],tmp=(C_word)a,a+=10,tmp);
/* ##sys#dynamic-wind */
t17=*((C_word*)lf[42]+1);
((C_proc5)(void*)(*((C_word*)t17+1)))(5,t17,((C_word*)t0)[2],t14,t15,t16);}

/* a6216 in k6051 in a6048 in k6039 in k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6217,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,*((C_word*)lf[193]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,*((C_word*)lf[174]+1));
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,*((C_word*)lf[175]+1));
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,*((C_word*)lf[173]+1));
t6=C_mutate((C_word*)lf[193]+1 /* (set! read-error-with-line-number ...) */,((C_word*)((C_word*)t0)[5])[1]);
t7=C_mutate((C_word*)lf[174]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[4])[1]);
t8=C_mutate((C_word*)lf[175]+1 /* (set! current-load-path ...) */,((C_word*)((C_word*)t0)[3])[1]);
t9=C_mutate((C_word*)lf[173]+1 /* (set! abort-load ...) */,((C_word*)((C_word*)t0)[2])[1]);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}

/* a6073 in k6051 in a6048 in k6039 in k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6074,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6078,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[5])){
/* eval.scm: 955  open-input-file */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t3=t2;
f_6078(2,t3,((C_word*)((C_word*)t0)[2])[1]);}}

/* k6076 in a6073 in k6051 in a6048 in k6039 in k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6078,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6083,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6086,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6208,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 956  ##sys#dynamic-wind */
t5=*((C_word*)lf[42]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[2],t2,t3,t4);}

/* a6207 in k6076 in a6073 in k6051 in a6048 in k6039 in k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6208,2,t0,t1);}
/* eval.scm: 978  close-input-port */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a6085 in k6076 in a6073 in k6051 in a6048 in k6039 in k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6090,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 959  peek-char */
t3=*((C_word*)lf[199]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[9]);}

/* k6088 in a6085 in k6076 in a6073 in k6051 in a6048 in k6039 in k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6090,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6093,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(t1,C_make_character(127));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6202,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_dlerror),C_fix(0));}
else{
t4=t2;
f_6093(2,t4,C_SCHEME_UNDEFINED);}}

/* k6200 in k6088 in a6085 in k6076 in a6073 in k6051 in a6048 in k6039 in k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 961  ##sys#error */
t2=*((C_word*)lf[44]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[197],lf[198],((C_word*)t0)[2],t1);}

/* k6091 in k6088 in a6085 in k6076 in a6073 in k6051 in a6048 in k6039 in k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6093,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6096,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 962  read */
t3=((C_word*)t0)[10];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[9]);}

/* k6094 in k6091 in k6088 in a6085 in k6076 in a6073 in k6051 in a6048 in k6039 in k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6096,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6101,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t3,tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_6101(t5,((C_word*)t0)[2],t1);}

/* doloop1228 in k6094 in k6091 in k6088 in a6085 in k6076 in a6073 in k6051 in a6048 in k6039 in k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_6101(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6101,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6111,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[2])){
/* eval.scm: 965  printer */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
t4=t3;
f_6111(2,t4,C_SCHEME_UNDEFINED);}}}

/* k6109 in doloop1228 in k6094 in k6091 in k6088 in a6085 in k6076 in a6073 in k6051 in a6048 in k6039 in k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6111,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6114,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6123,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6157,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 966  ##sys#call-with-values */
C_u_call_with_values(4,0,t2,t3,t4);}

/* a6156 in k6109 in doloop1228 in k6094 in k6091 in k6088 in a6085 in k6076 in a6073 in k6051 in a6048 in k6039 in k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6157(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_6157r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6157r(t0,t1,t2);}}

static void C_ccall f_6157r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
if(C_truep(((C_word*)t0)[4])){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6166,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_6166(t6,t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* loop1246 in a6156 in k6109 in doloop1228 in k6094 in k6091 in k6088 in a6085 in k6076 in a6073 in k6051 in a6048 in k6039 in k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_6166(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6166,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6179,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 975  write */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6177 in loop1246 in a6156 in k6109 in doloop1228 in k6094 in k6091 in k6088 in a6085 in k6076 in a6073 in k6051 in a6048 in k6039 in k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6179,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6182,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 976  newline */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k6180 in k6177 in loop1246 in a6156 in k6109 in doloop1228 in k6094 in k6091 in k6088 in a6085 in k6076 in a6073 in k6051 in a6048 in k6039 in k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6166(t3,((C_word*)t0)[2],t2);}

/* a6122 in k6109 in doloop1228 in k6094 in k6091 in k6088 in a6085 in k6076 in a6073 in k6051 in a6048 in k6039 in k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6123,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6130,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#start-timer */
t3=*((C_word*)lf[196]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* eval.scm: 970  evproc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}}

/* k6128 in a6122 in k6109 in doloop1228 in k6094 in k6091 in k6088 in a6085 in k6076 in a6073 in k6051 in a6048 in k6039 in k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6130,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6135,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6141,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a6140 in k6128 in a6122 in k6109 in doloop1228 in k6094 in k6091 in k6088 in a6085 in k6076 in a6073 in k6051 in a6048 in k6039 in k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6141(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_6141r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6141r(t0,t1,t2);}}

static void C_ccall f_6141r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6145,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6152,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#stop-timer */
t5=*((C_word*)lf[195]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k6150 in a6140 in k6128 in a6122 in k6109 in doloop1228 in k6094 in k6091 in k6088 in a6085 in k6076 in a6073 in k6051 in a6048 in k6039 in k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#display-times */
t2=*((C_word*)lf[194]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6143 in a6140 in k6128 in a6122 in k6109 in doloop1228 in k6094 in k6091 in k6088 in a6085 in k6076 in a6073 in k6051 in a6048 in k6039 in k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6134 in k6128 in a6122 in k6109 in doloop1228 in k6094 in k6091 in k6088 in a6085 in k6076 in a6073 in k6051 in a6048 in k6039 in k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6135,2,t0,t1);}
/* eval.scm: 969  evproc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k6112 in k6109 in doloop1228 in k6094 in k6091 in k6088 in a6085 in k6076 in a6073 in k6051 in a6048 in k6039 in k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6114,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6121,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 963  read */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6119 in k6112 in k6109 in doloop1228 in k6094 in k6091 in k6088 in a6085 in k6076 in a6073 in k6051 in a6048 in k6039 in k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_6101(t2,((C_word*)t0)[2],t1);}

/* a6082 in k6076 in a6073 in k6051 in a6048 in k6039 in k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6083,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* a6062 in k6051 in a6048 in k6039 in k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6063,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,*((C_word*)lf[193]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,*((C_word*)lf[174]+1));
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,*((C_word*)lf[175]+1));
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,*((C_word*)lf[173]+1));
t6=C_mutate((C_word*)lf[193]+1 /* (set! read-error-with-line-number ...) */,((C_word*)((C_word*)t0)[5])[1]);
t7=C_mutate((C_word*)lf[174]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[4])[1]);
t8=C_mutate((C_word*)lf[175]+1 /* (set! current-load-path ...) */,((C_word*)((C_word*)t0)[3])[1]);
t9=C_mutate((C_word*)lf[173]+1 /* (set! abort-load ...) */,((C_word*)((C_word*)t0)[2])[1]);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}

/* f_6054 in k6051 in a6048 in k6039 in k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6054,2,t0,t1);}
/* eval.scm: 954  abrt */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_FALSE);}

/* k6042 in k6039 in k6036 in k6030 in k6027 in body1116 in ##sys#load in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_6044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* has-sep? in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_5977(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5977,NULL,2,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5987,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_5987(t5,t4));}

/* loop in has-sep? in k5973 in k5892 in k5797 in k2514 in k2511 in k2478 */
static C_word C_fcall f_5987(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
if(C_truep((C_word)C_i_zerop(t1))){
return(C_SCHEME_FALSE);}
else{
t2=(C_word)C_subchar(((C_word*)t0)[2],t1);
if(C_truep((C_truep((C_word)C_eqp(t2,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t2,C_make_character(47)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
return(t1);}
else{
t3=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}}

/* set-dynamic-load-mode! in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_5902(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5902,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?t2:(C_word)C_a_i_list(&a,1,t2));
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_TRUE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5909,a[2]=t8,a[3]=t6,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5914,a[2]=t6,a[3]=t8,a[4]=t11,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_5914(t13,t9,t4);}

/* loop in set-dynamic-load-mode! in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_5914(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5914,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5927,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(t3,lf[180]);
if(C_truep(t5)){
t6=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t7=t4;
f_5927(2,t7,t6);}
else{
t6=(C_word)C_eqp(t3,lf[181]);
if(C_truep(t6)){
t7=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_FALSE);
t8=t4;
f_5927(2,t8,t7);}
else{
t7=(C_word)C_eqp(t3,lf[182]);
if(C_truep(t7)){
t8=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t9=t4;
f_5927(2,t9,t8);}
else{
t8=(C_word)C_eqp(t3,lf[183]);
if(C_truep(t8)){
t9=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t10=t4;
f_5927(2,t10,t9);}
else{
t9=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 888  ##sys#signal-hook */
t10=*((C_word*)lf[184]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t4,lf[178],lf[185],t9);}}}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k5925 in loop in set-dynamic-load-mode! in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_5927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 889  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5914(t3,((C_word*)t0)[2],t2);}

/* k5907 in set-dynamic-load-mode! in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_5909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 890  ##sys#set-dlopen-flags! */
t2=*((C_word*)lf[179]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* f_5896 in k5892 in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_5896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5896,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* ##sys#decompose-lambda-list in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_5812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5812,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5815,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5825,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_5825(t8,t1,t2,C_SCHEME_END_OF_LIST,C_fix(0));}

/* loop in ##sys#decompose-lambda-list in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_5825(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(9);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5825,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5839,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 857  reverse */
t7=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}
else{
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_symbolp(t2))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5858,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_a_i_cons(&a,2,t2,t3);
/* eval.scm: 859  reverse */
t8=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
if(C_truep((C_word)C_pairp(t2))){
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t2,C_fix(0));
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
t9=(C_word)C_u_fixnum_plus(t4,C_fix(1));
/* eval.scm: 861  loop */
t14=t1;
t15=t6;
t16=t8;
t17=t9;
t1=t14;
t2=t15;
t3=t16;
t4=t17;
goto loop;}
else{
/* eval.scm: 860  err */
t6=((C_word*)t0)[2];
f_5815(t6,t1);}}}
else{
/* eval.scm: 858  err */
t6=((C_word*)t0)[2];
f_5815(t6,t1);}}}

/* k5856 in loop in ##sys#decompose-lambda-list in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_5858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 859  k */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5837 in loop in ##sys#decompose-lambda-list in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_5839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 857  k */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* err in ##sys#decompose-lambda-list in k5797 in k2514 in k2511 in k2478 */
static void C_fcall f_5815(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5815,NULL,2,t0,t1);}
t2=C_set_block_item(lf[170] /* syntax-error-culprit */,0,C_SCHEME_FALSE);
/* eval.scm: 854  ##sys#syntax-error-hook */
t3=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[171],((C_word*)t0)[2]);}

/* eval in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_5802(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_5802r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5802r(t0,t1,t2,t3);}}

static void C_ccall f_5802r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5810,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 842  ##sys#eval-handler */
t5=*((C_word*)lf[167]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k5808 in eval in k5797 in k2514 in k2511 in k2478 */
static void C_ccall f_5810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_2872(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+32)){
C_save_and_reclaim((void*)tr5rv,(void*)f_2872r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_2872r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_2872r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a=C_alloc(32);
t6=(C_word)C_vemptyp(t5);
t7=(C_truep(t6)?C_SCHEME_FALSE:(C_word)C_slot(t5,C_fix(0)));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2878,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2917,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2932,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3028,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3034,tmp=(C_word)a,a+=2,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3085,a[2]=t18,a[3]=((C_word*)t0)[2],a[4]=t11,a[5]=t14,a[6]=t13,a[7]=t16,a[8]=((C_word*)t0)[3],a[9]=t12,tmp=(C_word)a,a+=10,tmp));
t20=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5551,a[2]=t16,tmp=(C_word)a,a+=3,tmp));
t21=(C_word)C_fixnum_greaterp(*((C_word*)lf[31]+1),C_fix(0));
/* eval.scm: 821  compile */
t22=((C_word*)t16)[1];
f_3085(t22,t1,t2,t3,C_SCHEME_FALSE,t21,t7,t4);}

/* compile-call in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_fcall f_5551(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5551,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5555,a[2]=t6,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t4,a[7]=t1,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t8=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 785  compile */
t9=((C_word*)((C_word*)t0)[2])[1];
f_3085(t9,t7,t8,t3,C_SCHEME_FALSE,t4,t5,t6);}

/* k5553 in compile-call in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5555,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5525,tmp=(C_word)a,a+=2,tmp);
t4=f_5525(t2,C_fix(0));
t5=((C_word*)t0)[8];
switch(t4){
case C_SCHEME_FALSE:
/* eval.scm: 790  ##sys#syntax-error-hook */
t6=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[7],lf[166],((C_word*)t0)[8]);
case C_fix(0):
t6=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5577,a[2]=t1,a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
case C_fix(1):
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5596,a[2]=t1,a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 794  compile */
t8=((C_word*)((C_word*)t0)[4])[1];
f_3085(t8,t6,t7,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);
case C_fix(2):
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5624,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t5,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 798  compile */
t8=((C_word*)((C_word*)t0)[4])[1];
f_3085(t8,t6,t7,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);
case C_fix(3):
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5659,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t5,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 803  compile */
t8=((C_word*)((C_word*)t0)[4])[1];
f_3085(t8,t6,t7,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);
case C_fix(4):
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5701,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t5,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 809  compile */
t8=((C_word*)((C_word*)t0)[4])[1];
f_3085(t8,t6,t7,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);
default:
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5744,a[2]=t1,a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5768,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 816  ##sys#map */
t8=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,t2);}}

/* a5767 in k5553 in compile-call in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5768(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5768,3,t0,t1,t2);}
/* eval.scm: 816  compile */
t3=((C_word*)((C_word*)t0)[6])[1];
f_3085(t3,t1,t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5742 in k5553 in compile-call in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5744,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5745,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));}

/* f_5745 in k5742 in k5553 in compile-call in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5745(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5745,3,t0,t1,t2);}
t3=((C_word*)t0)[6];
t4=((C_word*)t0)[5];
t5=(C_truep(t3)?(C_word)C_emit_eval_trace_info(((C_word*)t0)[4],t4,*((C_word*)lf[51]+1)):C_SCHEME_UNDEFINED);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5756,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k5754 */
static void C_ccall f_5756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5756,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5760,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5762,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 819  ##sys#map */
t4=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a5761 in k5754 */
static void C_ccall f_5762(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5762,3,t0,t1,t2);}
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,((C_word*)t0)[2]);}

/* k5758 in k5754 */
static void C_ccall f_5760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5699 in k5553 in compile-call in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5701,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5704,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 810  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3085(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(1)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[2]);}

/* k5702 in k5699 in k5553 in compile-call in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5704,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5707,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* eval.scm: 811  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3085(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(2)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[2]);}

/* k5705 in k5702 in k5699 in k5553 in compile-call in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5707,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5710,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 812  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3085(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(3)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[2]);}

/* k5708 in k5705 in k5702 in k5699 in k5553 in compile-call in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5710,2,t0,t1);}
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5711,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));}

/* f_5711 in k5708 in k5705 in k5702 in k5699 in k5553 in compile-call in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5711(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5711,3,t0,t1,t2);}
t3=((C_word*)t0)[9];
t4=((C_word*)t0)[8];
t5=(C_truep(t3)?(C_word)C_emit_eval_trace_info(((C_word*)t0)[7],t4,*((C_word*)lf[51]+1)):C_SCHEME_UNDEFINED);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5722,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k5720 */
static void C_ccall f_5722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5722,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5726,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k5724 in k5720 */
static void C_ccall f_5726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5726,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5730,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k5728 in k5724 in k5720 */
static void C_ccall f_5730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5730,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5734,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k5732 in k5728 in k5724 in k5720 */
static void C_ccall f_5734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5734,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5737,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5735 in k5732 in k5728 in k5724 in k5720 */
static void C_ccall f_5737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5657 in k5553 in compile-call in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5659,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5662,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 804  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3085(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(1)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[2]);}

/* k5660 in k5657 in k5553 in compile-call in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5662,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5665,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 805  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3085(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(2)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[2]);}

/* k5663 in k5660 in k5657 in k5553 in compile-call in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5665,2,t0,t1);}
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5666,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));}

/* f_5666 in k5663 in k5660 in k5657 in k5553 in compile-call in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5666(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5666,3,t0,t1,t2);}
t3=((C_word*)t0)[8];
t4=((C_word*)t0)[7];
t5=(C_truep(t3)?(C_word)C_emit_eval_trace_info(((C_word*)t0)[6],t4,*((C_word*)lf[51]+1)):C_SCHEME_UNDEFINED);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5677,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k5675 */
static void C_ccall f_5677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5677,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5681,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k5679 in k5675 */
static void C_ccall f_5681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5685,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k5683 in k5679 in k5675 */
static void C_ccall f_5685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5685,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5688,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5686 in k5683 in k5679 in k5675 */
static void C_ccall f_5688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5622 in k5553 in compile-call in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5624,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5627,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 799  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3085(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(1)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[2]);}

/* k5625 in k5622 in k5553 in compile-call in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5627,2,t0,t1);}
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5628,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));}

/* f_5628 in k5625 in k5622 in k5553 in compile-call in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5628(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5628,3,t0,t1,t2);}
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
t5=(C_truep(t3)?(C_word)C_emit_eval_trace_info(((C_word*)t0)[5],t4,*((C_word*)lf[51]+1)):C_SCHEME_UNDEFINED);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5639,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k5637 */
static void C_ccall f_5639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5639,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5643,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k5641 in k5637 */
static void C_ccall f_5643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5643,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5646,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5644 in k5641 in k5637 */
static void C_ccall f_5646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5594 in k5553 in compile-call in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5596,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5597,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));}

/* f_5597 in k5594 in k5553 in compile-call in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5597(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5597,3,t0,t1,t2);}
t3=((C_word*)t0)[6];
t4=((C_word*)t0)[5];
t5=(C_truep(t3)?(C_word)C_emit_eval_trace_info(((C_word*)t0)[4],t4,*((C_word*)lf[51]+1)):C_SCHEME_UNDEFINED);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5608,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k5606 */
static void C_ccall f_5608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5608,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5611,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5609 in k5606 */
static void C_ccall f_5611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_5577 in k5553 in compile-call in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5577(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5577,3,t0,t1,t2);}
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=(C_truep(t3)?(C_word)C_emit_eval_trace_info(((C_word*)t0)[3],t4,*((C_word*)lf[51]+1)):C_SCHEME_UNDEFINED);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5587,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 793  fn */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k5585 */
static void C_ccall f_5587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* loop in k5553 in compile-call in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static C_word C_fcall f_5525(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(t2);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_fcall f_3085(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3085,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3092,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t4,a[8]=((C_word*)t0)[7],a[9]=t5,a[10]=t6,a[11]=((C_word*)t0)[8],a[12]=t7,a[13]=t3,a[14]=((C_word*)t0)[9],a[15]=t2,a[16]=t1,tmp=(C_word)a,a+=17,tmp);
/* eval.scm: 293  keyword? */
t9=*((C_word*)lf[165]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}

/* k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3092,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[16];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3093,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp));}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[15]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3105,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[14],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3111,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[16],t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3212,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[14],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[9],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
/* eval.scm: 319  ##sys#number? */
t3=*((C_word*)lf[164]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[15]);}}}

/* k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3212,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[15];
switch(t2){
case C_fix(-1):
t3=((C_word*)t0)[14];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3219,tmp=(C_word)a,a+=2,tmp));
case C_fix(0):
t3=((C_word*)t0)[14];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3227,tmp=(C_word)a,a+=2,tmp));
case C_fix(1):
t3=((C_word*)t0)[14];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3235,tmp=(C_word)a,a+=2,tmp));
default:
t3=(C_word)C_eqp(t2,C_fix(2));
t4=((C_word*)t0)[14];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3243,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3245,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp)));}}
else{
if(C_truep((C_word)C_booleanp(((C_word*)t0)[15]))){
t2=((C_word*)t0)[14];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)t0)[15])?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3256,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3258,tmp=(C_word)a,a+=2,tmp)));}
else{
t2=(C_word)C_charp(((C_word*)t0)[15]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3268,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
if(C_truep(t2)){
t4=t3;
f_3268(t4,t2);}
else{
t4=(C_word)C_eofp(((C_word*)t0)[15]);
t5=t3;
f_3268(t5,(C_truep(t4)?t4:(C_word)C_i_stringp(((C_word*)t0)[15])));}}}}

/* k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_fcall f_3268(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3268,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3269,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[14]))){
t2=(C_word)C_slot(((C_word*)t0)[14],C_fix(0));
if(C_truep((C_word)C_i_symbolp(t2))){
t3=((C_word*)t0)[13];
t4=((C_word*)t0)[14];
t5=((C_word*)t0)[12];
t6=(C_truep(t3)?(C_word)C_emit_syntax_trace_info(t4,t5,*((C_word*)lf[51]+1)):C_SCHEME_UNDEFINED);
t7=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3291,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* eval.scm: 337  ##sys#expand */
t8=*((C_word*)lf[162]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,((C_word*)t0)[14],((C_word*)t0)[11],C_SCHEME_FALSE);}
else{
t3=((C_word*)t0)[13];
t4=((C_word*)t0)[14];
t5=((C_word*)t0)[12];
t6=(C_truep(t3)?(C_word)C_emit_syntax_trace_info(t4,t5,*((C_word*)lf[51]+1)):C_SCHEME_UNDEFINED);
/* eval.scm: 762  compile-call */
t7=((C_word*)((C_word*)t0)[2])[1];
f_5551(t7,((C_word*)t0)[15],((C_word*)t0)[14],((C_word*)t0)[9],((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[11]);}}
else{
/* eval.scm: 334  ##sys#syntax-error-hook */
t2=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[15],lf[163],((C_word*)t0)[14]);}}}

/* k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3291,2,t0,t1);}
t2=*((C_word*)lf[38]+1);
t3=(C_word)C_eqp(t1,((C_word*)t0)[15]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3306,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
t5=(C_word)C_slot(((C_word*)t0)[15],C_fix(0));
/* eval.scm: 341  rename */
t6=((C_word*)t0)[4];
f_2917(t6,t4,t5,((C_word*)t0)[13]);}
else{
/* eval.scm: 340  compile */
t4=((C_word*)((C_word*)t0)[12])[1];
f_3085(t4,((C_word*)t0)[14],t1,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[13]);}}

/* k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3306,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[52]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3315,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 347  ##sys#check-syntax */
t4=*((C_word*)lf[54]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,t3,lf[52],((C_word*)t0)[14],lf[55],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t3=(C_word)C_eqp(t1,lf[56]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(t1,lf[57]));
if(C_truep(t4)){
t5=(C_word)C_u_i_cadr(((C_word*)t0)[14]);
t6=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3393,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t5=(C_word)C_eqp(t1,lf[58]);
if(C_truep(t5)){
t6=(C_word)C_u_i_cadr(((C_word*)t0)[14]);
if(C_truep(*((C_word*)lf[22]+1))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3409,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 366  ##sys#hash-table-location */
t8=*((C_word*)lf[21]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,*((C_word*)lf[22]+1),t6,C_SCHEME_TRUE);}
else{
t7=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3415,a[2]=t6,tmp=(C_word)a,a+=3,tmp));}}
else{
t6=(C_word)C_eqp(t1,lf[59]);
if(C_truep(t6)){
t7=(C_word)C_u_i_cadr(((C_word*)t0)[14]);
/* eval.scm: 371  compile */
t8=((C_word*)((C_word*)t0)[12])[1];
f_3085(t8,((C_word*)t0)[15],t7,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[13]);}
else{
t7=(C_word)C_eqp(t1,lf[60]);
if(C_truep(t7)){
t8=(C_word)C_u_i_cadr(((C_word*)t0)[14]);
/* eval.scm: 374  compile */
t9=((C_word*)((C_word*)t0)[12])[1];
f_3085(t9,((C_word*)t0)[15],t8,((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[13]);}
else{
t8=(C_word)C_eqp(t1,lf[61]);
if(C_truep(t8)){
t9=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3449,tmp=(C_word)a,a+=2,tmp));}
else{
t9=(C_word)C_eqp(t1,lf[62]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3459,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[14],a[8]=((C_word*)t0)[15],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 379  ##sys#check-syntax */
t11=*((C_word*)lf[54]+1);
((C_proc7)(void*)(*((C_word*)t11+1)))(7,t11,t10,lf[62],((C_word*)t0)[14],lf[64],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t10=(C_word)C_eqp(t1,lf[65]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t1,lf[66]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3519,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 388  ##sys#check-syntax */
t13=*((C_word*)lf[54]+1);
((C_proc7)(void*)(*((C_word*)t13+1)))(7,t13,t12,lf[65],((C_word*)t0)[14],lf[69],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t12=(C_word)C_eqp(t1,lf[70]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t1,lf[71]));
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3631,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[14],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 404  ##sys#check-syntax */
t15=*((C_word*)lf[54]+1);
((C_proc7)(void*)(*((C_word*)t15+1)))(7,t15,t14,lf[70],((C_word*)t0)[14],lf[74],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t14=(C_word)C_eqp(t1,lf[75]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(t1,lf[76]));
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3743,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 428  ##sys#check-syntax */
t17=*((C_word*)lf[54]+1);
((C_proc7)(void*)(*((C_word*)t17+1)))(7,t17,t16,lf[75],((C_word*)t0)[14],lf[84],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t16=(C_word)C_eqp(t1,lf[85]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(t1,lf[86]));
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4088,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[14],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 480  ##sys#check-syntax */
t19=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t19+1)))(5,t19,t18,lf[85],((C_word*)t0)[14],lf[88]);}
else{
t18=(C_word)C_eqp(t1,lf[89]);
t19=(C_truep(t18)?t18:(C_word)C_eqp(t1,lf[90]));
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4177,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 495  ##sys#check-syntax */
t21=*((C_word*)lf[54]+1);
((C_proc7)(void*)(*((C_word*)t21+1)))(7,t21,t20,lf[89],((C_word*)t0)[14],lf[98],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t20=(C_word)C_eqp(t1,lf[99]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4541,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[15],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 590  ##sys#check-syntax */
t22=*((C_word*)lf[54]+1);
((C_proc7)(void*)(*((C_word*)t22+1)))(7,t22,t21,lf[99],((C_word*)t0)[14],lf[101],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t21=(C_word)C_eqp(t1,lf[102]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4594,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[15],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 605  ##sys#check-syntax */
t23=*((C_word*)lf[54]+1);
((C_proc7)(void*)(*((C_word*)t23+1)))(7,t23,t22,lf[102],((C_word*)t0)[14],lf[103],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t22=(C_word)C_eqp(t1,lf[104]);
t23=(C_truep(t22)?t22:(C_word)C_eqp(t1,lf[105]));
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4678,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[15],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t25=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4765,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],a[4]=t24,tmp=(C_word)a,a+=5,tmp);
t26=(C_word)C_slot(((C_word*)t0)[14],C_fix(1));
if(C_truep((C_word)C_i_pairp(t26))){
t27=(C_word)C_u_i_cadr(((C_word*)t0)[14]);
t28=t25;
f_4765(t28,(C_word)C_i_pairp(t27));}
else{
t27=t25;
f_4765(t27,C_SCHEME_FALSE);}}
else{
t24=(C_word)C_eqp(t1,lf[113]);
if(C_truep(t24)){
/* eval.scm: 644  compile */
t25=((C_word*)((C_word*)t0)[12])[1];
f_3085(t25,((C_word*)t0)[15],lf[114],((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[13]);}
else{
t25=(C_word)C_eqp(t1,lf[115]);
if(C_truep(t25)){
t26=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4801,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
t27=(C_word)C_u_i_cddr(((C_word*)t0)[14]);
/* eval.scm: 648  ##sys#canonicalize-body */
t28=*((C_word*)lf[79]+1);
((C_proc5)(void*)(*((C_word*)t28+1)))(5,t28,t26,t27,((C_word*)t0)[13],C_SCHEME_FALSE);}
else{
t26=(C_word)C_eqp(t1,lf[116]);
if(C_truep(t26)){
t27=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4814,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[14],tmp=(C_word)a,a+=8,tmp);
t28=(C_word)C_u_i_cadr(((C_word*)t0)[14]);
/* eval.scm: 652  ##sys#strip-syntax */
t29=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t29+1)))(3,t29,t27,t28);}
else{
t27=(C_word)C_eqp(t1,lf[123]);
if(C_truep(t27)){
t28=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5037,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 697  rename */
t29=((C_word*)t0)[4];
f_2917(t29,t28,lf[89],((C_word*)t0)[13]);}
else{
t28=(C_word)C_eqp(t1,lf[124]);
if(C_truep(t28)){
t29=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5066,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 700  rename */
t30=((C_word*)t0)[4];
f_2917(t30,t29,lf[89],((C_word*)t0)[13]);}
else{
t29=(C_word)C_eqp(t1,lf[125]);
if(C_truep(t29)){
t30=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5083,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
t31=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5122,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t32=(C_word)C_slot(((C_word*)t0)[14],C_fix(1));
/* map */
t33=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t33+1)))(4,t33,t30,t31,t32);}
else{
t30=(C_word)C_eqp(t1,lf[129]);
if(C_truep(t30)){
t31=(C_word)C_u_i_caddr(((C_word*)t0)[14]);
t32=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5146,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
t33=(C_word)C_u_i_cadr(((C_word*)t0)[14]);
t34=C_SCHEME_UNDEFINED;
t35=(*a=C_VECTOR_TYPE|1,a[1]=t34,tmp=(C_word)a,a+=2,tmp);
t36=C_set_block_item(t35,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5152,a[2]=t35,a[3]=t31,tmp=(C_word)a,a+=4,tmp));
t37=((C_word*)t35)[1];
f_5152(t37,t32,t33);}
else{
t31=(C_word)C_eqp(t1,lf[132]);
t32=(C_truep(t31)?t31:(C_word)C_eqp(t1,lf[133]));
if(C_truep(t32)){
t33=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5206,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
t34=(C_word)C_u_i_cadr(((C_word*)t0)[14]);
/* eval.scm: 726  eval/meta */
f_3034(t33,t34);}
else{
t33=(C_word)C_eqp(t1,lf[135]);
if(C_truep(t33)){
t34=(C_word)C_u_i_cadr(((C_word*)t0)[14]);
/* eval.scm: 730  compile */
t35=((C_word*)((C_word*)t0)[12])[1];
f_3085(t35,((C_word*)t0)[15],t34,((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[13]);}
else{
t34=(C_word)C_eqp(t1,lf[136]);
t35=(C_truep(t34)?t34:(C_word)C_eqp(t1,lf[137]));
if(C_truep(t35)){
/* eval.scm: 733  compile */
t36=((C_word*)((C_word*)t0)[12])[1];
f_3085(t36,((C_word*)t0)[15],lf[138],((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[13]);}
else{
t36=(C_word)C_eqp(t1,lf[139]);
if(C_truep(t36)){
t37=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5247,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_u_i_memq(lf[141],*((C_word*)lf[142]+1)))){
t38=(C_word)C_slot(((C_word*)t0)[14],C_fix(1));
t39=C_SCHEME_UNDEFINED;
t40=(*a=C_VECTOR_TYPE|1,a[1]=t39,tmp=(C_word)a,a+=2,tmp);
t41=C_set_block_item(t40,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5262,a[2]=((C_word*)t0)[13],a[3]=t40,tmp=(C_word)a,a+=4,tmp));
t42=((C_word*)t40)[1];
f_5262(t42,t37,t38);}
else{
/* eval.scm: 738  ##sys#warn */
t38=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t38+1)))(4,t38,t37,lf[145],((C_word*)t0)[14]);}}
else{
t37=(C_word)C_eqp(t1,lf[146]);
t38=(C_truep(t37)?t37:(C_word)C_eqp(t1,lf[147]));
if(C_truep(t38)){
t39=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5305,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 742  rename */
t40=((C_word*)t0)[4];
f_2917(t40,t39,lf[148],((C_word*)t0)[13]);}
else{
t39=(C_word)C_eqp(t1,lf[49]);
t40=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5322,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[2],a[7]=t1,a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t39)){
t41=t40;
f_5322(t41,t39);}
else{
t41=(C_word)C_eqp(t1,lf[153]);
if(C_truep(t41)){
t42=t40;
f_5322(t42,t41);}
else{
t42=(C_word)C_eqp(t1,lf[154]);
if(C_truep(t42)){
t43=t40;
f_5322(t43,t42);}
else{
t43=(C_word)C_eqp(t1,lf[155]);
if(C_truep(t43)){
t44=t40;
f_5322(t44,t43);}
else{
t44=(C_word)C_eqp(t1,lf[156]);
if(C_truep(t44)){
t45=t40;
f_5322(t45,t44);}
else{
t45=(C_word)C_eqp(t1,lf[157]);
if(C_truep(t45)){
t46=t40;
f_5322(t46,t45);}
else{
t46=(C_word)C_eqp(t1,lf[158]);
if(C_truep(t46)){
t47=t40;
f_5322(t47,t46);}
else{
t47=(C_word)C_eqp(t1,lf[159]);
if(C_truep(t47)){
t48=t40;
f_5322(t48,t47);}
else{
t48=(C_word)C_eqp(t1,lf[160]);
t49=t40;
f_5322(t49,(C_truep(t48)?t48:(C_word)C_eqp(t1,lf[161])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k5320 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_fcall f_5322(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
/* eval.scm: 749  ##sys#syntax-error-hook */
t2=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[9],lf[149],((C_word*)t0)[8]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[150]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
/* eval.scm: 752  compile-call */
t4=((C_word*)((C_word*)t0)[6])[1];
f_5551(t4,((C_word*)t0)[9],t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[151]);
if(C_truep(t3)){
/* eval.scm: 756  ##sys#syntax-error-hook */
t4=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[9],lf[152],((C_word*)t0)[8]);}
else{
/* eval.scm: 758  compile-call */
t4=((C_word*)((C_word*)t0)[6])[1];
f_5551(t4,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}}}

/* k5303 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5305,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5309,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* ##sys#append */
t4=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k5307 in k5303 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5309,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* eval.scm: 742  compile */
t3=((C_word*)((C_word*)t0)[7])[1];
f_3085(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop858 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_fcall f_5262(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5262,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5275,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 737  ##compiler#process-declaration */
t5=*((C_word*)lf[143]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k5273 in loop858 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5262(t3,((C_word*)t0)[2],t2);}

/* k5245 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 739  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3085(t2,((C_word*)t0)[6],lf[140],((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5204 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 727  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3085(t2,((C_word*)t0)[6],lf[134],((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_fcall f_5152(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5152,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[130]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5164,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5174,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}}

/* a5173 in loop in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5174(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5174,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5190,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 722  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_5152(t6,t4,t5);}

/* k5188 in a5173 in loop in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5190,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[66],t3));}

/* a5163 in loop in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5164,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[3]);
/* eval.scm: 721  ##sys#do-the-right-thing */
t3=*((C_word*)lf[131]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,t2,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k5144 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 716  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3085(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5121 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5122(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5122,3,t0,t1,t2);}
/* eval.scm: 704  eval/meta */
f_3034(t1,t2);}

/* k5081 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5083,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5086,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_apply(4,0,t2,*((C_word*)lf[127]+1),t1);}

/* k5084 in k5081 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5089,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 707  ##sys#lookup-runtime-requirements */
t3=*((C_word*)lf[128]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5087 in k5084 in k5081 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5089,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5096,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_nullp(t1))){
t3=t2;
f_5096(t3,lf[126]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5106,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5110,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5112,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t1);}}

/* a5111 in k5087 in k5084 in k5081 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5112(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5112,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[52],t3));}

/* k5108 in k5087 in k5084 in k5081 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k5104 in k5087 in k5084 in k5081 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5106,2,t0,t1);}
t2=((C_word*)t0)[2];
f_5096(t2,(C_word)C_a_i_cons(&a,2,lf[127],t1));}

/* k5094 in k5087 in k5084 in k5081 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_fcall f_5096(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 708  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3085(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5064 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5066,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5070,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[8]);
/* ##sys#append */
t4=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k5068 in k5064 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5070,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
/* eval.scm: 700  compile */
t4=((C_word*)((C_word*)t0)[7])[1];
f_3085(t4,((C_word*)t0)[6],t2,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5035 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5037,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5041,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* ##sys#append */
t4=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k5039 in k5035 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5041,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* eval.scm: 697  compile */
t3=((C_word*)((C_word*)t0)[7])[1];
f_3085(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4812 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4814,2,t0,t1);}
t2=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
t3=(C_word)C_eqp(C_SCHEME_TRUE,t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4820,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t5=t4;
f_4820(2,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4956,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5008,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
/* eval.scm: 667  ##sys#strip-syntax */
t8=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}}

/* k5006 in k4812 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_5008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4955 in k4812 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4956(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4956,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4969,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4980,tmp=(C_word)a,a+=2,tmp);
t5=t3;
f_4969(t5,f_4980(t2));}
else{
t4=t3;
f_4969(t4,C_SCHEME_FALSE);}}}

/* loop in a4955 in k4812 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static C_word C_fcall f_4980(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
t2=(C_word)C_i_nullp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_word)C_u_i_car(t1);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_slot(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* k4967 in a4955 in k4812 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_fcall f_4969(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
/* eval.scm: 664  ##sys#syntax-error-hook */
t2=*((C_word*)lf[46]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[120],lf[122],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4818 in k4812 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4820,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4823,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4948,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 668  ##sys#current-module */
t4=*((C_word*)lf[39]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k4946 in k4818 in k4812 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* eval.scm: 669  ##sys#syntax-error-hook */
t2=*((C_word*)lf[46]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[120],lf[121],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_4823(2,t2,C_SCHEME_UNDEFINED);}}

/* k4821 in k4818 in k4812 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4823,2,t0,t1);}
t2=*((C_word*)lf[39]+1);
t3=*((C_word*)lf[108]+1);
t4=*((C_word*)lf[40]+1);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4826,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t2,a[9]=t3,a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 671  ##sys#register-module */
t6=*((C_word*)lf[119]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4824 in k4821 in k4818 in k4812 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4826,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=*((C_word*)lf[117]+1);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4827,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=t7,a[6]=t5,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4854,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* ##sys#dynamic-wind */
t10=*((C_word*)lf[42]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,((C_word*)t0)[2],t8,t9,t8);}

/* a4853 in k4824 in k4821 in k4818 in k4812 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4854,2,t0,t1);}
t2=(C_word)C_u_i_cdddr(((C_word*)t0)[6]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_4864(t6,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in a4853 in k4824 in k4821 in k4818 in k4812 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_fcall f_4864(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4864,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4874,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 676  reverse */
t5=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4937,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_u_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4945,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t5,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 693  ##sys#current-environment */
t8=*((C_word*)lf[108]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* k4943 in loop in a4853 in k4824 in k4821 in k4818 in k4812 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 690  compile */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3085(t2,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_END_OF_LIST,C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4935 in loop in a4853 in k4824 in k4821 in k4818 in k4812 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4937,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* eval.scm: 688  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4864(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4872 in loop in a4853 in k4824 in k4821 in k4818 in k4812 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4874,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4877,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4922,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 677  ##sys#current-module */
t4=*((C_word*)lf[39]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k4920 in k4872 in loop in a4853 in k4824 in k4821 in k4818 in k4812 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 677  ##sys#finalize-module */
t2=*((C_word*)lf[118]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4875 in k4872 in loop in a4853 in k4824 in k4821 in k4818 in k4812 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4877,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4878,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp));}

/* f_4878 in k4875 in k4872 in loop in a4853 in k4824 in k4821 in k4818 in k4812 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4878(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4878,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4884,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4884(t6,t1,((C_word*)t0)[2]);}

/* loop2 */
static void C_fcall f_4884(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4884,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,*((C_word*)lf[38]+1));}
else{
t3=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4906,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
t6=t5;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[2]);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=t4;
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,((C_word*)t0)[2]);}}}

/* k4904 in loop2 */
static void C_ccall f_4906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 685  loop2 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4884(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* swap757 in k4824 in k4821 in k4818 in k4812 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4827,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4831,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* g760761772 */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4829 in swap757 in k4824 in k4821 in k4818 in k4812 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4834,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* g760761772 */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[8])[1]);}

/* k4832 in k4829 in swap757 in k4824 in k4821 in k4818 in k4812 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4834,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4838,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* g762763773 */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k4836 in k4832 in k4829 in swap757 in k4824 in k4821 in k4818 in k4812 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4838,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4841,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* g762763773 */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[6])[1]);}

/* k4839 in k4836 in k4832 in k4829 in swap757 in k4824 in k4821 in k4818 in k4812 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4841,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4845,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g764765774 */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k4843 in k4839 in k4836 in k4832 in k4829 in swap757 in k4824 in k4821 in k4818 in k4812 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4848,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g764765774 */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k4846 in k4843 in k4839 in k4836 in k4832 in k4829 in swap757 in k4824 in k4821 in k4818 in k4812 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4799 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 647  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3085(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4763 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_fcall f_4765(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?lf[111]:lf[112]);
/* eval.scm: 623  ##sys#check-syntax */
t3=*((C_word*)lf[54]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,((C_word*)t0)[4],lf[104],((C_word*)t0)[3],t2,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k4676 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4681,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_pairp(t3))){
/* eval.scm: 629  caadr */
t4=*((C_word*)lf[110]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,((C_word*)t0)[2]);}
else{
t4=t2;
f_4681(2,t4,(C_word)C_u_i_cadr(((C_word*)t0)[2]));}}

/* k4679 in k4676 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4684,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4722,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 631  rename */
t5=((C_word*)t0)[3];
f_2917(t5,t4,lf[89],((C_word*)t0)[5]);}
else{
t4=t2;
f_4684(t4,(C_word)C_u_i_caddr(((C_word*)t0)[2]));}}

/* k4720 in k4679 in k4676 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4722,2,t0,t1);}
t2=(C_word)C_u_i_cdadr(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4734,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
/* ##sys#append */
t5=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k4732 in k4720 in k4679 in k4676 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4734,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_4684(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k4682 in k4679 in k4676 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_fcall f_4684(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4684,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4687,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 633  rename */
t3=((C_word*)t0)[3];
f_2917(t3,t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k4685 in k4682 in k4679 in k4676 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4687,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4690,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4712,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 635  ##sys#current-module */
t4=*((C_word*)lf[39]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k4710 in k4685 in k4682 in k4679 in k4676 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 634  ##sys#register-syntax-export */
t2=*((C_word*)lf[109]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4688 in k4685 in k4682 in k4679 in k4676 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4693,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4700,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 639  ##sys#current-environment */
t4=*((C_word*)lf[108]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k4698 in k4688 in k4685 in k4682 in k4679 in k4676 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4700,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4704,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4708,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 640  eval/meta */
f_3034(t3,((C_word*)t0)[2]);}

/* k4706 in k4698 in k4688 in k4685 in k4682 in k4679 in k4676 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 640  ##sys#er-transformer */
t2=*((C_word*)lf[100]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4702 in k4698 in k4688 in k4685 in k4682 in k4679 in k4676 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 637  ##sys#extend-macro-environment */
t2=*((C_word*)lf[107]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4691 in k4688 in k4685 in k4682 in k4679 in k4676 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 641  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3085(t2,((C_word*)t0)[6],lf[106],((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4592 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4594,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4597,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4642,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
/* map */
t5=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a4641 in k4592 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4642(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4642,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4654,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4658,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_u_i_cadr(t2);
/* eval.scm: 611  eval/meta */
f_3034(t5,t6);}

/* k4656 in a4641 in k4592 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 610  ##sys#er-transformer */
t2=*((C_word*)lf[100]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4652 in a4641 in k4592 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4654,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[2],C_SCHEME_FALSE,t1));}

/* k4595 in k4592 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4597,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4600,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 613  append */
t3=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k4598 in k4595 in k4592 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4600,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4616,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=f_4616(t2,((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4610,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_u_i_cddr(((C_word*)t0)[2]);
/* eval.scm: 619  ##sys#canonicalize-body */
t6=*((C_word*)lf[79]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,t5,t1,C_SCHEME_FALSE);}

/* k4608 in k4598 in k4595 in k4592 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 618  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3085(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop700 in k4598 in k4595 in k4592 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static C_word C_fcall f_4616(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_i_setslot(t3,C_fix(0),((C_word*)t0)[2]);
t5=(C_word)C_slot(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}
else{
return(C_SCHEME_UNDEFINED);}}

/* k4539 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4541,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4544,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4559,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4561,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
/* map */
t6=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a4560 in k4539 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4561(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4561,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4573,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4577,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_u_i_cadr(t2);
/* eval.scm: 597  eval/meta */
f_3034(t5,t6);}

/* k4575 in a4560 in k4539 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 596  ##sys#er-transformer */
t2=*((C_word*)lf[100]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4571 in a4560 in k4539 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4573,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k4557 in k4539 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 591  append */
t2=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4542 in k4539 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4544,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4551,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[2]);
/* eval.scm: 601  ##sys#canonicalize-body */
t4=*((C_word*)lf[79]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,t1,C_SCHEME_FALSE);}

/* k4549 in k4542 in k4539 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 600  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3085(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4175 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4177,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_u_i_cddr(((C_word*)t0)[8]);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t0)[7];
t9=(C_truep(t8)?t8:lf[91]);
t10=(C_word)C_a_i_cons(&a,2,t9,((C_word*)t4)[1]);
t11=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4189,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[7],a[8]=t10,a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],tmp=(C_word)a,a+=11,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4514,a[2]=t11,a[3]=((C_word*)t0)[3],a[4]=t7,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 499  ##sys#extended-lambda-list? */
t13=*((C_word*)lf[97]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,((C_word*)t4)[1]);}

/* k4512 in k4175 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4514,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4519,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4525,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
f_4189(2,t2,C_SCHEME_UNDEFINED);}}

/* a4524 in k4512 in k4175 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4525(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4525,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a4518 in k4512 in k4175 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4519,2,t0,t1);}
/* eval.scm: 502  ##sys#expand-extended-lambda-list */
t2=*((C_word*)lf[96]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],*((C_word*)lf[46]+1),((C_word*)t0)[2]);}

/* k4187 in k4175 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4189,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4194,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 504  ##sys#decompose-lambda-list */
t3=*((C_word*)lf[95]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* a4193 in k4187 in k4175 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4194(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4194,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4198,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t4,a[10]=t1,a[11]=t3,a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
/* map */
t6=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,*((C_word*)lf[83]+1),t2);}

/* k4196 in a4193 in k4187 in k4175 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4198,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4201,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4511,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 508  map */
t4=*((C_word*)lf[81]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,*((C_word*)lf[82]+1),((C_word*)t0)[2],t1);}

/* k4509 in k4196 in a4193 in k4187 in k4175 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 508  append */
t2=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4199 in k4196 in a4193 in k4187 in k4175 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4201,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4207,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4503,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 512  ##sys#canonicalize-body */
t5=*((C_word*)lf[79]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)((C_word*)t0)[2])[1],t1,C_SCHEME_FALSE);}

/* k4501 in k4199 in k4196 in a4193 in k4187 in k4175 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[6];
t3=(C_truep(t2)?t2:((C_word*)t0)[5]);
/* eval.scm: 511  ##sys#compile-to-closure */
t4=*((C_word*)lf[35]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k4205 in k4199 in k4196 in a4193 in k4187 in k4175 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4207,2,t0,t1);}
t2=((C_word*)t0)[8];
switch(t2){
case C_fix(0):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4217,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4236,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)));
case C_fix(1):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4260,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4279,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)));
case C_fix(2):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4307,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4326,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)));
case C_fix(3):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4354,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4373,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)));
default:
t3=(C_word)C_eqp(t2,C_fix(4));
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4401,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4420,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)):(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4442,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=t1,tmp=(C_word)a,a+=8,tmp):(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4465,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp))));}}

/* f_4465 in k4205 in k4199 in k4196 in a4193 in k4187 in k4175 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4465(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4465,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4471,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 581  decorate */
f_3028(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4470 */
static void C_ccall f_4471(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_4471r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4471r(t0,t1,t2);}}

static void C_ccall f_4471r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t3=(C_word)C_i_length(t2);
t4=(C_word)C_eqp(t3,((C_word*)t0)[4]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4495,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_apply(4,0,t5,*((C_word*)lf[92]+1),t2);}
else{
/* eval.scm: 585  ##sys#error */
t5=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[94],((C_word*)t0)[4],t3);}}

/* k4493 in a4470 */
static void C_ccall f_4495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4495,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_4442 in k4205 in k4199 in k4196 in a4193 in k4187 in k4175 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4442(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4442,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4448,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 574  decorate */
f_3028(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4447 */
static void C_ccall f_4448(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr2r,(void*)f_4448r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4448r(t0,t1,t2);}}

static void C_ccall f_4448r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(14);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4460,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4464,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
if(C_truep((C_word)C_i_nullp(t2))){
t6=t4;
f_4464(2,t6,(C_word)C_a_i_list(&a,1,t2));}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5479,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_5479(t9,t4,t5,C_fix(0),t2,C_SCHEME_FALSE);}}

/* doloop932 in a4447 */
static void C_fcall f_5479(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5479,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t6)){
t7=(C_word)C_a_i_list(&a,1,t4);
t8=(C_word)C_i_setslot(t5,C_fix(1),t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,((C_word*)t0)[3]);}
else{
t7=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t8=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5508,a[2]=t4,a[3]=t8,a[4]=t7,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t10=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4);
if(C_truep(t10)){
/* eval.scm: 771  ##sys#error */
t11=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t9,lf[93],t2,t3);}
else{
t11=t9;
f_5508(2,t11,(C_word)C_slot(t4,C_fix(1)));}}}

/* k5506 in doloop932 in a4447 */
static void C_ccall f_5508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[6])[1];
f_5479(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4462 in a4447 */
static void C_ccall f_4464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[92]+1),t1);}

/* k4458 in a4447 */
static void C_ccall f_4460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4460,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_4420 in k4205 in k4199 in k4196 in a4193 in k4187 in k4175 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4420(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4420,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4426,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 567  decorate */
f_3028(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4425 */
static void C_ccall f_4426(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4426,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4438,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 569  ##sys#vector */
t7=*((C_word*)lf[92]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t2,t3,t4,t5);}

/* k4436 in a4425 */
static void C_ccall f_4438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4438,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_4401 in k4205 in k4199 in k4196 in a4193 in k4187 in k4175 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4401(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4401,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4407,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 562  decorate */
f_3028(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4406 */
static void C_ccall f_4407(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr6r,(void*)f_4407r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_4407r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_4407r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(9);
t7=(C_word)C_a_i_vector(&a,5,t2,t3,t4,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,t7,((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t1,t8);}

/* f_4373 in k4205 in k4199 in k4196 in a4193 in k4187 in k4175 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4373(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4373,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4379,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 556  decorate */
f_3028(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4378 */
static void C_ccall f_4379(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4379,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_vector(&a,3,t2,t3,t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t6);}

/* f_4354 in k4205 in k4199 in k4196 in a4193 in k4187 in k4175 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4354(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4354,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4360,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 551  decorate */
f_3028(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4359 */
static void C_ccall f_4360(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_4360r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_4360r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_4360r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(8);
t6=(C_word)C_a_i_vector(&a,4,t2,t3,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[3]);
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t1,t7);}

/* f_4326 in k4205 in k4199 in k4196 in a4193 in k4187 in k4175 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4326(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4326,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4332,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 545  decorate */
f_3028(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4331 */
static void C_ccall f_4332(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4332,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_vector(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t5);}

/* f_4307 in k4205 in k4199 in k4196 in a4193 in k4187 in k4175 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4307(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4307,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4313,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 540  decorate */
f_3028(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4312 */
static void C_ccall f_4313(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_4313r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4313r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4313r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t5=(C_word)C_a_i_vector(&a,3,t2,t3,t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t6);}

/* f_4279 in k4205 in k4199 in k4196 in a4193 in k4187 in k4175 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4279(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4279,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4285,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 534  decorate */
f_3028(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4284 */
static void C_ccall f_4285(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4285,3,t0,t1,t2);}
t3=(C_word)C_a_i_vector(&a,1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}

/* f_4260 in k4205 in k4199 in k4196 in a4193 in k4187 in k4175 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4260(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4260,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4266,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 529  decorate */
f_3028(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4265 */
static void C_ccall f_4266(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_4266r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4266r(t0,t1,t2,t3);}}

static void C_ccall f_4266r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t4=(C_word)C_a_i_vector(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t5);}

/* f_4236 in k4205 in k4199 in k4196 in a4193 in k4187 in k4175 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4236(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4236,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4242,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 524  decorate */
f_3028(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4241 */
static void C_ccall f_4242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4242,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* f_4217 in k4205 in k4199 in k4196 in a4193 in k4187 in k4175 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4217(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4217,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4223,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 519  decorate */
f_3028(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4222 */
static void C_ccall f_4223(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_4223r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4223r(t0,t1,t2);}}

static void C_ccall f_4223r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(C_word)C_a_i_vector(&a,1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}

/* k4086 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4088,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4109,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4157,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 485  ##sys#map */
t6=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a4156 in k4086 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4157(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4157,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t3,lf[87]));}

/* k4107 in k4086 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4109,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4113,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4117,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4135,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 488  ##sys#map */
t5=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a4134 in k4107 in k4086 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4135(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4135,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_u_i_cadr(t2);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[71],t6));}

/* k4115 in k4107 in k4086 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4117,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4133,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t3=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4131 in k4115 in k4107 in k4086 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4133,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[76],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t5=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[3],((C_word*)t0)[2],t4);}

/* k4111 in k4107 in k4086 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4113,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[76],t2);
/* eval.scm: 483  compile */
t4=((C_word*)((C_word*)t0)[8])[1];
f_3085(t4,((C_word*)t0)[7],t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3741 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3743,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t3=(C_word)C_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3752,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=t3,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4072,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a4071 in k3741 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4072(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4072,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_car(t2));}

/* k3750 in k3741 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3752,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3755,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* map */
t3=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[83]+1),t1);}

/* k3753 in k3750 in k3741 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3755,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3761,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4070,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 434  map */
t5=*((C_word*)lf[81]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,*((C_word*)lf[82]+1),((C_word*)t0)[7],t1);}

/* k4068 in k3753 in k3750 in k3741 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 434  append */
t2=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3759 in k3753 in k3750 in k3741 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3761,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3764,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4062,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_u_i_cddr(((C_word*)t0)[2]);
/* eval.scm: 436  ##sys#canonicalize-body */
t5=*((C_word*)lf[79]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,t1,C_SCHEME_FALSE);}

/* k4060 in k3759 in k3753 in k3750 in k3741 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 435  ##sys#compile-to-closure */
t2=*((C_word*)lf[35]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3762 in k3759 in k3753 in k3750 in k3741 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3764,2,t0,t1);}
switch(((C_word*)t0)[10]){
case C_fix(1):
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3773,a[2]=t1,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 441  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3085(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
case C_fix(2):
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3807,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 444  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3085(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
case C_fix(3):
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3856,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 448  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3085(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
case C_fix(4):
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3923,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 456  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3085(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
default:
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3999,a[2]=((C_word*)t0)[10],a[3]=t1,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4046,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* map */
t4=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[8]);}}

/* a4045 in k3762 in k3759 in k3753 in k3750 in k3741 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4046(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4046,3,t0,t1,t2);}
t3=(C_word)C_u_i_cadr(t2);
t4=(C_word)C_u_i_car(t2);
/* eval.scm: 470  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3085(t5,t1,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3997 in k3762 in k3759 in k3753 in k3750 in k3741 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3999,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4000,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_4000 in k3997 in k3762 in k3759 in k3753 in k3750 in k3741 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_4000(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4000,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4004,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 472  ##sys#make-vector */
t4=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* k4002 */
static void C_ccall f_4004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4007,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4016,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_4016(t6,t2,C_fix(0),((C_word*)t0)[2]);}

/* doloop581 in k4002 */
static void C_fcall f_4016(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4016,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4041,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
t6=t5;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[2]);}}

/* k4039 in doloop581 in k4002 */
static void C_ccall f_4041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_4016(t5,((C_word*)t0)[2],t3,t4);}

/* k4005 in k4002 */
static void C_ccall f_4007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4007,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k3921 in k3762 in k3759 in k3753 in k3750 in k3741 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3923,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3926,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_u_i_cadadr(((C_word*)t0)[10]);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 457  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3085(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3924 in k3921 in k3762 in k3759 in k3753 in k3750 in k3741 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3926,2,t0,t1);}
t2=(C_word)C_u_i_cddr(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3932,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],a[10]=t1,a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_u_i_cadar(t2);
t5=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
/* eval.scm: 459  compile */
t6=((C_word*)((C_word*)t0)[6])[1];
f_3085(t6,t3,t4,((C_word*)t0)[5],t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3930 in k3924 in k3921 in k3762 in k3759 in k3753 in k3750 in k3741 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3932,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3935,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t1,a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_u_i_cadadr(((C_word*)t0)[8]);
t4=(C_word)C_u_i_cadddr(((C_word*)t0)[7]);
/* eval.scm: 460  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3085(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3933 in k3930 in k3924 in k3921 in k3762 in k3759 in k3753 in k3750 in k3741 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3935,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3936,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));}

/* f_3936 in k3933 in k3930 in k3924 in k3921 in k3762 in k3759 in k3753 in k3750 in k3741 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3936(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3936,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3952,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k3950 */
static void C_ccall f_3952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3956,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}

/* k3954 in k3950 */
static void C_ccall f_3956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3956,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3960,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k3958 in k3954 in k3950 */
static void C_ccall f_3960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3964,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k3962 in k3958 in k3954 in k3950 */
static void C_ccall f_3964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3964,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k3854 in k3762 in k3759 in k3753 in k3750 in k3741 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3856,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3859,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_u_i_cadadr(((C_word*)t0)[10]);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 449  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3085(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3857 in k3854 in k3762 in k3759 in k3753 in k3750 in k3741 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3859,2,t0,t1);}
t2=(C_word)C_u_i_cddr(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3865,a[2]=((C_word*)t0)[8],a[3]=t1,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_u_i_cadar(t2);
t5=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
/* eval.scm: 451  compile */
t6=((C_word*)((C_word*)t0)[6])[1];
f_3085(t6,t3,t4,((C_word*)t0)[5],t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3863 in k3857 in k3854 in k3762 in k3759 in k3753 in k3750 in k3741 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3865,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3866,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));}

/* f_3866 in k3863 in k3857 in k3854 in k3762 in k3759 in k3753 in k3750 in k3741 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3866(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3866,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3882,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k3880 */
static void C_ccall f_3882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3882,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3886,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k3884 in k3880 */
static void C_ccall f_3886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3890,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k3888 in k3884 in k3880 */
static void C_ccall f_3890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3890,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k3805 in k3762 in k3759 in k3753 in k3750 in k3741 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3807,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3810,a[2]=t1,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_cadadr(((C_word*)t0)[8]);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 445  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3085(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3808 in k3805 in k3762 in k3759 in k3753 in k3750 in k3741 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3810,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3811,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_3811 in k3808 in k3805 in k3762 in k3759 in k3753 in k3750 in k3741 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3811(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3811,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3827,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k3825 */
static void C_ccall f_3827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3827,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3831,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k3829 in k3825 */
static void C_ccall f_3831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3831,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k3771 in k3762 in k3759 in k3753 in k3750 in k3741 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3773,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3774,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_3774 in k3771 in k3762 in k3759 in k3753 in k3750 in k3741 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3774(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3774,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3790,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k3788 */
static void C_ccall f_3790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3790,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,1,t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k3629 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3631,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3639,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3645,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a3644 in k3629 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3645(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3645,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3649,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_u_i_caddr(((C_word*)t0)[8]);
/* eval.scm: 407  compile */
t6=((C_word*)((C_word*)t0)[7])[1];
f_3085(t6,t4,t5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3647 in a3644 in k3629 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3649,2,t0,t1);}
t2=((C_word*)t0)[4];
if(C_truep(t2)){
t3=(C_word)C_i_zerop(((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3706,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3719,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp)));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3658,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 409  ##sys#alias-global-hook */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_TRUE);}}

/* k3656 in k3647 in a3644 in k3629 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3658,2,t0,t1);}
if(C_truep(*((C_word*)lf[22]+1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3664,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 411  ##sys#hash-table-location */
t3=*((C_word*)lf[21]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[22]+1),t1,*((C_word*)lf[23]+1));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3691,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp));}}

/* f_3691 in k3656 in k3647 in a3644 in k3629 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3691(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3691,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3699,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k3697 */
static void C_ccall f_3699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(0),t1));}

/* k3662 in k3656 in k3647 in a3644 in k3629 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3664,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3667,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_3667(2,t3,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 415  ##sys#error */
t3=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[73],((C_word*)t0)[2]);}}

/* k3665 in k3662 in k3656 in k3647 in a3644 in k3629 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3667,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3674,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3683,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp)));}

/* f_3683 in k3665 in k3662 in k3656 in k3647 in a3644 in k3629 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3683(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3683,2,t0,t1);}
/* eval.scm: 418  ##sys#error */
t2=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[72],((C_word*)t0)[2]);}

/* f_3674 in k3665 in k3662 in k3656 in k3647 in a3644 in k3629 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3674(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3674,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3682,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k3680 */
static void C_ccall f_3682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* f_3719 in k3647 in a3644 in k3629 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3719(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3719,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3727,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k3725 */
static void C_ccall f_3727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot((C_word)C_u_i_list_ref(((C_word*)t0)[4],((C_word*)t0)[3]),((C_word*)t0)[2],t1));}

/* f_3706 in k3647 in a3644 in k3629 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3706(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3706,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3718,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3716 */
static void C_ccall f_3718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* a3638 in k3629 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3639,2,t0,t1);}
/* eval.scm: 406  lookup */
t2=((C_word*)t0)[5];
f_2932(t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3517 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3519,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t3=(C_word)C_i_length(t2);
switch(t3){
case C_fix(0):
/* eval.scm: 392  compile */
t4=((C_word*)((C_word*)t0)[7])[1];
f_3085(t4,((C_word*)t0)[6],lf[67],((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
case C_fix(1):
t4=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 393  compile */
t5=((C_word*)((C_word*)t0)[7])[1];
f_3085(t5,((C_word*)t0)[6],t4,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
case C_fix(2):
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3556,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 394  compile */
t6=((C_word*)((C_word*)t0)[7])[1];
f_3085(t6,t4,t5,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
default:
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3578,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 398  compile */
t6=((C_word*)((C_word*)t0)[7])[1];
f_3085(t6,t4,t5,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k3576 in k3517 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3578,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3581,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
/* eval.scm: 399  compile */
t4=((C_word*)((C_word*)t0)[7])[1];
f_3085(t4,t2,t3,((C_word*)t0)[6],C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}

/* k3579 in k3576 in k3517 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3581,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3584,a[2]=((C_word*)t0)[8],a[3]=t1,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3603,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t5=(C_word)C_slot(t4,C_fix(1));
/* ##sys#append */
t6=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t5,C_SCHEME_END_OF_LIST);}

/* k3601 in k3579 in k3576 in k3517 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3603,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[66],t1);
/* eval.scm: 400  compile */
t3=((C_word*)((C_word*)t0)[7])[1];
f_3085(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3582 in k3579 in k3576 in k3517 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3584,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3585,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp));}

/* f_3585 in k3582 in k3579 in k3576 in k3517 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3585(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3585,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3589,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k3587 */
static void C_ccall f_3589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3592,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k3590 in k3587 */
static void C_ccall f_3592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3554 in k3517 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3556,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3559,a[2]=t1,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 395  compile */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3085(t4,t2,t3,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3557 in k3554 in k3517 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3559,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3560,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp));}

/* f_3560 in k3557 in k3554 in k3517 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3560(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3560,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3564,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k3562 */
static void C_ccall f_3564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3457 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3459,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3462,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 380  compile */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3085(t4,t2,t3,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3460 in k3457 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3462,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3465,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
/* eval.scm: 381  compile */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3085(t4,t2,t3,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3463 in k3460 in k3457 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3468,a[2]=((C_word*)t0)[8],a[3]=t1,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_cdddr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_cadddr(((C_word*)t0)[7]);
/* eval.scm: 383  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3085(t5,t2,t4,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* eval.scm: 384  compile */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3085(t4,t2,lf[63],((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k3466 in k3463 in k3460 in k3457 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3468,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3469,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_3469 in k3466 in k3463 in k3460 in k3457 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3469(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3469,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3476,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k3474 */
static void C_ccall f_3476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* f_3449 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3449(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3449,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* f_3415 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3415(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3415,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(0)));}

/* k3407 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3409,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3410,a[2]=t1,tmp=(C_word)a,a+=3,tmp));}

/* f_3410 in k3407 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3410(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3410,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(1)));}

/* f_3393 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3393(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3393,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3313 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3318,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
/* eval.scm: 348  ##sys#strip-syntax */
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* k3316 in k3313 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3318,2,t0,t1);}
switch(t1){
case C_fix(-1):
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3325,tmp=(C_word)a,a+=2,tmp));
case C_fix(0):
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3333,tmp=(C_word)a,a+=2,tmp));
case C_fix(1):
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3341,tmp=(C_word)a,a+=2,tmp));
case C_fix(2):
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3349,tmp=(C_word)a,a+=2,tmp));
case C_SCHEME_TRUE:
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3357,tmp=(C_word)a,a+=2,tmp));
case C_SCHEME_FALSE:
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3365,tmp=(C_word)a,a+=2,tmp));
default:
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3373,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3375,a[2]=t1,tmp=(C_word)a,a+=3,tmp)));}}

/* f_3375 in k3316 in k3313 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3375(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3375,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_3373 in k3316 in k3313 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3373(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3373,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}

/* f_3365 in k3316 in k3313 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3365(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3365,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* f_3357 in k3316 in k3313 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3357(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3357,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_3349 in k3316 in k3313 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3349(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3349,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(2));}

/* f_3341 in k3316 in k3313 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3341(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3341,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(1));}

/* f_3333 in k3316 in k3313 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3333(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3333,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}

/* f_3325 in k3316 in k3313 in k3304 in k3289 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3325(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3325,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(-1));}

/* f_3269 in k3266 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3269(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3269,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_3258 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3258(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3258,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* f_3256 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3256(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3256,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_3245 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3245(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3245,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_3243 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3243(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3243,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(2));}

/* f_3235 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3235(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3235,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(1));}

/* f_3227 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3227(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3227,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}

/* f_3219 in k3210 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3219(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3219,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(-1));}

/* a3110 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3111(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3111,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep(t4)){
t5=(C_word)C_i_zerop(t2);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3193,a[2]=t3,tmp=(C_word)a,a+=3,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3202,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp)));}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3121,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_u_i_assq(((C_word*)t0)[3],((C_word*)t0)[2]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3179,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 299  ##sys#get */
t7=*((C_word*)lf[36]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,lf[49]);}
else{
/* eval.scm: 298  ##sys#alias-global-hook */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,C_SCHEME_FALSE);}}}

/* k3177 in a3110 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3121(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k3119 in a3110 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3121,2,t0,t1);}
if(C_truep(*((C_word*)lf[22]+1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3127,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 301  ##sys#hash-table-location */
t3=*((C_word*)lf[21]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[22]+1),t1,C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3150,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3155,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[30]+1))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3170,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 314  ##sys#symbol-has-toplevel-binding? */
t5=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t1);}
else{
t4=t3;
f_3155(t4,C_SCHEME_FALSE);}}}

/* k3168 in k3119 in a3110 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3155(t2,(C_word)C_i_not(t1));}

/* k3153 in k3119 in a3110 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_fcall f_3155(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3155,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t2,*((C_word*)lf[30]+1));
t4=C_mutate((C_word*)lf[30]+1 /* (set! unbound-in-eval ...) */,t3);
t5=((C_word*)t0)[2];
f_3150(t5,t4);}
else{
t2=((C_word*)t0)[2];
f_3150(t2,C_SCHEME_UNDEFINED);}}

/* k3148 in k3119 in a3110 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_fcall f_3150(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3150,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3151,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp));}

/* f_3151 in k3148 in k3119 in a3110 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3151(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3151,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_retrieve(((C_word*)t0)[2]));}

/* k3125 in k3119 in a3110 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3127,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3130,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_3130(2,t3,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 302  ##sys#syntax-error-hook */
t3=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[47],((C_word*)t0)[2]);}}

/* k3128 in k3125 in k3119 in a3110 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3130,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3131,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));}

/* f_3131 in k3128 in k3125 in k3119 in a3110 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3131(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3131,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_eqp(((C_word*)t0)[3],t2);
if(C_truep(t3)){
/* eval.scm: 309  ##sys#error */
t4=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,lf[45],((C_word*)t0)[2]);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* f_3202 in a3110 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3202(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3202,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot((C_word)C_u_i_list_ref(t2,((C_word*)t0)[3]),((C_word*)t0)[2]));}

/* f_3193 in a3110 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3193(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3193,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t3,((C_word*)t0)[2]));}

/* a3104 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3105,2,t0,t1);}
/* eval.scm: 295  lookup */
t2=((C_word*)t0)[5];
f_2932(t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_3093 in k3090 in compile in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3093(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3093,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* eval/meta in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_fcall f_3034(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3034,NULL,2,t1,t2);}
t3=*((C_word*)lf[39]+1);
t4=*((C_word*)lf[40]+1);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3038,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 278  ##sys#meta-macro-environment */
t8=*((C_word*)lf[43]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}

/* k3036 in eval/meta in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3038,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3039,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3059,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#dynamic-wind */
t6=*((C_word*)lf[42]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,((C_word*)t0)[2],t4,t5,t4);}

/* a3058 in k3036 in eval/meta in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3059,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3066,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3070,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 282  ##sys#current-meta-environment */
t4=*((C_word*)lf[41]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3068 in a3058 in k3036 in eval/meta in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 279  ##sys#compile-to-closure */
t2=*((C_word*)lf[35]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1);}

/* k3064 in a3058 in k3036 in eval/meta in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* swap344 in k3036 in eval/meta in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3039,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3043,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* g347348355 */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3041 in swap344 in k3036 in eval/meta in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3043,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3046,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* g347348355 */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[6])[1]);}

/* k3044 in k3041 in swap344 in k3036 in eval/meta in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3046,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3050,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g349350356 */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3048 in k3044 in k3041 in swap344 in k3036 in eval/meta in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3050,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3053,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g349350356 */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k3051 in k3048 in k3044 in k3041 in swap344 in k3036 in eval/meta in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_3053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* decorate in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_fcall f_3028(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3028,NULL,5,t1,t2,t3,t4,t5);}
/* eval.scm: 274  ##sys#eval-decorator */
t6=*((C_word*)lf[24]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,t2,t3,t4,t5);}

/* lookup in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_fcall f_2932(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2932,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2936,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 252  rename */
t6=((C_word*)t0)[2];
f_2917(t6,t5,t2,t4);}

/* k2934 in lookup in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_2936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2936,2,t0,t1);}
t2=*((C_word*)lf[38]+1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2944,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_2944(t6,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* loop in k2934 in lookup in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_fcall f_2944(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2944,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* eval.scm: 255  values */
C_values(4,0,t1,C_SCHEME_FALSE,((C_word*)t0)[3]);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=((C_word*)t0)[3];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2986,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=f_2986(t6,t4,C_fix(0));
if(C_truep(t7)){
/* eval.scm: 256  values */
C_values(4,0,t1,t3,t7);}
else{
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_u_fixnum_plus(t3,C_fix(1));
/* eval.scm: 257  loop */
t11=t1;
t12=t8;
t13=t9;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}}

/* loop in loop in k2934 in lookup in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static C_word C_fcall f_2986(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t1,C_fix(0));
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t2);}
else{
t5=(C_word)C_slot(t1,C_fix(1));
t6=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* rename in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_fcall f_2917(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2917,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2921,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 247  find-id */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2878(t5,t4,t2,t3);}

/* k2919 in rename in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_2921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2921,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2927,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 248  ##sys#get */
t3=*((C_word*)lf[36]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[37]);}}

/* k2925 in k2919 in rename in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_ccall f_2927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* find-id in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_fcall f_2878(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2878,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2891,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_caar(t3);
t6=(C_word)C_eqp(t2,t5);
if(C_truep(t6)){
t7=(C_word)C_u_i_cdar(t3);
t8=t4;
f_2891(t8,(C_word)C_i_symbolp(t7));}
else{
t7=t4;
f_2891(t7,C_SCHEME_FALSE);}}}

/* k2889 in find-id in ##sys#compile-to-closure in k2514 in k2511 in k2478 */
static void C_fcall f_2891(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_i_cdar(((C_word*)t0)[4]));}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 244  find-id */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2878(t3,((C_word*)t0)[5],((C_word*)t0)[2],t2);}}

/* ##sys#eval-decorator in k2514 in k2511 in k2478 */
static void C_ccall f_2828(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2828,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2834,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2847,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 216  ##sys#decorate-lambda */
t8=*((C_word*)lf[29]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,t2,t6,t7);}

/* a2846 in ##sys#eval-decorator in k2514 in k2511 in k2478 */
static void C_ccall f_2847(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2847,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2855,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2859,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 223  open-output-string */
t6=*((C_word*)lf[28]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k2857 in a2846 in ##sys#eval-decorator in k2514 in k2511 in k2478 */
static void C_ccall f_2859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2859,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2862,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 224  write */
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k2860 in k2857 in a2846 in ##sys#eval-decorator in k2514 in k2511 in k2478 */
static void C_ccall f_2862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2862,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2865,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 225  get-output-string */
t3=*((C_word*)lf[26]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2863 in k2860 in k2857 in a2846 in ##sys#eval-decorator in k2514 in k2511 in k2478 */
static void C_ccall f_2865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 222  ##sys#make-lambda-info */
t2=*((C_word*)lf[25]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2853 in a2846 in ##sys#eval-decorator in k2514 in k2511 in k2478 */
static void C_ccall f_2855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}

/* a2833 in ##sys#eval-decorator in k2514 in k2511 in k2478 */
static void C_ccall f_2834(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2834,3,t0,t1,t2);}
t3=(C_word)C_immp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_lambdainfop(t2)));}

/* ##sys#hash-table-location in k2514 in k2511 in k2478 */
static void C_ccall f_2768(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2768,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2772,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_block_size(t2);
/* eval.scm: 196  ##sys#hash-symbol */
t7=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t3,t6);}

/* k2770 in ##sys#hash-table-location in k2514 in k2511 in k2478 */
static void C_ccall f_2772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2772,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2780,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_2780(t6,((C_word*)t0)[2],t2);}

/* loop in k2770 in ##sys#hash-table-location in k2514 in k2511 in k2478 */
static void C_fcall f_2780(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2780,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep(((C_word*)t0)[8])){
t3=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[7],((C_word*)t0)[6],C_SCHEME_TRUE);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[5]);
t5=(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[7],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 207  loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* ##sys#hash-table-for-each in k2514 in k2511 in k2478 */
static void C_ccall f_2706(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2706,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2712,a[2]=t2,a[3]=t3,a[4]=t6,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_2712(t8,t1,C_fix(0));}

/* doloop190 in ##sys#hash-table-for-each in k2514 in k2511 in k2478 */
static void C_fcall f_2712(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2712,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2722,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2735,a[2]=((C_word*)t0)[2],a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_2735(t8,t3,t4);}}

/* loop197 in doloop190 in ##sys#hash-table-for-each in k2514 in k2511 in k2478 */
static void C_fcall f_2735(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2735,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2748,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
t6=(C_word)C_slot(t3,C_fix(1));
/* eval.scm: 190  p */
t7=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,t6);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2746 in loop197 in doloop190 in ##sys#hash-table-for-each in k2514 in k2511 in k2478 */
static void C_ccall f_2748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2735(t3,((C_word*)t0)[2],t2);}

/* k2720 in doloop190 in ##sys#hash-table-for-each in k2514 in k2511 in k2478 */
static void C_ccall f_2722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2712(t3,((C_word*)t0)[2],t2);}

/* ##sys#hash-table-update! in k2514 in k2511 in k2478 */
static void C_ccall f_2686(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2686,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2694,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2698,a[2]=t5,a[3]=t6,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 184  ##sys#hash-table-ref */
t8=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t2,t3);}

/* k2696 in ##sys#hash-table-update! in k2514 in k2511 in k2478 */
static void C_ccall f_2698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2698,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2701,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_2701(2,t3,t1);}
else{
/* eval.scm: 184  valufunc */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2699 in k2696 in ##sys#hash-table-update! in k2514 in k2511 in k2478 */
static void C_ccall f_2701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 184  updtfunc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2692 in ##sys#hash-table-update! in k2514 in k2511 in k2478 */
static void C_ccall f_2694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 184  ##sys#hash-table-set! */
t2=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#hash-table-set! in k2514 in k2511 in k2478 */
static void C_ccall f_2626(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2626,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2630,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 174  ##sys#hash-symbol */
t6=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,(C_word)C_block_size(t2));}

/* k2628 in ##sys#hash-table-set! in k2514 in k2511 in k2478 */
static void C_ccall f_2630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2630,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2638,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_2638(t6,((C_word*)t0)[2],t2);}

/* loop in k2628 in ##sys#hash-table-set! in k2514 in k2511 in k2478 */
static void C_fcall f_2638(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2638,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t2);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[5]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t5));}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[7],t5);
if(C_truep(t6)){
t7=(C_word)C_slot(t2,C_fix(0));
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_setslot(t7,C_fix(1),((C_word*)t0)[6]));}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 181  loop */
t12=t1;
t13=t7;
t1=t12;
t2=t13;
goto loop;}}}

/* ##sys#hash-table-ref in k2514 in k2511 in k2478 */
static void C_ccall f_2571(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2571,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2624,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 167  ##sys#hash-symbol */
t5=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,(C_word)C_block_size(t2));}

/* k2622 in ##sys#hash-table-ref in k2514 in k2511 in k2478 */
static void C_ccall f_2624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2624,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2581,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_2581(t3,t2));}

/* loop in k2622 in ##sys#hash-table-ref in k2514 in k2511 in k2478 */
static C_word C_fcall f_2581(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
t2=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t1);
if(C_truep(t2)){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t1,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
t6=(C_word)C_slot(t1,C_fix(0));
return((C_word)C_slot(t6,C_fix(1)));}
else{
t6=(C_word)C_slot(t1,C_fix(1));
t9=t6;
t1=t9;
goto loop;}}}

/* ##sys#hash-symbol in k2514 in k2511 in k2478 */
static void C_ccall f_2556(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2556,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(((C_word*)((C_word*)t0)[2])[1],t3));}
else{
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t6=(C_word)C_slot(t2,C_fix(1));
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,(C_word)C_hash_string(t6));
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_fixnum_modulo(((C_word*)((C_word*)t0)[2])[1],t3));}}

/* chicken-home in k2514 in k2511 in k2478 */
static void C_ccall f_2544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2544,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2548,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 149  ##sys#chicken-prefix */
t3=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[14]);}

/* k2546 in chicken-home in k2514 in k2511 in k2478 */
static void C_ccall f_2548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2548,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* ##sys#peek-c-string */
t2=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_mpointer(&a,(void*)C_INSTALL_SHARE_HOME),C_fix(0));}}

/* ##sys#chicken-prefix in k2514 in k2511 in k2478 */
static void C_ccall f_2517(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2517r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2517r(t0,t1,t2);}}

static void C_ccall f_2517r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
t3=(C_word)C_vemptyp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_slot(t2,C_fix(0)));
if(C_truep(((C_word*)t0)[2])){
if(C_truep(t4)){
/* eval.scm: 143  ##sys#string-append */
t5=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,((C_word*)t0)[2],t4);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[2]);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* d in k2478 */
static void C_ccall f_2482(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_2482r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2482r(t0,t1,t2,t3);}}

static void C_ccall f_2482r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
if(C_truep((C_word)C_i_nullp(t3))){
/* eval.scm: 41   pp */
t4=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}
else{
C_apply(5,0,t1,*((C_word*)lf[2]+1),t2,t3);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[778] = {
{"toplevel:eval_scm",(void*)C_eval_toplevel},
{"f_2480:eval_scm",(void*)f_2480},
{"f_2513:eval_scm",(void*)f_2513},
{"f_2516:eval_scm",(void*)f_2516},
{"f_9618:eval_scm",(void*)f_9618},
{"f_9622:eval_scm",(void*)f_9622},
{"f_9647:eval_scm",(void*)f_9647},
{"f_9637:eval_scm",(void*)f_9637},
{"f_9645:eval_scm",(void*)f_9645},
{"f_9630:eval_scm",(void*)f_9630},
{"f_9628:eval_scm",(void*)f_9628},
{"f_5799:eval_scm",(void*)f_5799},
{"f_5894:eval_scm",(void*)f_5894},
{"f_5975:eval_scm",(void*)f_5975},
{"f_9612:eval_scm",(void*)f_9612},
{"f_9608:eval_scm",(void*)f_9608},
{"f_9604:eval_scm",(void*)f_9604},
{"f_9600:eval_scm",(void*)f_9600},
{"f_9590:eval_scm",(void*)f_9590},
{"f_6519:eval_scm",(void*)f_6519},
{"f_6524:eval_scm",(void*)f_6524},
{"f_9572:eval_scm",(void*)f_9572},
{"f_9551:eval_scm",(void*)f_9551},
{"f_9558:eval_scm",(void*)f_9558},
{"f_6531:eval_scm",(void*)f_6531},
{"f_9542:eval_scm",(void*)f_9542},
{"f_9544:eval_scm",(void*)f_9544},
{"f_6540:eval_scm",(void*)f_6540},
{"f_9511:eval_scm",(void*)f_9511},
{"f_9531:eval_scm",(void*)f_9531},
{"f_9527:eval_scm",(void*)f_9527},
{"f_9517:eval_scm",(void*)f_9517},
{"f_9514:eval_scm",(void*)f_9514},
{"f_6894:eval_scm",(void*)f_6894},
{"f_9457:eval_scm",(void*)f_9457},
{"f_9471:eval_scm",(void*)f_9471},
{"f_9507:eval_scm",(void*)f_9507},
{"f_9503:eval_scm",(void*)f_9503},
{"f_9491:eval_scm",(void*)f_9491},
{"f_9495:eval_scm",(void*)f_9495},
{"f_9465:eval_scm",(void*)f_9465},
{"f_7797:eval_scm",(void*)f_7797},
{"f_9360:eval_scm",(void*)f_9360},
{"f_9397:eval_scm",(void*)f_9397},
{"f_9400:eval_scm",(void*)f_9400},
{"f_9423:eval_scm",(void*)f_9423},
{"f_9427:eval_scm",(void*)f_9427},
{"f_9409:eval_scm",(void*)f_9409},
{"f_9406:eval_scm",(void*)f_9406},
{"f_9363:eval_scm",(void*)f_9363},
{"f_7800:eval_scm",(void*)f_7800},
{"f_7858:eval_scm",(void*)f_7858},
{"f_9334:eval_scm",(void*)f_9334},
{"f_9358:eval_scm",(void*)f_9358},
{"f_9344:eval_scm",(void*)f_9344},
{"f_8209:eval_scm",(void*)f_8209},
{"f_8213:eval_scm",(void*)f_8213},
{"f_9308:eval_scm",(void*)f_9308},
{"f_9332:eval_scm",(void*)f_9332},
{"f_9318:eval_scm",(void*)f_9318},
{"f_8216:eval_scm",(void*)f_8216},
{"f_8220:eval_scm",(void*)f_8220},
{"f_8487:eval_scm",(void*)f_8487},
{"f_9302:eval_scm",(void*)f_9302},
{"f_8509:eval_scm",(void*)f_8509},
{"f_8920:eval_scm",(void*)f_8920},
{"f_9293:eval_scm",(void*)f_9293},
{"f_9300:eval_scm",(void*)f_9300},
{"f_9283:eval_scm",(void*)f_9283},
{"f_9268:eval_scm",(void*)f_9268},
{"f_9272:eval_scm",(void*)f_9272},
{"f_9277:eval_scm",(void*)f_9277},
{"f_9281:eval_scm",(void*)f_9281},
{"f_9246:eval_scm",(void*)f_9246},
{"f_9250:eval_scm",(void*)f_9250},
{"f_9255:eval_scm",(void*)f_9255},
{"f_9259:eval_scm",(void*)f_9259},
{"f_9266:eval_scm",(void*)f_9266},
{"f_9220:eval_scm",(void*)f_9220},
{"f_9226:eval_scm",(void*)f_9226},
{"f_9230:eval_scm",(void*)f_9230},
{"f_9244:eval_scm",(void*)f_9244},
{"f_9233:eval_scm",(void*)f_9233},
{"f_9240:eval_scm",(void*)f_9240},
{"f_9204:eval_scm",(void*)f_9204},
{"f_9210:eval_scm",(void*)f_9210},
{"f_9218:eval_scm",(void*)f_9218},
{"f_9167:eval_scm",(void*)f_9167},
{"f_9171:eval_scm",(void*)f_9171},
{"f_9176:eval_scm",(void*)f_9176},
{"f_9180:eval_scm",(void*)f_9180},
{"f_9202:eval_scm",(void*)f_9202},
{"f_9198:eval_scm",(void*)f_9198},
{"f_9194:eval_scm",(void*)f_9194},
{"f_9183:eval_scm",(void*)f_9183},
{"f_9190:eval_scm",(void*)f_9190},
{"f_9141:eval_scm",(void*)f_9141},
{"f_9147:eval_scm",(void*)f_9147},
{"f_9151:eval_scm",(void*)f_9151},
{"f_9165:eval_scm",(void*)f_9165},
{"f_9154:eval_scm",(void*)f_9154},
{"f_9161:eval_scm",(void*)f_9161},
{"f_9128:eval_scm",(void*)f_9128},
{"f_9102:eval_scm",(void*)f_9102},
{"f_9106:eval_scm",(void*)f_9106},
{"f_9111:eval_scm",(void*)f_9111},
{"f_9115:eval_scm",(void*)f_9115},
{"f_9126:eval_scm",(void*)f_9126},
{"f_9122:eval_scm",(void*)f_9122},
{"f_9086:eval_scm",(void*)f_9086},
{"f_9092:eval_scm",(void*)f_9092},
{"f_9100:eval_scm",(void*)f_9100},
{"f_9074:eval_scm",(void*)f_9074},
{"f_9080:eval_scm",(void*)f_9080},
{"f_9084:eval_scm",(void*)f_9084},
{"f_9065:eval_scm",(void*)f_9065},
{"f_9069:eval_scm",(void*)f_9069},
{"f_9006:eval_scm",(void*)f_9006},
{"f_9016:eval_scm",(void*)f_9016},
{"f_9041:eval_scm",(void*)f_9041},
{"f_9053:eval_scm",(void*)f_9053},
{"f_9059:eval_scm",(void*)f_9059},
{"f_9047:eval_scm",(void*)f_9047},
{"f_9022:eval_scm",(void*)f_9022},
{"f_9028:eval_scm",(void*)f_9028},
{"f_9032:eval_scm",(void*)f_9032},
{"f_9035:eval_scm",(void*)f_9035},
{"f_9039:eval_scm",(void*)f_9039},
{"f_9014:eval_scm",(void*)f_9014},
{"f_8931:eval_scm",(void*)f_8931},
{"f_8941:eval_scm",(void*)f_8941},
{"f_8944:eval_scm",(void*)f_8944},
{"f_8958:eval_scm",(void*)f_8958},
{"f_8976:eval_scm",(void*)f_8976},
{"f_8945:eval_scm",(void*)f_8945},
{"f_8922:eval_scm",(void*)f_8922},
{"f_8530:eval_scm",(void*)f_8530},
{"f_8606:eval_scm",(void*)f_8606},
{"f_8609:eval_scm",(void*)f_8609},
{"f_8905:eval_scm",(void*)f_8905},
{"f_8909:eval_scm",(void*)f_8909},
{"f_8913:eval_scm",(void*)f_8913},
{"f_8691:eval_scm",(void*)f_8691},
{"f_8697:eval_scm",(void*)f_8697},
{"f_8888:eval_scm",(void*)f_8888},
{"f_8894:eval_scm",(void*)f_8894},
{"f_8704:eval_scm",(void*)f_8704},
{"f_8707:eval_scm",(void*)f_8707},
{"f_8710:eval_scm",(void*)f_8710},
{"f_8883:eval_scm",(void*)f_8883},
{"f_8719:eval_scm",(void*)f_8719},
{"f_8722:eval_scm",(void*)f_8722},
{"f_8737:eval_scm",(void*)f_8737},
{"f_8755:eval_scm",(void*)f_8755},
{"f_8837:eval_scm",(void*)f_8837},
{"f_8771:eval_scm",(void*)f_8771},
{"f_8779:eval_scm",(void*)f_8779},
{"f_8792:eval_scm",(void*)f_8792},
{"f_8795:eval_scm",(void*)f_8795},
{"f_8814:eval_scm",(void*)f_8814},
{"f_8817:eval_scm",(void*)f_8817},
{"f_8798:eval_scm",(void*)f_8798},
{"f_8801:eval_scm",(void*)f_8801},
{"f_8774:eval_scm",(void*)f_8774},
{"f_8759:eval_scm",(void*)f_8759},
{"f_8741:eval_scm",(void*)f_8741},
{"f_8571:eval_scm",(void*)f_8571},
{"f_8576:eval_scm",(void*)f_8576},
{"f_8589:eval_scm",(void*)f_8589},
{"f_8744:eval_scm",(void*)f_8744},
{"f_8728:eval_scm",(void*)f_8728},
{"f_8626:eval_scm",(void*)f_8626},
{"f_8631:eval_scm",(void*)f_8631},
{"f_8634:eval_scm",(void*)f_8634},
{"f_8639:eval_scm",(void*)f_8639},
{"f_8646:eval_scm",(void*)f_8646},
{"f_8686:eval_scm",(void*)f_8686},
{"f_8649:eval_scm",(void*)f_8649},
{"f_8661:eval_scm",(void*)f_8661},
{"f_8670:eval_scm",(void*)f_8670},
{"f_8664:eval_scm",(void*)f_8664},
{"f_8652:eval_scm",(void*)f_8652},
{"f_8655:eval_scm",(void*)f_8655},
{"f_8617:eval_scm",(void*)f_8617},
{"f_8611:eval_scm",(void*)f_8611},
{"f_8533:eval_scm",(void*)f_8533},
{"f_8539:eval_scm",(void*)f_8539},
{"f_8552:eval_scm",(void*)f_8552},
{"f_8527:eval_scm",(void*)f_8527},
{"f_8511:eval_scm",(void*)f_8511},
{"f_8525:eval_scm",(void*)f_8525},
{"f_8522:eval_scm",(void*)f_8522},
{"f_8515:eval_scm",(void*)f_8515},
{"f_8492:eval_scm",(void*)f_8492},
{"f_8501:eval_scm",(void*)f_8501},
{"f_8496:eval_scm",(void*)f_8496},
{"f_8432:eval_scm",(void*)f_8432},
{"f_8436:eval_scm",(void*)f_8436},
{"f_8439:eval_scm",(void*)f_8439},
{"f_8442:eval_scm",(void*)f_8442},
{"f_8445:eval_scm",(void*)f_8445},
{"f_8448:eval_scm",(void*)f_8448},
{"f_8451:eval_scm",(void*)f_8451},
{"f_8454:eval_scm",(void*)f_8454},
{"f_8457:eval_scm",(void*)f_8457},
{"f_8460:eval_scm",(void*)f_8460},
{"f_8411:eval_scm",(void*)f_8411},
{"f_8415:eval_scm",(void*)f_8415},
{"f_8418:eval_scm",(void*)f_8418},
{"f_8387:eval_scm",(void*)f_8387},
{"f_8393:eval_scm",(void*)f_8393},
{"f_8403:eval_scm",(void*)f_8403},
{"f_8245:eval_scm",(void*)f_8245},
{"f_8316:eval_scm",(void*)f_8316},
{"f_8363:eval_scm",(void*)f_8363},
{"f_8373:eval_scm",(void*)f_8373},
{"f_8366:eval_scm",(void*)f_8366},
{"f_8326:eval_scm",(void*)f_8326},
{"f_8328:eval_scm",(void*)f_8328},
{"f_8352:eval_scm",(void*)f_8352},
{"f_8338:eval_scm",(void*)f_8338},
{"f_8286:eval_scm",(void*)f_8286},
{"f_8251:eval_scm",(void*)f_8251},
{"f_8267:eval_scm",(void*)f_8267},
{"f_8273:eval_scm",(void*)f_8273},
{"f_8264:eval_scm",(void*)f_8264},
{"f_8226:eval_scm",(void*)f_8226},
{"f_8230:eval_scm",(void*)f_8230},
{"f_8193:eval_scm",(void*)f_8193},
{"f_8195:eval_scm",(void*)f_8195},
{"f_8199:eval_scm",(void*)f_8199},
{"f_8155:eval_scm",(void*)f_8155},
{"f_8162:eval_scm",(void*)f_8162},
{"f_8169:eval_scm",(void*)f_8169},
{"f_8111:eval_scm",(void*)f_8111},
{"f_8144:eval_scm",(void*)f_8144},
{"f_8131:eval_scm",(void*)f_8131},
{"f_8108:eval_scm",(void*)f_8108},
{"f_7989:eval_scm",(void*)f_7989},
{"f_8083:eval_scm",(void*)f_8083},
{"f_8093:eval_scm",(void*)f_8093},
{"f_8081:eval_scm",(void*)f_8081},
{"f_8010:eval_scm",(void*)f_8010},
{"f_8034:eval_scm",(void*)f_8034},
{"f_8053:eval_scm",(void*)f_8053},
{"f_8028:eval_scm",(void*)f_8028},
{"f_7881:eval_scm",(void*)f_7881},
{"f_7891:eval_scm",(void*)f_7891},
{"f_7896:eval_scm",(void*)f_7896},
{"f_7923:eval_scm",(void*)f_7923},
{"f_7956:eval_scm",(void*)f_7956},
{"f_7917:eval_scm",(void*)f_7917},
{"f_7865:eval_scm",(void*)f_7865},
{"f_7802:eval_scm",(void*)f_7802},
{"f_7806:eval_scm",(void*)f_7806},
{"f_7814:eval_scm",(void*)f_7814},
{"f_7834:eval_scm",(void*)f_7834},
{"f_7758:eval_scm",(void*)f_7758},
{"f_7790:eval_scm",(void*)f_7790},
{"f_7776:eval_scm",(void*)f_7776},
{"f_7236:eval_scm",(void*)f_7236},
{"f_7626:eval_scm",(void*)f_7626},
{"f_7635:eval_scm",(void*)f_7635},
{"f_7665:eval_scm",(void*)f_7665},
{"f_7667:eval_scm",(void*)f_7667},
{"f_7704:eval_scm",(void*)f_7704},
{"f_7694:eval_scm",(void*)f_7694},
{"f_7689:eval_scm",(void*)f_7689},
{"f_7685:eval_scm",(void*)f_7685},
{"f_7305:eval_scm",(void*)f_7305},
{"f_7315:eval_scm",(void*)f_7315},
{"f_7477:eval_scm",(void*)f_7477},
{"f_7588:eval_scm",(void*)f_7588},
{"f_7595:eval_scm",(void*)f_7595},
{"f_7492:eval_scm",(void*)f_7492},
{"f_7511:eval_scm",(void*)f_7511},
{"f_7539:eval_scm",(void*)f_7539},
{"f_7537:eval_scm",(void*)f_7537},
{"f_7533:eval_scm",(void*)f_7533},
{"f_7519:eval_scm",(void*)f_7519},
{"f_7515:eval_scm",(void*)f_7515},
{"f_7507:eval_scm",(void*)f_7507},
{"f_7499:eval_scm",(void*)f_7499},
{"f_7382:eval_scm",(void*)f_7382},
{"f_7403:eval_scm",(void*)f_7403},
{"f_7415:eval_scm",(void*)f_7415},
{"f_7411:eval_scm",(void*)f_7411},
{"f_7399:eval_scm",(void*)f_7399},
{"f_7339:eval_scm",(void*)f_7339},
{"f_7335:eval_scm",(void*)f_7335},
{"f_7322:eval_scm",(void*)f_7322},
{"f_7264:eval_scm",(void*)f_7264},
{"f_7283:eval_scm",(void*)f_7283},
{"f_7280:eval_scm",(void*)f_7280},
{"f_7276:eval_scm",(void*)f_7276},
{"f_7239:eval_scm",(void*)f_7239},
{"f_7258:eval_scm",(void*)f_7258},
{"f_7252:eval_scm",(void*)f_7252},
{"f_7187:eval_scm",(void*)f_7187},
{"f_7193:eval_scm",(void*)f_7193},
{"f_7207:eval_scm",(void*)f_7207},
{"f_7210:eval_scm",(void*)f_7210},
{"f_7217:eval_scm",(void*)f_7217},
{"f_7181:eval_scm",(void*)f_7181},
{"f_7153:eval_scm",(void*)f_7153},
{"f_7157:eval_scm",(void*)f_7157},
{"f_7163:eval_scm",(void*)f_7163},
{"f_7166:eval_scm",(void*)f_7166},
{"f_7179:eval_scm",(void*)f_7179},
{"f_7169:eval_scm",(void*)f_7169},
{"f_7124:eval_scm",(void*)f_7124},
{"f_7130:eval_scm",(void*)f_7130},
{"f_7143:eval_scm",(void*)f_7143},
{"f_7110:eval_scm",(void*)f_7110},
{"f_7121:eval_scm",(void*)f_7121},
{"f_7074:eval_scm",(void*)f_7074},
{"f_7080:eval_scm",(void*)f_7080},
{"f_7096:eval_scm",(void*)f_7096},
{"f_6997:eval_scm",(void*)f_6997},
{"f_7057:eval_scm",(void*)f_7057},
{"f_7004:eval_scm",(void*)f_7004},
{"f_7007:eval_scm",(void*)f_7007},
{"f_7034:eval_scm",(void*)f_7034},
{"f_7040:eval_scm",(void*)f_7040},
{"f_7022:eval_scm",(void*)f_7022},
{"f_6898:eval_scm",(void*)f_6898},
{"f_6902:eval_scm",(void*)f_6902},
{"f_6950:eval_scm",(void*)f_6950},
{"f_6952:eval_scm",(void*)f_6952},
{"f_6965:eval_scm",(void*)f_6965},
{"f_6904:eval_scm",(void*)f_6904},
{"f_6908:eval_scm",(void*)f_6908},
{"f_6943:eval_scm",(void*)f_6943},
{"f_6914:eval_scm",(void*)f_6914},
{"f_6924:eval_scm",(void*)f_6924},
{"f_6917:eval_scm",(void*)f_6917},
{"f_6734:eval_scm",(void*)f_6734},
{"f_6839:eval_scm",(void*)f_6839},
{"f_6856:eval_scm",(void*)f_6856},
{"f_6864:eval_scm",(void*)f_6864},
{"f_6756:eval_scm",(void*)f_6756},
{"f_6761:eval_scm",(void*)f_6761},
{"f_6800:eval_scm",(void*)f_6800},
{"f_6787:eval_scm",(void*)f_6787},
{"f_6737:eval_scm",(void*)f_6737},
{"f_6648:eval_scm",(void*)f_6648},
{"f_6655:eval_scm",(void*)f_6655},
{"f_6665:eval_scm",(void*)f_6665},
{"f_6542:eval_scm",(void*)f_6542},
{"f_6546:eval_scm",(void*)f_6546},
{"f_6638:eval_scm",(void*)f_6638},
{"f_6642:eval_scm",(void*)f_6642},
{"f_6555:eval_scm",(void*)f_6555},
{"f_6624:eval_scm",(void*)f_6624},
{"f_6620:eval_scm",(void*)f_6620},
{"f_6558:eval_scm",(void*)f_6558},
{"f_6607:eval_scm",(void*)f_6607},
{"f_6610:eval_scm",(void*)f_6610},
{"f_6613:eval_scm",(void*)f_6613},
{"f_6561:eval_scm",(void*)f_6561},
{"f_6566:eval_scm",(void*)f_6566},
{"f_6600:eval_scm",(void*)f_6600},
{"f_6579:eval_scm",(void*)f_6579},
{"f_6582:eval_scm",(void*)f_6582},
{"f_6533:eval_scm",(void*)f_6533},
{"f_6493:eval_scm",(void*)f_6493},
{"f_6514:eval_scm",(void*)f_6514},
{"f_6497:eval_scm",(void*)f_6497},
{"f_6511:eval_scm",(void*)f_6511},
{"f_6500:eval_scm",(void*)f_6500},
{"f_6508:eval_scm",(void*)f_6508},
{"f_6503:eval_scm",(void*)f_6503},
{"f_6457:eval_scm",(void*)f_6457},
{"f_6465:eval_scm",(void*)f_6465},
{"f_6435:eval_scm",(void*)f_6435},
{"f_6023:eval_scm",(void*)f_6023},
{"f_6390:eval_scm",(void*)f_6390},
{"f_6385:eval_scm",(void*)f_6385},
{"f_6025:eval_scm",(void*)f_6025},
{"f_6384:eval_scm",(void*)f_6384},
{"f_6029:eval_scm",(void*)f_6029},
{"f_6306:eval_scm",(void*)f_6306},
{"f_6321:eval_scm",(void*)f_6321},
{"f_6324:eval_scm",(void*)f_6324},
{"f_6327:eval_scm",(void*)f_6327},
{"f_6333:eval_scm",(void*)f_6333},
{"f_6336:eval_scm",(void*)f_6336},
{"f_6342:eval_scm",(void*)f_6342},
{"f_6032:eval_scm",(void*)f_6032},
{"f_6297:eval_scm",(void*)f_6297},
{"f_6285:eval_scm",(void*)f_6285},
{"f_6288:eval_scm",(void*)f_6288},
{"f_6291:eval_scm",(void*)f_6291},
{"f_6038:eval_scm",(void*)f_6038},
{"f_6270:eval_scm",(void*)f_6270},
{"f_6242:eval_scm",(void*)f_6242},
{"f_6266:eval_scm",(void*)f_6266},
{"f_6262:eval_scm",(void*)f_6262},
{"f_6258:eval_scm",(void*)f_6258},
{"f_6041:eval_scm",(void*)f_6041},
{"f_6049:eval_scm",(void*)f_6049},
{"f_6229:eval_scm",(void*)f_6229},
{"f_6053:eval_scm",(void*)f_6053},
{"f_6217:eval_scm",(void*)f_6217},
{"f_6074:eval_scm",(void*)f_6074},
{"f_6078:eval_scm",(void*)f_6078},
{"f_6208:eval_scm",(void*)f_6208},
{"f_6086:eval_scm",(void*)f_6086},
{"f_6090:eval_scm",(void*)f_6090},
{"f_6202:eval_scm",(void*)f_6202},
{"f_6093:eval_scm",(void*)f_6093},
{"f_6096:eval_scm",(void*)f_6096},
{"f_6101:eval_scm",(void*)f_6101},
{"f_6111:eval_scm",(void*)f_6111},
{"f_6157:eval_scm",(void*)f_6157},
{"f_6166:eval_scm",(void*)f_6166},
{"f_6179:eval_scm",(void*)f_6179},
{"f_6182:eval_scm",(void*)f_6182},
{"f_6123:eval_scm",(void*)f_6123},
{"f_6130:eval_scm",(void*)f_6130},
{"f_6141:eval_scm",(void*)f_6141},
{"f_6152:eval_scm",(void*)f_6152},
{"f_6145:eval_scm",(void*)f_6145},
{"f_6135:eval_scm",(void*)f_6135},
{"f_6114:eval_scm",(void*)f_6114},
{"f_6121:eval_scm",(void*)f_6121},
{"f_6083:eval_scm",(void*)f_6083},
{"f_6063:eval_scm",(void*)f_6063},
{"f_6054:eval_scm",(void*)f_6054},
{"f_6044:eval_scm",(void*)f_6044},
{"f_5977:eval_scm",(void*)f_5977},
{"f_5987:eval_scm",(void*)f_5987},
{"f_5902:eval_scm",(void*)f_5902},
{"f_5914:eval_scm",(void*)f_5914},
{"f_5927:eval_scm",(void*)f_5927},
{"f_5909:eval_scm",(void*)f_5909},
{"f_5896:eval_scm",(void*)f_5896},
{"f_5812:eval_scm",(void*)f_5812},
{"f_5825:eval_scm",(void*)f_5825},
{"f_5858:eval_scm",(void*)f_5858},
{"f_5839:eval_scm",(void*)f_5839},
{"f_5815:eval_scm",(void*)f_5815},
{"f_5802:eval_scm",(void*)f_5802},
{"f_5810:eval_scm",(void*)f_5810},
{"f_2872:eval_scm",(void*)f_2872},
{"f_5551:eval_scm",(void*)f_5551},
{"f_5555:eval_scm",(void*)f_5555},
{"f_5768:eval_scm",(void*)f_5768},
{"f_5744:eval_scm",(void*)f_5744},
{"f_5745:eval_scm",(void*)f_5745},
{"f_5756:eval_scm",(void*)f_5756},
{"f_5762:eval_scm",(void*)f_5762},
{"f_5760:eval_scm",(void*)f_5760},
{"f_5701:eval_scm",(void*)f_5701},
{"f_5704:eval_scm",(void*)f_5704},
{"f_5707:eval_scm",(void*)f_5707},
{"f_5710:eval_scm",(void*)f_5710},
{"f_5711:eval_scm",(void*)f_5711},
{"f_5722:eval_scm",(void*)f_5722},
{"f_5726:eval_scm",(void*)f_5726},
{"f_5730:eval_scm",(void*)f_5730},
{"f_5734:eval_scm",(void*)f_5734},
{"f_5737:eval_scm",(void*)f_5737},
{"f_5659:eval_scm",(void*)f_5659},
{"f_5662:eval_scm",(void*)f_5662},
{"f_5665:eval_scm",(void*)f_5665},
{"f_5666:eval_scm",(void*)f_5666},
{"f_5677:eval_scm",(void*)f_5677},
{"f_5681:eval_scm",(void*)f_5681},
{"f_5685:eval_scm",(void*)f_5685},
{"f_5688:eval_scm",(void*)f_5688},
{"f_5624:eval_scm",(void*)f_5624},
{"f_5627:eval_scm",(void*)f_5627},
{"f_5628:eval_scm",(void*)f_5628},
{"f_5639:eval_scm",(void*)f_5639},
{"f_5643:eval_scm",(void*)f_5643},
{"f_5646:eval_scm",(void*)f_5646},
{"f_5596:eval_scm",(void*)f_5596},
{"f_5597:eval_scm",(void*)f_5597},
{"f_5608:eval_scm",(void*)f_5608},
{"f_5611:eval_scm",(void*)f_5611},
{"f_5577:eval_scm",(void*)f_5577},
{"f_5587:eval_scm",(void*)f_5587},
{"f_5525:eval_scm",(void*)f_5525},
{"f_3085:eval_scm",(void*)f_3085},
{"f_3092:eval_scm",(void*)f_3092},
{"f_3212:eval_scm",(void*)f_3212},
{"f_3268:eval_scm",(void*)f_3268},
{"f_3291:eval_scm",(void*)f_3291},
{"f_3306:eval_scm",(void*)f_3306},
{"f_5322:eval_scm",(void*)f_5322},
{"f_5305:eval_scm",(void*)f_5305},
{"f_5309:eval_scm",(void*)f_5309},
{"f_5262:eval_scm",(void*)f_5262},
{"f_5275:eval_scm",(void*)f_5275},
{"f_5247:eval_scm",(void*)f_5247},
{"f_5206:eval_scm",(void*)f_5206},
{"f_5152:eval_scm",(void*)f_5152},
{"f_5174:eval_scm",(void*)f_5174},
{"f_5190:eval_scm",(void*)f_5190},
{"f_5164:eval_scm",(void*)f_5164},
{"f_5146:eval_scm",(void*)f_5146},
{"f_5122:eval_scm",(void*)f_5122},
{"f_5083:eval_scm",(void*)f_5083},
{"f_5086:eval_scm",(void*)f_5086},
{"f_5089:eval_scm",(void*)f_5089},
{"f_5112:eval_scm",(void*)f_5112},
{"f_5110:eval_scm",(void*)f_5110},
{"f_5106:eval_scm",(void*)f_5106},
{"f_5096:eval_scm",(void*)f_5096},
{"f_5066:eval_scm",(void*)f_5066},
{"f_5070:eval_scm",(void*)f_5070},
{"f_5037:eval_scm",(void*)f_5037},
{"f_5041:eval_scm",(void*)f_5041},
{"f_4814:eval_scm",(void*)f_4814},
{"f_5008:eval_scm",(void*)f_5008},
{"f_4956:eval_scm",(void*)f_4956},
{"f_4980:eval_scm",(void*)f_4980},
{"f_4969:eval_scm",(void*)f_4969},
{"f_4820:eval_scm",(void*)f_4820},
{"f_4948:eval_scm",(void*)f_4948},
{"f_4823:eval_scm",(void*)f_4823},
{"f_4826:eval_scm",(void*)f_4826},
{"f_4854:eval_scm",(void*)f_4854},
{"f_4864:eval_scm",(void*)f_4864},
{"f_4945:eval_scm",(void*)f_4945},
{"f_4937:eval_scm",(void*)f_4937},
{"f_4874:eval_scm",(void*)f_4874},
{"f_4922:eval_scm",(void*)f_4922},
{"f_4877:eval_scm",(void*)f_4877},
{"f_4878:eval_scm",(void*)f_4878},
{"f_4884:eval_scm",(void*)f_4884},
{"f_4906:eval_scm",(void*)f_4906},
{"f_4827:eval_scm",(void*)f_4827},
{"f_4831:eval_scm",(void*)f_4831},
{"f_4834:eval_scm",(void*)f_4834},
{"f_4838:eval_scm",(void*)f_4838},
{"f_4841:eval_scm",(void*)f_4841},
{"f_4845:eval_scm",(void*)f_4845},
{"f_4848:eval_scm",(void*)f_4848},
{"f_4801:eval_scm",(void*)f_4801},
{"f_4765:eval_scm",(void*)f_4765},
{"f_4678:eval_scm",(void*)f_4678},
{"f_4681:eval_scm",(void*)f_4681},
{"f_4722:eval_scm",(void*)f_4722},
{"f_4734:eval_scm",(void*)f_4734},
{"f_4684:eval_scm",(void*)f_4684},
{"f_4687:eval_scm",(void*)f_4687},
{"f_4712:eval_scm",(void*)f_4712},
{"f_4690:eval_scm",(void*)f_4690},
{"f_4700:eval_scm",(void*)f_4700},
{"f_4708:eval_scm",(void*)f_4708},
{"f_4704:eval_scm",(void*)f_4704},
{"f_4693:eval_scm",(void*)f_4693},
{"f_4594:eval_scm",(void*)f_4594},
{"f_4642:eval_scm",(void*)f_4642},
{"f_4658:eval_scm",(void*)f_4658},
{"f_4654:eval_scm",(void*)f_4654},
{"f_4597:eval_scm",(void*)f_4597},
{"f_4600:eval_scm",(void*)f_4600},
{"f_4610:eval_scm",(void*)f_4610},
{"f_4616:eval_scm",(void*)f_4616},
{"f_4541:eval_scm",(void*)f_4541},
{"f_4561:eval_scm",(void*)f_4561},
{"f_4577:eval_scm",(void*)f_4577},
{"f_4573:eval_scm",(void*)f_4573},
{"f_4559:eval_scm",(void*)f_4559},
{"f_4544:eval_scm",(void*)f_4544},
{"f_4551:eval_scm",(void*)f_4551},
{"f_4177:eval_scm",(void*)f_4177},
{"f_4514:eval_scm",(void*)f_4514},
{"f_4525:eval_scm",(void*)f_4525},
{"f_4519:eval_scm",(void*)f_4519},
{"f_4189:eval_scm",(void*)f_4189},
{"f_4194:eval_scm",(void*)f_4194},
{"f_4198:eval_scm",(void*)f_4198},
{"f_4511:eval_scm",(void*)f_4511},
{"f_4201:eval_scm",(void*)f_4201},
{"f_4503:eval_scm",(void*)f_4503},
{"f_4207:eval_scm",(void*)f_4207},
{"f_4465:eval_scm",(void*)f_4465},
{"f_4471:eval_scm",(void*)f_4471},
{"f_4495:eval_scm",(void*)f_4495},
{"f_4442:eval_scm",(void*)f_4442},
{"f_4448:eval_scm",(void*)f_4448},
{"f_5479:eval_scm",(void*)f_5479},
{"f_5508:eval_scm",(void*)f_5508},
{"f_4464:eval_scm",(void*)f_4464},
{"f_4460:eval_scm",(void*)f_4460},
{"f_4420:eval_scm",(void*)f_4420},
{"f_4426:eval_scm",(void*)f_4426},
{"f_4438:eval_scm",(void*)f_4438},
{"f_4401:eval_scm",(void*)f_4401},
{"f_4407:eval_scm",(void*)f_4407},
{"f_4373:eval_scm",(void*)f_4373},
{"f_4379:eval_scm",(void*)f_4379},
{"f_4354:eval_scm",(void*)f_4354},
{"f_4360:eval_scm",(void*)f_4360},
{"f_4326:eval_scm",(void*)f_4326},
{"f_4332:eval_scm",(void*)f_4332},
{"f_4307:eval_scm",(void*)f_4307},
{"f_4313:eval_scm",(void*)f_4313},
{"f_4279:eval_scm",(void*)f_4279},
{"f_4285:eval_scm",(void*)f_4285},
{"f_4260:eval_scm",(void*)f_4260},
{"f_4266:eval_scm",(void*)f_4266},
{"f_4236:eval_scm",(void*)f_4236},
{"f_4242:eval_scm",(void*)f_4242},
{"f_4217:eval_scm",(void*)f_4217},
{"f_4223:eval_scm",(void*)f_4223},
{"f_4088:eval_scm",(void*)f_4088},
{"f_4157:eval_scm",(void*)f_4157},
{"f_4109:eval_scm",(void*)f_4109},
{"f_4135:eval_scm",(void*)f_4135},
{"f_4117:eval_scm",(void*)f_4117},
{"f_4133:eval_scm",(void*)f_4133},
{"f_4113:eval_scm",(void*)f_4113},
{"f_3743:eval_scm",(void*)f_3743},
{"f_4072:eval_scm",(void*)f_4072},
{"f_3752:eval_scm",(void*)f_3752},
{"f_3755:eval_scm",(void*)f_3755},
{"f_4070:eval_scm",(void*)f_4070},
{"f_3761:eval_scm",(void*)f_3761},
{"f_4062:eval_scm",(void*)f_4062},
{"f_3764:eval_scm",(void*)f_3764},
{"f_4046:eval_scm",(void*)f_4046},
{"f_3999:eval_scm",(void*)f_3999},
{"f_4000:eval_scm",(void*)f_4000},
{"f_4004:eval_scm",(void*)f_4004},
{"f_4016:eval_scm",(void*)f_4016},
{"f_4041:eval_scm",(void*)f_4041},
{"f_4007:eval_scm",(void*)f_4007},
{"f_3923:eval_scm",(void*)f_3923},
{"f_3926:eval_scm",(void*)f_3926},
{"f_3932:eval_scm",(void*)f_3932},
{"f_3935:eval_scm",(void*)f_3935},
{"f_3936:eval_scm",(void*)f_3936},
{"f_3952:eval_scm",(void*)f_3952},
{"f_3956:eval_scm",(void*)f_3956},
{"f_3960:eval_scm",(void*)f_3960},
{"f_3964:eval_scm",(void*)f_3964},
{"f_3856:eval_scm",(void*)f_3856},
{"f_3859:eval_scm",(void*)f_3859},
{"f_3865:eval_scm",(void*)f_3865},
{"f_3866:eval_scm",(void*)f_3866},
{"f_3882:eval_scm",(void*)f_3882},
{"f_3886:eval_scm",(void*)f_3886},
{"f_3890:eval_scm",(void*)f_3890},
{"f_3807:eval_scm",(void*)f_3807},
{"f_3810:eval_scm",(void*)f_3810},
{"f_3811:eval_scm",(void*)f_3811},
{"f_3827:eval_scm",(void*)f_3827},
{"f_3831:eval_scm",(void*)f_3831},
{"f_3773:eval_scm",(void*)f_3773},
{"f_3774:eval_scm",(void*)f_3774},
{"f_3790:eval_scm",(void*)f_3790},
{"f_3631:eval_scm",(void*)f_3631},
{"f_3645:eval_scm",(void*)f_3645},
{"f_3649:eval_scm",(void*)f_3649},
{"f_3658:eval_scm",(void*)f_3658},
{"f_3691:eval_scm",(void*)f_3691},
{"f_3699:eval_scm",(void*)f_3699},
{"f_3664:eval_scm",(void*)f_3664},
{"f_3667:eval_scm",(void*)f_3667},
{"f_3683:eval_scm",(void*)f_3683},
{"f_3674:eval_scm",(void*)f_3674},
{"f_3682:eval_scm",(void*)f_3682},
{"f_3719:eval_scm",(void*)f_3719},
{"f_3727:eval_scm",(void*)f_3727},
{"f_3706:eval_scm",(void*)f_3706},
{"f_3718:eval_scm",(void*)f_3718},
{"f_3639:eval_scm",(void*)f_3639},
{"f_3519:eval_scm",(void*)f_3519},
{"f_3578:eval_scm",(void*)f_3578},
{"f_3581:eval_scm",(void*)f_3581},
{"f_3603:eval_scm",(void*)f_3603},
{"f_3584:eval_scm",(void*)f_3584},
{"f_3585:eval_scm",(void*)f_3585},
{"f_3589:eval_scm",(void*)f_3589},
{"f_3592:eval_scm",(void*)f_3592},
{"f_3556:eval_scm",(void*)f_3556},
{"f_3559:eval_scm",(void*)f_3559},
{"f_3560:eval_scm",(void*)f_3560},
{"f_3564:eval_scm",(void*)f_3564},
{"f_3459:eval_scm",(void*)f_3459},
{"f_3462:eval_scm",(void*)f_3462},
{"f_3465:eval_scm",(void*)f_3465},
{"f_3468:eval_scm",(void*)f_3468},
{"f_3469:eval_scm",(void*)f_3469},
{"f_3476:eval_scm",(void*)f_3476},
{"f_3449:eval_scm",(void*)f_3449},
{"f_3415:eval_scm",(void*)f_3415},
{"f_3409:eval_scm",(void*)f_3409},
{"f_3410:eval_scm",(void*)f_3410},
{"f_3393:eval_scm",(void*)f_3393},
{"f_3315:eval_scm",(void*)f_3315},
{"f_3318:eval_scm",(void*)f_3318},
{"f_3375:eval_scm",(void*)f_3375},
{"f_3373:eval_scm",(void*)f_3373},
{"f_3365:eval_scm",(void*)f_3365},
{"f_3357:eval_scm",(void*)f_3357},
{"f_3349:eval_scm",(void*)f_3349},
{"f_3341:eval_scm",(void*)f_3341},
{"f_3333:eval_scm",(void*)f_3333},
{"f_3325:eval_scm",(void*)f_3325},
{"f_3269:eval_scm",(void*)f_3269},
{"f_3258:eval_scm",(void*)f_3258},
{"f_3256:eval_scm",(void*)f_3256},
{"f_3245:eval_scm",(void*)f_3245},
{"f_3243:eval_scm",(void*)f_3243},
{"f_3235:eval_scm",(void*)f_3235},
{"f_3227:eval_scm",(void*)f_3227},
{"f_3219:eval_scm",(void*)f_3219},
{"f_3111:eval_scm",(void*)f_3111},
{"f_3179:eval_scm",(void*)f_3179},
{"f_3121:eval_scm",(void*)f_3121},
{"f_3170:eval_scm",(void*)f_3170},
{"f_3155:eval_scm",(void*)f_3155},
{"f_3150:eval_scm",(void*)f_3150},
{"f_3151:eval_scm",(void*)f_3151},
{"f_3127:eval_scm",(void*)f_3127},
{"f_3130:eval_scm",(void*)f_3130},
{"f_3131:eval_scm",(void*)f_3131},
{"f_3202:eval_scm",(void*)f_3202},
{"f_3193:eval_scm",(void*)f_3193},
{"f_3105:eval_scm",(void*)f_3105},
{"f_3093:eval_scm",(void*)f_3093},
{"f_3034:eval_scm",(void*)f_3034},
{"f_3038:eval_scm",(void*)f_3038},
{"f_3059:eval_scm",(void*)f_3059},
{"f_3070:eval_scm",(void*)f_3070},
{"f_3066:eval_scm",(void*)f_3066},
{"f_3039:eval_scm",(void*)f_3039},
{"f_3043:eval_scm",(void*)f_3043},
{"f_3046:eval_scm",(void*)f_3046},
{"f_3050:eval_scm",(void*)f_3050},
{"f_3053:eval_scm",(void*)f_3053},
{"f_3028:eval_scm",(void*)f_3028},
{"f_2932:eval_scm",(void*)f_2932},
{"f_2936:eval_scm",(void*)f_2936},
{"f_2944:eval_scm",(void*)f_2944},
{"f_2986:eval_scm",(void*)f_2986},
{"f_2917:eval_scm",(void*)f_2917},
{"f_2921:eval_scm",(void*)f_2921},
{"f_2927:eval_scm",(void*)f_2927},
{"f_2878:eval_scm",(void*)f_2878},
{"f_2891:eval_scm",(void*)f_2891},
{"f_2828:eval_scm",(void*)f_2828},
{"f_2847:eval_scm",(void*)f_2847},
{"f_2859:eval_scm",(void*)f_2859},
{"f_2862:eval_scm",(void*)f_2862},
{"f_2865:eval_scm",(void*)f_2865},
{"f_2855:eval_scm",(void*)f_2855},
{"f_2834:eval_scm",(void*)f_2834},
{"f_2768:eval_scm",(void*)f_2768},
{"f_2772:eval_scm",(void*)f_2772},
{"f_2780:eval_scm",(void*)f_2780},
{"f_2706:eval_scm",(void*)f_2706},
{"f_2712:eval_scm",(void*)f_2712},
{"f_2735:eval_scm",(void*)f_2735},
{"f_2748:eval_scm",(void*)f_2748},
{"f_2722:eval_scm",(void*)f_2722},
{"f_2686:eval_scm",(void*)f_2686},
{"f_2698:eval_scm",(void*)f_2698},
{"f_2701:eval_scm",(void*)f_2701},
{"f_2694:eval_scm",(void*)f_2694},
{"f_2626:eval_scm",(void*)f_2626},
{"f_2630:eval_scm",(void*)f_2630},
{"f_2638:eval_scm",(void*)f_2638},
{"f_2571:eval_scm",(void*)f_2571},
{"f_2624:eval_scm",(void*)f_2624},
{"f_2581:eval_scm",(void*)f_2581},
{"f_2556:eval_scm",(void*)f_2556},
{"f_2544:eval_scm",(void*)f_2544},
{"f_2548:eval_scm",(void*)f_2548},
{"f_2517:eval_scm",(void*)f_2517},
{"f_2482:eval_scm",(void*)f_2482},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
