/* Generated from support.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-12-14 09:04
   Version 4.2.0 - SVN rev. 16023
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-12-14 on galinha (Linux)
   command line: support.scm -optimize-level 2 -include-path . -include-path ./ -inline -no-lambda-info -local -no-trace -extend private-namespace.scm -no-trace -output-file support.c
   unit: support
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[499];
static double C_possibly_force_alignment;


/* from k3819 */
static C_word C_fcall stub270(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub270(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_wordstobytes(t0));
return C_r;}

/* from k3812 */
static C_word C_fcall stub266(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub266(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_bytestowords(t0));
return C_r;}

C_noret_decl(C_support_toplevel)
C_externexport void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3188)
static void C_ccall f_3188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3191)
static void C_ccall f_3191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3194)
static void C_ccall f_3194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3197)
static void C_ccall f_3197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3200)
static void C_ccall f_3200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3203)
static void C_ccall f_3203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4275)
static void C_ccall f_4275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4278)
static void C_ccall f_4278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11196)
static void C_ccall f_11196(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11200)
static void C_ccall f_11200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11284)
static void C_ccall f_11284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11206)
static void C_ccall f_11206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11271)
static void C_ccall f_11271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11274)
static void C_ccall f_11274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11277)
static void C_ccall f_11277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11212)
static void C_ccall f_11212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11219)
static void C_ccall f_11219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11221)
static void C_fcall f_11221(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11253)
static void C_ccall f_11253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11249)
static void C_ccall f_11249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11234)
static void C_ccall f_11234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11190)
static void C_ccall f_11190(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11184)
static void C_ccall f_11184(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11178)
static void C_ccall f_11178(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11150)
static void C_ccall f_11150(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_11150)
static void C_ccall f_11150r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_11154)
static void C_ccall f_11154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11129)
static void C_ccall f_11129(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11133)
static void C_ccall f_11133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11096)
static void C_ccall f_11096(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11102)
static void C_ccall f_11102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11063)
static void C_ccall f_11063(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11069)
static void C_ccall f_11069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11039)
static void C_ccall f_11039(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10970)
static void C_ccall f_10970(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10974)
static void C_ccall f_10974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10979)
static void C_fcall f_10979(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10983)
static void C_ccall f_10983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11034)
static void C_ccall f_11034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11013)
static void C_ccall f_11013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11025)
static void C_ccall f_11025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11028)
static void C_ccall f_11028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11001)
static void C_ccall f_11001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10937)
static void C_ccall f_10937(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10947)
static void C_ccall f_10947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10950)
static void C_ccall f_10950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10813)
static void C_ccall f_10813(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10822)
static void C_fcall f_10822(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10835)
static void C_ccall f_10835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10841)
static void C_ccall f_10841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10844)
static void C_ccall f_10844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10847)
static void C_ccall f_10847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10850)
static void C_ccall f_10850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10853)
static void C_ccall f_10853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10856)
static void C_ccall f_10856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10915)
static void C_fcall f_10915(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10928)
static void C_ccall f_10928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10859)
static void C_ccall f_10859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10874)
static void C_ccall f_10874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10877)
static void C_ccall f_10877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10885)
static void C_fcall f_10885(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10895)
static void C_ccall f_10895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10898)
static void C_ccall f_10898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10880)
static void C_ccall f_10880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10865)
static void C_ccall f_10865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10817)
static void C_ccall f_10817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10810)
static void C_ccall f_10810(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10792)
static void C_ccall f_10792(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10746)
static void C_ccall f_10746(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10765)
static void C_ccall f_10765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10776)
static void C_ccall f_10776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10772)
static void C_ccall f_10772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10725)
static void C_ccall f_10725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10731)
static void C_ccall f_10731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10735)
static void C_ccall f_10735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10738)
static void C_ccall f_10738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10741)
static void C_ccall f_10741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10713)
static void C_ccall f_10713(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10717)
static void C_ccall f_10717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10622)
static void C_ccall f_10622(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_10622)
static void C_ccall f_10622r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_10641)
static void C_ccall f_10641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10666)
static void C_ccall f_10666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10670)
static void C_ccall f_10670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10672)
static void C_fcall f_10672(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10679)
static void C_ccall f_10679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10692)
static void C_ccall f_10692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10695)
static void C_ccall f_10695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10698)
static void C_ccall f_10698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10701)
static void C_ccall f_10701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10704)
static void C_ccall f_10704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10708)
static void C_ccall f_10708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10625)
static void C_fcall f_10625(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10629)
static void C_ccall f_10629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10635)
static void C_ccall f_10635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10616)
static void C_ccall f_10616(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10557)
static void C_ccall f_10557(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_10557)
static void C_ccall f_10557r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_10565)
static void C_ccall f_10565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10592)
static void C_ccall f_10592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10568)
static void C_ccall f_10568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10571)
static void C_ccall f_10571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10588)
static void C_ccall f_10588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10574)
static void C_ccall f_10574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10584)
static void C_ccall f_10584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10577)
static void C_ccall f_10577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10580)
static void C_ccall f_10580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10548)
static void C_ccall f_10548(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10542)
static void C_ccall f_10542(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10536)
static void C_ccall f_10536(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10524)
static void C_ccall f_10524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10528)
static void C_ccall f_10528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10531)
static void C_ccall f_10531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10486)
static void C_ccall f_10486(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_10486)
static void C_ccall f_10486r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_10490)
static void C_ccall f_10490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10493)
static void C_ccall f_10493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10500)
static void C_ccall f_10500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10444)
static void C_ccall f_10444(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10453)
static void C_fcall f_10453(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10415)
static void C_ccall f_10415(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10425)
static void C_fcall f_10425(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10227)
static void C_ccall f_10227(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10410)
static void C_ccall f_10410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10381)
static void C_fcall f_10381(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10387)
static void C_fcall f_10387(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10400)
static void C_ccall f_10400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10230)
static void C_fcall f_10230(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10249)
static void C_fcall f_10249(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10343)
static void C_ccall f_10343(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10355)
static void C_ccall f_10355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10313)
static void C_ccall f_10313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10324)
static void C_ccall f_10324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10304)
static void C_ccall f_10304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10290)
static void C_fcall f_10290(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10268)
static void C_ccall f_10268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10274)
static void C_ccall f_10274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10278)
static void C_ccall f_10278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10103)
static void C_ccall f_10103(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10109)
static void C_fcall f_10109(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10187)
static void C_fcall f_10187(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10192)
static void C_fcall f_10192(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10202)
static void C_ccall f_10202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10160)
static void C_fcall f_10160(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10131)
static void C_fcall f_10131(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10136)
static void C_fcall f_10136(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10146)
static void C_ccall f_10146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10107)
static void C_ccall f_10107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9734)
static void C_ccall f_9734(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9933)
static void C_fcall f_9933(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10025)
static void C_fcall f_10025(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9936)
static void C_ccall f_9936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9418)
static void C_ccall f_9418(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9728)
static void C_ccall f_9728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9430)
static void C_ccall f_9430(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9440)
static void C_fcall f_9440(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9458)
static void C_ccall f_9458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9492)
static void C_fcall f_9492(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9421)
static void C_fcall f_9421(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9093)
static void C_ccall f_9093(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9412)
static void C_ccall f_9412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9099)
static void C_ccall f_9099(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9109)
static void C_fcall f_9109(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9118)
static void C_fcall f_9118(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9130)
static void C_fcall f_9130(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9142)
static void C_fcall f_9142(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9148)
static void C_ccall f_9148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9182)
static void C_fcall f_9182(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9053)
static void C_ccall f_9053(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9087)
static void C_ccall f_9087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9059)
static void C_ccall f_9059(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9063)
static void C_ccall f_9063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9022)
static void C_ccall f_9022(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9035)
static void C_ccall f_9035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9026)
static void C_fcall f_9026(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8991)
static void C_ccall f_8991(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9004)
static void C_ccall f_9004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8995)
static void C_fcall f_8995(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7938)
static void C_ccall f_7938(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8985)
static void C_ccall f_8985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7944)
static void C_ccall f_7944(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7950)
static void C_fcall f_7950(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7979)
static void C_fcall f_7979(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7998)
static void C_fcall f_7998(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8017)
static void C_fcall f_8017(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8087)
static void C_fcall f_8087(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8106)
static void C_fcall f_8106(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8188)
static void C_fcall f_8188(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8227)
static void C_fcall f_8227(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8246)
static void C_fcall f_8246(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8265)
static void C_fcall f_8265(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8345)
static void C_fcall f_8345(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8430)
static void C_fcall f_8430(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8505)
static void C_ccall f_8505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8539)
static void C_fcall f_8539(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8609)
static void C_ccall f_8609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8542)
static void C_ccall f_8542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8348)
static void C_ccall f_8348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8379)
static void C_fcall f_8379(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8268)
static void C_ccall f_8268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8109)
static void C_ccall f_8109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8140)
static void C_fcall f_8140(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8020)
static void C_ccall f_8020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8051)
static void C_fcall f_8051(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7886)
static void C_ccall f_7886(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7890)
static void C_ccall f_7890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7901)
static void C_ccall f_7901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7907)
static void C_fcall f_7907(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7920)
static void C_ccall f_7920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7923)
static void C_ccall f_7923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7893)
static void C_ccall f_7893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7805)
static void C_ccall f_7805(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7817)
static void C_ccall f_7817(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_7824)
static void C_ccall f_7824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7827)
static void C_ccall f_7827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7830)
static void C_ccall f_7830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7833)
static void C_ccall f_7833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7836)
static void C_ccall f_7836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7839)
static void C_ccall f_7839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7842)
static void C_ccall f_7842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7845)
static void C_ccall f_7845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7848)
static void C_ccall f_7848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7851)
static void C_ccall f_7851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7854)
static void C_ccall f_7854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7857)
static void C_ccall f_7857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7860)
static void C_ccall f_7860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7863)
static void C_ccall f_7863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7866)
static void C_ccall f_7866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7869)
static void C_ccall f_7869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7872)
static void C_ccall f_7872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7875)
static void C_ccall f_7875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7878)
static void C_ccall f_7878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7881)
static void C_ccall f_7881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7811)
static void C_ccall f_7811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7709)
static void C_ccall f_7709(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7718)
static void C_ccall f_7718(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7724)
static void C_fcall f_7724(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7744)
static void C_fcall f_7744(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7713)
static void C_ccall f_7713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7688)
static void C_ccall f_7688(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7698)
static void C_ccall f_7698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7639)
static void C_ccall f_7639(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7645)
static void C_ccall f_7645(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7686)
static void C_ccall f_7686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7669)
static void C_fcall f_7669(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7658)
static void C_ccall f_7658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7602)
static void C_ccall f_7602(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7608)
static void C_ccall f_7608(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7637)
static void C_ccall f_7637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7615)
static void C_fcall f_7615(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7618)
static void C_ccall f_7618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7561)
static void C_ccall f_7561(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7567)
static void C_ccall f_7567(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7600)
static void C_ccall f_7600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7574)
static void C_fcall f_7574(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7577)
static void C_ccall f_7577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7469)
static void C_ccall f_7469(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7493)
static void C_ccall f_7493(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7383)
static void C_ccall f_7383(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7389)
static void C_ccall f_7389(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7405)
static void C_fcall f_7405(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7419)
static void C_ccall f_7419(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7427)
static void C_ccall f_7427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7188)
static void C_ccall f_7188(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7367)
static void C_ccall f_7367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7373)
static void C_ccall f_7373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7263)
static void C_fcall f_7263(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7285)
static void C_ccall f_7285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7298)
static void C_fcall f_7298(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7329)
static void C_ccall f_7329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7220)
static void C_fcall f_7220(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7242)
static void C_ccall f_7242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7191)
static void C_fcall f_7191(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7215)
static void C_ccall f_7215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7119)
static void C_ccall f_7119(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7125)
static void C_ccall f_7125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7131)
static void C_fcall f_7131(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7135)
static void C_ccall f_7135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7182)
static void C_ccall f_7182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7146)
static void C_ccall f_7146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7171)
static void C_ccall f_7171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6933)
static void C_ccall f_6933(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6980)
static void C_ccall f_6980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7117)
static void C_ccall f_7117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6984)
static void C_ccall f_6984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6992)
static void C_ccall f_6992(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6999)
static void C_ccall f_6999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7110)
static void C_ccall f_7110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7023)
static void C_fcall f_7023(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7095)
static void C_ccall f_7095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7050)
static void C_ccall f_7050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7053)
static void C_fcall f_7053(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7071)
static void C_ccall f_7071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7060)
static void C_ccall f_7060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6987)
static void C_ccall f_6987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6937)
static void C_ccall f_6937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6943)
static void C_ccall f_6943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6950)
static void C_ccall f_6950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6952)
static void C_fcall f_6952(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6965)
static void C_ccall f_6965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6908)
static void C_ccall f_6908(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6914)
static void C_ccall f_6914(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6924)
static void C_ccall f_6924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6872)
static void C_ccall f_6872(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6878)
static void C_ccall f_6878(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6902)
static void C_ccall f_6902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6898)
static void C_ccall f_6898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6848)
static void C_ccall f_6848(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6852)
static void C_ccall f_6852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6855)
static void C_ccall f_6855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6858)
static void C_ccall f_6858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6814)
static void C_ccall f_6814(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6820)
static void C_fcall f_6820(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6834)
static void C_ccall f_6834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6838)
static void C_ccall f_6838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6604)
static void C_ccall f_6604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6608)
static void C_ccall f_6608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6616)
static void C_fcall f_6616(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6797)
static void C_ccall f_6797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6805)
static void C_ccall f_6805(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6800)
static void C_ccall f_6800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6736)
static void C_ccall f_6736(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6787)
static void C_ccall f_6787(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6791)
static void C_ccall f_6791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6794)
static void C_ccall f_6794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6740)
static void C_ccall f_6740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6785)
static void C_ccall f_6785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6743)
static void C_ccall f_6743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6762)
static void C_ccall f_6762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6778)
static void C_ccall f_6778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6770)
static void C_ccall f_6770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6754)
static void C_ccall f_6754(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6749)
static void C_ccall f_6749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6694)
static void C_ccall f_6694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6697)
static void C_ccall f_6697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6700)
static void C_ccall f_6700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6713)
static void C_ccall f_6713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6678)
static void C_ccall f_6678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6670)
static void C_ccall f_6670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6648)
static void C_ccall f_6648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6638)
static void C_ccall f_6638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6645)
static void C_ccall f_6645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6610)
static void C_fcall f_6610(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6511)
static void C_ccall f_6511(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_6517)
static void C_ccall f_6517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6529)
static void C_ccall f_6529(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6533)
static void C_ccall f_6533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6536)
static void C_ccall f_6536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6596)
static void C_ccall f_6596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6572)
static void C_fcall f_6572(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6555)
static void C_fcall f_6555(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6559)
static void C_ccall f_6559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6541)
static void C_ccall f_6541(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6523)
static void C_ccall f_6523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6463)
static void C_ccall f_6463(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6469)
static void C_fcall f_6469(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6489)
static void C_ccall f_6489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6493)
static void C_ccall f_6493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6145)
static void C_ccall f_6145(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6151)
static void C_ccall f_6151(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6170)
static void C_fcall f_6170(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6404)
static void C_fcall f_6404(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6434)
static void C_ccall f_6434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6430)
static void C_ccall f_6430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6411)
static void C_ccall f_6411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6415)
static void C_ccall f_6415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6342)
static void C_fcall f_6342(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6391)
static void C_ccall f_6391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6360)
static void C_ccall f_6360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6368)
static void C_ccall f_6368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6318)
static void C_ccall f_6318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6285)
static void C_ccall f_6285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6264)
static void C_ccall f_6264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6260)
static void C_ccall f_6260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6244)
static void C_ccall f_6244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6256)
static void C_ccall f_6256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6252)
static void C_ccall f_6252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6198)
static void C_ccall f_6198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6194)
static void C_ccall f_6194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6177)
static void C_ccall f_6177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5631)
static void C_ccall f_5631(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6140)
static void C_ccall f_6140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6143)
static void C_ccall f_6143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5634)
static void C_ccall f_5634(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6130)
static void C_ccall f_6130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6010)
static void C_fcall f_6010(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6053)
static void C_ccall f_6053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6090)
static void C_ccall f_6090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6067)
static void C_fcall f_6067(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6074)
static void C_ccall f_6074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6081)
static void C_ccall f_6081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6071)
static void C_ccall f_6071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6060)
static void C_ccall f_6060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6047)
static void C_ccall f_6047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6035)
static void C_ccall f_6035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6019)
static void C_ccall f_6019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5989)
static void C_ccall f_5989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5973)
static void C_ccall f_5973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5969)
static void C_ccall f_5969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5936)
static void C_ccall f_5936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5894)
static void C_ccall f_5894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5863)
static void C_fcall f_5863(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5849)
static void C_ccall f_5849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5823)
static void C_ccall f_5823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5769)
static void C_ccall f_5769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5789)
static void C_ccall f_5789(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5779)
static void C_ccall f_5779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5787)
static void C_ccall f_5787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5772)
static void C_ccall f_5772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5719)
static void C_fcall f_5719(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5722)
static void C_ccall f_5722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5729)
static void C_ccall f_5729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5716)
static void C_fcall f_5716(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5693)
static void C_ccall f_5693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5622)
static void C_ccall f_5622(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5613)
static void C_ccall f_5613(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5607)
static void C_ccall f_5607(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5598)
static void C_ccall f_5598(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5589)
static void C_ccall f_5589(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5580)
static void C_ccall f_5580(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5571)
static void C_ccall f_5571(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5562)
static void C_ccall f_5562(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5553)
static void C_ccall f_5553(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5547)
static void C_ccall f_5547(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5541)
static void C_ccall f_5541(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5066)
static void C_ccall f_5066(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5539)
static void C_ccall f_5539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5070)
static void C_fcall f_5070(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5075)
static void C_ccall f_5075(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5085)
static void C_ccall f_5085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5218)
static void C_fcall f_5218(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5228)
static void C_ccall f_5228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5244)
static void C_fcall f_5244(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5320)
static void C_fcall f_5320(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5360)
static void C_ccall f_5360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5350)
static void C_ccall f_5350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5323)
static void C_ccall f_5323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5340)
static void C_ccall f_5340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5326)
static void C_ccall f_5326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5329)
static void C_ccall f_5329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5336)
static void C_ccall f_5336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5311)
static void C_ccall f_5311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5301)
static void C_ccall f_5301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5285)
static void C_ccall f_5285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5247)
static void C_ccall f_5247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5262)
static void C_ccall f_5262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5231)
static void C_ccall f_5231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5088)
static void C_ccall f_5088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5129)
static void C_fcall f_5129(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5153)
static void C_fcall f_5153(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5177)
static void C_fcall f_5177(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5180)
static void C_ccall f_5180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5156)
static void C_ccall f_5156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5132)
static void C_ccall f_5132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5091)
static void C_ccall f_5091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5119)
static void C_ccall f_5119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5094)
static void C_ccall f_5094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5106)
static void C_ccall f_5106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5097)
static void C_ccall f_5097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5038)
static void C_ccall f_5038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5044)
static void C_ccall f_5044(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5051)
static void C_ccall f_5051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5054)
static void C_ccall f_5054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5064)
static void C_ccall f_5064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5057)
static void C_ccall f_5057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5014)
static void C_ccall f_5014(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5020)
static void C_fcall f_5020(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5030)
static void C_ccall f_5030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4978)
static void C_ccall f_4978(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4985)
static void C_ccall f_4985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4988)
static void C_fcall f_4988(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4968)
static void C_ccall f_4968(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4959)
static void C_ccall f_4959(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4963)
static void C_ccall f_4963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4902)
static void C_ccall f_4902(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_4902)
static void C_ccall f_4902r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_4906)
static void C_ccall f_4906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4936)
static void C_ccall f_4936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4850)
static void C_ccall f_4850(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4854)
static void C_ccall f_4854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4881)
static void C_ccall f_4881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4804)
static void C_ccall f_4804(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4808)
static void C_ccall f_4808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4830)
static void C_ccall f_4830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4786)
static void C_ccall f_4786(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4786)
static void C_ccall f_4786r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4790)
static void C_ccall f_4790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4798)
static void C_ccall f_4798(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4768)
static void C_ccall f_4768(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4772)
static void C_ccall f_4772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4533)
static void C_ccall f_4533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4683)
static void C_fcall f_4683(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4698)
static void C_ccall f_4698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4723)
static void C_ccall f_4723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4741)
static void C_ccall f_4741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4726)
static void C_ccall f_4726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4541)
static void C_ccall f_4541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4598)
static void C_fcall f_4598(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4613)
static void C_ccall f_4613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4638)
static void C_ccall f_4638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4656)
static void C_ccall f_4656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4641)
static void C_ccall f_4641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4544)
static void C_ccall f_4544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4549)
static void C_fcall f_4549(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4564)
static void C_ccall f_4564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4589)
static void C_ccall f_4589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4537)
static void C_ccall f_4537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4392)
static void C_ccall f_4392(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4396)
static void C_ccall f_4396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4400)
static void C_ccall f_4400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4389)
static void C_ccall f_4389(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4386)
static void C_ccall f_4386(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4279)
static void C_ccall f_4279(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4288)
static void C_ccall f_4288(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4319)
static void C_ccall f_4319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4373)
static void C_ccall f_4373(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4373)
static void C_ccall f_4373r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4379)
static void C_ccall f_4379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4325)
static void C_ccall f_4325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4357)
static void C_ccall f_4357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4371)
static void C_ccall f_4371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4363)
static void C_ccall f_4363(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4329)
static void C_ccall f_4329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4351)
static void C_ccall f_4351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4294)
static void C_ccall f_4294(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4300)
static void C_ccall f_4300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4311)
static void C_ccall f_4311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4308)
static void C_ccall f_4308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4286)
static void C_ccall f_4286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4178)
static void C_ccall f_4178(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4184)
static void C_fcall f_4184(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4261)
static void C_ccall f_4261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4212)
static void C_fcall f_4212(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4250)
static void C_ccall f_4250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4238)
static void C_ccall f_4238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4118)
static void C_ccall f_4118(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4134)
static void C_ccall f_4134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4176)
static void C_ccall f_4176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4140)
static void C_ccall f_4140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4155)
static void C_ccall f_4155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4072)
static void C_ccall f_4072(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4116)
static void C_ccall f_4116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4076)
static void C_fcall f_4076(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4042)
static void C_ccall f_4042(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3996)
static void C_ccall f_3996(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3976)
static void C_ccall f_3976(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3982)
static void C_ccall f_3982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3990)
static void C_ccall f_3990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3994)
static void C_ccall f_3994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3945)
static void C_ccall f_3945(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3951)
static void C_fcall f_3951(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3966)
static void C_ccall f_3966(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3882)
static void C_ccall f_3882(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3896)
static void C_ccall f_3896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3898)
static void C_fcall f_3898(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3927)
static void C_ccall f_3927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3906)
static void C_fcall f_3906(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3870)
static void C_ccall f_3870(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3823)
static void C_ccall f_3823(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3823)
static void C_ccall f_3823r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3839)
static void C_ccall f_3839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3851)
static void C_fcall f_3851(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3816)
static void C_ccall f_3816(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3809)
static void C_ccall f_3809(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3753)
static void C_ccall f_3753(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3807)
static void C_ccall f_3807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3757)
static void C_ccall f_3757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3780)
static void C_ccall f_3780(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3659)
static void C_ccall f_3659(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3675)
static void C_ccall f_3675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3677)
static void C_fcall f_3677(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3699)
static void C_fcall f_3699(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3738)
static void C_ccall f_3738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3706)
static void C_fcall f_3706(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3722)
static void C_ccall f_3722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3710)
static void C_ccall f_3710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3714)
static void C_ccall f_3714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3671)
static void C_ccall f_3671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3615)
static void C_ccall f_3615(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3621)
static void C_fcall f_3621(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3645)
static void C_ccall f_3645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3584)
static void C_ccall f_3584(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3607)
static void C_ccall f_3607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3610)
static void C_ccall f_3610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3613)
static void C_ccall f_3613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3557)
static void C_ccall f_3557(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3576)
static void C_ccall f_3576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3579)
static void C_ccall f_3579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3521)
static void C_ccall f_3521(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3527)
static C_word C_fcall f_3527(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_3453)
static void C_ccall f_3453(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3477)
static void C_fcall f_3477(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3456)
static void C_fcall f_3456(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3464)
static void C_ccall f_3464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3468)
static void C_ccall f_3468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3410)
static void C_ccall f_3410(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3416)
static void C_fcall f_3416(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3439)
static void C_ccall f_3439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3443)
static void C_ccall f_3443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3407)
static void C_ccall f_3407(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3346)
static void C_ccall f_3346(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3346)
static void C_ccall f_3346r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3350)
static void C_ccall f_3350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3353)
static void C_fcall f_3353(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3356)
static void C_ccall f_3356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3367)
static void C_fcall f_3367(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3380)
static void C_ccall f_3380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3359)
static void C_ccall f_3359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3362)
static void C_ccall f_3362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3327)
static void C_ccall f_3327(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3327)
static void C_ccall f_3327r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3331)
static void C_ccall f_3331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3344)
static void C_ccall f_3344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3334)
static void C_ccall f_3334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3337)
static void C_ccall f_3337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3298)
static void C_ccall f_3298(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3298)
static void C_ccall f_3298r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3305)
static void C_fcall f_3305(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3308)
static void C_ccall f_3308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3318)
static void C_ccall f_3318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3311)
static void C_ccall f_3311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3239)
static void C_ccall f_3239(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3239)
static void C_ccall f_3239r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3249)
static void C_ccall f_3249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3264)
static void C_ccall f_3264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3269)
static void C_fcall f_3269(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3296)
static void C_ccall f_3296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3282)
static void C_ccall f_3282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3285)
static void C_ccall f_3285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3252)
static void C_ccall f_3252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3255)
static void C_ccall f_3255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3258)
static void C_ccall f_3258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3212)
static void C_ccall f_3212(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3212)
static void C_ccall f_3212r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3226)
static void C_ccall f_3226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3207)
static void C_ccall f_3207(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_11221)
static void C_fcall trf_11221(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11221(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11221(t0,t1,t2);}

C_noret_decl(trf_10979)
static void C_fcall trf_10979(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10979(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10979(t0,t1);}

C_noret_decl(trf_10822)
static void C_fcall trf_10822(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10822(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10822(t0,t1,t2,t3);}

C_noret_decl(trf_10915)
static void C_fcall trf_10915(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10915(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10915(t0,t1,t2);}

C_noret_decl(trf_10885)
static void C_fcall trf_10885(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10885(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10885(t0,t1,t2);}

C_noret_decl(trf_10672)
static void C_fcall trf_10672(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10672(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10672(t0,t1,t2,t3);}

C_noret_decl(trf_10625)
static void C_fcall trf_10625(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10625(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10625(t0,t1);}

C_noret_decl(trf_10453)
static void C_fcall trf_10453(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10453(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10453(t0,t1,t2);}

C_noret_decl(trf_10425)
static void C_fcall trf_10425(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10425(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10425(t0,t1);}

C_noret_decl(trf_10381)
static void C_fcall trf_10381(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10381(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10381(t0,t1,t2,t3);}

C_noret_decl(trf_10387)
static void C_fcall trf_10387(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10387(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10387(t0,t1,t2);}

C_noret_decl(trf_10230)
static void C_fcall trf_10230(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10230(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10230(t0,t1,t2,t3);}

C_noret_decl(trf_10249)
static void C_fcall trf_10249(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10249(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10249(t0,t1);}

C_noret_decl(trf_10290)
static void C_fcall trf_10290(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10290(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10290(t0,t1);}

C_noret_decl(trf_10109)
static void C_fcall trf_10109(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10109(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10109(t0,t1,t2);}

C_noret_decl(trf_10187)
static void C_fcall trf_10187(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10187(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10187(t0,t1);}

C_noret_decl(trf_10192)
static void C_fcall trf_10192(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10192(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10192(t0,t1,t2);}

C_noret_decl(trf_10160)
static void C_fcall trf_10160(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10160(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10160(t0,t1);}

C_noret_decl(trf_10131)
static void C_fcall trf_10131(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10131(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10131(t0,t1);}

C_noret_decl(trf_10136)
static void C_fcall trf_10136(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10136(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10136(t0,t1,t2);}

C_noret_decl(trf_9933)
static void C_fcall trf_9933(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9933(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9933(t0,t1);}

C_noret_decl(trf_10025)
static void C_fcall trf_10025(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10025(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10025(t0,t1);}

C_noret_decl(trf_9440)
static void C_fcall trf_9440(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9440(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9440(t0,t1);}

C_noret_decl(trf_9492)
static void C_fcall trf_9492(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9492(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9492(t0,t1);}

C_noret_decl(trf_9421)
static void C_fcall trf_9421(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9421(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9421(t0,t1);}

C_noret_decl(trf_9109)
static void C_fcall trf_9109(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9109(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9109(t0,t1);}

C_noret_decl(trf_9118)
static void C_fcall trf_9118(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9118(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9118(t0,t1);}

C_noret_decl(trf_9130)
static void C_fcall trf_9130(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9130(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9130(t0,t1);}

C_noret_decl(trf_9142)
static void C_fcall trf_9142(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9142(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9142(t0,t1);}

C_noret_decl(trf_9182)
static void C_fcall trf_9182(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9182(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9182(t0,t1);}

C_noret_decl(trf_9026)
static void C_fcall trf_9026(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9026(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9026(t0,t1);}

C_noret_decl(trf_8995)
static void C_fcall trf_8995(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8995(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8995(t0,t1);}

C_noret_decl(trf_7950)
static void C_fcall trf_7950(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7950(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7950(t0,t1,t2);}

C_noret_decl(trf_7979)
static void C_fcall trf_7979(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7979(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7979(t0,t1);}

C_noret_decl(trf_7998)
static void C_fcall trf_7998(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7998(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7998(t0,t1);}

C_noret_decl(trf_8017)
static void C_fcall trf_8017(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8017(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8017(t0,t1);}

C_noret_decl(trf_8087)
static void C_fcall trf_8087(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8087(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8087(t0,t1);}

C_noret_decl(trf_8106)
static void C_fcall trf_8106(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8106(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8106(t0,t1);}

C_noret_decl(trf_8188)
static void C_fcall trf_8188(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8188(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8188(t0,t1);}

C_noret_decl(trf_8227)
static void C_fcall trf_8227(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8227(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8227(t0,t1);}

C_noret_decl(trf_8246)
static void C_fcall trf_8246(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8246(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8246(t0,t1);}

C_noret_decl(trf_8265)
static void C_fcall trf_8265(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8265(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8265(t0,t1);}

C_noret_decl(trf_8345)
static void C_fcall trf_8345(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8345(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8345(t0,t1);}

C_noret_decl(trf_8430)
static void C_fcall trf_8430(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8430(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8430(t0,t1);}

C_noret_decl(trf_8539)
static void C_fcall trf_8539(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8539(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8539(t0,t1);}

C_noret_decl(trf_8379)
static void C_fcall trf_8379(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8379(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8379(t0,t1);}

C_noret_decl(trf_8140)
static void C_fcall trf_8140(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8140(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8140(t0,t1);}

C_noret_decl(trf_8051)
static void C_fcall trf_8051(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8051(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8051(t0,t1);}

C_noret_decl(trf_7907)
static void C_fcall trf_7907(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7907(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7907(t0,t1,t2);}

C_noret_decl(trf_7724)
static void C_fcall trf_7724(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7724(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7724(t0,t1,t2);}

C_noret_decl(trf_7744)
static void C_fcall trf_7744(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7744(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7744(t0,t1);}

C_noret_decl(trf_7669)
static void C_fcall trf_7669(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7669(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7669(t0,t1);}

C_noret_decl(trf_7615)
static void C_fcall trf_7615(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7615(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7615(t0,t1);}

C_noret_decl(trf_7574)
static void C_fcall trf_7574(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7574(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7574(t0,t1);}

C_noret_decl(trf_7405)
static void C_fcall trf_7405(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7405(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7405(t0,t1);}

C_noret_decl(trf_7263)
static void C_fcall trf_7263(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7263(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7263(t0,t1,t2,t3);}

C_noret_decl(trf_7298)
static void C_fcall trf_7298(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7298(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7298(t0,t1,t2,t3);}

C_noret_decl(trf_7220)
static void C_fcall trf_7220(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7220(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7220(t0,t1,t2,t3);}

C_noret_decl(trf_7191)
static void C_fcall trf_7191(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7191(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7191(t0,t1,t2,t3);}

C_noret_decl(trf_7131)
static void C_fcall trf_7131(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7131(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7131(t0,t1);}

C_noret_decl(trf_7023)
static void C_fcall trf_7023(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7023(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7023(t0,t1);}

C_noret_decl(trf_7053)
static void C_fcall trf_7053(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7053(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7053(t0,t1);}

C_noret_decl(trf_6952)
static void C_fcall trf_6952(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6952(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6952(t0,t1,t2);}

C_noret_decl(trf_6820)
static void C_fcall trf_6820(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6820(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6820(t0,t1,t2);}

C_noret_decl(trf_6616)
static void C_fcall trf_6616(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6616(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6616(t0,t1,t2,t3);}

C_noret_decl(trf_6610)
static void C_fcall trf_6610(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6610(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6610(t0,t1,t2);}

C_noret_decl(trf_6572)
static void C_fcall trf_6572(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6572(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6572(t0,t1);}

C_noret_decl(trf_6555)
static void C_fcall trf_6555(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6555(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6555(t0,t1);}

C_noret_decl(trf_6469)
static void C_fcall trf_6469(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6469(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6469(t0,t1,t2);}

C_noret_decl(trf_6170)
static void C_fcall trf_6170(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6170(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6170(t0,t1);}

C_noret_decl(trf_6404)
static void C_fcall trf_6404(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6404(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6404(t0,t1);}

C_noret_decl(trf_6342)
static void C_fcall trf_6342(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6342(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6342(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6010)
static void C_fcall trf_6010(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6010(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6010(t0,t1);}

C_noret_decl(trf_6067)
static void C_fcall trf_6067(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6067(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6067(t0,t1);}

C_noret_decl(trf_5863)
static void C_fcall trf_5863(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5863(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5863(t0,t1);}

C_noret_decl(trf_5719)
static void C_fcall trf_5719(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5719(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5719(t0,t1);}

C_noret_decl(trf_5716)
static void C_fcall trf_5716(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5716(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5716(t0,t1);}

C_noret_decl(trf_5070)
static void C_fcall trf_5070(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5070(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5070(t0,t1);}

C_noret_decl(trf_5218)
static void C_fcall trf_5218(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5218(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5218(t0,t1,t2);}

C_noret_decl(trf_5244)
static void C_fcall trf_5244(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5244(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5244(t0,t1);}

C_noret_decl(trf_5320)
static void C_fcall trf_5320(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5320(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5320(t0,t1);}

C_noret_decl(trf_5129)
static void C_fcall trf_5129(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5129(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5129(t0,t1);}

C_noret_decl(trf_5153)
static void C_fcall trf_5153(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5153(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5153(t0,t1);}

C_noret_decl(trf_5177)
static void C_fcall trf_5177(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5177(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5177(t0,t1);}

C_noret_decl(trf_5020)
static void C_fcall trf_5020(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5020(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5020(t0,t1,t2);}

C_noret_decl(trf_4988)
static void C_fcall trf_4988(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4988(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4988(t0,t1);}

C_noret_decl(trf_4683)
static void C_fcall trf_4683(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4683(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4683(t0,t1,t2);}

C_noret_decl(trf_4598)
static void C_fcall trf_4598(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4598(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4598(t0,t1,t2);}

C_noret_decl(trf_4549)
static void C_fcall trf_4549(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4549(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4549(t0,t1,t2);}

C_noret_decl(trf_4184)
static void C_fcall trf_4184(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4184(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4184(t0,t1,t2);}

C_noret_decl(trf_4212)
static void C_fcall trf_4212(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4212(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4212(t0,t1);}

C_noret_decl(trf_4076)
static void C_fcall trf_4076(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4076(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4076(t0,t1);}

C_noret_decl(trf_3951)
static void C_fcall trf_3951(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3951(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3951(t0,t1,t2,t3);}

C_noret_decl(trf_3898)
static void C_fcall trf_3898(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3898(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3898(t0,t1,t2);}

C_noret_decl(trf_3906)
static void C_fcall trf_3906(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3906(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3906(t0,t1);}

C_noret_decl(trf_3851)
static void C_fcall trf_3851(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3851(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3851(t0,t1);}

C_noret_decl(trf_3677)
static void C_fcall trf_3677(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3677(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3677(t0,t1,t2);}

C_noret_decl(trf_3699)
static void C_fcall trf_3699(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3699(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3699(t0,t1);}

C_noret_decl(trf_3706)
static void C_fcall trf_3706(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3706(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3706(t0,t1);}

C_noret_decl(trf_3621)
static void C_fcall trf_3621(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3621(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3621(t0,t1,t2,t3);}

C_noret_decl(trf_3477)
static void C_fcall trf_3477(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3477(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3477(t0,t1,t2,t3);}

C_noret_decl(trf_3456)
static void C_fcall trf_3456(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3456(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3456(t0,t1);}

C_noret_decl(trf_3416)
static void C_fcall trf_3416(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3416(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3416(t0,t1,t2);}

C_noret_decl(trf_3353)
static void C_fcall trf_3353(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3353(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3353(t0,t1);}

C_noret_decl(trf_3367)
static void C_fcall trf_3367(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3367(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3367(t0,t1,t2);}

C_noret_decl(trf_3305)
static void C_fcall trf_3305(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3305(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3305(t0,t1);}

C_noret_decl(trf_3269)
static void C_fcall trf_3269(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3269(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3269(t0,t1,t2);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_support_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("support_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(5170)){
C_save(t1);
C_rereclaim2(5170*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,499);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],30,"\010compilercompiler-cleanup-hook");
lf[3]=C_h_intern(&lf[3],26,"\010compilerdebugging-chicken");
lf[4]=C_h_intern(&lf[4],26,"\010compilerdisabled-warnings");
lf[5]=C_h_intern(&lf[5],13,"\010compilerbomb");
lf[6]=C_h_intern(&lf[6],5,"error");
lf[7]=C_h_intern(&lf[7],13,"string-append");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\032[internal compiler error] ");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\031[internal compiler error]");
lf[10]=C_h_intern(&lf[10],18,"\010compilerdebugging");
lf[11]=C_h_intern(&lf[11],19,"\003sysstandard-output");
lf[12]=C_h_intern(&lf[12],12,"flush-output");
lf[13]=C_h_intern(&lf[13],7,"newline");
lf[14]=C_h_intern(&lf[14],19,"\003syswrite-char/port");
lf[15]=C_h_intern(&lf[15],5,"write");
lf[16]=C_h_intern(&lf[16],5,"force");
lf[17]=C_h_intern(&lf[17],7,"display");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[19]=C_h_intern(&lf[19],25,"\010compilercompiler-warning");
lf[20]=C_h_intern(&lf[20],7,"fprintf");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\012\012Warning: ");
lf[22]=C_h_intern(&lf[22],18,"current-error-port");
lf[23]=C_h_intern(&lf[23],20,"\003syswarnings-enabled");
lf[24]=C_h_intern(&lf[24],4,"quit");
lf[25]=C_h_intern(&lf[25],4,"exit");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000\010\012Error: ");
lf[27]=C_h_intern(&lf[27],21,"\003syssyntax-error-hook");
lf[28]=C_h_intern(&lf[28],16,"print-call-chain");
lf[29]=C_h_intern(&lf[29],18,"\003syscurrent-thread");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\025\012\011Expansion history:\012");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\005\011~s~%");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\031Syntax error (~a): ~a~%~%");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\024Syntax error: ~a~%~%");
lf[34]=C_h_intern(&lf[34],12,"syntax-error");
lf[35]=C_h_intern(&lf[35],31,"\010compileremit-syntax-trace-info");
lf[36]=C_h_intern(&lf[36],9,"map-llist");
lf[37]=C_h_intern(&lf[37],24,"\010compilercheck-signature");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000@Arguments to inlined call of `~A\047 do not match parameter-list ~A");
lf[39]=C_h_intern(&lf[39],18,"\010compilerreal-name");
lf[40]=C_h_intern(&lf[40],13,"\010compilerposq");
lf[41]=C_h_intern(&lf[41],18,"\010compilerstringify");
lf[42]=C_h_intern(&lf[42],14,"symbol->string");
lf[43]=C_h_intern(&lf[43],17,"get-output-string");
lf[44]=C_h_intern(&lf[44],18,"open-output-string");
lf[45]=C_h_intern(&lf[45],18,"\010compilersymbolify");
lf[46]=C_h_intern(&lf[46],14,"string->symbol");
lf[47]=C_h_intern(&lf[47],26,"\010compilerbuild-lambda-list");
lf[48]=C_h_intern(&lf[48],29,"\010compilerstring->c-identifier");
lf[49]=C_h_intern(&lf[49],24,"\003sysstring->c-identifier");
lf[50]=C_h_intern(&lf[50],21,"\010compilerc-ify-string");
lf[51]=C_h_intern(&lf[51],16,"\003syslist->string");
lf[52]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\377\016");
lf[53]=C_h_intern(&lf[53],6,"append");
lf[54]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\377\016");
lf[55]=C_h_intern(&lf[55],16,"\003sysstring->list");
lf[56]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[57]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[58]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\003\000\000\002\376\377\012\000\000\047\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000\077\376\377\016");
lf[59]=C_h_intern(&lf[59],28,"\010compilervalid-c-identifier\077");
lf[60]=C_h_intern(&lf[60],3,"any");
lf[61]=C_h_intern(&lf[61],8,"->string");
lf[62]=C_h_intern(&lf[62],14,"\010compilerwords");
lf[63]=C_h_intern(&lf[63],21,"\010compilerwords->bytes");
lf[64]=C_h_intern(&lf[64],34,"\010compilercheck-and-open-input-file");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[66]=C_h_intern(&lf[66],18,"current-input-port");
lf[67]=C_h_intern(&lf[67],15,"open-input-file");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\024Can not open file ~s");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\037Can not open file ~s in line ~s");
lf[70]=C_h_intern(&lf[70],12,"file-exists\077");
lf[71]=C_h_intern(&lf[71],33,"\010compilerclose-checked-input-file");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[73]=C_h_intern(&lf[73],16,"close-input-port");
lf[74]=C_h_intern(&lf[74],19,"\010compilerfold-inner");
lf[75]=C_h_intern(&lf[75],7,"reverse");
lf[76]=C_h_intern(&lf[76],28,"\010compilerfollow-without-loop");
lf[77]=C_h_intern(&lf[77],21,"\010compilersort-symbols");
lf[78]=C_h_intern(&lf[78],8,"string<\077");
lf[79]=C_h_intern(&lf[79],4,"sort");
lf[80]=C_h_intern(&lf[80],18,"\010compilerconstant\077");
lf[81]=C_h_intern(&lf[81],5,"quote");
lf[82]=C_h_intern(&lf[82],29,"\010compilercollapsable-literal\077");
lf[83]=C_h_intern(&lf[83],19,"\010compilerimmediate\077");
lf[84]=C_h_intern(&lf[84],20,"\010compilerbig-fixnum\077");
lf[85]=C_h_intern(&lf[85],23,"\010compilerbasic-literal\077");
lf[86]=C_h_intern(&lf[86],5,"every");
lf[87]=C_h_intern(&lf[87],12,"vector->list");
lf[88]=C_h_intern(&lf[88],32,"\010compilercanonicalize-begin-body");
lf[89]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[90]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[91]=C_h_intern(&lf[91],3,"let");
lf[92]=C_h_intern(&lf[92],6,"gensym");
lf[93]=C_h_intern(&lf[93],1,"t");
lf[94]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[95]=C_h_intern(&lf[95],21,"\010compilerstring->expr");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot parse expression: ~s [~a]~%");
lf[97]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[98]=C_h_intern(&lf[98],5,"begin");
lf[99]=C_h_intern(&lf[99],10,"\003sysappend");
lf[100]=C_h_intern(&lf[100],4,"read");
lf[101]=C_h_intern(&lf[101],6,"unfold");
lf[102]=C_h_intern(&lf[102],11,"eof-object\077");
lf[103]=C_h_intern(&lf[103],6,"values");
lf[104]=C_h_intern(&lf[104],22,"with-input-from-string");
lf[105]=C_h_intern(&lf[105],22,"with-exception-handler");
lf[106]=C_h_intern(&lf[106],30,"call-with-current-continuation");
lf[107]=C_h_intern(&lf[107],30,"\010compilerdecompose-lambda-list");
lf[108]=C_h_intern(&lf[108],25,"\003sysdecompose-lambda-list");
lf[109]=C_h_intern(&lf[109],37,"\010compilerprocess-lambda-documentation");
lf[110]=C_h_intern(&lf[110],21,"\010compilerllist-length");
lf[111]=C_h_intern(&lf[111],30,"\010compilerexpand-profile-lambda");
lf[112]=C_h_intern(&lf[112],29,"\010compilerprofile-lambda-index");
lf[113]=C_h_intern(&lf[113],28,"\010compilerprofile-lambda-list");
lf[114]=C_h_intern(&lf[114],33,"\010compilerprofile-info-vector-name");
lf[115]=C_h_intern(&lf[115],17,"\003sysprofile-entry");
lf[116]=C_h_intern(&lf[116],6,"lambda");
lf[117]=C_h_intern(&lf[117],5,"apply");
lf[118]=C_h_intern(&lf[118],16,"\003sysprofile-exit");
lf[119]=C_h_intern(&lf[119],16,"\003sysdynamic-wind");
lf[120]=C_h_intern(&lf[120],10,"alist-cons");
lf[121]=C_h_intern(&lf[121],37,"\010compilerinitialize-analysis-database");
lf[122]=C_h_intern(&lf[122],8,"internal");
lf[123]=C_h_intern(&lf[123],8,"\003sysput!");
lf[124]=C_h_intern(&lf[124],18,"\010compilerintrinsic");
lf[125]=C_h_intern(&lf[125],9,"\003syserror");
lf[126]=C_h_intern(&lf[126],26,"\010compilerinternal-bindings");
lf[127]=C_h_intern(&lf[127],26,"\010compilerfoldable-bindings");
lf[128]=C_h_intern(&lf[128],17,"\010compilerfoldable");
lf[129]=C_h_intern(&lf[129],8,"extended");
lf[130]=C_h_intern(&lf[130],17,"extended-bindings");
lf[131]=C_h_intern(&lf[131],8,"standard");
lf[132]=C_h_intern(&lf[132],17,"standard-bindings");
lf[133]=C_h_intern(&lf[133],12,"\010compilerget");
lf[134]=C_h_intern(&lf[134],18,"\003syshash-table-ref");
lf[135]=C_h_intern(&lf[135],16,"\010compilerget-all");
lf[136]=C_h_intern(&lf[136],10,"filter-map");
lf[137]=C_h_intern(&lf[137],13,"\010compilerput!");
lf[138]=C_h_intern(&lf[138],19,"\003syshash-table-set!");
lf[139]=C_h_intern(&lf[139],17,"\010compilercollect!");
lf[140]=C_h_intern(&lf[140],15,"\010compilercount!");
lf[141]=C_h_intern(&lf[141],17,"\010compilerget-list");
lf[142]=C_h_intern(&lf[142],17,"\010compilerget-line");
lf[143]=C_h_intern(&lf[143],24,"\003sysline-number-database");
lf[144]=C_h_intern(&lf[144],19,"\010compilerget-line-2");
lf[145]=C_h_intern(&lf[145],30,"\010compilerfind-lambda-container");
lf[146]=C_h_intern(&lf[146],12,"contained-in");
lf[147]=C_h_intern(&lf[147],37,"\010compilerdisplay-line-number-database");
lf[148]=C_h_intern(&lf[148],7,"\003sysmap");
lf[149]=C_h_intern(&lf[149],3,"cdr");
lf[150]=C_h_intern(&lf[150],23,"\003syshash-table-for-each");
lf[151]=C_h_intern(&lf[151],34,"\010compilerdisplay-analysis-database");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\005\011css=");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\006\011refs=");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\005\011val=");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\006\011lval=");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\006\011pval=");
lf[157]=C_h_intern(&lf[157],7,"unknown");
lf[158]=C_h_intern(&lf[158],8,"captured");
lf[159]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010captured\376\001\000\000\003cpt\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010assigned\376\001\000\000\003set\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005box"
"ed\376\001\000\000\003box\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006global\376\001\000\000\003glo\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020assigned-locally\376\001\000\000\003stl\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\014contractable\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020standard-binding\376\001\000\000\003stb\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\006simple\376\001\000\000\003sim\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011inlinable\376\001\000\000\003inl\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013collapsable\376"
"\001\000\000\003col\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011removable\376\001\000\000\003rem\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010constant\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002"
"\376\001\000\000\015inline-target\376\001\000\000\003ilt\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020inline-transient\376\001\000\000\003itr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011"
"undefined\376\001\000\000\003und\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011replacing\376\001\000\000\003rpg\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006unused\376\001\000\000\003uud\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\020extended-binding\376\001\000\000\003xtb\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015inline-export\376\001\000\000\003ilx\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\014customizable\376\001\000\000\003cst\376\003\000\000\002\376\003\000\000\002\376\001\000\000\025has-unused-parameters\376\001\000\000\003hup\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\012boxed-rest\376\001\000\000\003bxr\376\377\016");
lf[160]=C_h_intern(&lf[160],4,"caar");
lf[161]=C_h_intern(&lf[161],5,"value");
lf[162]=C_h_intern(&lf[162],4,"cdar");
lf[163]=C_h_intern(&lf[163],11,"local-value");
lf[164]=C_h_intern(&lf[164],15,"potential-value");
lf[165]=C_h_intern(&lf[165],10,"replacable");
lf[166]=C_h_intern(&lf[166],10,"references");
lf[167]=C_h_intern(&lf[167],10,"call-sites");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\020Illegal property");
lf[169]=C_h_intern(&lf[169],4,"home");
lf[170]=C_h_intern(&lf[170],8,"contains");
lf[171]=C_h_intern(&lf[171],8,"use-expr");
lf[172]=C_h_intern(&lf[172],12,"closure-size");
lf[173]=C_h_intern(&lf[173],14,"rest-parameter");
lf[174]=C_h_intern(&lf[174],16,"o-r/access-count");
lf[175]=C_h_intern(&lf[175],18,"captured-variables");
lf[176]=C_h_intern(&lf[176],13,"explicit-rest");
lf[177]=C_h_intern(&lf[177],8,"assigned");
lf[178]=C_h_intern(&lf[178],5,"boxed");
lf[179]=C_h_intern(&lf[179],6,"global");
lf[180]=C_h_intern(&lf[180],12,"contractable");
lf[181]=C_h_intern(&lf[181],16,"standard-binding");
lf[182]=C_h_intern(&lf[182],16,"assigned-locally");
lf[183]=C_h_intern(&lf[183],11,"collapsable");
lf[184]=C_h_intern(&lf[184],9,"removable");
lf[185]=C_h_intern(&lf[185],9,"undefined");
lf[186]=C_h_intern(&lf[186],9,"replacing");
lf[187]=C_h_intern(&lf[187],6,"unused");
lf[188]=C_h_intern(&lf[188],6,"simple");
lf[189]=C_h_intern(&lf[189],9,"inlinable");
lf[190]=C_h_intern(&lf[190],13,"inline-export");
lf[191]=C_h_intern(&lf[191],21,"has-unused-parameters");
lf[192]=C_h_intern(&lf[192],16,"extended-binding");
lf[193]=C_h_intern(&lf[193],12,"customizable");
lf[194]=C_h_intern(&lf[194],8,"constant");
lf[195]=C_h_intern(&lf[195],10,"boxed-rest");
lf[196]=C_h_intern(&lf[196],11,"hidden-refs");
lf[197]=C_h_intern(&lf[197],34,"\010compilerdefault-standard-bindings");
lf[198]=C_h_intern(&lf[198],34,"\010compilerdefault-extended-bindings");
lf[199]=C_h_intern(&lf[199],9,"make-node");
lf[200]=C_h_intern(&lf[200],4,"node");
lf[201]=C_h_intern(&lf[201],5,"node\077");
lf[202]=C_h_intern(&lf[202],15,"node-class-set!");
lf[203]=C_h_intern(&lf[203],14,"\003sysblock-set!");
lf[204]=C_h_intern(&lf[204],10,"node-class");
lf[205]=C_h_intern(&lf[205],20,"node-parameters-set!");
lf[206]=C_h_intern(&lf[206],15,"node-parameters");
lf[207]=C_h_intern(&lf[207],24,"node-subexpressions-set!");
lf[208]=C_h_intern(&lf[208],19,"node-subexpressions");
lf[209]=C_h_intern(&lf[209],16,"\010compilervarnode");
lf[210]=C_h_intern(&lf[210],13,"\004corevariable");
lf[211]=C_h_intern(&lf[211],14,"\010compilerqnode");
lf[212]=C_h_intern(&lf[212],25,"\010compilerbuild-node-graph");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\016bad expression");
lf[214]=C_h_intern(&lf[214],15,"\004coreglobal-ref");
lf[215]=C_h_intern(&lf[215],2,"if");
lf[216]=C_h_intern(&lf[216],14,"\004coreundefined");
lf[217]=C_h_intern(&lf[217],8,"truncate");
lf[218]=C_h_intern(&lf[218],4,"type");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000;literal \047~s\047 is out of range - will be truncated to integer");
lf[220]=C_h_intern(&lf[220],6,"fixnum");
lf[221]=C_h_intern(&lf[221],11,"number-type");
lf[222]=C_h_intern(&lf[222],6,"unzip1");
lf[223]=C_h_intern(&lf[223],11,"\004corelambda");
lf[224]=C_h_intern(&lf[224],14,"\004coreprimitive");
lf[225]=C_h_intern(&lf[225],11,"\004coreinline");
lf[226]=C_h_intern(&lf[226],13,"\004corecallunit");
lf[227]=C_h_intern(&lf[227],9,"\004coreproc");
lf[228]=C_h_intern(&lf[228],4,"set!");
lf[229]=C_h_intern(&lf[229],9,"\004coreset!");
lf[230]=C_h_intern(&lf[230],29,"\004coreforeign-callback-wrapper");
lf[231]=C_h_intern(&lf[231],5,"sixth");
lf[232]=C_h_intern(&lf[232],5,"fifth");
lf[233]=C_h_intern(&lf[233],20,"\004coreinline_allocate");
lf[234]=C_h_intern(&lf[234],8,"\004coreapp");
lf[235]=C_h_intern(&lf[235],9,"\004corecall");
lf[236]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[237]=C_h_intern(&lf[237],24,"\010compilersource-filename");
lf[238]=C_h_intern(&lf[238],28,"\003syssymbol->qualified-string");
lf[239]=C_h_intern(&lf[239],7,"\003sysget");
lf[240]=C_h_intern(&lf[240],34,"\010compileralways-bound-to-procedure");
lf[241]=C_h_intern(&lf[241],15,"\004coreinline_ref");
lf[242]=C_h_intern(&lf[242],18,"\004coreinline_update");
lf[243]=C_h_intern(&lf[243],19,"\004coreinline_loc_ref");
lf[244]=C_h_intern(&lf[244],22,"\004coreinline_loc_update");
lf[245]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\000\376\377\016");
lf[246]=C_h_intern(&lf[246],1,"o");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\033eliminated procedure checks");
lf[248]=C_h_intern(&lf[248],30,"\010compilerbuild-expression-tree");
lf[249]=C_h_intern(&lf[249],12,"\004coreclosure");
lf[250]=C_h_intern(&lf[250],4,"last");
lf[251]=C_h_intern(&lf[251],3,"map");
lf[252]=C_h_intern(&lf[252],4,"list");
lf[253]=C_h_intern(&lf[253],7,"butlast");
lf[254]=C_h_intern(&lf[254],5,"cons*");
lf[255]=C_h_intern(&lf[255],9,"\004corebind");
lf[256]=C_h_intern(&lf[256],10,"\004coreunbox");
lf[257]=C_h_intern(&lf[257],8,"\004coreref");
lf[258]=C_h_intern(&lf[258],11,"\004coreupdate");
lf[259]=C_h_intern(&lf[259],13,"\004coreupdate_i");
lf[260]=C_h_intern(&lf[260],8,"\004corebox");
lf[261]=C_h_intern(&lf[261],9,"\004corecond");
lf[262]=C_h_intern(&lf[262],21,"\010compilerfold-boolean");
lf[263]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005C_and\376\377\016");
lf[264]=C_h_intern(&lf[264],31,"\010compilerinline-lambda-bindings");
lf[265]=C_h_intern(&lf[265],8,"split-at");
lf[266]=C_h_intern(&lf[266],10,"fold-right");
lf[267]=C_h_intern(&lf[267],4,"take");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[269]=C_h_intern(&lf[269],34,"\010compilercopy-node-tree-and-rename");
lf[270]=C_h_intern(&lf[270],9,"alist-ref");
lf[271]=C_h_intern(&lf[271],3,"eq\077");
lf[272]=C_h_intern(&lf[272],1,"f");
lf[273]=C_h_intern(&lf[273],4,"cons");
lf[274]=C_h_intern(&lf[274],16,"inline-transient");
lf[275]=C_h_intern(&lf[275],18,"\010compilertree-copy");
lf[276]=C_h_intern(&lf[276],19,"\010compilercopy-node!");
lf[277]=C_h_intern(&lf[277],20,"\010compilernode->sexpr");
lf[278]=C_h_intern(&lf[278],20,"\010compilersexpr->node");
lf[279]=C_h_intern(&lf[279],32,"\010compileremit-global-inline-file");
lf[280]=C_h_intern(&lf[280],5,"print");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[282]=C_h_intern(&lf[282],1,"i");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\0001the following procedures can be globally inlined:");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\015; END OF FILE");
lf[285]=C_h_intern(&lf[285],2,"pp");
lf[286]=C_h_intern(&lf[286],3,"yes");
lf[287]=C_h_intern(&lf[287],2,"no");
lf[288]=C_h_intern(&lf[288],24,"\010compilerinline-max-size");
lf[289]=C_h_intern(&lf[289],15,"\010compilerinline");
lf[290]=C_h_intern(&lf[290],22,"\010compilerinline-global");
lf[291]=C_h_intern(&lf[291],26,"\010compilervariable-visible\077");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\027; GENERATED BY CHICKEN ");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\006 FROM ");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[295]=C_h_intern(&lf[295],15,"chicken-version");
lf[296]=C_h_intern(&lf[296],19,"with-output-to-file");
lf[297]=C_h_intern(&lf[297],25,"\010compilerload-inline-file");
lf[298]=C_h_intern(&lf[298],20,"with-input-from-file");
lf[299]=C_h_intern(&lf[299],19,"\010compilermatch-node");
lf[300]=C_h_intern(&lf[300],1,"a");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\007matched");
lf[302]=C_h_intern(&lf[302],37,"\010compilerexpression-has-side-effects\077");
lf[303]=C_h_intern(&lf[303],24,"foreign-callback-stub-id");
lf[304]=C_h_intern(&lf[304],4,"find");
lf[305]=C_h_intern(&lf[305],22,"foreign-callback-stubs");
lf[306]=C_h_intern(&lf[306],28,"\010compilersimple-lambda-node\077");
lf[307]=C_h_intern(&lf[307],31,"\010compilerdump-undefined-globals");
lf[308]=C_h_intern(&lf[308],8,"keyword\077");
lf[309]=C_h_intern(&lf[309],29,"\010compilerdump-defined-globals");
lf[310]=C_h_intern(&lf[310],25,"\010compilerdump-global-refs");
lf[311]=C_h_intern(&lf[311],28,"\003systoplevel-definition-hook");
lf[312]=C_h_intern(&lf[312],22,"\010compilerhide-variable");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\042hiding nonexported module bindings");
lf[314]=C_h_intern(&lf[314],36,"\010compilercompute-database-statistics");
lf[315]=C_h_intern(&lf[315],29,"\010compilercurrent-program-size");
lf[316]=C_h_intern(&lf[316],30,"\010compileroriginal-program-size");
lf[317]=C_h_intern(&lf[317],33,"\010compilerprint-program-statistics");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\027;   database entries: \011");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\027;   known call sites: \011");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\027;   global variables: \011");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\027;   known procedures: \011");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\042;   variables with known values: \011");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\032 \011original program size: \011");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\023;   program size: \011");
lf[325]=C_h_intern(&lf[325],1,"s");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\023program statistics:");
lf[327]=C_h_intern(&lf[327],35,"\010compilerpprint-expressions-to-file");
lf[328]=C_h_intern(&lf[328],17,"close-output-port");
lf[329]=C_h_intern(&lf[329],12,"pretty-print");
lf[330]=C_h_intern(&lf[330],19,"with-output-to-port");
lf[331]=C_h_intern(&lf[331],16,"open-output-file");
lf[332]=C_h_intern(&lf[332],19,"current-output-port");
lf[333]=C_h_intern(&lf[333],27,"\010compilerforeign-type-check");
lf[334]=C_h_intern(&lf[334],4,"char");
lf[335]=C_h_intern(&lf[335],13,"unsigned-char");
lf[336]=C_h_intern(&lf[336],6,"unsafe");
lf[337]=C_h_intern(&lf[337],25,"\003sysforeign-char-argument");
lf[338]=C_h_intern(&lf[338],3,"int");
lf[339]=C_h_intern(&lf[339],27,"\003sysforeign-fixnum-argument");
lf[340]=C_h_intern(&lf[340],5,"float");
lf[341]=C_h_intern(&lf[341],27,"\003sysforeign-flonum-argument");
lf[342]=C_h_intern(&lf[342],7,"pointer");
lf[343]=C_h_intern(&lf[343],26,"\003sysforeign-block-argument");
lf[344]=C_h_intern(&lf[344],15,"nonnull-pointer");
lf[345]=C_h_intern(&lf[345],8,"u8vector");
lf[346]=C_h_intern(&lf[346],34,"\003sysforeign-number-vector-argument");
lf[347]=C_h_intern(&lf[347],16,"nonnull-u8vector");
lf[348]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-u8vector\376\001\000\000\010u8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u16vector\376\001\000\000"
"\011u16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-s8vector\376\001\000\000\010s8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-s16"
"vector\376\001\000\000\011s16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u32vector\376\001\000\000\011u32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\021nonnull-s32vector\376\001\000\000\011s32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f32vector\376\001\000\000\011f32vector\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f64vector\376\001\000\000\011f64vector\376\377\016");
lf[349]=C_h_intern(&lf[349],7,"integer");
lf[350]=C_h_intern(&lf[350],28,"\003sysforeign-integer-argument");
lf[351]=C_h_intern(&lf[351],16,"unsigned-integer");
lf[352]=C_h_intern(&lf[352],37,"\003sysforeign-unsigned-integer-argument");
lf[353]=C_h_intern(&lf[353],9,"c-pointer");
lf[354]=C_h_intern(&lf[354],28,"\003sysforeign-pointer-argument");
lf[355]=C_h_intern(&lf[355],17,"nonnull-c-pointer");
lf[356]=C_h_intern(&lf[356],8,"c-string");
lf[357]=C_h_intern(&lf[357],17,"\003sysmake-c-string");
lf[358]=C_h_intern(&lf[358],27,"\003sysforeign-string-argument");
lf[359]=C_h_intern(&lf[359],16,"nonnull-c-string");
lf[360]=C_h_intern(&lf[360],6,"symbol");
lf[361]=C_h_intern(&lf[361],18,"\003syssymbol->string");
lf[362]=C_h_intern(&lf[362],3,"ref");
lf[363]=C_h_intern(&lf[363],8,"instance");
lf[364]=C_h_intern(&lf[364],12,"instance-ref");
lf[365]=C_h_intern(&lf[365],4,"this");
lf[366]=C_h_intern(&lf[366],8,"slot-ref");
lf[367]=C_h_intern(&lf[367],16,"nonnull-instance");
lf[368]=C_h_intern(&lf[368],5,"const");
lf[369]=C_h_intern(&lf[369],4,"enum");
lf[370]=C_h_intern(&lf[370],8,"function");
lf[371]=C_h_intern(&lf[371],27,"\010compilerforeign-type-table");
lf[372]=C_h_intern(&lf[372],17,"nonnull-c-string*");
lf[373]=C_h_intern(&lf[373],26,"nonnull-unsigned-c-string*");
lf[374]=C_h_intern(&lf[374],9,"c-string*");
lf[375]=C_h_intern(&lf[375],17,"unsigned-c-string");
lf[376]=C_h_intern(&lf[376],18,"unsigned-c-string*");
lf[377]=C_h_intern(&lf[377],13,"c-string-list");
lf[378]=C_h_intern(&lf[378],14,"c-string-list*");
lf[379]=C_h_intern(&lf[379],18,"unsigned-integer32");
lf[380]=C_h_intern(&lf[380],13,"unsigned-long");
lf[381]=C_h_intern(&lf[381],4,"long");
lf[382]=C_h_intern(&lf[382],9,"integer32");
lf[383]=C_h_intern(&lf[383],17,"nonnull-u16vector");
lf[384]=C_h_intern(&lf[384],16,"nonnull-s8vector");
lf[385]=C_h_intern(&lf[385],17,"nonnull-s16vector");
lf[386]=C_h_intern(&lf[386],17,"nonnull-u32vector");
lf[387]=C_h_intern(&lf[387],17,"nonnull-s32vector");
lf[388]=C_h_intern(&lf[388],17,"nonnull-f32vector");
lf[389]=C_h_intern(&lf[389],17,"nonnull-f64vector");
lf[390]=C_h_intern(&lf[390],9,"u16vector");
lf[391]=C_h_intern(&lf[391],8,"s8vector");
lf[392]=C_h_intern(&lf[392],9,"s16vector");
lf[393]=C_h_intern(&lf[393],9,"u32vector");
lf[394]=C_h_intern(&lf[394],9,"s32vector");
lf[395]=C_h_intern(&lf[395],9,"f32vector");
lf[396]=C_h_intern(&lf[396],9,"f64vector");
lf[397]=C_h_intern(&lf[397],22,"nonnull-scheme-pointer");
lf[398]=C_h_intern(&lf[398],12,"nonnull-blob");
lf[399]=C_h_intern(&lf[399],19,"nonnull-byte-vector");
lf[400]=C_h_intern(&lf[400],11,"byte-vector");
lf[401]=C_h_intern(&lf[401],4,"blob");
lf[402]=C_h_intern(&lf[402],14,"scheme-pointer");
lf[403]=C_h_intern(&lf[403],6,"double");
lf[404]=C_h_intern(&lf[404],6,"number");
lf[405]=C_h_intern(&lf[405],12,"unsigned-int");
lf[406]=C_h_intern(&lf[406],5,"short");
lf[407]=C_h_intern(&lf[407],14,"unsigned-short");
lf[408]=C_h_intern(&lf[408],4,"byte");
lf[409]=C_h_intern(&lf[409],13,"unsigned-byte");
lf[410]=C_h_intern(&lf[410],5,"int32");
lf[411]=C_h_intern(&lf[411],14,"unsigned-int32");
lf[412]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[413]=C_h_intern(&lf[413],36,"\010compilerforeign-type-convert-result");
lf[414]=C_h_intern(&lf[414],38,"\010compilerforeign-type-convert-argument");
lf[415]=C_h_intern(&lf[415],27,"\010compilerfinal-foreign-type");
lf[416]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[417]=C_h_intern(&lf[417],37,"\010compilerestimate-foreign-result-size");
lf[418]=C_h_intern(&lf[418],9,"integer64");
lf[419]=C_h_intern(&lf[419],4,"bool");
lf[420]=C_h_intern(&lf[420],4,"void");
lf[421]=C_h_intern(&lf[421],13,"scheme-object");
lf[422]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[423]=C_h_intern(&lf[423],46,"\010compilerestimate-foreign-result-location-size");
lf[424]=C_decode_literal(C_heaptop,"\376B\000\0005cannot compute size of location for foreign type `~S\047");
lf[425]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[426]=C_h_intern(&lf[426],30,"\010compilerfinish-foreign-result");
lf[427]=C_h_intern(&lf[427],17,"\003syspeek-c-string");
lf[428]=C_h_intern(&lf[428],25,"\003syspeek-nonnull-c-string");
lf[429]=C_h_intern(&lf[429],26,"\003syspeek-and-free-c-string");
lf[430]=C_h_intern(&lf[430],34,"\003syspeek-and-free-nonnull-c-string");
lf[431]=C_h_intern(&lf[431],17,"\003sysintern-symbol");
lf[432]=C_h_intern(&lf[432],22,"\003syspeek-c-string-list");
lf[433]=C_h_intern(&lf[433],31,"\003syspeek-and-free-c-string-list");
lf[434]=C_h_intern(&lf[434],17,"\003sysnull-pointer\077");
lf[435]=C_h_intern(&lf[435],3,"not");
lf[436]=C_h_intern(&lf[436],4,"make");
lf[437]=C_h_intern(&lf[437],3,"and");
lf[438]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010instance\376\003\000\000\002\376\001\000\000\014instance-ref\376\377\016");
lf[439]=C_h_intern(&lf[439],28,"\010compilerscan-used-variables");
lf[440]=C_h_intern(&lf[440],28,"\010compilerscan-free-variables");
lf[441]=C_h_intern(&lf[441],11,"lset-adjoin");
lf[442]=C_h_intern(&lf[442],23,"\010compilerchop-separator");
lf[443]=C_h_intern(&lf[443],9,"substring");
lf[444]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[445]=C_h_intern(&lf[445],23,"\010compilerchop-extension");
lf[446]=C_h_intern(&lf[446],22,"\010compilerprint-version");
lf[447]=C_h_intern(&lf[447],6,"print*");
lf[448]=C_decode_literal(C_heaptop,"\376B\000\000\077(c)2008-2009 The Chicken Team\012(c)2000-2007 Felix L. Winkelmann\012");
lf[449]=C_h_intern(&lf[449],20,"\010compilerprint-usage");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\030LUsage: chicken FILENAME OPTION ...\012\012  `chicken\047 is the CHICKEN compiler.\012  "
"\012  FILENAME should be a complete source file name with extension, or \042-\042 for\012  s"
"tandard input. OPTION may be one of the following:\012\012  General options:\012\012    -hel"
"p                        display this text and exit\012    -version                "
"     display compiler version and exit\012    -release                     print re"
"lease number and exit\012    -verbose                     display information on co"
"mpilation progress\012\012  File and pathname options:\012\012    -output-file FILENAME     "
"   specifies output-filename, default is \047out.c\047\012    -include-path PATHNAME     "
"  specifies alternative path for included files\012    -to-stdout                  "
" write compiled file to stdout instead of file\012\012  Language options:\012\012    -featur"
"e SYMBOL              register feature identifier\012\012  Syntax related options:\012\012  "
"  -case-insensitive            don\047t preserve case of read symbols\012    -keyword-"
"style STYLE         allow alternative keyword syntax\012                           "
"       (prefix, suffix or none)\012    -no-parentheses-synonyms     disables list d"
"elimiter synonyms\012    -no-symbol-escape            disables support for escaped "
"symbols\012    -r5rs-syntax                 disables the Chicken extensions to\012    "
"                              R5RS syntax\012    -compile-syntax              macro"
"s are made available at run-time\012    -emit-import-library MODULE  write compile-"
"time module information into\012                                  separate file\012   "
" -emit-all-import-libraries   emit import-libraries for all defined modules\012    "
"-no-compiler-syntax          disable expansion of compiler-macros\012\012  Translation"
" options:\012\012    -explicit-use                do not use units \047library\047 and \047eval"
"\047 by\012                                  default\012    -check-syntax                "
"stop compilation after macro-expansion\012    -analyze-only                stop com"
"pilation after first analysis pass\012\012  Debugging options:\012\012    -no-warnings      "
"           disable warnings\012    -disable-warning CLASS       disable specific cl"
"ass of warnings\012    -debug-level NUMBER          set level of available debuggin"
"g information\012    -no-trace                    disable tracing information\012    -"
"profile                     executable emits profiling information \012    -profile"
"-name FILENAME       name of the generated profile information file\012    -accumul"
"ate-profile          executable emits profiling information in\012                 "
"                 append mode\012    -no-lambda-info              omit additional pr"
"ocedure-information\012    -scrutinize                  perform local flow analysis"
"\012    -types FILENAME              load additional type database\012\012  Optimization "
"options:\012\012    -optimize-level NUMBER       enable certain sets of optimization o"
"ptions\012    -optimize-leaf-routines      enable leaf routine optimization\012    -la"
"mbda-lift                 enable lambda-lifting\012    -no-usual-integrations      "
" standard procedures may be redefined\012    -unsafe                      disable a"
"ll safety checks\012    -local                       assume globals are only modifi"
"ed in current\012                                  file\012    -block                 "
"      enable block-compilation\012    -disable-interrupts          disable interrup"
"ts in compiled code\012    -fixnum-arithmetic           assume all numbers are fixn"
"ums\012    -benchmark-mode              equivalent to \047block -optimize-level 4\012    "
"                              -debug-level 0 -fixnum-arithmetic -lambda-lift\012   "
"                               -inline -disable-interrupts\047\012    -disable-stack-o"
"verflow-checks  disables detection of stack-overflows\012    -inline               "
"       enable inlining\012    -inline-limit                set inlining threshold\012 "
"   -inline-global               enable cross-module inlining\012    -emit-inline-fi"
"le FILENAME   generate file with globally inlinable\012                            "
"      procedures (implies -inline -local)\012    -consult-inline-file FILENAME  exp"
"licitly load inline file\012    -no-argc-checks              disable argument count"
" checks\012    -no-bound-checks             disable bound variable checks\012    -no-p"
"rocedure-checks         disable procedure call checks\012    -no-procedure-checks-f"
"or-usual-bindings\012                                 disable procedure call checks"
" only for usual\012                                  bindings\012\012  Configuration opti"
"ons:\012\012    -unit NAME                   compile file as a library unit\012    -uses "
"NAME                   declare library unit as used.\012    -heap-size NUMBER      "
"      specifies heap-size of compiled executable\012    -heap-initial-size NUMBER  "
"  specifies heap-size at startup time\012    -heap-growth PERCENTAGE      specifies"
" growth-rate of expanding heap\012    -heap-shrinkage PERCENTAGE   specifies shrink"
"-rate of contracting heap\012    -nursery NUMBER  -stack-size NUMBER\012              "
"                   specifies nursery size of compiled executable\012    -extend FIL"
"ENAME             load file before compilation commences\012    -prelude EXPRESSION"
"          add expression to front of source file\012    -postlude EXPRESSION       "
"  add expression to end of source file\012    -prologue FILENAME           include "
"file before main source file\012    -epilogue FILENAME           include file after"
" main source file\012    -dynamic                     compile as dynamically loadab"
"le code\012    -require-extension NAME      require and import extension NAME\012    -"
"static-extension NAME       import extension NAME but link statically\012          "
"                        (if available)\012\012  Obscure options:\012\012    -debug MODES    "
"             display debugging output for the given modes\012    -unsafe-libraries "
"           marks the generated file as being linked with\012                       "
"           the unsafe runtime system\012    -raw                         do not gen"
"erate implicit init- and exit code                           \012    -emit-external"
"-prototypes-first\012                                 emit prototypes for callbacks"
" before foreign\012                                  declarations\012    -ignore-repos"
"itory           do not refer to repository for extensions\012    -setup-mode       "
"           prefer the current directory when locating extensions\012");
lf[451]=C_h_intern(&lf[451],36,"\010compilermake-block-variable-literal");
lf[452]=C_h_intern(&lf[452],22,"block-variable-literal");
lf[453]=C_h_intern(&lf[453],32,"\010compilerblock-variable-literal\077");
lf[454]=C_h_intern(&lf[454],36,"\010compilerblock-variable-literal-name");
lf[455]=C_h_intern(&lf[455],25,"\010compilermake-random-name");
lf[456]=C_h_intern(&lf[456],6,"random");
lf[457]=C_h_intern(&lf[457],15,"current-seconds");
lf[458]=C_h_intern(&lf[458],23,"\010compilerset-real-name!");
lf[459]=C_h_intern(&lf[459],24,"\010compilerreal-name-table");
lf[460]=C_decode_literal(C_heaptop,"\376B\000\000\004 in ");
lf[461]=C_h_intern(&lf[461],19,"\010compilerreal-name2");
lf[462]=C_h_intern(&lf[462],32,"\010compilerdisplay-real-name-table");
lf[463]=C_h_intern(&lf[463],28,"\010compilersource-info->string");
lf[464]=C_h_intern(&lf[464],4,"conc");
lf[465]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[466]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[467]=C_h_intern(&lf[467],11,"make-string");
lf[468]=C_h_intern(&lf[468],3,"max");
lf[469]=C_h_intern(&lf[469],26,"\010compilersource-info->line");
lf[470]=C_h_intern(&lf[470],12,"string-null\077");
lf[471]=C_h_intern(&lf[471],19,"\010compilerdump-nodes");
lf[472]=C_h_intern(&lf[472],18,"\003sysuser-read-hook");
lf[473]=C_h_intern(&lf[473],15,"foreign-declare");
lf[474]=C_h_intern(&lf[474],7,"declare");
lf[475]=C_h_intern(&lf[475],34,"\010compilerscan-sharp-greater-string");
lf[476]=C_h_intern(&lf[476],18,"\003sysread-char/port");
lf[477]=C_decode_literal(C_heaptop,"\376B\000\000&unexpected end of `#> ... <#\047 sequence");
lf[478]=C_h_intern(&lf[478],6,"hidden");
lf[479]=C_h_intern(&lf[479],19,"\010compilervisibility");
lf[480]=C_h_intern(&lf[480],24,"\010compilerexport-variable");
lf[481]=C_h_intern(&lf[481],8,"exported");
lf[482]=C_h_intern(&lf[482],26,"\010compilerblock-compilation");
lf[483]=C_h_intern(&lf[483],22,"\010compilermark-variable");
lf[484]=C_h_intern(&lf[484],22,"\010compilervariable-mark");
lf[485]=C_h_intern(&lf[485],19,"\010compilerintrinsic\077");
lf[486]=C_h_intern(&lf[486],9,"foldable\077");
lf[487]=C_h_intern(&lf[487],33,"\010compilerload-identifier-database");
lf[488]=C_h_intern(&lf[488],7,"\004coredb");
lf[489]=C_h_intern(&lf[489],9,"read-file");
lf[490]=C_h_intern(&lf[490],21,"\010compilerverbose-mode");
lf[491]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[492]=C_decode_literal(C_heaptop,"\376B\000\000\034loading identifier database ");
lf[493]=C_h_intern(&lf[493],13,"make-pathname");
lf[494]=C_h_intern(&lf[494],15,"repository-path");
lf[495]=C_h_intern(&lf[495],27,"condition-property-accessor");
lf[496]=C_h_intern(&lf[496],3,"exn");
lf[497]=C_h_intern(&lf[497],7,"message");
lf[498]=C_h_intern(&lf[498],19,"condition-predicate");
C_register_lf2(lf,499,create_ptable());
t2=C_mutate(&lf[0] /* (set! c514 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3188,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k3186 */
static void C_ccall f_3188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3188,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3191,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3189 in k3186 */
static void C_ccall f_3191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3191,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3194,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3192 in k3189 in k3186 */
static void C_ccall f_3194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3194,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3197,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3197,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3200,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3200,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3203,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3203,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! compiler-cleanup-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3207,tmp=(C_word)a,a+=2,tmp));
t3=C_set_block_item(lf[3] /* debugging-chicken */,0,C_SCHEME_END_OF_LIST);
t4=C_set_block_item(lf[4] /* disabled-warnings */,0,C_SCHEME_END_OF_LIST);
t5=C_mutate((C_word*)lf[5]+1 /* (set! bomb ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3212,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[10]+1 /* (set! debugging ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3239,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[19]+1 /* (set! compiler-warning ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3298,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[24]+1 /* (set! quit ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3327,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[27]+1 /* (set! syntax-error-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3346,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[34]+1 /* (set! syntax-error ...) */,C_retrieve(lf[27]));
t11=C_mutate((C_word*)lf[35]+1 /* (set! emit-syntax-trace-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3407,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[36]+1 /* (set! map-llist ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3410,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[37]+1 /* (set! check-signature ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3453,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[40]+1 /* (set! posq ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3521,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[41]+1 /* (set! stringify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3557,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[45]+1 /* (set! symbolify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3584,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[47]+1 /* (set! build-lambda-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3615,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[48]+1 /* (set! string->c-identifier ...) */,C_retrieve(lf[49]));
t19=C_mutate((C_word*)lf[50]+1 /* (set! c-ify-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3659,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[59]+1 /* (set! valid-c-identifier? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3753,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[62]+1 /* (set! words ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3809,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[63]+1 /* (set! words->bytes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3816,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[64]+1 /* (set! check-and-open-input-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3823,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[71]+1 /* (set! close-checked-input-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3870,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[74]+1 /* (set! fold-inner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3882,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[76]+1 /* (set! follow-without-loop ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3945,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[77]+1 /* (set! sort-symbols ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3976,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[80]+1 /* (set! constant? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3996,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[82]+1 /* (set! collapsable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4042,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[83]+1 /* (set! immediate? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4072,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[85]+1 /* (set! basic-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4118,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[88]+1 /* (set! canonicalize-begin-body ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4178,tmp=(C_word)a,a+=2,tmp));
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4275,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 255  condition-predicate */
((C_proc3)C_retrieve_symbol_proc(lf[498]))(3,*((C_word*)lf[498]+1),t33,lf[496]);}

/* k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4275,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4278,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 256  condition-property-accessor */
((C_proc4)C_retrieve_symbol_proc(lf[495]))(4,*((C_word*)lf[495]+1),t2,lf[496],lf[497]);}

/* k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word ab[177],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4278,2,t0,t1);}
t2=C_mutate((C_word*)lf[95]+1 /* (set! string->expr ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4279,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[107]+1 /* (set! decompose-lambda-list ...) */,C_retrieve(lf[108]));
t4=C_mutate((C_word*)lf[109]+1 /* (set! process-lambda-documentation ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4386,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[110]+1 /* (set! llist-length ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4389,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[111]+1 /* (set! expand-profile-lambda ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4392,tmp=(C_word)a,a+=2,tmp));
t7=C_SCHEME_TRUE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_mutate((C_word*)lf[121]+1 /* (set! initialize-analysis-database ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4533,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[133]+1 /* (set! get ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4768,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[135]+1 /* (set! get-all ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4786,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[137]+1 /* (set! put! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4804,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[139]+1 /* (set! collect! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4850,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[140]+1 /* (set! count! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4902,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[141]+1 /* (set! get-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4959,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[142]+1 /* (set! get-line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4968,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[144]+1 /* (set! get-line-2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4978,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[145]+1 /* (set! find-lambda-container ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5014,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[147]+1 /* (set! display-line-number-database ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5038,tmp=(C_word)a,a+=2,tmp));
t20=C_SCHEME_FALSE;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_mutate((C_word*)lf[151]+1 /* (set! display-analysis-database ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5066,a[2]=t21,tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[199]+1 /* (set! make-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5541,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[201]+1 /* (set! node? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5547,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[202]+1 /* (set! node-class-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5553,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[204]+1 /* (set! node-class ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5562,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[205]+1 /* (set! node-parameters-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5571,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[206]+1 /* (set! node-parameters ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5580,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[207]+1 /* (set! node-subexpressions-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5589,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[208]+1 /* (set! node-subexpressions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5598,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[199]+1 /* (set! make-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5607,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[209]+1 /* (set! varnode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5613,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[211]+1 /* (set! qnode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5622,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[212]+1 /* (set! build-node-graph ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5631,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[248]+1 /* (set! build-expression-tree ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6145,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[262]+1 /* (set! fold-boolean ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6463,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[264]+1 /* (set! inline-lambda-bindings ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6511,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate((C_word*)lf[269]+1 /* (set! copy-node-tree-and-rename ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6604,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate((C_word*)lf[275]+1 /* (set! tree-copy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6814,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate((C_word*)lf[276]+1 /* (set! copy-node! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6848,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate((C_word*)lf[277]+1 /* (set! node->sexpr ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6872,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[278]+1 /* (set! sexpr->node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6908,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[279]+1 /* (set! emit-global-inline-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6933,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[297]+1 /* (set! load-inline-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7119,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[299]+1 /* (set! match-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7188,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[302]+1 /* (set! expression-has-side-effects? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7383,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[306]+1 /* (set! simple-lambda-node? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7469,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate((C_word*)lf[307]+1 /* (set! dump-undefined-globals ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7561,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[309]+1 /* (set! dump-defined-globals ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7602,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[310]+1 /* (set! dump-global-refs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7639,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[311]+1 /* (set! toplevel-definition-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7688,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[314]+1 /* (set! compute-database-statistics ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7709,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[317]+1 /* (set! print-program-statistics ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7805,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate((C_word*)lf[327]+1 /* (set! pprint-expressions-to-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7886,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate((C_word*)lf[333]+1 /* (set! foreign-type-check ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7938,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[413]+1 /* (set! foreign-type-convert-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8991,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[414]+1 /* (set! foreign-type-convert-argument ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9022,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[415]+1 /* (set! final-foreign-type ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9053,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate((C_word*)lf[417]+1 /* (set! estimate-foreign-result-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9093,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[423]+1 /* (set! estimate-foreign-result-location-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9418,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate((C_word*)lf[426]+1 /* (set! finish-foreign-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9734,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[439]+1 /* (set! scan-used-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10103,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[440]+1 /* (set! scan-free-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10227,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[442]+1 /* (set! chop-separator ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10415,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[445]+1 /* (set! chop-extension ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10444,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[446]+1 /* (set! print-version ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10486,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate((C_word*)lf[449]+1 /* (set! print-usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10524,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate((C_word*)lf[451]+1 /* (set! make-block-variable-literal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10536,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate((C_word*)lf[453]+1 /* (set! block-variable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10542,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate((C_word*)lf[454]+1 /* (set! block-variable-literal-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10548,tmp=(C_word)a,a+=2,tmp));
t71=C_mutate((C_word*)lf[455]+1 /* (set! make-random-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10557,tmp=(C_word)a,a+=2,tmp));
t72=C_mutate((C_word*)lf[458]+1 /* (set! set-real-name! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10616,tmp=(C_word)a,a+=2,tmp));
t73=C_mutate((C_word*)lf[39]+1 /* (set! real-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10622,tmp=(C_word)a,a+=2,tmp));
t74=C_mutate((C_word*)lf[461]+1 /* (set! real-name2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10713,tmp=(C_word)a,a+=2,tmp));
t75=C_mutate((C_word*)lf[462]+1 /* (set! display-real-name-table ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10725,tmp=(C_word)a,a+=2,tmp));
t76=C_mutate((C_word*)lf[463]+1 /* (set! source-info->string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10746,tmp=(C_word)a,a+=2,tmp));
t77=C_mutate((C_word*)lf[469]+1 /* (set! source-info->line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10792,tmp=(C_word)a,a+=2,tmp));
t78=C_mutate((C_word*)lf[470]+1 /* (set! string-null? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10810,tmp=(C_word)a,a+=2,tmp));
t79=C_mutate((C_word*)lf[471]+1 /* (set! dump-nodes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10813,tmp=(C_word)a,a+=2,tmp));
t80=C_retrieve(lf[472]);
t81=C_mutate((C_word*)lf[472]+1 /* (set! user-read-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10937,a[2]=t80,tmp=(C_word)a,a+=3,tmp));
t82=C_mutate((C_word*)lf[475]+1 /* (set! scan-sharp-greater-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10970,tmp=(C_word)a,a+=2,tmp));
t83=C_mutate((C_word*)lf[84]+1 /* (set! big-fixnum? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11039,tmp=(C_word)a,a+=2,tmp));
t84=C_mutate((C_word*)lf[312]+1 /* (set! hide-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11063,tmp=(C_word)a,a+=2,tmp));
t85=C_mutate((C_word*)lf[480]+1 /* (set! export-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11096,tmp=(C_word)a,a+=2,tmp));
t86=C_mutate((C_word*)lf[291]+1 /* (set! variable-visible? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11129,tmp=(C_word)a,a+=2,tmp));
t87=C_mutate((C_word*)lf[483]+1 /* (set! mark-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11150,tmp=(C_word)a,a+=2,tmp));
t88=C_mutate((C_word*)lf[484]+1 /* (set! variable-mark ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11178,tmp=(C_word)a,a+=2,tmp));
t89=C_mutate((C_word*)lf[485]+1 /* (set! intrinsic? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11184,tmp=(C_word)a,a+=2,tmp));
t90=C_mutate((C_word*)lf[486]+1 /* (set! foldable? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11190,tmp=(C_word)a,a+=2,tmp));
t91=C_mutate((C_word*)lf[487]+1 /* (set! load-identifier-database ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11196,tmp=(C_word)a,a+=2,tmp));
t92=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t92+1)))(2,t92,C_SCHEME_UNDEFINED);}

/* ##compiler#load-identifier-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_11196(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11196,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11200,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1482 repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[494]))(2,*((C_word*)lf[494]+1),t3);}

/* k11198 in ##compiler#load-identifier-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_11200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11200,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11206,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11284,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1483 make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[493]))(4,*((C_word*)lf[493]+1),t3,t1,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k11282 in k11198 in ##compiler#load-identifier-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_11284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1483 file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[70]))(3,*((C_word*)lf[70]+1),((C_word*)t0)[2],t1);}

/* k11204 in k11198 in ##compiler#load-identifier-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_11206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11206,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11212,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[490]))){
t3=*((C_word*)lf[11]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11271,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t4,lf[492],t3);}
else{
t3=t2;
f_11212(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k11269 in k11204 in k11198 in ##compiler#load-identifier-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_11271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11271,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11274,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k11272 in k11269 in k11204 in k11198 in ##compiler#load-identifier-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_11274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11274,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11277,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,lf[491],((C_word*)t0)[2]);}

/* k11275 in k11272 in k11269 in k11204 in k11198 in ##compiler#load-identifier-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_11277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* k11210 in k11204 in k11198 in ##compiler#load-identifier-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_11212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11219,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1491 read-file */
((C_proc3)C_retrieve_symbol_proc(lf[489]))(3,*((C_word*)lf[489]+1),t2,((C_word*)t0)[2]);}

/* k11217 in k11210 in k11204 in k11198 in ##compiler#load-identifier-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_11219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11219,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11221,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_11221(t5,((C_word*)t0)[2],t1);}

/* loop3054 in k11217 in k11210 in k11204 in k11198 in ##compiler#load-identifier-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_11221(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11221,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11234,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11249,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11253,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_car(t3);
/* support.scm: 1490 ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[239]))(4,*((C_word*)lf[239]+1),t7,t8,lf[488]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k11251 in loop3054 in k11217 in k11210 in k11204 in k11198 in ##compiler#load-identifier-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_11253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11253,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,1,t3);
/* support.scm: 1490 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[53]+1)))(4,*((C_word*)lf[53]+1),((C_word*)t0)[2],t2,t4);}

/* k11247 in loop3054 in k11217 in k11210 in k11204 in k11198 in ##compiler#load-identifier-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_11249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1488 ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[488],t1);}

/* k11232 in loop3054 in k11217 in k11210 in k11204 in k11198 in ##compiler#load-identifier-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_11234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11221(t3,((C_word*)t0)[2],t2);}

/* foldable? in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_11190(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11190,3,t0,t1,t2);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[239]))(4,*((C_word*)lf[239]+1),t1,t2,lf[128]);}

/* ##compiler#intrinsic? in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_11184(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11184,3,t0,t1,t2);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[239]))(4,*((C_word*)lf[239]+1),t1,t2,lf[124]);}

/* ##compiler#variable-mark in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_11178(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11178,4,t0,t1,t2,t3);}
/* support.scm: 1473 ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[239]))(4,*((C_word*)lf[239]+1),t1,t2,t3);}

/* ##compiler#mark-variable in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_11150(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_11150r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_11150r(t0,t1,t2,t3,t4);}}

static void C_ccall f_11150r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11154,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_11154(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_11154(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k11152 in ##compiler#mark-variable in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_11154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1470 ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#variable-visible? in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_11129(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11129,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11133,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1463 ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[239]))(4,*((C_word*)lf[239]+1),t3,t2,lf[479]);}

/* k11131 in ##compiler#variable-visible? in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_11133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(t1,lf[478]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_eqp(t1,lf[481]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_TRUE:(C_word)C_i_not(C_retrieve(lf[482]))));}}

/* ##compiler#export-variable in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_11096(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11096,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,lf[481]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11102,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_11102(2,t5,C_SCHEME_TRUE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_11102(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k11100 in ##compiler#export-variable in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_11102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[479],t1);}

/* ##compiler#hide-variable in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_11063(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11063,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,lf[478]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11069,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_11069(2,t5,C_SCHEME_TRUE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_11069(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k11067 in ##compiler#hide-variable in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_11069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[479],t1);}

/* ##compiler#big-fixnum? in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_11039(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11039,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnump(t2))){
if(C_truep((C_word)C_fudge(C_fix(3)))){
t3=(C_word)C_fixnum_greaterp(t2,C_fix(1073741823));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_fixnum_lessp(t2,C_fix(-1073741824))));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* ##compiler#scan-sharp-greater-string in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10970(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10970,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10974,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1425 open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[44]))(2,*((C_word*)lf[44]+1),t3);}

/* k10972 in ##compiler#scan-sharp-greater-string in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10974,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10979,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_10979(t5,((C_word*)t0)[2]);}

/* loop in k10972 in ##compiler#scan-sharp-greater-string in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_10979(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10979,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10983,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* read-char/port */
t3=C_retrieve(lf[476]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k10981 in loop in k10972 in ##compiler#scan-sharp-greater-string in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10983,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
/* support.scm: 1428 quit */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),((C_word*)t0)[5],lf[477]);}
else{
switch(t1){
case C_make_character(10):
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11001,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1430 newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[13]+1)))(3,*((C_word*)lf[13]+1),t2,((C_word*)t0)[3]);
case C_make_character(60):
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11013,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* read-char/port */
t3=C_retrieve(lf[476]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);
default:
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11034,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[3]);}}}

/* k11032 in k10981 in loop in k10972 in ##compiler#scan-sharp-greater-string in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_11034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1442 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_10979(t2,((C_word*)t0)[2]);}

/* k11011 in k10981 in loop in k10972 in ##compiler#scan-sharp-greater-string in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_11013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11013,2,t0,t1);}
t2=(C_word)C_eqp(C_make_character(35),t1);
if(C_truep(t2)){
/* support.scm: 1435 get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11025,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t4=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(60),((C_word*)t0)[3]);}}

/* k11023 in k11011 in k10981 in loop in k10972 in ##compiler#scan-sharp-greater-string in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_11025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11028,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11026 in k11023 in k11011 in k10981 in loop in k10972 in ##compiler#scan-sharp-greater-string in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_11028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1439 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_10979(t2,((C_word*)t0)[2]);}

/* k10999 in k10981 in loop in k10972 in ##compiler#scan-sharp-greater-string in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_11001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1431 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_10979(t2,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10937(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10937,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_make_character(62),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10947,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* read-char/port */
t6=C_retrieve(lf[476]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
/* support.scm: 1422 old-hook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k10945 in ##sys#user-read-hook in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10947,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10950,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1420 scan-sharp-greater-string */
((C_proc3)C_retrieve_symbol_proc(lf[475]))(3,*((C_word*)lf[475]+1),t2,((C_word*)t0)[2]);}

/* k10948 in k10945 in ##sys#user-read-hook in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10950,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[473],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[474],t4));}

/* ##compiler#dump-nodes in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10813(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10813,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10817,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10822,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_10822(t7,t3,C_fix(0),t2);}

/* loop in ##compiler#dump-nodes in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_10822(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10822,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t3;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10835,a[2]=t5,a[3]=t7,a[4]=t9,a[5]=((C_word*)t0)[2],a[6]=t1,a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* support.scm: 1398 make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[467]+1)))(4,*((C_word*)lf[467]+1),t10,t2,C_make_character(32));}

/* k10833 in loop in ##compiler#dump-nodes in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10835,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[8],C_fix(2));
t3=*((C_word*)lf[11]+1);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10841,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
/* write-char/port */
t5=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_make_character(10),t3);}

/* k10839 in k10833 in loop in ##compiler#dump-nodes in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10841,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10844,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k10842 in k10839 in k10833 in loop in ##compiler#dump-nodes in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10844,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10847,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* write-char/port */
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(60),((C_word*)t0)[3]);}

/* k10845 in k10842 in k10839 in k10833 in loop in ##compiler#dump-nodes in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10847,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10850,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k10848 in k10845 in k10842 in k10839 in k10833 in loop in ##compiler#dump-nodes in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10850,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10853,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* write-char/port */
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[2]);}

/* k10851 in k10848 in k10845 in k10842 in k10839 in k10833 in loop in ##compiler#dump-nodes in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10853,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10856,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10854 in k10851 in k10848 in k10845 in k10842 in k10839 in k10833 in loop in ##compiler#dump-nodes in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10856,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10859,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10915,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_10915(t6,t2,((C_word*)t0)[2]);}

/* loop2882 in k10854 in k10851 in k10848 in k10845 in k10842 in k10839 in k10833 in loop in ##compiler#dump-nodes in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_10915(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10915,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10928,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* loop2861 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_10822(t5,t4,((C_word*)t0)[2],t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k10926 in loop2882 in k10854 in k10851 in k10848 in k10845 in k10842 in k10839 in k10833 in loop in ##compiler#dump-nodes in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10915(t3,((C_word*)t0)[2],t2);}

/* k10857 in k10854 in k10851 in k10848 in k10845 in k10842 in k10839 in k10833 in loop in ##compiler#dump-nodes in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10859,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10865,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(4)))){
t4=*((C_word*)lf[11]+1);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10874,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t6=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_make_character(91),t4);}
else{
t4=t3;
f_10865(2,t4,C_SCHEME_UNDEFINED);}}

/* k10872 in k10857 in k10854 in k10851 in k10848 in k10845 in k10842 in k10839 in k10833 in loop in ##compiler#dump-nodes in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10874,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10877,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t2,t3,((C_word*)t0)[2]);}

/* k10875 in k10872 in k10857 in k10854 in k10851 in k10848 in k10845 in k10842 in k10839 in k10833 in loop in ##compiler#dump-nodes in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10880,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10885,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_10885(t6,t2,C_fix(5));}

/* doloop2903 in k10875 in k10872 in k10857 in k10854 in k10851 in k10848 in k10845 in k10842 in k10839 in k10833 in loop in ##compiler#dump-nodes in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_10885(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10885,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=*((C_word*)lf[11]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10895,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* write-char/port */
t5=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_make_character(32),t3);}}

/* k10893 in doloop2903 in k10875 in k10872 in k10857 in k10854 in k10851 in k10848 in k10845 in k10842 in k10839 in k10833 in loop in ##compiler#dump-nodes in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10898,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],((C_word*)t0)[6]);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t2,t3,((C_word*)t0)[2]);}

/* k10896 in k10893 in doloop2903 in k10875 in k10872 in k10857 in k10854 in k10851 in k10848 in k10845 in k10842 in k10839 in k10833 in loop in ##compiler#dump-nodes in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10885(t3,((C_word*)t0)[2],t2);}

/* k10878 in k10875 in k10872 in k10857 in k10854 in k10851 in k10848 in k10845 in k10842 in k10839 in k10833 in loop in ##compiler#dump-nodes in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(93),*((C_word*)lf[11]+1));}

/* k10863 in k10857 in k10854 in k10851 in k10848 in k10845 in k10842 in k10839 in k10833 in loop in ##compiler#dump-nodes in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(62),*((C_word*)lf[11]+1));}

/* k10815 in ##compiler#dump-nodes in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1410 newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[13]+1)))(2,*((C_word*)lf[13]+1),((C_word*)t0)[2]);}

/* string-null? in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10810(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10810,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_string_null_p(C_retrieve(lf[325])));}

/* ##compiler#source-info->line in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10792(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10792,3,t0,t1,t2);}
if(C_truep((C_word)C_i_listp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cadr(t2));}
else{
if(C_truep(t2)){
/* support.scm: 1382 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[61]))(3,*((C_word*)lf[61]+1),t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* ##compiler#source-info->string in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10746(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10746,3,t0,t1,t2);}
if(C_truep((C_word)C_i_listp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=(C_word)C_i_caddr(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10765,a[2]=t5,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1375 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[61]))(3,*((C_word*)lf[61]+1),t6,t4);}
else{
if(C_truep(t2)){
/* support.scm: 1377 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[61]))(3,*((C_word*)lf[61]+1),t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* k10763 in ##compiler#source-info->string in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10765,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10772,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10776,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_string_length(t1);
t5=(C_word)C_fixnum_difference(C_fix(4),t4);
/* support.scm: 1376 max */
((C_proc4)C_retrieve_proc(*((C_word*)lf[468]+1)))(4,*((C_word*)lf[468]+1),t3,C_fix(0),t5);}

/* k10774 in k10763 in ##compiler#source-info->string in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1376 make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[467]+1)))(4,*((C_word*)lf[467]+1),((C_word*)t0)[2],t1,C_make_character(32));}

/* k10770 in k10763 in ##compiler#source-info->string in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1376 conc */
((C_proc8)C_retrieve_symbol_proc(lf[464]))(8,*((C_word*)lf[464]+1),((C_word*)t0)[5],((C_word*)t0)[4],lf[465],((C_word*)t0)[3],t1,lf[466],((C_word*)t0)[2]);}

/* ##compiler#display-real-name-table in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10725,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10731,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 1365 ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[150]))(4,*((C_word*)lf[150]+1),t1,t2,C_retrieve(lf[459]));}

/* a10730 in ##compiler#display-real-name-table in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10731,4,t0,t1,t2,t3);}
t4=*((C_word*)lf[11]+1);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10735,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t5,t2,t4);}

/* k10733 in a10730 in ##compiler#display-real-name-table in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10735,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10738,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(9),((C_word*)t0)[3]);}

/* k10736 in k10733 in a10730 in ##compiler#display-real-name-table in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10738,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10741,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k10739 in k10736 in k10733 in a10730 in ##compiler#display-real-name-table in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* ##compiler#real-name2 in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10713(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10713,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10717,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1361 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t4,C_retrieve(lf[459]),t2);}

/* k10715 in ##compiler#real-name2 in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1362 real-name */
((C_proc4)C_retrieve_symbol_proc(lf[39]))(4,*((C_word*)lf[39]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#real-name in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10622(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3rv,(void*)f_10622r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_10622r(t0,t1,t2,t3);}}

static void C_ccall f_10622r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10625,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10641,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1345 resolve */
f_10625(t5,t2);}

/* k10639 in ##compiler#real-name in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10641,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[5]))){
t3=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10666,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1349 ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[238]))(3,*((C_word*)lf[238]+1),t4,t1);}
else{
/* support.scm: 1358 ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[238]))(3,*((C_word*)lf[238]+1),((C_word*)t0)[3],t1);}}
else{
/* support.scm: 1346 ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[238]))(3,*((C_word*)lf[238]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k10664 in k10639 in ##compiler#real-name in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10670,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1350 get */
((C_proc5)C_retrieve_symbol_proc(lf[133]))(5,*((C_word*)lf[133]+1),t2,((C_word*)t0)[5],((C_word*)t0)[2],lf[146]);}

/* k10668 in k10664 in k10639 in ##compiler#real-name in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10670,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10672,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_10672(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k10668 in k10664 in k10639 in ##compiler#real-name in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_10672(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10672,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10679,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 1352 resolve */
f_10625(t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k10677 in loop in k10668 in k10664 in k10639 in ##compiler#real-name in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10679,2,t0,t1);}
t2=(C_word)C_eqp(t1,((C_word*)t0)[6]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10692,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[44]))(2,*((C_word*)lf[44]+1),t3);}}

/* k10690 in k10677 in loop in k10668 in k10664 in k10639 in ##compiler#real-name in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10692,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10695,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,((C_word*)t0)[2],t1);}

/* k10693 in k10690 in k10677 in loop in k10668 in k10664 in k10639 in ##compiler#real-name in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10695,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10698,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,lf[460],((C_word*)t0)[3]);}

/* k10696 in k10693 in k10690 in k10677 in loop in k10668 in k10664 in k10639 in ##compiler#real-name in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10698,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10701,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k10699 in k10696 in k10693 in k10690 in k10677 in loop in k10668 in k10664 in k10639 in ##compiler#real-name in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10701,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10704,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t2,((C_word*)t0)[2]);}

/* k10702 in k10699 in k10696 in k10693 in k10690 in k10677 in loop in k10668 in k10664 in k10639 in ##compiler#real-name in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10704,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10708,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1356 get */
((C_proc5)C_retrieve_symbol_proc(lf[133]))(5,*((C_word*)lf[133]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[146]);}

/* k10706 in k10702 in k10699 in k10696 in k10693 in k10690 in k10677 in loop in k10668 in k10664 in k10639 in ##compiler#real-name in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1355 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10672(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* resolve in ##compiler#real-name in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_10625(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10625,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10629,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1340 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t3,C_retrieve(lf[459]),t2);}

/* k10627 in resolve in ##compiler#real-name in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10629,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10635,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1342 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t2,C_retrieve(lf[459]),t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k10633 in k10627 in resolve in ##compiler#real-name in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#set-real-name! in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10616(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10616,4,t0,t1,t2,t3);}
/* support.scm: 1336 ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[138]))(5,*((C_word*)lf[138]+1),t1,C_retrieve(lf[459]),t2,t3);}

/* ##compiler#make-random-name in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10557(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_10557r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_10557r(t0,t1,t2);}}

static void C_ccall f_10557r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10565,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[44]))(2,*((C_word*)lf[44]+1),t3);}

/* k10563 in ##compiler#make-random-name in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10568,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10592,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* support.scm: 1323 gensym */
((C_proc2)C_retrieve_symbol_proc(lf[92]))(2,*((C_word*)lf[92]+1),t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_10592(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k10590 in k10563 in ##compiler#make-random-name in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k10566 in k10563 in ##compiler#make-random-name in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10571,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(45),((C_word*)t0)[2]);}

/* k10569 in k10566 in k10563 in ##compiler#make-random-name in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10574,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10588,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1324 current-seconds */
((C_proc2)C_retrieve_symbol_proc(lf[457]))(2,*((C_word*)lf[457]+1),t3);}

/* k10586 in k10569 in k10566 in k10563 in ##compiler#make-random-name in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k10572 in k10569 in k10566 in k10563 in ##compiler#make-random-name in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10574,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10577,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10584,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1325 random */
((C_proc3)C_retrieve_symbol_proc(lf[456]))(3,*((C_word*)lf[456]+1),t3,C_fix(1000));}

/* k10582 in k10572 in k10569 in k10566 in k10563 in ##compiler#make-random-name in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k10575 in k10572 in k10569 in k10566 in k10563 in ##compiler#make-random-name in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10577,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10580,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t2,((C_word*)t0)[2]);}

/* k10578 in k10575 in k10572 in k10569 in k10566 in k10563 in ##compiler#make-random-name in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1321 string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[46]+1)))(3,*((C_word*)lf[46]+1),((C_word*)t0)[2],t1);}

/* ##compiler#block-variable-literal-name in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10548(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10548,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[452]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* ##compiler#block-variable-literal? in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10542(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10542,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[452]));}

/* ##compiler#make-block-variable-literal in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10536(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10536,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,2,lf[452],t2));}

/* ##compiler#print-usage in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10524,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10528,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1182 print-version */
((C_proc2)C_retrieve_symbol_proc(lf[446]))(2,*((C_word*)lf[446]+1),t2);}

/* k10526 in ##compiler#print-usage in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10528,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10531,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1183 newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[13]+1)))(2,*((C_word*)lf[13]+1),t2);}

/* k10529 in k10526 in ##compiler#print-usage in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1184 display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[17]+1)))(3,*((C_word*)lf[17]+1),((C_word*)t0)[2],lf[450]);}

/* ##compiler#print-version in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10486(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_10486r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_10486r(t0,t1,t2);}}

static void C_ccall f_10486r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10490,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_10490(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_10490(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k10488 in ##compiler#print-version in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10490,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10493,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
/* support.scm: 1178 print* */
((C_proc3)C_retrieve_proc(*((C_word*)lf[447]+1)))(3,*((C_word*)lf[447]+1),t2,lf[448]);}
else{
t3=t2;
f_10493(2,t3,C_SCHEME_UNDEFINED);}}

/* k10491 in k10488 in ##compiler#print-version in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10493,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10500,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1179 chicken-version */
((C_proc3)C_retrieve_symbol_proc(lf[295]))(3,*((C_word*)lf[295]+1),t2,C_SCHEME_TRUE);}

/* k10498 in k10491 in k10488 in ##compiler#print-version in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1179 print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[280]+1)))(3,*((C_word*)lf[280]+1),((C_word*)t0)[2],t1);}

/* ##compiler#chop-extension in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10444(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10444,3,t0,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_decrease(t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10453,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_10453(t8,t1,t4);}

/* loop in ##compiler#chop-extension in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_10453(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10453,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t5=(C_word)C_eqp(C_make_character(46),t4);
if(C_truep(t5)){
/* support.scm: 1171 substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[443]+1)))(5,*((C_word*)lf[443]+1),t1,((C_word*)t0)[3],C_fix(0),t2);}
else{
t6=(C_word)C_fixnum_decrease(t2);
/* support.scm: 1172 loop */
t8=t1;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##compiler#chop-separator in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10415(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10415,3,t0,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_decrease(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10425,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t4,C_fix(0)))){
t6=(C_word)C_i_string_ref(t2,t4);
t7=t5;
f_10425(t7,(C_word)C_i_memq(t6,lf[444]));}
else{
t6=t5;
f_10425(t6,C_SCHEME_FALSE);}}

/* k10423 in ##compiler#chop-separator in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_10425(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1164 substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[443]+1)))(5,*((C_word*)lf[443]+1),((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ##compiler#scan-free-variables in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10227(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10227,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10230,a[2]=t10,a[3]=t8,a[4]=t6,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t12=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10381,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10410,a[2]=t6,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1154 walk */
t14=((C_word*)t8)[1];
f_10230(t14,t13,t2,C_SCHEME_END_OF_LIST);}

/* k10408 in ##compiler#scan-free-variables in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1155 values */
C_values(4,0,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* walkeach in ##compiler#scan-free-variables in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_10381(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10381,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10387,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_10387(t7,t1,t2);}

/* loop2716 in walkeach in ##compiler#scan-free-variables in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_10387(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10387,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10400,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1152 walk */
t5=((C_word*)((C_word*)t0)[3])[1];
f_10230(t5,t4,t3,((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k10398 in loop2716 in walkeach in ##compiler#scan-free-variables in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10387(t3,((C_word*)t0)[2],t2);}

/* walk in ##compiler#scan-free-variables in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_10230(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10230,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[81]);
t11=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10249,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=t7,a[9]=t9,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t10)){
t12=t11;
f_10249(t12,t10);}
else{
t12=(C_word)C_eqp(t9,lf[216]);
if(C_truep(t12)){
t13=t11;
f_10249(t13,t12);}
else{
t13=(C_word)C_eqp(t9,lf[224]);
if(C_truep(t13)){
t14=t11;
f_10249(t14,t13);}
else{
t14=(C_word)C_eqp(t9,lf[227]);
t15=t11;
f_10249(t15,(C_truep(t14)?t14:(C_word)C_eqp(t9,lf[241])));}}}}

/* k10247 in walk in ##compiler#scan-free-variables in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_10249(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10249,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[210]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[8]);
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[7]))){
t4=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10268,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1134 lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[441]))(5,*((C_word*)lf[441]+1),t4,*((C_word*)lf[271]+1),((C_word*)((C_word*)t0)[6])[1],t3);}}
else{
t3=(C_word)C_eqp(((C_word*)t0)[9],lf[228]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[8]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10290,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(t4,((C_word*)t0)[7]))){
t6=t5;
f_10290(t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10304,a[2]=t5,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1139 lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[441]))(5,*((C_word*)lf[441]+1),t6,*((C_word*)lf[271]+1),((C_word*)((C_word*)t0)[6])[1],t4);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[9],lf[91]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10313,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
/* support.scm: 1142 walk */
t7=((C_word*)((C_word*)t0)[3])[1];
f_10230(t7,t5,t6,((C_word*)t0)[7]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[9],lf[223]);
if(C_truep(t5)){
t6=(C_word)C_i_caddr(((C_word*)t0)[8]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10343,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1145 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),((C_word*)t0)[10],t6,t7);}
else{
/* support.scm: 1149 walkeach */
t6=((C_word*)((C_word*)t0)[2])[1];
f_10381(t6,((C_word*)t0)[10],((C_word*)t0)[4],((C_word*)t0)[7]);}}}}}}

/* a10342 in k10247 in walk in ##compiler#scan-free-variables in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10343(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10343,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10355,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1148 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[53]+1)))(4,*((C_word*)lf[53]+1),t6,t2,((C_word*)t0)[2]);}

/* k10353 in a10342 in k10247 in walk in ##compiler#scan-free-variables in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1148 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10230(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10311 in k10247 in walk in ##compiler#scan-free-variables in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10313,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10324,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1143 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[53]+1)))(4,*((C_word*)lf[53]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10322 in k10311 in k10247 in walk in ##compiler#scan-free-variables in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1143 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10230(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10302 in k10247 in walk in ##compiler#scan-free-variables in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_10290(t3,t2);}

/* k10288 in k10247 in walk in ##compiler#scan-free-variables in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_10290(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* support.scm: 1140 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_10230(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k10266 in k10247 in walk in ##compiler#scan-free-variables in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10268,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10274,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1135 variable-visible? */
((C_proc3)C_retrieve_symbol_proc(lf[291]))(3,*((C_word*)lf[291]+1),t3,((C_word*)t0)[2]);}

/* k10272 in k10266 in k10247 in walk in ##compiler#scan-free-variables in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10274,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10278,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1136 lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[441]))(5,*((C_word*)lf[441]+1),t2,*((C_word*)lf[271]+1),((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}}

/* k10276 in k10272 in k10266 in k10247 in walk in ##compiler#scan-free-variables in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##compiler#scan-used-variables in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10103(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10103,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10107,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10109,a[2]=t3,a[3]=t5,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_10109(t10,t6,t2);}

/* walk in ##compiler#scan-used-variables in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_10109(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10109,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(1));
t7=(C_word)C_eqp(t6,lf[210]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(t6,lf[228]));
if(C_truep(t8)){
t9=t2;
t10=(C_word)C_slot(t9,C_fix(2));
t11=(C_word)C_i_car(t10);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10131,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10160,a[2]=t12,a[3]=((C_word*)t0)[3],a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t11,((C_word*)t0)[2]))){
t14=(C_word)C_i_memq(t11,((C_word*)((C_word*)t0)[3])[1]);
t15=t13;
f_10160(t15,(C_word)C_i_not(t14));}
else{
t14=t13;
f_10160(t14,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_eqp(t6,lf[81]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10187,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t9)){
t11=t10;
f_10187(t11,t9);}
else{
t11=(C_word)C_eqp(t6,lf[216]);
t12=t10;
f_10187(t12,(C_truep(t11)?t11:(C_word)C_eqp(t6,lf[224])));}}}

/* k10185 in walk in ##compiler#scan-used-variables in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_10187(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10187,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10192,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_10192(t5,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* loop2651 in k10185 in walk in ##compiler#scan-used-variables in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_10192(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10192,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10202,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* walk2608 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_10109(t5,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k10200 in loop2651 in k10185 in walk in ##compiler#scan-used-variables in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10192(t3,((C_word*)t0)[2],t2);}

/* k10158 in walk in ##compiler#scan-used-variables in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_10160(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10160,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_10131(t4,t3);}
else{
t2=((C_word*)t0)[2];
f_10131(t2,C_SCHEME_UNDEFINED);}}

/* k10129 in walk in ##compiler#scan-used-variables in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_10131(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10131,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10136,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_10136(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2631 in k10129 in walk in ##compiler#scan-used-variables in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_10136(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10136,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10146,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* walk2608 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_10109(t5,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k10144 in loop2631 in k10129 in walk in ##compiler#scan-used-variables in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10136(t3,((C_word*)t0)[2],t2);}

/* k10105 in ##compiler#scan-used-variables in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_10107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#finish-foreign-result in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_9734(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word ab[21],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9734,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[356]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(t4,lf[375]));
if(C_truep(t6)){
t7=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[81],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t3,t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[427],t10));}
else{
t7=(C_word)C_eqp(t4,lf[359]);
if(C_truep(t7)){
t8=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,lf[81],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t3,t10);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,lf[428],t11));}
else{
t8=(C_word)C_eqp(t4,lf[374]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t4,lf[376]));
if(C_truep(t9)){
t10=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,lf[81],t10);
t12=(C_word)C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,t3,t12);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_cons(&a,2,lf[429],t13));}
else{
t10=(C_word)C_eqp(t4,lf[372]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t4,lf[373]));
if(C_truep(t11)){
t12=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,lf[81],t12);
t14=(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,t3,t14);
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,(C_word)C_a_i_cons(&a,2,lf[430],t15));}
else{
t12=(C_word)C_eqp(t4,lf[360]);
if(C_truep(t12)){
t13=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,lf[81],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,t3,t15);
t17=(C_word)C_a_i_cons(&a,2,lf[427],t16);
t18=(C_word)C_a_i_cons(&a,2,t17,C_SCHEME_END_OF_LIST);
t19=t1;
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,(C_word)C_a_i_cons(&a,2,lf[431],t18));}
else{
t13=(C_word)C_eqp(t4,lf[377]);
if(C_truep(t13)){
t14=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,lf[81],t14);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t3,t16);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_cons(&a,2,lf[432],t17));}
else{
t14=(C_word)C_eqp(t4,lf[378]);
if(C_truep(t14)){
t15=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,lf[81],t15);
t17=(C_word)C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=(C_word)C_a_i_cons(&a,2,t3,t17);
t19=t1;
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,(C_word)C_a_i_cons(&a,2,lf[433],t18));}
else{
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9933,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t16=(C_word)C_i_length(t2);
t17=(C_word)C_eqp(C_fix(3),t16);
if(C_truep(t17)){
t18=(C_word)C_i_car(t2);
t19=t15;
f_9933(t19,(C_word)C_i_memq(t18,lf[438]));}
else{
t18=t15;
f_9933(t18,C_SCHEME_FALSE);}}
else{
t16=t15;
f_9933(t16,C_SCHEME_FALSE);}}}}}}}}}

/* k9931 in ##compiler#finish-foreign-result in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_9933(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9933,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9936,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1093 gensym */
((C_proc2)C_retrieve_symbol_proc(lf[92]))(2,*((C_word*)lf[92]+1),t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10025,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[3]))){
t3=(C_word)C_i_length(((C_word*)t0)[3]);
t4=(C_word)C_eqp(C_fix(3),t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=t2;
f_10025(t6,(C_word)C_eqp(lf[367],t5));}
else{
t5=t2;
f_10025(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_10025(t3,C_SCHEME_FALSE);}}}

/* k10023 in k9931 in ##compiler#finish-foreign-result in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_10025(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10025,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,lf[365],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[81],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t2,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[436],t7));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* k9934 in k9931 in ##compiler#finish-foreign-result in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_9936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[60],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9936,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[434],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[435],t7);
t9=(C_word)C_i_caddr(((C_word*)t0)[3]);
t10=(C_word)C_a_i_cons(&a,2,lf[365],C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,lf[81],t10);
t12=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,t11,t12);
t14=(C_word)C_a_i_cons(&a,2,t9,t13);
t15=(C_word)C_a_i_cons(&a,2,lf[436],t14);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t8,t16);
t18=(C_word)C_a_i_cons(&a,2,t1,t17);
t19=(C_word)C_a_i_cons(&a,2,lf[437],t18);
t20=(C_word)C_a_i_cons(&a,2,t19,C_SCHEME_END_OF_LIST);
t21=(C_word)C_a_i_cons(&a,2,t4,t20);
t22=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,(C_word)C_a_i_cons(&a,2,lf[91],t21));}

/* ##compiler#estimate-foreign-result-location-size in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_9418(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9418,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9421,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9430,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9728,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1054 follow-without-loop */
((C_proc5)C_retrieve_symbol_proc(lf[76]))(5,*((C_word*)lf[76]+1),t1,t2,t4,t5);}

/* a9727 in ##compiler#estimate-foreign-result-location-size in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_9728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9728,2,t0,t1);}
/* support.scm: 1075 quit */
((C_proc4)C_retrieve_symbol_proc(lf[24]))(4,*((C_word*)lf[24]+1),t1,lf[425],((C_word*)t0)[2]);}

/* a9429 in ##compiler#estimate-foreign-result-location-size in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_9430(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9430,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[334]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9440,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_9440(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[338]);
if(C_truep(t7)){
t8=t6;
f_9440(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[406]);
if(C_truep(t8)){
t9=t6;
f_9440(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[419]);
if(C_truep(t9)){
t10=t6;
f_9440(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[407]);
if(C_truep(t10)){
t11=t6;
f_9440(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[335]);
if(C_truep(t11)){
t12=t6;
f_9440(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[405]);
if(C_truep(t12)){
t13=t6;
f_9440(t13,t12);}
else{
t13=(C_word)C_eqp(t4,lf[381]);
if(C_truep(t13)){
t14=t6;
f_9440(t14,t13);}
else{
t14=(C_word)C_eqp(t4,lf[380]);
if(C_truep(t14)){
t15=t6;
f_9440(t15,t14);}
else{
t15=(C_word)C_eqp(t4,lf[408]);
if(C_truep(t15)){
t16=t6;
f_9440(t16,t15);}
else{
t16=(C_word)C_eqp(t4,lf[409]);
if(C_truep(t16)){
t17=t6;
f_9440(t17,t16);}
else{
t17=(C_word)C_eqp(t4,lf[353]);
if(C_truep(t17)){
t18=t6;
f_9440(t18,t17);}
else{
t18=(C_word)C_eqp(t4,lf[342]);
if(C_truep(t18)){
t19=t6;
f_9440(t19,t18);}
else{
t19=(C_word)C_eqp(t4,lf[355]);
if(C_truep(t19)){
t20=t6;
f_9440(t20,t19);}
else{
t20=(C_word)C_eqp(t4,lf[351]);
if(C_truep(t20)){
t21=t6;
f_9440(t21,t20);}
else{
t21=(C_word)C_eqp(t4,lf[349]);
if(C_truep(t21)){
t22=t6;
f_9440(t22,t21);}
else{
t22=(C_word)C_eqp(t4,lf[340]);
if(C_truep(t22)){
t23=t6;
f_9440(t23,t22);}
else{
t23=(C_word)C_eqp(t4,lf[356]);
if(C_truep(t23)){
t24=t6;
f_9440(t24,t23);}
else{
t24=(C_word)C_eqp(t4,lf[360]);
if(C_truep(t24)){
t25=t6;
f_9440(t25,t24);}
else{
t25=(C_word)C_eqp(t4,lf[402]);
if(C_truep(t25)){
t26=t6;
f_9440(t26,t25);}
else{
t26=(C_word)C_eqp(t4,lf[397]);
if(C_truep(t26)){
t27=t6;
f_9440(t27,t26);}
else{
t27=(C_word)C_eqp(t4,lf[410]);
if(C_truep(t27)){
t28=t6;
f_9440(t28,t27);}
else{
t28=(C_word)C_eqp(t4,lf[411]);
if(C_truep(t28)){
t29=t6;
f_9440(t29,t28);}
else{
t29=(C_word)C_eqp(t4,lf[382]);
if(C_truep(t29)){
t30=t6;
f_9440(t30,t29);}
else{
t30=(C_word)C_eqp(t4,lf[379]);
if(C_truep(t30)){
t31=t6;
f_9440(t31,t30);}
else{
t31=(C_word)C_eqp(t4,lf[375]);
if(C_truep(t31)){
t32=t6;
f_9440(t32,t31);}
else{
t32=(C_word)C_eqp(t4,lf[376]);
if(C_truep(t32)){
t33=t6;
f_9440(t33,t32);}
else{
t33=(C_word)C_eqp(t4,lf[373]);
if(C_truep(t33)){
t34=t6;
f_9440(t34,t33);}
else{
t34=(C_word)C_eqp(t4,lf[359]);
if(C_truep(t34)){
t35=t6;
f_9440(t35,t34);}
else{
t35=(C_word)C_eqp(t4,lf[374]);
if(C_truep(t35)){
t36=t6;
f_9440(t36,t35);}
else{
t36=(C_word)C_eqp(t4,lf[372]);
if(C_truep(t36)){
t37=t6;
f_9440(t37,t36);}
else{
t37=(C_word)C_eqp(t4,lf[377]);
t38=t6;
f_9440(t38,(C_truep(t37)?t37:(C_word)C_eqp(t4,lf[378])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k9438 in a9429 in ##compiler#estimate-foreign-result-location-size in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_9440(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9440,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(1));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub270(C_SCHEME_UNDEFINED,t3));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[403]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[404]));
if(C_truep(t3)){
t4=((C_word*)t0)[6];
t5=(C_word)C_i_foreign_fixnum_argumentp(C_fix(2));
t6=t4;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub270(C_SCHEME_UNDEFINED,t5));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9458,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* support.scm: 1067 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t4,C_retrieve(lf[371]),((C_word*)t0)[3]);}
else{
t5=t4;
f_9458(2,t5,C_SCHEME_FALSE);}}}}

/* k9456 in k9438 in a9429 in ##compiler#estimate-foreign-result-location-size in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_9458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9458,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1069 next */
t4=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[4],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_eqp(t2,lf[362]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9492,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=t4;
f_9492(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[344]);
if(C_truep(t5)){
t6=t4;
f_9492(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[342]);
if(C_truep(t6)){
t7=t4;
f_9492(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[353]);
if(C_truep(t7)){
t8=t4;
f_9492(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[355]);
t9=t4;
f_9492(t9,(C_truep(t8)?t8:(C_word)C_eqp(t2,lf[370])));}}}}}
else{
/* support.scm: 1074 err */
f_9421(((C_word*)t0)[4],((C_word*)t0)[3]);}}}

/* k9490 in k9456 in k9438 in a9429 in ##compiler#estimate-foreign-result-location-size in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_9492(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(1));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub270(C_SCHEME_UNDEFINED,t3));}
else{
/* support.scm: 1073 err */
f_9421(((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* err in ##compiler#estimate-foreign-result-location-size in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_9421(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9421,NULL,2,t1,t2);}
/* support.scm: 1053 quit */
((C_proc4)C_retrieve_symbol_proc(lf[24]))(4,*((C_word*)lf[24]+1),t1,lf[424],t2);}

/* ##compiler#estimate-foreign-result-size in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_9093(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9093,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9099,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9412,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1024 follow-without-loop */
((C_proc5)C_retrieve_symbol_proc(lf[76]))(5,*((C_word*)lf[76]+1),t1,t2,t3,t4);}

/* a9411 in ##compiler#estimate-foreign-result-size in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_9412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9412,2,t0,t1);}
/* support.scm: 1049 quit */
((C_proc4)C_retrieve_symbol_proc(lf[24]))(4,*((C_word*)lf[24]+1),t1,lf[422],((C_word*)t0)[2]);}

/* a9098 in ##compiler#estimate-foreign-result-size in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_9099(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9099,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[334]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9109,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_9109(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[338]);
if(C_truep(t7)){
t8=t6;
f_9109(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[406]);
if(C_truep(t8)){
t9=t6;
f_9109(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[419]);
if(C_truep(t9)){
t10=t6;
f_9109(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[420]);
if(C_truep(t10)){
t11=t6;
f_9109(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[407]);
if(C_truep(t11)){
t12=t6;
f_9109(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[421]);
if(C_truep(t12)){
t13=t6;
f_9109(t13,t12);}
else{
t13=(C_word)C_eqp(t4,lf[335]);
if(C_truep(t13)){
t14=t6;
f_9109(t14,t13);}
else{
t14=(C_word)C_eqp(t4,lf[405]);
if(C_truep(t14)){
t15=t6;
f_9109(t15,t14);}
else{
t15=(C_word)C_eqp(t4,lf[408]);
if(C_truep(t15)){
t16=t6;
f_9109(t16,t15);}
else{
t16=(C_word)C_eqp(t4,lf[409]);
if(C_truep(t16)){
t17=t6;
f_9109(t17,t16);}
else{
t17=(C_word)C_eqp(t4,lf[410]);
t18=t6;
f_9109(t18,(C_truep(t17)?t17:(C_word)C_eqp(t4,lf[411])));}}}}}}}}}}}}

/* k9107 in a9098 in ##compiler#estimate-foreign-result-size in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_9109(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9109,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[356]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9118,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_9118(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[359]);
if(C_truep(t4)){
t5=t3;
f_9118(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[353]);
if(C_truep(t5)){
t6=t3;
f_9118(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[355]);
if(C_truep(t6)){
t7=t3;
f_9118(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[360]);
if(C_truep(t7)){
t8=t3;
f_9118(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[374]);
if(C_truep(t8)){
t9=t3;
f_9118(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[372]);
if(C_truep(t9)){
t10=t3;
f_9118(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[375]);
if(C_truep(t10)){
t11=t3;
f_9118(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[376]);
if(C_truep(t11)){
t12=t3;
f_9118(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[4],lf[373]);
if(C_truep(t12)){
t13=t3;
f_9118(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[4],lf[377]);
t14=t3;
f_9118(t14,(C_truep(t13)?t13:(C_word)C_eqp(((C_word*)t0)[4],lf[378])));}}}}}}}}}}}}

/* k9116 in k9107 in a9098 in ##compiler#estimate-foreign-result-size in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_9118(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9118,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(3));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub270(C_SCHEME_UNDEFINED,t3));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[351]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9130,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_9130(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[381]);
if(C_truep(t4)){
t5=t3;
f_9130(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[349]);
if(C_truep(t5)){
t6=t3;
f_9130(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[380]);
if(C_truep(t6)){
t7=t3;
f_9130(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[382]);
t8=t3;
f_9130(t8,(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[379])));}}}}}}

/* k9128 in k9116 in k9107 in a9098 in ##compiler#estimate-foreign-result-size in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_9130(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9130,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(4));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub270(C_SCHEME_UNDEFINED,t3));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[340]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9142,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_9142(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[403]);
if(C_truep(t4)){
t5=t3;
f_9142(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[404]);
t6=t3;
f_9142(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[4],lf[418])));}}}}

/* k9140 in k9128 in k9116 in k9107 in a9098 in ##compiler#estimate-foreign-result-size in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_9142(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9142,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(4));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub270(C_SCHEME_UNDEFINED,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9148,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
/* support.scm: 1040 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t2,C_retrieve(lf[371]),((C_word*)t0)[2]);}
else{
t3=t2;
f_9148(2,t3,C_SCHEME_FALSE);}}}

/* k9146 in k9140 in k9128 in k9116 in k9107 in a9098 in ##compiler#estimate-foreign-result-size in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_9148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9148,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1042 next */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[3],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_eqp(t2,lf[362]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9182,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t3)){
t5=t4;
f_9182(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[344]);
if(C_truep(t5)){
t6=t4;
f_9182(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[342]);
if(C_truep(t6)){
t7=t4;
f_9182(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[353]);
if(C_truep(t7)){
t8=t4;
f_9182(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[355]);
if(C_truep(t8)){
t9=t4;
f_9182(t9,t8);}
else{
t9=(C_word)C_eqp(t2,lf[370]);
if(C_truep(t9)){
t10=t4;
f_9182(t10,t9);}
else{
t10=(C_word)C_eqp(t2,lf[363]);
if(C_truep(t10)){
t11=t4;
f_9182(t11,t10);}
else{
t11=(C_word)C_eqp(t2,lf[364]);
t12=t4;
f_9182(t12,(C_truep(t11)?t11:(C_word)C_eqp(t2,lf[367])));}}}}}}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}}

/* k9180 in k9146 in k9140 in k9128 in k9116 in k9107 in a9098 in ##compiler#estimate-foreign-result-size in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_9182(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(3));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub270(C_SCHEME_UNDEFINED,t3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}

/* ##compiler#final-foreign-type in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_9053(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9053,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9059,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9087,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1011 follow-without-loop */
((C_proc5)C_retrieve_symbol_proc(lf[76]))(5,*((C_word*)lf[76]+1),t1,t2,t3,t4);}

/* a9086 in ##compiler#final-foreign-type in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_9087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9087,2,t0,t1);}
/* support.scm: 1018 quit */
((C_proc4)C_retrieve_symbol_proc(lf[24]))(4,*((C_word*)lf[24]+1),t1,lf[416],((C_word*)t0)[2]);}

/* a9058 in ##compiler#final-foreign-type in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_9059(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9059,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9063,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 1014 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t4,C_retrieve(lf[371]),t2);}
else{
t5=t4;
f_9063(2,t5,C_SCHEME_FALSE);}}

/* k9061 in a9058 in ##compiler#final-foreign-type in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_9063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1016 next */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[3],t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* ##compiler#foreign-type-convert-argument in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_9022(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9022,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9026,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9035,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1005 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t5,C_retrieve(lf[371]),t3);}
else{
t5=t4;
f_9026(t5,C_SCHEME_FALSE);}}

/* k9033 in ##compiler#foreign-type-convert-argument in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_9035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9035,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(1));
t3=((C_word*)t0)[3];
f_9026(t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_9026(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_9026(t2,C_SCHEME_FALSE);}}

/* k9024 in ##compiler#foreign-type-convert-argument in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_9026(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#foreign-type-convert-result in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_8991(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8991,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8995,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9004,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 998  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t5,C_retrieve(lf[371]),t3);}
else{
t5=t4;
f_8995(t5,C_SCHEME_FALSE);}}

/* k9002 in ##compiler#foreign-type-convert-result in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_9004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9004,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(2));
t3=((C_word*)t0)[3];
f_8995(t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_8995(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_8995(t2,C_SCHEME_FALSE);}}

/* k8993 in ##compiler#foreign-type-convert-result in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_8995(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#foreign-type-check in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7938(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7938,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7944,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8985,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 899  follow-without-loop */
((C_proc5)C_retrieve_symbol_proc(lf[76]))(5,*((C_word*)lf[76]+1),t1,t3,t4,t5);}

/* a8984 in ##compiler#foreign-type-check in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_8985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8985,2,t0,t1);}
/* support.scm: 991  quit */
((C_proc4)C_retrieve_symbol_proc(lf[24]))(4,*((C_word*)lf[24]+1),t1,lf[412],((C_word*)t0)[2]);}

/* a7943 in ##compiler#foreign-type-check in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7944(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7944,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7950,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_7950(t7,t1,t2);}

/* repeat in a7943 in ##compiler#foreign-type-check in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_7950(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7950,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_eqp(t3,lf[334]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[335]));
if(C_truep(t5)){
if(C_truep(C_retrieve(lf[336]))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,((C_word*)t0)[4]);}
else{
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[337],t6));}}
else{
t6=(C_word)C_eqp(t3,lf[338]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7979,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_7979(t8,t6);}
else{
t8=(C_word)C_eqp(t3,lf[405]);
if(C_truep(t8)){
t9=t7;
f_7979(t9,t8);}
else{
t9=(C_word)C_eqp(t3,lf[406]);
if(C_truep(t9)){
t10=t7;
f_7979(t10,t9);}
else{
t10=(C_word)C_eqp(t3,lf[407]);
if(C_truep(t10)){
t11=t7;
f_7979(t11,t10);}
else{
t11=(C_word)C_eqp(t3,lf[408]);
if(C_truep(t11)){
t12=t7;
f_7979(t12,t11);}
else{
t12=(C_word)C_eqp(t3,lf[409]);
if(C_truep(t12)){
t13=t7;
f_7979(t13,t12);}
else{
t13=(C_word)C_eqp(t3,lf[410]);
t14=t7;
f_7979(t14,(C_truep(t13)?t13:(C_word)C_eqp(t3,lf[411])));}}}}}}}}

/* k7977 in repeat in a7943 in ##compiler#foreign-type-check in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_7979(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7979,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[339],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[340]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7998,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_7998(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[403]);
t5=t3;
f_7998(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[404])));}}}

/* k7996 in k7977 in repeat in a7943 in ##compiler#foreign-type-check in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_7998(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7998,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[341],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[342]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8017,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8017(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[400]);
if(C_truep(t4)){
t5=t3;
f_8017(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[401]);
t6=t3;
f_8017(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[402])));}}}}

/* k8015 in k7996 in k7977 in repeat in a7943 in ##compiler#foreign-type-check in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_8017(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8017,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8020,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 909  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[92]))(2,*((C_word*)lf[92]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[344]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8087,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8087(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[397]);
if(C_truep(t4)){
t5=t3;
f_8087(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[398]);
t6=t3;
f_8087(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[399])));}}}}

/* k8085 in k8015 in k7996 in k7977 in repeat in a7943 in ##compiler#foreign-type-check in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_8087(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8087,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[343],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[345]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8106,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8106(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[390]);
if(C_truep(t4)){
t5=t3;
f_8106(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[391]);
if(C_truep(t5)){
t6=t3;
f_8106(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[392]);
if(C_truep(t6)){
t7=t3;
f_8106(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[393]);
if(C_truep(t7)){
t8=t3;
f_8106(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[394]);
if(C_truep(t8)){
t9=t3;
f_8106(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[395]);
t10=t3;
f_8106(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[5],lf[396])));}}}}}}}}

/* k8104 in k8085 in k8015 in k7996 in k7977 in repeat in a7943 in ##compiler#foreign-type-check in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_8106(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8106,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8109,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 921  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[92]))(2,*((C_word*)lf[92]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[347]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8188,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8188(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[383]);
if(C_truep(t4)){
t5=t3;
f_8188(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[384]);
if(C_truep(t5)){
t6=t3;
f_8188(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[385]);
if(C_truep(t6)){
t7=t3;
f_8188(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[386]);
if(C_truep(t7)){
t8=t3;
f_8188(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[387]);
if(C_truep(t8)){
t9=t3;
f_8188(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[388]);
t10=t3;
f_8188(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[4],lf[389])));}}}}}}}}

/* k8186 in k8104 in k8085 in k8015 in k7996 in k7977 in repeat in a7943 in ##compiler#foreign-type-check in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_8188(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8188,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[5],lf[348]);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[81],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[346],t7));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[349]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8227,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8227(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[381]);
t5=t3;
f_8227(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[4],lf[382])));}}}

/* k8225 in k8186 in k8104 in k8085 in k8015 in k7996 in k7977 in repeat in a7943 in ##compiler#foreign-type-check in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_8227(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8227,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[350],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[351]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8246,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8246(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[379]);
t5=t3;
f_8246(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[380])));}}}

/* k8244 in k8225 in k8186 in k8104 in k8085 in k8015 in k7996 in k7977 in repeat in a7943 in ##compiler#foreign-type-check in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_8246(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8246,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[352],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[353]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8265,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8265(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[377]);
t5=t3;
f_8265(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[378])));}}}

/* k8263 in k8244 in k8225 in k8186 in k8104 in k8085 in k8015 in k7996 in k7977 in repeat in a7943 in ##compiler#foreign-type-check in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_8265(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8265,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8268,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 941  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[92]))(2,*((C_word*)lf[92]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[355]);
if(C_truep(t2)){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[354],t3));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[356]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8345,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_8345(t5,t3);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[374]);
if(C_truep(t5)){
t6=t4;
f_8345(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[375]);
t7=t4;
f_8345(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[5],lf[376])));}}}}}

/* k8343 in k8263 in k8244 in k8225 in k8186 in k8104 in k8085 in k8015 in k7996 in k7977 in repeat in a7943 in ##compiler#foreign-type-check in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_8345(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8345,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8348,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 949  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[92]))(2,*((C_word*)lf[92]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[359]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8430,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8430(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[372]);
t5=t3;
f_8430(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[373])));}}}

/* k8428 in k8343 in k8263 in k8244 in k8225 in k8186 in k8104 in k8085 in k8015 in k7996 in k7977 in repeat in a7943 in ##compiler#foreign-type-check in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_8430(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8430,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[357],t2));}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[358],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[357],t4));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[360]);
if(C_truep(t2)){
if(C_truep(C_retrieve(lf[336]))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[361],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[357],t5));}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[361],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[358],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[357],t7));}}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8505,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* support.scm: 965  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t3,C_retrieve(lf[371]),((C_word*)t0)[3]);}
else{
t4=t3;
f_8505(2,t4,C_SCHEME_FALSE);}}}}

/* k8503 in k8428 in k8343 in k8263 in k8244 in k8225 in k8186 in k8104 in k8085 in k8015 in k7996 in k7977 in repeat in a7943 in ##compiler#foreign-type-check in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_8505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8505,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 967  next */
t4=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[5],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[362]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8539,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t3)){
t5=t4;
f_8539(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[342]);
if(C_truep(t5)){
t6=t4;
f_8539(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[370]);
t7=t4;
f_8539(t7,(C_truep(t6)?t6:(C_word)C_eqp(t2,lf[353])));}}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}}

/* k8537 in k8503 in k8428 in k8343 in k8263 in k8244 in k8225 in k8186 in k8104 in k8085 in k8015 in k7996 in k7977 in repeat in a7943 in ##compiler#foreign-type-check in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_8539(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8539,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8542,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 971  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[92]))(2,*((C_word*)lf[92]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[363]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[4],lf[364]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8609,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 977  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[92]))(2,*((C_word*)lf[92]+1),t4);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[367]);
if(C_truep(t4)){
t5=(C_word)C_a_i_cons(&a,2,lf[365],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[81],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t7);
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[366],t8));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[368]);
if(C_truep(t5)){
t6=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* support.scm: 984  repeat */
t7=((C_word*)((C_word*)t0)[2])[1];
f_7950(t7,((C_word*)t0)[5],t6);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[369]);
if(C_truep(t6)){
if(C_truep(C_retrieve(lf[336]))){
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,((C_word*)t0)[6]);}
else{
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[350],t7));}}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[344]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[355]));
if(C_truep(t8)){
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t10=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[354],t9));}
else{
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,((C_word*)t0)[6]);}}}}}}}

/* k8607 in k8537 in k8503 in k8428 in k8343 in k8263 in k8244 in k8225 in k8186 in k8104 in k8085 in k8015 in k7996 in k7977 in repeat in a7943 in ##compiler#foreign-type-check in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_8609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8609,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[365],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[81],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[366],t8);
t10=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,lf[81],t10);
t12=(C_word)C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,t9,t12);
t14=(C_word)C_a_i_cons(&a,2,t1,t13);
t15=(C_word)C_a_i_cons(&a,2,lf[215],t14);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t4,t16);
t18=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_cons(&a,2,lf[91],t17));}

/* k8540 in k8537 in k8503 in k8428 in k8343 in k8263 in k8244 in k8225 in k8186 in k8104 in k8085 in k8015 in k7996 in k7977 in repeat in a7943 in ##compiler#foreign-type-check in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_8542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8542,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[354],t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[81],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t6,t9);
t11=(C_word)C_a_i_cons(&a,2,t1,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[215],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t4,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[91],t14));}

/* k8346 in k8343 in k8263 in k8244 in k8225 in k8186 in k8104 in k8085 in k8015 in k7996 in k7977 in repeat in a7943 in ##compiler#foreign-type-check in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_8348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8348,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8379,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[336]))){
t6=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=t5;
f_8379(t7,(C_word)C_a_i_cons(&a,2,lf[357],t6));}
else{
t6=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[358],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=t5;
f_8379(t9,(C_word)C_a_i_cons(&a,2,lf[357],t8));}}

/* k8377 in k8346 in k8343 in k8263 in k8244 in k8225 in k8186 in k8104 in k8085 in k8015 in k7996 in k7977 in repeat in a7943 in ##compiler#foreign-type-check in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_8379(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8379,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[81],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[215],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[91],t9));}

/* k8266 in k8263 in k8244 in k8225 in k8186 in k8104 in k8085 in k8015 in k7996 in k7977 in repeat in a7943 in ##compiler#foreign-type-check in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_8268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8268,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[354],t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[81],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t6,t9);
t11=(C_word)C_a_i_cons(&a,2,t1,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[215],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t4,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[91],t14));}

/* k8107 in k8104 in k8085 in k8015 in k7996 in k7977 in repeat in a7943 in ##compiler#foreign-type-check in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_8109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8109,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8140,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[336]))){
t6=t5;
f_8140(t6,t1);}
else{
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[81],t6);
t8=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
t10=t5;
f_8140(t10,(C_word)C_a_i_cons(&a,2,lf[346],t9));}}

/* k8138 in k8107 in k8104 in k8085 in k8015 in k7996 in k7977 in repeat in a7943 in ##compiler#foreign-type-check in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_8140(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8140,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[81],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[215],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[91],t9));}

/* k8018 in k8015 in k7996 in k7977 in repeat in a7943 in ##compiler#foreign-type-check in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_8020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8020,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8051,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[336]))){
t6=t5;
f_8051(t6,t1);}
else{
t6=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=t5;
f_8051(t7,(C_word)C_a_i_cons(&a,2,lf[343],t6));}}

/* k8049 in k8018 in k8015 in k7996 in k7977 in repeat in a7943 in ##compiler#foreign-type-check in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_8051(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8051,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[81],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[215],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[91],t9));}

/* ##compiler#pprint-expressions-to-file in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7886(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7886,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7890,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
/* support.scm: 880  open-output-file */
((C_proc3)C_retrieve_proc(*((C_word*)lf[331]+1)))(3,*((C_word*)lf[331]+1),t4,t3);}
else{
/* support.scm: 880  current-output-port */
((C_proc2)C_retrieve_proc(*((C_word*)lf[332]+1)))(2,*((C_word*)lf[332]+1),t4);}}

/* k7888 in ##compiler#pprint-expressions-to-file in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7893,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7901,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 881  with-output-to-port */
((C_proc4)C_retrieve_symbol_proc(lf[330]))(4,*((C_word*)lf[330]+1),t2,t1,t3);}

/* a7900 in k7888 in ##compiler#pprint-expressions-to-file in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7901,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7907,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_7907(t5,t1,((C_word*)t0)[2]);}

/* loop1676 in a7900 in k7888 in ##compiler#pprint-expressions-to-file in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_7907(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7907,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7920,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 885  pretty-print */
((C_proc3)C_retrieve_symbol_proc(lf[329]))(3,*((C_word*)lf[329]+1),t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k7918 in loop1676 in a7900 in k7888 in ##compiler#pprint-expressions-to-file in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7920,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7923,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 886  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[13]+1)))(2,*((C_word*)lf[13]+1),t2);}

/* k7921 in k7918 in loop1676 in a7900 in k7888 in ##compiler#pprint-expressions-to-file in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7907(t3,((C_word*)t0)[2],t2);}

/* k7891 in k7888 in ##compiler#pprint-expressions-to-file in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* support.scm: 888  close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[328]+1)))(3,*((C_word*)lf[328]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##compiler#print-program-statistics in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7805(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7805,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7811,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7817,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a7816 in ##compiler#print-program-statistics in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7817(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_7817,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7824,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t5,a[6]=t6,a[7]=t7,a[8]=t8,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* support.scm: 868  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[10]))(4,*((C_word*)lf[10]+1),t9,lf[325],lf[326]);}

/* k7822 in a7816 in ##compiler#print-program-statistics in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7824,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7827,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t3,lf[324],t2);}
else{
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7825 in k7822 in a7816 in ##compiler#print-program-statistics in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7827,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7830,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k7828 in k7825 in k7822 in a7816 in ##compiler#print-program-statistics in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7830,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7833,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,lf[323],((C_word*)t0)[3]);}

/* k7831 in k7828 in k7825 in k7822 in a7816 in ##compiler#print-program-statistics in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7833,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7836,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k7834 in k7831 in k7828 in k7825 in k7822 in a7816 in ##compiler#print-program-statistics in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7836,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7839,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* write-char/port */
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k7837 in k7834 in k7831 in k7828 in k7825 in k7822 in a7816 in ##compiler#print-program-statistics in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7839,2,t0,t1);}
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7842,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t3,lf[322],t2);}

/* k7840 in k7837 in k7834 in k7831 in k7828 in k7825 in k7822 in a7816 in ##compiler#print-program-statistics in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7842,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7845,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k7843 in k7840 in k7837 in k7834 in k7831 in k7828 in k7825 in k7822 in a7816 in ##compiler#print-program-statistics in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7848,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* write-char/port */
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7828 in k7825 in k7822 in a7816 in ##compiler#print-program-statistics in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7848,2,t0,t1);}
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7851,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t3,lf[321],t2);}

/* k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7828 in k7825 in k7822 in a7816 in ##compiler#print-program-statistics in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7854,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7828 in k7825 in k7822 in a7816 in ##compiler#print-program-statistics in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7857,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7828 in k7825 in k7822 in a7816 in ##compiler#print-program-statistics in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7857,2,t0,t1);}
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7860,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t3,lf[320],t2);}

/* k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7828 in k7825 in k7822 in a7816 in ##compiler#print-program-statistics in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7863,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7828 in k7825 in k7822 in a7816 in ##compiler#print-program-statistics in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7866,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7828 in k7825 in k7822 in a7816 in ##compiler#print-program-statistics in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7866,2,t0,t1);}
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7869,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t3,lf[319],t2);}

/* k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7828 in k7825 in k7822 in a7816 in ##compiler#print-program-statistics in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7869,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7872,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7828 in k7825 in k7822 in a7816 in ##compiler#print-program-statistics in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7872,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7875,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7828 in k7825 in k7822 in a7816 in ##compiler#print-program-statistics in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7875,2,t0,t1);}
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7878,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t3,lf[318],t2);}

/* k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7828 in k7825 in k7822 in a7816 in ##compiler#print-program-statistics in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7878,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7881,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7828 in k7825 in k7822 in a7816 in ##compiler#print-program-statistics in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* a7810 in ##compiler#print-program-statistics in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7811,2,t0,t1);}
/* support.scm: 867  compute-database-statistics */
((C_proc3)C_retrieve_symbol_proc(lf[314]))(3,*((C_word*)lf[314]+1),t1,((C_word*)t0)[2]);}

/* ##compiler#compute-database-statistics in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7709(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7709,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_fix(0);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(0);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_fix(0);
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7713,a[2]=t10,a[3]=t12,a[4]=t8,a[5]=t4,a[6]=t6,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7718,a[2]=t12,a[3]=t4,a[4]=t6,a[5]=t8,a[6]=t10,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 843  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[150]))(4,*((C_word*)lf[150]+1),t13,t14,t2);}

/* a7717 in ##compiler#compute-database-statistics in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7718(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7718,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7724,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t5,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_7724(t7,t1,t3);}

/* loop1603 in a7717 in ##compiler#compute-database-statistics in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_7724(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7724,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],C_fix(1));
t5=C_mutate(((C_word *)((C_word*)t0)[7])+1,t4);
t6=(C_word)C_i_car(t3);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7744,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_eqp(t6,lf[179]);
if(C_truep(t8)){
t9=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t10=C_mutate(((C_word *)((C_word*)t0)[5])+1,t9);
t11=t7;
f_7744(t11,t10);}
else{
t9=(C_word)C_eqp(t6,lf[161]);
if(C_truep(t9)){
t10=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[4])[1],C_fix(1));
t11=C_mutate(((C_word *)((C_word*)t0)[4])+1,t10);
t12=(C_word)C_i_cdr(t3);
t13=(C_word)C_slot(t12,C_fix(1));
t14=(C_word)C_eqp(lf[223],t13);
if(C_truep(t14)){
t15=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t16=C_mutate(((C_word *)((C_word*)t0)[3])+1,t15);
t17=t7;
f_7744(t17,t16);}
else{
t15=t7;
f_7744(t15,C_SCHEME_UNDEFINED);}}
else{
t10=(C_word)C_eqp(t6,lf[167]);
if(C_truep(t10)){
t11=(C_word)C_i_cdr(t3);
t12=(C_word)C_i_length(t11);
t13=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t12);
t14=C_mutate(((C_word *)((C_word*)t0)[2])+1,t13);
t15=t7;
f_7744(t15,t14);}
else{
t11=t7;
f_7744(t11,C_SCHEME_UNDEFINED);}}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k7742 in loop1603 in a7717 in ##compiler#compute-database-statistics in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_7744(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7724(t3,((C_word*)t0)[2],t2);}

/* k7711 in ##compiler#compute-database-statistics in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 857  values */
C_values(9,0,((C_word*)t0)[7],C_retrieve(lf[315]),C_retrieve(lf[316]),((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* ##sys#toplevel-definition-hook in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7688(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_7688,6,t0,t1,t2,t3,t4,t5);}
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_i_not(t4));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7698,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 820  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[10]))(5,*((C_word*)lf[10]+1),t7,lf[246],lf[313],t2);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}}

/* k7696 in ##sys#toplevel-definition-hook in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 821  hide-variable */
((C_proc3)C_retrieve_symbol_proc(lf[312]))(3,*((C_word*)lf[312]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#dump-global-refs in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7639(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7639,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7645,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 806  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[150]))(4,*((C_word*)lf[150]+1),t1,t3,t2);}

/* a7644 in ##compiler#dump-global-refs in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7645(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7645,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7686,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 808  keyword? */
((C_proc3)C_retrieve_symbol_proc(lf[308]))(3,*((C_word*)lf[308]+1),t4,t2);}

/* k7684 in a7644 in ##compiler#dump-global-refs in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7686,2,t0,t1);}
t2=(C_truep(t1)?C_SCHEME_FALSE:(C_word)C_i_assq(lf[179],((C_word*)t0)[4]));
if(C_truep(t2)){
t3=(C_word)C_i_assq(lf[166],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7658,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7669,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t6=(C_word)C_i_cdr(t3);
t7=t5;
f_7669(t7,(C_word)C_i_length(t6));}
else{
t6=t5;
f_7669(t6,C_fix(0));}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k7667 in k7684 in a7644 in ##compiler#dump-global-refs in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_7669(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7669,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
/* support.scm: 810  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),((C_word*)t0)[2],t2);}

/* k7656 in k7684 in a7644 in ##compiler#dump-global-refs in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 811  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[13]+1)))(2,*((C_word*)lf[13]+1),((C_word*)t0)[2]);}

/* ##compiler#dump-defined-globals in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7602(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7602,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7608,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 796  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[150]))(4,*((C_word*)lf[150]+1),t1,t3,t2);}

/* a7607 in ##compiler#dump-defined-globals in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7608(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7608,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7615,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7637,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 798  keyword? */
((C_proc3)C_retrieve_symbol_proc(lf[308]))(3,*((C_word*)lf[308]+1),t5,t2);}

/* k7635 in a7607 in ##compiler#dump-defined-globals in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_7615(t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_assq(lf[179],((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_7615(t3,(C_truep(t2)?(C_word)C_i_assq(lf[177],((C_word*)t0)[2]):C_SCHEME_FALSE));}}

/* k7613 in a7607 in ##compiler#dump-defined-globals in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_7615(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7615,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7618,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 801  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7616 in k7613 in a7607 in ##compiler#dump-defined-globals in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 802  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[13]+1)))(2,*((C_word*)lf[13]+1),((C_word*)t0)[2]);}

/* ##compiler#dump-undefined-globals in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7561(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7561,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7567,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 786  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[150]))(4,*((C_word*)lf[150]+1),t1,t3,t2);}

/* a7566 in ##compiler#dump-undefined-globals in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7567(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7567,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7574,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7600,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 788  keyword? */
((C_proc3)C_retrieve_symbol_proc(lf[308]))(3,*((C_word*)lf[308]+1),t5,t2);}

/* k7598 in a7566 in ##compiler#dump-undefined-globals in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_7574(t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_assq(lf[179],((C_word*)t0)[2]))){
t2=(C_word)C_i_assq(lf[177],((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_7574(t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[3];
f_7574(t2,C_SCHEME_FALSE);}}}

/* k7572 in a7566 in ##compiler#dump-undefined-globals in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_7574(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7574,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7577,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 791  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7575 in k7572 in a7566 in ##compiler#dump-undefined-globals in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 792  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[13]+1)))(2,*((C_word*)lf[13]+1),((C_word*)t0)[2]);}

/* ##compiler#simple-lambda-node? in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7469(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7469,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_caddr(t4);
t6=(C_word)C_i_pairp(t5);
t7=(C_truep(t6)?(C_word)C_i_car(t5):C_SCHEME_FALSE);
if(C_truep(t7)){
if(C_truep((C_word)C_i_cadr(t4))){
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7493,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t11=((C_word*)t9)[1];
f_7493(3,t11,t1,t2);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}

/* rec in ##compiler#simple-lambda-node? in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7493(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7493,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(t4,lf[235]);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=(C_word)C_i_car(t7);
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(lf[210],t9);
if(C_truep(t10)){
t11=(C_word)C_slot(t8,C_fix(2));
t12=(C_word)C_i_car(t11);
t13=(C_word)C_eqp(((C_word*)t0)[3],t12);
if(C_truep(t13)){
t14=(C_word)C_i_cdr(t7);
/* support.scm: 778  every */
((C_proc4)C_retrieve_symbol_proc(lf[86]))(4,*((C_word*)lf[86]+1),t1,((C_word*)((C_word*)t0)[2])[1],t14);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t6=(C_word)C_eqp(t4,lf[226]);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}
else{
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
/* support.scm: 780  every */
((C_proc4)C_retrieve_symbol_proc(lf[86]))(4,*((C_word*)lf[86]+1),t1,((C_word*)((C_word*)t0)[2])[1],t8);}}}

/* ##compiler#expression-has-side-effects? in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7383(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7383,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7389,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_7389(3,t7,t1,t2);}

/* walk in ##compiler#expression-has-side-effects? in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7389(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7389,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(1));
t7=(C_word)C_eqp(t6,lf[210]);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7405,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t6,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t7)){
t9=t8;
f_7405(t9,t7);}
else{
t9=(C_word)C_eqp(t6,lf[81]);
if(C_truep(t9)){
t10=t8;
f_7405(t10,t9);}
else{
t10=(C_word)C_eqp(t6,lf[216]);
if(C_truep(t10)){
t11=t8;
f_7405(t11,t10);}
else{
t11=(C_word)C_eqp(t6,lf[227]);
t12=t8;
f_7405(t12,(C_truep(t11)?t11:(C_word)C_eqp(t6,lf[214])));}}}}

/* k7403 in walk in ##compiler#expression-has-side-effects? in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_7405(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7405,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[223]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7419,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 761  find */
((C_proc4)C_retrieve_symbol_proc(lf[304]))(4,*((C_word*)lf[304]+1),((C_word*)t0)[6],t6,C_retrieve(lf[305]));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[215]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[91]));
if(C_truep(t4)){
/* support.scm: 762  any */
((C_proc4)C_retrieve_symbol_proc(lf[60]))(4,*((C_word*)lf[60]+1),((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}}}}

/* a7418 in k7403 in walk in ##compiler#expression-has-side-effects? in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7419(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7419,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7427,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 761  foreign-callback-stub-id */
((C_proc3)C_retrieve_symbol_proc(lf[303]))(3,*((C_word*)lf[303]+1),t3,t2);}

/* k7425 in a7418 in k7403 in walk in ##compiler#expression-has-side-effects? in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* ##compiler#match-node in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7188(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7188,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7191,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7220,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7263,a[2]=t9,a[3]=t12,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7367,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 745  matchn */
t15=((C_word*)t12)[1];
f_7263(t15,t14,t2,t3);}

/* k7365 in ##compiler#match-node in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7367,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7373,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=(C_word)C_slot(t3,C_fix(1));
t5=((C_word*)t0)[3];
t6=(C_word)C_slot(t5,C_fix(2));
/* support.scm: 748  debugging */
((C_proc7)C_retrieve_symbol_proc(lf[10]))(7,*((C_word*)lf[10]+1),t2,lf[300],lf[301],t4,t6,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7371 in k7365 in ##compiler#match-node in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* matchn in ##compiler#match-node in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_7263(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7263,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 734  resolve */
t4=((C_word*)t0)[4];
f_7191(t4,t1,t3,t2);}
else{
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_i_car(t3);
t7=(C_word)C_eqp(t5,t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7285,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t9=t2;
t10=(C_word)C_slot(t9,C_fix(2));
t11=(C_word)C_i_cadr(t3);
/* support.scm: 736  match1 */
t12=((C_word*)((C_word*)t0)[2])[1];
f_7220(t12,t8,t10,t11);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}

/* k7283 in matchn in ##compiler#match-node in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7285,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
t3=(C_word)C_slot(t2,C_fix(3));
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7298,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_7298(t8,((C_word*)t0)[2],t3,t4);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop in k7283 in matchn in ##compiler#match-node in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_7298(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7298,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_nullp(t2));}
else{
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 740  resolve */
t4=((C_word*)t0)[4];
f_7191(t4,t1,t3,t2);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7329,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* support.scm: 742  matchn */
t7=((C_word*)((C_word*)t0)[2])[1];
f_7263(t7,t4,t5,t6);}}}}

/* k7327 in loop in k7283 in matchn in ##compiler#match-node in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 743  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7298(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* match1 in ##compiler#match-node in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_7220(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7220,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 727  resolve */
t4=((C_word*)t0)[3];
f_7191(t4,t1,t3,t2);}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7242,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* support.scm: 729  match1 */
t8=t4;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}

/* k7240 in match1 in ##compiler#match-node in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 729  match1 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7220(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* resolve in ##compiler#match-node in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_7191(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7191,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_equalp(t3,t5));}
else{
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[2]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7215,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 722  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),t5,t2,t3,((C_word*)((C_word*)t0)[3])[1]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t2,t3));}}}

/* k7213 in resolve in ##compiler#match-node in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* ##compiler#load-inline-file in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7119(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7119,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7125,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 702  with-input-from-file */
((C_proc4)C_retrieve_symbol_proc(lf[298]))(4,*((C_word*)lf[298]+1),t1,t2,t3);}

/* a7124 in ##compiler#load-inline-file in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7125,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7131,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_7131(t5,t1);}

/* loop in a7124 in ##compiler#load-inline-file in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_7131(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7131,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7135,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 705  read */
((C_proc2)C_retrieve_proc(*((C_word*)lf[100]+1)))(2,*((C_word*)lf[100]+1),t2);}

/* k7133 in loop in a7124 in ##compiler#load-inline-file in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7135,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7171,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(t1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7182,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(t1);
/* support.scm: 710  sexpr->node */
((C_proc3)C_retrieve_symbol_proc(lf[278]))(3,*((C_word*)lf[278]+1),t4,t5);}}

/* k7180 in k7133 in loop in a7124 in ##compiler#load-inline-file in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7182,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7146,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_7146(2,t4,C_SCHEME_TRUE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_7146(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k7144 in k7180 in k7133 in loop in a7124 in ##compiler#load-inline-file in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[290],t1);}

/* k7169 in k7133 in loop in a7124 in ##compiler#load-inline-file in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 711  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_7131(t2,((C_word*)t0)[2]);}

/* ##compiler#emit-global-inline-file in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6933(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6933,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6937,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6980,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 671  with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[296]))(4,*((C_word*)lf[296]+1),t6,t2,t7);}

/* a6979 in ##compiler#emit-global-inline-file in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6984,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7117,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 673  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[295]))(2,*((C_word*)lf[295]+1),t3);}

/* k7115 in a6979 in ##compiler#emit-global-inline-file in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 673  print */
((C_proc7)C_retrieve_proc(*((C_word*)lf[280]+1)))(7,*((C_word*)lf[280]+1),((C_word*)t0)[2],lf[292],t1,lf[293],C_retrieve(lf[237]),lf[294]);}

/* k6982 in a6979 in ##compiler#emit-global-inline-file in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6987,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6992,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 675  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[150]))(4,*((C_word*)lf[150]+1),t2,t3,((C_word*)t0)[2]);}

/* a6991 in k6982 in a6979 in ##compiler#emit-global-inline-file in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6992(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6992,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6999,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 677  variable-visible? */
((C_proc3)C_retrieve_symbol_proc(lf[291]))(3,*((C_word*)lf[291]+1),t4,t2);}

/* k6997 in a6991 in k6982 in a6979 in ##compiler#emit-global-inline-file in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6999,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[163],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7110,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[239]))(4,*((C_word*)lf[239]+1),t4,t3,lf[290]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7108 in k6997 in a6991 in k6982 in a6979 in ##compiler#emit-global-inline-file in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7110,2,t0,t1);}
if(C_truep((C_word)C_i_structurep(t1,lf[200]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_assq(lf[161],((C_word*)t0)[6]);
t3=(C_word)C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7023,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_7023(t5,t3);}
else{
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_eqp(lf[157],t5);
t7=t4;
f_7023(t7,(C_word)C_i_not(t6));}}}

/* k7021 in k7108 in k6997 in a6991 in k6982 in a6979 in ##compiler#emit-global-inline-file in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_7023(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7023,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_assq(lf[189],((C_word*)t0)[7]))){
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_slot(t2,C_fix(2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7095,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 686  get */
((C_proc5)C_retrieve_symbol_proc(lf[133]))(5,*((C_word*)lf[133]+1),t4,((C_word*)t0)[2],((C_word*)t0)[4],lf[196]);}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7093 in k7021 in k7108 in k6997 in a6991 in k6982 in a6979 in ##compiler#emit-global-inline-file in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7095,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=((C_word*)t0)[5];
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7050,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[239]))(4,*((C_word*)lf[239]+1),t3,t2,lf[289]);}}

/* k7048 in k7093 in k7021 in k7108 in k6997 in a6991 in k6982 in a6979 in ##compiler#emit-global-inline-file in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7050,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7053,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(t1,lf[286]);
if(C_truep(t3)){
t4=t2;
f_7053(t4,C_SCHEME_TRUE);}
else{
t4=(C_word)C_eqp(t1,lf[287]);
if(C_truep(t4)){
t5=t2;
f_7053(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cadddr(((C_word*)t0)[2]);
t6=C_retrieve(lf[288]);
t7=t2;
f_7053(t7,(C_word)C_fixnum_lessp(t5,t6));}}}

/* k7051 in k7048 in k7093 in k7021 in k7108 in k6997 in a6991 in k6982 in a6979 in ##compiler#emit-global-inline-file in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_7053(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7053,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7060,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7071,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* support.scm: 693  node->sexpr */
((C_proc3)C_retrieve_symbol_proc(lf[277]))(3,*((C_word*)lf[277]+1),t5,t6);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7069 in k7051 in k7048 in k7093 in k7021 in k7108 in k6997 in a6991 in k6982 in a6979 in ##compiler#emit-global-inline-file in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7071,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
/* support.scm: 693  pp */
((C_proc3)C_retrieve_symbol_proc(lf[285]))(3,*((C_word*)lf[285]+1),((C_word*)t0)[2],t2);}

/* k7058 in k7051 in k7048 in k7093 in k7021 in k7108 in k6997 in a6991 in k6982 in a6979 in ##compiler#emit-global-inline-file in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_7060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 694  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[13]+1)))(2,*((C_word*)lf[13]+1),((C_word*)t0)[2]);}

/* k6985 in k6982 in a6979 in ##compiler#emit-global-inline-file in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 696  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[280]+1)))(3,*((C_word*)lf[280]+1),((C_word*)t0)[2],lf[284]);}

/* k6935 in ##compiler#emit-global-inline-file in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6937,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6943,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
/* support.scm: 698  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[10]))(4,*((C_word*)lf[10]+1),t2,lf[282],lf[283]);}
else{
t3=t2;
f_6943(2,t3,C_SCHEME_FALSE);}}

/* k6941 in k6935 in ##compiler#emit-global-inline-file in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6943,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6950,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 699  sort-symbols */
((C_proc3)C_retrieve_symbol_proc(lf[77]))(3,*((C_word*)lf[77]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k6948 in k6941 in k6935 in ##compiler#emit-global-inline-file in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6950,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6952,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_6952(t5,((C_word*)t0)[2],t1);}

/* loop1380 in k6948 in k6941 in k6935 in ##compiler#emit-global-inline-file in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_6952(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6952,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6965,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[280]+1)))(4,*((C_word*)lf[280]+1),t4,lf[281],t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6963 in loop1380 in k6948 in k6941 in k6935 in ##compiler#emit-global-inline-file in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6952(t3,((C_word*)t0)[2],t2);}

/* ##compiler#sexpr->node in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6908(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6908,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6914,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_6914(3,t6,t1,t2);}

/* walk in ##compiler#sexpr->node in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6914(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6914,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6924,a[2]=t4,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cddr(t2);
/* map */
t7=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)((C_word*)t0)[2])[1],t6);}

/* k6922 in walk in ##compiler#sexpr->node in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6924,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[200],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* ##compiler#node->sexpr in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6872(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6872,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6878,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_6878(3,t6,t1,t2);}

/* walk in ##compiler#node->sexpr in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6878(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6878,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6898,a[2]=t4,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6902,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=t2;
t10=(C_word)C_slot(t9,C_fix(3));
/* map */
t11=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t8,((C_word*)((C_word*)t0)[2])[1],t10);}

/* k6900 in walk in ##compiler#node->sexpr in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[99]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6896 in walk in ##compiler#node->sexpr in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6898,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* ##compiler#copy-node! in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6848(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6848,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6852,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=(C_word)C_slot(t5,C_fix(1));
/* support.scm: 654  node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[202]))(4,*((C_word*)lf[202]+1),t4,t3,t6);}

/* k6850 in ##compiler#copy-node! in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6852,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6855,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_slot(t3,C_fix(2));
/* support.scm: 655  node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[205]))(4,*((C_word*)lf[205]+1),t2,((C_word*)t0)[3],t4);}

/* k6853 in k6850 in ##compiler#copy-node! in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6858,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_slot(t3,C_fix(3));
/* support.scm: 656  node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[207]))(4,*((C_word*)lf[207]+1),t2,((C_word*)t0)[3],t4);}

/* k6856 in k6853 in k6850 in ##compiler#copy-node! in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#tree-copy in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6814(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6814,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6820,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_6820(t6,t1,t2);}

/* rec in ##compiler#tree-copy in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_6820(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6820,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6834,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 650  rec */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k6832 in rec in ##compiler#tree-copy in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6838,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 650  rec */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6820(t4,t2,t3);}

/* k6836 in k6832 in rec in ##compiler#tree-copy in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6838,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#copy-node-tree-and-rename in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_6604,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6608,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 604  map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[251]+1)))(5,*((C_word*)lf[251]+1),t6,*((C_word*)lf[273]+1),t3,t4);}

/* k6606 in ##compiler#copy-node-tree-and-rename in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6608,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6610,tmp=(C_word)a,a+=2,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6616,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
/* support.scm: 645  walk */
t6=((C_word*)t4)[1];
f_6616(t6,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* walk in k6606 in ##compiler#copy-node-tree-and-rename in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_6616(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word *a;
loop:
a=C_alloc(11);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6616,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[210]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t7);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6638,a[2]=t3,a[3]=t11,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6648,a[2]=t11,a[3]=((C_word*)t0)[3],a[4]=t12,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 613  get */
((C_proc5)C_retrieve_symbol_proc(lf[133]))(5,*((C_word*)lf[133]+1),t13,((C_word*)t0)[3],t11,lf[180]);}
else{
t11=(C_word)C_eqp(t9,lf[228]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6678,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t13=(C_word)C_i_car(t7);
/* support.scm: 618  rename */
f_6610(t12,t13,t3);}
else{
t12=(C_word)C_eqp(t9,lf[91]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t7);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6694,a[2]=t3,a[3]=t13,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t15=(C_word)C_i_car(t5);
/* support.scm: 622  walk */
t26=t14;
t27=t15;
t28=t3;
t1=t26;
t2=t27;
t3=t28;
goto loop;}
else{
t13=(C_word)C_eqp(t9,lf[223]);
if(C_truep(t13)){
t14=(C_word)C_i_caddr(t7);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6736,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=((C_word*)t0)[2],a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* support.scm: 629  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),t1,t14,t15);}
else{
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6797,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t9,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 644  tree-copy */
((C_proc3)C_retrieve_symbol_proc(lf[275]))(3,*((C_word*)lf[275]+1),t14,t7);}}}}}

/* k6795 in walk in k6606 in ##compiler#copy-node-tree-and-rename in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6797,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6800,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6805,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a6804 in k6795 in walk in k6606 in ##compiler#copy-node-tree-and-rename in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6805(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6805,3,t0,t1,t2);}
/* walk1242 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6616(t3,t1,t2,((C_word*)t0)[2]);}

/* k6798 in k6795 in walk in k6606 in ##compiler#copy-node-tree-and-rename in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6800,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[200],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* a6735 in walk in k6606 in ##compiler#copy-node-tree-and-rename in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6736(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6736,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6740,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t1,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6787,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t7=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a6786 in a6735 in walk in k6606 in ##compiler#copy-node-tree-and-rename in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6787(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6787,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6791,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 633  gensym */
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),t3,t2);}

/* k6789 in a6786 in a6735 in walk in k6606 in ##compiler#copy-node-tree-and-rename in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6791,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6794,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 634  put! */
((C_proc6)C_retrieve_symbol_proc(lf[137]))(6,*((C_word*)lf[137]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[274],C_SCHEME_TRUE);}

/* k6792 in k6789 in a6786 in a6735 in walk in k6606 in ##compiler#copy-node-tree-and-rename in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k6738 in a6735 in walk in k6606 in ##compiler#copy-node-tree-and-rename in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6740,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6743,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6785,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 637  map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[251]+1)))(5,*((C_word*)lf[251]+1),t3,*((C_word*)lf[273]+1),((C_word*)t0)[2],t1);}

/* k6783 in k6738 in a6735 in walk in k6606 in ##compiler#copy-node-tree-and-rename in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 637  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[53]+1)))(4,*((C_word*)lf[53]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6741 in k6738 in a6735 in walk in k6606 in ##compiler#copy-node-tree-and-rename in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6743,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6762,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* support.scm: 640  gensym */
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),t2,lf[272]);}

/* k6760 in k6741 in k6738 in a6735 in walk in k6606 in ##compiler#copy-node-tree-and-rename in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6762,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6770,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6778,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
/* support.scm: 641  rename */
f_6610(t4,((C_word*)t0)[3],((C_word*)t0)[7]);}
else{
t5=t4;
f_6778(2,t5,C_SCHEME_FALSE);}}

/* k6776 in k6760 in k6741 in k6738 in a6735 in walk in k6606 in ##compiler#copy-node-tree-and-rename in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 641  build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[47]))(5,*((C_word*)lf[47]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6768 in k6760 in k6741 in k6738 in a6735 in walk in k6606 in ##compiler#copy-node-tree-and-rename in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6770,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6749,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6754,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t6=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a6753 in k6768 in k6760 in k6741 in k6738 in a6735 in walk in k6606 in ##compiler#copy-node-tree-and-rename in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6754(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6754,3,t0,t1,t2);}
/* walk1242 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6616(t3,t1,t2,((C_word*)t0)[2]);}

/* k6747 in k6768 in k6760 in k6741 in k6738 in a6735 in walk in k6606 in ##compiler#copy-node-tree-and-rename in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6749,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[200],lf[223],((C_word*)t0)[2],t1));}

/* k6692 in walk in k6606 in ##compiler#copy-node-tree-and-rename in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6694,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6697,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* support.scm: 623  gensym */
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),t2,((C_word*)t0)[3]);}

/* k6695 in k6692 in walk in k6606 in ##compiler#copy-node-tree-and-rename in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6697,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6700,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 624  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6698 in k6695 in k6692 in walk in k6606 in ##compiler#copy-node-tree-and-rename in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6700,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6713,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* support.scm: 627  walk */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6616(t5,t3,t4,t1);}

/* k6711 in k6698 in k6695 in k6692 in walk in k6606 in ##compiler#copy-node-tree-and-rename in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6713,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[200],lf[91],((C_word*)t0)[2],t2));}

/* k6676 in walk in k6606 in ##compiler#copy-node-tree-and-rename in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6678,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6670,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
/* support.scm: 619  walk */
t5=((C_word*)((C_word*)t0)[3])[1];
f_6616(t5,t3,t4,((C_word*)t0)[2]);}

/* k6668 in k6676 in walk in k6606 in ##compiler#copy-node-tree-and-rename in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6670,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[200],lf[228],((C_word*)t0)[2],t2));}

/* k6646 in walk in k6606 in ##compiler#copy-node-tree-and-rename in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 614  put! */
((C_proc6)C_retrieve_symbol_proc(lf[137]))(6,*((C_word*)lf[137]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[180],C_SCHEME_FALSE);}
else{
t2=((C_word*)t0)[4];
f_6638(2,t2,C_SCHEME_UNDEFINED);}}

/* k6636 in walk in k6606 in ##compiler#copy-node-tree-and-rename in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6645,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 615  rename */
f_6610(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6643 in k6636 in walk in k6606 in ##compiler#copy-node-tree-and-rename in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6645,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(C_word)C_a_i_list(&a,1,t1);
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[200],lf[210],t3,C_SCHEME_END_OF_LIST));}

/* rename in k6606 in ##compiler#copy-node-tree-and-rename in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_6610(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6610,NULL,3,t1,t2,t3);}
/* support.scm: 605  alist-ref */
((C_proc6)C_retrieve_symbol_proc(lf[270]))(6,*((C_word*)lf[270]+1),t1,t2,t3,*((C_word*)lf[271]+1),t2);}

/* ##compiler#inline-lambda-bindings in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6511(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_6511,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6517,a[2]=t6,a[3]=t4,a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 582  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),t1,t2,t7);}

/* a6516 in ##compiler#inline-lambda-bindings in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6517,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6523,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6529,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a6528 in a6516 in ##compiler#inline-lambda-bindings in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6529(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6529,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6533,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t2,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
/* map */
t5=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[92]),((C_word*)t0)[3]);}
else{
t5=t4;
f_6533(2,t5,((C_word*)t0)[3]);}}

/* k6531 in a6528 in a6516 in ##compiler#inline-lambda-bindings in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6533,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6536,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t1,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
/* support.scm: 588  copy-node-tree-and-rename */
((C_proc6)C_retrieve_symbol_proc(lf[269]))(6,*((C_word*)lf[269]+1),t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
t3=t2;
f_6536(2,t3,((C_word*)t0)[4]);}}

/* k6534 in k6531 in a6528 in a6516 in ##compiler#inline-lambda-bindings in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6536,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6541,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6555,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6596,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 594  last */
((C_proc3)C_retrieve_symbol_proc(lf[250]))(3,*((C_word*)lf[250]+1),t4,((C_word*)t0)[5]);}
else{
t4=t3;
f_6555(t4,t1);}}

/* k6594 in k6534 in k6531 in a6528 in a6516 in ##compiler#inline-lambda-bindings in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6596,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6572,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[2]))){
t4=(C_word)C_a_i_list(&a,1,C_SCHEME_END_OF_LIST);
t5=t3;
f_6572(t5,(C_word)C_a_i_record(&a,4,lf[200],lf[81],t4,C_SCHEME_END_OF_LIST));}
else{
t4=(C_word)C_i_length(((C_word*)t0)[2]);
t5=(C_word)C_fixnum_times(C_fix(3),t4);
t6=(C_word)C_a_i_list(&a,2,lf[268],t5);
t7=((C_word*)t0)[2];
t8=t3;
f_6572(t8,(C_word)C_a_i_record(&a,4,lf[200],lf[233],t6,t7));}}

/* k6570 in k6594 in k6534 in k6531 in a6528 in a6516 in ##compiler#inline-lambda-bindings in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_6572(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6572,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
f_6555(t3,(C_word)C_a_i_record(&a,4,lf[200],lf[91],((C_word*)t0)[2],t2));}

/* k6553 in k6534 in k6531 in a6528 in a6516 in ##compiler#inline-lambda-bindings in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_6555(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6555,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6559,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 600  take */
((C_proc4)C_retrieve_symbol_proc(lf[267]))(4,*((C_word*)lf[267]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6557 in k6553 in k6534 in k6531 in a6528 in a6516 in ##compiler#inline-lambda-bindings in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 590  fold-right */
((C_proc6)C_retrieve_symbol_proc(lf[266]))(6,*((C_word*)lf[266]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a6540 in k6534 in k6531 in a6528 in a6516 in ##compiler#inline-lambda-bindings in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6541(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6541,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t2);
t6=(C_word)C_a_i_list(&a,2,t3,t4);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[200],lf[91],t5,t6));}

/* a6522 in a6516 in ##compiler#inline-lambda-bindings in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6523,2,t0,t1);}
/* support.scm: 585  split-at */
((C_proc4)C_retrieve_symbol_proc(lf[265]))(4,*((C_word*)lf[265]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#fold-boolean in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6463(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6463,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6469,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_6469(t7,t1,t3);}

/* fold in ##compiler#fold-boolean in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_6469(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6469,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
C_apply(4,0,t1,((C_word*)t0)[3],t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6489,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cadr(t2);
/* support.scm: 578  proc */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t5,t6);}}

/* k6487 in fold in ##compiler#fold-boolean in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6493,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 579  fold */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6469(t4,t2,t3);}

/* k6491 in k6487 in fold in ##compiler#fold-boolean in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6493,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[200],lf[225],lf[263],t2));}

/* ##compiler#build-expression-tree in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6145(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6145,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6151,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_6151(3,t6,t1,t2);}

/* walk in ##compiler#build-expression-tree in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6151(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6151,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(t8,lf[215]);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6170,a[2]=t6,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t8,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t9)){
t11=t10;
f_6170(t11,t9);}
else{
t11=(C_word)C_eqp(t8,lf[260]);
t12=t10;
f_6170(t12,(C_truep(t11)?t11:(C_word)C_eqp(t8,lf[261])));}}

/* k6168 in walk in ##compiler#build-expression-tree in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_6170(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6170,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6177,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[249]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6194,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6198,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[210]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[214]));
if(C_truep(t4)){
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_car(((C_word*)t0)[2]));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[81]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[2]);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[81],t7));}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[91]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6244,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6260,a[2]=((C_word*)t0)[2],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6264,a[2]=((C_word*)t0)[4],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 552  butlast */
((C_proc3)C_retrieve_symbol_proc(lf[253]))(3,*((C_word*)lf[253]+1),t9,((C_word*)t0)[3]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[223]);
if(C_truep(t7)){
t8=(C_word)C_i_cadr(((C_word*)t0)[2]);
t9=(C_truep(t8)?lf[116]:lf[223]);
t10=(C_word)C_i_caddr(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6285,a[2]=t10,a[3]=t9,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 559  walk */
t13=((C_word*)((C_word*)t0)[4])[1];
f_6151(3,t13,t11,t12);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[235]);
if(C_truep(t8)){
/* map */
t9=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,((C_word*)t0)[6],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[226]);
if(C_truep(t9)){
t10=(C_word)C_i_car(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6318,a[2]=t10,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t12=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[216]);
if(C_truep(t10)){
t11=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]));}
else{
t11=(C_word)C_eqp(((C_word*)t0)[5],lf[255]);
if(C_truep(t11)){
t12=(C_word)C_i_car(((C_word*)t0)[2]);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6342,a[2]=t14,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t16=((C_word*)t14)[1];
f_6342(t16,((C_word*)t0)[6],t12,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[256]);
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6404,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t12)){
t14=t13;
f_6404(t14,t12);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[257]);
if(C_truep(t14)){
t15=t13;
f_6404(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[5],lf[258]);
t16=t13;
f_6404(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[5],lf[259])));}}}}}}}}}}}}}

/* k6402 in k6168 in walk in ##compiler#build-expression-tree in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_6404(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6404,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6411,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 569  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6151(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6430,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6434,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3]);}}

/* k6432 in k6402 in k6168 in walk in ##compiler#build-expression-tree in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 570  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[53]+1)))(4,*((C_word*)lf[53]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6428 in k6402 in k6168 in walk in ##compiler#build-expression-tree in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6430,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6409 in k6402 in k6168 in walk in ##compiler#build-expression-tree in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6415,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)((C_word*)t0)[2])[1],t3);}

/* k6413 in k6409 in k6402 in k6168 in walk in ##compiler#build-expression-tree in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 569  cons* */
((C_proc6)C_retrieve_symbol_proc(lf[254]))(6,*((C_word*)lf[254]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k6168 in walk in ##compiler#build-expression-tree in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_6342(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6342,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6360,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 566  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[75]+1)))(3,*((C_word*)lf[75]+1),t6,t4);}
else{
t6=(C_word)C_fixnum_difference(t2,C_fix(1));
t7=(C_word)C_i_cdr(t3);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6391,a[2]=t7,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_i_car(t3);
/* support.scm: 567  walk */
t10=((C_word*)((C_word*)t0)[3])[1];
f_6151(3,t10,t8,t9);}}

/* k6389 in loop in k6168 in walk in ##compiler#build-expression-tree in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6391,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* support.scm: 567  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_6342(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6358 in loop in k6168 in walk in ##compiler#build-expression-tree in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6360,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6368,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 566  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6151(3,t4,t2,t3);}

/* k6366 in k6358 in loop in k6168 in walk in ##compiler#build-expression-tree in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6368,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[255],t3));}

/* k6316 in k6168 in walk in ##compiler#build-expression-tree in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 561  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[254]))(5,*((C_word*)lf[254]+1),((C_word*)t0)[3],lf[226],((C_word*)t0)[2],t1);}

/* k6283 in k6168 in walk in ##compiler#build-expression-tree in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6285,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k6262 in k6168 in walk in ##compiler#build-expression-tree in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k6258 in k6168 in walk in ##compiler#build-expression-tree in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 552  map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[251]+1)))(5,*((C_word*)lf[251]+1),((C_word*)t0)[3],*((C_word*)lf[252]+1),((C_word*)t0)[2],t1);}

/* k6242 in k6168 in walk in ##compiler#build-expression-tree in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6244,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6252,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6256,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 553  last */
((C_proc3)C_retrieve_symbol_proc(lf[250]))(3,*((C_word*)lf[250]+1),t3,((C_word*)t0)[2]);}

/* k6254 in k6242 in k6168 in walk in ##compiler#build-expression-tree in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 553  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6151(3,t2,((C_word*)t0)[2],t1);}

/* k6250 in k6242 in k6168 in walk in ##compiler#build-expression-tree in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6252,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[91],t3));}

/* k6196 in k6168 in walk in ##compiler#build-expression-tree in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[99]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6192 in k6168 in walk in ##compiler#build-expression-tree in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6194,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[249],t2));}

/* k6175 in k6168 in walk in ##compiler#build-expression-tree in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6177,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#build-node-graph in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5631(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5631,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5634,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6140,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 536  walk */
t9=((C_word*)t6)[1];
f_5634(3,t9,t8,t2);}

/* k6138 in ##compiler#build-node-graph in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6140,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6143,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 537  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[10]))(5,*((C_word*)lf[10]+1),t2,lf[246],lf[247],((C_word*)((C_word*)t0)[2])[1]);}

/* k6141 in k6138 in ##compiler#build-node-graph in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* walk in ##compiler#build-node-graph in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5634(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word *a;
loop:
a=C_alloc(11);
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)tr3,(void*)f_5634,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
t4=t2;
t5=(C_word)C_a_i_list(&a,1,t4);
t6=t3;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_record(&a,4,lf[200],lf[210],t5,C_SCHEME_END_OF_LIST));}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
/* support.scm: 471  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t1,lf[213],t2);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[214]);
if(C_truep(t5)){
t6=(C_word)C_i_cadr(t2);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_record(&a,4,lf[200],lf[214],t7,C_SCHEME_END_OF_LIST));}
else{
t6=(C_word)C_eqp(t4,lf[215]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t4,lf[216]));
if(C_truep(t7)){
t8=(C_word)C_i_car(t2);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5693,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_i_cdr(t2);
/* map */
t11=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,((C_word*)((C_word*)t0)[3])[1],t10);}
else{
t8=(C_word)C_eqp(t4,lf[81]);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(t2);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5716,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5719,a[2]=t9,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_numberp(t9))){
t12=(C_word)C_eqp(lf[220],C_retrieve(lf[221]));
if(C_truep(t12)){
t13=(C_word)C_i_integerp(t9);
t14=t11;
f_5719(t14,(C_word)C_i_not(t13));}
else{
t13=t11;
f_5719(t13,C_SCHEME_FALSE);}}
else{
t12=t11;
f_5719(t12,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_eqp(t4,lf[91]);
if(C_truep(t9)){
t10=(C_word)C_i_cadr(t2);
t11=(C_word)C_i_caddr(t2);
if(C_truep((C_word)C_i_nullp(t10))){
/* support.scm: 491  walk */
t68=t1;
t69=t11;
t1=t68;
t2=t69;
c=3;
goto loop;}
else{
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5769,a[2]=t2,a[3]=t11,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 492  unzip1 */
((C_proc3)C_retrieve_symbol_proc(lf[222]))(3,*((C_word*)lf[222]+1),t12,t10);}}
else{
t10=(C_word)C_eqp(t4,lf[116]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t4,lf[223]));
if(C_truep(t11)){
t12=(C_word)C_i_cadr(t2);
t13=(C_word)C_a_i_list(&a,1,t12);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5823,a[2]=t13,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t15=(C_word)C_i_caddr(t2);
/* support.scm: 496  walk */
t68=t14;
t69=t15;
t1=t68;
t2=t69;
c=3;
goto loop;}
else{
t12=(C_word)C_eqp(t4,lf[224]);
if(C_truep(t12)){
t13=(C_word)C_i_cadr(t2);
t14=(C_word)C_i_car(t2);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5863,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t14,a[5]=t1,a[6]=t13,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t13))){
t16=(C_word)C_i_car(t13);
t17=t15;
f_5863(t17,(C_word)C_eqp(lf[81],t16));}
else{
t16=t15;
f_5863(t16,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_eqp(t4,lf[225]);
t14=(C_truep(t13)?t13:(C_word)C_eqp(t4,lf[226]));
if(C_truep(t14)){
t15=(C_word)C_i_car(t2);
t16=(C_word)C_i_cadr(t2);
t17=(C_word)C_a_i_list(&a,1,t16);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5894,a[2]=t17,a[3]=t15,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t19=(C_word)C_i_cddr(t2);
/* map */
t20=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t18,((C_word*)((C_word*)t0)[3])[1],t19);}
else{
t15=(C_word)C_eqp(t4,lf[227]);
if(C_truep(t15)){
t16=(C_word)C_i_cadr(t2);
t17=(C_word)C_a_i_list(&a,2,t16,C_SCHEME_TRUE);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_record(&a,4,lf[200],lf[227],t17,C_SCHEME_END_OF_LIST));}
else{
t16=(C_word)C_eqp(t4,lf[228]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(t4,lf[229]));
if(C_truep(t17)){
t18=(C_word)C_i_cadr(t2);
t19=(C_word)C_a_i_list(&a,1,t18);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5936,a[2]=t19,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t21=(C_word)C_i_cddr(t2);
/* map */
t22=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t22+1)))(4,t22,t20,((C_word*)((C_word*)t0)[3])[1],t21);}
else{
t18=(C_word)C_eqp(t4,lf[230]);
if(C_truep(t18)){
t19=(C_word)C_i_cadr(t2);
t20=(C_word)C_i_cadr(t19);
t21=(C_word)C_i_caddr(t2);
t22=(C_word)C_i_cadr(t21);
t23=(C_word)C_i_cadddr(t2);
t24=(C_word)C_i_cadr(t23);
t25=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5989,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t24,a[6]=t22,a[7]=t20,tmp=(C_word)a,a+=8,tmp);
/* support.scm: 515  fifth */
((C_proc3)C_retrieve_symbol_proc(lf[232]))(3,*((C_word*)lf[232]+1),t25,t2);}
else{
t19=(C_word)C_eqp(t4,lf[233]);
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6010,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t19)){
t21=t20;
f_6010(t21,t19);}
else{
t21=(C_word)C_eqp(t4,lf[241]);
if(C_truep(t21)){
t22=t20;
f_6010(t22,t21);}
else{
t22=(C_word)C_eqp(t4,lf[242]);
if(C_truep(t22)){
t23=t20;
f_6010(t23,t22);}
else{
t23=(C_word)C_eqp(t4,lf[243]);
t24=t20;
f_6010(t24,(C_truep(t23)?t23:(C_word)C_eqp(t4,lf[244])));}}}}}}}}}}}}}}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6130,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[3])[1],t2);}}}}

/* k6128 in walk in ##compiler#build-node-graph in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6130,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[200],lf[235],lf[245],t1));}

/* k6008 in walk in ##compiler#build-node-graph in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_6010(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6010,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cadr(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6019,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[6]);
/* map */
t6=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)((C_word*)t0)[4])[1],t5);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[234]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6035,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* map */
t5=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)((C_word*)t0)[4])[1],t4);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6047,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6053,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[5],t3,t4);}}}

/* a6052 in k6008 in walk in ##compiler#build-node-graph in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6053,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6067,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=t2;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6090,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[239]))(4,*((C_word*)lf[239]+1),t6,t5,lf[240]);}

/* k6088 in a6052 in k6008 in walk in ##compiler#build-node-graph in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_6067(t4,C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[2];
f_6067(t2,C_SCHEME_FALSE);}}

/* k6065 in a6052 in k6008 in walk in ##compiler#build-node-graph in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_6067(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6067,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6071,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6074,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 531  real-name */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t3,((C_word*)t0)[2]);}
else{
/* support.scm: 533  ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[238]))(3,*((C_word*)lf[238]+1),t2,((C_word*)t0)[2]);}}

/* k6072 in k6065 in a6052 in k6008 in walk in ##compiler#build-node-graph in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6074,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6081,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_6081(2,t3,t1);}
else{
/* support.scm: 532  ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[238]))(3,*((C_word*)lf[238]+1),t2,((C_word*)t0)[2]);}}

/* k6079 in k6072 in k6065 in a6052 in k6008 in walk in ##compiler#build-node-graph in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6081,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6071(2,t2,(C_word)C_a_i_list(&a,3,C_retrieve(lf[237]),((C_word*)t0)[2],t1));}

/* k6069 in k6065 in a6052 in k6008 in walk in ##compiler#build-node-graph in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6071,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6060,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k6058 in k6069 in k6065 in a6052 in k6008 in walk in ##compiler#build-node-graph in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6060,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[200],lf[235],((C_word*)t0)[2],t1));}

/* a6046 in k6008 in walk in ##compiler#build-node-graph in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6047,2,t0,t1);}
/* support.scm: 523  get-line-2 */
((C_proc3)C_retrieve_symbol_proc(lf[144]))(3,*((C_word*)lf[144]+1),t1,((C_word*)t0)[2]);}

/* k6033 in k6008 in walk in ##compiler#build-node-graph in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6035,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[200],lf[235],lf[236],t1));}

/* k6017 in k6008 in walk in ##compiler#build-node-graph in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_6019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6019,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[200],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k5987 in walk in ##compiler#build-node-graph in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5989,2,t0,t1);}
t2=(C_word)C_i_cadr(t1);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5969,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5973,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 516  sixth */
((C_proc3)C_retrieve_symbol_proc(lf[231]))(3,*((C_word*)lf[231]+1),t5,((C_word*)t0)[2]);}

/* k5971 in k5987 in walk in ##compiler#build-node-graph in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 516  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5634(3,t2,((C_word*)t0)[2],t1);}

/* k5967 in k5987 in walk in ##compiler#build-node-graph in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5969,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[200],lf[230],((C_word*)t0)[2],t2));}

/* k5934 in walk in ##compiler#build-node-graph in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5936,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[200],lf[228],((C_word*)t0)[2],t1));}

/* k5892 in walk in ##compiler#build-node-graph in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5894,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[200],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k5861 in walk in ##compiler#build-node-graph in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_5863(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5863,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadr(((C_word*)t0)[6]):((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5849,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)((C_word*)t0)[2])[1],t5);}

/* k5847 in k5861 in walk in ##compiler#build-node-graph in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5849,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[200],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k5821 in walk in ##compiler#build-node-graph in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5823,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[200],lf[116],((C_word*)t0)[2],t2));}

/* k5767 in walk in ##compiler#build-node-graph in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5769,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5772,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5779,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5789,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* map */
t6=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a5788 in k5767 in walk in ##compiler#build-node-graph in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5789(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5789,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
/* support.scm: 493  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5634(3,t4,t1,t3);}

/* k5777 in k5767 in walk in ##compiler#build-node-graph in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5779,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5787,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 494  walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5634(3,t3,t2,((C_word*)t0)[2]);}

/* k5785 in k5777 in k5767 in walk in ##compiler#build-node-graph in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5787,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* support.scm: 493  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[53]+1)))(4,*((C_word*)lf[53]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5770 in k5767 in walk in ##compiler#build-node-graph in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5772,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[200],lf[91],((C_word*)t0)[2],t1));}

/* k5717 in walk in ##compiler#build-node-graph in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_5719(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5719,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5722,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 482  compiler-warning */
((C_proc5)C_retrieve_symbol_proc(lf[19]))(5,*((C_word*)lf[19]+1),t2,lf[218],lf[219],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_5716(t2,((C_word*)t0)[2]);}}

/* k5720 in k5717 in walk in ##compiler#build-node-graph in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5722,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5729,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 485  truncate */
((C_proc3)C_retrieve_proc(*((C_word*)lf[217]+1)))(3,*((C_word*)lf[217]+1),t2,((C_word*)t0)[2]);}

/* k5727 in k5720 in k5717 in walk in ##compiler#build-node-graph in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5716(t2,(C_word)C_i_inexact_to_exact(t1));}

/* k5714 in walk in ##compiler#build-node-graph in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_5716(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5716,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(C_word)C_a_i_list(&a,1,t1);
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[200],lf[81],t3,C_SCHEME_END_OF_LIST));}

/* k5691 in walk in ##compiler#build-node-graph in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5693,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[200],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1));}

/* ##compiler#qnode in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5622(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5622,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[200],lf[81],t3,C_SCHEME_END_OF_LIST));}

/* ##compiler#varnode in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5613(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5613,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[200],lf[210],t3,C_SCHEME_END_OF_LIST));}

/* make-node in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5607(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5607,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[200],t2,t3,t4));}

/* node-subexpressions in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5598(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5598,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[200]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* node-subexpressions-set! in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5589(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5589,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[200]);
/* ##sys#block-set! */
t5=*((C_word*)lf[203]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* node-parameters in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5580(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5580,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[200]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* node-parameters-set! in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5571(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5571,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[200]);
/* ##sys#block-set! */
t5=*((C_word*)lf[203]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* node-class in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5562(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5562,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[200]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* node-class-set! in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5553(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5553,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[200]);
/* ##sys#block-set! */
t5=*((C_word*)lf[203]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* node? in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5547(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5547,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[200]));}

/* f_5541 in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5541(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5541,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[200],t2,t3,t4));}

/* ##compiler#display-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5066(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5066,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5070,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=t3;
f_5070(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5539,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 401  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[53]+1)))(5,*((C_word*)lf[53]+1),t4,C_retrieve(lf[197]),C_retrieve(lf[198]),C_retrieve(lf[126]));}}

/* k5537 in ##compiler#display-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5070(t3,t2);}

/* k5068 in ##compiler#display-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_5070(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5070,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5075,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 404  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[150]))(4,*((C_word*)lf[150]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a5074 in k5068 in ##compiler#display-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5075(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5075,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[2])[1]))){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_UNDEFINED);}
else{
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5085,a[2]=t3,a[3]=t9,a[4]=t7,a[5]=t5,a[6]=t13,a[7]=t11,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* support.scm: 412  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t14,t2);}}

/* k5083 in a5074 in k5068 in ##compiler#display-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5085,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5088,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5218,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_5218(t6,t2,((C_word*)t0)[2]);}

/* loop in k5083 in a5074 in k5068 in ##compiler#display-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_5218(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5218,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5228,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* support.scm: 416  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[160]+1)))(3,*((C_word*)lf[160]+1),t3,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k5226 in loop in k5083 in a5074 in k5068 in ##compiler#display-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5228,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5231,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(t1,lf[158]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5244,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[9],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t3)){
t5=t4;
f_5244(t5,t3);}
else{
t5=(C_word)C_eqp(t1,lf[177]);
if(C_truep(t5)){
t6=t4;
f_5244(t6,t5);}
else{
t6=(C_word)C_eqp(t1,lf[178]);
if(C_truep(t6)){
t7=t4;
f_5244(t7,t6);}
else{
t7=(C_word)C_eqp(t1,lf[179]);
if(C_truep(t7)){
t8=t4;
f_5244(t8,t7);}
else{
t8=(C_word)C_eqp(t1,lf[180]);
if(C_truep(t8)){
t9=t4;
f_5244(t9,t8);}
else{
t9=(C_word)C_eqp(t1,lf[181]);
if(C_truep(t9)){
t10=t4;
f_5244(t10,t9);}
else{
t10=(C_word)C_eqp(t1,lf[182]);
if(C_truep(t10)){
t11=t4;
f_5244(t11,t10);}
else{
t11=(C_word)C_eqp(t1,lf[183]);
if(C_truep(t11)){
t12=t4;
f_5244(t12,t11);}
else{
t12=(C_word)C_eqp(t1,lf[184]);
if(C_truep(t12)){
t13=t4;
f_5244(t13,t12);}
else{
t13=(C_word)C_eqp(t1,lf[185]);
if(C_truep(t13)){
t14=t4;
f_5244(t14,t13);}
else{
t14=(C_word)C_eqp(t1,lf[186]);
if(C_truep(t14)){
t15=t4;
f_5244(t15,t14);}
else{
t15=(C_word)C_eqp(t1,lf[187]);
if(C_truep(t15)){
t16=t4;
f_5244(t16,t15);}
else{
t16=(C_word)C_eqp(t1,lf[188]);
if(C_truep(t16)){
t17=t4;
f_5244(t17,t16);}
else{
t17=(C_word)C_eqp(t1,lf[189]);
if(C_truep(t17)){
t18=t4;
f_5244(t18,t17);}
else{
t18=(C_word)C_eqp(t1,lf[190]);
if(C_truep(t18)){
t19=t4;
f_5244(t19,t18);}
else{
t19=(C_word)C_eqp(t1,lf[191]);
if(C_truep(t19)){
t20=t4;
f_5244(t20,t19);}
else{
t20=(C_word)C_eqp(t1,lf[192]);
if(C_truep(t20)){
t21=t4;
f_5244(t21,t20);}
else{
t21=(C_word)C_eqp(t1,lf[193]);
if(C_truep(t21)){
t22=t4;
f_5244(t22,t21);}
else{
t22=(C_word)C_eqp(t1,lf[194]);
if(C_truep(t22)){
t23=t4;
f_5244(t23,t22);}
else{
t23=(C_word)C_eqp(t1,lf[195]);
t24=t4;
f_5244(t24,(C_truep(t23)?t23:(C_word)C_eqp(t1,lf[196])));}}}}}}}}}}}}}}}}}}}}

/* k5242 in k5226 in loop in k5083 in a5074 in k5068 in ##compiler#display-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_5244(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5244,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5247,a[2]=((C_word*)t0)[8],a[3]=t2,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t4=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(9),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[157]);
if(C_truep(t2)){
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,lf[157]);
t4=((C_word*)t0)[9];
f_5231(2,t4,t3);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[161]);
if(C_truep(t3)){
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[6])[1],lf[157]);
if(C_truep(t4)){
t5=((C_word*)t0)[9];
f_5231(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5285,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 424  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[162]+1)))(3,*((C_word*)lf[162]+1),t5,((C_word*)t0)[8]);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[7],lf[163]);
if(C_truep(t4)){
t5=(C_word)C_eqp(((C_word*)((C_word*)t0)[6])[1],lf[157]);
if(C_truep(t5)){
t6=((C_word*)t0)[9];
f_5231(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5301,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 426  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[162]+1)))(3,*((C_word*)lf[162]+1),t6,((C_word*)t0)[8]);}}
else{
t5=(C_word)C_eqp(((C_word*)t0)[7],lf[164]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5311,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 428  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[162]+1)))(3,*((C_word*)lf[162]+1),t6,((C_word*)t0)[8]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[7],lf[165]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5320,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_5320(t8,t6);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[7],lf[169]);
if(C_truep(t8)){
t9=t7;
f_5320(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[7],lf[170]);
if(C_truep(t9)){
t10=t7;
f_5320(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[7],lf[146]);
if(C_truep(t10)){
t11=t7;
f_5320(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[7],lf[171]);
if(C_truep(t11)){
t12=t7;
f_5320(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[7],lf[172]);
if(C_truep(t12)){
t13=t7;
f_5320(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[7],lf[173]);
if(C_truep(t13)){
t14=t7;
f_5320(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[7],lf[174]);
if(C_truep(t14)){
t15=t7;
f_5320(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[7],lf[175]);
t16=t7;
f_5320(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[7],lf[176])));}}}}}}}}}}}}}}

/* k5318 in k5242 in k5226 in loop in k5083 in a5074 in k5068 in ##compiler#display-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_5320(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5320,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5323,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t4=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(9),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[166]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5350,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 433  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[162]+1)))(3,*((C_word*)lf[162]+1),t3,((C_word*)t0)[5]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[167]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5360,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 435  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[162]+1)))(3,*((C_word*)lf[162]+1),t4,((C_word*)t0)[5]);}
else{
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* support.scm: 436  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),((C_word*)t0)[6],lf[168],t4);}}}}

/* k5358 in k5318 in k5242 in k5226 in loop in k5083 in a5074 in k5068 in ##compiler#display-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5231(2,t3,t2);}

/* k5348 in k5318 in k5242 in k5226 in loop in k5083 in a5074 in k5068 in ##compiler#display-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5231(2,t3,t2);}

/* k5321 in k5318 in k5242 in k5226 in loop in k5083 in a5074 in k5068 in ##compiler#display-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5323,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5326,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5340,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 431  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[160]+1)))(3,*((C_word*)lf[160]+1),t3,((C_word*)t0)[2]);}

/* k5338 in k5321 in k5318 in k5242 in k5226 in loop in k5083 in a5074 in k5068 in ##compiler#display-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5324 in k5321 in k5318 in k5242 in k5226 in loop in k5083 in a5074 in k5068 in ##compiler#display-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5329,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(61),((C_word*)t0)[3]);}

/* k5327 in k5324 in k5321 in k5318 in k5242 in k5226 in loop in k5083 in a5074 in k5068 in ##compiler#display-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5329,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5336,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 431  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[162]+1)))(3,*((C_word*)lf[162]+1),t2,((C_word*)t0)[2]);}

/* k5334 in k5327 in k5324 in k5321 in k5318 in k5242 in k5226 in loop in k5083 in a5074 in k5068 in ##compiler#display-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5309 in k5242 in k5226 in loop in k5083 in a5074 in k5068 in ##compiler#display-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5231(2,t3,t2);}

/* k5299 in k5242 in k5226 in loop in k5083 in a5074 in k5068 in ##compiler#display-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5231(2,t3,t2);}

/* k5283 in k5242 in k5226 in loop in k5083 in a5074 in k5068 in ##compiler#display-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5231(2,t3,t2);}

/* k5245 in k5242 in k5226 in loop in k5083 in a5074 in k5068 in ##compiler#display-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5262,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 420  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[160]+1)))(3,*((C_word*)lf[160]+1),t2,((C_word*)t0)[2]);}

/* k5260 in k5245 in k5242 in k5226 in loop in k5083 in a5074 in k5068 in ##compiler#display-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(t1,lf[159]);
t3=(C_word)C_i_cdr(t2);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k5229 in k5226 in loop in k5083 in a5074 in k5068 in ##compiler#display-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 437  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5218(t3,((C_word*)t0)[2],t2);}

/* k5086 in k5083 in a5074 in k5068 in ##compiler#display-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5088,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5091,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5129,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[4])[1],lf[157]);
t5=t3;
f_5129(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_5129(t4,C_SCHEME_FALSE);}}

/* k5127 in k5086 in k5083 in a5074 in k5068 in ##compiler#display-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_5129(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5129,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5132,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t3,lf[154],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5153,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[5])[1],lf[157]);
t4=t2;
f_5153(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_5153(t3,C_SCHEME_FALSE);}}}

/* k5151 in k5127 in k5086 in k5083 in a5074 in k5068 in ##compiler#display-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_5153(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5153,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5156,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t3,lf[155],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5177,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[2])[1],lf[157]);
t4=t2;
f_5177(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_5177(t3,C_SCHEME_FALSE);}}}

/* k5175 in k5151 in k5127 in k5086 in k5083 in a5074 in k5068 in ##compiler#display-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_5177(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5177,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5180,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t3,lf[156],t2);}
else{
t2=((C_word*)t0)[2];
f_5091(2,t2,C_SCHEME_UNDEFINED);}}

/* k5178 in k5175 in k5151 in k5127 in k5086 in k5083 in a5074 in k5068 in ##compiler#display-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5180,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[4])[1];
t3=(C_word)C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(C_word)C_slot(t4,C_fix(2));
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),((C_word*)t0)[3],t6,((C_word*)t0)[2]);}

/* k5154 in k5151 in k5127 in k5086 in k5083 in a5074 in k5068 in ##compiler#display-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5156,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[4])[1];
t3=(C_word)C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(C_word)C_slot(t4,C_fix(2));
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),((C_word*)t0)[3],t6,((C_word*)t0)[2]);}

/* k5130 in k5127 in k5086 in k5083 in a5074 in k5068 in ##compiler#display-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5132,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[4])[1];
t3=(C_word)C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(C_word)C_slot(t4,C_fix(2));
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),((C_word*)t0)[3],t6,((C_word*)t0)[2]);}

/* k5089 in k5086 in k5083 in a5074 in k5068 in ##compiler#display-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5091,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5094,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=*((C_word*)lf[11]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5119,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t4,lf[153],t3);}
else{
t3=t2;
f_5094(2,t3,C_SCHEME_UNDEFINED);}}

/* k5117 in k5089 in k5086 in k5083 in a5074 in k5068 in ##compiler#display-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_length(((C_word*)((C_word*)t0)[4])[1]);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k5092 in k5089 in k5086 in k5083 in a5074 in k5068 in ##compiler#display-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5094,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5097,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=*((C_word*)lf[11]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5106,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t4,lf[152],t3);}
else{
t3=t2;
f_5097(2,t3,C_SCHEME_UNDEFINED);}}

/* k5104 in k5092 in k5089 in k5086 in k5083 in a5074 in k5068 in ##compiler#display-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_length(((C_word*)((C_word*)t0)[4])[1]);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k5095 in k5092 in k5089 in k5086 in k5083 in a5074 in k5068 in ##compiler#display-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 446  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[13]+1)))(2,*((C_word*)lf[13]+1),((C_word*)t0)[2]);}

/* ##compiler#display-line-number-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5038,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5044,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 382  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[150]))(4,*((C_word*)lf[150]+1),t1,t2,C_retrieve(lf[143]));}

/* a5043 in ##compiler#display-line-number-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5044(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5044,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=*((C_word*)lf[11]+1);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5051,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t5,t2,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k5049 in a5043 in ##compiler#display-line-number-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5051,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5054,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[3]);}

/* k5052 in k5049 in a5043 in ##compiler#display-line-number-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5057,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5064,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[149]+1),((C_word*)t0)[2]);}

/* k5062 in k5052 in k5049 in a5043 in ##compiler#display-line-number-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5055 in k5052 in k5049 in a5043 in ##compiler#display-line-number-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* ##compiler#find-lambda-container in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5014(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5014,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5020,a[2]=t4,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5020(t8,t1,t2);}

/* loop in ##compiler#find-lambda-container in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_5020(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5020,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5030,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 378  get */
((C_proc5)C_retrieve_symbol_proc(lf[133]))(5,*((C_word*)lf[133]+1),t4,((C_word*)t0)[2],t2,lf[146]);}}

/* k5028 in loop in ##compiler#find-lambda-container in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_5030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 379  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5020(t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#get-line-2 in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4978(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4978,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4985,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 370  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t4,C_retrieve(lf[143]),t3);}

/* k4983 in ##compiler#get-line-2 in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4985,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4988,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_cdr(t1);
t4=t2;
f_4988(t4,(C_word)C_i_assq(((C_word*)t0)[2],t3));}
else{
t3=t2;
f_4988(t3,C_SCHEME_FALSE);}}

/* k4986 in k4983 in ##compiler#get-line-2 in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_4988(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(t1);
/* support.scm: 372  values */
C_values(4,0,((C_word*)t0)[3],t2,t3);}
else{
/* support.scm: 373  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* ##compiler#get-line in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4968(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4968,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
/* support.scm: 366  get */
((C_proc5)C_retrieve_symbol_proc(lf[133]))(5,*((C_word*)lf[133]+1),t1,C_retrieve(lf[143]),t3,t2);}

/* ##compiler#get-list in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4959(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4959,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4963,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 359  get */
((C_proc5)C_retrieve_symbol_proc(lf[133]))(5,*((C_word*)lf[133]+1),t5,t2,t3,t4);}

/* k4961 in ##compiler#get-list in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:C_SCHEME_END_OF_LIST));}

/* ##compiler#count! in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4902(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr5r,(void*)f_4902r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_4902r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_4902r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4906,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 350  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t6,t2,t3);}

/* k4904 in ##compiler#count! in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4906,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[6]);
t3=(C_truep(t2)?(C_word)C_i_car(((C_word*)t0)[6]):C_fix(1));
if(C_truep(t1)){
t4=(C_word)C_i_assq(((C_word*)t0)[5],t1);
if(C_truep(t4)){
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_fixnum_plus(t5,t3);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(t4,C_fix(1),t6));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4936,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 355  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),t5,((C_word*)t0)[5],t3,t6);}}
else{
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,1,t4);
/* support.scm: 356  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[138]))(5,*((C_word*)lf[138]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t5);}}

/* k4934 in k4904 in ##compiler#count! in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#collect! in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4850(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4850,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4854,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 342  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t6,t2,t3);}

/* k4852 in ##compiler#collect! in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4854,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(1),t4));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4881,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t5=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 346  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),t3,((C_word*)t0)[6],t4,t5);}}
else{
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* support.scm: 347  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[138]))(5,*((C_word*)lf[138]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3);}}

/* k4879 in k4852 in ##compiler#collect! in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#put! in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4804(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4804,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4808,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 334  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t6,t2,t3);}

/* k4806 in ##compiler#put! in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4808,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(t2,C_fix(1),((C_word*)t0)[4]));}
else{
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4830,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 338  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),t3,((C_word*)t0)[6],((C_word*)t0)[4],t4);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}}
else{
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* support.scm: 339  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[138]))(5,*((C_word*)lf[138]+1),((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2],t3);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}}

/* k4828 in k4806 in ##compiler#put! in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#get-all in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4786(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_4786r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4786r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4786r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4790,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 328  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t5,t2,t3);}

/* k4788 in ##compiler#get-all in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4790,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4798,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 330  filter-map */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* a4797 in k4788 in ##compiler#get-all in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4798(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4798,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* ##compiler#get in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4768(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4768,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4772,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 322  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t5,t2,t3);}

/* k4770 in ##compiler#get in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#initialize-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4533,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4537,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4541,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4683,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_4683(t7,t3,C_retrieve(lf[132]));}
else{
t3=t2;
f_4537(2,t3,C_SCHEME_UNDEFINED);}}

/* loop494 in ##compiler#initialize-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_4683(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4683,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4723,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_a_i_list(&a,1,lf[131]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4698,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
t7=t6;
f_4698(2,t7,C_SCHEME_TRUE);}
else{
t7=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t7))){
t8=t6;
f_4698(2,t8,(C_word)C_i_car(t5));}
else{
/* ##sys#error */
t8=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,lf[0],t5);}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k4696 in loop494 in ##compiler#initialize-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[124],t1);}

/* k4721 in loop494 in ##compiler#initialize-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4723,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4726,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[127])))){
t3=(C_word)C_a_i_list(&a,1,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4741,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4741(2,t5,C_SCHEME_TRUE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4741(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}
else{
t3=t2;
f_4726(2,t3,C_SCHEME_UNDEFINED);}}

/* k4739 in k4721 in loop494 in ##compiler#initialize-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[128],t1);}

/* k4724 in k4721 in loop494 in ##compiler#initialize-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4683(t3,((C_word*)t0)[2],t2);}

/* k4539 in ##compiler#initialize-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4541,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4544,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4598,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4598(t6,t2,C_retrieve(lf[130]));}

/* loop538 in k4539 in ##compiler#initialize-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_4598(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4598,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4638,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_a_i_list(&a,1,lf[129]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4613,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
t7=t6;
f_4613(2,t7,C_SCHEME_TRUE);}
else{
t7=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t7))){
t8=t6;
f_4613(2,t8,(C_word)C_i_car(t5));}
else{
/* ##sys#error */
t8=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,lf[0],t5);}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k4611 in loop538 in k4539 in ##compiler#initialize-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[124],t1);}

/* k4636 in loop538 in k4539 in ##compiler#initialize-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4641,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[127])))){
t3=(C_word)C_a_i_list(&a,1,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4656,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4656(2,t5,C_SCHEME_TRUE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4656(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}
else{
t3=t2;
f_4641(2,t3,C_SCHEME_UNDEFINED);}}

/* k4654 in k4636 in loop538 in k4539 in ##compiler#initialize-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[128],t1);}

/* k4639 in k4636 in loop538 in k4539 in ##compiler#initialize-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4598(t3,((C_word*)t0)[2],t2);}

/* k4542 in k4539 in ##compiler#initialize-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4544,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4549,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4549(t5,((C_word*)t0)[2],C_retrieve(lf[126]));}

/* loop581 in k4542 in k4539 in ##compiler#initialize-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_4549(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4549,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4589,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_list(&a,1,lf[122]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4564,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
t7=t6;
f_4564(2,t7,C_SCHEME_TRUE);}
else{
t7=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t7))){
t8=t6;
f_4564(2,t8,(C_word)C_i_car(t5));}
else{
/* ##sys#error */
t8=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,lf[0],t5);}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k4562 in loop581 in k4542 in k4539 in ##compiler#initialize-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[124],t1);}

/* k4587 in loop581 in k4542 in k4539 in ##compiler#initialize-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4549(t3,((C_word*)t0)[2],t2);}

/* k4535 in ##compiler#initialize-analysis-database in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##compiler#expand-profile-lambda in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4392(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4392,5,t0,t1,t2,t3,t4);}
t5=C_retrieve(lf[112]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4396,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=t4,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 282  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[92]))(2,*((C_word*)lf[92]+1),t6);}

/* k4394 in ##compiler#expand-profile-lambda in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4400,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 283  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),t2,((C_word*)t0)[6],((C_word*)t0)[2],C_retrieve(lf[113]));}

/* k4398 in k4394 in ##compiler#expand-profile-lambda in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[96],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4400,2,t0,t1);}
t2=C_mutate((C_word*)lf[113]+1 /* (set! profile-lambda-list ...) */,t1);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[6]);
t4=C_mutate((C_word*)lf[112]+1 /* (set! profile-lambda-index ...) */,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[81],t5);
t7=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[114]),C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[115],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[116],t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t13);
t15=(C_word)C_a_i_cons(&a,2,lf[116],t14);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t15,t16);
t18=(C_word)C_a_i_cons(&a,2,lf[117],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t19);
t21=(C_word)C_a_i_cons(&a,2,lf[116],t20);
t22=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t23=(C_word)C_a_i_cons(&a,2,lf[81],t22);
t24=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[114]),C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,t23,t24);
t26=(C_word)C_a_i_cons(&a,2,lf[118],t25);
t27=(C_word)C_a_i_cons(&a,2,t26,C_SCHEME_END_OF_LIST);
t28=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t27);
t29=(C_word)C_a_i_cons(&a,2,lf[116],t28);
t30=(C_word)C_a_i_cons(&a,2,t29,C_SCHEME_END_OF_LIST);
t31=(C_word)C_a_i_cons(&a,2,t21,t30);
t32=(C_word)C_a_i_cons(&a,2,t12,t31);
t33=(C_word)C_a_i_cons(&a,2,lf[119],t32);
t34=(C_word)C_a_i_cons(&a,2,t33,C_SCHEME_END_OF_LIST);
t35=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t34);
t36=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t36+1)))(2,t36,(C_word)C_a_i_cons(&a,2,lf[116],t35));}

/* ##compiler#llist-length in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4389(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4389,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_length(t2));}

/* ##compiler#process-lambda-documentation in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4386(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4386,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* ##compiler#string->expr in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4279(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4279,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4286,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4288,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[106]+1)))(3,*((C_word*)lf[106]+1),t3,t4);}

/* a4287 in ##compiler#string->expr in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4288(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4288,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4294,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4319,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[105]))(4,*((C_word*)lf[105]+1),t1,t3,t4);}

/* a4318 in a4287 in ##compiler#string->expr in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4319,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4325,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4373,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a4372 in a4318 in a4287 in ##compiler#string->expr in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4373(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_4373r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4373r(t0,t1,t2);}}

static void C_ccall f_4373r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4379,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k453456 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4378 in a4372 in a4318 in a4287 in ##compiler#string->expr in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4379,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a4324 in a4318 in a4287 in ##compiler#string->expr in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4325,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4329,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4357,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 264  with-input-from-string */
((C_proc4)C_retrieve_symbol_proc(lf[104]))(4,*((C_word*)lf[104]+1),t2,((C_word*)t0)[2],t3);}

/* a4356 in a4324 in a4318 in a4287 in ##compiler#string->expr in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4357,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4363,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4371,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 264  read */
((C_proc2)C_retrieve_proc(*((C_word*)lf[100]+1)))(2,*((C_word*)lf[100]+1),t3);}

/* k4369 in a4356 in a4324 in a4318 in a4287 in ##compiler#string->expr in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 264  unfold */
((C_proc6)C_retrieve_symbol_proc(lf[101]))(6,*((C_word*)lf[101]+1),((C_word*)t0)[3],*((C_word*)lf[102]+1),*((C_word*)lf[103]+1),((C_word*)t0)[2],t1);}

/* a4362 in a4356 in a4324 in a4318 in a4287 in ##compiler#string->expr in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4363(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4363,3,t0,t1,t2);}
/* support.scm: 264  read */
((C_proc2)C_retrieve_proc(*((C_word*)lf[100]+1)))(2,*((C_word*)lf[100]+1),t1);}

/* k4327 in a4324 in a4318 in a4287 in ##compiler#string->expr in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4329,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[97]);}
else{
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t1));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4351,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t4=*((C_word*)lf[99]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_SCHEME_END_OF_LIST);}}}

/* k4349 in k4327 in a4324 in a4318 in a4287 in ##compiler#string->expr in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4351,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[98],t1));}

/* a4293 in a4287 in ##compiler#string->expr in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4294(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4294,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4300,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* k453456 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4299 in a4293 in a4287 in ##compiler#string->expr in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4308,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4311,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 261  exn? */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}

/* k4309 in a4299 in a4293 in a4287 in ##compiler#string->expr in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 262  exn-msg */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* support.scm: 263  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[61]))(3,*((C_word*)lf[61]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4306 in a4299 in a4293 in a4287 in ##compiler#string->expr in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 259  quit */
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),((C_word*)t0)[3],lf[96],((C_word*)t0)[2],t1);}

/* k4284 in ##compiler#string->expr in k4276 in k4273 in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#canonicalize-begin-body in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4178(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4178,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4184,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4184(t6,t1,t2);}

/* loop in ##compiler#canonicalize-begin-body in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_4184(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4184,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[89]);}
else{
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_car(t2));}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_equalp(t4,lf[90]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4212,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=t6;
f_4212(t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4261,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 248  constant? */
((C_proc3)C_retrieve_symbol_proc(lf[80]))(3,*((C_word*)lf[80]+1),t7,t4);}}}}

/* k4259 in loop in ##compiler#canonicalize-begin-body in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_4212(t2,(C_truep(t1)?t1:(C_word)C_i_equalp(((C_word*)t0)[2],lf[94])));}

/* k4210 in loop in ##compiler#canonicalize-begin-body in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_4212(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4212,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 250  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4184(t3,((C_word*)t0)[2],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4250,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 251  gensym */
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),t2,lf[93]);}}

/* k4248 in k4210 in loop in ##compiler#canonicalize-begin-body in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4250,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4238,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 252  loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_4184(t8,t6,t7);}

/* k4236 in k4248 in k4210 in loop in ##compiler#canonicalize-begin-body in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4238,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[91],t3));}

/* ##compiler#basic-literal? in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4118(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4118,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_symbolp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4134,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 233  constant? */
((C_proc3)C_retrieve_symbol_proc(lf[80]))(3,*((C_word*)lf[80]+1),t5,t2);}}}

/* k4132 in ##compiler#basic-literal? in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4134,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4140,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4176,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 234  vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[87]+1)))(3,*((C_word*)lf[87]+1),t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4140(2,t3,C_SCHEME_FALSE);}}}

/* k4174 in k4132 in ##compiler#basic-literal? in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 234  every */
((C_proc4)C_retrieve_symbol_proc(lf[86]))(4,*((C_word*)lf[86]+1),((C_word*)t0)[2],C_retrieve(lf[85]),t1);}

/* k4138 in k4132 in ##compiler#basic-literal? in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4140,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4155,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* support.scm: 236  basic-literal? */
((C_proc3)C_retrieve_symbol_proc(lf[85]))(3,*((C_word*)lf[85]+1),t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* k4153 in k4138 in k4132 in ##compiler#basic-literal? in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 237  basic-literal? */
((C_proc3)C_retrieve_symbol_proc(lf[85]))(3,*((C_word*)lf[85]+1),((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#immediate? in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4072(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4072,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4076,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4116,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 223  big-fixnum? */
((C_proc3)C_retrieve_symbol_proc(lf[84]))(3,*((C_word*)lf[84]+1),t4,t2);}
else{
t4=t3;
f_4076(t4,C_SCHEME_FALSE);}}

/* k4114 in ##compiler#immediate? in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4076(t2,(C_word)C_i_not(t1));}

/* k4074 in ##compiler#immediate? in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_4076(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_eqp(C_SCHEME_UNDEFINED,((C_word*)t0)[2]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_nullp(((C_word*)t0)[2]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_eofp(((C_word*)t0)[2]);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_charp(((C_word*)t0)[2]);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?t5:(C_word)C_booleanp(((C_word*)t0)[2])));}}}}}

/* ##compiler#collapsable-literal? in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_4042(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4042,3,t0,t1,t2);}
t3=(C_word)C_booleanp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_eofp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_i_numberp(t2);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:(C_word)C_i_symbolp(t2)));}}}}

/* ##compiler#constant? in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3996(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3996,3,t0,t1,t2);}
t3=(C_word)C_i_numberp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_stringp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_booleanp(t2);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_eofp(t2);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t8=(C_word)C_i_car(t2);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_eqp(lf[81],t8));}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}}}}}

/* ##compiler#sort-symbols in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3976(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3976,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3982,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 202  sort */
((C_proc4)C_retrieve_symbol_proc(lf[79]))(4,*((C_word*)lf[79]+1),t1,t2,t3);}

/* a3981 in ##compiler#sort-symbols in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3982,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3990,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 202  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[42]+1)))(3,*((C_word*)lf[42]+1),t4,t2);}

/* k3988 in a3981 in ##compiler#sort-symbols in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3990,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3994,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 202  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[42]+1)))(3,*((C_word*)lf[42]+1),t2,((C_word*)t0)[2]);}

/* k3992 in k3988 in a3981 in ##compiler#sort-symbols in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 202  string<? */
((C_proc4)C_retrieve_proc(*((C_word*)lf[78]+1)))(4,*((C_word*)lf[78]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#follow-without-loop in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3945(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3945,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3951,a[2]=t3,a[3]=t6,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3951(t8,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in ##compiler#follow-without-loop in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_3951(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3951,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_member(t2,t3))){
/* support.scm: 198  abort */
t4=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3966,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 199  proc */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}}

/* a3965 in loop in ##compiler#follow-without-loop in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3966(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3966,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
/* support.scm: 199  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3951(t4,t1,t2,t3);}

/* ##compiler#fold-inner in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3882(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3882,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3896,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 188  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[75]+1)))(3,*((C_word*)lf[75]+1),t5,t3);}}

/* k3894 in ##compiler#fold-inner in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3896,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3898,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3898(t5,((C_word*)t0)[2],t1);}

/* fold in k3894 in ##compiler#fold-inner in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_3898(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3898,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3906,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(C_word)C_i_cadr(t2);
t6=(C_word)C_i_car(t2);
t7=t3;
f_3906(t7,(C_word)C_a_i_list(&a,2,t5,t6));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3927,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* support.scm: 193  fold */
t10=t5;
t11=t6;
t1=t10;
t2=t11;
goto loop;}}

/* k3925 in fold in k3894 in ##compiler#fold-inner in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3927,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_3906(t3,(C_word)C_a_i_list(&a,2,t1,t2));}

/* k3904 in fold in k3894 in ##compiler#fold-inner in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_3906(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#close-checked-input-file in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3870(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3870,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_string_equal_p(t3,lf[72]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* support.scm: 183  close-input-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[73]+1)))(3,*((C_word*)lf[73]+1),t1,t2);}}

/* ##compiler#check-and-open-input-file in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3823(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3823r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3823r(t0,t1,t2,t3);}}

static void C_ccall f_3823r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
if(C_truep((C_word)C_i_string_equal_p(t2,lf[65]))){
/* support.scm: 177  current-input-port */
((C_proc2)C_retrieve_proc(*((C_word*)lf[66]+1)))(2,*((C_word*)lf[66]+1),t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3839,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 178  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[70]))(3,*((C_word*)lf[70]+1),t4,t2);}}

/* k3837 in ##compiler#check-and-open-input-file in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3839,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 178  open-input-file */
((C_proc3)C_retrieve_proc(*((C_word*)lf[67]+1)))(3,*((C_word*)lf[67]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_vemptyp(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3851,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_3851(t4,t2);}
else{
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
t5=t3;
f_3851(t5,(C_word)C_i_not(t4));}}}

/* k3849 in k3837 in ##compiler#check-and-open-input-file in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_3851(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* support.scm: 179  quit */
((C_proc4)C_retrieve_symbol_proc(lf[24]))(4,*((C_word*)lf[24]+1),((C_word*)t0)[4],lf[68],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
/* support.scm: 180  quit */
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),((C_word*)t0)[4],lf[69],((C_word*)t0)[3],t2);}}

/* ##compiler#words->bytes in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3816(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3816,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub270(C_SCHEME_UNDEFINED,t3));}

/* ##compiler#words in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3809(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3809,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub266(C_SCHEME_UNDEFINED,t3));}

/* ##compiler#valid-c-identifier? in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3753(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3753,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3757,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3807,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 158  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[61]))(3,*((C_word*)lf[61]+1),t4,t2);}

/* k3805 in ##compiler#valid-c-identifier? in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[55]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3755 in ##compiler#valid-c-identifier? in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3757,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(t1);
t3=(C_word)C_u_i_char_alphabeticp(t2);
t4=(C_truep(t3)?t3:(C_word)C_eqp(C_make_character(95),t2));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3780,tmp=(C_word)a,a+=2,tmp);
t6=(C_word)C_i_cdr(t1);
/* support.scm: 162  any */
((C_proc4)C_retrieve_symbol_proc(lf[60]))(4,*((C_word*)lf[60]+1),((C_word*)t0)[2],t5,t6);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a3779 in k3755 in ##compiler#valid-c-identifier? in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3780(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3780,3,t0,t1,t2);}
t3=(C_word)C_u_i_char_alphabeticp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_char_numericp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:(C_word)C_eqp(C_make_character(95),t2)));}}

/* ##compiler#c-ify-string in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3659(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3659,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3671,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3675,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* string->list */
t5=C_retrieve(lf[55]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3673 in ##compiler#c-ify-string in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3675,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3677,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3677(t5,((C_word*)t0)[2],t1);}

/* loop in k3673 in ##compiler#c-ify-string in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_3677(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3677,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[52]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_fix((C_word)C_character_code(t3));
t5=(C_word)C_fixnum_lessp(t4,C_fix(32));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3699,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_3699(t7,t5);}
else{
t7=(C_word)C_fixnum_greater_or_equal_p(t4,C_fix(127));
t8=t6;
f_3699(t8,(C_truep(t7)?t7:(C_word)C_i_memq(t3,lf[58])));}}}

/* k3697 in loop in k3673 in ##compiler#c-ify-string in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_3699(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3699,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3706,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(8)))){
t3=t2;
f_3706(t3,lf[56]);}
else{
t3=(C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(64));
t4=t2;
f_3706(t4,(C_truep(t3)?lf[57]:C_SCHEME_END_OF_LIST));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3738,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* support.scm: 155  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3677(t4,t2,t3);}}

/* k3736 in k3697 in loop in k3673 in ##compiler#c-ify-string in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3738,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3704 in k3697 in loop in k3673 in ##compiler#c-ify-string in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_3706(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3706,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3710,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3722,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 153  number->string */
C_number_to_string(4,0,t3,((C_word*)t0)[2],C_fix(8));}

/* k3720 in k3704 in k3697 in loop in k3673 in ##compiler#c-ify-string in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[55]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3708 in k3704 in k3697 in loop in k3673 in ##compiler#c-ify-string in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3710,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3714,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 154  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3677(t4,t2,t3);}

/* k3712 in k3708 in k3704 in k3697 in loop in k3673 in ##compiler#c-ify-string in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 149  append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[53]+1)))(6,*((C_word*)lf[53]+1),((C_word*)t0)[4],lf[54],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3669 in ##compiler#c-ify-string in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3671,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_make_character(34),t1);
/* list->string */
t3=C_retrieve(lf[51]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* ##compiler#build-lambda-list in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3615(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3615,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3621,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_3621(t8,t1,t2,t3);}

/* loop in ##compiler#build-lambda-list in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_3621(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3621,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
t5=(C_truep(t4)?t4:(C_word)C_i_nullp(t2));
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:C_SCHEME_END_OF_LIST));}
else{
t6=(C_word)C_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3645,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_fixnum_decrease(t3);
/* support.scm: 135  loop */
t12=t7;
t13=t8;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* k3643 in loop in ##compiler#build-lambda-list in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3645,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#symbolify in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3584(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3584,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
/* support.scm: 129  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[46]+1)))(3,*((C_word*)lf[46]+1),t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3607,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[44]))(2,*((C_word*)lf[44]+1),t3);}}}

/* k3605 in ##compiler#symbolify in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3610,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,((C_word*)t0)[2],t1);}

/* k3608 in k3605 in ##compiler#symbolify in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3610,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3613,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t2,((C_word*)t0)[2]);}

/* k3611 in k3608 in k3605 in ##compiler#symbolify in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 130  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[46]+1)))(3,*((C_word*)lf[46]+1),((C_word*)t0)[2],t1);}

/* ##compiler#stringify in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3557(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3557,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 124  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[42]+1)))(3,*((C_word*)lf[42]+1),t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3576,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[44]))(2,*((C_word*)lf[44]+1),t3);}}}

/* k3574 in ##compiler#stringify in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3576,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3579,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,((C_word*)t0)[2],t1);}

/* k3577 in k3574 in ##compiler#stringify in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#posq in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3521(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3521,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3527,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_3527(t4,t3,C_fix(0)));}

/* loop in ##compiler#posq in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static C_word C_fcall f_3527(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t1);
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t2);}
else{
t5=(C_word)C_i_cdr(t1);
t6=(C_word)C_fixnum_increase(t2);
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##compiler#check-signature in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3453(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3453,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3456,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3477,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_3477(t9,t1,t3,t4);}

/* loop in ##compiler#check-signature in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_3477(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3477,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* support.scm: 108  err */
t4=((C_word*)t0)[3];
f_3456(t4,t1);}}
else{
t4=(C_word)C_i_symbolp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* support.scm: 110  err */
t5=((C_word*)t0)[3];
f_3456(t5,t1);}
else{
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_i_cdr(t3);
/* support.scm: 111  loop */
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}}

/* err in ##compiler#check-signature in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_3456(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3456,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3464,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 105  real-name */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t2,((C_word*)t0)[2]);}

/* k3462 in err in ##compiler#check-signature in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3464,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3468,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* support.scm: 106  map-llist */
((C_proc4)C_retrieve_symbol_proc(lf[36]))(4,*((C_word*)lf[36]+1),t2,C_retrieve(lf[39]),t3);}

/* k3466 in k3462 in err in ##compiler#check-signature in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 104  quit */
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),((C_word*)t0)[3],lf[38],((C_word*)t0)[2],t1);}

/* map-llist in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3410(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3410,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3416,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_3416(t7,t1,t3);}

/* loop in map-llist in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_3416(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3416,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 99   proc */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3439,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 100  proc */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}}}

/* k3437 in loop in map-llist in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3443,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 100  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3416(t4,t2,t3);}

/* k3441 in k3437 in loop in map-llist in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3443,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#emit-syntax-trace-info in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3407(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3407,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_emit_syntax_trace_info(t2,t3,C_retrieve(lf[29])));}

/* ##sys#syntax-error-hook in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3346(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_3346r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3346r(t0,t1,t2,t3);}}

static void C_ccall f_3346r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(9);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3350,a[2]=t4,a[3]=t5,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 78   current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[22]))(2,*((C_word*)lf[22]+1),t6);}

/* k3348 in ##sys#syntax-error-hook in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3350,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3353,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)((C_word*)t0)[2])[1]))){
t3=((C_word*)((C_word*)t0)[2])[1];
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t6);
t8=t2;
f_3353(t8,t3);}
else{
t3=t2;
f_3353(t3,C_SCHEME_FALSE);}}

/* k3351 in k3348 in ##sys#syntax-error-hook in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_3353(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3353,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3356,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
/* support.scm: 85   fprintf */
((C_proc6)C_retrieve_symbol_proc(lf[20]))(6,*((C_word*)lf[20]+1),t2,((C_word*)t0)[4],lf[32],t1,((C_word*)((C_word*)t0)[2])[1]);}
else{
/* support.scm: 86   fprintf */
((C_proc5)C_retrieve_symbol_proc(lf[20]))(5,*((C_word*)lf[20]+1),t2,((C_word*)t0)[4],lf[33],((C_word*)((C_word*)t0)[2])[1]);}}

/* k3354 in k3351 in k3348 in ##sys#syntax-error-hook in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3356,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3359,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3367,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_3367(t6,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* loop93 in k3354 in k3351 in k3348 in ##sys#syntax-error-hook in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_3367(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3367,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3380,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* fprintf */
((C_proc5)C_retrieve_symbol_proc(lf[20]))(5,*((C_word*)lf[20]+1),t4,((C_word*)t0)[2],lf[31],t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k3378 in loop93 in k3354 in k3351 in k3348 in ##sys#syntax-error-hook in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3367(t3,((C_word*)t0)[2],t2);}

/* k3357 in k3354 in k3351 in k3348 in ##sys#syntax-error-hook in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3359,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3362,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 88   print-call-chain */
((C_proc6)C_retrieve_symbol_proc(lf[28]))(6,*((C_word*)lf[28]+1),t2,((C_word*)t0)[2],C_fix(0),C_retrieve(lf[29]),lf[30]);}

/* k3360 in k3357 in k3354 in k3351 in k3348 in ##sys#syntax-error-hook in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 89   exit */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],C_fix(70));}

/* quit in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3327(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_3327r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3327r(t0,t1,t2,t3);}}

static void C_ccall f_3327r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3331,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 71   current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[22]))(2,*((C_word*)lf[22]+1),t4);}

/* k3329 in quit in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3331,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3334,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3344,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 72   string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[7]+1)))(4,*((C_word*)lf[7]+1),t3,lf[26],((C_word*)t0)[2]);}

/* k3342 in k3329 in quit in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],C_retrieve(lf[20]),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3332 in k3329 in quit in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3334,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3337,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 73   newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[13]+1)))(3,*((C_word*)lf[13]+1),t2,((C_word*)t0)[2]);}

/* k3335 in k3332 in k3329 in quit in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 74   exit */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],C_fix(1));}

/* ##compiler#compiler-warning in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3298(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3298r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3298r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3298r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3305,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[23]))){
t6=(C_word)C_i_memq(t2,C_retrieve(lf[4]));
t7=t5;
f_3305(t7,(C_word)C_i_not(t6));}
else{
t6=t5;
f_3305(t6,C_SCHEME_FALSE);}}

/* k3303 in ##compiler#compiler-warning in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_3305(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3305,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3308,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 66   current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[22]))(2,*((C_word*)lf[22]+1),t2);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3306 in k3303 in ##compiler#compiler-warning in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3308,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3311,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3318,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 67   string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[7]+1)))(4,*((C_word*)lf[7]+1),t3,lf[21],((C_word*)t0)[2]);}

/* k3316 in k3306 in k3303 in ##compiler#compiler-warning in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],C_retrieve(lf[20]),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3309 in k3306 in k3303 in ##compiler#compiler-warning in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 68   newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[13]+1)))(3,*((C_word*)lf[13]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#debugging in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3239(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_3239r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3239r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3239r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[3])))){
t5=*((C_word*)lf[11]+1);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3249,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t6,t3,t5);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k3247 in ##compiler#debugging in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3249,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3252,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3264,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 58   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[17]+1)))(3,*((C_word*)lf[17]+1),t3,lf[18]);}
else{
t3=t2;
f_3252(2,t3,C_SCHEME_UNDEFINED);}}

/* k3262 in k3247 in ##compiler#debugging in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3264,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3269,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3269(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop49 in k3262 in k3247 in ##compiler#debugging in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_fcall f_3269(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3269,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=*((C_word*)lf[11]+1);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3282,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3296,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 59   force */
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),t6,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k3294 in loop49 in k3262 in k3247 in ##compiler#debugging in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3280 in loop49 in k3262 in k3247 in ##compiler#debugging in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3282,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3285,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[2]);}

/* k3283 in k3280 in loop49 in k3262 in k3247 in ##compiler#debugging in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3269(t3,((C_word*)t0)[2],t2);}

/* k3250 in k3247 in ##compiler#debugging in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3252,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3255,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 60   newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[13]+1)))(2,*((C_word*)lf[13]+1),t2);}

/* k3253 in k3250 in k3247 in ##compiler#debugging in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3255,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3258,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 61   flush-output */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),t2);}

/* k3256 in k3253 in k3250 in k3247 in ##compiler#debugging in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* ##compiler#bomb in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3212(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3212r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3212r(t0,t1,t2);}}

static void C_ccall f_3212r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3226,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 49   string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[7]+1)))(4,*((C_word*)lf[7]+1),t3,lf[8],t4);}
else{
/* support.scm: 50   error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[6]+1)))(3,*((C_word*)lf[6]+1),t1,lf[9]);}}

/* k3224 in ##compiler#bomb in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_apply(5,0,((C_word*)t0)[2],*((C_word*)lf[6]+1),t1,t2);}

/* ##compiler#compiler-cleanup-hook in k3201 in k3198 in k3195 in k3192 in k3189 in k3186 */
static void C_ccall f_3207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3207,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[625] = {
{"toplevel:support_scm",(void*)C_support_toplevel},
{"f_3188:support_scm",(void*)f_3188},
{"f_3191:support_scm",(void*)f_3191},
{"f_3194:support_scm",(void*)f_3194},
{"f_3197:support_scm",(void*)f_3197},
{"f_3200:support_scm",(void*)f_3200},
{"f_3203:support_scm",(void*)f_3203},
{"f_4275:support_scm",(void*)f_4275},
{"f_4278:support_scm",(void*)f_4278},
{"f_11196:support_scm",(void*)f_11196},
{"f_11200:support_scm",(void*)f_11200},
{"f_11284:support_scm",(void*)f_11284},
{"f_11206:support_scm",(void*)f_11206},
{"f_11271:support_scm",(void*)f_11271},
{"f_11274:support_scm",(void*)f_11274},
{"f_11277:support_scm",(void*)f_11277},
{"f_11212:support_scm",(void*)f_11212},
{"f_11219:support_scm",(void*)f_11219},
{"f_11221:support_scm",(void*)f_11221},
{"f_11253:support_scm",(void*)f_11253},
{"f_11249:support_scm",(void*)f_11249},
{"f_11234:support_scm",(void*)f_11234},
{"f_11190:support_scm",(void*)f_11190},
{"f_11184:support_scm",(void*)f_11184},
{"f_11178:support_scm",(void*)f_11178},
{"f_11150:support_scm",(void*)f_11150},
{"f_11154:support_scm",(void*)f_11154},
{"f_11129:support_scm",(void*)f_11129},
{"f_11133:support_scm",(void*)f_11133},
{"f_11096:support_scm",(void*)f_11096},
{"f_11102:support_scm",(void*)f_11102},
{"f_11063:support_scm",(void*)f_11063},
{"f_11069:support_scm",(void*)f_11069},
{"f_11039:support_scm",(void*)f_11039},
{"f_10970:support_scm",(void*)f_10970},
{"f_10974:support_scm",(void*)f_10974},
{"f_10979:support_scm",(void*)f_10979},
{"f_10983:support_scm",(void*)f_10983},
{"f_11034:support_scm",(void*)f_11034},
{"f_11013:support_scm",(void*)f_11013},
{"f_11025:support_scm",(void*)f_11025},
{"f_11028:support_scm",(void*)f_11028},
{"f_11001:support_scm",(void*)f_11001},
{"f_10937:support_scm",(void*)f_10937},
{"f_10947:support_scm",(void*)f_10947},
{"f_10950:support_scm",(void*)f_10950},
{"f_10813:support_scm",(void*)f_10813},
{"f_10822:support_scm",(void*)f_10822},
{"f_10835:support_scm",(void*)f_10835},
{"f_10841:support_scm",(void*)f_10841},
{"f_10844:support_scm",(void*)f_10844},
{"f_10847:support_scm",(void*)f_10847},
{"f_10850:support_scm",(void*)f_10850},
{"f_10853:support_scm",(void*)f_10853},
{"f_10856:support_scm",(void*)f_10856},
{"f_10915:support_scm",(void*)f_10915},
{"f_10928:support_scm",(void*)f_10928},
{"f_10859:support_scm",(void*)f_10859},
{"f_10874:support_scm",(void*)f_10874},
{"f_10877:support_scm",(void*)f_10877},
{"f_10885:support_scm",(void*)f_10885},
{"f_10895:support_scm",(void*)f_10895},
{"f_10898:support_scm",(void*)f_10898},
{"f_10880:support_scm",(void*)f_10880},
{"f_10865:support_scm",(void*)f_10865},
{"f_10817:support_scm",(void*)f_10817},
{"f_10810:support_scm",(void*)f_10810},
{"f_10792:support_scm",(void*)f_10792},
{"f_10746:support_scm",(void*)f_10746},
{"f_10765:support_scm",(void*)f_10765},
{"f_10776:support_scm",(void*)f_10776},
{"f_10772:support_scm",(void*)f_10772},
{"f_10725:support_scm",(void*)f_10725},
{"f_10731:support_scm",(void*)f_10731},
{"f_10735:support_scm",(void*)f_10735},
{"f_10738:support_scm",(void*)f_10738},
{"f_10741:support_scm",(void*)f_10741},
{"f_10713:support_scm",(void*)f_10713},
{"f_10717:support_scm",(void*)f_10717},
{"f_10622:support_scm",(void*)f_10622},
{"f_10641:support_scm",(void*)f_10641},
{"f_10666:support_scm",(void*)f_10666},
{"f_10670:support_scm",(void*)f_10670},
{"f_10672:support_scm",(void*)f_10672},
{"f_10679:support_scm",(void*)f_10679},
{"f_10692:support_scm",(void*)f_10692},
{"f_10695:support_scm",(void*)f_10695},
{"f_10698:support_scm",(void*)f_10698},
{"f_10701:support_scm",(void*)f_10701},
{"f_10704:support_scm",(void*)f_10704},
{"f_10708:support_scm",(void*)f_10708},
{"f_10625:support_scm",(void*)f_10625},
{"f_10629:support_scm",(void*)f_10629},
{"f_10635:support_scm",(void*)f_10635},
{"f_10616:support_scm",(void*)f_10616},
{"f_10557:support_scm",(void*)f_10557},
{"f_10565:support_scm",(void*)f_10565},
{"f_10592:support_scm",(void*)f_10592},
{"f_10568:support_scm",(void*)f_10568},
{"f_10571:support_scm",(void*)f_10571},
{"f_10588:support_scm",(void*)f_10588},
{"f_10574:support_scm",(void*)f_10574},
{"f_10584:support_scm",(void*)f_10584},
{"f_10577:support_scm",(void*)f_10577},
{"f_10580:support_scm",(void*)f_10580},
{"f_10548:support_scm",(void*)f_10548},
{"f_10542:support_scm",(void*)f_10542},
{"f_10536:support_scm",(void*)f_10536},
{"f_10524:support_scm",(void*)f_10524},
{"f_10528:support_scm",(void*)f_10528},
{"f_10531:support_scm",(void*)f_10531},
{"f_10486:support_scm",(void*)f_10486},
{"f_10490:support_scm",(void*)f_10490},
{"f_10493:support_scm",(void*)f_10493},
{"f_10500:support_scm",(void*)f_10500},
{"f_10444:support_scm",(void*)f_10444},
{"f_10453:support_scm",(void*)f_10453},
{"f_10415:support_scm",(void*)f_10415},
{"f_10425:support_scm",(void*)f_10425},
{"f_10227:support_scm",(void*)f_10227},
{"f_10410:support_scm",(void*)f_10410},
{"f_10381:support_scm",(void*)f_10381},
{"f_10387:support_scm",(void*)f_10387},
{"f_10400:support_scm",(void*)f_10400},
{"f_10230:support_scm",(void*)f_10230},
{"f_10249:support_scm",(void*)f_10249},
{"f_10343:support_scm",(void*)f_10343},
{"f_10355:support_scm",(void*)f_10355},
{"f_10313:support_scm",(void*)f_10313},
{"f_10324:support_scm",(void*)f_10324},
{"f_10304:support_scm",(void*)f_10304},
{"f_10290:support_scm",(void*)f_10290},
{"f_10268:support_scm",(void*)f_10268},
{"f_10274:support_scm",(void*)f_10274},
{"f_10278:support_scm",(void*)f_10278},
{"f_10103:support_scm",(void*)f_10103},
{"f_10109:support_scm",(void*)f_10109},
{"f_10187:support_scm",(void*)f_10187},
{"f_10192:support_scm",(void*)f_10192},
{"f_10202:support_scm",(void*)f_10202},
{"f_10160:support_scm",(void*)f_10160},
{"f_10131:support_scm",(void*)f_10131},
{"f_10136:support_scm",(void*)f_10136},
{"f_10146:support_scm",(void*)f_10146},
{"f_10107:support_scm",(void*)f_10107},
{"f_9734:support_scm",(void*)f_9734},
{"f_9933:support_scm",(void*)f_9933},
{"f_10025:support_scm",(void*)f_10025},
{"f_9936:support_scm",(void*)f_9936},
{"f_9418:support_scm",(void*)f_9418},
{"f_9728:support_scm",(void*)f_9728},
{"f_9430:support_scm",(void*)f_9430},
{"f_9440:support_scm",(void*)f_9440},
{"f_9458:support_scm",(void*)f_9458},
{"f_9492:support_scm",(void*)f_9492},
{"f_9421:support_scm",(void*)f_9421},
{"f_9093:support_scm",(void*)f_9093},
{"f_9412:support_scm",(void*)f_9412},
{"f_9099:support_scm",(void*)f_9099},
{"f_9109:support_scm",(void*)f_9109},
{"f_9118:support_scm",(void*)f_9118},
{"f_9130:support_scm",(void*)f_9130},
{"f_9142:support_scm",(void*)f_9142},
{"f_9148:support_scm",(void*)f_9148},
{"f_9182:support_scm",(void*)f_9182},
{"f_9053:support_scm",(void*)f_9053},
{"f_9087:support_scm",(void*)f_9087},
{"f_9059:support_scm",(void*)f_9059},
{"f_9063:support_scm",(void*)f_9063},
{"f_9022:support_scm",(void*)f_9022},
{"f_9035:support_scm",(void*)f_9035},
{"f_9026:support_scm",(void*)f_9026},
{"f_8991:support_scm",(void*)f_8991},
{"f_9004:support_scm",(void*)f_9004},
{"f_8995:support_scm",(void*)f_8995},
{"f_7938:support_scm",(void*)f_7938},
{"f_8985:support_scm",(void*)f_8985},
{"f_7944:support_scm",(void*)f_7944},
{"f_7950:support_scm",(void*)f_7950},
{"f_7979:support_scm",(void*)f_7979},
{"f_7998:support_scm",(void*)f_7998},
{"f_8017:support_scm",(void*)f_8017},
{"f_8087:support_scm",(void*)f_8087},
{"f_8106:support_scm",(void*)f_8106},
{"f_8188:support_scm",(void*)f_8188},
{"f_8227:support_scm",(void*)f_8227},
{"f_8246:support_scm",(void*)f_8246},
{"f_8265:support_scm",(void*)f_8265},
{"f_8345:support_scm",(void*)f_8345},
{"f_8430:support_scm",(void*)f_8430},
{"f_8505:support_scm",(void*)f_8505},
{"f_8539:support_scm",(void*)f_8539},
{"f_8609:support_scm",(void*)f_8609},
{"f_8542:support_scm",(void*)f_8542},
{"f_8348:support_scm",(void*)f_8348},
{"f_8379:support_scm",(void*)f_8379},
{"f_8268:support_scm",(void*)f_8268},
{"f_8109:support_scm",(void*)f_8109},
{"f_8140:support_scm",(void*)f_8140},
{"f_8020:support_scm",(void*)f_8020},
{"f_8051:support_scm",(void*)f_8051},
{"f_7886:support_scm",(void*)f_7886},
{"f_7890:support_scm",(void*)f_7890},
{"f_7901:support_scm",(void*)f_7901},
{"f_7907:support_scm",(void*)f_7907},
{"f_7920:support_scm",(void*)f_7920},
{"f_7923:support_scm",(void*)f_7923},
{"f_7893:support_scm",(void*)f_7893},
{"f_7805:support_scm",(void*)f_7805},
{"f_7817:support_scm",(void*)f_7817},
{"f_7824:support_scm",(void*)f_7824},
{"f_7827:support_scm",(void*)f_7827},
{"f_7830:support_scm",(void*)f_7830},
{"f_7833:support_scm",(void*)f_7833},
{"f_7836:support_scm",(void*)f_7836},
{"f_7839:support_scm",(void*)f_7839},
{"f_7842:support_scm",(void*)f_7842},
{"f_7845:support_scm",(void*)f_7845},
{"f_7848:support_scm",(void*)f_7848},
{"f_7851:support_scm",(void*)f_7851},
{"f_7854:support_scm",(void*)f_7854},
{"f_7857:support_scm",(void*)f_7857},
{"f_7860:support_scm",(void*)f_7860},
{"f_7863:support_scm",(void*)f_7863},
{"f_7866:support_scm",(void*)f_7866},
{"f_7869:support_scm",(void*)f_7869},
{"f_7872:support_scm",(void*)f_7872},
{"f_7875:support_scm",(void*)f_7875},
{"f_7878:support_scm",(void*)f_7878},
{"f_7881:support_scm",(void*)f_7881},
{"f_7811:support_scm",(void*)f_7811},
{"f_7709:support_scm",(void*)f_7709},
{"f_7718:support_scm",(void*)f_7718},
{"f_7724:support_scm",(void*)f_7724},
{"f_7744:support_scm",(void*)f_7744},
{"f_7713:support_scm",(void*)f_7713},
{"f_7688:support_scm",(void*)f_7688},
{"f_7698:support_scm",(void*)f_7698},
{"f_7639:support_scm",(void*)f_7639},
{"f_7645:support_scm",(void*)f_7645},
{"f_7686:support_scm",(void*)f_7686},
{"f_7669:support_scm",(void*)f_7669},
{"f_7658:support_scm",(void*)f_7658},
{"f_7602:support_scm",(void*)f_7602},
{"f_7608:support_scm",(void*)f_7608},
{"f_7637:support_scm",(void*)f_7637},
{"f_7615:support_scm",(void*)f_7615},
{"f_7618:support_scm",(void*)f_7618},
{"f_7561:support_scm",(void*)f_7561},
{"f_7567:support_scm",(void*)f_7567},
{"f_7600:support_scm",(void*)f_7600},
{"f_7574:support_scm",(void*)f_7574},
{"f_7577:support_scm",(void*)f_7577},
{"f_7469:support_scm",(void*)f_7469},
{"f_7493:support_scm",(void*)f_7493},
{"f_7383:support_scm",(void*)f_7383},
{"f_7389:support_scm",(void*)f_7389},
{"f_7405:support_scm",(void*)f_7405},
{"f_7419:support_scm",(void*)f_7419},
{"f_7427:support_scm",(void*)f_7427},
{"f_7188:support_scm",(void*)f_7188},
{"f_7367:support_scm",(void*)f_7367},
{"f_7373:support_scm",(void*)f_7373},
{"f_7263:support_scm",(void*)f_7263},
{"f_7285:support_scm",(void*)f_7285},
{"f_7298:support_scm",(void*)f_7298},
{"f_7329:support_scm",(void*)f_7329},
{"f_7220:support_scm",(void*)f_7220},
{"f_7242:support_scm",(void*)f_7242},
{"f_7191:support_scm",(void*)f_7191},
{"f_7215:support_scm",(void*)f_7215},
{"f_7119:support_scm",(void*)f_7119},
{"f_7125:support_scm",(void*)f_7125},
{"f_7131:support_scm",(void*)f_7131},
{"f_7135:support_scm",(void*)f_7135},
{"f_7182:support_scm",(void*)f_7182},
{"f_7146:support_scm",(void*)f_7146},
{"f_7171:support_scm",(void*)f_7171},
{"f_6933:support_scm",(void*)f_6933},
{"f_6980:support_scm",(void*)f_6980},
{"f_7117:support_scm",(void*)f_7117},
{"f_6984:support_scm",(void*)f_6984},
{"f_6992:support_scm",(void*)f_6992},
{"f_6999:support_scm",(void*)f_6999},
{"f_7110:support_scm",(void*)f_7110},
{"f_7023:support_scm",(void*)f_7023},
{"f_7095:support_scm",(void*)f_7095},
{"f_7050:support_scm",(void*)f_7050},
{"f_7053:support_scm",(void*)f_7053},
{"f_7071:support_scm",(void*)f_7071},
{"f_7060:support_scm",(void*)f_7060},
{"f_6987:support_scm",(void*)f_6987},
{"f_6937:support_scm",(void*)f_6937},
{"f_6943:support_scm",(void*)f_6943},
{"f_6950:support_scm",(void*)f_6950},
{"f_6952:support_scm",(void*)f_6952},
{"f_6965:support_scm",(void*)f_6965},
{"f_6908:support_scm",(void*)f_6908},
{"f_6914:support_scm",(void*)f_6914},
{"f_6924:support_scm",(void*)f_6924},
{"f_6872:support_scm",(void*)f_6872},
{"f_6878:support_scm",(void*)f_6878},
{"f_6902:support_scm",(void*)f_6902},
{"f_6898:support_scm",(void*)f_6898},
{"f_6848:support_scm",(void*)f_6848},
{"f_6852:support_scm",(void*)f_6852},
{"f_6855:support_scm",(void*)f_6855},
{"f_6858:support_scm",(void*)f_6858},
{"f_6814:support_scm",(void*)f_6814},
{"f_6820:support_scm",(void*)f_6820},
{"f_6834:support_scm",(void*)f_6834},
{"f_6838:support_scm",(void*)f_6838},
{"f_6604:support_scm",(void*)f_6604},
{"f_6608:support_scm",(void*)f_6608},
{"f_6616:support_scm",(void*)f_6616},
{"f_6797:support_scm",(void*)f_6797},
{"f_6805:support_scm",(void*)f_6805},
{"f_6800:support_scm",(void*)f_6800},
{"f_6736:support_scm",(void*)f_6736},
{"f_6787:support_scm",(void*)f_6787},
{"f_6791:support_scm",(void*)f_6791},
{"f_6794:support_scm",(void*)f_6794},
{"f_6740:support_scm",(void*)f_6740},
{"f_6785:support_scm",(void*)f_6785},
{"f_6743:support_scm",(void*)f_6743},
{"f_6762:support_scm",(void*)f_6762},
{"f_6778:support_scm",(void*)f_6778},
{"f_6770:support_scm",(void*)f_6770},
{"f_6754:support_scm",(void*)f_6754},
{"f_6749:support_scm",(void*)f_6749},
{"f_6694:support_scm",(void*)f_6694},
{"f_6697:support_scm",(void*)f_6697},
{"f_6700:support_scm",(void*)f_6700},
{"f_6713:support_scm",(void*)f_6713},
{"f_6678:support_scm",(void*)f_6678},
{"f_6670:support_scm",(void*)f_6670},
{"f_6648:support_scm",(void*)f_6648},
{"f_6638:support_scm",(void*)f_6638},
{"f_6645:support_scm",(void*)f_6645},
{"f_6610:support_scm",(void*)f_6610},
{"f_6511:support_scm",(void*)f_6511},
{"f_6517:support_scm",(void*)f_6517},
{"f_6529:support_scm",(void*)f_6529},
{"f_6533:support_scm",(void*)f_6533},
{"f_6536:support_scm",(void*)f_6536},
{"f_6596:support_scm",(void*)f_6596},
{"f_6572:support_scm",(void*)f_6572},
{"f_6555:support_scm",(void*)f_6555},
{"f_6559:support_scm",(void*)f_6559},
{"f_6541:support_scm",(void*)f_6541},
{"f_6523:support_scm",(void*)f_6523},
{"f_6463:support_scm",(void*)f_6463},
{"f_6469:support_scm",(void*)f_6469},
{"f_6489:support_scm",(void*)f_6489},
{"f_6493:support_scm",(void*)f_6493},
{"f_6145:support_scm",(void*)f_6145},
{"f_6151:support_scm",(void*)f_6151},
{"f_6170:support_scm",(void*)f_6170},
{"f_6404:support_scm",(void*)f_6404},
{"f_6434:support_scm",(void*)f_6434},
{"f_6430:support_scm",(void*)f_6430},
{"f_6411:support_scm",(void*)f_6411},
{"f_6415:support_scm",(void*)f_6415},
{"f_6342:support_scm",(void*)f_6342},
{"f_6391:support_scm",(void*)f_6391},
{"f_6360:support_scm",(void*)f_6360},
{"f_6368:support_scm",(void*)f_6368},
{"f_6318:support_scm",(void*)f_6318},
{"f_6285:support_scm",(void*)f_6285},
{"f_6264:support_scm",(void*)f_6264},
{"f_6260:support_scm",(void*)f_6260},
{"f_6244:support_scm",(void*)f_6244},
{"f_6256:support_scm",(void*)f_6256},
{"f_6252:support_scm",(void*)f_6252},
{"f_6198:support_scm",(void*)f_6198},
{"f_6194:support_scm",(void*)f_6194},
{"f_6177:support_scm",(void*)f_6177},
{"f_5631:support_scm",(void*)f_5631},
{"f_6140:support_scm",(void*)f_6140},
{"f_6143:support_scm",(void*)f_6143},
{"f_5634:support_scm",(void*)f_5634},
{"f_6130:support_scm",(void*)f_6130},
{"f_6010:support_scm",(void*)f_6010},
{"f_6053:support_scm",(void*)f_6053},
{"f_6090:support_scm",(void*)f_6090},
{"f_6067:support_scm",(void*)f_6067},
{"f_6074:support_scm",(void*)f_6074},
{"f_6081:support_scm",(void*)f_6081},
{"f_6071:support_scm",(void*)f_6071},
{"f_6060:support_scm",(void*)f_6060},
{"f_6047:support_scm",(void*)f_6047},
{"f_6035:support_scm",(void*)f_6035},
{"f_6019:support_scm",(void*)f_6019},
{"f_5989:support_scm",(void*)f_5989},
{"f_5973:support_scm",(void*)f_5973},
{"f_5969:support_scm",(void*)f_5969},
{"f_5936:support_scm",(void*)f_5936},
{"f_5894:support_scm",(void*)f_5894},
{"f_5863:support_scm",(void*)f_5863},
{"f_5849:support_scm",(void*)f_5849},
{"f_5823:support_scm",(void*)f_5823},
{"f_5769:support_scm",(void*)f_5769},
{"f_5789:support_scm",(void*)f_5789},
{"f_5779:support_scm",(void*)f_5779},
{"f_5787:support_scm",(void*)f_5787},
{"f_5772:support_scm",(void*)f_5772},
{"f_5719:support_scm",(void*)f_5719},
{"f_5722:support_scm",(void*)f_5722},
{"f_5729:support_scm",(void*)f_5729},
{"f_5716:support_scm",(void*)f_5716},
{"f_5693:support_scm",(void*)f_5693},
{"f_5622:support_scm",(void*)f_5622},
{"f_5613:support_scm",(void*)f_5613},
{"f_5607:support_scm",(void*)f_5607},
{"f_5598:support_scm",(void*)f_5598},
{"f_5589:support_scm",(void*)f_5589},
{"f_5580:support_scm",(void*)f_5580},
{"f_5571:support_scm",(void*)f_5571},
{"f_5562:support_scm",(void*)f_5562},
{"f_5553:support_scm",(void*)f_5553},
{"f_5547:support_scm",(void*)f_5547},
{"f_5541:support_scm",(void*)f_5541},
{"f_5066:support_scm",(void*)f_5066},
{"f_5539:support_scm",(void*)f_5539},
{"f_5070:support_scm",(void*)f_5070},
{"f_5075:support_scm",(void*)f_5075},
{"f_5085:support_scm",(void*)f_5085},
{"f_5218:support_scm",(void*)f_5218},
{"f_5228:support_scm",(void*)f_5228},
{"f_5244:support_scm",(void*)f_5244},
{"f_5320:support_scm",(void*)f_5320},
{"f_5360:support_scm",(void*)f_5360},
{"f_5350:support_scm",(void*)f_5350},
{"f_5323:support_scm",(void*)f_5323},
{"f_5340:support_scm",(void*)f_5340},
{"f_5326:support_scm",(void*)f_5326},
{"f_5329:support_scm",(void*)f_5329},
{"f_5336:support_scm",(void*)f_5336},
{"f_5311:support_scm",(void*)f_5311},
{"f_5301:support_scm",(void*)f_5301},
{"f_5285:support_scm",(void*)f_5285},
{"f_5247:support_scm",(void*)f_5247},
{"f_5262:support_scm",(void*)f_5262},
{"f_5231:support_scm",(void*)f_5231},
{"f_5088:support_scm",(void*)f_5088},
{"f_5129:support_scm",(void*)f_5129},
{"f_5153:support_scm",(void*)f_5153},
{"f_5177:support_scm",(void*)f_5177},
{"f_5180:support_scm",(void*)f_5180},
{"f_5156:support_scm",(void*)f_5156},
{"f_5132:support_scm",(void*)f_5132},
{"f_5091:support_scm",(void*)f_5091},
{"f_5119:support_scm",(void*)f_5119},
{"f_5094:support_scm",(void*)f_5094},
{"f_5106:support_scm",(void*)f_5106},
{"f_5097:support_scm",(void*)f_5097},
{"f_5038:support_scm",(void*)f_5038},
{"f_5044:support_scm",(void*)f_5044},
{"f_5051:support_scm",(void*)f_5051},
{"f_5054:support_scm",(void*)f_5054},
{"f_5064:support_scm",(void*)f_5064},
{"f_5057:support_scm",(void*)f_5057},
{"f_5014:support_scm",(void*)f_5014},
{"f_5020:support_scm",(void*)f_5020},
{"f_5030:support_scm",(void*)f_5030},
{"f_4978:support_scm",(void*)f_4978},
{"f_4985:support_scm",(void*)f_4985},
{"f_4988:support_scm",(void*)f_4988},
{"f_4968:support_scm",(void*)f_4968},
{"f_4959:support_scm",(void*)f_4959},
{"f_4963:support_scm",(void*)f_4963},
{"f_4902:support_scm",(void*)f_4902},
{"f_4906:support_scm",(void*)f_4906},
{"f_4936:support_scm",(void*)f_4936},
{"f_4850:support_scm",(void*)f_4850},
{"f_4854:support_scm",(void*)f_4854},
{"f_4881:support_scm",(void*)f_4881},
{"f_4804:support_scm",(void*)f_4804},
{"f_4808:support_scm",(void*)f_4808},
{"f_4830:support_scm",(void*)f_4830},
{"f_4786:support_scm",(void*)f_4786},
{"f_4790:support_scm",(void*)f_4790},
{"f_4798:support_scm",(void*)f_4798},
{"f_4768:support_scm",(void*)f_4768},
{"f_4772:support_scm",(void*)f_4772},
{"f_4533:support_scm",(void*)f_4533},
{"f_4683:support_scm",(void*)f_4683},
{"f_4698:support_scm",(void*)f_4698},
{"f_4723:support_scm",(void*)f_4723},
{"f_4741:support_scm",(void*)f_4741},
{"f_4726:support_scm",(void*)f_4726},
{"f_4541:support_scm",(void*)f_4541},
{"f_4598:support_scm",(void*)f_4598},
{"f_4613:support_scm",(void*)f_4613},
{"f_4638:support_scm",(void*)f_4638},
{"f_4656:support_scm",(void*)f_4656},
{"f_4641:support_scm",(void*)f_4641},
{"f_4544:support_scm",(void*)f_4544},
{"f_4549:support_scm",(void*)f_4549},
{"f_4564:support_scm",(void*)f_4564},
{"f_4589:support_scm",(void*)f_4589},
{"f_4537:support_scm",(void*)f_4537},
{"f_4392:support_scm",(void*)f_4392},
{"f_4396:support_scm",(void*)f_4396},
{"f_4400:support_scm",(void*)f_4400},
{"f_4389:support_scm",(void*)f_4389},
{"f_4386:support_scm",(void*)f_4386},
{"f_4279:support_scm",(void*)f_4279},
{"f_4288:support_scm",(void*)f_4288},
{"f_4319:support_scm",(void*)f_4319},
{"f_4373:support_scm",(void*)f_4373},
{"f_4379:support_scm",(void*)f_4379},
{"f_4325:support_scm",(void*)f_4325},
{"f_4357:support_scm",(void*)f_4357},
{"f_4371:support_scm",(void*)f_4371},
{"f_4363:support_scm",(void*)f_4363},
{"f_4329:support_scm",(void*)f_4329},
{"f_4351:support_scm",(void*)f_4351},
{"f_4294:support_scm",(void*)f_4294},
{"f_4300:support_scm",(void*)f_4300},
{"f_4311:support_scm",(void*)f_4311},
{"f_4308:support_scm",(void*)f_4308},
{"f_4286:support_scm",(void*)f_4286},
{"f_4178:support_scm",(void*)f_4178},
{"f_4184:support_scm",(void*)f_4184},
{"f_4261:support_scm",(void*)f_4261},
{"f_4212:support_scm",(void*)f_4212},
{"f_4250:support_scm",(void*)f_4250},
{"f_4238:support_scm",(void*)f_4238},
{"f_4118:support_scm",(void*)f_4118},
{"f_4134:support_scm",(void*)f_4134},
{"f_4176:support_scm",(void*)f_4176},
{"f_4140:support_scm",(void*)f_4140},
{"f_4155:support_scm",(void*)f_4155},
{"f_4072:support_scm",(void*)f_4072},
{"f_4116:support_scm",(void*)f_4116},
{"f_4076:support_scm",(void*)f_4076},
{"f_4042:support_scm",(void*)f_4042},
{"f_3996:support_scm",(void*)f_3996},
{"f_3976:support_scm",(void*)f_3976},
{"f_3982:support_scm",(void*)f_3982},
{"f_3990:support_scm",(void*)f_3990},
{"f_3994:support_scm",(void*)f_3994},
{"f_3945:support_scm",(void*)f_3945},
{"f_3951:support_scm",(void*)f_3951},
{"f_3966:support_scm",(void*)f_3966},
{"f_3882:support_scm",(void*)f_3882},
{"f_3896:support_scm",(void*)f_3896},
{"f_3898:support_scm",(void*)f_3898},
{"f_3927:support_scm",(void*)f_3927},
{"f_3906:support_scm",(void*)f_3906},
{"f_3870:support_scm",(void*)f_3870},
{"f_3823:support_scm",(void*)f_3823},
{"f_3839:support_scm",(void*)f_3839},
{"f_3851:support_scm",(void*)f_3851},
{"f_3816:support_scm",(void*)f_3816},
{"f_3809:support_scm",(void*)f_3809},
{"f_3753:support_scm",(void*)f_3753},
{"f_3807:support_scm",(void*)f_3807},
{"f_3757:support_scm",(void*)f_3757},
{"f_3780:support_scm",(void*)f_3780},
{"f_3659:support_scm",(void*)f_3659},
{"f_3675:support_scm",(void*)f_3675},
{"f_3677:support_scm",(void*)f_3677},
{"f_3699:support_scm",(void*)f_3699},
{"f_3738:support_scm",(void*)f_3738},
{"f_3706:support_scm",(void*)f_3706},
{"f_3722:support_scm",(void*)f_3722},
{"f_3710:support_scm",(void*)f_3710},
{"f_3714:support_scm",(void*)f_3714},
{"f_3671:support_scm",(void*)f_3671},
{"f_3615:support_scm",(void*)f_3615},
{"f_3621:support_scm",(void*)f_3621},
{"f_3645:support_scm",(void*)f_3645},
{"f_3584:support_scm",(void*)f_3584},
{"f_3607:support_scm",(void*)f_3607},
{"f_3610:support_scm",(void*)f_3610},
{"f_3613:support_scm",(void*)f_3613},
{"f_3557:support_scm",(void*)f_3557},
{"f_3576:support_scm",(void*)f_3576},
{"f_3579:support_scm",(void*)f_3579},
{"f_3521:support_scm",(void*)f_3521},
{"f_3527:support_scm",(void*)f_3527},
{"f_3453:support_scm",(void*)f_3453},
{"f_3477:support_scm",(void*)f_3477},
{"f_3456:support_scm",(void*)f_3456},
{"f_3464:support_scm",(void*)f_3464},
{"f_3468:support_scm",(void*)f_3468},
{"f_3410:support_scm",(void*)f_3410},
{"f_3416:support_scm",(void*)f_3416},
{"f_3439:support_scm",(void*)f_3439},
{"f_3443:support_scm",(void*)f_3443},
{"f_3407:support_scm",(void*)f_3407},
{"f_3346:support_scm",(void*)f_3346},
{"f_3350:support_scm",(void*)f_3350},
{"f_3353:support_scm",(void*)f_3353},
{"f_3356:support_scm",(void*)f_3356},
{"f_3367:support_scm",(void*)f_3367},
{"f_3380:support_scm",(void*)f_3380},
{"f_3359:support_scm",(void*)f_3359},
{"f_3362:support_scm",(void*)f_3362},
{"f_3327:support_scm",(void*)f_3327},
{"f_3331:support_scm",(void*)f_3331},
{"f_3344:support_scm",(void*)f_3344},
{"f_3334:support_scm",(void*)f_3334},
{"f_3337:support_scm",(void*)f_3337},
{"f_3298:support_scm",(void*)f_3298},
{"f_3305:support_scm",(void*)f_3305},
{"f_3308:support_scm",(void*)f_3308},
{"f_3318:support_scm",(void*)f_3318},
{"f_3311:support_scm",(void*)f_3311},
{"f_3239:support_scm",(void*)f_3239},
{"f_3249:support_scm",(void*)f_3249},
{"f_3264:support_scm",(void*)f_3264},
{"f_3269:support_scm",(void*)f_3269},
{"f_3296:support_scm",(void*)f_3296},
{"f_3282:support_scm",(void*)f_3282},
{"f_3285:support_scm",(void*)f_3285},
{"f_3252:support_scm",(void*)f_3252},
{"f_3255:support_scm",(void*)f_3255},
{"f_3258:support_scm",(void*)f_3258},
{"f_3212:support_scm",(void*)f_3212},
{"f_3226:support_scm",(void*)f_3226},
{"f_3207:support_scm",(void*)f_3207},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
