/* Generated from compiler-syntax.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-12-14 09:04
   Version 4.2.0 - SVN rev. 16023
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-12-14 on galinha (Linux)
   command line: compiler-syntax.scm -optimize-level 2 -include-path . -include-path ./ -inline -no-lambda-info -local -no-trace -extend private-namespace.scm -no-trace -output-file compiler-syntax.c
   unit: compiler_syntax
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[77];
static double C_possibly_force_alignment;


C_noret_decl(C_compiler_syntax_toplevel)
C_externexport void C_ccall C_compiler_syntax_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_461)
static void C_ccall f_461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_464)
static void C_ccall f_464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_467)
static void C_ccall f_467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_470)
static void C_ccall f_470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_473)
static void C_ccall f_473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_476)
static void C_ccall f_476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2240)
static void C_ccall f_2240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2015)
static void C_ccall f_2015(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2019)
static void C_ccall f_2019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2022)
static void C_ccall f_2022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2025)
static void C_ccall f_2025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2028)
static void C_ccall f_2028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2031)
static void C_ccall f_2031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2034)
static void C_ccall f_2034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2037)
static void C_ccall f_2037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2228)
static void C_ccall f_2228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2220)
static void C_ccall f_2220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2200)
static void C_ccall f_2200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2046)
static void C_fcall f_2046(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2184)
static void C_ccall f_2184(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2049)
static void C_ccall f_2049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2064)
static void C_ccall f_2064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2174)
static void C_ccall f_2174(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2172)
static void C_ccall f_2172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2168)
static void C_ccall f_2168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2144)
static void C_ccall f_2144(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2142)
static void C_ccall f_2142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2138)
static void C_ccall f_2138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2118)
static void C_ccall f_2118(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2116)
static void C_ccall f_2116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2112)
static void C_ccall f_2112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_561)
static void C_ccall f_561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2013)
static void C_ccall f_2013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1630)
static void C_ccall f_1630(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1634)
static void C_ccall f_1634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1637)
static void C_ccall f_1637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1640)
static void C_ccall f_1640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1643)
static void C_ccall f_1643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1646)
static void C_ccall f_1646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1649)
static void C_ccall f_1649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1652)
static void C_ccall f_1652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1655)
static void C_ccall f_1655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1658)
static void C_ccall f_1658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1661)
static void C_ccall f_1661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1664)
static void C_ccall f_1664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1667)
static void C_ccall f_1667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1670)
static void C_ccall f_1670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2001)
static void C_ccall f_2001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1993)
static void C_ccall f_1993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1973)
static void C_ccall f_1973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1679)
static void C_fcall f_1679(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1957)
static void C_ccall f_1957(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1682)
static void C_ccall f_1682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1713)
static void C_ccall f_1713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1919)
static void C_ccall f_1919(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1917)
static void C_ccall f_1917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1913)
static void C_ccall f_1913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1889)
static void C_ccall f_1889(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1887)
static void C_ccall f_1887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1883)
static void C_ccall f_1883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1783)
static void C_ccall f_1783(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1781)
static void C_ccall f_1781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1777)
static void C_ccall f_1777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_564)
static void C_ccall f_564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1581)
static void C_ccall f_1581(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1591)
static void C_ccall f_1591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1598)
static void C_ccall f_1598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1614)
static void C_ccall f_1614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_567)
static void C_ccall f_567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1579)
static void C_ccall f_1579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1575)
static void C_ccall f_1575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1571)
static void C_ccall f_1571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1567)
static void C_ccall f_1567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1563)
static void C_ccall f_1563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1559)
static void C_ccall f_1559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1555)
static void C_ccall f_1555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1419)
static void C_ccall f_1419(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1423)
static void C_ccall f_1423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1426)
static void C_ccall f_1426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1436)
static void C_ccall f_1436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1480)
static void C_ccall f_1480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1460)
static void C_ccall f_1460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_570)
static void C_ccall f_570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1417)
static void C_ccall f_1417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1413)
static void C_ccall f_1413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1409)
static void C_ccall f_1409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1405)
static void C_ccall f_1405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1401)
static void C_ccall f_1401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1397)
static void C_ccall f_1397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1393)
static void C_ccall f_1393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1308)
static void C_ccall f_1308(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1318)
static void C_ccall f_1318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_573)
static void C_ccall f_573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1306)
static void C_ccall f_1306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1302)
static void C_ccall f_1302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1298)
static void C_ccall f_1298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1294)
static void C_ccall f_1294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1290)
static void C_ccall f_1290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1286)
static void C_ccall f_1286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1282)
static void C_ccall f_1282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1211)
static void C_ccall f_1211(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1215)
static void C_ccall f_1215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_576)
static void C_ccall f_576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_578)
static void C_ccall f_578(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_584)
static void C_ccall f_584(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1193)
static void C_ccall f_1193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1197)
static void C_ccall f_1197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1182)
static void C_ccall f_1182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1189)
static void C_ccall f_1189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_606)
static void C_fcall f_606(C_word t0,C_word t1) C_noret;
C_noret_decl(f_609)
static void C_ccall f_609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_649)
static void C_ccall f_649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_652)
static void C_ccall f_652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_655)
static void C_ccall f_655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_658)
static void C_ccall f_658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_661)
static void C_ccall f_661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_664)
static void C_ccall f_664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_667)
static void C_ccall f_667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_761)
static void C_fcall f_761(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_822)
static void C_ccall f_822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1126)
static C_word C_fcall f_1126(C_word t0,C_word t1);
C_noret_decl(f_1040)
static void C_ccall f_1040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1043)
static void C_ccall f_1043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1010)
static void C_ccall f_1010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_973)
static void C_ccall f_973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_936)
static void C_ccall f_936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_899)
static void C_ccall f_899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_874)
static void C_ccall f_874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_849)
static void C_ccall f_849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_828)
static void C_ccall f_828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_771)
static void C_ccall f_771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_774)
static void C_ccall f_774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_793)
static void C_ccall f_793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_789)
static void C_ccall f_789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_698)
static void C_fcall f_698(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_741)
static void C_ccall f_741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_712)
static void C_fcall f_712(C_word t0,C_word t1) C_noret;
C_noret_decl(f_751)
static C_word C_fcall f_751(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_679)
static void C_fcall f_679(C_word t0,C_word t1) C_noret;
C_noret_decl(f_669)
static C_word C_fcall f_669(C_word t0);
C_noret_decl(f_614)
static void C_fcall f_614(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_618)
static void C_ccall f_618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_634)
static void C_ccall f_634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_637)
static void C_ccall f_637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_640)
static void C_ccall f_640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_631)
static void C_ccall f_631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_621)
static void C_ccall f_621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_493)
static void C_ccall f_493(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_493)
static void C_ccall f_493r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_497)
static void C_ccall f_497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_539)
static void C_ccall f_539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_509)
static void C_fcall f_509(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_522)
static void C_ccall f_522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_479)
static void C_ccall f_479(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_483)
static void C_ccall f_483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_487)
static void C_ccall f_487(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_2046)
static void C_fcall trf_2046(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2046(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2046(t0,t1);}

C_noret_decl(trf_1679)
static void C_fcall trf_1679(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1679(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1679(t0,t1);}

C_noret_decl(trf_606)
static void C_fcall trf_606(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_606(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_606(t0,t1);}

C_noret_decl(trf_761)
static void C_fcall trf_761(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_761(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_761(t0,t1,t2);}

C_noret_decl(trf_698)
static void C_fcall trf_698(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_698(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_698(t0,t1,t2);}

C_noret_decl(trf_712)
static void C_fcall trf_712(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_712(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_712(t0,t1);}

C_noret_decl(trf_679)
static void C_fcall trf_679(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_679(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_679(t0,t1);}

C_noret_decl(trf_614)
static void C_fcall trf_614(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_614(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_614(t0,t1,t2,t3,t4);}

C_noret_decl(trf_509)
static void C_fcall trf_509(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_509(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_509(t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr8)
static void C_fcall tr8(C_proc8 k) C_regparm C_noret;
C_regparm static void C_fcall tr8(C_proc8 k){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
(k)(8,t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_compiler_syntax_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_compiler_syntax_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("compiler_syntax_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(864)){
C_save(t1);
C_rereclaim2(864*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,77);
lf[0]=C_h_intern(&lf[0],35,"\010compilercompiler-syntax-statistics");
lf[1]=C_h_intern(&lf[1],24,"\003syscompiler-syntax-hook");
lf[2]=C_h_intern(&lf[2],13,"alist-update!");
lf[3]=C_h_intern(&lf[3],9,"alist-ref");
lf[4]=C_h_intern(&lf[4],3,"eq\077");
lf[5]=C_h_intern(&lf[5],14,"\010compilerr-c-s");
lf[6]=C_h_intern(&lf[6],8,"\003sysput!");
lf[7]=C_h_intern(&lf[7],24,"\010compilercompiler-syntax");
lf[8]=C_h_intern(&lf[8],18,"\003syser-transformer");
lf[9]=C_h_intern(&lf[9],9,"\003syserror");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[11]=C_h_intern(&lf[11],30,"\010compilercompile-format-string");
lf[12]=C_h_intern(&lf[12],17,"extended-bindings");
lf[13]=C_h_intern(&lf[13],25,"\010compilercompiler-warning");
lf[14]=C_h_intern(&lf[14],6,"syntax");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\000\036(~a) in format string ~s~a, ~\077");
lf[16]=C_h_intern(&lf[16],17,"get-output-string");
lf[17]=C_h_intern(&lf[17],7,"display");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\011 in line ");
lf[19]=C_h_intern(&lf[19],18,"open-output-string");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[21]=C_h_intern(&lf[21],17,"\010compilerget-line");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000/too few arguments to formatted output procedure");
lf[23]=C_h_intern(&lf[23],20,"reverse-list->string");
lf[24]=C_h_intern(&lf[24],10,"\003sysappend");
lf[25]=C_h_intern(&lf[25],7,"reverse");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\0000too many arguments to formatted output procedure");
lf[27]=C_h_intern(&lf[27],16,"\003sysflush-output");
lf[28]=C_h_intern(&lf[28],9,"\003sysapply");
lf[29]=C_h_intern(&lf[29],10,"write-char");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000$illegal format-string character `~c\047");
lf[31]=C_h_intern(&lf[31],14,"number->string");
lf[32]=C_h_intern(&lf[32],3,"let");
lf[33]=C_h_intern(&lf[33],7,"fprintf");
lf[34]=C_h_intern(&lf[34],3,"out");
lf[35]=C_h_intern(&lf[35],5,"write");
lf[36]=C_h_intern(&lf[36],5,"cadar");
lf[37]=C_h_intern(&lf[37],4,"caar");
lf[38]=C_h_intern(&lf[38],5,"quote");
lf[39]=C_h_intern(&lf[39],7,"call/cc");
lf[40]=C_h_intern(&lf[40],6,"printf");
lf[41]=C_h_intern(&lf[41],19,"\003sysstandard-output");
lf[42]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006printf\376\003\000\000\002\376\001\000\000\010#%printf\376\377\016");
lf[43]=C_h_intern(&lf[43],19,"\003sysprimitive-alias");
lf[44]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007fprintf\376\003\000\000\002\376\001\000\000\011#%fprintf\376\377\016");
lf[45]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007sprintf\376\003\000\000\002\376\001\000\000\011#%sprintf\376\377\016");
lf[46]=C_h_intern(&lf[46],7,"sprintf");
lf[47]=C_h_intern(&lf[47],6,"format");
lf[48]=C_h_intern(&lf[48],6,"gensym");
lf[49]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007sprintf\376\003\000\000\002\376\001\000\000\011#%sprintf\376\003\000\000\002\376\001\000\000\006format\376\003\000\000\002\376\001\000\000\010#%format\376\377\016");
lf[50]=C_h_intern(&lf[50],1,"o");
lf[51]=C_h_intern(&lf[51],10,"fold-right");
lf[52]=C_h_intern(&lf[52],4,"list");
lf[53]=C_h_intern(&lf[53],6,"lambda");
lf[54]=C_h_intern(&lf[54],3,"tmp");
lf[55]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001o\376\003\000\000\002\376\001\000\000\003#%o\376\377\016");
lf[56]=C_h_intern(&lf[56],11,"\003syssetslot");
lf[57]=C_h_intern(&lf[57],8,"\003sysslot");
lf[58]=C_h_intern(&lf[58],7,"\003sysmap");
lf[59]=C_h_intern(&lf[59],3,"map");
lf[60]=C_h_intern(&lf[60],17,"standard-bindings");
lf[61]=C_h_intern(&lf[61],5,"caadr");
lf[62]=C_h_intern(&lf[62],7,"length+");
lf[63]=C_h_intern(&lf[63],5,"pair\077");
lf[64]=C_h_intern(&lf[64],3,"and");
lf[65]=C_h_intern(&lf[65],5,"begin");
lf[66]=C_h_intern(&lf[66],4,"node");
lf[67]=C_h_intern(&lf[67],6,"result");
lf[68]=C_h_intern(&lf[68],4,"set!");
lf[69]=C_h_intern(&lf[69],4,"cons");
lf[70]=C_h_intern(&lf[70],3,"res");
lf[71]=C_h_intern(&lf[71],4,"loop");
lf[72]=C_h_intern(&lf[72],2,"if");
lf[73]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003map\376\003\000\000\002\376\001\000\000\007\003sysmap\376\003\000\000\002\376\001\000\000\005#%map\376\377\016");
lf[74]=C_h_intern(&lf[74],8,"\004coreapp");
lf[75]=C_h_intern(&lf[75],8,"for-each");
lf[76]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010for-each\376\003\000\000\002\376\001\000\000\014\003sysfor-each\376\003\000\000\002\376\001\000\000\012#%for-each\376\377\016");
C_register_lf2(lf,77,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_461,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k459 */
static void C_ccall f_461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_461,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_464,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k462 in k459 */
static void C_ccall f_464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_464,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_467,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k465 in k462 in k459 */
static void C_ccall f_467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_467,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_470,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k468 in k465 in k462 in k459 */
static void C_ccall f_470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_470,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_473,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_476,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_476,2,t0,t1);}
t2=C_set_block_item(lf[0] /* compiler-syntax-statistics */,0,C_SCHEME_END_OF_LIST);
t3=C_mutate((C_word*)lf[1]+1 /* (set! compiler-syntax-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_479,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[5]+1 /* (set! r-c-s ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_493,tmp=(C_word)a,a+=2,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_561,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2015,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2240,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t7,lf[63]);}

/* k2238 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_2240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2240,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[63],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* ##compiler#r-c-s */
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),((C_word*)t0)[3],lf[76],((C_word*)t0)[2],t3);}

/* a2014 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_2015(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2015,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2019,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* compiler-syntax.scm: 61   r */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[32]);}

/* k2017 in a2014 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_2019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2022,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm: 62   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[72]);}

/* k2020 in k2017 in a2014 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_2022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2025,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* compiler-syntax.scm: 63   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[71]);}

/* k2023 in k2020 in k2017 in a2014 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_2025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2028,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* compiler-syntax.scm: 64   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[65]);}

/* k2026 in k2023 in k2020 in k2017 in a2014 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_2028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2031,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* compiler-syntax.scm: 65   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[64]);}

/* k2029 in k2026 in k2023 in k2020 in k2017 in a2014 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_2031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2034,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler-syntax.scm: 66   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[63]);}

/* k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in a2014 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_2034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2037,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* compiler-syntax.scm: 67   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[53]);}

/* k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in a2014 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_2037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2037,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2046,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_memq(lf[75],C_retrieve(lf[60])))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2228,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[10],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* compiler-syntax.scm: 70   length+ */
((C_proc3)C_retrieve_symbol_proc(lf[62]))(3,*((C_word*)lf[62]+1),t4,((C_word*)t0)[10]);}
else{
t4=t3;
f_2046(t4,C_SCHEME_FALSE);}}

/* k2226 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in a2014 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_2228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2228,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greaterp(t1,C_fix(2)))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2200,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2220,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* compiler-syntax.scm: 72   caadr */
((C_proc3)C_retrieve_proc(*((C_word*)lf[61]+1)))(3,*((C_word*)lf[61]+1),t4,((C_word*)t0)[4]);}
else{
t4=t2;
f_2200(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
f_2046(t2,C_SCHEME_FALSE);}}

/* k2218 in k2226 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in a2014 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_2220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler-syntax.scm: 72   c */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2198 in k2226 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in a2014 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_2200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2046(t2,t1);}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_2046(t3,(C_word)C_i_symbolp(t2));}}

/* k2044 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in a2014 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_fcall f_2046(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2046,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2049,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2184,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[9]);}}

/* a2183 in k2044 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in a2014 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_2184(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2184,2,t0,t1);}
/* compiler-syntax.scm: 74   gensym */
((C_proc2)C_retrieve_symbol_proc(lf[48]))(2,*((C_word*)lf[48]+1),t1);}

/* k2047 in k2044 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in a2014 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_2049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2064,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* compiler-syntax.scm: 75   map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[59]+1)))(5,*((C_word*)lf[59]+1),t2,*((C_word*)lf[52]+1),t1,((C_word*)t0)[2]);}

/* k2062 in k2047 in k2044 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in a2014 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_2064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2064,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2168,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2172,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2174,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[3]);}

/* a2173 in k2062 in k2047 in k2044 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in a2014 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_2174(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2174,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k2170 in k2062 in k2047 in k2044 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in a2014 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_2172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2166 in k2062 in k2047 in k2044 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in a2014 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_2168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2168,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_i_cadr(((C_word*)t0)[9]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2138,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[7],a[10]=t5,tmp=(C_word)a,a+=11,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2142,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2144,tmp=(C_word)a,a+=2,tmp);
/* map */
t9=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,((C_word*)t0)[2]);}

/* a2143 in k2166 in k2062 in k2047 in k2044 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in a2014 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_2144(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2144,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[57],t4));}

/* k2140 in k2166 in k2062 in k2047 in k2044 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in a2014 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_2142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2136 in k2166 in k2062 in k2047 in k2044 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in a2014 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_2138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2138,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2112,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2116,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2118,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a2117 in k2136 in k2166 in k2062 in k2047 in k2044 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in a2014 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_2118(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2118,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,C_fix(1),C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[57],t4));}

/* k2114 in k2136 in k2166 in k2062 in k2047 in k2044 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in a2014 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_2116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2110 in k2136 in k2166 in k2062 in k2047 in k2044 in k2035 in k2032 in k2029 in k2026 in k2023 in k2020 in k2017 in a2014 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_2112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2112,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[74],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t10);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t11);
t13=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t12));}

/* k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_564,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1630,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2013,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t4,lf[63]);}

/* k2011 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_2013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2013,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[63],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* ##compiler#r-c-s */
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),((C_word*)t0)[3],lf[73],((C_word*)t0)[2],t3);}

/* a1629 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1630(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1630,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1634,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* compiler-syntax.scm: 87   r */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[32]);}

/* k1632 in a1629 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1637,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm: 88   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[72]);}

/* k1635 in k1632 in a1629 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1640,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* compiler-syntax.scm: 89   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[71]);}

/* k1638 in k1635 in k1632 in a1629 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1643,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* compiler-syntax.scm: 90   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[70]);}

/* k1641 in k1638 in k1635 in k1632 in a1629 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1643,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1646,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* compiler-syntax.scm: 91   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[69]);}

/* k1644 in k1641 in k1638 in k1635 in k1632 in a1629 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1649,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler-syntax.scm: 92   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[68]);}

/* k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in a1629 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1652,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* compiler-syntax.scm: 93   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[67]);}

/* k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in a1629 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1652,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1655,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* compiler-syntax.scm: 94   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[66]);}

/* k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in a1629 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1655,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1658,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* compiler-syntax.scm: 95   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[38]);}

/* k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in a1629 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1658,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1661,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* compiler-syntax.scm: 96   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[65]);}

/* k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in a1629 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1661,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1664,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* compiler-syntax.scm: 97   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[53]);}

/* k1662 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in a1629 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1664,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1667,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
/* compiler-syntax.scm: 98   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[64]);}

/* k1665 in k1662 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in a1629 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1667,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1670,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t1,a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
/* compiler-syntax.scm: 99   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[63]);}

/* k1668 in k1665 in k1662 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in a1629 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1670,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[16]);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1679,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[16],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
if(C_truep((C_word)C_i_memq(lf[59],C_retrieve(lf[60])))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2001,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[16],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* compiler-syntax.scm: 102  length+ */
((C_proc3)C_retrieve_symbol_proc(lf[62]))(3,*((C_word*)lf[62]+1),t4,((C_word*)t0)[16]);}
else{
t4=t3;
f_1679(t4,C_SCHEME_FALSE);}}

/* k1999 in k1668 in k1665 in k1662 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in a1629 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_2001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2001,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greaterp(t1,C_fix(2)))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1973,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1993,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* compiler-syntax.scm: 104  caadr */
((C_proc3)C_retrieve_proc(*((C_word*)lf[61]+1)))(3,*((C_word*)lf[61]+1),t4,((C_word*)t0)[4]);}
else{
t4=t2;
f_1973(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
f_1679(t2,C_SCHEME_FALSE);}}

/* k1991 in k1999 in k1668 in k1665 in k1662 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in a1629 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler-syntax.scm: 104  c */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1971 in k1999 in k1668 in k1665 in k1662 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in a1629 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_1679(t2,t1);}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_1679(t3,(C_word)C_i_symbolp(t2));}}

/* k1677 in k1668 in k1665 in k1662 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in a1629 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_fcall f_1679(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1679,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1682,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1957,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[12]);}}

/* a1956 in k1677 in k1668 in k1665 in k1662 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in a1629 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1957(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1957,2,t0,t1);}
/* compiler-syntax.scm: 106  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[48]))(2,*((C_word*)lf[48]+1),t1);}

/* k1680 in k1677 in k1668 in k1665 in k1662 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in a1629 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1682,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[16],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[15],t4);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[14],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t5,t8);
t10=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1713,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t9,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[15],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[11],a[16]=((C_word*)t0)[12],a[17]=((C_word*)t0)[13],tmp=(C_word)a,a+=18,tmp);
/* compiler-syntax.scm: 109  map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[59]+1)))(5,*((C_word*)lf[59]+1),t10,*((C_word*)lf[52]+1),t1,((C_word*)t0)[2]);}

/* k1711 in k1680 in k1677 in k1668 in k1665 in k1662 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in a1629 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1713,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1913,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1917,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1919,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[3]);}

/* a1918 in k1711 in k1680 in k1677 in k1668 in k1665 in k1662 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in a1629 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1919(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1919,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k1915 in k1711 in k1680 in k1677 in k1668 in k1665 in k1662 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in a1629 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k1911 in k1711 in k1680 in k1677 in k1668 in k1665 in k1662 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in a1629 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1913,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[17],t1);
t3=(C_word)C_i_cadr(((C_word*)t0)[16]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[15],t4);
t6=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1883,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=t5,tmp=(C_word)a,a+=17,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1887,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1889,tmp=(C_word)a,a+=2,tmp);
/* map */
t9=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,((C_word*)t0)[2]);}

/* a1888 in k1911 in k1711 in k1680 in k1677 in k1668 in k1665 in k1662 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in a1629 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1889(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1889,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[57],t4));}

/* k1885 in k1911 in k1711 in k1680 in k1677 in k1668 in k1665 in k1662 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in a1629 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k1881 in k1911 in k1711 in k1680 in k1677 in k1668 in k1665 in k1662 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in a1629 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[87],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1883,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[16],t1);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[15],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t2,t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[14],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,C_fix(1),t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],t12);
t14=(C_word)C_a_i_cons(&a,2,lf[56],t13);
t15=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t15);
t17=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t16);
t18=(C_word)C_a_i_cons(&a,2,t17,C_SCHEME_END_OF_LIST);
t19=(C_word)C_a_i_cons(&a,2,t14,t18);
t20=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],t19);
t21=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t20);
t22=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t23=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],t22);
t24=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t23);
t25=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1777,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[7],a[9]=t10,a[10]=t21,a[11]=t24,a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1781,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1783,tmp=(C_word)a,a+=2,tmp);
/* map */
t28=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t28+1)))(4,t28,t26,t27,((C_word*)t0)[2]);}

/* a1782 in k1881 in k1911 in k1711 in k1680 in k1677 in k1668 in k1665 in k1662 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in a1629 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1783(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1783,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,C_fix(1),C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[57],t4));}

/* k1779 in k1881 in k1911 in k1711 in k1680 in k1677 in k1668 in k1665 in k1662 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in a1629 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k1775 in k1881 in k1911 in k1711 in k1680 in k1677 in k1668 in k1665 in k1662 in k1659 in k1656 in k1653 in k1650 in k1647 in k1644 in k1641 in k1638 in k1635 in k1632 in a1629 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1777,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t9);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t10);
t12=(C_word)C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t12);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],t13);
t15=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t14);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t16);
t18=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t17));}

/* k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_564,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_567,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1581,tmp=(C_word)a,a+=2,tmp);
/* ##compiler#r-c-s */
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),t2,lf[55],t3,C_SCHEME_END_OF_LIST);}

/* a1580 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1581(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1581,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_length(t2);
t6=(C_word)C_fixnum_greaterp(t5,C_fix(1));
t7=(C_truep(t6)?(C_word)C_i_memq(lf[50],C_retrieve(lf[12])):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1591,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler-syntax.scm: 128  r */
t9=t3;
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,lf[54]);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t2);}}

/* k1589 in a1580 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1591,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1598,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler-syntax.scm: 129  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[53]);}

/* k1596 in k1589 in a1580 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1598,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1614,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* compiler-syntax.scm: 129  fold-right */
((C_proc5)C_retrieve_symbol_proc(lf[51]))(5,*((C_word*)lf[51]+1),t3,*((C_word*)lf[52]+1),((C_word*)t0)[4],t4);}

/* k1612 in k1596 in k1589 in a1580 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1614,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_567,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_570,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1419,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1579,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t4,lf[17]);}

/* k1577 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1579,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[17],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1575,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[35]);}

/* k1573 in k1577 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1575,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[35],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1571,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[33]);}

/* k1569 in k1573 in k1577 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1571,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[33],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1567,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[31]);}

/* k1565 in k1569 in k1573 in k1577 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1567,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[31],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1563,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[29]);}

/* k1561 in k1565 in k1569 in k1573 in k1577 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1563,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[29],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1559,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[19]);}

/* k1557 in k1561 in k1565 in k1569 in k1573 in k1577 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1559,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[19],t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1555,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[16]);}

/* k1553 in k1557 in k1561 in k1565 in k1569 in k1573 in k1577 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1555,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[16],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
/* ##compiler#r-c-s */
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),((C_word*)t0)[3],lf[49],((C_word*)t0)[2],t9);}

/* a1418 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1419(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1419,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1423,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler-syntax.scm: 134  gensym */
((C_proc3)C_retrieve_symbol_proc(lf[48]))(3,*((C_word*)lf[48]+1),t5,lf[34]);}

/* k1421 in a1418 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1426,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_i_memq(t3,lf[45]);
t5=(C_truep(t4)?lf[46]:lf[47]);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* compiler-syntax.scm: 135  compile-format-string */
((C_proc8)C_retrieve_symbol_proc(lf[11]))(8,*((C_word*)lf[11]+1),t2,t5,t1,((C_word*)t0)[3],t6,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k1424 in k1421 in a1418 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1426,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1436,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler-syntax.scm: 144  r */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[32]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k1434 in k1424 in k1421 in a1418 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1436,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1480,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm: 144  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[19]);}

/* k1478 in k1434 in k1424 in k1421 in a1418 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1480,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1460,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm: 146  r */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[16]);}

/* k1458 in k1478 in k1434 in k1424 in k1421 in a1418 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1460,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t6));}

/* k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_570,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_573,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1308,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1417,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t4,lf[17]);}

/* k1415 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1417,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[17],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1413,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[35]);}

/* k1411 in k1415 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1413,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[35],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1409,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[33]);}

/* k1407 in k1411 in k1415 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1409,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[33],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1405,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[31]);}

/* k1403 in k1407 in k1411 in k1415 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1405,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[31],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1401,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[29]);}

/* k1399 in k1403 in k1407 in k1411 in k1415 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1401,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[29],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1397,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[19]);}

/* k1395 in k1399 in k1403 in k1407 in k1411 in k1415 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1397,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[19],t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1393,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[16]);}

/* k1391 in k1395 in k1399 in k1403 in k1407 in k1411 in k1415 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1393,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[16],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
/* ##compiler#r-c-s */
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),((C_word*)t0)[3],lf[44],((C_word*)t0)[2],t9);}

/* a1307 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1308(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1308,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_length(t2);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t5,C_fix(3)))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1318,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cadr(t2);
t8=(C_word)C_i_cddr(t2);
/* compiler-syntax.scm: 152  compile-format-string */
((C_proc8)C_retrieve_symbol_proc(lf[11]))(8,*((C_word*)lf[11]+1),t6,lf[33],t7,t2,t8,t3,t4);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}}

/* k1316 in a1307 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_573,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_576,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1211,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1306,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t4,lf[17]);}

/* k1304 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1306,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[17],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1302,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[35]);}

/* k1300 in k1304 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1302,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[35],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1298,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[33]);}

/* k1296 in k1300 in k1304 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1298,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[33],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1294,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[31]);}

/* k1292 in k1296 in k1300 in k1304 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1294,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[31],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1290,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[29]);}

/* k1288 in k1292 in k1296 in k1300 in k1304 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1290,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[29],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1286,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[19]);}

/* k1284 in k1288 in k1292 in k1296 in k1300 in k1304 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1286,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[19],t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1282,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[16]);}

/* k1280 in k1284 in k1288 in k1292 in k1296 in k1300 in k1304 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1282,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[16],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
/* ##compiler#r-c-s */
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),((C_word*)t0)[3],lf[42],((C_word*)t0)[2],t9);}

/* a1210 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1211(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1211,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1215,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* compiler-syntax.scm: 161  compile-format-string */
((C_proc8)C_retrieve_symbol_proc(lf[11]))(8,*((C_word*)lf[11]+1),t5,lf[40],lf[41],t2,t6,t3,t4);}

/* k1213 in a1210 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_576,2,t0,t1);}
t2=C_mutate((C_word*)lf[11]+1 /* (set! compile-format-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_578,tmp=(C_word)a,a+=2,tmp));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_578(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=8) C_bad_argc_2(c,8,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr8,(void*)f_578,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_584,a[2]=t7,a[3]=t6,a[4]=t3,a[5]=t4,a[6]=t2,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* compiler-syntax.scm: 168  call/cc */
((C_proc3)C_retrieve_proc(*((C_word*)lf[39]+1)))(3,*((C_word*)lf[39]+1),t1,t8);}

/* a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_584(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_584,3,t0,t1,t2);}
t3=(C_word)C_i_length(((C_word*)t0)[7]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(1)))){
if(C_truep((C_word)C_i_memq(((C_word*)t0)[6],C_retrieve(lf[12])))){
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(C_word)C_i_stringp(t4);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_606,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t5)){
t7=t6;
f_606(t7,t5);}
else{
t7=(C_word)C_i_car(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_listp(t7))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1182,a[2]=((C_word*)t0)[7],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1193,a[2]=((C_word*)t0)[7],a[3]=t8,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* compiler-syntax.scm: 174  r */
t10=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,lf[38]);}
else{
t8=t6;
f_606(t8,C_SCHEME_FALSE);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k1191 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1193,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1197,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler-syntax.scm: 174  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[37]+1)))(3,*((C_word*)lf[37]+1),t2,((C_word*)t0)[2]);}

/* k1195 in k1191 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler-syntax.scm: 174  c */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1180 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1182,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1189,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler-syntax.scm: 175  cadar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_606(t2,C_SCHEME_FALSE);}}

/* k1187 in k1180 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_606(t2,(C_word)C_i_stringp(t1));}

/* k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_fcall f_606(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_606,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_609,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[8]);
if(C_truep((C_word)C_i_stringp(t3))){
t4=t2;
f_609(2,t4,(C_word)C_i_car(((C_word*)t0)[8]));}
else{
/* compiler-syntax.scm: 176  cadar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t2,((C_word*)t0)[8]);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_609,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_614,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_fix(0);
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(C_word)C_i_string_length(t1);
t11=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_649,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t10,a[6]=t7,a[7]=t5,a[8]=t4,a[9]=t9,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* compiler-syntax.scm: 190  r */
t12=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t12))(3,t12,t11,lf[17]);}

/* k647 in k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_652,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* compiler-syntax.scm: 191  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[35]);}

/* k650 in k647 in k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_652,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_655,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* compiler-syntax.scm: 192  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[29]);}

/* k653 in k650 in k647 in k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_655,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_658,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* compiler-syntax.scm: 193  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[34]);}

/* k656 in k653 in k650 in k647 in k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_658,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_661,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* compiler-syntax.scm: 194  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[33]);}

/* k659 in k656 in k653 in k650 in k647 in k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_661,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_664,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* compiler-syntax.scm: 195  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[32]);}

/* k662 in k659 in k656 in k653 in k650 in k647 in k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_664,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_667,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
/* compiler-syntax.scm: 196  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[31]);}

/* k665 in k662 in k659 in k656 in k653 in k650 in k647 in k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_667,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_669,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_679,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_751,a[2]=((C_word*)t0)[11],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_698,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_761,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[8],a[6]=t3,a[7]=t4,a[8]=((C_word*)t0)[4],a[9]=t7,a[10]=t2,a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t5,a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[5],a[16]=((C_word*)t0)[10],a[17]=((C_word*)t0)[6],a[18]=((C_word*)t0)[7],a[19]=((C_word*)t0)[14],tmp=(C_word)a,a+=20,tmp));
t9=((C_word*)t7)[1];
f_761(t9,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* loop in k665 in k662 in k659 in k656 in k653 in k650 in k647 in k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_fcall f_761(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(16);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_761,NULL,3,t0,t1,t2);}
t3=((C_word*)((C_word*)t0)[19])[1];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[18]))){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_771,a[2]=t2,a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=t1,a[7]=((C_word*)t0)[16],a[8]=((C_word*)t0)[17],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[12])[1]))){
t5=t4;
f_771(2,t5,C_SCHEME_UNDEFINED);}
else{
/* compiler-syntax.scm: 218  fail */
t5=((C_word*)t0)[11];
f_614(t5,t4,C_SCHEME_FALSE,lf[26],C_SCHEME_END_OF_LIST);}}
else{
t4=f_669(((C_word*)t0)[10]);
t5=(C_word)C_eqp(t4,C_make_character(126));
if(C_truep(t5)){
t6=f_669(((C_word*)t0)[10]);
t7=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_822,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[19],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[16],a[13]=t1,a[14]=((C_word*)t0)[9],a[15]=t6,tmp=(C_word)a,a+=16,tmp);
/* compiler-syntax.scm: 226  endchunk */
t8=((C_word*)t0)[13];
f_698(t8,t7,t2);}
else{
t6=(C_word)C_a_i_cons(&a,2,t4,t2);
/* compiler-syntax.scm: 249  loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* k820 in loop in k665 in k662 in k659 in k656 in k653 in k650 in k647 in k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_822,2,t0,t1);}
t2=(C_word)C_u_i_char_upcase(((C_word*)t0)[15]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_828,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],tmp=(C_word)a,a+=4,tmp);
switch(t2){
case C_make_character(83):
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_849,a[2]=((C_word*)t0)[10],a[3]=t3,a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
/* compiler-syntax.scm: 228  next */
t5=((C_word*)t0)[9];
f_679(t5,t4);
case C_make_character(65):
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_874,a[2]=((C_word*)t0)[10],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
/* compiler-syntax.scm: 229  next */
t5=((C_word*)t0)[9];
f_679(t5,t4);
case C_make_character(67):
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_899,a[2]=((C_word*)t0)[10],a[3]=t3,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
/* compiler-syntax.scm: 230  next */
t5=((C_word*)t0)[9];
f_679(t5,t4);
case C_make_character(66):
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_936,a[2]=((C_word*)t0)[10],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm: 231  next */
t5=((C_word*)t0)[9];
f_679(t5,t4);
case C_make_character(79):
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_973,a[2]=((C_word*)t0)[10],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm: 232  next */
t5=((C_word*)t0)[9];
f_679(t5,t4);
case C_make_character(88):
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1010,a[2]=((C_word*)t0)[10],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm: 233  next */
t5=((C_word*)t0)[9];
f_679(t5,t4);
case C_make_character(33):
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[27],t4);
/* compiler-syntax.scm: 234  push */
t6=t3;
f_828(2,t6,f_751(C_a_i(&a,3),((C_word*)t0)[10],t5));
case C_make_character(63):
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1040,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm: 236  next */
t5=((C_word*)t0)[9];
f_679(t5,t4);
case C_make_character(126):
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,C_make_character(126),t4);
t6=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[29]+1),t5);
/* compiler-syntax.scm: 239  push */
t7=t3;
f_828(2,t7,f_751(C_a_i(&a,3),((C_word*)t0)[10],t6));
default:
t4=(C_word)C_eqp(t2,C_make_character(37));
t5=(C_truep(t4)?t4:(C_word)C_eqp(t2,C_make_character(78)));
if(C_truep(t5)){
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,C_make_character(10),t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t7);
/* compiler-syntax.scm: 240  push */
t9=t3;
f_828(2,t9,f_751(C_a_i(&a,3),((C_word*)t0)[10],t8));}
else{
if(C_truep((C_word)C_u_i_char_whitespacep(((C_word*)t0)[15]))){
t6=f_669(((C_word*)t0)[4]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1126,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=t3;
f_828(2,t8,f_1126(t7,t6));}
else{
/* compiler-syntax.scm: 247  fail */
t6=((C_word*)t0)[2];
f_614(t6,t3,C_SCHEME_TRUE,lf[30],(C_word)C_a_i_list(&a,1,((C_word*)t0)[15]));}}}}

/* skip in k820 in loop in k665 in k662 in k659 in k656 in k653 in k650 in k647 in k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static C_word C_fcall f_1126(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
if(C_truep((C_word)C_u_i_char_whitespacep(t1))){
t2=f_669(((C_word*)t0)[3]);
t6=t2;
t1=t6;
goto loop;}
else{
t2=(C_word)C_fixnum_decrease(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t3);}}

/* k1038 in k820 in loop in k665 in k662 in k659 in k656 in k653 in k650 in k647 in k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1040,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1043,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm: 237  next */
t3=((C_word*)t0)[2];
f_679(t3,t2);}

/* k1041 in k1038 in k820 in loop in k665 in k662 in k659 in k656 in k653 in k650 in k647 in k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1043,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[28],t5);
/* compiler-syntax.scm: 238  push */
t7=((C_word*)t0)[3];
f_828(2,t7,f_751(C_a_i(&a,3),((C_word*)t0)[2],t6));}

/* k1008 in k820 in loop in k665 in k662 in k659 in k656 in k653 in k650 in k647 in k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_1010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1010,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_fix(16),C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
/* compiler-syntax.scm: 233  push */
t8=((C_word*)t0)[3];
f_828(2,t8,f_751(C_a_i(&a,3),((C_word*)t0)[2],t7));}

/* k971 in k820 in loop in k665 in k662 in k659 in k656 in k653 in k650 in k647 in k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_973,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_fix(8),C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
/* compiler-syntax.scm: 232  push */
t8=((C_word*)t0)[3];
f_828(2,t8,f_751(C_a_i(&a,3),((C_word*)t0)[2],t7));}

/* k934 in k820 in loop in k665 in k662 in k659 in k656 in k653 in k650 in k647 in k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_936,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_fix(2),C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
/* compiler-syntax.scm: 231  push */
t8=((C_word*)t0)[3];
f_828(2,t8,f_751(C_a_i(&a,3),((C_word*)t0)[2],t7));}

/* k897 in k820 in loop in k665 in k662 in k659 in k656 in k653 in k650 in k647 in k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_899,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
/* compiler-syntax.scm: 230  push */
t5=((C_word*)t0)[3];
f_828(2,t5,f_751(C_a_i(&a,3),((C_word*)t0)[2],t4));}

/* k872 in k820 in loop in k665 in k662 in k659 in k656 in k653 in k650 in k647 in k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_874,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
/* compiler-syntax.scm: 229  push */
t5=((C_word*)t0)[3];
f_828(2,t5,f_751(C_a_i(&a,3),((C_word*)t0)[2],t4));}

/* k847 in k820 in loop in k665 in k662 in k659 in k656 in k653 in k650 in k647 in k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_849,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
/* compiler-syntax.scm: 228  push */
t5=((C_word*)t0)[3];
f_828(2,t5,f_751(C_a_i(&a,3),((C_word*)t0)[2],t4));}

/* k826 in k820 in loop in k665 in k662 in k659 in k656 in k653 in k650 in k647 in k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler-syntax.scm: 248  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_761(t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k769 in loop in k665 in k662 in k659 in k656 in k653 in k650 in k647 in k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_771,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_774,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm: 219  endchunk */
t3=((C_word*)t0)[3];
f_698(t3,t2,((C_word*)t0)[2]);}

/* k772 in k769 in loop in k665 in k662 in k659 in k656 in k653 in k650 in k647 in k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_774,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_789,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_793,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* compiler-syntax.scm: 221  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[25]+1)))(3,*((C_word*)lf[25]+1),t6,((C_word*)((C_word*)t0)[2])[1]);}

/* k791 in k772 in k769 in loop in k665 in k662 in k659 in k656 in k653 in k650 in k647 in k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k787 in k772 in k769 in loop in k665 in k662 in k659 in k656 in k653 in k650 in k647 in k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_789,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* endchunk in k665 in k662 in k659 in k656 in k653 in k650 in k647 in k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_fcall f_698(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_698,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_712,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_length(t2);
t5=(C_word)C_eqp(C_fix(1),t4);
if(C_truep(t5)){
t6=(C_word)C_i_car(t2);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=t3;
f_712(t9,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8));}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_741,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler-syntax.scm: 212  reverse-list->string */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),t6,t2);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k739 in endchunk in k665 in k662 in k659 in k656 in k653 in k650 in k647 in k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_741,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[3];
f_712(t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k710 in endchunk in k665 in k662 in k659 in k656 in k653 in k650 in k647 in k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_fcall f_712(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_712,NULL,2,t0,t1);}
/* compiler-syntax.scm: 209  push */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_751(C_a_i(&a,3),((C_word*)t0)[2],t1));}

/* push in k665 in k662 in k659 in k656 in k653 in k650 in k647 in k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static C_word C_fcall f_751(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t3);}

/* next in k665 in k662 in k659 in k656 in k653 in k650 in k647 in k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_fcall f_679(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_679,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[3])[1]))){
/* compiler-syntax.scm: 203  fail */
t2=((C_word*)t0)[2];
f_614(t2,t1,C_SCHEME_TRUE,lf[22],C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* fetch in k665 in k662 in k659 in k656 in k653 in k650 in k647 in k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static C_word C_fcall f_669(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t1=(C_word)C_i_string_ref(((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t1);}

/* fail in k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_fcall f_614(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_614,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_618,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* compiler-syntax.scm: 179  get-line */
((C_proc3)C_retrieve_symbol_proc(lf[21]))(3,*((C_word*)lf[21]+1),t5,((C_word*)t0)[2]);}

/* k616 in fail in k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_618,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_621,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_631,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_634,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[19]))(2,*((C_word*)lf[19]+1),t4);}
else{
t4=t3;
f_631(2,t4,lf[20]);}}

/* k632 in k616 in fail in k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_637,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,lf[18],t1);}

/* k635 in k632 in k616 in fail in k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_640,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k638 in k635 in k632 in k616 in fail in k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k629 in k616 in fail in k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler-syntax.scm: 180  compiler-warning */
((C_proc9)C_retrieve_symbol_proc(lf[13]))(9,*((C_word*)lf[13]+1),((C_word*)t0)[6],lf[14],lf[15],((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k619 in k616 in fail in k607 in k604 in a583 in ##compiler#compile-format-string in k574 in k571 in k568 in k565 in k562 in k559 in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* compiler-syntax.scm: 186  return */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##compiler#r-c-s in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_493(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_493r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_493r(t0,t1,t2,t3,t4);}}

static void C_ccall f_493r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_497,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_497(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_497(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[10],t4);}}}

/* k495 in ##compiler#r-c-s in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_497,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_539,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler-syntax.scm: 46   ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[8]))(3,*((C_word*)lf[8]+1),t2,((C_word*)t0)[2]);}

/* k537 in k495 in ##compiler#r-c-s in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_539,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_i_symbolp(((C_word*)t0)[3]);
t4=(C_truep(t3)?(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]):((C_word*)t0)[3]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_509,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_509(t8,((C_word*)t0)[2],t4);}

/* loop52 in k537 in k495 in ##compiler#r-c-s in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_fcall f_509(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_509,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_522,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* compiler-syntax.scm: 49   ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),t4,t3,lf[7],((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k520 in loop52 in k537 in k495 in ##compiler#r-c-s in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_509(t3,((C_word*)t0)[2],t2);}

/* ##sys#compiler-syntax-hook in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_479(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_479,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_483,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler-syntax.scm: 41   alist-ref */
((C_proc6)C_retrieve_symbol_proc(lf[3]))(6,*((C_word*)lf[3]+1),t4,t2,C_retrieve(lf[0]),*((C_word*)lf[4]+1),C_fix(0));}

/* k481 in ##sys#compiler-syntax-hook in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_483,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_487,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_fixnum_increase(t1);
/* compiler-syntax.scm: 43   alist-update! */
((C_proc5)C_retrieve_symbol_proc(lf[2]))(5,*((C_word*)lf[2]+1),t2,((C_word*)t0)[2],t3,C_retrieve(lf[0]));}

/* k485 in k481 in ##sys#compiler-syntax-hook in k474 in k471 in k468 in k465 in k462 in k459 */
static void C_ccall f_487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[0]+1 /* (set! compiler-syntax-statistics ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[157] = {
{"toplevel:compiler_syntax_scm",(void*)C_compiler_syntax_toplevel},
{"f_461:compiler_syntax_scm",(void*)f_461},
{"f_464:compiler_syntax_scm",(void*)f_464},
{"f_467:compiler_syntax_scm",(void*)f_467},
{"f_470:compiler_syntax_scm",(void*)f_470},
{"f_473:compiler_syntax_scm",(void*)f_473},
{"f_476:compiler_syntax_scm",(void*)f_476},
{"f_2240:compiler_syntax_scm",(void*)f_2240},
{"f_2015:compiler_syntax_scm",(void*)f_2015},
{"f_2019:compiler_syntax_scm",(void*)f_2019},
{"f_2022:compiler_syntax_scm",(void*)f_2022},
{"f_2025:compiler_syntax_scm",(void*)f_2025},
{"f_2028:compiler_syntax_scm",(void*)f_2028},
{"f_2031:compiler_syntax_scm",(void*)f_2031},
{"f_2034:compiler_syntax_scm",(void*)f_2034},
{"f_2037:compiler_syntax_scm",(void*)f_2037},
{"f_2228:compiler_syntax_scm",(void*)f_2228},
{"f_2220:compiler_syntax_scm",(void*)f_2220},
{"f_2200:compiler_syntax_scm",(void*)f_2200},
{"f_2046:compiler_syntax_scm",(void*)f_2046},
{"f_2184:compiler_syntax_scm",(void*)f_2184},
{"f_2049:compiler_syntax_scm",(void*)f_2049},
{"f_2064:compiler_syntax_scm",(void*)f_2064},
{"f_2174:compiler_syntax_scm",(void*)f_2174},
{"f_2172:compiler_syntax_scm",(void*)f_2172},
{"f_2168:compiler_syntax_scm",(void*)f_2168},
{"f_2144:compiler_syntax_scm",(void*)f_2144},
{"f_2142:compiler_syntax_scm",(void*)f_2142},
{"f_2138:compiler_syntax_scm",(void*)f_2138},
{"f_2118:compiler_syntax_scm",(void*)f_2118},
{"f_2116:compiler_syntax_scm",(void*)f_2116},
{"f_2112:compiler_syntax_scm",(void*)f_2112},
{"f_561:compiler_syntax_scm",(void*)f_561},
{"f_2013:compiler_syntax_scm",(void*)f_2013},
{"f_1630:compiler_syntax_scm",(void*)f_1630},
{"f_1634:compiler_syntax_scm",(void*)f_1634},
{"f_1637:compiler_syntax_scm",(void*)f_1637},
{"f_1640:compiler_syntax_scm",(void*)f_1640},
{"f_1643:compiler_syntax_scm",(void*)f_1643},
{"f_1646:compiler_syntax_scm",(void*)f_1646},
{"f_1649:compiler_syntax_scm",(void*)f_1649},
{"f_1652:compiler_syntax_scm",(void*)f_1652},
{"f_1655:compiler_syntax_scm",(void*)f_1655},
{"f_1658:compiler_syntax_scm",(void*)f_1658},
{"f_1661:compiler_syntax_scm",(void*)f_1661},
{"f_1664:compiler_syntax_scm",(void*)f_1664},
{"f_1667:compiler_syntax_scm",(void*)f_1667},
{"f_1670:compiler_syntax_scm",(void*)f_1670},
{"f_2001:compiler_syntax_scm",(void*)f_2001},
{"f_1993:compiler_syntax_scm",(void*)f_1993},
{"f_1973:compiler_syntax_scm",(void*)f_1973},
{"f_1679:compiler_syntax_scm",(void*)f_1679},
{"f_1957:compiler_syntax_scm",(void*)f_1957},
{"f_1682:compiler_syntax_scm",(void*)f_1682},
{"f_1713:compiler_syntax_scm",(void*)f_1713},
{"f_1919:compiler_syntax_scm",(void*)f_1919},
{"f_1917:compiler_syntax_scm",(void*)f_1917},
{"f_1913:compiler_syntax_scm",(void*)f_1913},
{"f_1889:compiler_syntax_scm",(void*)f_1889},
{"f_1887:compiler_syntax_scm",(void*)f_1887},
{"f_1883:compiler_syntax_scm",(void*)f_1883},
{"f_1783:compiler_syntax_scm",(void*)f_1783},
{"f_1781:compiler_syntax_scm",(void*)f_1781},
{"f_1777:compiler_syntax_scm",(void*)f_1777},
{"f_564:compiler_syntax_scm",(void*)f_564},
{"f_1581:compiler_syntax_scm",(void*)f_1581},
{"f_1591:compiler_syntax_scm",(void*)f_1591},
{"f_1598:compiler_syntax_scm",(void*)f_1598},
{"f_1614:compiler_syntax_scm",(void*)f_1614},
{"f_567:compiler_syntax_scm",(void*)f_567},
{"f_1579:compiler_syntax_scm",(void*)f_1579},
{"f_1575:compiler_syntax_scm",(void*)f_1575},
{"f_1571:compiler_syntax_scm",(void*)f_1571},
{"f_1567:compiler_syntax_scm",(void*)f_1567},
{"f_1563:compiler_syntax_scm",(void*)f_1563},
{"f_1559:compiler_syntax_scm",(void*)f_1559},
{"f_1555:compiler_syntax_scm",(void*)f_1555},
{"f_1419:compiler_syntax_scm",(void*)f_1419},
{"f_1423:compiler_syntax_scm",(void*)f_1423},
{"f_1426:compiler_syntax_scm",(void*)f_1426},
{"f_1436:compiler_syntax_scm",(void*)f_1436},
{"f_1480:compiler_syntax_scm",(void*)f_1480},
{"f_1460:compiler_syntax_scm",(void*)f_1460},
{"f_570:compiler_syntax_scm",(void*)f_570},
{"f_1417:compiler_syntax_scm",(void*)f_1417},
{"f_1413:compiler_syntax_scm",(void*)f_1413},
{"f_1409:compiler_syntax_scm",(void*)f_1409},
{"f_1405:compiler_syntax_scm",(void*)f_1405},
{"f_1401:compiler_syntax_scm",(void*)f_1401},
{"f_1397:compiler_syntax_scm",(void*)f_1397},
{"f_1393:compiler_syntax_scm",(void*)f_1393},
{"f_1308:compiler_syntax_scm",(void*)f_1308},
{"f_1318:compiler_syntax_scm",(void*)f_1318},
{"f_573:compiler_syntax_scm",(void*)f_573},
{"f_1306:compiler_syntax_scm",(void*)f_1306},
{"f_1302:compiler_syntax_scm",(void*)f_1302},
{"f_1298:compiler_syntax_scm",(void*)f_1298},
{"f_1294:compiler_syntax_scm",(void*)f_1294},
{"f_1290:compiler_syntax_scm",(void*)f_1290},
{"f_1286:compiler_syntax_scm",(void*)f_1286},
{"f_1282:compiler_syntax_scm",(void*)f_1282},
{"f_1211:compiler_syntax_scm",(void*)f_1211},
{"f_1215:compiler_syntax_scm",(void*)f_1215},
{"f_576:compiler_syntax_scm",(void*)f_576},
{"f_578:compiler_syntax_scm",(void*)f_578},
{"f_584:compiler_syntax_scm",(void*)f_584},
{"f_1193:compiler_syntax_scm",(void*)f_1193},
{"f_1197:compiler_syntax_scm",(void*)f_1197},
{"f_1182:compiler_syntax_scm",(void*)f_1182},
{"f_1189:compiler_syntax_scm",(void*)f_1189},
{"f_606:compiler_syntax_scm",(void*)f_606},
{"f_609:compiler_syntax_scm",(void*)f_609},
{"f_649:compiler_syntax_scm",(void*)f_649},
{"f_652:compiler_syntax_scm",(void*)f_652},
{"f_655:compiler_syntax_scm",(void*)f_655},
{"f_658:compiler_syntax_scm",(void*)f_658},
{"f_661:compiler_syntax_scm",(void*)f_661},
{"f_664:compiler_syntax_scm",(void*)f_664},
{"f_667:compiler_syntax_scm",(void*)f_667},
{"f_761:compiler_syntax_scm",(void*)f_761},
{"f_822:compiler_syntax_scm",(void*)f_822},
{"f_1126:compiler_syntax_scm",(void*)f_1126},
{"f_1040:compiler_syntax_scm",(void*)f_1040},
{"f_1043:compiler_syntax_scm",(void*)f_1043},
{"f_1010:compiler_syntax_scm",(void*)f_1010},
{"f_973:compiler_syntax_scm",(void*)f_973},
{"f_936:compiler_syntax_scm",(void*)f_936},
{"f_899:compiler_syntax_scm",(void*)f_899},
{"f_874:compiler_syntax_scm",(void*)f_874},
{"f_849:compiler_syntax_scm",(void*)f_849},
{"f_828:compiler_syntax_scm",(void*)f_828},
{"f_771:compiler_syntax_scm",(void*)f_771},
{"f_774:compiler_syntax_scm",(void*)f_774},
{"f_793:compiler_syntax_scm",(void*)f_793},
{"f_789:compiler_syntax_scm",(void*)f_789},
{"f_698:compiler_syntax_scm",(void*)f_698},
{"f_741:compiler_syntax_scm",(void*)f_741},
{"f_712:compiler_syntax_scm",(void*)f_712},
{"f_751:compiler_syntax_scm",(void*)f_751},
{"f_679:compiler_syntax_scm",(void*)f_679},
{"f_669:compiler_syntax_scm",(void*)f_669},
{"f_614:compiler_syntax_scm",(void*)f_614},
{"f_618:compiler_syntax_scm",(void*)f_618},
{"f_634:compiler_syntax_scm",(void*)f_634},
{"f_637:compiler_syntax_scm",(void*)f_637},
{"f_640:compiler_syntax_scm",(void*)f_640},
{"f_631:compiler_syntax_scm",(void*)f_631},
{"f_621:compiler_syntax_scm",(void*)f_621},
{"f_493:compiler_syntax_scm",(void*)f_493},
{"f_497:compiler_syntax_scm",(void*)f_497},
{"f_539:compiler_syntax_scm",(void*)f_539},
{"f_509:compiler_syntax_scm",(void*)f_509},
{"f_522:compiler_syntax_scm",(void*)f_522},
{"f_479:compiler_syntax_scm",(void*)f_479},
{"f_483:compiler_syntax_scm",(void*)f_483},
{"f_487:compiler_syntax_scm",(void*)f_487},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
