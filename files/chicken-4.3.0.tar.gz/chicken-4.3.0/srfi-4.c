/* Generated from srfi-4.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-12-14 09:02
   Version 4.2.0 - SVN rev. 16023
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-12-14 on galinha (Linux)
   command line: srfi-4.scm -optimize-level 2 -include-path . -include-path ./ -inline -explicit-use -no-trace -output-file srfi-4.c
   unit: srfi_4
*/

#include "chicken.h"

#define C_u8peek(b, i)         C_fix(((unsigned char *)C_data_pointer(b))[ C_unfix(i) ])
#define C_s8peek(b, i)         C_fix(((char *)C_data_pointer(b))[ C_unfix(i) ])
#define C_u16peek(b, i)        C_fix(((unsigned short *)C_data_pointer(b))[ C_unfix(i) ])
#define C_s16peek(b, i)        C_fix(((short *)C_data_pointer(b))[ C_unfix(i) ])
#ifdef C_SIXTY_FOUR
# define C_a_u32peek(ptr, d, b, i) C_fix(((C_u32 *)C_data_pointer(b))[ C_unfix(i) ])
# define C_a_s32peek(ptr, d, b, i) C_fix(((C_s32 *)C_data_pointer(b))[ C_unfix(i) ])
#else
# define C_a_u32peek(ptr, d, b, i) C_unsigned_int_to_num(ptr, ((C_u32 *)C_data_pointer(b))[ C_unfix(i) ])
# define C_a_s32peek(ptr, d, b, i) C_int_to_num(ptr, ((C_s32 *)C_data_pointer(b))[ C_unfix(i) ])
#endif
#define C_f32peek(b, i)        (C_temporary_flonum = ((float *)C_data_pointer(b))[ C_unfix(i) ], C_SCHEME_UNDEFINED)
#define C_f64peek(b, i)        (C_temporary_flonum = ((double *)C_data_pointer(b))[ C_unfix(i) ], C_SCHEME_UNDEFINED)
#define C_u8poke(b, i, x)      ((((unsigned char *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_s8poke(b, i, x)      ((((char *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_u16poke(b, i, x)     ((((unsigned short *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_s16poke(b, i, x)     ((((short *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_u32poke(b, i, x)     ((((C_u32 *)C_data_pointer(b))[ C_unfix(i) ] = C_num_to_unsigned_int(x)), C_SCHEME_UNDEFINED)
#define C_s32poke(b, i, x)     ((((C_s32 *)C_data_pointer(b))[ C_unfix(i) ] = C_num_to_int(x)), C_SCHEME_UNDEFINED)
#define C_f32poke(b, i, x)     ((((float *)C_data_pointer(b))[ C_unfix(i) ] = C_flonum_magnitude(x)), C_SCHEME_UNDEFINED)
#define C_f64poke(b, i, x)     ((((double *)C_data_pointer(b))[ C_unfix(i) ] = C_flonum_magnitude(x)), C_SCHEME_UNDEFINED)
#define C_copy_subvector(to, from, start_to, start_from, bytes)   \
  (C_memcpy((C_char *)C_data_pointer(to) + C_unfix(start_to), (C_char *)C_data_pointer(from) + C_unfix(start_from), C_unfix(bytes)), \
    C_SCHEME_UNDEFINED)

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[176];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,49),40,35,35,115,121,115,35,99,104,101,99,107,45,101,120,97,99,116,45,105,110,116,101,114,118,97,108,32,110,57,32,102,114,111,109,49,48,32,116,111,49,49,32,108,111,99,49,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,52),40,35,35,115,121,115,35,99,104,101,99,107,45,105,110,101,120,97,99,116,45,105,110,116,101,114,118,97,108,32,110,49,57,32,102,114,111,109,50,48,32,116,111,50,49,32,108,111,99,50,50,41,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,28),40,35,35,115,121,115,35,117,56,118,101,99,116,111,114,45,114,101,102,32,118,51,48,32,105,51,49,41,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,28),40,35,35,115,121,115,35,115,56,118,101,99,116,111,114,45,114,101,102,32,118,51,51,32,105,51,52,41,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,117,49,54,118,101,99,116,111,114,45,114,101,102,32,118,51,54,32,105,51,55,41,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,115,49,54,118,101,99,116,111,114,45,114,101,102,32,118,51,57,32,105,52,48,41,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,117,51,50,118,101,99,116,111,114,45,114,101,102,32,118,52,50,32,105,52,51,41,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,115,51,50,118,101,99,116,111,114,45,114,101,102,32,118,52,53,32,105,52,54,41,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,102,51,50,118,101,99,116,111,114,45,114,101,102,32,118,52,56,32,105,52,57,41,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,102,54,52,118,101,99,116,111,114,45,114,101,102,32,118,53,50,32,105,53,51,41,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,33),40,35,35,115,121,115,35,117,56,118,101,99,116,111,114,45,115,101,116,33,32,118,53,54,32,105,53,55,32,120,53,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,33),40,35,35,115,121,115,35,115,56,118,101,99,116,111,114,45,115,101,116,33,32,118,54,48,32,105,54,49,32,120,54,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,34),40,35,35,115,121,115,35,117,49,54,118,101,99,116,111,114,45,115,101,116,33,32,118,54,52,32,105,54,53,32,120,54,54,41,0,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,34),40,35,35,115,121,115,35,115,49,54,118,101,99,116,111,114,45,115,101,116,33,32,118,54,56,32,105,54,57,32,120,55,48,41,0,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,34),40,35,35,115,121,115,35,117,51,50,118,101,99,116,111,114,45,115,101,116,33,32,118,55,50,32,105,55,51,32,120,55,52,41,0,0,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,34),40,35,35,115,121,115,35,115,51,50,118,101,99,116,111,114,45,115,101,116,33,32,118,55,54,32,105,55,55,32,120,55,56,41,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,34),40,35,35,115,121,115,35,102,51,50,118,101,99,116,111,114,45,115,101,116,33,32,118,56,48,32,105,56,49,32,120,56,50,41,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,34),40,35,35,115,121,115,35,102,54,52,118,101,99,116,111,114,45,115,101,116,33,32,118,56,52,32,105,56,53,32,120,56,54,41,0,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,12),40,102,95,49,50,49,48,32,118,57,49,41,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,25),40,108,101,110,32,116,97,103,56,56,32,115,104,105,102,116,56,57,32,108,111,99,57,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,18),40,102,95,49,50,53,51,32,118,49,49,49,32,105,49,49,50,41,0,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,29),40,103,101,116,32,108,101,110,103,116,104,49,48,56,32,97,99,99,49,48,57,32,108,111,99,49,49,48,41,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,23),40,102,95,49,50,54,55,32,118,49,49,56,32,105,49,49,57,32,120,49,50,48,41,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,29),40,115,101,116,32,108,101,110,103,116,104,49,49,53,32,117,112,100,49,49,54,32,108,111,99,49,49,55,41,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,23),40,102,95,49,50,56,52,32,118,49,50,55,32,105,49,50,56,32,120,49,50,57,41,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,30),40,115,101,116,117,32,108,101,110,103,116,104,49,50,52,32,117,112,100,49,50,53,32,108,111,99,49,50,54,41,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,23),40,102,95,49,51,55,51,32,118,49,54,49,32,105,49,54,50,32,120,49,54,51,41,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,30),40,115,101,116,102,32,108,101,110,103,116,104,49,53,56,32,117,112,100,49,53,57,32,108,111,99,49,54,48,41,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,23),40,102,95,49,51,51,55,32,118,49,52,54,32,105,49,52,55,32,120,49,52,56,41,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,23),40,102,95,49,51,49,48,32,118,49,51,55,32,105,49,51,56,32,120,49,51,57,41,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,18),40,101,120,116,45,102,114,101,101,32,97,49,57,53,49,57,56,41,0,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,29),40,97,108,108,111,99,32,108,111,99,50,48,49,32,108,101,110,50,48,50,32,101,120,116,63,50,48,51,41,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,28),40,114,101,108,101,97,115,101,45,110,117,109,98,101,114,45,118,101,99,116,111,114,32,118,50,49,50,41,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,50,52,55,41,0,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,33),40,98,111,100,121,50,50,57,32,105,110,105,116,50,51,57,32,101,120,116,63,50,52,48,32,102,105,110,63,50,52,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,37),40,100,101,102,45,102,105,110,63,50,51,51,32,37,105,110,105,116,50,50,54,50,53,56,32,37,101,120,116,63,50,50,55,50,53,57,41,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,50,51,50,32,37,105,110,105,116,50,50,54,50,54,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,50,51,49,41,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,34),40,109,97,107,101,45,117,56,118,101,99,116,111,114,32,108,101,110,50,50,49,32,46,32,116,109,112,50,50,48,50,50,50,41,0,0,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,51,48,50,41,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,50,56,52,32,105,110,105,116,50,57,52,32,101,120,116,63,50,57,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,102,105,110,50,56,56,32,37,105,110,105,116,50,56,49,51,49,51,32,37,101,120,116,63,50,56,50,51,49,52,41,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,50,56,55,32,37,105,110,105,116,50,56,49,51,49,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,50,56,54,41,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,34),40,109,97,107,101,45,115,56,118,101,99,116,111,114,32,108,101,110,50,55,54,32,46,32,116,109,112,50,55,53,50,55,55,41,0,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,51,53,54,41,0,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,51,51,56,32,105,110,105,116,51,52,56,32,101,120,116,63,51,52,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,102,105,110,51,52,50,32,37,105,110,105,116,51,51,53,51,54,55,32,37,101,120,116,63,51,51,54,51,54,56,41,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,51,52,49,32,37,105,110,105,116,51,51,53,51,55,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,51,52,48,41,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,35),40,109,97,107,101,45,117,49,54,118,101,99,116,111,114,32,108,101,110,51,51,48,32,46,32,116,109,112,51,50,57,51,51,49,41,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,52,49,48,41,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,51,57,50,32,105,110,105,116,52,48,50,32,101,120,116,63,52,48,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,102,105,110,51,57,54,32,37,105,110,105,116,51,56,57,52,50,49,32,37,101,120,116,63,51,57,48,52,50,50,41,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,51,57,53,32,37,105,110,105,116,51,56,57,52,50,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,51,57,52,41,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,35),40,109,97,107,101,45,115,49,54,118,101,99,116,111,114,32,108,101,110,51,56,52,32,46,32,116,109,112,51,56,51,51,56,53,41,0,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,52,54,52,41,0,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,52,52,54,32,105,110,105,116,52,53,54,32,101,120,116,63,52,53,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,102,105,110,52,53,48,32,37,105,110,105,116,52,52,51,52,55,53,32,37,101,120,116,63,52,52,52,52,55,54,41,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,52,52,57,32,37,105,110,105,116,52,52,51,52,55,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,52,52,56,41,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,35),40,109,97,107,101,45,117,51,50,118,101,99,116,111,114,32,108,101,110,52,51,56,32,46,32,116,109,112,52,51,55,52,51,57,41,0,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,53,49,56,41,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,53,48,48,32,105,110,105,116,53,49,48,32,101,120,116,63,53,49,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,102,105,110,53,48,52,32,37,105,110,105,116,52,57,55,53,50,57,32,37,101,120,116,63,52,57,56,53,51,48,41,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,53,48,51,32,37,105,110,105,116,52,57,55,53,51,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,53,48,50,41,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,35),40,109,97,107,101,45,115,51,50,118,101,99,116,111,114,32,108,101,110,52,57,50,32,46,32,116,109,112,52,57,49,52,57,51,41,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,53,55,52,41,0,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,53,53,52,32,105,110,105,116,53,54,52,32,101,120,116,63,53,54,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,102,105,110,53,53,56,32,37,105,110,105,116,53,53,49,53,56,54,32,37,101,120,116,63,53,53,50,53,56,55,41,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,53,53,55,32,37,105,110,105,116,53,53,49,53,56,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,53,53,54,41,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,35),40,109,97,107,101,45,102,51,50,118,101,99,116,111,114,32,108,101,110,53,52,54,32,46,32,116,109,112,53,52,53,53,52,55,41,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,54,51,49,41,0,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,54,49,49,32,105,110,105,116,54,50,49,32,101,120,116,63,54,50,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,102,105,110,54,49,53,32,37,105,110,105,116,54,48,56,54,52,51,32,37,101,120,116,63,54,48,57,54,52,52,41,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,54,49,52,32,37,105,110,105,116,54,48,56,54,52,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,54,49,51,41,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,35),40,109,97,107,101,45,102,54,52,118,101,99,116,111,114,32,108,101,110,54,48,51,32,46,32,116,109,112,54,48,50,54,48,52,41,0,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,21),40,100,111,108,111,111,112,54,55,48,32,112,54,55,52,32,105,54,55,53,41,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,15),40,102,95,50,52,56,53,32,108,115,116,54,54,54,41,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,28),40,105,110,105,116,32,109,97,107,101,54,54,51,32,115,101,116,54,54,52,32,108,111,99,54,54,53,41,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,18),40,117,56,118,101,99,116,111,114,32,46,32,120,115,54,57,48,41,0,0,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,18),40,115,56,118,101,99,116,111,114,32,46,32,120,115,54,57,50,41,0,0,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,19),40,117,49,54,118,101,99,116,111,114,32,46,32,120,115,54,57,52,41,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,19),40,115,49,54,118,101,99,116,111,114,32,46,32,120,115,54,57,54,41,0,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,19),40,117,51,50,118,101,99,116,111,114,32,46,32,120,115,54,57,56,41,0,0,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,19),40,115,51,50,118,101,99,116,111,114,32,46,32,120,115,55,48,48,41,0,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,19),40,102,51,50,118,101,99,116,111,114,32,46,32,120,115,55,48,50,41,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,19),40,102,54,52,118,101,99,116,111,114,32,46,32,120,115,55,48,52,41,0,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,55,49,50,41,0,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,13),40,102,95,50,54,48,51,32,118,55,48,57,41,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,23),40,105,110,105,116,32,108,101,110,103,116,104,55,48,55,32,114,101,102,55,48,56,41,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,16),40,117,56,118,101,99,116,111,114,63,32,120,55,50,51,41};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,16),40,115,56,118,101,99,116,111,114,63,32,120,55,50,53,41};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,17),40,117,49,54,118,101,99,116,111,114,63,32,120,55,50,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,17),40,115,49,54,118,101,99,116,111,114,63,32,120,55,50,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,17),40,117,51,50,118,101,99,116,111,114,63,32,120,55,51,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,17),40,115,51,50,118,101,99,116,111,114,63,32,120,55,51,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,17),40,102,51,50,118,101,99,116,111,114,63,32,120,55,51,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,17),40,102,54,52,118,101,99,116,111,114,63,32,120,55,51,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,13),40,102,95,50,55,49,56,32,118,55,52,52,41,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,20),40,112,97,99,107,32,116,97,103,55,52,50,32,108,111,99,55,52,51,41,0,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,13),40,102,95,50,55,50,57,32,118,55,52,56,41,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,25),40,112,97,99,107,45,99,111,112,121,32,116,97,103,55,52,54,32,108,111,99,55,52,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,15),40,102,95,50,55,52,55,32,115,116,114,55,53,54,41,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,28),40,117,110,112,97,99,107,32,116,97,103,55,53,51,32,115,122,55,53,52,32,108,111,99,55,53,53,41,0,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,15),40,102,95,50,55,55,54,32,115,116,114,55,54,55,41,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,33),40,117,110,112,97,99,107,45,99,111,112,121,32,116,97,103,55,54,52,32,115,122,55,54,53,32,108,111,99,55,54,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,38),40,35,35,115,121,115,35,117,115,101,114,45,114,101,97,100,45,104,111,111,107,32,99,104,97,114,56,49,53,32,112,111,114,116,56,49,54,41,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,48),40,35,35,115,121,115,35,117,115,101,114,45,112,114,105,110,116,45,104,111,111,107,32,120,56,51,55,32,114,101,97,100,97,98,108,101,56,51,56,32,112,111,114,116,56,51,57,41};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,48),40,115,117,98,118,101,99,116,111,114,32,118,56,53,52,32,116,56,53,53,32,101,115,56,53,54,32,102,114,111,109,56,53,55,32,116,111,56,53,56,32,108,111,99,56,53,57,41};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,32),40,115,117,98,117,56,118,101,99,116,111,114,32,118,56,55,52,32,102,114,111,109,56,55,53,32,116,111,56,55,54,41};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,33),40,115,117,98,117,49,54,118,101,99,116,111,114,32,118,56,55,56,32,102,114,111,109,56,55,57,32,116,111,56,56,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,33),40,115,117,98,117,51,50,118,101,99,116,111,114,32,118,56,56,50,32,102,114,111,109,56,56,51,32,116,111,56,56,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,32),40,115,117,98,115,56,118,101,99,116,111,114,32,118,56,56,54,32,102,114,111,109,56,56,55,32,116,111,56,56,56,41};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,33),40,115,117,98,115,49,54,118,101,99,116,111,114,32,118,56,57,48,32,102,114,111,109,56,57,49,32,116,111,56,57,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,33),40,115,117,98,115,51,50,118,101,99,116,111,114,32,118,56,57,52,32,102,114,111,109,56,57,53,32,116,111,56,57,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,33),40,115,117,98,102,51,50,118,101,99,116,111,114,32,118,56,57,56,32,102,114,111,109,56,57,57,32,116,111,57,48,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,33),40,115,117,98,102,54,52,118,101,99,116,111,114,32,118,57,48,50,32,102,114,111,109,57,48,51,32,116,111,57,48,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,57,51,52,32,105,57,51,56,41};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,31),40,98,111,100,121,57,50,48,32,112,111,114,116,57,51,48,32,102,114,111,109,57,51,49,32,116,111,57,51,50,41,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,116,111,57,50,52,32,37,112,111,114,116,57,49,55,57,52,52,32,37,102,114,111,109,57,49,56,57,52,53,41,0,0,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,102,114,111,109,57,50,51,32,37,112,111,114,116,57,49,55,57,52,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,112,111,114,116,57,50,50,41,0,0,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,33),40,119,114,105,116,101,45,117,56,118,101,99,116,111,114,32,118,57,49,50,32,46,32,116,109,112,57,49,49,57,49,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,26),40,98,111,100,121,57,55,48,32,112,111,114,116,57,55,57,32,115,116,97,114,116,57,56,48,41,0,0,0,0,0,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,26),40,100,101,102,45,115,116,97,114,116,57,55,51,32,37,112,111,114,116,57,54,56,57,57,50,41,0,0,0,0,0,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,112,111,114,116,57,55,50,41,0,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,41),40,114,101,97,100,45,117,56,118,101,99,116,111,114,33,32,110,57,54,50,32,100,101,115,116,57,54,51,32,46,32,116,109,112,57,54,49,57,54,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,20),40,119,114,97,112,32,115,116,114,49,48,48,49,32,110,49,48,48,50,41,0,0,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,22),40,98,111,100,121,49,48,49,56,32,110,49,48,50,55,32,112,49,48,50,56,41,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,22),40,100,101,102,45,112,49,48,50,49,32,37,110,49,48,49,54,49,48,53,48,41,0,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,11),40,100,101,102,45,110,49,48,50,48,41,0,0,0,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,29),40,114,101,97,100,45,117,56,118,101,99,116,111,114,32,46,32,116,109,112,49,48,49,49,49,48,49,50,41,0,0,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from ext-free in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub196(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub196(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word bv=(C_word )(C_a0);
C_free((void *)C_block_item(bv, 1));
C_ret:
#undef return

return C_r;}

/* from k1461 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub191(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub191(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int bytes=(int )C_unfix(C_a0);
C_word *buf = (C_word *)C_malloc(bytes + sizeof(C_header));if(buf == NULL) return(C_SCHEME_FALSE);C_block_header(buf) = C_make_header(C_BYTEVECTOR_TYPE, bytes);return(buf);
C_ret:
#undef return

return C_r;}

C_noret_decl(C_srfi_4_toplevel)
C_externexport void C_ccall C_srfi_4_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1221)
static void C_ccall f_1221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1225)
static void C_ccall f_1225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1229)
static void C_ccall f_1229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1233)
static void C_ccall f_1233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1237)
static void C_ccall f_1237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1241)
static void C_ccall f_1241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1245)
static void C_ccall f_1245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1249)
static void C_ccall f_1249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1397)
static void C_ccall f_1397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1401)
static void C_ccall f_1401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1405)
static void C_ccall f_1405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1409)
static void C_ccall f_1409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1421)
static void C_ccall f_1421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1425)
static void C_ccall f_1425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3620)
static void C_ccall f_3620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1429)
static void C_ccall f_1429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3616)
static void C_ccall f_3616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1433)
static void C_ccall f_1433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3612)
static void C_ccall f_3612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1437)
static void C_ccall f_1437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3608)
static void C_ccall f_3608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1441)
static void C_ccall f_1441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3604)
static void C_ccall f_3604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1445)
static void C_ccall f_1445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3600)
static void C_ccall f_3600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1449)
static void C_ccall f_1449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3596)
static void C_ccall f_3596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1453)
static void C_ccall f_1453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3592)
static void C_ccall f_3592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1457)
static void C_ccall f_1457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2523)
static void C_ccall f_2523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2527)
static void C_ccall f_2527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2531)
static void C_ccall f_2531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2535)
static void C_ccall f_2535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2539)
static void C_ccall f_2539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2543)
static void C_ccall f_2543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2547)
static void C_ccall f_2547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2551)
static void C_ccall f_2551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2638)
static void C_ccall f_2638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2642)
static void C_ccall f_2642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2646)
static void C_ccall f_2646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2650)
static void C_ccall f_2650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2654)
static void C_ccall f_2654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2658)
static void C_ccall f_2658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2662)
static void C_ccall f_2662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2666)
static void C_ccall f_2666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2808)
static void C_ccall f_2808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2812)
static void C_ccall f_2812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2816)
static void C_ccall f_2816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2820)
static void C_ccall f_2820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2824)
static void C_ccall f_2824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2828)
static void C_ccall f_2828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2832)
static void C_ccall f_2832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2836)
static void C_ccall f_2836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2840)
static void C_ccall f_2840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2844)
static void C_ccall f_2844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2848)
static void C_ccall f_2848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2852)
static void C_ccall f_2852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2856)
static void C_ccall f_2856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2860)
static void C_ccall f_2860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2864)
static void C_ccall f_2864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2868)
static void C_ccall f_2868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2872)
static void C_ccall f_2872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2876)
static void C_ccall f_2876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2880)
static void C_ccall f_2880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2884)
static void C_ccall f_2884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2888)
static void C_ccall f_2888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2892)
static void C_ccall f_2892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2896)
static void C_ccall f_2896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2900)
static void C_ccall f_2900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2904)
static void C_ccall f_2904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2908)
static void C_ccall f_2908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2912)
static void C_ccall f_2912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2916)
static void C_ccall f_2916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2920)
static void C_ccall f_2920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2924)
static void C_ccall f_2924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2928)
static void C_ccall f_2928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2932)
static void C_ccall f_2932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3588)
static void C_ccall f_3588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3470)
static void C_ccall f_3470(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3470)
static void C_ccall f_3470r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3539)
static void C_fcall f_3539(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3534)
static void C_fcall f_3534(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3472)
static void C_fcall f_3472(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3476)
static void C_ccall f_3476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3503)
static void C_ccall f_3503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3508)
static void C_fcall f_3508(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3512)
static void C_ccall f_3512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3530)
static void C_ccall f_3530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3521)
static void C_ccall f_3521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3485)
static void C_ccall f_3485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3488)
static void C_ccall f_3488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3461)
static void C_fcall f_3461(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3469)
static void C_ccall f_3469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3360)
static void C_ccall f_3360(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3360)
static void C_ccall f_3360r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3412)
static void C_fcall f_3412(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3407)
static void C_fcall f_3407(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3362)
static void C_fcall f_3362(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3366)
static void C_ccall f_3366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3378)
static void C_fcall f_3378(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3244)
static void C_ccall f_3244(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3244)
static void C_ccall f_3244r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3297)
static void C_fcall f_3297(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3292)
static void C_fcall f_3292(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3283)
static void C_fcall f_3283(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3291)
static void C_ccall f_3291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3246)
static void C_fcall f_3246(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3253)
static void C_ccall f_3253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3261)
static void C_fcall f_3261(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3271)
static void C_ccall f_3271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3238)
static void C_ccall f_3238(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3232)
static void C_ccall f_3232(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3226)
static void C_ccall f_3226(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3220)
static void C_ccall f_3220(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3214)
static void C_ccall f_3214(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3208)
static void C_ccall f_3208(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3202)
static void C_ccall f_3202(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3196)
static void C_ccall f_3196(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3153)
static void C_fcall f_3153(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3166)
static void C_ccall f_3166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3169)
static void C_ccall f_3169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3175)
static void C_ccall f_3175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2993)
static void C_ccall f_2993(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3003)
static void C_ccall f_3003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3006)
static void C_ccall f_3006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3013)
static void C_ccall f_3013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2937)
static void C_ccall f_2937(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2947)
static void C_ccall f_2947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2972)
static void C_ccall f_2972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2774)
static void C_fcall f_2774(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2776)
static void C_ccall f_2776(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2786)
static void C_ccall f_2786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2745)
static void C_fcall f_2745(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2747)
static void C_ccall f_2747(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2727)
static void C_fcall f_2727(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2729)
static void C_ccall f_2729(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2739)
static void C_ccall f_2739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2716)
static void C_fcall f_2716(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2718)
static void C_ccall f_2718(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2710)
static void C_ccall f_2710(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2704)
static void C_ccall f_2704(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2698)
static void C_ccall f_2698(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2692)
static void C_ccall f_2692(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2686)
static void C_ccall f_2686(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2680)
static void C_ccall f_2680(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2674)
static void C_ccall f_2674(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2668)
static void C_ccall f_2668(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2601)
static void C_fcall f_2601(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2603)
static void C_ccall f_2603(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2607)
static void C_ccall f_2607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2612)
static void C_fcall f_2612(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2626)
static void C_ccall f_2626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2630)
static void C_ccall f_2630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2595)
static void C_ccall f_2595(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2595)
static void C_ccall f_2595r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2589)
static void C_ccall f_2589(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2589)
static void C_ccall f_2589r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2583)
static void C_ccall f_2583(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2583)
static void C_ccall f_2583r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2577)
static void C_ccall f_2577(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2577)
static void C_ccall f_2577r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2571)
static void C_ccall f_2571(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2571)
static void C_ccall f_2571r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2565)
static void C_ccall f_2565(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2565)
static void C_ccall f_2565r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2559)
static void C_ccall f_2559(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2559)
static void C_ccall f_2559r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2553)
static void C_ccall f_2553(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2553)
static void C_ccall f_2553r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2483)
static void C_fcall f_2483(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2485)
static void C_ccall f_2485(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2495)
static void C_ccall f_2495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2500)
static void C_fcall f_2500(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2507)
static void C_ccall f_2507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2356)
static void C_ccall f_2356(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2356)
static void C_ccall f_2356r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2420)
static void C_fcall f_2420(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2415)
static void C_fcall f_2415(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2410)
static void C_fcall f_2410(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2358)
static void C_fcall f_2358(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2409)
static void C_ccall f_2409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2368)
static void C_ccall f_2368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2399)
static void C_ccall f_2399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2380)
static void C_fcall f_2380(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2385)
static C_word C_fcall f_2385(C_word t0,C_word t1);
C_noret_decl(f_2229)
static void C_ccall f_2229(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2229)
static void C_ccall f_2229r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2293)
static void C_fcall f_2293(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2288)
static void C_fcall f_2288(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2283)
static void C_fcall f_2283(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2231)
static void C_fcall f_2231(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2282)
static void C_ccall f_2282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2241)
static void C_ccall f_2241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2272)
static void C_ccall f_2272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2253)
static void C_fcall f_2253(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2258)
static C_word C_fcall f_2258(C_word t0,C_word t1);
C_noret_decl(f_2109)
static void C_ccall f_2109(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2109)
static void C_ccall f_2109r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2166)
static void C_fcall f_2166(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2161)
static void C_fcall f_2161(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2156)
static void C_fcall f_2156(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2111)
static void C_fcall f_2111(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2155)
static void C_ccall f_2155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2121)
static void C_ccall f_2121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2135)
static C_word C_fcall f_2135(C_word t0,C_word t1);
C_noret_decl(f_1989)
static void C_ccall f_1989(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1989)
static void C_ccall f_1989r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2046)
static void C_fcall f_2046(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2041)
static void C_fcall f_2041(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2036)
static void C_fcall f_2036(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1991)
static void C_fcall f_1991(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2035)
static void C_ccall f_2035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2001)
static void C_ccall f_2001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2015)
static C_word C_fcall f_2015(C_word t0,C_word t1);
C_noret_decl(f_1869)
static void C_ccall f_1869(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1869)
static void C_ccall f_1869r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1926)
static void C_fcall f_1926(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1921)
static void C_fcall f_1921(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1916)
static void C_fcall f_1916(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1871)
static void C_fcall f_1871(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1915)
static void C_ccall f_1915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1881)
static void C_ccall f_1881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1890)
static void C_ccall f_1890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1895)
static C_word C_fcall f_1895(C_word t0,C_word t1);
C_noret_decl(f_1749)
static void C_ccall f_1749(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1749)
static void C_ccall f_1749r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1806)
static void C_fcall f_1806(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1801)
static void C_fcall f_1801(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1796)
static void C_fcall f_1796(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1751)
static void C_fcall f_1751(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1795)
static void C_ccall f_1795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1761)
static void C_ccall f_1761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1770)
static void C_ccall f_1770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1775)
static C_word C_fcall f_1775(C_word t0,C_word t1);
C_noret_decl(f_1629)
static void C_ccall f_1629(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1629)
static void C_ccall f_1629r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1686)
static void C_fcall f_1686(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1681)
static void C_fcall f_1681(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1676)
static void C_fcall f_1676(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1631)
static void C_fcall f_1631(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1675)
static void C_ccall f_1675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1641)
static void C_ccall f_1641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1650)
static void C_ccall f_1650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1655)
static C_word C_fcall f_1655(C_word t0,C_word t1);
C_noret_decl(f_1509)
static void C_ccall f_1509(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1509)
static void C_ccall f_1509r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1566)
static void C_fcall f_1566(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1561)
static void C_fcall f_1561(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1556)
static void C_fcall f_1556(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1511)
static void C_fcall f_1511(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1555)
static void C_ccall f_1555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1521)
static void C_ccall f_1521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1530)
static void C_ccall f_1530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1535)
static C_word C_fcall f_1535(C_word t0,C_word t1);
C_noret_decl(f_1484)
static void C_ccall f_1484(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1491)
static void C_fcall f_1491(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1466)
static void C_fcall f_1466(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1482)
static void C_ccall f_1482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1464)
static void C_ccall f_1464(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1310)
static void C_ccall f_1310(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1314)
static void C_ccall f_1314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1317)
static void C_ccall f_1317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1320)
static void C_ccall f_1320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1337)
static void C_ccall f_1337(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1341)
static void C_ccall f_1341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1344)
static void C_ccall f_1344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1347)
static void C_ccall f_1347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1371)
static void C_fcall f_1371(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1373)
static void C_ccall f_1373(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1377)
static void C_ccall f_1377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1383)
static void C_ccall f_1383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1390)
static void C_ccall f_1390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1282)
static void C_fcall f_1282(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1284)
static void C_ccall f_1284(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1288)
static void C_ccall f_1288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1294)
static void C_ccall f_1294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1297)
static void C_ccall f_1297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1265)
static void C_fcall f_1265(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1267)
static void C_ccall f_1267(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1271)
static void C_ccall f_1271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1277)
static void C_ccall f_1277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1251)
static void C_fcall f_1251(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1253)
static void C_ccall f_1253(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1257)
static void C_ccall f_1257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1260)
static void C_ccall f_1260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1208)
static void C_fcall f_1208(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1210)
static void C_ccall f_1210(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1205)
static void C_ccall f_1205(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1202)
static void C_ccall f_1202(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1199)
static void C_ccall f_1199(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1196)
static void C_ccall f_1196(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1193)
static void C_ccall f_1193(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1190)
static void C_ccall f_1190(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1187)
static void C_ccall f_1187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1184)
static void C_ccall f_1184(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1178)
static void C_ccall f_1178(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1172)
static void C_ccall f_1172(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1169)
static void C_ccall f_1169(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1166)
static void C_ccall f_1166(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1163)
static void C_ccall f_1163(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1160)
static void C_ccall f_1160(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1157)
static void C_ccall f_1157(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1154)
static void C_ccall f_1154(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1133)
static void C_ccall f_1133(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1118)
static void C_ccall f_1118(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;

C_noret_decl(trf_3539)
static void C_fcall trf_3539(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3539(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3539(t0,t1);}

C_noret_decl(trf_3534)
static void C_fcall trf_3534(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3534(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3534(t0,t1,t2);}

C_noret_decl(trf_3472)
static void C_fcall trf_3472(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3472(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3472(t0,t1,t2,t3);}

C_noret_decl(trf_3508)
static void C_fcall trf_3508(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3508(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3508(t0,t1);}

C_noret_decl(trf_3461)
static void C_fcall trf_3461(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3461(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3461(t0,t1,t2);}

C_noret_decl(trf_3412)
static void C_fcall trf_3412(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3412(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3412(t0,t1);}

C_noret_decl(trf_3407)
static void C_fcall trf_3407(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3407(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3407(t0,t1,t2);}

C_noret_decl(trf_3362)
static void C_fcall trf_3362(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3362(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3362(t0,t1,t2,t3);}

C_noret_decl(trf_3378)
static void C_fcall trf_3378(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3378(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3378(t0,t1);}

C_noret_decl(trf_3297)
static void C_fcall trf_3297(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3297(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3297(t0,t1);}

C_noret_decl(trf_3292)
static void C_fcall trf_3292(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3292(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3292(t0,t1,t2);}

C_noret_decl(trf_3283)
static void C_fcall trf_3283(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3283(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3283(t0,t1,t2,t3);}

C_noret_decl(trf_3246)
static void C_fcall trf_3246(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3246(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3246(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3261)
static void C_fcall trf_3261(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3261(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3261(t0,t1,t2);}

C_noret_decl(trf_3153)
static void C_fcall trf_3153(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3153(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3153(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2774)
static void C_fcall trf_2774(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2774(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2774(t0,t1,t2,t3);}

C_noret_decl(trf_2745)
static void C_fcall trf_2745(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2745(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2745(t0,t1,t2,t3);}

C_noret_decl(trf_2727)
static void C_fcall trf_2727(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2727(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2727(t0,t1,t2);}

C_noret_decl(trf_2716)
static void C_fcall trf_2716(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2716(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2716(t0,t1,t2);}

C_noret_decl(trf_2601)
static void C_fcall trf_2601(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2601(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2601(t0,t1,t2);}

C_noret_decl(trf_2612)
static void C_fcall trf_2612(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2612(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2612(t0,t1,t2);}

C_noret_decl(trf_2483)
static void C_fcall trf_2483(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2483(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2483(t0,t1,t2,t3);}

C_noret_decl(trf_2500)
static void C_fcall trf_2500(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2500(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2500(t0,t1,t2,t3);}

C_noret_decl(trf_2420)
static void C_fcall trf_2420(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2420(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2420(t0,t1);}

C_noret_decl(trf_2415)
static void C_fcall trf_2415(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2415(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2415(t0,t1,t2);}

C_noret_decl(trf_2410)
static void C_fcall trf_2410(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2410(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2410(t0,t1,t2,t3);}

C_noret_decl(trf_2358)
static void C_fcall trf_2358(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2358(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2358(t0,t1,t2,t3);}

C_noret_decl(trf_2380)
static void C_fcall trf_2380(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2380(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2380(t0,t1);}

C_noret_decl(trf_2293)
static void C_fcall trf_2293(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2293(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2293(t0,t1);}

C_noret_decl(trf_2288)
static void C_fcall trf_2288(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2288(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2288(t0,t1,t2);}

C_noret_decl(trf_2283)
static void C_fcall trf_2283(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2283(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2283(t0,t1,t2,t3);}

C_noret_decl(trf_2231)
static void C_fcall trf_2231(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2231(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2231(t0,t1,t2,t3);}

C_noret_decl(trf_2253)
static void C_fcall trf_2253(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2253(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2253(t0,t1);}

C_noret_decl(trf_2166)
static void C_fcall trf_2166(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2166(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2166(t0,t1);}

C_noret_decl(trf_2161)
static void C_fcall trf_2161(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2161(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2161(t0,t1,t2);}

C_noret_decl(trf_2156)
static void C_fcall trf_2156(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2156(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2156(t0,t1,t2,t3);}

C_noret_decl(trf_2111)
static void C_fcall trf_2111(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2111(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2111(t0,t1,t2,t3);}

C_noret_decl(trf_2046)
static void C_fcall trf_2046(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2046(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2046(t0,t1);}

C_noret_decl(trf_2041)
static void C_fcall trf_2041(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2041(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2041(t0,t1,t2);}

C_noret_decl(trf_2036)
static void C_fcall trf_2036(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2036(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2036(t0,t1,t2,t3);}

C_noret_decl(trf_1991)
static void C_fcall trf_1991(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1991(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1991(t0,t1,t2,t3);}

C_noret_decl(trf_1926)
static void C_fcall trf_1926(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1926(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1926(t0,t1);}

C_noret_decl(trf_1921)
static void C_fcall trf_1921(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1921(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1921(t0,t1,t2);}

C_noret_decl(trf_1916)
static void C_fcall trf_1916(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1916(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1916(t0,t1,t2,t3);}

C_noret_decl(trf_1871)
static void C_fcall trf_1871(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1871(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1871(t0,t1,t2,t3);}

C_noret_decl(trf_1806)
static void C_fcall trf_1806(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1806(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1806(t0,t1);}

C_noret_decl(trf_1801)
static void C_fcall trf_1801(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1801(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1801(t0,t1,t2);}

C_noret_decl(trf_1796)
static void C_fcall trf_1796(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1796(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1796(t0,t1,t2,t3);}

C_noret_decl(trf_1751)
static void C_fcall trf_1751(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1751(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1751(t0,t1,t2,t3);}

C_noret_decl(trf_1686)
static void C_fcall trf_1686(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1686(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1686(t0,t1);}

C_noret_decl(trf_1681)
static void C_fcall trf_1681(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1681(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1681(t0,t1,t2);}

C_noret_decl(trf_1676)
static void C_fcall trf_1676(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1676(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1676(t0,t1,t2,t3);}

C_noret_decl(trf_1631)
static void C_fcall trf_1631(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1631(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1631(t0,t1,t2,t3);}

C_noret_decl(trf_1566)
static void C_fcall trf_1566(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1566(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1566(t0,t1);}

C_noret_decl(trf_1561)
static void C_fcall trf_1561(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1561(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1561(t0,t1,t2);}

C_noret_decl(trf_1556)
static void C_fcall trf_1556(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1556(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1556(t0,t1,t2,t3);}

C_noret_decl(trf_1511)
static void C_fcall trf_1511(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1511(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1511(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1491)
static void C_fcall trf_1491(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1491(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1491(t0,t1);}

C_noret_decl(trf_1466)
static void C_fcall trf_1466(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1466(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1466(t0,t1,t2,t3);}

C_noret_decl(trf_1371)
static void C_fcall trf_1371(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1371(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1371(t0,t1,t2,t3);}

C_noret_decl(trf_1282)
static void C_fcall trf_1282(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1282(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1282(t0,t1,t2,t3);}

C_noret_decl(trf_1265)
static void C_fcall trf_1265(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1265(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1265(t0,t1,t2,t3);}

C_noret_decl(trf_1251)
static void C_fcall trf_1251(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1251(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1251(t0,t1,t2,t3);}

C_noret_decl(trf_1208)
static void C_fcall trf_1208(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1208(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1208(t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_4_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_4_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_4_toplevel"));
C_check_nursery_minimum(61);
if(!C_demand(61)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1554)){
C_save(t1);
C_rereclaim2(1554*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(61);
C_initialize_lf(lf,176);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],24,"\003syscheck-exact-interval");
lf[3]=C_h_intern(&lf[3],9,"\003syserror");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\000&numeric value is not in expected range");
lf[5]=C_h_intern(&lf[5],26,"\003syscheck-inexact-interval");
lf[6]=C_decode_literal(C_heaptop,"\376B\000\000&numeric value is not in expected range");
lf[14]=C_h_intern(&lf[14],15,"\003syscons-flonum");
lf[24]=C_h_intern(&lf[24],15,"u8vector-length");
lf[25]=C_h_intern(&lf[25],15,"s8vector-length");
lf[26]=C_h_intern(&lf[26],16,"u16vector-length");
lf[27]=C_h_intern(&lf[27],16,"s16vector-length");
lf[28]=C_h_intern(&lf[28],16,"u32vector-length");
lf[29]=C_h_intern(&lf[29],16,"s32vector-length");
lf[30]=C_h_intern(&lf[30],16,"f32vector-length");
lf[31]=C_h_intern(&lf[31],16,"f64vector-length");
lf[32]=C_h_intern(&lf[32],15,"\003syscheck-range");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\034argument may not be negative");
lf[34]=C_h_intern(&lf[34],13,"u8vector-set!");
lf[35]=C_h_intern(&lf[35],13,"s8vector-set!");
lf[36]=C_h_intern(&lf[36],14,"u16vector-set!");
lf[37]=C_h_intern(&lf[37],14,"s16vector-set!");
lf[38]=C_h_intern(&lf[38],14,"u32vector-set!");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\034argument may not be negative");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\036argument exceeds integer range");
lf[41]=C_h_intern(&lf[41],14,"s32vector-set!");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\036argument exceeds integer range");
lf[43]=C_h_intern(&lf[43],14,"f32vector-set!");
lf[44]=C_h_intern(&lf[44],14,"f64vector-set!");
lf[45]=C_h_intern(&lf[45],12,"u8vector-ref");
lf[46]=C_h_intern(&lf[46],12,"s8vector-ref");
lf[47]=C_h_intern(&lf[47],13,"u16vector-ref");
lf[48]=C_h_intern(&lf[48],13,"s16vector-ref");
lf[49]=C_h_intern(&lf[49],13,"u32vector-ref");
lf[50]=C_h_intern(&lf[50],13,"s32vector-ref");
lf[51]=C_h_intern(&lf[51],13,"f32vector-ref");
lf[52]=C_h_intern(&lf[52],13,"f64vector-ref");
lf[53]=C_h_intern(&lf[53],14,"set-finalizer!");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000:not enough memory - cannot allocate external number vector");
lf[55]=C_h_intern(&lf[55],19,"\003sysallocate-vector");
lf[56]=C_h_intern(&lf[56],21,"release-number-vector");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\047bad argument type - not a number vector");
lf[58]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000\002\376\001\000\000\010s8vector\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376"
"\001\000\000\011u32vector\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376\001\000\000\011f64vector\376\377\016");
lf[59]=C_h_intern(&lf[59],13,"make-u8vector");
lf[60]=C_h_intern(&lf[60],8,"u8vector");
lf[61]=C_h_intern(&lf[61],13,"make-s8vector");
lf[62]=C_h_intern(&lf[62],8,"s8vector");
lf[63]=C_h_intern(&lf[63],4,"fin\077");
lf[64]=C_h_intern(&lf[64],14,"make-u16vector");
lf[65]=C_h_intern(&lf[65],9,"u16vector");
lf[66]=C_h_intern(&lf[66],14,"make-s16vector");
lf[67]=C_h_intern(&lf[67],9,"s16vector");
lf[68]=C_h_intern(&lf[68],14,"make-u32vector");
lf[69]=C_h_intern(&lf[69],9,"u32vector");
lf[70]=C_h_intern(&lf[70],14,"make-s32vector");
lf[71]=C_h_intern(&lf[71],9,"s32vector");
lf[72]=C_h_intern(&lf[72],14,"make-f32vector");
lf[73]=C_h_intern(&lf[73],9,"f32vector");
lf[74]=C_h_intern(&lf[74],14,"make-f64vector");
lf[75]=C_h_intern(&lf[75],9,"f64vector");
lf[76]=C_h_intern(&lf[76],27,"\003syserror-not-a-proper-list");
lf[77]=C_h_intern(&lf[77],14,"list->u8vector");
lf[78]=C_h_intern(&lf[78],14,"list->s8vector");
lf[79]=C_h_intern(&lf[79],15,"list->u16vector");
lf[80]=C_h_intern(&lf[80],15,"list->s16vector");
lf[81]=C_h_intern(&lf[81],15,"list->u32vector");
lf[82]=C_h_intern(&lf[82],15,"list->s32vector");
lf[83]=C_h_intern(&lf[83],15,"list->f32vector");
lf[84]=C_h_intern(&lf[84],15,"list->f64vector");
lf[85]=C_h_intern(&lf[85],14,"u8vector->list");
lf[86]=C_h_intern(&lf[86],14,"s8vector->list");
lf[87]=C_h_intern(&lf[87],15,"u16vector->list");
lf[88]=C_h_intern(&lf[88],15,"s16vector->list");
lf[89]=C_h_intern(&lf[89],15,"u32vector->list");
lf[90]=C_h_intern(&lf[90],15,"s32vector->list");
lf[91]=C_h_intern(&lf[91],15,"f32vector->list");
lf[92]=C_h_intern(&lf[92],15,"f64vector->list");
lf[93]=C_h_intern(&lf[93],9,"u8vector\077");
lf[94]=C_h_intern(&lf[94],9,"s8vector\077");
lf[95]=C_h_intern(&lf[95],10,"u16vector\077");
lf[96]=C_h_intern(&lf[96],10,"s16vector\077");
lf[97]=C_h_intern(&lf[97],10,"u32vector\077");
lf[98]=C_h_intern(&lf[98],10,"s32vector\077");
lf[99]=C_h_intern(&lf[99],10,"f32vector\077");
lf[100]=C_h_intern(&lf[100],10,"f64vector\077");
lf[101]=C_h_intern(&lf[101],13,"\003sysmake-blob");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000+blob does not have correct size for packing");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000+blob does not have correct size for packing");
lf[104]=C_h_intern(&lf[104],21,"u8vector->blob/shared");
lf[105]=C_h_intern(&lf[105],21,"s8vector->blob/shared");
lf[106]=C_h_intern(&lf[106],22,"u16vector->blob/shared");
lf[107]=C_h_intern(&lf[107],22,"s16vector->blob/shared");
lf[108]=C_h_intern(&lf[108],22,"u32vector->blob/shared");
lf[109]=C_h_intern(&lf[109],22,"s32vector->blob/shared");
lf[110]=C_h_intern(&lf[110],22,"f32vector->blob/shared");
lf[111]=C_h_intern(&lf[111],22,"f64vector->blob/shared");
lf[112]=C_h_intern(&lf[112],14,"u8vector->blob");
lf[113]=C_h_intern(&lf[113],14,"s8vector->blob");
lf[114]=C_h_intern(&lf[114],15,"u16vector->blob");
lf[115]=C_h_intern(&lf[115],15,"s16vector->blob");
lf[116]=C_h_intern(&lf[116],15,"u32vector->blob");
lf[117]=C_h_intern(&lf[117],15,"s32vector->blob");
lf[118]=C_h_intern(&lf[118],15,"f32vector->blob");
lf[119]=C_h_intern(&lf[119],15,"f64vector->blob");
lf[120]=C_h_intern(&lf[120],21,"blob->u8vector/shared");
lf[121]=C_h_intern(&lf[121],21,"blob->s8vector/shared");
lf[122]=C_h_intern(&lf[122],22,"blob->u16vector/shared");
lf[123]=C_h_intern(&lf[123],22,"blob->s16vector/shared");
lf[124]=C_h_intern(&lf[124],22,"blob->u32vector/shared");
lf[125]=C_h_intern(&lf[125],22,"blob->s32vector/shared");
lf[126]=C_h_intern(&lf[126],22,"blob->f32vector/shared");
lf[127]=C_h_intern(&lf[127],22,"blob->f64vector/shared");
lf[128]=C_h_intern(&lf[128],14,"blob->u8vector");
lf[129]=C_h_intern(&lf[129],14,"blob->s8vector");
lf[130]=C_h_intern(&lf[130],15,"blob->u16vector");
lf[131]=C_h_intern(&lf[131],15,"blob->s16vector");
lf[132]=C_h_intern(&lf[132],15,"blob->u32vector");
lf[133]=C_h_intern(&lf[133],15,"blob->s32vector");
lf[134]=C_h_intern(&lf[134],15,"blob->f32vector");
lf[135]=C_h_intern(&lf[135],15,"blob->f64vector");
lf[136]=C_h_intern(&lf[136],18,"\003sysuser-read-hook");
lf[137]=C_h_intern(&lf[137],4,"read");
lf[138]=C_h_intern(&lf[138],2,"u8");
lf[139]=C_h_intern(&lf[139],2,"s8");
lf[140]=C_h_intern(&lf[140],3,"u16");
lf[141]=C_h_intern(&lf[141],3,"s16");
lf[142]=C_h_intern(&lf[142],3,"u32");
lf[143]=C_h_intern(&lf[143],3,"s32");
lf[144]=C_h_intern(&lf[144],3,"f32");
lf[145]=C_h_intern(&lf[145],3,"f64");
lf[146]=C_h_intern(&lf[146],1,"f");
lf[147]=C_h_intern(&lf[147],1,"F");
lf[148]=C_h_intern(&lf[148],14,"\003sysread-error");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal bytevector syntax");
lf[150]=C_h_intern(&lf[150],19,"\003sysuser-print-hook");
lf[151]=C_h_intern(&lf[151],9,"\003sysprint");
lf[153]=C_h_intern(&lf[153],11,"subu8vector");
lf[154]=C_h_intern(&lf[154],12,"subu16vector");
lf[155]=C_h_intern(&lf[155],12,"subu32vector");
lf[156]=C_h_intern(&lf[156],11,"subs8vector");
lf[157]=C_h_intern(&lf[157],12,"subs16vector");
lf[158]=C_h_intern(&lf[158],12,"subs32vector");
lf[159]=C_h_intern(&lf[159],12,"subf32vector");
lf[160]=C_h_intern(&lf[160],12,"subf64vector");
lf[161]=C_h_intern(&lf[161],14,"write-u8vector");
lf[162]=C_h_intern(&lf[162],16,"\003syswrite-char-0");
lf[163]=C_h_intern(&lf[163],14,"\003syscheck-port");
lf[164]=C_h_intern(&lf[164],19,"\003sysstandard-output");
lf[165]=C_h_intern(&lf[165],14,"read-u8vector!");
lf[166]=C_h_intern(&lf[166],16,"\003sysread-string!");
lf[167]=C_h_intern(&lf[167],18,"\003sysstandard-input");
lf[168]=C_h_intern(&lf[168],18,"open-output-string");
lf[169]=C_h_intern(&lf[169],17,"get-output-string");
lf[170]=C_h_intern(&lf[170],13,"read-u8vector");
lf[171]=C_h_intern(&lf[171],19,"\003syswrite-char/port");
lf[172]=C_h_intern(&lf[172],15,"\003sysread-char-0");
lf[173]=C_h_intern(&lf[173],17,"register-feature!");
lf[174]=C_h_intern(&lf[174],6,"srfi-4");
lf[175]=C_h_intern(&lf[175],18,"getter-with-setter");
C_register_lf2(lf,176,create_ptable());
t2=C_mutate(&lf[0] /* (set! c269 ...) */,lf[1]);
t3=C_mutate((C_word*)lf[2]+1 /* (set! check-exact-interval ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1118,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[5]+1 /* (set! check-inexact-interval ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1133,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[7] /* (set! u8vector-ref ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1154,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate(&lf[8] /* (set! s8vector-ref ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1157,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[9] /* (set! u16vector-ref ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1160,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate(&lf[10] /* (set! s16vector-ref ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1163,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate(&lf[11] /* (set! u32vector-ref ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1166,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate(&lf[12] /* (set! s32vector-ref ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1169,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[13] /* (set! f32vector-ref ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1172,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate(&lf[15] /* (set! f64vector-ref ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1178,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate(&lf[16] /* (set! u8vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1184,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate(&lf[17] /* (set! s8vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1187,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate(&lf[18] /* (set! u16vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1190,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate(&lf[19] /* (set! s16vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1193,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate(&lf[20] /* (set! u32vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1196,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate(&lf[21] /* (set! s32vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1199,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate(&lf[22] /* (set! f32vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1202,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate(&lf[23] /* (set! f64vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1205,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1208,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp);
t22=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1221,a[2]=t21,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 141  len */
f_1208(t22,lf[60],C_SCHEME_FALSE,lf[24]);}

/* k1219 */
static void C_ccall f_1221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1221,2,t0,t1);}
t2=C_mutate((C_word*)lf[24]+1 /* (set! u8vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1225,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 142  len */
f_1208(t3,lf[62],C_SCHEME_FALSE,lf[25]);}

/* k1223 in k1219 */
static void C_ccall f_1225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1225,2,t0,t1);}
t2=C_mutate((C_word*)lf[25]+1 /* (set! s8vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1229,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 143  len */
f_1208(t3,lf[65],C_fix(1),lf[26]);}

/* k1227 in k1223 in k1219 */
static void C_ccall f_1229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1229,2,t0,t1);}
t2=C_mutate((C_word*)lf[26]+1 /* (set! u16vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1233,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 144  len */
f_1208(t3,lf[67],C_fix(1),lf[27]);}

/* k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1233,2,t0,t1);}
t2=C_mutate((C_word*)lf[27]+1 /* (set! s16vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1237,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 145  len */
f_1208(t3,lf[69],C_fix(2),lf[28]);}

/* k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1237,2,t0,t1);}
t2=C_mutate((C_word*)lf[28]+1 /* (set! u32vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1241,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 146  len */
f_1208(t3,lf[71],C_fix(2),lf[29]);}

/* k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1241,2,t0,t1);}
t2=C_mutate((C_word*)lf[29]+1 /* (set! s32vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1245,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 147  len */
f_1208(t3,lf[73],C_fix(2),lf[30]);}

/* k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1245,2,t0,t1);}
t2=C_mutate((C_word*)lf[30]+1 /* (set! f32vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1249,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 148  len */
f_1208(t3,lf[75],C_fix(3),lf[31]);}

/* k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1249,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1 /* (set! f64vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1251,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1265,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1282,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1371,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1397,a[2]=t5,a[3]=t4,a[4]=t6,a[5]=t3,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 204  setu */
f_1282(t7,*((C_word*)lf[24]+1),lf[16],lf[34]);}

/* k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1397,2,t0,t1);}
t2=C_mutate((C_word*)lf[34]+1 /* (set! u8vector-set! ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1401,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 205  set */
f_1265(t3,*((C_word*)lf[25]+1),lf[17],lf[35]);}

/* k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1401,2,t0,t1);}
t2=C_mutate((C_word*)lf[35]+1 /* (set! s8vector-set! ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1405,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 206  setu */
f_1282(t3,*((C_word*)lf[26]+1),lf[18],lf[36]);}

/* k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1405,2,t0,t1);}
t2=C_mutate((C_word*)lf[36]+1 /* (set! u16vector-set! ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1409,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 207  set */
f_1265(t3,*((C_word*)lf[27]+1),lf[19],lf[37]);}

/* k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1409,2,t0,t1);}
t2=C_mutate((C_word*)lf[37]+1 /* (set! s16vector-set! ...) */,t1);
t3=*((C_word*)lf[28]+1);
t4=lf[20];
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1337,a[2]=t3,a[3]=((C_word)li28),tmp=(C_word)a,a+=4,tmp);
t6=C_mutate((C_word*)lf[38]+1 /* (set! u32vector-set! ...) */,t5);
t7=*((C_word*)lf[29]+1);
t8=lf[21];
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1310,a[2]=t7,a[3]=((C_word)li29),tmp=(C_word)a,a+=4,tmp);
t10=C_mutate((C_word*)lf[41]+1 /* (set! s32vector-set! ...) */,t9);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1421,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 210  setf */
f_1371(t11,*((C_word*)lf[30]+1),lf[22],lf[43]);}

/* k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1421,2,t0,t1);}
t2=C_mutate((C_word*)lf[43]+1 /* (set! f32vector-set! ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1425,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 211  setf */
f_1371(t3,*((C_word*)lf[31]+1),lf[23],lf[44]);}

/* k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1425,2,t0,t1);}
t2=C_mutate((C_word*)lf[44]+1 /* (set! f64vector-set! ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1429,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3620,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 214  get */
f_1251(t4,*((C_word*)lf[24]+1),lf[7],lf[45]);}

/* k3618 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 214  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[175]+1)))(4,*((C_word*)lf[175]+1),((C_word*)t0)[2],t1,*((C_word*)lf[34]+1));}

/* k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1429,2,t0,t1);}
t2=C_mutate((C_word*)lf[45]+1 /* (set! u8vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1433,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3616,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 217  get */
f_1251(t4,*((C_word*)lf[25]+1),lf[8],lf[46]);}

/* k3614 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 217  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[175]+1)))(4,*((C_word*)lf[175]+1),((C_word*)t0)[2],t1,*((C_word*)lf[35]+1));}

/* k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1433,2,t0,t1);}
t2=C_mutate((C_word*)lf[46]+1 /* (set! s8vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1437,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3612,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 220  get */
f_1251(t4,*((C_word*)lf[26]+1),lf[9],lf[47]);}

/* k3610 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 220  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[175]+1)))(4,*((C_word*)lf[175]+1),((C_word*)t0)[2],t1,*((C_word*)lf[36]+1));}

/* k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1437,2,t0,t1);}
t2=C_mutate((C_word*)lf[47]+1 /* (set! u16vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1441,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3608,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 223  get */
f_1251(t4,*((C_word*)lf[27]+1),lf[10],lf[48]);}

/* k3606 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 223  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[175]+1)))(4,*((C_word*)lf[175]+1),((C_word*)t0)[2],t1,*((C_word*)lf[37]+1));}

/* k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1441,2,t0,t1);}
t2=C_mutate((C_word*)lf[48]+1 /* (set! s16vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1445,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3604,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 227  get */
f_1251(t4,*((C_word*)lf[28]+1),lf[11],lf[49]);}

/* k3602 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 226  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[175]+1)))(4,*((C_word*)lf[175]+1),((C_word*)t0)[2],t1,*((C_word*)lf[38]+1));}

/* k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1445,2,t0,t1);}
t2=C_mutate((C_word*)lf[49]+1 /* (set! u32vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1449,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3600,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 231  get */
f_1251(t4,*((C_word*)lf[29]+1),lf[12],lf[50]);}

/* k3598 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 230  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[175]+1)))(4,*((C_word*)lf[175]+1),((C_word*)t0)[2],t1,*((C_word*)lf[41]+1));}

/* k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1449,2,t0,t1);}
t2=C_mutate((C_word*)lf[50]+1 /* (set! s32vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1453,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3596,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 235  get */
f_1251(t4,*((C_word*)lf[30]+1),lf[13],lf[51]);}

/* k3594 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 234  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[175]+1)))(4,*((C_word*)lf[175]+1),((C_word*)t0)[2],t1,*((C_word*)lf[43]+1));}

/* k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1453,2,t0,t1);}
t2=C_mutate((C_word*)lf[51]+1 /* (set! f32vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1457,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3592,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 239  get */
f_1251(t4,*((C_word*)lf[31]+1),lf[15],lf[52]);}

/* k3590 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 238  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[175]+1)))(4,*((C_word*)lf[175]+1),((C_word*)t0)[2],t1,*((C_word*)lf[44]+1));}

/* k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[64],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1457,2,t0,t1);}
t2=C_mutate((C_word*)lf[52]+1 /* (set! f64vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1464,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[53]+1);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1466,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp);
t6=C_mutate((C_word*)lf[56]+1 /* (set! release-number-vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1484,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[59]+1 /* (set! make-u8vector ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1509,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=((C_word)li38),tmp=(C_word)a,a+=6,tmp));
t8=C_mutate((C_word*)lf[61]+1 /* (set! make-s8vector ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1629,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=((C_word)li44),tmp=(C_word)a,a+=6,tmp));
t9=C_mutate((C_word*)lf[64]+1 /* (set! make-u16vector ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1749,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=((C_word)li50),tmp=(C_word)a,a+=6,tmp));
t10=C_mutate((C_word*)lf[66]+1 /* (set! make-s16vector ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1869,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=((C_word)li56),tmp=(C_word)a,a+=6,tmp));
t11=C_mutate((C_word*)lf[68]+1 /* (set! make-u32vector ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1989,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=((C_word)li62),tmp=(C_word)a,a+=6,tmp));
t12=C_mutate((C_word*)lf[70]+1 /* (set! make-s32vector ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2109,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=((C_word)li68),tmp=(C_word)a,a+=6,tmp));
t13=C_mutate((C_word*)lf[72]+1 /* (set! make-f32vector ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2229,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=((C_word)li74),tmp=(C_word)a,a+=6,tmp));
t14=C_mutate((C_word*)lf[74]+1 /* (set! make-f64vector ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2356,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=((C_word)li80),tmp=(C_word)a,a+=6,tmp));
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2483,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2523,a[2]=t15,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 398  init */
f_2483(t16,*((C_word*)lf[59]+1),*((C_word*)lf[34]+1),lf[77]);}

/* k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2523,2,t0,t1);}
t2=C_mutate((C_word*)lf[77]+1 /* (set! list->u8vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2527,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 399  init */
f_2483(t3,*((C_word*)lf[61]+1),*((C_word*)lf[35]+1),lf[78]);}

/* k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2527,2,t0,t1);}
t2=C_mutate((C_word*)lf[78]+1 /* (set! list->s8vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2531,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 400  init */
f_2483(t3,*((C_word*)lf[64]+1),*((C_word*)lf[36]+1),lf[79]);}

/* k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2531,2,t0,t1);}
t2=C_mutate((C_word*)lf[79]+1 /* (set! list->u16vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2535,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 401  init */
f_2483(t3,*((C_word*)lf[66]+1),*((C_word*)lf[37]+1),lf[80]);}

/* k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2535,2,t0,t1);}
t2=C_mutate((C_word*)lf[80]+1 /* (set! list->s16vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2539,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 402  init */
f_2483(t3,*((C_word*)lf[68]+1),*((C_word*)lf[38]+1),lf[81]);}

/* k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2539,2,t0,t1);}
t2=C_mutate((C_word*)lf[81]+1 /* (set! list->u32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2543,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 403  init */
f_2483(t3,*((C_word*)lf[70]+1),*((C_word*)lf[41]+1),lf[82]);}

/* k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2543,2,t0,t1);}
t2=C_mutate((C_word*)lf[82]+1 /* (set! list->s32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2547,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 404  init */
f_2483(t3,*((C_word*)lf[72]+1),*((C_word*)lf[43]+1),lf[83]);}

/* k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2547,2,t0,t1);}
t2=C_mutate((C_word*)lf[83]+1 /* (set! list->f32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2551,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 405  init */
f_2483(t3,*((C_word*)lf[74]+1),*((C_word*)lf[44]+1),lf[84]);}

/* k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2551,2,t0,t1);}
t2=C_mutate((C_word*)lf[84]+1 /* (set! list->f64vector ...) */,t1);
t3=*((C_word*)lf[77]+1);
t4=C_mutate((C_word*)lf[60]+1 /* (set! u8vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2553,a[2]=t3,a[3]=((C_word)li84),tmp=(C_word)a,a+=4,tmp));
t5=*((C_word*)lf[78]+1);
t6=C_mutate((C_word*)lf[62]+1 /* (set! s8vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2559,a[2]=t5,a[3]=((C_word)li85),tmp=(C_word)a,a+=4,tmp));
t7=*((C_word*)lf[79]+1);
t8=C_mutate((C_word*)lf[65]+1 /* (set! u16vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2565,a[2]=t7,a[3]=((C_word)li86),tmp=(C_word)a,a+=4,tmp));
t9=*((C_word*)lf[80]+1);
t10=C_mutate((C_word*)lf[67]+1 /* (set! s16vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2571,a[2]=t9,a[3]=((C_word)li87),tmp=(C_word)a,a+=4,tmp));
t11=*((C_word*)lf[81]+1);
t12=C_mutate((C_word*)lf[69]+1 /* (set! u32vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2577,a[2]=t11,a[3]=((C_word)li88),tmp=(C_word)a,a+=4,tmp));
t13=*((C_word*)lf[82]+1);
t14=C_mutate((C_word*)lf[71]+1 /* (set! s32vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2583,a[2]=t13,a[3]=((C_word)li89),tmp=(C_word)a,a+=4,tmp));
t15=*((C_word*)lf[83]+1);
t16=C_mutate((C_word*)lf[73]+1 /* (set! f32vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2589,a[2]=t15,a[3]=((C_word)li90),tmp=(C_word)a,a+=4,tmp));
t17=*((C_word*)lf[84]+1);
t18=C_mutate((C_word*)lf[75]+1 /* (set! f64vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2595,a[2]=t17,a[3]=((C_word)li91),tmp=(C_word)a,a+=4,tmp));
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2601,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2638,a[2]=t19,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 456  init */
f_2601(t20,*((C_word*)lf[24]+1),lf[7]);}

/* k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2638,2,t0,t1);}
t2=C_mutate((C_word*)lf[85]+1 /* (set! u8vector->list ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2642,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 457  init */
f_2601(t3,*((C_word*)lf[25]+1),lf[8]);}

/* k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2642,2,t0,t1);}
t2=C_mutate((C_word*)lf[86]+1 /* (set! s8vector->list ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2646,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 458  init */
f_2601(t3,*((C_word*)lf[26]+1),lf[9]);}

/* k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2646,2,t0,t1);}
t2=C_mutate((C_word*)lf[87]+1 /* (set! u16vector->list ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2650,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 459  init */
f_2601(t3,*((C_word*)lf[27]+1),lf[10]);}

/* k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2650,2,t0,t1);}
t2=C_mutate((C_word*)lf[88]+1 /* (set! s16vector->list ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2654,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 460  init */
f_2601(t3,*((C_word*)lf[28]+1),lf[11]);}

/* k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2654,2,t0,t1);}
t2=C_mutate((C_word*)lf[89]+1 /* (set! u32vector->list ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2658,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 461  init */
f_2601(t3,*((C_word*)lf[29]+1),lf[12]);}

/* k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2658,2,t0,t1);}
t2=C_mutate((C_word*)lf[90]+1 /* (set! s32vector->list ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2662,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 462  init */
f_2601(t3,*((C_word*)lf[30]+1),lf[13]);}

/* k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2662,2,t0,t1);}
t2=C_mutate((C_word*)lf[91]+1 /* (set! f32vector->list ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2666,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 463  init */
f_2601(t3,*((C_word*)lf[31]+1),lf[15]);}

/* k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2666,2,t0,t1);}
t2=C_mutate((C_word*)lf[92]+1 /* (set! f64vector->list ...) */,t1);
t3=C_mutate((C_word*)lf[93]+1 /* (set! u8vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2668,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[94]+1 /* (set! s8vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2674,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[95]+1 /* (set! u16vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2680,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[96]+1 /* (set! s16vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2686,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[97]+1 /* (set! u32vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2692,a[2]=((C_word)li99),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[98]+1 /* (set! s32vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2698,a[2]=((C_word)li100),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[99]+1 /* (set! f32vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2704,a[2]=((C_word)li101),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[100]+1 /* (set! f64vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2710,a[2]=((C_word)li102),tmp=(C_word)a,a+=3,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2716,a[2]=((C_word)li104),tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2727,a[2]=((C_word)li106),tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2745,a[2]=((C_word)li108),tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2774,a[2]=((C_word)li110),tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2808,a[2]=t11,a[3]=t12,a[4]=t13,a[5]=t14,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 515  pack */
f_2716(t15,lf[60],lf[104]);}

/* k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2808,2,t0,t1);}
t2=C_mutate((C_word*)lf[104]+1 /* (set! u8vector->blob/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2812,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 516  pack */
f_2716(t3,lf[62],lf[105]);}

/* k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2812,2,t0,t1);}
t2=C_mutate((C_word*)lf[105]+1 /* (set! s8vector->blob/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2816,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 517  pack */
f_2716(t3,lf[65],lf[106]);}

/* k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2816,2,t0,t1);}
t2=C_mutate((C_word*)lf[106]+1 /* (set! u16vector->blob/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2820,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 518  pack */
f_2716(t3,lf[67],lf[107]);}

/* k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2820,2,t0,t1);}
t2=C_mutate((C_word*)lf[107]+1 /* (set! s16vector->blob/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2824,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 519  pack */
f_2716(t3,lf[69],lf[108]);}

/* k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2824,2,t0,t1);}
t2=C_mutate((C_word*)lf[108]+1 /* (set! u32vector->blob/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2828,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 520  pack */
f_2716(t3,lf[71],lf[109]);}

/* k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2828,2,t0,t1);}
t2=C_mutate((C_word*)lf[109]+1 /* (set! s32vector->blob/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2832,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 521  pack */
f_2716(t3,lf[73],lf[110]);}

/* k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2832,2,t0,t1);}
t2=C_mutate((C_word*)lf[110]+1 /* (set! f32vector->blob/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2836,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 522  pack */
f_2716(t3,lf[75],lf[111]);}

/* k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2836,2,t0,t1);}
t2=C_mutate((C_word*)lf[111]+1 /* (set! f64vector->blob/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2840,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 524  pack-copy */
f_2727(t3,lf[60],lf[112]);}

/* k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2840,2,t0,t1);}
t2=C_mutate((C_word*)lf[112]+1 /* (set! u8vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2844,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 525  pack-copy */
f_2727(t3,lf[62],lf[113]);}

/* k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2844,2,t0,t1);}
t2=C_mutate((C_word*)lf[113]+1 /* (set! s8vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2848,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 526  pack-copy */
f_2727(t3,lf[65],lf[114]);}

/* k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2848,2,t0,t1);}
t2=C_mutate((C_word*)lf[114]+1 /* (set! u16vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2852,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 527  pack-copy */
f_2727(t3,lf[67],lf[115]);}

/* k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2852,2,t0,t1);}
t2=C_mutate((C_word*)lf[115]+1 /* (set! s16vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2856,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 528  pack-copy */
f_2727(t3,lf[69],lf[116]);}

/* k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2856,2,t0,t1);}
t2=C_mutate((C_word*)lf[116]+1 /* (set! u32vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2860,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 529  pack-copy */
f_2727(t3,lf[71],lf[117]);}

/* k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2860,2,t0,t1);}
t2=C_mutate((C_word*)lf[117]+1 /* (set! s32vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 530  pack-copy */
f_2727(t3,lf[73],lf[118]);}

/* k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2864,2,t0,t1);}
t2=C_mutate((C_word*)lf[118]+1 /* (set! f32vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2868,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 531  pack-copy */
f_2727(t3,lf[75],lf[119]);}

/* k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2868,2,t0,t1);}
t2=C_mutate((C_word*)lf[119]+1 /* (set! f64vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2872,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 533  unpack */
f_2745(t3,lf[60],C_SCHEME_TRUE,lf[120]);}

/* k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2872,2,t0,t1);}
t2=C_mutate((C_word*)lf[120]+1 /* (set! blob->u8vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2876,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 534  unpack */
f_2745(t3,lf[62],C_SCHEME_TRUE,lf[121]);}

/* k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2876,2,t0,t1);}
t2=C_mutate((C_word*)lf[121]+1 /* (set! blob->s8vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2880,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 535  unpack */
f_2745(t3,lf[65],C_fix(2),lf[122]);}

/* k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2880,2,t0,t1);}
t2=C_mutate((C_word*)lf[122]+1 /* (set! blob->u16vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2884,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 536  unpack */
f_2745(t3,lf[67],C_fix(2),lf[123]);}

/* k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2884,2,t0,t1);}
t2=C_mutate((C_word*)lf[123]+1 /* (set! blob->s16vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2888,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 537  unpack */
f_2745(t3,lf[69],C_fix(4),lf[124]);}

/* k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2888,2,t0,t1);}
t2=C_mutate((C_word*)lf[124]+1 /* (set! blob->u32vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2892,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 538  unpack */
f_2745(t3,lf[71],C_fix(4),lf[125]);}

/* k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2892,2,t0,t1);}
t2=C_mutate((C_word*)lf[125]+1 /* (set! blob->s32vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2896,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 539  unpack */
f_2745(t3,lf[73],C_fix(4),lf[126]);}

/* k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2896,2,t0,t1);}
t2=C_mutate((C_word*)lf[126]+1 /* (set! blob->f32vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2900,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 540  unpack */
f_2745(t3,lf[75],C_fix(8),lf[127]);}

/* k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2900,2,t0,t1);}
t2=C_mutate((C_word*)lf[127]+1 /* (set! blob->f64vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2904,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 542  unpack-copy */
f_2774(t3,lf[60],C_SCHEME_TRUE,lf[128]);}

/* k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2904,2,t0,t1);}
t2=C_mutate((C_word*)lf[128]+1 /* (set! blob->u8vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2908,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 543  unpack-copy */
f_2774(t3,lf[62],C_SCHEME_TRUE,lf[129]);}

/* k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2908,2,t0,t1);}
t2=C_mutate((C_word*)lf[129]+1 /* (set! blob->s8vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2912,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 544  unpack-copy */
f_2774(t3,lf[65],C_fix(2),lf[130]);}

/* k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2912,2,t0,t1);}
t2=C_mutate((C_word*)lf[130]+1 /* (set! blob->u16vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2916,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 545  unpack-copy */
f_2774(t3,lf[67],C_fix(2),lf[131]);}

/* k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2916,2,t0,t1);}
t2=C_mutate((C_word*)lf[131]+1 /* (set! blob->s16vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2920,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 546  unpack-copy */
f_2774(t3,lf[69],C_fix(4),lf[132]);}

/* k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2920,2,t0,t1);}
t2=C_mutate((C_word*)lf[132]+1 /* (set! blob->u32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2924,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 547  unpack-copy */
f_2774(t3,lf[71],C_fix(4),lf[133]);}

/* k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2924,2,t0,t1);}
t2=C_mutate((C_word*)lf[133]+1 /* (set! blob->s32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2928,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 548  unpack-copy */
f_2774(t3,lf[73],C_fix(4),lf[134]);}

/* k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2928,2,t0,t1);}
t2=C_mutate((C_word*)lf[134]+1 /* (set! blob->f32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2932,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 549  unpack-copy */
f_2774(t3,lf[75],C_fix(8),lf[135]);}

/* k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[103],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2932,2,t0,t1);}
t2=C_mutate((C_word*)lf[135]+1 /* (set! blob->f64vector ...) */,t1);
t3=*((C_word*)lf[136]+1);
t4=*((C_word*)lf[137]+1);
t5=(C_word)C_a_i_list(&a,16,lf[138],*((C_word*)lf[77]+1),lf[139],*((C_word*)lf[78]+1),lf[140],*((C_word*)lf[79]+1),lf[141],*((C_word*)lf[80]+1),lf[142],*((C_word*)lf[81]+1),lf[143],*((C_word*)lf[82]+1),lf[144],*((C_word*)lf[83]+1),lf[145],*((C_word*)lf[84]+1));
t6=C_mutate((C_word*)lf[136]+1 /* (set! user-read-hook ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2937,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=((C_word)li111),tmp=(C_word)a,a+=6,tmp));
t7=*((C_word*)lf[150]+1);
t8=C_mutate((C_word*)lf[150]+1 /* (set! user-print-hook ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2993,a[2]=t7,a[3]=((C_word)li112),tmp=(C_word)a,a+=4,tmp));
t9=C_mutate(&lf[152] /* (set! subvector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3153,a[2]=((C_word)li113),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[153]+1 /* (set! subu8vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3196,a[2]=((C_word)li114),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[154]+1 /* (set! subu16vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3202,a[2]=((C_word)li115),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[155]+1 /* (set! subu32vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3208,a[2]=((C_word)li116),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[156]+1 /* (set! subs8vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3214,a[2]=((C_word)li117),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[157]+1 /* (set! subs16vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3220,a[2]=((C_word)li118),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[158]+1 /* (set! subs32vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3226,a[2]=((C_word)li119),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[159]+1 /* (set! subf32vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3232,a[2]=((C_word)li120),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[160]+1 /* (set! subf64vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3238,a[2]=((C_word)li121),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[161]+1 /* (set! write-u8vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3244,a[2]=((C_word)li127),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[165]+1 /* (set! read-u8vector! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3360,a[2]=((C_word)li131),tmp=(C_word)a,a+=3,tmp));
t20=*((C_word*)lf[168]+1);
t21=*((C_word*)lf[169]+1);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3461,a[2]=((C_word)li132),tmp=(C_word)a,a+=3,tmp);
t23=C_mutate((C_word*)lf[170]+1 /* (set! read-u8vector ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3470,a[2]=t20,a[3]=t21,a[4]=t22,a[5]=((C_word)li137),tmp=(C_word)a,a+=6,tmp));
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3588,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 671  register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[173]+1)))(3,*((C_word*)lf[173]+1),t24,lf[174]);}

/* k3586 in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* read-u8vector in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3470(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr2r,(void*)f_3470r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3470r(t0,t1,t2);}}

static void C_ccall f_3470r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(14);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3472,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li134),tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3534,a[2]=t3,a[3]=((C_word)li135),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3539,a[2]=t4,a[3]=((C_word)li136),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-n10201051 */
t6=t5;
f_3539(t6,t1);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-p10211049 */
t8=t4;
f_3534(t8,t1,t6);}
else{
t8=(C_word)C_i_car(t7);
t9=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t9))){
/* body10181026 */
t10=t3;
f_3472(t10,t1,t6,t8);}
else{
/* ##sys#error */
t10=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,lf[0],t9);}}}}

/* def-n1020 in read-u8vector in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_3539(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3539,NULL,2,t0,t1);}
/* def-p10211049 */
t2=((C_word*)t0)[2];
f_3534(t2,t1,C_SCHEME_FALSE);}

/* def-p1021 in read-u8vector in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_3534(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3534,NULL,3,t0,t1,t2);}
/* body10181026 */
t3=((C_word*)t0)[2];
f_3472(t3,t1,t2,*((C_word*)lf[167]+1));}

/* body1018 in read-u8vector in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_3472(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3472,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3476,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 651  ##sys#check-port */
((C_proc4)C_retrieve_proc(*((C_word*)lf[163]+1)))(4,*((C_word*)lf[163]+1),t4,t3,lf[170]);}

/* k3474 in body1018 in read-u8vector in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3476,2,t0,t1);}
if(C_truep(((C_word*)t0)[7])){
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[7],lf[170]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3485,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 653  ##sys#allocate-vector */
t4=*((C_word*)lf[55]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[7],C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3503,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 660  open-output-string */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}}

/* k3501 in k3474 in body1018 in read-u8vector in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3503,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3508,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word)li133),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_3508(t5,((C_word*)t0)[2]);}

/* loop in k3501 in k3474 in body1018 in read-u8vector in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_3508(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3508,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3512,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 662  ##sys#read-char-0 */
((C_proc3)C_retrieve_proc(*((C_word*)lf[172]+1)))(3,*((C_word*)lf[172]+1),t2,((C_word*)t0)[2]);}

/* k3510 in loop in k3501 in k3474 in body1018 in read-u8vector in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3512,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3521,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 664  get-output-string */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3530,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 668  ##sys#write-char/port */
((C_proc4)C_retrieve_proc(*((C_word*)lf[171]+1)))(4,*((C_word*)lf[171]+1),t2,t1,((C_word*)t0)[3]);}}

/* k3528 in k3510 in loop in k3501 in k3474 in body1018 in read-u8vector in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 669  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3508(t2,((C_word*)t0)[2]);}

/* k3519 in k3510 in loop in k3501 in k3474 in body1018 in read-u8vector in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_block_size(t1);
/* srfi-4.scm: 666  wrap */
f_3461(((C_word*)t0)[2],t1,t2);}

/* k3483 in k3474 in body1018 in read-u8vector in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3485,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3488,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 654  ##sys#read-string! */
((C_proc6)C_retrieve_proc(*((C_word*)lf[166]+1)))(6,*((C_word*)lf[166]+1),t2,((C_word*)t0)[5],t1,((C_word*)t0)[2],C_fix(0));}

/* k3486 in k3483 in k3474 in body1018 in read-u8vector in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3488,2,t0,t1);}
t2=(C_word)C_string_to_bytevector(((C_word*)t0)[5]);
t3=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,2,lf[60],((C_word*)t0)[5]));}
else{
/* srfi-4.scm: 658  wrap */
f_3461(((C_word*)t0)[3],((C_word*)t0)[5],t1);}}

/* wrap in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_3461(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3461,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3469,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 646  ##sys#allocate-vector */
t5=*((C_word*)lf[55]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,t3,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k3467 in wrap in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3469,2,t0,t1);}
t2=(C_word)C_string_to_bytevector(t1);
t3=(C_word)C_substring_copy(((C_word*)t0)[4],t1,C_fix(0),((C_word*)t0)[3],C_fix(0));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,2,lf[60],t1));}

/* read-u8vector! in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3360(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr4r,(void*)f_3360r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3360r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3360r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(15);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3362,a[2]=t5,a[3]=t3,a[4]=((C_word)li128),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3407,a[2]=t6,a[3]=((C_word)li129),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3412,a[2]=t7,a[3]=((C_word)li130),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-port972993 */
t9=t8;
f_3412(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-start973991 */
t11=t7;
f_3407(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* body970978 */
t13=t6;
f_3362(t13,t1,t9,t11);}
else{
/* ##sys#error */
t13=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,lf[0],t12);}}}}

/* def-port972 in read-u8vector! in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_3412(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3412,NULL,2,t0,t1);}
/* def-start973991 */
t2=((C_word*)t0)[2];
f_3407(t2,t1,*((C_word*)lf[167]+1));}

/* def-start973 in read-u8vector! in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_3407(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3407,NULL,3,t0,t1,t2);}
/* body970978 */
t3=((C_word*)t0)[2];
f_3362(t3,t1,t2,C_fix(0));}

/* body970 in read-u8vector! in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_3362(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3362,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3366,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 630  ##sys#check-port */
((C_proc4)C_retrieve_proc(*((C_word*)lf[163]+1)))(4,*((C_word*)lf[163]+1),t4,t2,lf[165]);}

/* k3364 in body970 in read-u8vector! in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3366,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[165]);
t3=(C_word)C_i_check_structure_2(((C_word*)t0)[5],lf[60],lf[165]);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3378,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t6=(C_word)C_i_check_exact_2(((C_word*)((C_word*)t0)[3])[1],lf[165]);
t7=(C_word)C_fixnum_plus(((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1]);
t8=(C_word)C_block_size(t4);
if(C_truep((C_word)C_fixnum_greaterp(t7,t8))){
t9=(C_word)C_block_size(t4);
t10=(C_word)C_fixnum_difference(t9,((C_word*)t0)[6]);
t11=C_mutate(((C_word *)((C_word*)t0)[3])+1,t10);
t12=t5;
f_3378(t12,t11);}
else{
t9=t5;
f_3378(t9,C_SCHEME_UNDEFINED);}}
else{
t6=t5;
f_3378(t6,C_SCHEME_UNDEFINED);}}

/* k3376 in k3364 in body970 in read-u8vector! in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_3378(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 638  ##sys#read-string! */
((C_proc6)C_retrieve_proc(*((C_word*)lf[166]+1)))(6,*((C_word*)lf[166]+1),((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* write-u8vector in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3244(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_3244r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3244r(t0,t1,t2,t3);}}

static void C_ccall f_3244r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(17);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3246,a[2]=t2,a[3]=((C_word)li123),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3283,a[2]=t2,a[3]=t4,a[4]=((C_word)li124),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3292,a[2]=t5,a[3]=((C_word)li125),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3297,a[2]=t6,a[3]=((C_word)li126),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-port922948 */
t8=t7;
f_3297(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-from923946 */
t10=t6;
f_3292(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-to924943 */
t12=t5;
f_3283(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body920929 */
t14=t4;
f_3246(t14,t1,t8,t10,t12);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-port922 in write-u8vector in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_3297(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3297,NULL,2,t0,t1);}
/* def-from923946 */
t2=((C_word*)t0)[2];
f_3292(t2,t1,*((C_word*)lf[164]+1));}

/* def-from923 in write-u8vector in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_3292(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3292,NULL,3,t0,t1,t2);}
/* def-to924943 */
t3=((C_word*)t0)[2];
f_3283(t3,t1,t2,C_fix(0));}

/* def-to924 in write-u8vector in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_3283(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3283,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3291,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 621  u8vector-length */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k3289 in def-to924 in write-u8vector in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* body920929 */
t2=((C_word*)t0)[5];
f_3246(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* body920 in write-u8vector in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_3246(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3246,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(((C_word*)t0)[2],lf[60],lf[161]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3253,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=t4,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 623  ##sys#check-port */
((C_proc4)C_retrieve_proc(*((C_word*)lf[163]+1)))(4,*((C_word*)lf[163]+1),t6,t2,lf[161]);}

/* k3251 in body920 in write-u8vector in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3253,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3261,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t4,a[5]=((C_word*)t0)[5],a[6]=((C_word)li122),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_3261(t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* doloop934 in k3251 in body920 in write-u8vector in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_3261(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3261,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3271,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_make_character((C_word)C_unfix((C_word)C_u8peek(((C_word*)t0)[3],t2)));
/* srfi-4.scm: 627  ##sys#write-char-0 */
((C_proc4)C_retrieve_proc(*((C_word*)lf[162]+1)))(4,*((C_word*)lf[162]+1),t3,t4,((C_word*)t0)[2]);}}

/* k3269 in doloop934 in k3251 in body920 in write-u8vector in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3261(t3,((C_word*)t0)[2],t2);}

/* subf64vector in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3238(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3238,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 619  subvector */
f_3153(t1,t2,lf[75],C_fix(8),t3,t4,lf[160]);}

/* subf32vector in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3232(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3232,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 618  subvector */
f_3153(t1,t2,lf[73],C_fix(4),t3,t4,lf[159]);}

/* subs32vector in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3226(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3226,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 617  subvector */
f_3153(t1,t2,lf[71],C_fix(4),t3,t4,lf[158]);}

/* subs16vector in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3220(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3220,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 616  subvector */
f_3153(t1,t2,lf[67],C_fix(2),t3,t4,lf[157]);}

/* subs8vector in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3214(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3214,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 615  subvector */
f_3153(t1,t2,lf[62],C_fix(1),t3,t4,lf[156]);}

/* subu32vector in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3208(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3208,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 614  subvector */
f_3153(t1,t2,lf[69],C_fix(4),t3,t4,lf[155]);}

/* subu16vector in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3202(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3202,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 613  subvector */
f_3153(t1,t2,lf[65],C_fix(2),t3,t4,lf[154]);}

/* subu8vector in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3196(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3196,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 612  subvector */
f_3153(t1,t2,lf[60],C_fix(1),t3,t4,lf[153]);}

/* subvector in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_3153(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3153,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(C_word)C_i_check_structure_2(t2,t3,t7);
t9=(C_word)C_slot(t2,C_fix(1));
t10=(C_word)C_block_size(t9);
t11=(C_word)C_fixnum_divide(t10,t4);
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3166,a[2]=t7,a[3]=t11,a[4]=t1,a[5]=t9,a[6]=t3,a[7]=t4,a[8]=t5,a[9]=t6,tmp=(C_word)a,a+=10,tmp);
t13=(C_word)C_fixnum_plus(t11,C_fix(1));
/* srfi-4.scm: 603  ##sys#check-range */
t14=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t14+1)))(6,t14,t12,t5,C_fix(0),t13,t7);}

/* k3164 in subvector in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3166,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3169,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-4.scm: 604  ##sys#check-range */
t4=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,((C_word*)t0)[9],C_fix(0),t3,((C_word*)t0)[2]);}

/* k3167 in k3164 in subvector in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3169,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(C_word)C_fixnum_times(((C_word*)t0)[5],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3175,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 606  ##sys#allocate-vector */
t5=*((C_word*)lf[55]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,t3,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k3173 in k3167 in k3164 in subvector in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3175,2,t0,t1);}
t2=(C_word)C_string_to_bytevector(t1);
t3=(C_word)C_a_i_record(&a,2,((C_word*)t0)[7],t1);
t4=(C_word)C_fixnum_times(((C_word*)t0)[6],((C_word*)t0)[5]);
t5=(C_word)C_copy_subvector(t1,((C_word*)t0)[4],C_fix(0),t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}

/* ##sys#user-print-hook in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2993(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word ab[102],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2993,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[85]+1),C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[138],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[60],t6);
t8=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[86]+1),C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,lf[139],t8);
t10=(C_word)C_a_i_cons(&a,2,lf[62],t9);
t11=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[87]+1),C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,lf[140],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[65],t12);
t14=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[88]+1),C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,lf[141],t14);
t16=(C_word)C_a_i_cons(&a,2,lf[67],t15);
t17=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[89]+1),C_SCHEME_END_OF_LIST);
t18=(C_word)C_a_i_cons(&a,2,lf[142],t17);
t19=(C_word)C_a_i_cons(&a,2,lf[69],t18);
t20=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[90]+1),C_SCHEME_END_OF_LIST);
t21=(C_word)C_a_i_cons(&a,2,lf[143],t20);
t22=(C_word)C_a_i_cons(&a,2,lf[71],t21);
t23=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[91]+1),C_SCHEME_END_OF_LIST);
t24=(C_word)C_a_i_cons(&a,2,lf[144],t23);
t25=(C_word)C_a_i_cons(&a,2,lf[73],t24);
t26=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[92]+1),C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,lf[145],t26);
t28=(C_word)C_a_i_cons(&a,2,lf[75],t27);
t29=(C_word)C_a_i_cons(&a,2,t28,C_SCHEME_END_OF_LIST);
t30=(C_word)C_a_i_cons(&a,2,t25,t29);
t31=(C_word)C_a_i_cons(&a,2,t22,t30);
t32=(C_word)C_a_i_cons(&a,2,t19,t31);
t33=(C_word)C_a_i_cons(&a,2,t16,t32);
t34=(C_word)C_a_i_cons(&a,2,t13,t33);
t35=(C_word)C_a_i_cons(&a,2,t10,t34);
t36=(C_word)C_a_i_cons(&a,2,t7,t35);
t37=(C_word)C_i_assq((C_word)C_slot(t2,C_fix(0)),t36);
if(C_truep(t37)){
t38=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3003,a[2]=t2,a[3]=t37,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 590  ##sys#print */
t39=*((C_word*)lf[151]+1);
((C_proc5)(void*)(*((C_word*)t39+1)))(5,t39,t38,C_make_character(35),C_SCHEME_FALSE,t4);}
else{
/* srfi-4.scm: 593  old-hook */
t38=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t38))(5,t38,t1,t2,t3,t4);}}

/* k3001 in ##sys#user-print-hook in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3006,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* srfi-4.scm: 591  ##sys#print */
t4=*((C_word*)lf[151]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k3004 in k3001 in ##sys#user-print-hook in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3013,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[3]);
t4=t3;
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,((C_word*)t0)[2]);}

/* k3011 in k3004 in k3001 in ##sys#user-print-hook in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_3013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 592  ##sys#print */
t2=*((C_word*)lf[151]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2937(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2937,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_truep((C_word)C_eqp(t4,C_make_character(117)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(115)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(102)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(85)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(83)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(70)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2947,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 567  read */
t6=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}
else{
/* srfi-4.scm: 572  old-hook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k2945 in ##sys#user-read-hook in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2947,2,t0,t1);}
t2=(C_word)C_i_symbolp(t1);
t3=(C_truep(t2)?t1:C_SCHEME_FALSE);
t4=(C_word)C_eqp(t3,lf[146]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[147]));
if(C_truep(t5)){
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_memq(t3,((C_word*)t0)[4]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2972,a[2]=((C_word*)t0)[5],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 570  read */
t8=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[2]);}
else{
/* srfi-4.scm: 571  ##sys#read-error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[148]+1)))(5,*((C_word*)lf[148]+1),((C_word*)t0)[5],((C_word*)t0)[2],lf[149],t3);}}}

/* k2970 in k2945 in ##sys#user-read-hook in k2930 in k2926 in k2922 in k2918 in k2914 in k2910 in k2906 in k2902 in k2898 in k2894 in k2890 in k2886 in k2882 in k2878 in k2874 in k2870 in k2866 in k2862 in k2858 in k2854 in k2850 in k2846 in k2842 in k2838 in k2834 in k2830 in k2826 in k2822 in k2818 in k2814 in k2810 in k2806 in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_word)C_slot(t2,C_fix(0));
t4=t3;
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],t1);}

/* unpack-copy in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2774(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2774,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2776,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=((C_word)li109),tmp=(C_word)a,a+=6,tmp));}

/* f_2776 in unpack-copy in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2776(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2776,3,t0,t1,t2);}
t3=(C_word)C_i_check_bytevector_2(t2,((C_word*)t0)[4]);
t4=(C_word)C_block_size(t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2786,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=t4,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 507  ##sys#make-blob */
((C_proc3)C_retrieve_proc(*((C_word*)lf[101]+1)))(3,*((C_word*)lf[101]+1),t5,t4);}

/* k2784 */
static void C_ccall f_2786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2786,2,t0,t1);}
t2=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[7]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(C_fix(0),(C_word)C_fixnum_modulo(((C_word*)t0)[6],((C_word*)t0)[7])));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,2,((C_word*)t0)[4],(C_word)C_copy_block(((C_word*)t0)[3],t1)));}
else{
/* srfi-4.scm: 513  ##sys#error */
t4=*((C_word*)lf[3]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,((C_word*)t0)[5],((C_word*)t0)[2],lf[103],((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[7]);}}

/* unpack in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2745(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2745,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2747,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=((C_word)li107),tmp=(C_word)a,a+=6,tmp));}

/* f_2747 in unpack in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2747(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2747,3,t0,t1,t2);}
t3=(C_word)C_i_check_bytevector_2(t2,((C_word*)t0)[4]);
t4=(C_word)C_block_size(t2);
t5=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(C_fix(0),(C_word)C_fixnum_modulo(t4,((C_word*)t0)[3])));
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,2,((C_word*)t0)[2],t2));}
else{
/* srfi-4.scm: 501  ##sys#error */
t7=*((C_word*)lf[3]+1);
((C_proc7)(void*)(*((C_word*)t7+1)))(7,t7,t1,((C_word*)t0)[4],lf[102],((C_word*)t0)[2],t4,((C_word*)t0)[3]);}}

/* pack-copy in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2727(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2727,NULL,3,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2729,a[2]=t3,a[3]=t2,a[4]=((C_word)li105),tmp=(C_word)a,a+=5,tmp));}

/* f_2729 in pack-copy in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2729(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2729,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,((C_word*)t0)[3],((C_word*)t0)[2]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2739,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_block_size(t4);
/* srfi-4.scm: 491  ##sys#make-blob */
((C_proc3)C_retrieve_proc(*((C_word*)lf[101]+1)))(3,*((C_word*)lf[101]+1),t5,t6);}

/* k2737 */
static void C_ccall f_2739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_copy_block(((C_word*)t0)[2],t1));}

/* pack in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2716(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2716,NULL,3,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2718,a[2]=t3,a[3]=t2,a[4]=((C_word)li103),tmp=(C_word)a,a+=5,tmp));}

/* f_2718 in pack in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2718(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2718,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,((C_word*)t0)[3],((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* f64vector? in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2710(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2710,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[75]));}

/* f32vector? in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2704(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2704,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[73]));}

/* s32vector? in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2698(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2698,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[71]));}

/* u32vector? in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2692(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2692,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[69]));}

/* s16vector? in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2686(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2686,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[67]));}

/* u16vector? in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2680(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2680,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[65]));}

/* s8vector? in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2674(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2674,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[62]));}

/* u8vector? in k2664 in k2660 in k2656 in k2652 in k2648 in k2644 in k2640 in k2636 in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2668(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2668,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[60]));}

/* init in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2601(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2601,NULL,3,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2603,a[2]=t2,a[3]=t3,a[4]=((C_word)li93),tmp=(C_word)a,a+=5,tmp));}

/* f_2603 in init in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2603(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2603,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2607,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 449  length */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2605 */
static void C_ccall f_2607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2607,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2612,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word)li92),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2612(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k2605 */
static void C_fcall f_2612(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2612,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2626,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 453  ref */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],t2);}}

/* k2624 in loop in k2605 */
static void C_ccall f_2626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2626,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2630,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-4.scm: 454  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2612(t4,t2,t3);}

/* k2628 in k2624 in loop in k2605 */
static void C_ccall f_2630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2630,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* f64vector in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2595(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2595r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2595r(t0,t1,t2);}}

static void C_ccall f_2595r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 440  list->f64vector */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* f32vector in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2589(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2589r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2589r(t0,t1,t2);}}

static void C_ccall f_2589r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 436  list->f32vector */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* s32vector in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2583(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2583r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2583r(t0,t1,t2);}}

static void C_ccall f_2583r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 432  list->s32vector */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* u32vector in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2577(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2577r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2577r(t0,t1,t2);}}

static void C_ccall f_2577r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 428  list->u32vector */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* s16vector in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2571(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2571r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2571r(t0,t1,t2);}}

static void C_ccall f_2571r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 424  list->s16vector */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* u16vector in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2565(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2565r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2565r(t0,t1,t2);}}

static void C_ccall f_2565r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 420  list->u16vector */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* s8vector in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2559(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2559r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2559r(t0,t1,t2);}}

static void C_ccall f_2559r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 416  list->s8vector */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* u8vector in k2549 in k2545 in k2541 in k2537 in k2533 in k2529 in k2525 in k2521 in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2553(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2553r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2553r(t0,t1,t2);}}

static void C_ccall f_2553r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 412  list->u8vector */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* init in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2483(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2483,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2485,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=((C_word)li82),tmp=(C_word)a,a+=6,tmp));}

/* f_2485 in init in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2485(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2485,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,((C_word*)t0)[4]);
t4=(C_word)C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2495,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 390  make */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}

/* k2493 */
static void C_ccall f_2495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2495,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2500,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word)li81),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2500(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* doloop670 in k2493 */
static void C_fcall f_2500(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2500,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2507,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(C_truep((C_word)C_blockp(t2))?(C_word)C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t5)){
/* srfi-4.scm: 395  set */
t6=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,((C_word*)t0)[5],t3,(C_word)C_slot(t2,C_fix(0)));}
else{
/* srfi-4.scm: 396  ##sys#error-not-a-proper-list */
t6=*((C_word*)lf[76]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[2]);}}}

/* k2505 in doloop670 in k2493 */
static void C_ccall f_2507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[5])[1];
f_2500(t2,((C_word*)t0)[4],(C_word)C_slot(((C_word*)t0)[3],C_fix(1)),(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-f64vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2356(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_2356r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2356r(t0,t1,t2,t3);}}

static void C_ccall f_2356r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2358,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li76),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2410,a[2]=t4,a[3]=((C_word)li77),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2415,a[2]=t5,a[3]=((C_word)li78),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2420,a[2]=t6,a[3]=((C_word)li79),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init613647 */
t8=t7;
f_2420(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?614645 */
t10=t6;
f_2415(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin615642 */
t12=t5;
f_2410(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body611620 */
t14=t4;
f_2358(t14,t1,t8,t10);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init613 in make-f64vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2420(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2420,NULL,2,t0,t1);}
/* def-ext?614645 */
t2=((C_word*)t0)[2];
f_2415(t2,t1,C_SCHEME_FALSE);}

/* def-ext?614 in make-f64vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2415(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2415,NULL,3,t0,t1,t2);}
/* def-fin615642 */
t3=((C_word*)t0)[2];
f_2410(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin615 in make-f64vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2410(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2410,NULL,4,t0,t1,t2,t3);}
/* body611620 */
t4=((C_word*)t0)[2];
f_2358(t4,t1,t2,t3);}

/* body611 in make-f64vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2358(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2358,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[74]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2409,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 369  alloc */
f_1466(t6,lf[74],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(3)),t3);}

/* k2407 in body611 in make-f64vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2409,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[75],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2368,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[63]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 370  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_2368(2,t5,C_SCHEME_UNDEFINED);}}

/* k2366 in k2407 in body611 in make-f64vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2368,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[5])[1];
if(C_truep(t2)){
t3=(C_word)C_i_check_number_2(((C_word*)((C_word*)t0)[5])[1],lf[74]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2380,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(((C_word*)((C_word*)t0)[5])[1]))){
t5=t4;
f_2380(t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2399,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 376  exact->inexact */
C_exact_to_inexact(3,0,t5,((C_word*)((C_word*)t0)[5])[1]);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k2397 in k2366 in k2407 in body611 in make-f64vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2380(t3,t2);}

/* k2378 in k2366 in k2407 in body611 in make-f64vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2380(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2380,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2385,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li75),tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2385(t2,C_fix(0)));}

/* doloop631 in k2378 in k2366 in k2407 in body611 in make-f64vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static C_word C_fcall f_2385(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=t1;
t3=((C_word*)((C_word*)t0)[2])[1];
t4=(C_word)C_f64poke((C_word)C_slot(((C_word*)t0)[3],C_fix(1)),t2,t3);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t6;
goto loop;}}

/* make-f32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2229(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_2229r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2229r(t0,t1,t2,t3);}}

static void C_ccall f_2229r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2231,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li70),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2283,a[2]=t4,a[3]=((C_word)li71),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2288,a[2]=t5,a[3]=((C_word)li72),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2293,a[2]=t6,a[3]=((C_word)li73),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init556590 */
t8=t7;
f_2293(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?557588 */
t10=t6;
f_2288(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin558585 */
t12=t5;
f_2283(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body554563 */
t14=t4;
f_2231(t14,t1,t8,t10);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init556 in make-f32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2293(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2293,NULL,2,t0,t1);}
/* def-ext?557588 */
t2=((C_word*)t0)[2];
f_2288(t2,t1,C_SCHEME_FALSE);}

/* def-ext?557 in make-f32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2288(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2288,NULL,3,t0,t1,t2);}
/* def-fin558585 */
t3=((C_word*)t0)[2];
f_2283(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin558 in make-f32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2283(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2283,NULL,4,t0,t1,t2,t3);}
/* body554563 */
t4=((C_word*)t0)[2];
f_2231(t4,t1,t2,t3);}

/* body554 in make-f32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2231(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2231,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[72]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2282,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 354  alloc */
f_1466(t6,lf[72],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(2)),t3);}

/* k2280 in body554 in make-f32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2282,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[73],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2241,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[63]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 355  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_2241(2,t5,C_SCHEME_UNDEFINED);}}

/* k2239 in k2280 in body554 in make-f32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2241,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[5])[1];
if(C_truep(t2)){
t3=(C_word)C_i_check_number_2(((C_word*)((C_word*)t0)[5])[1],lf[72]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2253,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(((C_word*)((C_word*)t0)[5])[1]))){
t5=t4;
f_2253(t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2272,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 361  exact->inexact */
C_exact_to_inexact(3,0,t5,((C_word*)((C_word*)t0)[5])[1]);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k2270 in k2239 in k2280 in body554 in make-f32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2253(t3,t2);}

/* k2251 in k2239 in k2280 in body554 in make-f32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2253(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2253,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2258,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li69),tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2258(t2,C_fix(0)));}

/* doloop574 in k2251 in k2239 in k2280 in body554 in make-f32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static C_word C_fcall f_2258(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=t1;
t3=((C_word*)((C_word*)t0)[2])[1];
t4=(C_word)C_f32poke((C_word)C_slot(((C_word*)t0)[3],C_fix(1)),t2,t3);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t6;
goto loop;}}

/* make-s32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2109(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_2109r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2109r(t0,t1,t2,t3);}}

static void C_ccall f_2109r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2111,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li64),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2156,a[2]=t4,a[3]=((C_word)li65),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2161,a[2]=t5,a[3]=((C_word)li66),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2166,a[2]=t6,a[3]=((C_word)li67),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init502533 */
t8=t7;
f_2166(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?503531 */
t10=t6;
f_2161(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin504528 */
t12=t5;
f_2156(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body500509 */
t14=t4;
f_2111(t14,t1,t8,t10);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init502 in make-s32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2166(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2166,NULL,2,t0,t1);}
/* def-ext?503531 */
t2=((C_word*)t0)[2];
f_2161(t2,t1,C_SCHEME_FALSE);}

/* def-ext?503 in make-s32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2161(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2161,NULL,3,t0,t1,t2);}
/* def-fin504528 */
t3=((C_word*)t0)[2];
f_2156(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin504 in make-s32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2156(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2156,NULL,4,t0,t1,t2,t3);}
/* body500509 */
t4=((C_word*)t0)[2];
f_2111(t4,t1,t2,t3);}

/* body500 in make-s32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2111(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2111,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[70]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2155,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 341  alloc */
f_1466(t5,lf[70],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(2)),t3);}

/* k2153 in body500 in make-s32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2155,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[71],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2121,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[63]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 342  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_2121(2,t5,C_SCHEME_UNDEFINED);}}

/* k2119 in k2153 in body500 in make-s32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2121,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[70]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2135,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li63),tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_2135(t4,C_fix(0)));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* doloop518 in k2119 in k2153 in body500 in make-s32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static C_word C_fcall f_2135(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=t1;
t3=((C_word*)t0)[2];
t4=(C_word)C_s32poke((C_word)C_slot(((C_word*)t0)[3],C_fix(1)),t2,t3);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t6;
goto loop;}}

/* make-u32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1989(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_1989r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1989r(t0,t1,t2,t3);}}

static void C_ccall f_1989r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li58),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2036,a[2]=t4,a[3]=((C_word)li59),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2041,a[2]=t5,a[3]=((C_word)li60),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2046,a[2]=t6,a[3]=((C_word)li61),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init448479 */
t8=t7;
f_2046(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?449477 */
t10=t6;
f_2041(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin450474 */
t12=t5;
f_2036(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body446455 */
t14=t4;
f_1991(t14,t1,t8,t10);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init448 in make-u32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2046(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2046,NULL,2,t0,t1);}
/* def-ext?449477 */
t2=((C_word*)t0)[2];
f_2041(t2,t1,C_SCHEME_FALSE);}

/* def-ext?449 in make-u32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2041(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2041,NULL,3,t0,t1,t2);}
/* def-fin450474 */
t3=((C_word*)t0)[2];
f_2036(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin450 in make-u32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_2036(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2036,NULL,4,t0,t1,t2,t3);}
/* body446455 */
t4=((C_word*)t0)[2];
f_1991(t4,t1,t2,t3);}

/* body446 in make-u32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1991(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1991,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[68]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2035,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 328  alloc */
f_1466(t5,lf[68],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(2)),t3);}

/* k2033 in body446 in make-u32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2035,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[69],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2001,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[63]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 329  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_2001(2,t5,C_SCHEME_UNDEFINED);}}

/* k1999 in k2033 in body446 in make-u32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_2001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2001,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[68]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2015,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li57),tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_2015(t4,C_fix(0)));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* doloop464 in k1999 in k2033 in body446 in make-u32vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static C_word C_fcall f_2015(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=t1;
t3=((C_word*)t0)[2];
t4=(C_word)C_u32poke((C_word)C_slot(((C_word*)t0)[3],C_fix(1)),t2,t3);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t6;
goto loop;}}

/* make-s16vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1869(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_1869r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1869r(t0,t1,t2,t3);}}

static void C_ccall f_1869r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1871,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li52),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1916,a[2]=t4,a[3]=((C_word)li53),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1921,a[2]=t5,a[3]=((C_word)li54),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1926,a[2]=t6,a[3]=((C_word)li55),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init394425 */
t8=t7;
f_1926(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?395423 */
t10=t6;
f_1921(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin396420 */
t12=t5;
f_1916(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body392401 */
t14=t4;
f_1871(t14,t1,t8,t10);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init394 in make-s16vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1926(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1926,NULL,2,t0,t1);}
/* def-ext?395423 */
t2=((C_word*)t0)[2];
f_1921(t2,t1,C_SCHEME_FALSE);}

/* def-ext?395 in make-s16vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1921(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1921,NULL,3,t0,t1,t2);}
/* def-fin396420 */
t3=((C_word*)t0)[2];
f_1916(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin396 in make-s16vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1916(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1916,NULL,4,t0,t1,t2,t3);}
/* body392401 */
t4=((C_word*)t0)[2];
f_1871(t4,t1,t2,t3);}

/* body392 in make-s16vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1871(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1871,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[66]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1915,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 315  alloc */
f_1466(t5,lf[66],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(1)),t3);}

/* k1913 in body392 in make-s16vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1915,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[67],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1881,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[63]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 316  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1881(2,t5,C_SCHEME_UNDEFINED);}}

/* k1879 in k1913 in body392 in make-s16vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1881,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1890,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 320  ##sys#check-exact-interval */
t4=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(-32768),C_fix(32767),lf[66]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1888 in k1879 in k1913 in body392 in make-s16vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1895,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li51),tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1895(t2,C_fix(0)));}

/* doloop410 in k1888 in k1879 in k1913 in body392 in make-s16vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static C_word C_fcall f_1895(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=t1;
t3=((C_word*)t0)[2];
t4=(C_word)C_s16poke((C_word)C_slot(((C_word*)t0)[3],C_fix(1)),t2,t3);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t6;
goto loop;}}

/* make-u16vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1749(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_1749r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1749r(t0,t1,t2,t3);}}

static void C_ccall f_1749r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1751,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li46),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1796,a[2]=t4,a[3]=((C_word)li47),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1801,a[2]=t5,a[3]=((C_word)li48),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1806,a[2]=t6,a[3]=((C_word)li49),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init340371 */
t8=t7;
f_1806(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?341369 */
t10=t6;
f_1801(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin342366 */
t12=t5;
f_1796(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body338347 */
t14=t4;
f_1751(t14,t1,t8,t10);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init340 in make-u16vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1806(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1806,NULL,2,t0,t1);}
/* def-ext?341369 */
t2=((C_word*)t0)[2];
f_1801(t2,t1,C_SCHEME_FALSE);}

/* def-ext?341 in make-u16vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1801(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1801,NULL,3,t0,t1,t2);}
/* def-fin342366 */
t3=((C_word*)t0)[2];
f_1796(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin342 in make-u16vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1796(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1796,NULL,4,t0,t1,t2,t3);}
/* body338347 */
t4=((C_word*)t0)[2];
f_1751(t4,t1,t2,t3);}

/* body338 in make-u16vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1751(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1751,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[64]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1795,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 302  alloc */
f_1466(t5,lf[64],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(1)),t3);}

/* k1793 in body338 in make-u16vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1795,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[65],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1761,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[63]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 303  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1761(2,t5,C_SCHEME_UNDEFINED);}}

/* k1759 in k1793 in body338 in make-u16vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1761,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1770,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 307  ##sys#check-exact-interval */
t4=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(0),C_fix(65535),lf[64]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1768 in k1759 in k1793 in body338 in make-u16vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1770,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1775,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li45),tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1775(t2,C_fix(0)));}

/* doloop356 in k1768 in k1759 in k1793 in body338 in make-u16vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static C_word C_fcall f_1775(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=t1;
t3=((C_word*)t0)[2];
t4=(C_word)C_u16poke((C_word)C_slot(((C_word*)t0)[3],C_fix(1)),t2,t3);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t6;
goto loop;}}

/* make-s8vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1629(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_1629r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1629r(t0,t1,t2,t3);}}

static void C_ccall f_1629r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1631,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li40),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1676,a[2]=t4,a[3]=((C_word)li41),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1681,a[2]=t5,a[3]=((C_word)li42),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1686,a[2]=t6,a[3]=((C_word)li43),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init286317 */
t8=t7;
f_1686(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?287315 */
t10=t6;
f_1681(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin288312 */
t12=t5;
f_1676(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body284293 */
t14=t4;
f_1631(t14,t1,t8,t10);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init286 in make-s8vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1686(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1686,NULL,2,t0,t1);}
/* def-ext?287315 */
t2=((C_word*)t0)[2];
f_1681(t2,t1,C_SCHEME_FALSE);}

/* def-ext?287 in make-s8vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1681(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1681,NULL,3,t0,t1,t2);}
/* def-fin288312 */
t3=((C_word*)t0)[2];
f_1676(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin288 in make-s8vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1676(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1676,NULL,4,t0,t1,t2,t3);}
/* body284293 */
t4=((C_word*)t0)[2];
f_1631(t4,t1,t2,t3);}

/* body284 in make-s8vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1631(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1631,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[61]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1675,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 289  alloc */
f_1466(t5,lf[61],((C_word*)t0)[5],t3);}

/* k1673 in body284 in make-s8vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1675,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[62],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1641,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[63]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 290  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1641(2,t5,C_SCHEME_UNDEFINED);}}

/* k1639 in k1673 in body284 in make-s8vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1641,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1650,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 294  ##sys#check-exact-interval */
t4=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(-128),C_fix(127),lf[61]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1648 in k1639 in k1673 in body284 in make-s8vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1650,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1655,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li39),tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1655(t2,C_fix(0)));}

/* doloop302 in k1648 in k1639 in k1673 in body284 in make-s8vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static C_word C_fcall f_1655(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=t1;
t3=((C_word*)t0)[2];
t4=(C_word)C_s8poke((C_word)C_slot(((C_word*)t0)[3],C_fix(1)),t2,t3);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t6;
goto loop;}}

/* make-u8vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1509(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_1509r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1509r(t0,t1,t2,t3);}}

static void C_ccall f_1509r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1511,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li34),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1556,a[2]=t4,a[3]=((C_word)li35),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1561,a[2]=t5,a[3]=((C_word)li36),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1566,a[2]=t6,a[3]=((C_word)li37),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init231262 */
t8=t7;
f_1566(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?232260 */
t10=t6;
f_1561(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin?233257 */
t12=t5;
f_1556(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body229238 */
t14=t4;
f_1511(t14,t1,t8,t10,t12);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init231 in make-u8vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1566(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1566,NULL,2,t0,t1);}
/* def-ext?232260 */
t2=((C_word*)t0)[2];
f_1561(t2,t1,C_SCHEME_FALSE);}

/* def-ext?232 in make-u8vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1561(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1561,NULL,3,t0,t1,t2);}
/* def-fin?233257 */
t3=((C_word*)t0)[2];
f_1556(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin?233 in make-u8vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1556(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1556,NULL,4,t0,t1,t2,t3);}
/* body229238 */
t4=((C_word*)t0)[2];
f_1511(t4,t1,t2,t3,C_SCHEME_TRUE);}

/* body229 in make-u8vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1511(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1511,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[59]);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1555,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* srfi-4.scm: 276  alloc */
f_1466(t6,lf[59],((C_word*)t0)[5],t3);}

/* k1553 in body229 in make-u8vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1555,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[60],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1521,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[4]:C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 277  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1521(2,t5,C_SCHEME_UNDEFINED);}}

/* k1519 in k1553 in body229 in make-u8vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1521,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1530,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 281  ##sys#check-exact-interval */
t4=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(0),C_fix(255),lf[59]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1528 in k1519 in k1553 in body229 in make-u8vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1535,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li33),tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1535(t2,C_fix(0)));}

/* doloop247 in k1528 in k1519 in k1553 in body229 in make-u8vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static C_word C_fcall f_1535(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=t1;
t3=((C_word*)t0)[2];
t4=(C_word)C_u8poke((C_word)C_slot(((C_word*)t0)[3],C_fix(1)),t2,t3);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t6;
goto loop;}}

/* release-number-vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1484(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1484,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1491,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_structurep(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=t3;
f_1491(t5,(C_word)C_i_memq(t4,lf[58]));}
else{
t4=t3;
f_1491(t4,C_SCHEME_FALSE);}}

/* k1489 in release-number-vector in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1491(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub196(C_SCHEME_UNDEFINED,t3));}
else{
/* srfi-4.scm: 271  ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[56],lf[57],((C_word*)t0)[2]);}}

/* alloc in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1466(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1466,NULL,4,t1,t2,t3,t4);}
if(C_truep(t4)){
t5=t3;
t6=(C_word)C_i_foreign_fixnum_argumentp(t5);
t7=(C_word)stub191(C_SCHEME_UNDEFINED,t6);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
/* srfi-4.scm: 261  ##sys#error */
t8=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,t2,lf[54],t3);}}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1482,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 262  ##sys#allocate-vector */
t6=*((C_word*)lf[55]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,t3,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}}

/* k1480 in alloc in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_string_to_bytevector(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* ext-free in k1455 in k1451 in k1447 in k1443 in k1439 in k1435 in k1431 in k1427 in k1423 in k1419 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1464(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1464,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub196(C_SCHEME_UNDEFINED,t2));}

/* f_1310 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1310(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1310,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1314,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 179  length */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1312 */
static void C_ccall f_1314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1317,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fits_in_int_p(((C_word*)t0)[2]))){
t3=t2;
f_1317(2,t3,C_SCHEME_UNDEFINED);}
else{
/* srfi-4.scm: 181  ##sys#error */
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[41],lf[42],((C_word*)t0)[2]);}}

/* k1315 in k1312 */
static void C_ccall f_1317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1320,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 182  ##sys#check-range */
t3=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[4],C_fix(0),((C_word*)t0)[2],lf[41]);}

/* k1318 in k1315 in k1312 */
static void C_ccall f_1320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
t5=((C_word*)t0)[2];
t6=t2;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_s32poke((C_word)C_slot(t3,C_fix(1)),t4,t5));}

/* f_1337 in k1407 in k1403 in k1399 in k1395 in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1337(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1337,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1341,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 187  length */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1339 */
static void C_ccall f_1341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1344,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_negativep(((C_word*)t0)[2]))){
/* srfi-4.scm: 189  ##sys#error */
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[38],lf[39],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_fits_in_unsigned_int_p(((C_word*)t0)[2]))){
t3=t2;
f_1344(2,t3,C_SCHEME_UNDEFINED);}
else{
/* srfi-4.scm: 191  ##sys#error */
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[38],lf[40],((C_word*)t0)[2]);}}}

/* k1342 in k1339 */
static void C_ccall f_1344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1347,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 192  ##sys#check-range */
t3=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[4],C_fix(0),((C_word*)t0)[2],lf[38]);}

/* k1345 in k1342 in k1339 */
static void C_ccall f_1347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
t5=((C_word*)t0)[2];
t6=t2;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_u32poke((C_word)C_slot(t3,C_fix(1)),t4,t5));}

/* setf in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1371(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1371,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1373,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=((C_word)li26),tmp=(C_word)a,a+=6,tmp));}

/* f_1373 in setf in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1373(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1373,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1377,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 197  length */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1375 */
static void C_ccall f_1377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1377,2,t0,t1);}
t2=(C_word)C_i_check_number_2(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1383,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 199  ##sys#check-range */
t4=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[2],C_fix(0),t1,((C_word*)t0)[6]);}

/* k1381 in k1375 */
static void C_ccall f_1383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1390,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(((C_word*)t0)[2]))){
t3=t2;
f_1390(2,t3,((C_word*)t0)[2]);}
else{
/* srfi-4.scm: 202  exact->inexact */
C_exact_to_inexact(3,0,t2,((C_word*)t0)[2]);}}

/* k1388 in k1381 in k1375 */
static void C_ccall f_1390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 200  upd */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* setu in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1282(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1282,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1284,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=((C_word)li24),tmp=(C_word)a,a+=6,tmp));}

/* f_1284 in setu in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1284(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1284,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1288,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 170  length */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1286 */
static void C_ccall f_1288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1288,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1294,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[7],C_fix(0)))){
/* srfi-4.scm: 173  ##sys#error */
t4=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[6],lf[33],((C_word*)t0)[7]);}
else{
t4=t3;
f_1294(2,t4,C_SCHEME_UNDEFINED);}}

/* k1292 in k1286 */
static void C_ccall f_1294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1297,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 174  ##sys#check-range */
t3=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[5],C_fix(0),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1295 in k1292 in k1286 */
static void C_ccall f_1297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 175  upd */
t2=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1265(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1265,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1267,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=((C_word)li22),tmp=(C_word)a,a+=6,tmp));}

/* f_1267 in set in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1267(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1267,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1271,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 163  length */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1269 */
static void C_ccall f_1271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1271,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1277,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 165  ##sys#check-range */
t4=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[2],C_fix(0),t1,((C_word*)t0)[6]);}

/* k1275 in k1269 */
static void C_ccall f_1277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 166  upd */
t2=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* get in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_fcall f_1251(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1251,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1253,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=((C_word)li20),tmp=(C_word)a,a+=6,tmp));}

/* f_1253 in get in k1247 in k1243 in k1239 in k1235 in k1231 in k1227 in k1223 in k1219 */
static void C_ccall f_1253(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1253,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1257,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 157  length */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k1255 */
static void C_ccall f_1257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1257,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1260,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 158  ##sys#check-range */
t3=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[3],C_fix(0),t1,((C_word*)t0)[2]);}

/* k1258 in k1255 */
static void C_ccall f_1260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 159  acc */
t2=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* len */
static void C_fcall f_1208(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1208,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1210,a[2]=t3,a[3]=t4,a[4]=t2,a[5]=((C_word)li18),tmp=(C_word)a,a+=6,tmp));}

/* f_1210 in len */
static void C_ccall f_1210(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1210,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,((C_word*)t0)[4],((C_word*)t0)[3]);
t4=(C_word)C_block_size((C_word)C_slot(t2,C_fix(1)));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(((C_word*)t0)[2])?(C_word)C_fixnum_shift_right(t4,((C_word*)t0)[2]):t4));}

/* ##sys#f64vector-set! */
static void C_ccall f_1205(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1205,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_f64poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#f32vector-set! */
static void C_ccall f_1202(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1202,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_f32poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#s32vector-set! */
static void C_ccall f_1199(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1199,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_s32poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#u32vector-set! */
static void C_ccall f_1196(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1196,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_u32poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#s16vector-set! */
static void C_ccall f_1193(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1193,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_s16poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#u16vector-set! */
static void C_ccall f_1190(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1190,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_u16poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#s8vector-set! */
static void C_ccall f_1187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1187,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_s8poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#u8vector-set! */
static void C_ccall f_1184(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1184,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_u8poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#f64vector-ref */
static void C_ccall f_1178(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1178,4,t0,t1,t2,t3);}
t4=(C_word)C_f64peek((C_word)C_slot(t2,C_fix(1)),t3);
/* srfi-4.scm: 117  ##sys#cons-flonum */
t5=*((C_word*)lf[14]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* ##sys#f32vector-ref */
static void C_ccall f_1172(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1172,4,t0,t1,t2,t3);}
t4=(C_word)C_f32peek((C_word)C_slot(t2,C_fix(1)),t3);
/* srfi-4.scm: 113  ##sys#cons-flonum */
t5=*((C_word*)lf[14]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* ##sys#s32vector-ref */
static void C_ccall f_1169(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1169,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_s32peek(&a,2,(C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#u32vector-ref */
static void C_ccall f_1166(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1166,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_u32peek(&a,2,(C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#s16vector-ref */
static void C_ccall f_1163(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1163,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_s16peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#u16vector-ref */
static void C_ccall f_1160(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1160,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u16peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#s8vector-ref */
static void C_ccall f_1157(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1157,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_s8peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#u8vector-ref */
static void C_ccall f_1154(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1154,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u8peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#check-inexact-interval */
static void C_ccall f_1133(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1133,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_number_2(t2,t5);
t7=(C_word)C_i_lessp(t2,t3);
t8=(C_truep(t7)?t7:(C_word)C_i_greaterp(t2,t4));
if(C_truep(t8)){
/* srfi-4.scm: 99   ##sys#error */
t9=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t1,lf[6],t2,t3,t4);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}

/* ##sys#check-exact-interval */
static void C_ccall f_1118(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1118,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_exact_2(t2,t5);
t7=(C_word)C_fixnum_lessp(t2,t3);
t8=(C_truep(t7)?t7:(C_word)C_fixnum_greaterp(t2,t4));
if(C_truep(t8)){
/* srfi-4.scm: 93   ##sys#error */
t9=*((C_word*)lf[3]+1);
((C_proc7)(void*)(*((C_word*)t9+1)))(7,t9,t1,t5,lf[4],t2,t3,t4);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[289] = {
{"toplevel:srfi_4_scm",(void*)C_srfi_4_toplevel},
{"f_1221:srfi_4_scm",(void*)f_1221},
{"f_1225:srfi_4_scm",(void*)f_1225},
{"f_1229:srfi_4_scm",(void*)f_1229},
{"f_1233:srfi_4_scm",(void*)f_1233},
{"f_1237:srfi_4_scm",(void*)f_1237},
{"f_1241:srfi_4_scm",(void*)f_1241},
{"f_1245:srfi_4_scm",(void*)f_1245},
{"f_1249:srfi_4_scm",(void*)f_1249},
{"f_1397:srfi_4_scm",(void*)f_1397},
{"f_1401:srfi_4_scm",(void*)f_1401},
{"f_1405:srfi_4_scm",(void*)f_1405},
{"f_1409:srfi_4_scm",(void*)f_1409},
{"f_1421:srfi_4_scm",(void*)f_1421},
{"f_1425:srfi_4_scm",(void*)f_1425},
{"f_3620:srfi_4_scm",(void*)f_3620},
{"f_1429:srfi_4_scm",(void*)f_1429},
{"f_3616:srfi_4_scm",(void*)f_3616},
{"f_1433:srfi_4_scm",(void*)f_1433},
{"f_3612:srfi_4_scm",(void*)f_3612},
{"f_1437:srfi_4_scm",(void*)f_1437},
{"f_3608:srfi_4_scm",(void*)f_3608},
{"f_1441:srfi_4_scm",(void*)f_1441},
{"f_3604:srfi_4_scm",(void*)f_3604},
{"f_1445:srfi_4_scm",(void*)f_1445},
{"f_3600:srfi_4_scm",(void*)f_3600},
{"f_1449:srfi_4_scm",(void*)f_1449},
{"f_3596:srfi_4_scm",(void*)f_3596},
{"f_1453:srfi_4_scm",(void*)f_1453},
{"f_3592:srfi_4_scm",(void*)f_3592},
{"f_1457:srfi_4_scm",(void*)f_1457},
{"f_2523:srfi_4_scm",(void*)f_2523},
{"f_2527:srfi_4_scm",(void*)f_2527},
{"f_2531:srfi_4_scm",(void*)f_2531},
{"f_2535:srfi_4_scm",(void*)f_2535},
{"f_2539:srfi_4_scm",(void*)f_2539},
{"f_2543:srfi_4_scm",(void*)f_2543},
{"f_2547:srfi_4_scm",(void*)f_2547},
{"f_2551:srfi_4_scm",(void*)f_2551},
{"f_2638:srfi_4_scm",(void*)f_2638},
{"f_2642:srfi_4_scm",(void*)f_2642},
{"f_2646:srfi_4_scm",(void*)f_2646},
{"f_2650:srfi_4_scm",(void*)f_2650},
{"f_2654:srfi_4_scm",(void*)f_2654},
{"f_2658:srfi_4_scm",(void*)f_2658},
{"f_2662:srfi_4_scm",(void*)f_2662},
{"f_2666:srfi_4_scm",(void*)f_2666},
{"f_2808:srfi_4_scm",(void*)f_2808},
{"f_2812:srfi_4_scm",(void*)f_2812},
{"f_2816:srfi_4_scm",(void*)f_2816},
{"f_2820:srfi_4_scm",(void*)f_2820},
{"f_2824:srfi_4_scm",(void*)f_2824},
{"f_2828:srfi_4_scm",(void*)f_2828},
{"f_2832:srfi_4_scm",(void*)f_2832},
{"f_2836:srfi_4_scm",(void*)f_2836},
{"f_2840:srfi_4_scm",(void*)f_2840},
{"f_2844:srfi_4_scm",(void*)f_2844},
{"f_2848:srfi_4_scm",(void*)f_2848},
{"f_2852:srfi_4_scm",(void*)f_2852},
{"f_2856:srfi_4_scm",(void*)f_2856},
{"f_2860:srfi_4_scm",(void*)f_2860},
{"f_2864:srfi_4_scm",(void*)f_2864},
{"f_2868:srfi_4_scm",(void*)f_2868},
{"f_2872:srfi_4_scm",(void*)f_2872},
{"f_2876:srfi_4_scm",(void*)f_2876},
{"f_2880:srfi_4_scm",(void*)f_2880},
{"f_2884:srfi_4_scm",(void*)f_2884},
{"f_2888:srfi_4_scm",(void*)f_2888},
{"f_2892:srfi_4_scm",(void*)f_2892},
{"f_2896:srfi_4_scm",(void*)f_2896},
{"f_2900:srfi_4_scm",(void*)f_2900},
{"f_2904:srfi_4_scm",(void*)f_2904},
{"f_2908:srfi_4_scm",(void*)f_2908},
{"f_2912:srfi_4_scm",(void*)f_2912},
{"f_2916:srfi_4_scm",(void*)f_2916},
{"f_2920:srfi_4_scm",(void*)f_2920},
{"f_2924:srfi_4_scm",(void*)f_2924},
{"f_2928:srfi_4_scm",(void*)f_2928},
{"f_2932:srfi_4_scm",(void*)f_2932},
{"f_3588:srfi_4_scm",(void*)f_3588},
{"f_3470:srfi_4_scm",(void*)f_3470},
{"f_3539:srfi_4_scm",(void*)f_3539},
{"f_3534:srfi_4_scm",(void*)f_3534},
{"f_3472:srfi_4_scm",(void*)f_3472},
{"f_3476:srfi_4_scm",(void*)f_3476},
{"f_3503:srfi_4_scm",(void*)f_3503},
{"f_3508:srfi_4_scm",(void*)f_3508},
{"f_3512:srfi_4_scm",(void*)f_3512},
{"f_3530:srfi_4_scm",(void*)f_3530},
{"f_3521:srfi_4_scm",(void*)f_3521},
{"f_3485:srfi_4_scm",(void*)f_3485},
{"f_3488:srfi_4_scm",(void*)f_3488},
{"f_3461:srfi_4_scm",(void*)f_3461},
{"f_3469:srfi_4_scm",(void*)f_3469},
{"f_3360:srfi_4_scm",(void*)f_3360},
{"f_3412:srfi_4_scm",(void*)f_3412},
{"f_3407:srfi_4_scm",(void*)f_3407},
{"f_3362:srfi_4_scm",(void*)f_3362},
{"f_3366:srfi_4_scm",(void*)f_3366},
{"f_3378:srfi_4_scm",(void*)f_3378},
{"f_3244:srfi_4_scm",(void*)f_3244},
{"f_3297:srfi_4_scm",(void*)f_3297},
{"f_3292:srfi_4_scm",(void*)f_3292},
{"f_3283:srfi_4_scm",(void*)f_3283},
{"f_3291:srfi_4_scm",(void*)f_3291},
{"f_3246:srfi_4_scm",(void*)f_3246},
{"f_3253:srfi_4_scm",(void*)f_3253},
{"f_3261:srfi_4_scm",(void*)f_3261},
{"f_3271:srfi_4_scm",(void*)f_3271},
{"f_3238:srfi_4_scm",(void*)f_3238},
{"f_3232:srfi_4_scm",(void*)f_3232},
{"f_3226:srfi_4_scm",(void*)f_3226},
{"f_3220:srfi_4_scm",(void*)f_3220},
{"f_3214:srfi_4_scm",(void*)f_3214},
{"f_3208:srfi_4_scm",(void*)f_3208},
{"f_3202:srfi_4_scm",(void*)f_3202},
{"f_3196:srfi_4_scm",(void*)f_3196},
{"f_3153:srfi_4_scm",(void*)f_3153},
{"f_3166:srfi_4_scm",(void*)f_3166},
{"f_3169:srfi_4_scm",(void*)f_3169},
{"f_3175:srfi_4_scm",(void*)f_3175},
{"f_2993:srfi_4_scm",(void*)f_2993},
{"f_3003:srfi_4_scm",(void*)f_3003},
{"f_3006:srfi_4_scm",(void*)f_3006},
{"f_3013:srfi_4_scm",(void*)f_3013},
{"f_2937:srfi_4_scm",(void*)f_2937},
{"f_2947:srfi_4_scm",(void*)f_2947},
{"f_2972:srfi_4_scm",(void*)f_2972},
{"f_2774:srfi_4_scm",(void*)f_2774},
{"f_2776:srfi_4_scm",(void*)f_2776},
{"f_2786:srfi_4_scm",(void*)f_2786},
{"f_2745:srfi_4_scm",(void*)f_2745},
{"f_2747:srfi_4_scm",(void*)f_2747},
{"f_2727:srfi_4_scm",(void*)f_2727},
{"f_2729:srfi_4_scm",(void*)f_2729},
{"f_2739:srfi_4_scm",(void*)f_2739},
{"f_2716:srfi_4_scm",(void*)f_2716},
{"f_2718:srfi_4_scm",(void*)f_2718},
{"f_2710:srfi_4_scm",(void*)f_2710},
{"f_2704:srfi_4_scm",(void*)f_2704},
{"f_2698:srfi_4_scm",(void*)f_2698},
{"f_2692:srfi_4_scm",(void*)f_2692},
{"f_2686:srfi_4_scm",(void*)f_2686},
{"f_2680:srfi_4_scm",(void*)f_2680},
{"f_2674:srfi_4_scm",(void*)f_2674},
{"f_2668:srfi_4_scm",(void*)f_2668},
{"f_2601:srfi_4_scm",(void*)f_2601},
{"f_2603:srfi_4_scm",(void*)f_2603},
{"f_2607:srfi_4_scm",(void*)f_2607},
{"f_2612:srfi_4_scm",(void*)f_2612},
{"f_2626:srfi_4_scm",(void*)f_2626},
{"f_2630:srfi_4_scm",(void*)f_2630},
{"f_2595:srfi_4_scm",(void*)f_2595},
{"f_2589:srfi_4_scm",(void*)f_2589},
{"f_2583:srfi_4_scm",(void*)f_2583},
{"f_2577:srfi_4_scm",(void*)f_2577},
{"f_2571:srfi_4_scm",(void*)f_2571},
{"f_2565:srfi_4_scm",(void*)f_2565},
{"f_2559:srfi_4_scm",(void*)f_2559},
{"f_2553:srfi_4_scm",(void*)f_2553},
{"f_2483:srfi_4_scm",(void*)f_2483},
{"f_2485:srfi_4_scm",(void*)f_2485},
{"f_2495:srfi_4_scm",(void*)f_2495},
{"f_2500:srfi_4_scm",(void*)f_2500},
{"f_2507:srfi_4_scm",(void*)f_2507},
{"f_2356:srfi_4_scm",(void*)f_2356},
{"f_2420:srfi_4_scm",(void*)f_2420},
{"f_2415:srfi_4_scm",(void*)f_2415},
{"f_2410:srfi_4_scm",(void*)f_2410},
{"f_2358:srfi_4_scm",(void*)f_2358},
{"f_2409:srfi_4_scm",(void*)f_2409},
{"f_2368:srfi_4_scm",(void*)f_2368},
{"f_2399:srfi_4_scm",(void*)f_2399},
{"f_2380:srfi_4_scm",(void*)f_2380},
{"f_2385:srfi_4_scm",(void*)f_2385},
{"f_2229:srfi_4_scm",(void*)f_2229},
{"f_2293:srfi_4_scm",(void*)f_2293},
{"f_2288:srfi_4_scm",(void*)f_2288},
{"f_2283:srfi_4_scm",(void*)f_2283},
{"f_2231:srfi_4_scm",(void*)f_2231},
{"f_2282:srfi_4_scm",(void*)f_2282},
{"f_2241:srfi_4_scm",(void*)f_2241},
{"f_2272:srfi_4_scm",(void*)f_2272},
{"f_2253:srfi_4_scm",(void*)f_2253},
{"f_2258:srfi_4_scm",(void*)f_2258},
{"f_2109:srfi_4_scm",(void*)f_2109},
{"f_2166:srfi_4_scm",(void*)f_2166},
{"f_2161:srfi_4_scm",(void*)f_2161},
{"f_2156:srfi_4_scm",(void*)f_2156},
{"f_2111:srfi_4_scm",(void*)f_2111},
{"f_2155:srfi_4_scm",(void*)f_2155},
{"f_2121:srfi_4_scm",(void*)f_2121},
{"f_2135:srfi_4_scm",(void*)f_2135},
{"f_1989:srfi_4_scm",(void*)f_1989},
{"f_2046:srfi_4_scm",(void*)f_2046},
{"f_2041:srfi_4_scm",(void*)f_2041},
{"f_2036:srfi_4_scm",(void*)f_2036},
{"f_1991:srfi_4_scm",(void*)f_1991},
{"f_2035:srfi_4_scm",(void*)f_2035},
{"f_2001:srfi_4_scm",(void*)f_2001},
{"f_2015:srfi_4_scm",(void*)f_2015},
{"f_1869:srfi_4_scm",(void*)f_1869},
{"f_1926:srfi_4_scm",(void*)f_1926},
{"f_1921:srfi_4_scm",(void*)f_1921},
{"f_1916:srfi_4_scm",(void*)f_1916},
{"f_1871:srfi_4_scm",(void*)f_1871},
{"f_1915:srfi_4_scm",(void*)f_1915},
{"f_1881:srfi_4_scm",(void*)f_1881},
{"f_1890:srfi_4_scm",(void*)f_1890},
{"f_1895:srfi_4_scm",(void*)f_1895},
{"f_1749:srfi_4_scm",(void*)f_1749},
{"f_1806:srfi_4_scm",(void*)f_1806},
{"f_1801:srfi_4_scm",(void*)f_1801},
{"f_1796:srfi_4_scm",(void*)f_1796},
{"f_1751:srfi_4_scm",(void*)f_1751},
{"f_1795:srfi_4_scm",(void*)f_1795},
{"f_1761:srfi_4_scm",(void*)f_1761},
{"f_1770:srfi_4_scm",(void*)f_1770},
{"f_1775:srfi_4_scm",(void*)f_1775},
{"f_1629:srfi_4_scm",(void*)f_1629},
{"f_1686:srfi_4_scm",(void*)f_1686},
{"f_1681:srfi_4_scm",(void*)f_1681},
{"f_1676:srfi_4_scm",(void*)f_1676},
{"f_1631:srfi_4_scm",(void*)f_1631},
{"f_1675:srfi_4_scm",(void*)f_1675},
{"f_1641:srfi_4_scm",(void*)f_1641},
{"f_1650:srfi_4_scm",(void*)f_1650},
{"f_1655:srfi_4_scm",(void*)f_1655},
{"f_1509:srfi_4_scm",(void*)f_1509},
{"f_1566:srfi_4_scm",(void*)f_1566},
{"f_1561:srfi_4_scm",(void*)f_1561},
{"f_1556:srfi_4_scm",(void*)f_1556},
{"f_1511:srfi_4_scm",(void*)f_1511},
{"f_1555:srfi_4_scm",(void*)f_1555},
{"f_1521:srfi_4_scm",(void*)f_1521},
{"f_1530:srfi_4_scm",(void*)f_1530},
{"f_1535:srfi_4_scm",(void*)f_1535},
{"f_1484:srfi_4_scm",(void*)f_1484},
{"f_1491:srfi_4_scm",(void*)f_1491},
{"f_1466:srfi_4_scm",(void*)f_1466},
{"f_1482:srfi_4_scm",(void*)f_1482},
{"f_1464:srfi_4_scm",(void*)f_1464},
{"f_1310:srfi_4_scm",(void*)f_1310},
{"f_1314:srfi_4_scm",(void*)f_1314},
{"f_1317:srfi_4_scm",(void*)f_1317},
{"f_1320:srfi_4_scm",(void*)f_1320},
{"f_1337:srfi_4_scm",(void*)f_1337},
{"f_1341:srfi_4_scm",(void*)f_1341},
{"f_1344:srfi_4_scm",(void*)f_1344},
{"f_1347:srfi_4_scm",(void*)f_1347},
{"f_1371:srfi_4_scm",(void*)f_1371},
{"f_1373:srfi_4_scm",(void*)f_1373},
{"f_1377:srfi_4_scm",(void*)f_1377},
{"f_1383:srfi_4_scm",(void*)f_1383},
{"f_1390:srfi_4_scm",(void*)f_1390},
{"f_1282:srfi_4_scm",(void*)f_1282},
{"f_1284:srfi_4_scm",(void*)f_1284},
{"f_1288:srfi_4_scm",(void*)f_1288},
{"f_1294:srfi_4_scm",(void*)f_1294},
{"f_1297:srfi_4_scm",(void*)f_1297},
{"f_1265:srfi_4_scm",(void*)f_1265},
{"f_1267:srfi_4_scm",(void*)f_1267},
{"f_1271:srfi_4_scm",(void*)f_1271},
{"f_1277:srfi_4_scm",(void*)f_1277},
{"f_1251:srfi_4_scm",(void*)f_1251},
{"f_1253:srfi_4_scm",(void*)f_1253},
{"f_1257:srfi_4_scm",(void*)f_1257},
{"f_1260:srfi_4_scm",(void*)f_1260},
{"f_1208:srfi_4_scm",(void*)f_1208},
{"f_1210:srfi_4_scm",(void*)f_1210},
{"f_1205:srfi_4_scm",(void*)f_1205},
{"f_1202:srfi_4_scm",(void*)f_1202},
{"f_1199:srfi_4_scm",(void*)f_1199},
{"f_1196:srfi_4_scm",(void*)f_1196},
{"f_1193:srfi_4_scm",(void*)f_1193},
{"f_1190:srfi_4_scm",(void*)f_1190},
{"f_1187:srfi_4_scm",(void*)f_1187},
{"f_1184:srfi_4_scm",(void*)f_1184},
{"f_1178:srfi_4_scm",(void*)f_1178},
{"f_1172:srfi_4_scm",(void*)f_1172},
{"f_1169:srfi_4_scm",(void*)f_1169},
{"f_1166:srfi_4_scm",(void*)f_1166},
{"f_1163:srfi_4_scm",(void*)f_1163},
{"f_1160:srfi_4_scm",(void*)f_1160},
{"f_1157:srfi_4_scm",(void*)f_1157},
{"f_1154:srfi_4_scm",(void*)f_1154},
{"f_1133:srfi_4_scm",(void*)f_1133},
{"f_1118:srfi_4_scm",(void*)f_1118},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
