/* Generated from lolevel.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-12-14 09:02
   Version 4.2.0 - SVN rev. 16023
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-12-14 on galinha (Linux)
   command line: lolevel.scm -optimize-level 2 -include-path . -include-path ./ -inline -explicit-use -no-trace -output-file lolevel.c
   unit: lolevel
*/

#include "chicken.h"

#if defined(__FreeBSD__) || defined(__NetBSD__) || defined(__OpenBSD__)
# include <sys/types.h>
#endif
#ifndef C_NONUNIX
# include <sys/mman.h>
#endif

#define C_w2b(x)                   C_fix(C_wordstobytes(C_unfix(x)))
#define C_pointer_eqp(x, y)        C_mk_bool(C_c_pointer_nn(x) == C_c_pointer_nn(y))
#define C_memmove_o(to, from, n, toff, foff) C_memmove((char *)(to) + (toff), (char *)(from) + (foff), (n))

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[128];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,99,104,101,99,107,45,98,108,111,99,107,32,120,49,53,32,108,111,99,49,54,41,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,41),40,35,35,115,121,115,35,99,104,101,99,107,45,103,101,110,101,114,105,99,45,115,116,114,117,99,116,117,114,101,32,120,52,55,32,108,111,99,52,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,33),40,35,35,115,121,115,35,99,104,101,99,107,45,112,111,105,110,116,101,114,32,120,55,50,32,46,32,108,111,99,55,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,13),40,116,121,112,101,114,114,32,120,49,53,56,41,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,10),40,110,111,115,105,122,101,114,114,41,0,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,16),40,115,105,122,101,114,114,32,97,114,103,115,49,57,52,41};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,29),40,99,104,101,99,107,110,49,32,110,49,57,53,32,110,109,97,120,49,57,54,32,111,102,102,49,57,55,41,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,47),40,99,104,101,99,107,110,50,32,110,50,48,50,32,110,109,97,120,50,48,51,32,110,109,97,120,50,50,48,52,32,111,102,102,49,50,48,53,32,111,102,102,50,50,48,54,41,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,20),40,109,111,118,101,32,102,114,111,109,50,49,52,32,116,111,50,49,53,41,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,36),40,98,111,100,121,49,55,55,32,110,49,56,55,32,102,111,102,102,115,101,116,49,56,56,32,116,111,102,102,115,101,116,49,56,57,41,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,40),40,100,101,102,45,116,111,102,102,115,101,116,49,56,49,32,37,110,49,55,52,51,48,53,32,37,102,111,102,102,115,101,116,49,55,53,51,48,54,41};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,102,111,102,102,115,101,116,49,56,48,32,37,110,49,55,52,51,48,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,10),40,100,101,102,45,110,49,55,57,41,0,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,40),40,109,111,118,101,45,109,101,109,111,114,121,33,32,102,114,111,109,49,54,56,32,116,111,49,54,57,32,46,32,116,109,112,49,54,55,49,55,48,41};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,51,51,56,32,105,51,52,50,41};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,11),40,99,111,112,121,32,120,51,50,48,41,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,18),40,111,98,106,101,99,116,45,99,111,112,121,32,120,51,49,56,41,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,18),40,97,108,108,111,99,97,116,101,32,97,51,52,55,51,53,48,41,0,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,14),40,102,114,101,101,32,97,51,53,50,51,53,54,41,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,15),40,112,111,105,110,116,101,114,63,32,120,51,53,57,41,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,20),40,112,111,105,110,116,101,114,45,108,105,107,101,63,32,120,51,54,52,41,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,26),40,97,100,100,114,101,115,115,45,62,112,111,105,110,116,101,114,32,97,100,100,114,51,54,57,41,0,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,25),40,112,111,105,110,116,101,114,45,62,97,100,100,114,101,115,115,32,112,116,114,51,55,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,22),40,110,117,108,108,45,112,111,105,110,116,101,114,63,32,112,116,114,51,55,53,41,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,22),40,111,98,106,101,99,116,45,62,112,111,105,110,116,101,114,32,120,51,55,56,41,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,24),40,112,111,105,110,116,101,114,45,62,111,98,106,101,99,116,32,112,116,114,51,56,55,41};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,23),40,112,111,105,110,116,101,114,61,63,32,112,49,51,57,48,32,112,50,51,57,49,41,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,32),40,112,111,105,110,116,101,114,45,111,102,102,115,101,116,32,97,51,57,53,51,57,57,32,97,51,57,52,52,48,48,41};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,20),40,97,108,105,103,110,45,116,111,45,119,111,114,100,32,120,52,48,57,41,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,27),40,116,97,103,45,112,111,105,110,116,101,114,32,112,116,114,52,50,48,32,116,97,103,52,50,49,41,0,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,34),40,116,97,103,103,101,100,45,112,111,105,110,116,101,114,63,32,120,52,51,55,32,46,32,116,109,112,52,51,54,52,51,56,41,0,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,18),40,112,111,105,110,116,101,114,45,116,97,103,32,120,52,53,52,41,0,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,33),40,109,97,107,101,45,108,111,99,97,116,105,118,101,32,111,98,106,52,54,52,32,46,32,105,110,100,101,120,52,54,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,38),40,109,97,107,101,45,119,101,97,107,45,108,111,99,97,116,105,118,101,32,111,98,106,52,55,49,32,46,32,105,110,100,101,120,52,55,50,41,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,25),40,108,111,99,97,116,105,118,101,45,115,101,116,33,32,120,52,55,56,32,121,52,55,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,23),40,108,111,99,97,116,105,118,101,45,62,111,98,106,101,99,116,32,120,52,56,49,41,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,16),40,108,111,99,97,116,105,118,101,63,32,120,52,56,51,41};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,33),40,112,111,105,110,116,101,114,45,117,56,45,115,101,116,33,32,97,52,56,55,52,57,49,32,97,52,56,54,52,57,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,33),40,112,111,105,110,116,101,114,45,115,56,45,115,101,116,33,32,97,52,57,53,52,57,57,32,97,52,57,52,53,48,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,117,49,54,45,115,101,116,33,32,97,53,48,51,53,48,55,32,97,53,48,50,53,48,56,41,0,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,115,49,54,45,115,101,116,33,32,97,53,49,49,53,49,53,32,97,53,49,48,53,49,54,41,0,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,117,51,50,45,115,101,116,33,32,97,53,49,57,53,50,51,32,97,53,49,56,53,50,52,41,0,0,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,115,51,50,45,115,101,116,33,32,97,53,50,55,53,51,49,32,97,53,50,54,53,51,50,41,0,0,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,102,51,50,45,115,101,116,33,32,97,53,51,53,53,51,57,32,97,53,51,52,53,52,48,41,0,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,102,54,52,45,115,101,116,33,32,97,53,52,51,53,52,55,32,97,53,52,50,53,52,56,41,0,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,12),40,97,50,49,53,56,32,120,54,48,53,41,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,17),40,97,50,49,55,52,32,120,54,48,56,32,105,54,48,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,34),40,101,120,116,101,110,100,45,112,114,111,99,101,100,117,114,101,32,112,114,111,99,54,48,51,32,100,97,116,97,54,48,52,41,0,0,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,12),40,97,50,49,57,57,32,120,54,50,50,41,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,26),40,101,120,116,101,110,100,101,100,45,112,114,111,99,101,100,117,114,101,63,32,120,54,49,52,41,0,0,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,12),40,97,50,50,51,51,32,120,54,51,54,41,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,21),40,112,114,111,99,101,100,117,114,101,45,100,97,116,97,32,120,54,50,54,41,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,34),40,115,101,116,45,112,114,111,99,101,100,117,114,101,45,100,97,116,97,33,32,112,114,111,99,54,52,48,32,120,54,52,49,41,0,0,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,22),40,110,117,109,98,101,114,45,111,102,45,115,108,111,116,115,32,120,54,52,52,41,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,22),40,110,117,109,98,101,114,45,111,102,45,98,121,116,101,115,32,120,54,52,55,41,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,40),40,109,97,107,101,45,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,32,116,121,112,101,54,53,53,32,46,32,97,114,103,115,54,53,54,41};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,35),40,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,63,32,120,54,54,53,32,46,32,116,109,112,54,54,52,54,54,54,41,0,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,27),40,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,45,116,121,112,101,32,120,54,56,51,41,0,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,29),40,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,45,108,101,110,103,116,104,32,120,54,56,54,41,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,42),40,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,45,115,108,111,116,45,115,101,116,33,32,120,54,56,57,32,105,54,57,48,32,121,54,57,49,41,0,0,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,55,48,51,41,0,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,21),40,114,101,99,111,114,100,45,62,118,101,99,116,111,114,32,120,54,57,57,41,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,22),40,111,98,106,101,99,116,45,101,118,105,99,116,101,100,63,32,120,55,49,50,41,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,16),40,102,95,50,53,53,54,32,97,55,49,56,55,50,49,41};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,55,52,52,32,105,55,52,56,41};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,12),40,101,118,105,99,116,32,120,55,50,52,41,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,34),40,111,98,106,101,99,116,45,101,118,105,99,116,32,120,55,49,52,32,46,32,97,108,108,111,99,97,116,111,114,55,49,53,41,0,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,56,48,52,32,105,56,48,56,41};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,12),40,101,118,105,99,116,32,120,55,55,57,41,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,49),40,111,98,106,101,99,116,45,101,118,105,99,116,45,116,111,45,108,111,99,97,116,105,111,110,32,120,55,54,50,32,112,116,114,55,54,51,32,46,32,108,105,109,105,116,55,54,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,16),40,102,95,50,56,48,57,32,97,56,50,56,56,51,50,41};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,56,52,53,32,105,56,52,57,41};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,14),40,114,101,108,101,97,115,101,32,120,56,51,53,41,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,35),40,111,98,106,101,99,116,45,114,101,108,101,97,115,101,32,120,56,50,52,32,46,32,114,101,108,101,97,115,101,114,56,50,53,41,0,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,56,55,49,32,105,56,55,53,41};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,12),40,101,118,105,99,116,32,120,56,53,57,41,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,18),40,111,98,106,101,99,116,45,115,105,122,101,32,120,56,53,54,41,0,0,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,57,50,49,32,105,57,50,53,41};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,11),40,99,111,112,121,32,120,57,48,50,41,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,33),40,111,98,106,101,99,116,45,117,110,101,118,105,99,116,32,120,56,57,51,32,46,32,116,109,112,56,57,50,56,57,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,108,115,116,50,56,41,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,24),40,111,98,106,101,99,116,45,98,101,99,111,109,101,33,32,97,108,115,116,57,51,50,41};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,33),40,109,117,116,97,116,101,45,112,114,111,99,101,100,117,114,101,32,111,108,100,57,51,57,32,112,114,111,99,57,52,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,19),40,103,108,111,98,97,108,45,114,101,102,32,115,121,109,57,52,57,41,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,25),40,103,108,111,98,97,108,45,115,101,116,33,32,115,121,109,57,53,50,32,120,57,53,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,22),40,103,108,111,98,97,108,45,98,111,117,110,100,63,32,115,121,109,57,53,54,41,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,29),40,103,108,111,98,97,108,45,109,97,107,101,45,117,110,98,111,117,110,100,33,32,115,121,109,57,53,57,41,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,17),40,97,51,49,48,56,32,120,54,57,52,32,105,54,57,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,15),40,97,51,49,51,50,32,97,53,57,53,53,57,57,41,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,15),40,97,51,49,52,50,32,97,53,56,56,53,57,50,41,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,15),40,97,51,49,53,50,32,97,53,56,49,53,56,53,41,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,15),40,97,51,49,54,50,32,97,53,55,52,53,55,56,41,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,15),40,97,51,49,55,50,32,97,53,54,56,53,55,50,41,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,15),40,97,51,49,56,50,32,97,53,54,50,53,54,54,41,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,15),40,97,51,49,57,50,32,97,53,53,54,53,54,48,41,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,15),40,97,51,50,48,50,32,97,53,53,48,53,53,52,41,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,14),67,95,108,111,99,97,116,105,118,101,95,114,101,102,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k2812 */
static C_word C_fcall stub829(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub829(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
C_free(t0);
return C_r;}

/* from k2559 */
static C_word C_fcall stub719(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub719(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer_or_false(&C_a,(void*)C_malloc(t0));
return C_r;}

/* from k3136 */
#define return(x) C_cblock C_r = (C_flonum(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub596(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub596(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((double *)p));
C_ret:
#undef return

return C_r;}

/* from k3146 */
#define return(x) C_cblock C_r = (C_flonum(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub589(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub589(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((float *)p));
C_ret:
#undef return

return C_r;}

/* from k3156 */
#define return(x) C_cblock C_r = (C_int_to_num(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub582(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub582(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((C_s32 *)p));
C_ret:
#undef return

return C_r;}

/* from k3166 */
#define return(x) C_cblock C_r = (C_int_to_num(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub575(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub575(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((C_u32 *)p));
C_ret:
#undef return

return C_r;}

/* from k3176 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub569(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub569(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((short *)p));
C_ret:
#undef return

return C_r;}

/* from k3186 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub563(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub563(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((unsigned short *)p));
C_ret:
#undef return

return C_r;}

/* from k3196 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub557(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub557(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((signed char *)p));
C_ret:
#undef return

return C_r;}

/* from k3206 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub551(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub551(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((unsigned char *)p));
C_ret:
#undef return

return C_r;}

/* from k2107 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub544(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub544(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
float n=(float )C_c_double(C_a1);
*((double *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2093 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub536(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub536(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
double n=(double )C_c_double(C_a1);
*((float *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2079 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub528(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub528(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((C_s32 *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2065 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub520(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub520(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((C_u32 *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2051 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub512(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub512(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((short *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2037 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub504(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub504(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((unsigned short *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2023 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub496(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub496(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((char *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2009 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub488(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub488(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((unsigned char *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1816 */
static C_word C_fcall stub405(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub405(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_int_to_num(&C_a,C_align(t0));
return C_r;}

/* from k1806 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub396(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub396(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * ptr=(void * )C_c_pointer_or_null(C_a0);
int off=(int )C_num_to_int(C_a1);
return((unsigned char *)ptr + off);
C_ret:
#undef return

return C_r;}

/* from object->pointer in k1045 in k1042 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub382(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub382(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word x=(C_word )(C_a0);
return((void *)x);
C_ret:
#undef return

return C_r;}

/* from k1727 */
static C_word C_fcall stub353(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub353(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
C_free(t0);
return C_r;}

/* from k1720 */
static C_word C_fcall stub348(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub348(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer_or_false(&C_a,(void*)C_malloc(t0));
return C_r;}

/* from k1298 */
static C_word C_fcall stub147(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub147(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k1270 */
static C_word C_fcall stub131(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub131(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k1242 */
static C_word C_fcall stub115(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub115(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k1214 */
static C_word C_fcall stub99(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub99(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

C_noret_decl(C_lolevel_toplevel)
C_externexport void C_ccall C_lolevel_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1044)
static void C_ccall f_1044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1047)
static void C_ccall f_1047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1991)
static void C_ccall f_1991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3203)
static void C_ccall f_3203(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2116)
static void C_ccall f_2116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3193)
static void C_ccall f_3193(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2120)
static void C_ccall f_2120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3183)
static void C_ccall f_3183(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2124)
static void C_ccall f_2124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3173)
static void C_ccall f_3173(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2128)
static void C_ccall f_2128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3163)
static void C_ccall f_3163(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2132)
static void C_ccall f_2132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3153)
static void C_ccall f_3153(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2136)
static void C_ccall f_2136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3143)
static void C_ccall f_3143(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2140)
static void C_ccall f_2140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3133)
static void C_ccall f_3133(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2144)
static void C_ccall f_2144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2268)
static void C_ccall f_2268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3109)
static void C_ccall f_3109(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3113)
static void C_ccall f_3113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3116)
static void C_ccall f_3116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2402)
static void C_ccall f_2402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3096)
static void C_ccall f_3096(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3087)
static void C_ccall f_3087(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3078)
static void C_ccall f_3078(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3072)
static void C_ccall f_3072(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3041)
static void C_ccall f_3041(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3045)
static void C_ccall f_3045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3048)
static void C_ccall f_3048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3055)
static void C_ccall f_3055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3070)
static void C_ccall f_3070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3058)
static void C_ccall f_3058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3032)
static void C_ccall f_3032(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1077)
static void C_fcall f_1077(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1099)
static void C_ccall f_1099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1102)
static void C_ccall f_1102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3036)
static void C_ccall f_3036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2903)
static void C_ccall f_2903(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2903)
static void C_ccall f_2903r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2907)
static void C_ccall f_2907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2910)
static void C_ccall f_2910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2915)
static void C_fcall f_2915(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2931)
static void C_ccall f_2931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2974)
static void C_ccall f_2974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2977)
static void C_ccall f_2977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2986)
static void C_fcall f_2986(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3007)
static void C_ccall f_3007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2980)
static void C_ccall f_2980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2960)
static void C_ccall f_2960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2963)
static void C_ccall f_2963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2944)
static void C_ccall f_2944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2947)
static void C_ccall f_2947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2819)
static void C_ccall f_2819(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2823)
static void C_ccall f_2823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2828)
static void C_fcall f_2828(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2841)
static void C_ccall f_2841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2898)
static void C_ccall f_2898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2850)
static void C_ccall f_2850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2862)
static void C_fcall f_2862(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2884)
static void C_ccall f_2884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2853)
static void C_ccall f_2853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2727)
static void C_ccall f_2727(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2727)
static void C_ccall f_2727r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2736)
static void C_fcall f_2736(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2781)
static void C_fcall f_2781(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2791)
static void C_ccall f_2791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2765)
static void C_ccall f_2765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2772)
static void C_ccall f_2772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2809)
static void C_ccall f_2809(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2563)
static void C_ccall f_2563(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2563)
static void C_ccall f_2563r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2567)
static void C_ccall f_2567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2570)
static void C_fcall f_2570(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2716)
static void C_ccall f_2716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2573)
static void C_ccall f_2573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2576)
static void C_ccall f_2576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2584)
static void C_fcall f_2584(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2594)
static void C_ccall f_2594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2709)
static void C_ccall f_2709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2697)
static void C_ccall f_2697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2701)
static void C_ccall f_2701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2693)
static void C_ccall f_2693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2606)
static void C_ccall f_2606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2609)
static void C_fcall f_2609(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2666)
static void C_ccall f_2666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2612)
static void C_ccall f_2612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2615)
static void C_ccall f_2615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2627)
static void C_fcall f_2627(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2648)
static void C_ccall f_2648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2618)
static void C_ccall f_2618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2579)
static void C_ccall f_2579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2445)
static void C_ccall f_2445(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2445)
static void C_ccall f_2445r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2452)
static void C_ccall f_2452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2455)
static void C_ccall f_2455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2460)
static void C_fcall f_2460(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2470)
static void C_ccall f_2470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2479)
static void C_ccall f_2479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2483)
static void C_ccall f_2483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2486)
static void C_fcall f_2486(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2489)
static void C_ccall f_2489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2501)
static void C_fcall f_2501(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2522)
static void C_ccall f_2522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2492)
static void C_ccall f_2492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2556)
static void C_ccall f_2556(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2442)
static void C_ccall f_2442(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2404)
static void C_ccall f_2404(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2408)
static void C_ccall f_2408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2414)
static void C_ccall f_2414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2419)
static C_word C_fcall f_2419(C_word t0,C_word t1);
C_noret_decl(f_2376)
static void C_ccall f_2376(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2380)
static void C_ccall f_2380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2383)
static void C_ccall f_2383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2363)
static void C_ccall f_2363(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2367)
static void C_ccall f_2367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2354)
static void C_ccall f_2354(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2358)
static void C_ccall f_2358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2310)
static void C_ccall f_2310(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2310)
static void C_ccall f_2310r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2314)
static void C_ccall f_2314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2301)
static void C_ccall f_2301(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2301)
static void C_ccall f_2301r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2279)
static void C_ccall f_2279(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2270)
static void C_ccall f_2270(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1151)
static void C_fcall f_1151(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2274)
static void C_ccall f_2274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2250)
static void C_ccall f_2250(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2254)
static void C_ccall f_2254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2216)
static void C_ccall f_2216(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2234)
static void C_ccall f_2234(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2226)
static void C_ccall f_2226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2185)
static void C_ccall f_2185(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2200)
static void C_ccall f_2200(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2198)
static void C_ccall f_2198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2150)
static void C_ccall f_2150(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2154)
static void C_ccall f_2154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2175)
static void C_ccall f_2175(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2159)
static void C_ccall f_2159(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2100)
static void C_ccall f_2100(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2086)
static void C_ccall f_2086(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2072)
static void C_ccall f_2072(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2058)
static void C_ccall f_2058(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2044)
static void C_ccall f_2044(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2030)
static void C_ccall f_2030(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2016)
static void C_ccall f_2016(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2002)
static void C_ccall f_2002(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1996)
static void C_ccall f_1996(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1993)
static void C_ccall f_1993(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1986)
static void C_ccall f_1986(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1957)
static void C_ccall f_1957(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1957)
static void C_ccall f_1957r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1965)
static void C_ccall f_1965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1928)
static void C_ccall f_1928(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1928)
static void C_ccall f_1928r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1936)
static void C_ccall f_1936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1910)
static void C_ccall f_1910(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1866)
static void C_ccall f_1866(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1866)
static void C_ccall f_1866r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1870)
static void C_ccall f_1870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1851)
static void C_ccall f_1851(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1855)
static void C_ccall f_1855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1858)
static void C_ccall f_1858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1819)
static void C_ccall f_1819(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1846)
static void C_ccall f_1846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1799)
static void C_ccall f_1799(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1790)
static void C_ccall f_1790(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1794)
static void C_ccall f_1794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1797)
static void C_ccall f_1797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1784)
static void C_ccall f_1784(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1788)
static void C_ccall f_1788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1778)
static void C_ccall f_1778(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1765)
static void C_ccall f_1765(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1769)
static void C_ccall f_1769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1776)
static void C_ccall f_1776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1755)
static void C_ccall f_1755(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1759)
static void C_ccall f_1759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1746)
static void C_ccall f_1746(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1750)
static void C_ccall f_1750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1740)
static void C_ccall f_1740(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1734)
static void C_ccall f_1734(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1724)
static void C_ccall f_1724(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1717)
static void C_ccall f_1717(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1636)
static void C_ccall f_1636(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1642)
static void C_fcall f_1642(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1672)
static void C_ccall f_1672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1687)
static void C_fcall f_1687(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1708)
static void C_ccall f_1708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1675)
static void C_ccall f_1675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1312)
static void C_ccall f_1312(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1312)
static void C_ccall f_1312r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1573)
static void C_fcall f_1573(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1568)
static void C_fcall f_1568(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1563)
static void C_fcall f_1563(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1314)
static void C_fcall f_1314(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1372)
static void C_ccall f_1372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1375)
static void C_ccall f_1375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1380)
static void C_fcall f_1380(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1500)
static void C_ccall f_1500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1532)
static void C_ccall f_1532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1542)
static void C_ccall f_1542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1522)
static void C_ccall f_1522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1467)
static void C_ccall f_1467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1481)
static void C_ccall f_1481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1477)
static void C_ccall f_1477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1458)
static void C_ccall f_1458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1345)
static void C_fcall f_1345(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1352)
static void C_fcall f_1352(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1329)
static void C_fcall f_1329(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1323)
static void C_fcall f_1323(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1317)
static void C_fcall f_1317(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1307)
static void C_fcall f_1307(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1173)
static void C_ccall f_1173(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1173)
static void C_ccall f_1173r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1122)
static void C_fcall f_1122(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1049)
static void C_fcall f_1049(C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_1077)
static void C_fcall trf_1077(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1077(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1077(t0,t1,t2);}

C_noret_decl(trf_2915)
static void C_fcall trf_2915(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2915(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2915(t0,t1,t2);}

C_noret_decl(trf_2986)
static void C_fcall trf_2986(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2986(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2986(t0,t1,t2);}

C_noret_decl(trf_2828)
static void C_fcall trf_2828(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2828(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2828(t0,t1,t2);}

C_noret_decl(trf_2862)
static void C_fcall trf_2862(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2862(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2862(t0,t1,t2);}

C_noret_decl(trf_2736)
static void C_fcall trf_2736(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2736(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2736(t0,t1,t2);}

C_noret_decl(trf_2781)
static void C_fcall trf_2781(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2781(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2781(t0,t1,t2);}

C_noret_decl(trf_2570)
static void C_fcall trf_2570(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2570(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2570(t0,t1);}

C_noret_decl(trf_2584)
static void C_fcall trf_2584(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2584(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2584(t0,t1,t2);}

C_noret_decl(trf_2609)
static void C_fcall trf_2609(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2609(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2609(t0,t1);}

C_noret_decl(trf_2627)
static void C_fcall trf_2627(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2627(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2627(t0,t1,t2);}

C_noret_decl(trf_2460)
static void C_fcall trf_2460(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2460(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2460(t0,t1,t2);}

C_noret_decl(trf_2486)
static void C_fcall trf_2486(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2486(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2486(t0,t1);}

C_noret_decl(trf_2501)
static void C_fcall trf_2501(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2501(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2501(t0,t1,t2);}

C_noret_decl(trf_1151)
static void C_fcall trf_1151(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1151(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1151(t0,t1);}

C_noret_decl(trf_1642)
static void C_fcall trf_1642(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1642(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1642(t0,t1,t2);}

C_noret_decl(trf_1687)
static void C_fcall trf_1687(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1687(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1687(t0,t1,t2);}

C_noret_decl(trf_1573)
static void C_fcall trf_1573(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1573(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1573(t0,t1);}

C_noret_decl(trf_1568)
static void C_fcall trf_1568(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1568(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1568(t0,t1,t2);}

C_noret_decl(trf_1563)
static void C_fcall trf_1563(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1563(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1563(t0,t1,t2,t3);}

C_noret_decl(trf_1314)
static void C_fcall trf_1314(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1314(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1314(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1380)
static void C_fcall trf_1380(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1380(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1380(t0,t1,t2,t3);}

C_noret_decl(trf_1345)
static void C_fcall trf_1345(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1345(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_1345(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_1352)
static void C_fcall trf_1352(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1352(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1352(t0,t1);}

C_noret_decl(trf_1329)
static void C_fcall trf_1329(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1329(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1329(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1323)
static void C_fcall trf_1323(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1323(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1323(t0,t1,t2);}

C_noret_decl(trf_1317)
static void C_fcall trf_1317(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1317(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1317(t0,t1);}

C_noret_decl(trf_1307)
static void C_fcall trf_1307(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1307(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1307(t0,t1);}

C_noret_decl(trf_1122)
static void C_fcall trf_1122(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1122(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1122(t0,t1,t2);}

C_noret_decl(trf_1049)
static void C_fcall trf_1049(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1049(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1049(t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_lolevel_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_lolevel_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("lolevel_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1237)){
C_save(t1);
C_rereclaim2(1237*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,128);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[3]=C_h_intern(&lf[3],14,"\003syserror-hook");
lf[5]=C_h_intern(&lf[5],15,"\003syssignal-hook");
lf[6]=C_h_intern(&lf[6],11,"\000type-error");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000#bad argument type - not a structure");
lf[8]=C_h_intern(&lf[8],17,"\003syscheck-pointer");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a pointer");
lf[10]=C_h_intern(&lf[10],12,"move-memory!");
lf[11]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\004mmap\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000\002\376\001\000\000\011u32vector\376\003\000\000\002\376\001\000\000\010"
"s8vector\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376\001\000\000\011f64ve"
"ctor\376\377\016");
lf[12]=C_h_intern(&lf[12],9,"\003syserror");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\000\034need number of bytes to move");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000!number of bytes to move too large");
lf[15]=C_h_intern(&lf[15],15,"\003sysbytevector\077");
lf[16]=C_h_intern(&lf[16],11,"object-copy");
lf[17]=C_h_intern(&lf[17],15,"\003sysmake-vector");
lf[18]=C_h_intern(&lf[18],8,"allocate");
lf[19]=C_h_intern(&lf[19],4,"free");
lf[20]=C_h_intern(&lf[20],8,"pointer\077");
lf[21]=C_h_intern(&lf[21],13,"pointer-like\077");
lf[22]=C_h_intern(&lf[22],16,"address->pointer");
lf[23]=C_h_intern(&lf[23],20,"\003sysaddress->pointer");
lf[24]=C_h_intern(&lf[24],17,"\003syscheck-integer");
lf[25]=C_h_intern(&lf[25],16,"pointer->address");
lf[26]=C_h_intern(&lf[26],20,"\003syspointer->address");
lf[27]=C_h_intern(&lf[27],17,"\003syscheck-special");
lf[28]=C_h_intern(&lf[28],12,"null-pointer");
lf[29]=C_h_intern(&lf[29],16,"\003sysnull-pointer");
lf[30]=C_h_intern(&lf[30],13,"null-pointer\077");
lf[31]=C_h_intern(&lf[31],15,"object->pointer");
lf[32]=C_h_intern(&lf[32],15,"pointer->object");
lf[33]=C_h_intern(&lf[33],9,"pointer=\077");
lf[34]=C_h_intern(&lf[34],14,"pointer-offset");
lf[35]=C_h_intern(&lf[35],13,"align-to-word");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000,bad argument type - not a pointer or integer");
lf[37]=C_h_intern(&lf[37],11,"tag-pointer");
lf[38]=C_h_intern(&lf[38],23,"\003sysmake-tagged-pointer");
lf[39]=C_h_intern(&lf[39],15,"tagged-pointer\077");
lf[40]=C_h_intern(&lf[40],11,"pointer-tag");
lf[41]=C_h_intern(&lf[41],13,"make-locative");
lf[42]=C_h_intern(&lf[42],17,"\003sysmake-locative");
lf[43]=C_h_intern(&lf[43],18,"make-weak-locative");
lf[44]=C_h_intern(&lf[44],13,"locative-set!");
lf[45]=C_h_intern(&lf[45],12,"locative-ref");
lf[46]=C_h_intern(&lf[46],16,"locative->object");
lf[47]=C_h_intern(&lf[47],9,"locative\077");
lf[48]=C_h_intern(&lf[48],15,"pointer-u8-set!");
lf[49]=C_h_intern(&lf[49],15,"pointer-s8-set!");
lf[50]=C_h_intern(&lf[50],16,"pointer-u16-set!");
lf[51]=C_h_intern(&lf[51],16,"pointer-s16-set!");
lf[52]=C_h_intern(&lf[52],16,"pointer-u32-set!");
lf[53]=C_h_intern(&lf[53],16,"pointer-s32-set!");
lf[54]=C_h_intern(&lf[54],16,"pointer-f32-set!");
lf[55]=C_h_intern(&lf[55],16,"pointer-f64-set!");
lf[56]=C_h_intern(&lf[56],14,"pointer-u8-ref");
lf[57]=C_h_intern(&lf[57],14,"pointer-s8-ref");
lf[58]=C_h_intern(&lf[58],15,"pointer-u16-ref");
lf[59]=C_h_intern(&lf[59],15,"pointer-s16-ref");
lf[60]=C_h_intern(&lf[60],15,"pointer-u32-ref");
lf[61]=C_h_intern(&lf[61],15,"pointer-s32-ref");
lf[62]=C_h_intern(&lf[62],15,"pointer-f32-ref");
lf[63]=C_h_intern(&lf[63],15,"pointer-f64-ref");
lf[64]=C_h_intern(&lf[64],8,"extended");
lf[66]=C_h_intern(&lf[66],16,"extend-procedure");
lf[67]=C_h_intern(&lf[67],19,"\003sysdecorate-lambda");
lf[68]=C_h_intern(&lf[68],17,"\003syscheck-closure");
lf[69]=C_h_intern(&lf[69],19,"extended-procedure\077");
lf[70]=C_h_intern(&lf[70],21,"\003syslambda-decoration");
lf[71]=C_h_intern(&lf[71],14,"procedure-data");
lf[72]=C_h_intern(&lf[72],19,"set-procedure-data!");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000-bad argument type - not an extended procedure");
lf[74]=C_h_intern(&lf[74],10,"block-set!");
lf[75]=C_h_intern(&lf[75],14,"\003sysblock-set!");
lf[76]=C_h_intern(&lf[76],9,"block-ref");
lf[77]=C_h_intern(&lf[77],15,"number-of-slots");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000,bad argument type - not a vector-like object");
lf[79]=C_h_intern(&lf[79],15,"number-of-bytes");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\0002cannot compute number of bytes of immediate object");
lf[81]=C_h_intern(&lf[81],20,"make-record-instance");
lf[82]=C_h_intern(&lf[82],18,"\003sysmake-structure");
lf[83]=C_h_intern(&lf[83],16,"record-instance\077");
lf[84]=C_h_intern(&lf[84],20,"record-instance-type");
lf[85]=C_h_intern(&lf[85],22,"record-instance-length");
lf[86]=C_h_intern(&lf[86],25,"record-instance-slot-set!");
lf[87]=C_h_intern(&lf[87],15,"\003syscheck-range");
lf[88]=C_h_intern(&lf[88],20,"record-instance-slot");
lf[89]=C_h_intern(&lf[89],14,"record->vector");
lf[90]=C_h_intern(&lf[90],15,"object-evicted\077");
lf[91]=C_h_intern(&lf[91],12,"object-evict");
lf[92]=C_h_intern(&lf[92],15,"hash-table-set!");
lf[93]=C_h_intern(&lf[93],19,"\003sysundefined-value");
lf[94]=C_h_intern(&lf[94],22,"hash-table-ref/default");
lf[95]=C_h_intern(&lf[95],15,"make-hash-table");
lf[96]=C_h_intern(&lf[96],3,"eq\077");
lf[97]=C_h_intern(&lf[97],24,"object-evict-to-location");
lf[98]=C_h_intern(&lf[98],24,"\003sysset-pointer-address!");
lf[99]=C_h_intern(&lf[99],6,"signal");
lf[100]=C_h_intern(&lf[100],24,"make-composite-condition");
lf[101]=C_h_intern(&lf[101],23,"make-property-condition");
lf[102]=C_h_intern(&lf[102],5,"evict");
lf[103]=C_h_intern(&lf[103],5,"limit");
lf[104]=C_h_intern(&lf[104],3,"exn");
lf[105]=C_h_intern(&lf[105],8,"location");
lf[106]=C_h_intern(&lf[106],7,"message");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000$cannot evict object - limit exceeded");
lf[108]=C_h_intern(&lf[108],9,"arguments");
lf[109]=C_h_intern(&lf[109],14,"object-release");
lf[110]=C_h_intern(&lf[110],11,"object-size");
lf[111]=C_h_intern(&lf[111],14,"object-unevict");
lf[112]=C_h_intern(&lf[112],15,"\003sysmake-string");
lf[113]=C_h_intern(&lf[113],14,"object-become!");
lf[114]=C_h_intern(&lf[114],11,"\003sysbecome!");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000:bad argument type - not an a-list of non-immediate objects");
lf[116]=C_h_intern(&lf[116],16,"mutate-procedure");
lf[117]=C_h_intern(&lf[117],10,"global-ref");
lf[118]=C_h_intern(&lf[118],11,"global-set!");
lf[119]=C_h_intern(&lf[119],13,"global-bound\077");
lf[120]=C_h_intern(&lf[120],32,"\003syssymbol-has-toplevel-binding\077");
lf[121]=C_h_intern(&lf[121],20,"global-make-unbound!");
lf[122]=C_h_intern(&lf[122],28,"\003sysarbitrary-unbound-symbol");
lf[123]=C_h_intern(&lf[123],18,"getter-with-setter");
lf[124]=C_h_intern(&lf[124],13,"\003sysblock-ref");
lf[125]=C_h_intern(&lf[125],15,"pointer-s6-set!");
lf[126]=C_h_intern(&lf[126],17,"register-feature!");
lf[127]=C_h_intern(&lf[127],7,"lolevel");
C_register_lf2(lf,128,create_ptable());
t2=C_mutate(&lf[0] /* (set! c316 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1044,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1042 */
static void C_ccall f_1044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1044,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1047,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 75   register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[126]+1)))(3,*((C_word*)lf[126]+1),t2,lf[127]);}

/* k1045 in k1042 */
static void C_ccall f_1047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[80],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1047,2,t0,t1);}
t2=C_mutate(&lf[2] /* (set! check-block ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1049,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate(&lf[4] /* (set! check-generic-structure ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1122,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[8]+1 /* (set! check-pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1173,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1307,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp);
t6=lf[11];
t7=C_mutate((C_word*)lf[10]+1 /* (set! move-memory! ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1312,a[2]=t5,a[3]=t6,a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp));
t8=C_mutate((C_word*)lf[16]+1 /* (set! object-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1636,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[18]+1 /* (set! allocate ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1717,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[19]+1 /* (set! free ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1724,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[20]+1 /* (set! pointer? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1734,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[21]+1 /* (set! pointer-like? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1740,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[22]+1 /* (set! address->pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1746,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[25]+1 /* (set! pointer->address ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1755,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[28]+1 /* (set! null-pointer ...) */,*((C_word*)lf[29]+1));
t16=C_mutate((C_word*)lf[30]+1 /* (set! null-pointer? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1765,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[31]+1 /* (set! object->pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1778,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[32]+1 /* (set! pointer->object ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1784,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[33]+1 /* (set! pointer=? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1790,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[34]+1 /* (set! pointer-offset ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1799,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[35]+1 /* (set! align-to-word ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1819,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[37]+1 /* (set! tag-pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1851,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[39]+1 /* (set! tagged-pointer? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1866,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[40]+1 /* (set! pointer-tag ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1910,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[41]+1 /* (set! make-locative ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1928,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[43]+1 /* (set! make-weak-locative ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1957,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[44]+1 /* (set! locative-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1986,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1991,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)C_locative_ref,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 345  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[123]+1)))(4,*((C_word*)lf[123]+1),t28,t29,*((C_word*)lf[44]+1));}

/* k1989 in k1045 in k1042 */
static void C_ccall f_1991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[36],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1991,2,t0,t1);}
t2=C_mutate((C_word*)lf[45]+1 /* (set! locative-ref ...) */,t1);
t3=C_mutate((C_word*)lf[46]+1 /* (set! locative->object ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1993,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[47]+1 /* (set! locative? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1996,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[48]+1 /* (set! pointer-u8-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2002,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[49]+1 /* (set! pointer-s8-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2016,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[50]+1 /* (set! pointer-u16-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2030,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[51]+1 /* (set! pointer-s16-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2044,a[2]=((C_word)li40),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[52]+1 /* (set! pointer-u32-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2058,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[53]+1 /* (set! pointer-s32-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2072,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[54]+1 /* (set! pointer-f32-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2086,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[55]+1 /* (set! pointer-f64-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2100,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2116,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3203,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 362  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[123]+1)))(4,*((C_word*)lf[123]+1),t13,t14,*((C_word*)lf[48]+1));}

/* a3202 in k1989 in k1045 in k1042 */
static void C_ccall f_3203(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3203,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub551(C_SCHEME_UNDEFINED,t3));}

/* k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2116,2,t0,t1);}
t2=C_mutate((C_word*)lf[56]+1 /* (set! pointer-u8-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2120,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3193,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 367  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[123]+1)))(4,*((C_word*)lf[123]+1),t3,t4,*((C_word*)lf[49]+1));}

/* a3192 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_3193(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3193,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub557(C_SCHEME_UNDEFINED,t3));}

/* k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2120,2,t0,t1);}
t2=C_mutate((C_word*)lf[57]+1 /* (set! pointer-s8-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2124,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3183,a[2]=((C_word)li93),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 372  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[123]+1)))(4,*((C_word*)lf[123]+1),t3,t4,*((C_word*)lf[50]+1));}

/* a3182 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_3183(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3183,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub563(C_SCHEME_UNDEFINED,t3));}

/* k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2124,2,t0,t1);}
t2=C_mutate((C_word*)lf[58]+1 /* (set! pointer-u16-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2128,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3173,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 377  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[123]+1)))(4,*((C_word*)lf[123]+1),t3,t4,*((C_word*)lf[125]+1));}

/* a3172 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_3173(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3173,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub569(C_SCHEME_UNDEFINED,t3));}

/* k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2128,2,t0,t1);}
t2=C_mutate((C_word*)lf[59]+1 /* (set! pointer-s16-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2132,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3163,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 382  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[123]+1)))(4,*((C_word*)lf[123]+1),t3,t4,*((C_word*)lf[52]+1));}

/* a3162 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_3163(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3163,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub575(t3,t4));}

/* k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2132,2,t0,t1);}
t2=C_mutate((C_word*)lf[60]+1 /* (set! pointer-u32-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2136,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3153,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 387  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[123]+1)))(4,*((C_word*)lf[123]+1),t3,t4,*((C_word*)lf[53]+1));}

/* a3152 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_3153(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3153,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub582(t3,t4));}

/* k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2136,2,t0,t1);}
t2=C_mutate((C_word*)lf[61]+1 /* (set! pointer-s32-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2140,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3143,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 392  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[123]+1)))(4,*((C_word*)lf[123]+1),t3,t4,*((C_word*)lf[54]+1));}

/* a3142 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_3143(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3143,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub589(t3,t4));}

/* k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2140,2,t0,t1);}
t2=C_mutate((C_word*)lf[62]+1 /* (set! pointer-f32-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2144,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3133,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 397  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[123]+1)))(4,*((C_word*)lf[123]+1),t3,t4,*((C_word*)lf[55]+1));}

/* a3132 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_3133(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3133,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub596(t3,t4));}

/* k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2144,2,t0,t1);}
t2=C_mutate((C_word*)lf[63]+1 /* (set! pointer-f64-ref ...) */,t1);
t3=(C_word)C_a_i_vector(&a,1,lf[64]);
t4=C_mutate(&lf[65] /* (set! xproc-tag ...) */,t3);
t5=C_mutate((C_word*)lf[66]+1 /* (set! extend-procedure ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2150,a[2]=((C_word)li47),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[69]+1 /* (set! extended-procedure? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2185,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[71]+1 /* (set! procedure-data ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2216,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp));
t8=*((C_word*)lf[66]+1);
t9=C_mutate((C_word*)lf[72]+1 /* (set! set-procedure-data! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2250,a[2]=t8,a[3]=((C_word)li52),tmp=(C_word)a,a+=4,tmp));
t10=C_mutate((C_word*)lf[74]+1 /* (set! block-set! ...) */,*((C_word*)lf[75]+1));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2268,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 441  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[123]+1)))(4,*((C_word*)lf[123]+1),t11,*((C_word*)lf[124]+1),*((C_word*)lf[75]+1));}

/* k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2268,2,t0,t1);}
t2=C_mutate((C_word*)lf[76]+1 /* (set! block-ref ...) */,t1);
t3=C_mutate((C_word*)lf[77]+1 /* (set! number-of-slots ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2270,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[79]+1 /* (set! number-of-bytes ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2279,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[81]+1 /* (set! make-record-instance ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2301,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[83]+1 /* (set! record-instance? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2310,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[84]+1 /* (set! record-instance-type ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2354,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[85]+1 /* (set! record-instance-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2363,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[86]+1 /* (set! record-instance-slot-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2376,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2402,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3109,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 488  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[123]+1)))(4,*((C_word*)lf[123]+1),t10,t11,*((C_word*)lf[86]+1));}

/* a3108 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_3109(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3109,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3113,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 490  ##sys#check-generic-structure */
f_1122(t4,t2,(C_word)C_a_i_list(&a,1,lf[88]));}

/* k3111 in a3108 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_3113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3113,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3116,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
/* lolevel.scm: 491  ##sys#check-range */
((C_proc6)C_retrieve_proc(*((C_word*)lf[87]+1)))(6,*((C_word*)lf[87]+1),t2,((C_word*)t0)[4],C_fix(0),t4,lf[88]);}

/* k3114 in k3111 in a3108 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_3116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[39],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2402,2,t0,t1);}
t2=C_mutate((C_word*)lf[88]+1 /* (set! record-instance-slot ...) */,t1);
t3=C_mutate((C_word*)lf[89]+1 /* (set! record->vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2404,a[2]=((C_word)li61),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[90]+1 /* (set! object-evicted? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2442,a[2]=((C_word)li62),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[91]+1 /* (set! object-evict ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2445,a[2]=((C_word)li66),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[97]+1 /* (set! object-evict-to-location ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2563,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[109]+1 /* (set! object-release ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2727,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[110]+1 /* (set! object-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2819,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[111]+1 /* (set! object-unevict ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2903,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[113]+1 /* (set! object-become! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3032,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[116]+1 /* (set! mutate-procedure ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3041,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[117]+1 /* (set! global-ref ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3072,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[118]+1 /* (set! global-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3078,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[119]+1 /* (set! global-bound? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3087,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[121]+1 /* (set! global-make-unbound! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3096,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp));
t16=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_UNDEFINED);}

/* global-make-unbound! in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_3096(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3096,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[121]);
t4=(C_word)C_slot(lf[122],C_fix(0));
t5=(C_word)C_i_setslot(t2,C_fix(0),t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}

/* global-bound? in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_3087(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3087,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[119]);
/* lolevel.scm: 659  ##sys#symbol-has-toplevel-binding? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[120]+1)))(3,*((C_word*)lf[120]+1),t1,t2);}

/* global-set! in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_3078(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3078,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_symbol_2(t2,lf[118]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(0),t3));}

/* global-ref in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_3072(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3072,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[117]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_retrieve(t2));}

/* mutate-procedure in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_3041(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3041,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3045,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 638  ##sys#check-closure */
t5=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[116]);}

/* k3043 in mutate-procedure in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_3045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3045,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3048,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 639  ##sys#check-closure */
t3=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[116]);}

/* k3046 in k3043 in mutate-procedure in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_3048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3048,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_words(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3055,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 642  ##sys#make-vector */
t5=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k3053 in k3046 in k3043 in mutate-procedure in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_3055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3055,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3058,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3070,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 643  proc */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k3068 in k3053 in k3046 in k3043 in mutate-procedure in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_3070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3070,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
/* lolevel.scm: 643  ##sys#become! */
t4=*((C_word*)lf[114]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k3056 in k3053 in k3046 in k3043 in mutate-procedure in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_3058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* object-become! in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_3032(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3032,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3036,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_i_check_list_2(t4,lf[113]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1077,a[2]=t4,a[3]=t7,a[4]=((C_word)li80),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_1077(t9,t3,t4);}

/* loop in object-become! in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_fcall f_1077(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1077,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_check_pair_2(t4,lf[113]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1099,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t4);
/* lolevel.scm: 116  ##sys#check-block */
f_1049(t6,t7,(C_word)C_a_i_list(&a,1,lf[113]));}
else{
/* lolevel.scm: 120  ##sys#signal-hook */
t4=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[6],lf[113],lf[115],((C_word*)t0)[2]);}}}

/* k1097 in loop in object-become! in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_1099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1099,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1102,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* lolevel.scm: 117  ##sys#check-block */
f_1049(t2,t3,(C_word)C_a_i_list(&a,1,lf[113]));}

/* k1100 in k1097 in loop in object-become! in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_1102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* lolevel.scm: 118  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1077(t3,((C_word*)t0)[2],t2);}

/* k3034 in object-become! in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_3036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 635  ##sys#become! */
t2=*((C_word*)lf[114]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* object-unevict in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2903(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2903r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2903r(t0,t1,t2,t3);}}

static void C_ccall f_2903r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2907,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2907(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2907(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2905 in object-unevict in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2907,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2910,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 606  make-hash-table */
t3=*((C_word*)lf[95]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[96]+1));}

/* k2908 in k2905 in object-unevict in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2910,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2915,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word)li78),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2915(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* copy in k2908 in k2905 in object-unevict in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_fcall f_2915(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2915,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_permanentp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2931,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 610  hash-table-ref/default */
t4=*((C_word*)lf[94]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],t2,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2929 in copy in k2908 in k2905 in object-unevict in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2931,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[5]))){
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2944,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[5]);
/* lolevel.scm: 613  ##sys#make-string */
t4=*((C_word*)lf[112]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2960,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* lolevel.scm: 618  ##sys#intern-symbol */
C_string_to_symbol(3,0,t2,t3);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2974,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 623  ##sys#make-vector */
t4=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}}}}

/* k2972 in k2929 in copy in k2908 in k2905 in object-unevict in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2974,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2977,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 624  hash-table-set! */
t4=*((C_word*)lf[92]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[6],t2);}

/* k2975 in k2972 in k2929 in copy in k2908 in k2905 in object-unevict in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2980,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep((C_word)C_specialp(((C_word*)t0)[4]))?C_fix(1):C_fix(0));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2986,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word)li77),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_2986(t7,t2,t3);}

/* doloop921 in k2975 in k2972 in k2929 in copy in k2908 in k2905 in object-unevict in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_fcall f_2986(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2986,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3007,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
/* lolevel.scm: 627  copy */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2915(t5,t3,t4);}}

/* k3005 in doloop921 in k2975 in k2972 in k2929 in copy in k2908 in k2905 in object-unevict in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_3007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2986(t4,((C_word*)t0)[2],t3);}

/* k2978 in k2975 in k2972 in k2929 in copy in k2908 in k2905 in object-unevict in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2958 in k2929 in copy in k2908 in k2905 in object-unevict in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2963,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 619  hash-table-set! */
t3=*((C_word*)lf[92]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2961 in k2958 in k2929 in copy in k2908 in k2905 in object-unevict in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2942 in k2929 in copy in k2908 in k2905 in object-unevict in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2944,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2947,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 614  hash-table-set! */
t4=*((C_word*)lf[92]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[4],t2);}

/* k2945 in k2942 in k2929 in copy in k2908 in k2905 in object-unevict in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* object-size in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2819(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2819,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2823,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 589  make-hash-table */
t4=*((C_word*)lf[95]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[96]+1));}

/* k2821 in object-size in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2823,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2828,a[2]=t1,a[3]=t3,a[4]=((C_word)li75),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2828(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* evict in k2821 in object-size in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_fcall f_2828(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2828,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2841,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 592  hash-table-ref/default */
t4=*((C_word*)lf[94]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],t2,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(0));}}

/* k2839 in evict in k2821 in object-size in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2841,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2898,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
/* lolevel.scm: 596  align-to-word */
((C_proc3)C_retrieve_proc(*((C_word*)lf[35]+1)))(3,*((C_word*)lf[35]+1),t3,t2);}
else{
t4=t3;
f_2898(2,t4,(C_word)C_bytes(t2));}}}

/* k2896 in k2839 in evict in k2821 in object-size in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2898,2,t0,t1);}
t2=(C_word)C_fixnum_plus(t1,(C_word)C_bytes(C_fix(1)));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2850,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 598  hash-table-set! */
t6=*((C_word*)lf[92]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[2],((C_word*)t0)[5],C_SCHEME_TRUE);}

/* k2848 in k2896 in k2839 in evict in k2821 in object-size in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2850,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2853,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=t2;
f_2853(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_specialp(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_i_symbolp(((C_word*)t0)[4]));
t5=(C_truep(t4)?C_fix(1):C_fix(0));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2862,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word)li74),tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_2862(t9,t2,t5);}}

/* doloop871 in k2848 in k2896 in k2839 in evict in k2821 in object-size in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_fcall f_2862(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2862,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2884,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 602  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2828(t5,t3,t4);}}

/* k2882 in doloop871 in k2848 in k2896 in k2839 in evict in k2821 in object-size in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_plus(t1,((C_word*)((C_word*)t0)[5])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,t2);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_2862(t5,((C_word*)t0)[2],t4);}

/* k2851 in k2848 in k2896 in k2839 in evict in k2821 in object-size in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* object-release in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2727(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2727r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2727r(t0,t1,t2,t3);}}

static void C_ccall f_2727r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2809,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp));
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2736,a[2]=t9,a[3]=t5,a[4]=t7,a[5]=((C_word)li72),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_2736(t11,t1,t2);}

/* release in object-release in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_fcall f_2736(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2736,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_permanentp(t2))){
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[4])[1]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_block_size(t2);
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2765,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_byteblockp(t2))){
t7=t6;
f_2765(2,t7,C_SCHEME_UNDEFINED);}
else{
t7=(C_truep((C_word)C_specialp(t2))?C_fix(1):C_fix(0));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2781,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t9,a[5]=t3,a[6]=((C_word)li71),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_2781(t11,t6,t7);}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* doloop845 in release in object-release in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_fcall f_2781(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2781,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2791,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 585  release */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2736(t5,t3,t4);}}

/* k2789 in doloop845 in release in object-release in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2781(t3,((C_word*)t0)[2],t2);}

/* k2763 in release in object-release in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2765,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2772,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 586  ##sys#address->pointer */
t3=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,(C_word)C_block_address(&a,1,((C_word*)t0)[2]));}

/* k2770 in k2763 in release in object-release in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 586  free */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* f_2809 in object-release in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2809(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2809,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub829(C_SCHEME_UNDEFINED,t3));}

/* object-evict-to-location in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2563(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2563r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2563r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2563r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2567,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 533  ##sys#check-special */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[97]);}

/* k2565 in object-evict-to-location in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2567,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2570,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[2]))){
t3=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
t4=(C_word)C_i_check_exact_2(t3,lf[97]);
t5=t2;
f_2570(t5,t3);}
else{
t3=t2;
f_2570(t3,C_SCHEME_FALSE);}}

/* k2568 in k2565 in object-evict-to-location in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_fcall f_2570(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2570,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2573,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2716,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 538  ##sys#pointer->address */
t6=*((C_word*)lf[26]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k2714 in k2568 in k2565 in object-evict-to-location in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 538  ##sys#address->pointer */
t2=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2571 in k2568 in k2565 in object-evict-to-location in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2573,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2576,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 539  make-hash-table */
t3=*((C_word*)lf[95]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[96]+1));}

/* k2574 in k2571 in k2568 in k2565 in object-evict-to-location in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2576,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2579,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2584,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word)li68),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_2584(t6,t2,((C_word*)t0)[2]);}

/* evict in k2574 in k2571 in k2568 in k2565 in object-evict-to-location in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_fcall f_2584(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2584,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2594,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* lolevel.scm: 543  hash-table-ref/default */
t4=*((C_word*)lf[94]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],t2,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2592 in evict in k2574 in k2571 in k2568 in k2565 in object-evict-to-location in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2594,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2709,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[6]))){
/* lolevel.scm: 547  align-to-word */
((C_proc3)C_retrieve_proc(*((C_word*)lf[35]+1)))(3,*((C_word*)lf[35]+1),t3,t2);}
else{
t4=t3;
f_2709(2,t4,(C_word)C_bytes(t2));}}}

/* k2707 in k2592 in evict in k2574 in k2571 in k2568 in k2565 in object-evict-to-location in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2709,2,t0,t1);}
t2=(C_word)C_fixnum_plus(t1,(C_word)C_bytes(C_fix(1)));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2606,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[2])[1],t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[2])[1],C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2693,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2697,a[2]=((C_word*)t0)[2],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],((C_word*)((C_word*)t0)[2])[1]);
/* lolevel.scm: 554  make-property-condition */
t9=*((C_word*)lf[101]+1);
((C_proc9)(void*)(*((C_word*)t9+1)))(9,t9,t7,lf[104],lf[105],lf[97],lf[106],lf[107],lf[108],t8);}
else{
t6=t3;
f_2606(2,t6,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_2606(2,t4,C_SCHEME_UNDEFINED);}}

/* k2695 in k2707 in k2592 in evict in k2574 in k2571 in k2568 in k2565 in object-evict-to-location in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2697,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2701,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 558  make-property-condition */
t3=*((C_word*)lf[101]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[102],lf[103],((C_word*)((C_word*)t0)[2])[1]);}

/* k2699 in k2695 in k2707 in k2592 in evict in k2574 in k2571 in k2568 in k2565 in object-evict-to-location in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 553  make-composite-condition */
t2=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2691 in k2707 in k2592 in evict in k2574 in k2571 in k2568 in k2565 in object-evict-to-location in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 552  signal */
t2=*((C_word*)lf[99]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2604 in k2707 in k2592 in evict in k2574 in k2571 in k2568 in k2565 in object-evict-to-location in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2606,2,t0,t1);}
t2=(C_word)C_evict_block(((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2609,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[8]))){
t4=*((C_word*)lf[93]+1);
t5=t3;
f_2609(t5,(C_word)C_i_set_i_slot(t2,C_fix(0),t4));}
else{
t4=t3;
f_2609(t4,C_SCHEME_UNDEFINED);}}

/* k2607 in k2604 in k2707 in k2592 in evict in k2574 in k2571 in k2568 in k2565 in object-evict-to-location in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_fcall f_2609(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2609,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2612,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2666,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 561  ##sys#pointer->address */
t4=*((C_word*)lf[26]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k2664 in k2607 in k2604 in k2707 in k2592 in evict in k2574 in k2571 in k2568 in k2565 in object-evict-to-location in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2666,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,t1,((C_word*)t0)[4]);
/* lolevel.scm: 561  ##sys#set-pointer-address! */
t3=*((C_word*)lf[98]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2610 in k2607 in k2604 in k2707 in k2592 in evict in k2574 in k2571 in k2568 in k2565 in object-evict-to-location in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2612,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2615,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 562  hash-table-set! */
t3=*((C_word*)lf[92]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k2613 in k2610 in k2607 in k2604 in k2707 in k2592 in evict in k2574 in k2571 in k2568 in k2565 in object-evict-to-location in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2615,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2618,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=t2;
f_2618(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_specialp(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_i_symbolp(((C_word*)t0)[4]));
t5=(C_truep(t4)?C_fix(1):C_fix(0));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2627,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word)li67),tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_2627(t9,t2,t5);}}

/* doloop804 in k2613 in k2610 in k2607 in k2604 in k2707 in k2592 in evict in k2574 in k2571 in k2568 in k2565 in object-evict-to-location in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_fcall f_2627(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2627,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2648,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 566  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2584(t5,t3,t4);}}

/* k2646 in doloop804 in k2613 in k2610 in k2607 in k2604 in k2707 in k2592 in evict in k2574 in k2571 in k2568 in k2565 in object-evict-to-location in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2627(t4,((C_word*)t0)[2],t3);}

/* k2616 in k2613 in k2610 in k2607 in k2604 in k2707 in k2592 in evict in k2574 in k2571 in k2568 in k2565 in object-evict-to-location in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2577 in k2574 in k2571 in k2568 in k2565 in object-evict-to-location in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 568  values */
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* object-evict in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2445(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2445r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2445r(t0,t1,t2,t3);}}

static void C_ccall f_2445r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2556,a[2]=((C_word)li63),tmp=(C_word)a,a+=3,tmp));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2452,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 514  make-hash-table */
t7=*((C_word*)lf[95]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,*((C_word*)lf[96]+1));}

/* k2450 in object-evict in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2455,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 515  ##sys#check-closure */
t3=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],lf[91]);}

/* k2453 in k2450 in object-evict in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2455,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2460,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word)li65),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2460(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* evict in k2453 in k2450 in object-evict in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_fcall f_2460(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2460,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2470,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 518  hash-table-ref/default */
t4=*((C_word*)lf[94]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],t2,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2468 in evict in k2453 in k2450 in object-evict in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2470,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2479,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[5]))){
/* lolevel.scm: 521  align-to-word */
((C_proc3)C_retrieve_proc(*((C_word*)lf[35]+1)))(3,*((C_word*)lf[35]+1),t3,t2);}
else{
t4=t3;
f_2479(2,t4,(C_word)C_bytes(t2));}}}

/* k2477 in k2468 in evict in k2453 in k2450 in object-evict in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2479,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2483,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_fixnum_plus(t1,(C_word)C_bytes(C_fix(1)));
/* lolevel.scm: 522  allocator */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k2481 in k2477 in k2468 in evict in k2453 in k2450 in object-evict in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2483,2,t0,t1);}
t2=(C_word)C_evict_block(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2486,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[6]))){
t4=*((C_word*)lf[93]+1);
t5=t3;
f_2486(t5,(C_word)C_i_set_i_slot(t2,C_fix(0),t4));}
else{
t4=t3;
f_2486(t4,C_SCHEME_UNDEFINED);}}

/* k2484 in k2481 in k2477 in k2468 in evict in k2453 in k2450 in object-evict in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_fcall f_2486(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2486,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2489,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 524  hash-table-set! */
t3=*((C_word*)lf[92]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k2487 in k2484 in k2481 in k2477 in k2468 in evict in k2453 in k2450 in object-evict in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2492,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=t2;
f_2492(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_specialp(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_i_symbolp(((C_word*)t0)[4]));
t5=(C_truep(t4)?C_fix(1):C_fix(0));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2501,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word)li64),tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_2501(t9,t2,t5);}}

/* doloop744 in k2487 in k2484 in k2481 in k2477 in k2468 in evict in k2453 in k2450 in object-evict in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_fcall f_2501(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2501,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2522,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 529  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2460(t5,t3,t4);}}

/* k2520 in doloop744 in k2487 in k2484 in k2481 in k2477 in k2468 in evict in k2453 in k2450 in object-evict in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2501(t4,((C_word*)t0)[2],t3);}

/* k2490 in k2487 in k2484 in k2481 in k2477 in k2468 in evict in k2453 in k2450 in object-evict in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_2556 in object-evict in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2556(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2556,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub719(t3,t4));}

/* object-evicted? in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2442(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2442,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_permanentp(t2));}

/* record->vector in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2404(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2404,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2408,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 496  ##sys#check-generic-structure */
f_1122(t3,t2,(C_word)C_a_i_list(&a,1,lf[89]));}

/* k2406 in record->vector in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2408,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2414,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 498  ##sys#make-vector */
t4=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2412 in k2406 in record->vector in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2414,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2419,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word)li60),tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2419(t2,C_fix(0)));}

/* doloop703 in k2412 in k2406 in record->vector in k2400 in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static C_word C_fcall f_2419(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[2],t1);
t3=(C_word)C_i_setslot(((C_word*)t0)[3],t1,t2);
t4=(C_word)C_fixnum_plus(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}}

/* record-instance-slot-set! in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2376(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2376,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2380,a[2]=t4,a[3]=t2,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 483  ##sys#check-generic-structure */
f_1122(t5,t2,(C_word)C_a_i_list(&a,1,lf[86]));}

/* k2378 in record-instance-slot-set! in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2383,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[3]);
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
/* lolevel.scm: 484  ##sys#check-range */
((C_proc6)C_retrieve_proc(*((C_word*)lf[87]+1)))(6,*((C_word*)lf[87]+1),t2,((C_word*)t0)[5],C_fix(0),t4,lf[86]);}

/* k2381 in k2378 in record-instance-slot-set! in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(((C_word*)t0)[3],t2,((C_word*)t0)[2]));}

/* record-instance-length in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2363(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2363,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2367,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 479  ##sys#check-generic-structure */
f_1122(t3,t2,(C_word)C_a_i_list(&a,1,lf[85]));}

/* k2365 in record-instance-length in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_difference(t2,C_fix(1)));}

/* record-instance-type in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2354(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2354,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2358,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 475  ##sys#check-generic-structure */
f_1122(t3,t2,(C_word)C_a_i_list(&a,1,lf[84]));}

/* k2356 in record-instance-type in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(0)));}

/* record-instance? in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2310(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2310r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2310r(t0,t1,t2,t3);}}

static void C_ccall f_2310r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2314,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2314(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2314(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2312 in record-instance? in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_truep((C_word)C_blockp(t2))?(C_word)C_structurep(t2):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(C_word)C_i_not(t1);
if(C_truep(t4)){
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t1,t5));}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* make-record-instance in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2301(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_2301r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2301r(t0,t1,t2,t3);}}

static void C_ccall f_2301r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
t4=(C_word)C_i_check_symbol_2(t2,lf[81]);
C_apply(5,0,t1,*((C_word*)lf[82]+1),t2,t3);}

/* number-of-bytes in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2279(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2279,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_byteblockp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_block_size(t2));}
else{
t3=(C_word)C_block_size(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_w2b(t3));}}
else{
/* lolevel.scm: 449  ##sys#signal-hook */
t3=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t1,lf[6],lf[79],lf[80],t2);}}

/* number-of-slots in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2270(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2270,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2274,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_a_i_list(&a,1,lf[77]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1151,a[2]=t4,a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_blockp(t4))){
t7=(C_word)C_specialp(t4);
t8=(C_truep(t7)?t7:(C_word)C_byteblockp(t4));
t9=t6;
f_1151(t9,(C_word)C_i_not(t8));}
else{
t7=t6;
f_1151(t7,C_SCHEME_FALSE);}}

/* k1149 in number-of-slots in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_fcall f_1151(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_2274(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_i_pairp(((C_word*)t0)[3]);
t3=(C_truep(t2)?(C_word)C_i_car(((C_word*)t0)[3]):C_SCHEME_FALSE);
/* lolevel.scm: 134  ##sys#signal-hook */
t4=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,((C_word*)t0)[4],lf[6],t3,lf[78],((C_word*)t0)[2]);}}

/* k2272 in number-of-slots in k2266 in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_block_size(((C_word*)t0)[2]));}

/* set-procedure-data! in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2250(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2250,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2254,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 430  extend-procedure */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,t3);}

/* k2252 in set-procedure-data! in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(t1,((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
/* lolevel.scm: 433  ##sys#signal-hook */
t3=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[2],lf[6],lf[72],lf[73],((C_word*)t0)[3]);}}

/* procedure-data in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2216(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2216,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_closurep(t2))){
t3=t2;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2226,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2234,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 415  ##sys#lambda-decoration */
t6=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t3,t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a2233 in procedure-data in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2234(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2234,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[65],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2224 in procedure-data in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_slot(t1,C_fix(1)):C_SCHEME_FALSE));}

/* extended-procedure? in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2185(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2185,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_closurep(t2))){
t3=t2;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2198,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2200,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 415  ##sys#lambda-decoration */
t6=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t3,t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a2199 in extended-procedure? in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2200(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2200,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[65],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2196 in extended-procedure? in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* extend-procedure in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2150(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2150,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2154,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 408  ##sys#check-closure */
t5=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[66]);}

/* k2152 in extend-procedure in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2154,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2159,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2175,a[2]=((C_word*)t0)[4],a[3]=((C_word)li46),tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 409  ##sys#decorate-lambda */
t4=*((C_word*)lf[67]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a2174 in k2152 in extend-procedure in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2175(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2175,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,lf[65],((C_word*)t0)[2]);
t5=(C_word)C_i_setslot(t2,t3,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}

/* a2158 in k2152 in extend-procedure in k2142 in k2138 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k1989 in k1045 in k1042 */
static void C_ccall f_2159(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2159,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[65],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* pointer-f64-set! in k1989 in k1045 in k1042 */
static void C_ccall f_2100(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2100,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_flonum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub544(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-f32-set! in k1989 in k1045 in k1042 */
static void C_ccall f_2086(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2086,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_flonum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub536(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-s32-set! in k1989 in k1045 in k1042 */
static void C_ccall f_2072(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2072,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub528(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-u32-set! in k1989 in k1045 in k1042 */
static void C_ccall f_2058(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2058,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub520(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-s16-set! in k1989 in k1045 in k1042 */
static void C_ccall f_2044(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2044,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub512(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-u16-set! in k1989 in k1045 in k1042 */
static void C_ccall f_2030(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2030,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub504(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-s8-set! in k1989 in k1045 in k1042 */
static void C_ccall f_2016(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2016,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub496(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-u8-set! in k1989 in k1045 in k1042 */
static void C_ccall f_2002(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2002,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub488(C_SCHEME_UNDEFINED,t4,t5));}

/* locative? in k1989 in k1045 in k1042 */
static void C_ccall f_1996(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1996,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_locativep(t2):C_SCHEME_FALSE));}

/* locative->object in k1989 in k1045 in k1042 */
static void C_ccall f_1993(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1993,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_locative_to_object(t2));}

/* locative-set! in k1045 in k1042 */
static void C_ccall f_1986(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1986,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_locative_set(t2,t3));}

/* make-weak-locative in k1045 in k1042 */
static void C_ccall f_1957(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1957r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1957r(t0,t1,t2,t3);}}

static void C_ccall f_1957r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1965,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_1965(2,t5,C_fix(0));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_1965(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1963 in make-weak-locative in k1045 in k1042 */
static void C_ccall f_1965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 342  ##sys#make-locative */
t2=*((C_word*)lf[42]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_TRUE,lf[43]);}

/* make-locative in k1045 in k1042 */
static void C_ccall f_1928(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1928r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1928r(t0,t1,t2,t3);}}

static void C_ccall f_1928r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1936,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_1936(2,t5,C_fix(0));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_1936(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1934 in make-locative in k1045 in k1042 */
static void C_ccall f_1936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 339  ##sys#make-locative */
t2=*((C_word*)lf[42]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE,lf[41]);}

/* pointer-tag in k1045 in k1042 */
static void C_ccall f_1910(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1910,3,t0,t1,t2);}
t3=t2;
t4=(C_truep((C_word)C_blockp(t3))?(C_word)C_specialp(t3):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep((C_word)C_taggedpointerp(t2))?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
/* lolevel.scm: 316  ##sys#error-hook */
t5=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_POINTER_ERROR),lf[40],t2);}}

/* tagged-pointer? in k1045 in k1042 */
static void C_ccall f_1866(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1866r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1866r(t0,t1,t2,t3);}}

static void C_ccall f_1866r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1870,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_1870(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_1870(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1868 in tagged-pointer? in k1045 in k1042 */
static void C_ccall f_1870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep((C_word)C_blockp(((C_word*)t0)[3]))){
if(C_truep((C_word)C_taggedpointerp(((C_word*)t0)[3]))){
t2=(C_word)C_i_not(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_equalp(t1,t3));}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* tag-pointer in k1045 in k1042 */
static void C_ccall f_1851(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1851,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1855,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 301  ##sys#make-tagged-pointer */
t5=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k1853 in tag-pointer in k1045 in k1042 */
static void C_ccall f_1855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1858,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_truep((C_word)C_blockp(t3))?(C_word)C_specialp(t3):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t2;
f_1858(2,t5,(C_word)C_copy_pointer(((C_word*)t0)[2],t1));}
else{
/* lolevel.scm: 304  ##sys#error-hook */
t5=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_POINTER_ERROR),lf[37],((C_word*)t0)[2]);}}

/* k1856 in k1853 in tag-pointer in k1045 in k1042 */
static void C_ccall f_1858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* align-to-word in k1045 in k1042 */
static void C_ccall f_1819(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1819,3,t0,t1,t2);}
if(C_truep((C_word)C_i_integerp(t2))){
t3=t1;
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t6=(C_word)C_i_foreign_integer_argumentp(t4);
t7=t3;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)stub405(t5,t6));}
else{
t3=t2;
t4=(C_truep((C_word)C_blockp(t3))?(C_word)C_specialp(t3):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1846,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 291  ##sys#pointer->address */
t6=*((C_word*)lf[26]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
/* lolevel.scm: 293  ##sys#signal-hook */
t5=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,lf[6],lf[35],lf[36],t2);}}}

/* k1844 in align-to-word in k1045 in k1042 */
static void C_ccall f_1846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1846,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t3=(C_word)C_i_foreign_integer_argumentp(t1);
t4=(C_word)stub405(t2,t3);
/* lolevel.scm: 291  ##sys#address->pointer */
t5=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,((C_word*)t0)[2],t4);}

/* pointer-offset in k1045 in k1042 */
static void C_ccall f_1799(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1799,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_integer_argumentp(t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)stub396(t4,t5,t6));}

/* pointer=? in k1045 in k1042 */
static void C_ccall f_1790(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1790,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1794,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 277  ##sys#check-special */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[33]);}

/* k1792 in pointer=? in k1045 in k1042 */
static void C_ccall f_1794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1794,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1797,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 278  ##sys#check-special */
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[33]);}

/* k1795 in k1792 in pointer=? in k1045 in k1042 */
static void C_ccall f_1797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_pointer_eqp(((C_word*)t0)[3],((C_word*)t0)[2]));}

/* pointer->object in k1045 in k1042 */
static void C_ccall f_1784(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1784,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1788,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 273  ##sys#check-pointer */
t4=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[32]);}

/* k1786 in pointer->object in k1045 in k1042 */
static void C_ccall f_1788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_pointer_to_object(((C_word*)t0)[2]));}

/* object->pointer in k1045 in k1042 */
static void C_ccall f_1778(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1778,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=t2;
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub382(t4,t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* null-pointer? in k1045 in k1042 */
static void C_ccall f_1765(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1765,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1769,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 265  ##sys#check-special */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[30]);}

/* k1767 in null-pointer? in k1045 in k1042 */
static void C_ccall f_1769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1769,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1776,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 266  ##sys#pointer->address */
t3=*((C_word*)lf[26]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1774 in k1767 in null-pointer? in k1045 in k1042 */
static void C_ccall f_1776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(C_fix(0),t1));}

/* pointer->address in k1045 in k1042 */
static void C_ccall f_1755(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1755,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1759,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 259  ##sys#check-special */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[25]);}

/* k1757 in pointer->address in k1045 in k1042 */
static void C_ccall f_1759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 260  ##sys#pointer->address */
t2=*((C_word*)lf[26]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* address->pointer in k1045 in k1042 */
static void C_ccall f_1746(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1746,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1750,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 255  ##sys#check-integer */
t4=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[22]);}

/* k1748 in address->pointer in k1045 in k1042 */
static void C_ccall f_1750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 256  ##sys#address->pointer */
t2=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pointer-like? in k1045 in k1042 */
static void C_ccall f_1740(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1740,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_specialp(t2):C_SCHEME_FALSE));}

/* pointer? in k1045 in k1042 */
static void C_ccall f_1734(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1734,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_anypointerp(t2):C_SCHEME_FALSE));}

/* free in k1045 in k1042 */
static void C_ccall f_1724(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1724,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub353(C_SCHEME_UNDEFINED,t3));}

/* allocate in k1045 in k1042 */
static void C_ccall f_1717(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1717,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub348(t3,t4));}

/* object-copy in k1045 in k1042 */
static void C_ccall f_1636(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1636,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1642,a[2]=t4,a[3]=((C_word)li15),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_1642(t6,t1,t2);}

/* copy in object-copy in k1045 in k1042 */
static void C_fcall f_1642(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1642,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_slot(t2,C_fix(1));
/* lolevel.scm: 233  ##sys#intern-symbol */
C_string_to_symbol(3,0,t1,t3);}
else{
t3=(C_word)C_block_size(t2);
t4=(C_truep((C_word)C_byteblockp(t2))?(C_word)C_words(t3):t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1672,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 237  ##sys#make-vector */
t6=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1670 in copy in object-copy in k1045 in k1042 */
static void C_ccall f_1672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1672,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1675,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_byteblockp(((C_word*)t0)[5]);
t5=(C_truep(t4)?t4:(C_word)C_i_symbolp(((C_word*)t0)[5]));
if(C_truep(t5)){
t6=t3;
f_1675(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_truep((C_word)C_specialp(((C_word*)t0)[5]))?C_fix(1):C_fix(0));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1687,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word)li14),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_1687(t10,t3,t6);}}

/* doloop338 in k1670 in copy in object-copy in k1045 in k1042 */
static void C_fcall f_1687(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1687,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1708,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
/* lolevel.scm: 241  copy */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1642(t5,t3,t4);}}

/* k1706 in doloop338 in k1670 in copy in object-copy in k1045 in k1042 */
static void C_ccall f_1708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_1687(t4,((C_word*)t0)[2],t3);}

/* k1673 in k1670 in copy in object-copy in k1045 in k1042 */
static void C_ccall f_1675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* move-memory! in k1045 in k1042 */
static void C_ccall f_1312(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr4r,(void*)f_1312r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1312r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1312r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(19);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1314,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word)li9),tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1563,a[2]=t5,a[3]=((C_word)li10),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1568,a[2]=t6,a[3]=((C_word)li11),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1573,a[2]=t7,a[3]=((C_word)li12),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-n179309 */
t9=t8;
f_1573(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-foffset180307 */
t11=t7;
f_1568(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-toffset181304 */
t13=t6;
f_1563(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body177186 */
t15=t5;
f_1314(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}}}}

/* def-n179 in move-memory! in k1045 in k1042 */
static void C_fcall f_1573(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1573,NULL,2,t0,t1);}
/* def-foffset180307 */
t2=((C_word*)t0)[2];
f_1568(t2,t1,C_SCHEME_FALSE);}

/* def-foffset180 in move-memory! in k1045 in k1042 */
static void C_fcall f_1568(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1568,NULL,3,t0,t1,t2);}
/* def-toffset181304 */
t3=((C_word*)t0)[2];
f_1563(t3,t1,t2,C_fix(0));}

/* def-toffset181 in move-memory! in k1045 in k1042 */
static void C_fcall f_1563(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1563,NULL,4,t0,t1,t2,t3);}
/* body177186 */
t4=((C_word*)t0)[2];
f_1314(t4,t1,t2,t3,C_fix(0));}

/* body177 in move-memory! in k1045 in k1042 */
static void C_fcall f_1314(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1314,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1317,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word)li4),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1323,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word)li5),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1329,a[2]=t6,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1345,a[2]=t6,a[3]=((C_word)li7),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1372,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t8,a[6]=t7,a[7]=t5,a[8]=t3,a[9]=t4,a[10]=t2,a[11]=((C_word*)t0)[2],a[12]=((C_word*)t0)[3],tmp=(C_word)a,a+=13,tmp);
/* lolevel.scm: 197  ##sys#check-block */
f_1049(t9,((C_word*)t0)[5],(C_word)C_a_i_list(&a,1,lf[10]));}

/* k1370 in body177 in move-memory! in k1045 in k1042 */
static void C_ccall f_1372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1375,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* lolevel.scm: 198  ##sys#check-block */
f_1049(t2,((C_word*)t0)[2],(C_word)C_a_i_list(&a,1,lf[10]));}

/* k1373 in k1370 in body177 in move-memory! in k1045 in k1042 */
static void C_ccall f_1375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1375,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1380,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=t3,a[10]=((C_word*)t0)[12],a[11]=((C_word)li8),tmp=(C_word)a,a+=12,tmp));
t5=((C_word*)t3)[1];
f_1380(t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* move in k1373 in k1370 in body177 in move-memory! in k1045 in k1042 */
static void C_fcall f_1380(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(11);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1380,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_structurep(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
if(C_truep((C_word)C_i_memq(t4,((C_word*)t0)[10]))){
t5=(C_word)C_slot(t2,C_fix(1));
/* lolevel.scm: 202  move */
t19=t1;
t20=t5;
t21=t3;
t1=t19;
t2=t20;
t3=t21;
goto loop;}
else{
/* lolevel.scm: 203  typerr */
f_1307(t1,t2);}}
else{
if(C_truep((C_word)C_structurep(t3))){
t4=(C_word)C_slot(t3,C_fix(0));
if(C_truep((C_word)C_i_memq(t4,((C_word*)t0)[10]))){
t5=(C_word)C_slot(t3,C_fix(1));
/* lolevel.scm: 206  move */
t19=t1;
t20=t2;
t21=t5;
t1=t19;
t2=t20;
t3=t21;
goto loop;}
else{
/* lolevel.scm: 207  typerr */
f_1307(t1,t3);}}
else{
t4=t2;
t5=(C_truep((C_word)C_blockp(t4))?(C_word)C_anypointerp(t4):C_SCHEME_FALSE);
t6=(C_truep(t5)?t5:(C_word)C_locativep(t4));
if(C_truep(t6)){
t7=t3;
t8=(C_truep((C_word)C_blockp(t7))?(C_word)C_anypointerp(t7):C_SCHEME_FALSE);
t9=(C_truep(t8)?t8:(C_word)C_locativep(t7));
if(C_truep(t9)){
t10=((C_word*)t0)[7];
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1458,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t10)){
t12=t11;
f_1458(2,t12,t10);}
else{
/* lolevel.scm: 210  nosizerr */
t12=((C_word*)t0)[4];
f_1317(t12,t11);}}
else{
t10=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1467,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=t1,a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* lolevel.scm: 211  ##sys#bytevector? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t10,t3);}}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1500,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=t3,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
/* lolevel.scm: 215  ##sys#bytevector? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t7,t2);}}}}

/* k1498 in move in k1373 in k1370 in body177 in move-memory! in k1045 in k1042 */
static void C_ccall f_1500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1500,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[10]));
if(C_truep(t2)){
t3=(C_word)C_block_size(((C_word*)t0)[10]);
t4=((C_word*)t0)[9];
t5=(C_truep((C_word)C_blockp(t4))?(C_word)C_anypointerp(t4):C_SCHEME_FALSE);
t6=(C_truep(t5)?t5:(C_word)C_locativep(t4));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1522,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t8=((C_word*)t0)[5];
t9=(C_truep(t8)?t8:t3);
/* lolevel.scm: 218  checkn1 */
t10=((C_word*)t0)[4];
f_1329(t10,t7,t9,t3,((C_word*)t0)[6]);}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1532,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* lolevel.scm: 219  ##sys#bytevector? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t7,((C_word*)t0)[9]);}}
else{
/* lolevel.scm: 225  typerr */
f_1307(((C_word*)t0)[8],((C_word*)t0)[10]);}}

/* k1530 in k1498 in move in k1373 in k1370 in body177 in move-memory! in k1045 in k1042 */
static void C_ccall f_1532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1532,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[10]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1542,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[5];
t5=(C_truep(t4)?t4:((C_word*)t0)[4]);
t6=(C_word)C_block_size(((C_word*)t0)[10]);
/* lolevel.scm: 220  checkn2 */
t7=((C_word*)t0)[3];
f_1345(t7,t3,t5,((C_word*)t0)[4],t6,((C_word*)t0)[6],((C_word*)t0)[7]);}
else{
/* lolevel.scm: 223  typerr */
f_1307(((C_word*)t0)[9],((C_word*)t0)[10]);}}

/* k1540 in k1530 in k1498 in move in k1373 in k1370 in body177 in move-memory! in k1045 in k1042 */
static void C_ccall f_1542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?(C_word)C_i_foreign_block_argumentp(t4):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_fixnum_argumentp(t1);
t10=(C_word)C_i_foreign_fixnum_argumentp(t5);
t11=(C_word)C_i_foreign_fixnum_argumentp(t6);
t12=t2;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)stub147(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* k1520 in k1498 in move in k1373 in k1370 in body177 in move-memory! in k1045 in k1042 */
static void C_ccall f_1522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?(C_word)C_i_foreign_block_argumentp(t4):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_fixnum_argumentp(t1);
t10=(C_word)C_i_foreign_fixnum_argumentp(t5);
t11=(C_word)C_i_foreign_fixnum_argumentp(t6);
t12=t2;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)stub115(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* k1465 in move in k1373 in k1370 in body177 in move-memory! in k1045 in k1042 */
static void C_ccall f_1467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1467,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[10]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1477,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[5];
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1481,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_1481(2,t6,t4);}
else{
/* lolevel.scm: 212  nosizerr */
t6=((C_word*)t0)[3];
f_1317(t6,t5);}}
else{
/* lolevel.scm: 214  typerr */
f_1307(((C_word*)t0)[9],((C_word*)t0)[10]);}}

/* k1479 in k1465 in move in k1373 in k1370 in body177 in move-memory! in k1045 in k1042 */
static void C_ccall f_1481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[5]);
/* lolevel.scm: 212  checkn1 */
t3=((C_word*)t0)[4];
f_1329(t3,((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}

/* k1475 in k1465 in move in k1373 in k1370 in body177 in move-memory! in k1045 in k1042 */
static void C_ccall f_1477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?(C_word)C_i_foreign_pointer_argumentp(t4):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_fixnum_argumentp(t1);
t10=(C_word)C_i_foreign_fixnum_argumentp(t5);
t11=(C_word)C_i_foreign_fixnum_argumentp(t6);
t12=t2;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)stub131(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* k1456 in move in k1373 in k1370 in body177 in move-memory! in k1045 in k1042 */
static void C_ccall f_1458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?(C_word)C_i_foreign_pointer_argumentp(t4):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_fixnum_argumentp(t1);
t10=(C_word)C_i_foreign_fixnum_argumentp(t5);
t11=(C_word)C_i_foreign_fixnum_argumentp(t6);
t12=t2;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)stub99(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* checkn2 in body177 in move-memory! in k1045 in k1042 */
static void C_fcall f_1345(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1345,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1352,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_fixnum_difference(t3,t5);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,t8))){
t9=(C_word)C_fixnum_difference(t4,t6);
t10=t7;
f_1352(t10,(C_word)C_fixnum_less_or_equal_p(t2,t9));}
else{
t9=t7;
f_1352(t9,C_SCHEME_FALSE);}}

/* k1350 in checkn2 in body177 in move-memory! in k1045 in k1042 */
static void C_fcall f_1352(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1352,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
/* lolevel.scm: 195  sizerr */
t2=((C_word*)t0)[4];
f_1323(t2,((C_word*)t0)[6],(C_word)C_a_i_list(&a,3,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]));}}

/* checkn1 in body177 in move-memory! in k1045 in k1042 */
static void C_fcall f_1329(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1329,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_difference(t3,t4);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}
else{
/* lolevel.scm: 190  sizerr */
t6=((C_word*)t0)[2];
f_1323(t6,t1,(C_word)C_a_i_list(&a,2,t2,t3));}}

/* sizerr in body177 in move-memory! in k1045 in k1042 */
static void C_fcall f_1323(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1323,NULL,3,t0,t1,t2);}
C_apply(8,0,t1,*((C_word*)lf[12]+1),lf[10],lf[14],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* nosizerr in body177 in move-memory! in k1045 in k1042 */
static void C_fcall f_1317(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1317,NULL,2,t0,t1);}
/* lolevel.scm: 182  ##sys#error */
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,lf[10],lf[13],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* typerr in k1045 in k1042 */
static void C_fcall f_1307(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1307,NULL,2,t1,t2);}
/* lolevel.scm: 173  ##sys#error-hook */
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,C_fix((C_word)C_BAD_ARGUMENT_TYPE_ERROR),lf[10],t2);}

/* ##sys#check-pointer in k1045 in k1042 */
static void C_ccall f_1173(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1173r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1173r(t0,t1,t2,t3);}}

static void C_ccall f_1173r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
t4=t2;
t5=(C_truep((C_word)C_blockp(t4))?(C_word)C_anypointerp(t4):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_word)C_notvemptyp(t3);
t7=(C_truep(t6)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_FALSE);
/* lolevel.scm: 140  ##sys#error-hook */
t8=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t1,C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_POINTER_ERROR),t7,lf[9],t2);}}

/* ##sys#check-generic-structure in k1045 in k1042 */
static void C_fcall f_1122(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1122,NULL,3,t1,t2,t3);}
t4=t2;
t5=(C_truep((C_word)C_blockp(t4))?(C_word)C_structurep(t4):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_word)C_i_pairp(t3);
t7=(C_truep(t6)?(C_word)C_i_car(t3):C_SCHEME_FALSE);
/* lolevel.scm: 126  ##sys#signal-hook */
t8=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t1,lf[6],t7,lf[7],t2);}}

/* ##sys#check-block in k1045 in k1042 */
static void C_fcall f_1049(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1049,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_blockp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_i_pairp(t3);
t5=(C_truep(t4)?(C_word)C_i_car(t3):C_SCHEME_FALSE);
/* lolevel.scm: 105  ##sys#error-hook */
t6=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_BLOCK_ERROR),t5,t2);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[208] = {
{"toplevel:lolevel_scm",(void*)C_lolevel_toplevel},
{"f_1044:lolevel_scm",(void*)f_1044},
{"f_1047:lolevel_scm",(void*)f_1047},
{"f_1991:lolevel_scm",(void*)f_1991},
{"f_3203:lolevel_scm",(void*)f_3203},
{"f_2116:lolevel_scm",(void*)f_2116},
{"f_3193:lolevel_scm",(void*)f_3193},
{"f_2120:lolevel_scm",(void*)f_2120},
{"f_3183:lolevel_scm",(void*)f_3183},
{"f_2124:lolevel_scm",(void*)f_2124},
{"f_3173:lolevel_scm",(void*)f_3173},
{"f_2128:lolevel_scm",(void*)f_2128},
{"f_3163:lolevel_scm",(void*)f_3163},
{"f_2132:lolevel_scm",(void*)f_2132},
{"f_3153:lolevel_scm",(void*)f_3153},
{"f_2136:lolevel_scm",(void*)f_2136},
{"f_3143:lolevel_scm",(void*)f_3143},
{"f_2140:lolevel_scm",(void*)f_2140},
{"f_3133:lolevel_scm",(void*)f_3133},
{"f_2144:lolevel_scm",(void*)f_2144},
{"f_2268:lolevel_scm",(void*)f_2268},
{"f_3109:lolevel_scm",(void*)f_3109},
{"f_3113:lolevel_scm",(void*)f_3113},
{"f_3116:lolevel_scm",(void*)f_3116},
{"f_2402:lolevel_scm",(void*)f_2402},
{"f_3096:lolevel_scm",(void*)f_3096},
{"f_3087:lolevel_scm",(void*)f_3087},
{"f_3078:lolevel_scm",(void*)f_3078},
{"f_3072:lolevel_scm",(void*)f_3072},
{"f_3041:lolevel_scm",(void*)f_3041},
{"f_3045:lolevel_scm",(void*)f_3045},
{"f_3048:lolevel_scm",(void*)f_3048},
{"f_3055:lolevel_scm",(void*)f_3055},
{"f_3070:lolevel_scm",(void*)f_3070},
{"f_3058:lolevel_scm",(void*)f_3058},
{"f_3032:lolevel_scm",(void*)f_3032},
{"f_1077:lolevel_scm",(void*)f_1077},
{"f_1099:lolevel_scm",(void*)f_1099},
{"f_1102:lolevel_scm",(void*)f_1102},
{"f_3036:lolevel_scm",(void*)f_3036},
{"f_2903:lolevel_scm",(void*)f_2903},
{"f_2907:lolevel_scm",(void*)f_2907},
{"f_2910:lolevel_scm",(void*)f_2910},
{"f_2915:lolevel_scm",(void*)f_2915},
{"f_2931:lolevel_scm",(void*)f_2931},
{"f_2974:lolevel_scm",(void*)f_2974},
{"f_2977:lolevel_scm",(void*)f_2977},
{"f_2986:lolevel_scm",(void*)f_2986},
{"f_3007:lolevel_scm",(void*)f_3007},
{"f_2980:lolevel_scm",(void*)f_2980},
{"f_2960:lolevel_scm",(void*)f_2960},
{"f_2963:lolevel_scm",(void*)f_2963},
{"f_2944:lolevel_scm",(void*)f_2944},
{"f_2947:lolevel_scm",(void*)f_2947},
{"f_2819:lolevel_scm",(void*)f_2819},
{"f_2823:lolevel_scm",(void*)f_2823},
{"f_2828:lolevel_scm",(void*)f_2828},
{"f_2841:lolevel_scm",(void*)f_2841},
{"f_2898:lolevel_scm",(void*)f_2898},
{"f_2850:lolevel_scm",(void*)f_2850},
{"f_2862:lolevel_scm",(void*)f_2862},
{"f_2884:lolevel_scm",(void*)f_2884},
{"f_2853:lolevel_scm",(void*)f_2853},
{"f_2727:lolevel_scm",(void*)f_2727},
{"f_2736:lolevel_scm",(void*)f_2736},
{"f_2781:lolevel_scm",(void*)f_2781},
{"f_2791:lolevel_scm",(void*)f_2791},
{"f_2765:lolevel_scm",(void*)f_2765},
{"f_2772:lolevel_scm",(void*)f_2772},
{"f_2809:lolevel_scm",(void*)f_2809},
{"f_2563:lolevel_scm",(void*)f_2563},
{"f_2567:lolevel_scm",(void*)f_2567},
{"f_2570:lolevel_scm",(void*)f_2570},
{"f_2716:lolevel_scm",(void*)f_2716},
{"f_2573:lolevel_scm",(void*)f_2573},
{"f_2576:lolevel_scm",(void*)f_2576},
{"f_2584:lolevel_scm",(void*)f_2584},
{"f_2594:lolevel_scm",(void*)f_2594},
{"f_2709:lolevel_scm",(void*)f_2709},
{"f_2697:lolevel_scm",(void*)f_2697},
{"f_2701:lolevel_scm",(void*)f_2701},
{"f_2693:lolevel_scm",(void*)f_2693},
{"f_2606:lolevel_scm",(void*)f_2606},
{"f_2609:lolevel_scm",(void*)f_2609},
{"f_2666:lolevel_scm",(void*)f_2666},
{"f_2612:lolevel_scm",(void*)f_2612},
{"f_2615:lolevel_scm",(void*)f_2615},
{"f_2627:lolevel_scm",(void*)f_2627},
{"f_2648:lolevel_scm",(void*)f_2648},
{"f_2618:lolevel_scm",(void*)f_2618},
{"f_2579:lolevel_scm",(void*)f_2579},
{"f_2445:lolevel_scm",(void*)f_2445},
{"f_2452:lolevel_scm",(void*)f_2452},
{"f_2455:lolevel_scm",(void*)f_2455},
{"f_2460:lolevel_scm",(void*)f_2460},
{"f_2470:lolevel_scm",(void*)f_2470},
{"f_2479:lolevel_scm",(void*)f_2479},
{"f_2483:lolevel_scm",(void*)f_2483},
{"f_2486:lolevel_scm",(void*)f_2486},
{"f_2489:lolevel_scm",(void*)f_2489},
{"f_2501:lolevel_scm",(void*)f_2501},
{"f_2522:lolevel_scm",(void*)f_2522},
{"f_2492:lolevel_scm",(void*)f_2492},
{"f_2556:lolevel_scm",(void*)f_2556},
{"f_2442:lolevel_scm",(void*)f_2442},
{"f_2404:lolevel_scm",(void*)f_2404},
{"f_2408:lolevel_scm",(void*)f_2408},
{"f_2414:lolevel_scm",(void*)f_2414},
{"f_2419:lolevel_scm",(void*)f_2419},
{"f_2376:lolevel_scm",(void*)f_2376},
{"f_2380:lolevel_scm",(void*)f_2380},
{"f_2383:lolevel_scm",(void*)f_2383},
{"f_2363:lolevel_scm",(void*)f_2363},
{"f_2367:lolevel_scm",(void*)f_2367},
{"f_2354:lolevel_scm",(void*)f_2354},
{"f_2358:lolevel_scm",(void*)f_2358},
{"f_2310:lolevel_scm",(void*)f_2310},
{"f_2314:lolevel_scm",(void*)f_2314},
{"f_2301:lolevel_scm",(void*)f_2301},
{"f_2279:lolevel_scm",(void*)f_2279},
{"f_2270:lolevel_scm",(void*)f_2270},
{"f_1151:lolevel_scm",(void*)f_1151},
{"f_2274:lolevel_scm",(void*)f_2274},
{"f_2250:lolevel_scm",(void*)f_2250},
{"f_2254:lolevel_scm",(void*)f_2254},
{"f_2216:lolevel_scm",(void*)f_2216},
{"f_2234:lolevel_scm",(void*)f_2234},
{"f_2226:lolevel_scm",(void*)f_2226},
{"f_2185:lolevel_scm",(void*)f_2185},
{"f_2200:lolevel_scm",(void*)f_2200},
{"f_2198:lolevel_scm",(void*)f_2198},
{"f_2150:lolevel_scm",(void*)f_2150},
{"f_2154:lolevel_scm",(void*)f_2154},
{"f_2175:lolevel_scm",(void*)f_2175},
{"f_2159:lolevel_scm",(void*)f_2159},
{"f_2100:lolevel_scm",(void*)f_2100},
{"f_2086:lolevel_scm",(void*)f_2086},
{"f_2072:lolevel_scm",(void*)f_2072},
{"f_2058:lolevel_scm",(void*)f_2058},
{"f_2044:lolevel_scm",(void*)f_2044},
{"f_2030:lolevel_scm",(void*)f_2030},
{"f_2016:lolevel_scm",(void*)f_2016},
{"f_2002:lolevel_scm",(void*)f_2002},
{"f_1996:lolevel_scm",(void*)f_1996},
{"f_1993:lolevel_scm",(void*)f_1993},
{"f_1986:lolevel_scm",(void*)f_1986},
{"f_1957:lolevel_scm",(void*)f_1957},
{"f_1965:lolevel_scm",(void*)f_1965},
{"f_1928:lolevel_scm",(void*)f_1928},
{"f_1936:lolevel_scm",(void*)f_1936},
{"f_1910:lolevel_scm",(void*)f_1910},
{"f_1866:lolevel_scm",(void*)f_1866},
{"f_1870:lolevel_scm",(void*)f_1870},
{"f_1851:lolevel_scm",(void*)f_1851},
{"f_1855:lolevel_scm",(void*)f_1855},
{"f_1858:lolevel_scm",(void*)f_1858},
{"f_1819:lolevel_scm",(void*)f_1819},
{"f_1846:lolevel_scm",(void*)f_1846},
{"f_1799:lolevel_scm",(void*)f_1799},
{"f_1790:lolevel_scm",(void*)f_1790},
{"f_1794:lolevel_scm",(void*)f_1794},
{"f_1797:lolevel_scm",(void*)f_1797},
{"f_1784:lolevel_scm",(void*)f_1784},
{"f_1788:lolevel_scm",(void*)f_1788},
{"f_1778:lolevel_scm",(void*)f_1778},
{"f_1765:lolevel_scm",(void*)f_1765},
{"f_1769:lolevel_scm",(void*)f_1769},
{"f_1776:lolevel_scm",(void*)f_1776},
{"f_1755:lolevel_scm",(void*)f_1755},
{"f_1759:lolevel_scm",(void*)f_1759},
{"f_1746:lolevel_scm",(void*)f_1746},
{"f_1750:lolevel_scm",(void*)f_1750},
{"f_1740:lolevel_scm",(void*)f_1740},
{"f_1734:lolevel_scm",(void*)f_1734},
{"f_1724:lolevel_scm",(void*)f_1724},
{"f_1717:lolevel_scm",(void*)f_1717},
{"f_1636:lolevel_scm",(void*)f_1636},
{"f_1642:lolevel_scm",(void*)f_1642},
{"f_1672:lolevel_scm",(void*)f_1672},
{"f_1687:lolevel_scm",(void*)f_1687},
{"f_1708:lolevel_scm",(void*)f_1708},
{"f_1675:lolevel_scm",(void*)f_1675},
{"f_1312:lolevel_scm",(void*)f_1312},
{"f_1573:lolevel_scm",(void*)f_1573},
{"f_1568:lolevel_scm",(void*)f_1568},
{"f_1563:lolevel_scm",(void*)f_1563},
{"f_1314:lolevel_scm",(void*)f_1314},
{"f_1372:lolevel_scm",(void*)f_1372},
{"f_1375:lolevel_scm",(void*)f_1375},
{"f_1380:lolevel_scm",(void*)f_1380},
{"f_1500:lolevel_scm",(void*)f_1500},
{"f_1532:lolevel_scm",(void*)f_1532},
{"f_1542:lolevel_scm",(void*)f_1542},
{"f_1522:lolevel_scm",(void*)f_1522},
{"f_1467:lolevel_scm",(void*)f_1467},
{"f_1481:lolevel_scm",(void*)f_1481},
{"f_1477:lolevel_scm",(void*)f_1477},
{"f_1458:lolevel_scm",(void*)f_1458},
{"f_1345:lolevel_scm",(void*)f_1345},
{"f_1352:lolevel_scm",(void*)f_1352},
{"f_1329:lolevel_scm",(void*)f_1329},
{"f_1323:lolevel_scm",(void*)f_1323},
{"f_1317:lolevel_scm",(void*)f_1317},
{"f_1307:lolevel_scm",(void*)f_1307},
{"f_1173:lolevel_scm",(void*)f_1173},
{"f_1122:lolevel_scm",(void*)f_1122},
{"f_1049:lolevel_scm",(void*)f_1049},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
