/* Generated from csi.scm by the CHICKEN compiler
   http://www.call-cc.org
   2014-06-02 16:40
   Version 4.9.0 (rev 3f195ba)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2014-06-02 on yves (Linux)
   command line: csi.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -no-lambda-info -local -no-trace -output-file csi.c -extend ./private-namespace.scm
   used units: library eval chicken_2dsyntax chicken_2dsyntax ports extras
*/

#include "chicken.h"

#include <signal.h>

#if defined(HAVE_DIRECT_H)
# include <direct.h>
#else
# define _getcwd(buf, len)       NULL
#endif

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_chicken_2dsyntax_toplevel)
C_externimport void C_ccall C_chicken_2dsyntax_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_chicken_2dsyntax_toplevel)
C_externimport void C_ccall C_chicken_2dsyntax_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[409];
static double C_possibly_force_alignment;


/* from k2035 */
static C_word C_fcall stub77(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub77(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_mpointer(&C_a,(void*)_getcwd(t0,t1));
return C_r;}

C_noret_decl(f_2578)
static void C_ccall f_2578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6535)
static void C_ccall f_6535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6553)
static void C_ccall f_6553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6559)
static void C_ccall f_6559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6556)
static void C_ccall f_6556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6550)
static void C_ccall f_6550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5785)
static void C_ccall f_5785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5789)
static void C_ccall f_5789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2568)
static void C_fcall f_2568(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2563)
static void C_ccall f_2563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2560)
static void C_ccall f_2560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6544)
static void C_ccall f_6544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5799)
static void C_ccall f_5799(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5791)
static void C_ccall f_5791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4526)
static void C_ccall f_4526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6562)
static void C_ccall f_6562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2593)
static void C_ccall f_2593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2239)
static void C_ccall f_2239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5976)
static void C_ccall f_5976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2249)
static void C_ccall f_2249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4545)
static void C_fcall f_4545(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6085)
static void C_ccall f_6085(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6089)
static void C_ccall f_6089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3436)
static C_word C_fcall f_3436(C_word t0);
C_noret_decl(f_2210)
static void C_fcall f_2210(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2980)
static void C_ccall f_2980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2224)
static void C_ccall f_2224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6527)
static void C_ccall f_6527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2277)
static void C_ccall f_2277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2274)
static void C_ccall f_2274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2271)
static void C_ccall f_2271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2888)
static void C_ccall f_2888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6095)
static void C_ccall f_6095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6098)
static void C_ccall f_6098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2255)
static void C_fcall f_2255(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2268)
static void C_ccall f_2268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2878)
static void C_fcall f_2878(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2873)
static void C_ccall f_2873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3896)
static void C_ccall f_3896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6275)
static void C_ccall f_6275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6271)
static void C_ccall f_6271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2435)
static void C_ccall f_2435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5352)
static void C_ccall f_5352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6832)
static void C_ccall f_6832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2803)
static void C_ccall f_2803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2118)
static void C_ccall f_2118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2418)
static void C_fcall f_2418(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4898)
static void C_ccall f_4898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2810)
static void C_ccall f_2810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5766)
static void C_ccall f_5766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5768)
static void C_fcall f_5768(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6710)
static void C_ccall f_6710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2637)
static void C_ccall f_2637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6293)
static void C_fcall f_6293(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5778)
static void C_ccall f_5778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6291)
static void C_ccall f_6291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6285)
static void C_ccall f_6285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6281)
static void C_ccall f_6281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2851)
static void C_ccall f_2851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6738)
static void C_ccall f_6738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6730)
static void C_ccall f_6730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3757)
static void C_ccall f_3757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6493)
static void C_ccall f_6493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2613)
static void C_ccall f_2613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6490)
static void C_ccall f_6490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6498)
static void C_fcall f_6498(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5577)
static void C_ccall f_5577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2627)
static void C_fcall f_2627(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3741)
static void C_ccall f_3741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6655)
static void C_ccall f_6655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3748)
static void C_ccall f_3748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6659)
static void C_ccall f_6659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2832)
static void C_ccall f_2832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6651)
static void C_ccall f_6651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6484)
static void C_ccall f_6484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2622)
static void C_ccall f_2622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3225)
static void C_ccall f_3225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3222)
static void C_ccall f_3222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1865)
static void C_ccall f_1865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1868)
static void C_ccall f_1868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1862)
static void C_ccall f_1862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2823)
static void C_ccall f_2823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6750)
static void C_ccall f_6750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6474)
static void C_ccall f_6474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3253)
static void C_ccall f_3253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1859)
static void C_ccall f_1859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1856)
static void C_ccall f_1856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2838)
static void C_ccall f_2838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2835)
static void C_ccall f_2835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4427)
static void C_ccall f_4427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3241)
static void C_ccall f_3241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1889)
static void C_ccall f_1889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1884)
static void C_ccall f_1884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3257)
static void C_ccall f_3257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4417)
static void C_ccall f_4417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3273)
static void C_ccall f_3273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1871)
static void C_ccall f_1871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3249)
static void C_ccall f_3249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5569)
static void C_ccall f_5569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5993)
static void C_ccall f_5993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3261)
static void C_ccall f_3261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5395)
static void C_ccall f_5395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5398)
static void C_ccall f_5398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6797)
static void C_ccall f_6797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6793)
static void C_ccall f_6793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5211)
static void C_ccall f_5211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5961)
static void C_ccall f_5961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1892)
static void C_fcall f_1892(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1898)
static void C_ccall f_1898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3269)
static void C_ccall f_3269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3265)
static void C_ccall f_3265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5223)
static void C_fcall f_5223(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6571)
static void C_ccall f_6571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2991)
static void C_ccall f_2991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2994)
static void C_ccall f_2994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3509)
static void C_ccall f_3509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4186)
static void C_ccall f_4186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2974)
static void C_ccall f_2974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4555)
static void C_ccall f_4555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4195)
static void C_fcall f_4195(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3103)
static void C_ccall f_3103(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3103)
static void C_ccall f_3103r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4583)
static void C_fcall f_4583(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3109)
static void C_ccall f_3109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4588)
static void C_fcall f_4588(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3301)
static void C_ccall f_3301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3196)
static void C_ccall f_3196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3560)
static void C_ccall f_3560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4350)
static void C_fcall f_4350(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5845)
static void C_ccall f_5845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5848)
static void C_ccall f_5848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6363)
static void C_fcall f_6363(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4364)
static void C_fcall f_4364(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3588)
static void C_ccall f_3588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4852)
static void C_fcall f_4852(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5854)
static void C_ccall f_5854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5858)
static void C_ccall f_5858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4372)
static void C_ccall f_4372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6357)
static void C_ccall f_6357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4963)
static void C_ccall f_4963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4969)
static void C_ccall f_4969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4382)
static void C_ccall f_4382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4966)
static void C_ccall f_4966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5056)
static void C_ccall f_5056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4388)
static void C_fcall f_4388(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2958)
static void C_ccall f_2958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5053)
static void C_ccall f_5053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2954)
static void C_ccall f_2954(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2954)
static void C_ccall f_2954r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4835)
static void C_ccall f_4835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4861)
static void C_fcall f_4861(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4829)
static void C_fcall f_4829(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4824)
static void C_ccall f_4824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4826)
static void C_fcall f_4826(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5809)
static void C_ccall f_5809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2767)
static void C_ccall f_2767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5070)
static void C_fcall f_5070(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4813)
static void C_ccall f_4813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4817)
static void C_ccall f_4817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3355)
static void C_fcall f_3355(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5812)
static void C_ccall f_5812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3353)
static void C_ccall f_3353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5815)
static void C_fcall f_5815(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5818)
static void C_ccall f_5818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3120)
static void C_ccall f_3120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3121)
static void C_ccall f_3121(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3121)
static void C_ccall f_3121r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5009)
static void C_fcall f_5009(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3998)
static void C_ccall f_3998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3129)
static void C_fcall f_3129(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4205)
static void C_ccall f_4205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2005)
static void C_ccall f_2005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5824)
static void C_ccall f_5824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3384)
static void C_ccall f_3384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5821)
static void C_fcall f_5821(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2902)
static void C_ccall f_2902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5827)
static void C_ccall f_5827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4785)
static void C_ccall f_4785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5019)
static void C_ccall f_5019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3117)
static void C_ccall f_3117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4895)
static void C_ccall f_4895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4892)
static void C_ccall f_4892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5836)
static void C_ccall f_5836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5830)
static void C_ccall f_5830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5839)
static void C_ccall f_5839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3141)
static void C_ccall f_3141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3143)
static void C_fcall f_3143(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5403)
static void C_fcall f_5403(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5409)
static void C_fcall f_5409(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4264)
static void C_ccall f_4264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3131)
static void C_ccall f_3131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3135)
static void C_ccall f_3135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3138)
static void C_ccall f_3138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2071)
static void C_fcall f_2071(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3161)
static void C_ccall f_3161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3162)
static void C_fcall f_3162(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2948)
static void C_ccall f_2948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4646)
static void C_ccall f_4646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4245)
static void C_ccall f_4245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3166)
static void C_ccall f_3166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4241)
static void C_fcall f_4241(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2049)
static void C_ccall f_2049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4240)
static void C_ccall f_4240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2042)
static void C_fcall f_2042(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3151)
static void C_ccall f_3151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4630)
static void C_ccall f_4630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3158)
static void C_ccall f_3158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4277)
static void C_ccall f_4277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2058)
static void C_ccall f_2058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2453)
static void C_ccall f_2453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2052)
static void C_ccall f_2052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2450)
static void C_ccall f_2450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3188)
static void C_ccall f_3188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4623)
static void C_ccall f_4623(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4626)
static void C_fcall f_4626(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2464)
static void C_ccall f_2464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2460)
static void C_ccall f_2460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6328)
static void C_fcall f_6328(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6322)
static void C_ccall f_6322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3179)
static void C_fcall f_3179(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4254)
static void C_fcall f_4254(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3775)
static void C_ccall f_3775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5608)
static C_word C_fcall f_5608(C_word t0);
C_noret_decl(f_2509)
static void C_ccall f_2509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2506)
static void C_ccall f_2506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1901)
static void C_ccall f_1901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1908)
static void C_ccall f_1908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2491)
static void C_ccall f_2491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2494)
static void C_ccall f_2494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3528)
static void C_ccall f_3528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2675)
static void C_ccall f_2675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2670)
static void C_ccall f_2670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5634)
static void C_ccall f_5634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5638)
static void C_ccall f_5638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2299)
static void C_ccall f_2299(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6001)
static void C_ccall f_6001(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6001)
static void C_ccall f_6001r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3518)
static void C_fcall f_3518(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2685)
static void C_ccall f_2685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2681)
static void C_ccall f_2681(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2681)
static void C_ccall f_2681r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6034)
static void C_ccall f_6034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2479)
static void C_ccall f_2479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5641)
static void C_ccall f_5641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2476)
static void C_ccall f_2476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5644)
static void C_ccall f_5644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5647)
static void C_ccall f_5647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2473)
static void C_ccall f_2473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2652)
static void C_ccall f_2652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5421)
static void C_fcall f_5421(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6159)
static void C_ccall f_6159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3531)
static void C_ccall f_3531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2666)
static void C_ccall f_2666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2661)
static void C_ccall f_2661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4131)
static void C_ccall f_4131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6016)
static void C_ccall f_6016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4005)
static void C_ccall f_4005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1936)
static void C_ccall f_1936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6140)
static void C_ccall f_6140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1938)
static void C_ccall f_1938(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6045)
static void C_ccall f_6045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6177)
static void C_ccall f_6177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6174)
static void C_ccall f_6174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6171)
static void C_ccall f_6171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3323)
static void C_ccall f_3323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3328)
static void C_fcall f_3328(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2698)
static void C_ccall f_2698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2692)
static void C_ccall f_2692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2694)
static void C_ccall f_2694(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2694)
static void C_ccall f_2694r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6024)
static void C_ccall f_6024(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6024)
static void C_ccall f_6024r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6809)
static void C_ccall f_6809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5881)
static void C_fcall f_5881(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6055)
static void C_ccall f_6055(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6055)
static void C_ccall f_6055r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6800)
static void C_fcall f_6800(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6053)
static void C_ccall f_6053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6104)
static void C_ccall f_6104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6109)
static void C_fcall f_6109(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6101)
static void C_ccall f_6101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5894)
static void C_ccall f_5894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3338)
static void C_ccall f_3338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5899)
static void C_ccall f_5899(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1922)
static void C_ccall f_1922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1926)
static void C_ccall f_1926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1929)
static void C_ccall f_1929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6125)
static void C_ccall f_6125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6122)
static void C_ccall f_6122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6845)
static void C_ccall f_6845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2280)
static void C_ccall f_2280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6876)
static void C_ccall f_6876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4975)
static void C_ccall f_4975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4972)
static void C_ccall f_4972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2289)
static void C_ccall f_2289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2150)
static void C_fcall f_2150(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6824)
static void C_ccall f_6824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6828)
static void C_fcall f_6828(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2128)
static void C_ccall f_2128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2121)
static void C_ccall f_2121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6858)
static void C_ccall f_6858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6856)
static void C_ccall f_6856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2135)
static void C_ccall f_2135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2132)
static void C_ccall f_2132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6880)
static void C_ccall f_6880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2109)
static void C_ccall f_2109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6889)
static void C_ccall f_6889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2791)
static void C_ccall f_2791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6866)
static void C_ccall f_6866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6638)
static void C_ccall f_6638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3964)
static void C_ccall f_3964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2163)
static void C_ccall f_2163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2160)
static void C_ccall f_2160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3960)
static void C_ccall f_3960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6869)
static void C_ccall f_6869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2779)
static void C_ccall f_2779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4775)
static void C_fcall f_4775(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2177)
static void C_ccall f_2177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6697)
static void C_fcall f_6697(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2148)
static void C_ccall f_2148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2141)
static void C_ccall f_2141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3989)
static void C_ccall f_3989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6685)
static void C_ccall f_6685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2200)
static void C_ccall f_2200(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4795)
static void C_ccall f_4795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6687)
static void C_ccall f_6687(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6681)
static void C_ccall f_6681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4798)
static void C_ccall f_4798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3970)
static void C_ccall f_3970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6673)
static void C_ccall f_6673(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6671)
static void C_ccall f_6671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6668)
static void C_ccall f_6668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6665)
static void C_ccall f_6665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2339)
static void C_ccall f_2339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3763)
static void C_ccall f_3763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3760)
static void C_ccall f_3760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2346)
static void C_ccall f_2346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3793)
static void C_ccall f_3793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4309)
static void C_fcall f_4309(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3796)
static void C_ccall f_3796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6386)
static void C_fcall f_6386(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3790)
static void C_ccall f_3790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6373)
static void C_ccall f_6373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3780)
static void C_fcall f_3780(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5464)
static void C_fcall f_5464(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2713)
static void C_ccall f_2713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5257)
static void C_fcall f_5257(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2326)
static void C_ccall f_2326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2324)
static void C_ccall f_2324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4901)
static void C_ccall f_4901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4904)
static void C_ccall f_4904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4907)
static void C_ccall f_4907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3805)
static void C_ccall f_3805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5263)
static void C_fcall f_5263(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6396)
static void C_ccall f_6396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5486)
static void C_fcall f_5486(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5273)
static void C_ccall f_5273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5458)
static void C_fcall f_5458(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2530)
static void C_ccall f_2530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5208)
static void C_ccall f_5208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5201)
static void C_ccall f_5201(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5204)
static void C_fcall f_5204(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2758)
static void C_ccall f_2758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4910)
static void C_ccall f_4910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4913)
static void C_ccall f_4913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3606)
static void C_ccall f_3606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3603)
static void C_ccall f_3603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4916)
static void C_ccall f_4916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4919)
static void C_ccall f_4919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2751)
static void C_ccall f_2751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5864)
static void C_ccall f_5864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5867)
static void C_ccall f_5867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5861)
static void C_ccall f_5861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5291)
static void C_ccall f_5291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5297)
static void C_ccall f_5297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5294)
static void C_ccall f_5294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4945)
static void C_ccall f_4945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3841)
static void C_ccall f_3841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3609)
static void C_ccall f_3609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3838)
static void C_ccall f_3838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5873)
static void C_ccall f_5873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5876)
static void C_fcall f_5876(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5870)
static void C_ccall f_5870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4935)
static void C_fcall f_4935(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2524)
static void C_ccall f_2524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2527)
static void C_ccall f_2527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4458)
static void C_ccall f_4458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2521)
static void C_ccall f_2521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2747)
static void C_ccall f_2747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4466)
static void C_ccall f_4466(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1955)
static void C_ccall f_1955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5248)
static void C_ccall f_5248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4480)
static void C_fcall f_4480(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4950)
static void C_fcall f_4950(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3853)
static void C_fcall f_3853(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3856)
static void C_ccall f_3856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4477)
static void C_fcall f_4477(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4475)
static void C_ccall f_4475(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4475)
static void C_ccall f_4475r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2729)
static void C_ccall f_2729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1977)
static void C_ccall f_1977(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1975)
static void C_ccall f_1975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3829)
static void C_ccall f_3829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4922)
static void C_ccall f_4922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1992)
static void C_ccall f_1992(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3401)
static C_word C_fcall f_3401(C_word t0,C_word t1);
C_noret_decl(f_5285)
static void C_ccall f_5285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5288)
static void C_ccall f_5288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6448)
static void C_ccall f_6448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3681)
static void C_ccall f_3681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6433)
static void C_ccall f_6433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6436)
static void C_ccall f_6436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6439)
static void C_ccall f_6439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1967)
static void C_ccall f_1967(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3675)
static void C_ccall f_3675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2084)
static void C_ccall f_2084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6207)
static void C_ccall f_6207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6204)
static void C_ccall f_6204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3080)
static void C_fcall f_3080(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2093)
static void C_ccall f_2093(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2097)
static void C_ccall f_2097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3468)
static void C_ccall f_3468(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3468)
static void C_ccall f_3468r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3466)
static void C_ccall f_3466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4502)
static void C_ccall f_4502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4509)
static void C_ccall f_4509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f7552)
static void C_ccall f7552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5902)
static void C_ccall f_5902(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3097)
static void C_ccall f_3097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3486)
static void C_fcall f_3486(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3481)
static void C_ccall f_3481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5918)
static void C_ccall f_5918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3474)
static void C_ccall f_3474(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3213)
static void C_ccall f_3213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5746)
static void C_ccall f_5746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3216)
static void C_ccall f_3216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3219)
static void C_ccall f_3219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5752)
static void C_fcall f_5752(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5759)
static void C_ccall f_5759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5342)
static void C_fcall f_5342(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5340)
static void C_ccall f_5340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5721)
static void C_ccall f_5721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4656)
static void C_fcall f_4656(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5181)
static void C_ccall f_5181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5733)
static void C_ccall f_5733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5739)
static void C_ccall f_5739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3000)
static void C_ccall f_3000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3003)
static void C_ccall f_3003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6419)
static void C_ccall f_6419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4669)
static void C_ccall f_4669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4666)
static void C_ccall f_4666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3078)
static void C_ccall f_3078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5705)
static void C_ccall f_5705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3865)
static void C_fcall f_3865(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6409)
static void C_fcall f_6409(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3070)
static void C_ccall f_3070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4675)
static void C_ccall f_4675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4678)
static void C_ccall f_4678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5333)
static void C_ccall f_5333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2402)
static void C_ccall f_2402(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4282)
static void C_ccall f_4282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4672)
static void C_ccall f_4672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6192)
static void C_ccall f_6192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6195)
static void C_ccall f_6195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4681)
static void C_ccall f_4681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5170)
static void C_fcall f_5170(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3011)
static void C_fcall f_3011(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6180)
static void C_ccall f_6180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6183)
static void C_ccall f_6183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6467)
static void C_ccall f_6467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3046)
static void C_ccall f_3046(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4690)
static void C_fcall f_4690(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5659)
static void C_ccall f_5659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5656)
static void C_fcall f_5656(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5653)
static void C_ccall f_5653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5650)
static void C_fcall f_5650(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3040)
static void C_ccall f_3040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6454)
static void C_ccall f_6454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6457)
static void C_ccall f_6457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4319)
static void C_ccall f_4319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5668)
static void C_ccall f_5668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5665)
static void C_ccall f_5665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5662)
static void C_fcall f_5662(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4346)
static void C_ccall f_4346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5521)
static void C_ccall f_5521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5525)
static void C_ccall f_5525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5529)
static void C_fcall f_5529(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5676)
static void C_fcall f_5676(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4106)
static void C_ccall f_4106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5670)
static void C_fcall f_5670(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3064)
static void C_ccall f_3064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5947)
static void C_ccall f_5947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3058)
static void C_ccall f_3058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5684)
static void C_fcall f_5684(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3052)
static void C_ccall f_3052(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5500)
static void C_ccall f_5500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2609)
static void C_ccall f_2609(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2603)
static void C_fcall f_2603(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5111)
static void C_fcall f_5111(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2602)
static void C_ccall f_2602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4112)
static void C_ccall f_4112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4118)
static void C_ccall f_4118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2372)
static C_word C_fcall f_2372(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_4703)
static void C_ccall f_4703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4706)
static void C_ccall f_4706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5168)
static void C_fcall f_5168(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4146)
static void C_ccall f_4146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4143)
static void C_ccall f_4143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2352)
static void C_ccall f_2352(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2352)
static void C_ccall f_2352r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4165)
static void C_fcall f_4165(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4157)
static void C_fcall f_4157(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4741)
static void C_fcall f_4741(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2023)
static void C_ccall f_2023(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_2568)
static void C_fcall trf_2568(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2568(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2568(t0,t1,t2);}

C_noret_decl(trf_4545)
static void C_fcall trf_4545(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4545(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4545(t0,t1);}

C_noret_decl(trf_2210)
static void C_fcall trf_2210(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2210(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2210(t0,t1);}

C_noret_decl(trf_2255)
static void C_fcall trf_2255(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2255(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2255(t0,t1,t2);}

C_noret_decl(trf_2878)
static void C_fcall trf_2878(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2878(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2878(t0,t1,t2);}

C_noret_decl(trf_2418)
static void C_fcall trf_2418(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2418(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2418(t0,t1);}

C_noret_decl(trf_5768)
static void C_fcall trf_5768(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5768(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5768(t0,t1,t2);}

C_noret_decl(trf_6293)
static void C_fcall trf_6293(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6293(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6293(t0,t1,t2);}

C_noret_decl(trf_6498)
static void C_fcall trf_6498(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6498(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6498(t0,t1,t2);}

C_noret_decl(trf_2627)
static void C_fcall trf_2627(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2627(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2627(t0,t1,t2);}

C_noret_decl(trf_1892)
static void C_fcall trf_1892(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1892(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1892(t0,t1);}

C_noret_decl(trf_5223)
static void C_fcall trf_5223(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5223(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5223(t0,t1,t2);}

C_noret_decl(trf_4195)
static void C_fcall trf_4195(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4195(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4195(t0,t1,t2);}

C_noret_decl(trf_4583)
static void C_fcall trf_4583(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4583(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4583(t0,t1,t2);}

C_noret_decl(trf_4588)
static void C_fcall trf_4588(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4588(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4588(t0,t1);}

C_noret_decl(trf_4350)
static void C_fcall trf_4350(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4350(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4350(t0,t1,t2);}

C_noret_decl(trf_6363)
static void C_fcall trf_6363(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6363(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6363(t0,t1,t2);}

C_noret_decl(trf_4364)
static void C_fcall trf_4364(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4364(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4364(t0,t1,t2);}

C_noret_decl(trf_4852)
static void C_fcall trf_4852(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4852(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4852(t0,t1);}

C_noret_decl(trf_4388)
static void C_fcall trf_4388(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4388(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4388(t0,t1,t2);}

C_noret_decl(trf_4861)
static void C_fcall trf_4861(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4861(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4861(t0,t1,t2,t3);}

C_noret_decl(trf_4829)
static void C_fcall trf_4829(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4829(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4829(t0,t1);}

C_noret_decl(trf_4826)
static void C_fcall trf_4826(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4826(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4826(t0,t1);}

C_noret_decl(trf_5070)
static void C_fcall trf_5070(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5070(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5070(t0,t1);}

C_noret_decl(trf_3355)
static void C_fcall trf_3355(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3355(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3355(t0,t1,t2);}

C_noret_decl(trf_5815)
static void C_fcall trf_5815(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5815(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5815(t0,t1);}

C_noret_decl(trf_5009)
static void C_fcall trf_5009(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5009(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5009(t0,t1,t2,t3);}

C_noret_decl(trf_3129)
static void C_fcall trf_3129(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3129(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3129(t0,t1);}

C_noret_decl(trf_5821)
static void C_fcall trf_5821(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5821(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5821(t0,t1);}

C_noret_decl(trf_3143)
static void C_fcall trf_3143(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3143(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3143(t0,t1);}

C_noret_decl(trf_5403)
static void C_fcall trf_5403(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5403(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5403(t0,t1,t2);}

C_noret_decl(trf_5409)
static void C_fcall trf_5409(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5409(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5409(t0,t1,t2);}

C_noret_decl(trf_2071)
static void C_fcall trf_2071(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2071(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2071(t0,t1,t2);}

C_noret_decl(trf_3162)
static void C_fcall trf_3162(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3162(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3162(t0,t1,t2);}

C_noret_decl(trf_4241)
static void C_fcall trf_4241(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4241(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4241(t0,t1,t2);}

C_noret_decl(trf_2042)
static void C_fcall trf_2042(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2042(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2042(t0,t1);}

C_noret_decl(trf_4626)
static void C_fcall trf_4626(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4626(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4626(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6328)
static void C_fcall trf_6328(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6328(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6328(t0,t1,t2);}

C_noret_decl(trf_3179)
static void C_fcall trf_3179(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3179(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3179(t0,t1);}

C_noret_decl(trf_4254)
static void C_fcall trf_4254(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4254(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4254(t0,t1,t2);}

C_noret_decl(trf_3518)
static void C_fcall trf_3518(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3518(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3518(t0,t1,t2,t3);}

C_noret_decl(trf_5421)
static void C_fcall trf_5421(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5421(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5421(t0,t1,t2);}

C_noret_decl(trf_3328)
static void C_fcall trf_3328(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3328(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3328(t0,t1,t2);}

C_noret_decl(trf_5881)
static void C_fcall trf_5881(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5881(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5881(t0,t1,t2);}

C_noret_decl(trf_6800)
static void C_fcall trf_6800(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6800(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6800(t0,t1);}

C_noret_decl(trf_6109)
static void C_fcall trf_6109(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6109(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6109(t0,t1,t2);}

C_noret_decl(trf_2150)
static void C_fcall trf_2150(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2150(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2150(t0,t1,t2);}

C_noret_decl(trf_6828)
static void C_fcall trf_6828(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6828(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6828(t0,t1,t2);}

C_noret_decl(trf_4775)
static void C_fcall trf_4775(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4775(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4775(t0,t1,t2);}

C_noret_decl(trf_6697)
static void C_fcall trf_6697(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6697(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6697(t0,t1);}

C_noret_decl(trf_4309)
static void C_fcall trf_4309(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4309(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4309(t0,t1,t2);}

C_noret_decl(trf_6386)
static void C_fcall trf_6386(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6386(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6386(t0,t1,t2);}

C_noret_decl(trf_3780)
static void C_fcall trf_3780(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3780(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3780(t0,t1,t2);}

C_noret_decl(trf_5464)
static void C_fcall trf_5464(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5464(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5464(t0,t1,t2);}

C_noret_decl(trf_5257)
static void C_fcall trf_5257(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5257(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5257(t0,t1,t2,t3);}

C_noret_decl(trf_5263)
static void C_fcall trf_5263(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5263(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5263(t0,t1,t2,t3);}

C_noret_decl(trf_5486)
static void C_fcall trf_5486(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5486(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5486(t0,t1);}

C_noret_decl(trf_5458)
static void C_fcall trf_5458(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5458(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5458(t0,t1);}

C_noret_decl(trf_5204)
static void C_fcall trf_5204(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5204(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5204(t0,t1,t2);}

C_noret_decl(trf_5876)
static void C_fcall trf_5876(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5876(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5876(t0,t1);}

C_noret_decl(trf_4935)
static void C_fcall trf_4935(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4935(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4935(t0,t1,t2,t3);}

C_noret_decl(trf_4480)
static void C_fcall trf_4480(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4480(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4480(t0,t1,t2);}

C_noret_decl(trf_4950)
static void C_fcall trf_4950(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4950(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4950(t0,t1,t2,t3);}

C_noret_decl(trf_3853)
static void C_fcall trf_3853(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3853(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3853(t0,t1);}

C_noret_decl(trf_4477)
static void C_fcall trf_4477(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4477(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4477(t0,t1,t2,t3);}

C_noret_decl(trf_3080)
static void C_fcall trf_3080(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3080(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3080(t0,t1,t2,t3);}

C_noret_decl(trf_3486)
static void C_fcall trf_3486(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3486(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3486(t0,t1,t2);}

C_noret_decl(trf_5752)
static void C_fcall trf_5752(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5752(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5752(t0,t1,t2);}

C_noret_decl(trf_5342)
static void C_fcall trf_5342(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5342(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5342(t0,t1,t2,t3);}

C_noret_decl(trf_4656)
static void C_fcall trf_4656(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4656(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4656(t0,t1,t2);}

C_noret_decl(trf_3865)
static void C_fcall trf_3865(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3865(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3865(t0,t1,t2,t3);}

C_noret_decl(trf_6409)
static void C_fcall trf_6409(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6409(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6409(t0,t1,t2);}

C_noret_decl(trf_5170)
static void C_fcall trf_5170(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5170(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5170(t0,t1,t2);}

C_noret_decl(trf_3011)
static void C_fcall trf_3011(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3011(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3011(t0,t1,t2);}

C_noret_decl(trf_4690)
static void C_fcall trf_4690(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4690(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4690(t0,t1,t2,t3);}

C_noret_decl(trf_5656)
static void C_fcall trf_5656(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5656(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5656(t0,t1);}

C_noret_decl(trf_5650)
static void C_fcall trf_5650(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5650(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5650(t0,t1);}

C_noret_decl(trf_5662)
static void C_fcall trf_5662(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5662(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5662(t0,t1);}

C_noret_decl(trf_5529)
static void C_fcall trf_5529(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5529(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5529(t0,t1,t2);}

C_noret_decl(trf_5676)
static void C_fcall trf_5676(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5676(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5676(t0,t1,t2);}

C_noret_decl(trf_5670)
static void C_fcall trf_5670(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5670(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5670(t0,t1,t2);}

C_noret_decl(trf_5684)
static void C_fcall trf_5684(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5684(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5684(t0,t1,t2);}

C_noret_decl(trf_2603)
static void C_fcall trf_2603(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2603(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2603(t0,t1,t2);}

C_noret_decl(trf_5111)
static void C_fcall trf_5111(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5111(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5111(t0,t1);}

C_noret_decl(trf_5168)
static void C_fcall trf_5168(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5168(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5168(t0,t1);}

C_noret_decl(trf_4165)
static void C_fcall trf_4165(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4165(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4165(t0,t1,t2);}

C_noret_decl(trf_4157)
static void C_fcall trf_4157(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4157(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4157(t0,t1,t2);}

C_noret_decl(trf_4741)
static void C_fcall trf_4741(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4741(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4741(t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* k2576 in for-each-loop241 in k2558 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2568(t3,((C_word*)t0)[4],t2);}

/* k6533 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in ... */
static void C_ccall f_6535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
/* csi.scm:1011: string-split */
t3=C_fast_retrieve(lf[40]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,lf[352]);}
else{
/* csi.scm:1011: string-split */
t2=C_fast_retrieve(lf[40]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[353],lf[352]);}}

/* k6551 in k6548 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in ... */
static void C_ccall f_6553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6553,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6556,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_u_i_cdr(((C_word*)t0)[2]);
t4=C_u_i_cdr(t3);
/* csi.scm:994: command-line-arguments */
t5=C_fast_retrieve(lf[305]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t2,t4);}

/* k6557 in k6554 in k6551 in k6548 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in ... */
static void C_ccall f_6559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6562,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:997: register-feature! */
t3=C_fast_retrieve(lf[282]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[358]);}

/* k6554 in k6551 in k6548 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in ... */
static void C_ccall f_6556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6556,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6559,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:996: register-feature! */
t3=C_fast_retrieve(lf[282]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[359]);}

/* k6548 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 in ... */
static void C_ccall f_6550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6553,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* csi.scm:993: program-name */
t4=C_fast_retrieve(lf[360]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* k5783 in k5776 in doloop1239 in k5764 in k5757 in evalstring in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in ... */
static void C_ccall f_5785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[2])[1];
f_5768(t2,((C_word*)t0)[3],t1);}

/* k5787 in doloop1239 in k5764 in k5757 in evalstring in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in ... */
static void C_ccall f_5789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:1032: rec */
t2=((C_word*)t0)[2];
((C_proc3)C_fast_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],t1);}

/* for-each-loop241 in k2558 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_2568(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2568,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2578,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:345: g242 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2561 in k2558 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[48]+1));}

/* k2558 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2560,2,t0,t1);}
t2=C_fast_retrieve(lf[89]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2563,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2568,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_2568(t7,t3,t1);}

/* k6542 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in ... */
static void C_ccall f_6544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
f_5656(t3,t2);}
else{
t2=((C_word*)t0)[2];
f_5656(t2,((C_word*)t0)[3]);}}

/* f_5799 in evalstring in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in ... */
static void C_ccall f_5799(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5799,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[48]+1));}

/* a5790 in doloop1239 in k5764 in k5757 in evalstring in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in ... */
static void C_ccall f_5791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5791,2,t0,t1);}
/* csi.scm:1032: eval */
t2=C_fast_retrieve(lf[67]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k4524 in k4500 in body700 in dump in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_4526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:753: hexdump */
t2=C_fast_retrieve(lf[224]);
f_4623(6,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1,*((C_word*)lf[225]+1),((C_word*)t0)[4]);}

/* k6560 in k6557 in k6554 in k6551 in k6548 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in ... */
static void C_ccall f_6562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6562,2,t0,t1);}
t2=C_u_i_cdr(((C_word*)t0)[2]);
t3=C_i_set_i_slot(t2,C_fix(1),C_SCHEME_END_OF_LIST);
if(C_truep(*((C_word*)lf[29]+1))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6571,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_i_cadr(((C_word*)t0)[2]);
/* csi.scm:1000: lookup-script-file */
t6=C_fast_retrieve(lf[36]);
f_2093(3,t6,t4,t5);}
else{
t4=C_SCHEME_UNDEFINED;
t5=((C_word*)t0)[3];
f_5650(t5,t4);}}

/* k2591 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:345: string-split */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* ##csi#history-clear in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2239,2,t0,t1);}
t2=*((C_word*)lf[48]+1);
/* csi.scm:241: vector-fill! */
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,C_fast_retrieve(lf[45]),*((C_word*)lf[48]+1));}

/* k5974 in doloop1370 in k5874 in k5871 in k5868 in k5865 in k5862 in k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in ... */
static void C_ccall f_5976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=((C_word*)((C_word*)t0)[2])[1];
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_u_i_cdr(t2));
t4=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t5=((C_word*)((C_word*)t0)[3])[1];
f_5881(t5,((C_word*)t0)[4],t4);}

/* ##csi#history-show in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2249,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2255,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2255(t5,t1,C_fix(1));}

/* k4543 in k4500 in body700 in dump in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_4545(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4545,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4555,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=C_block_size(t3);
/* csi.scm:758: bestlen */
t6=((C_word*)t0)[5];
f_4480(t6,t4,t5);}
else{
/* csi.scm:759: ##sys#error */
t2=*((C_word*)lf[58]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[253],lf[256],((C_word*)t0)[2]);}}

/* f_6085 in doloop1370 in k5874 in k5871 in k5868 in k5865 in k5862 in k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in ... */
static void C_ccall f_6085(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6085,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6089,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6140,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1118: with-output-to-string */
t5=C_fast_retrieve(lf[311]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k6087 */
static void C_ccall f_6089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6089,2,t0,t1);}
t2=t1;
t3=C_i_string_length(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6095,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm:1120: flush-output */
t6=*((C_word*)lf[310]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,*((C_word*)lf[52]+1));}

/* lp in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static C_word C_fcall f_3436(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_overflow_check;
loop:
if(C_truep(C_i_pairp(t1))){
t2=C_i_car(t1);
t3=C_eqp(t1,t2);
if(C_truep(t3)){
return(t3);}
else{
t4=t1;
t5=C_u_i_cdr(t4);
t7=t5;
t1=t7;
goto loop;}}
else{
return(C_SCHEME_FALSE);}}

/* k2208 in history-add in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_2210(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_i_vector_set(C_fast_retrieve(lf[45]),C_fast_retrieve(lf[25]),((C_word*)t0)[2]);
t3=C_fixnum_plus(C_fast_retrieve(lf[25]),C_fix(1));
t4=C_mutate2((C_word*)lf[25]+1 /* (set! ##csi#history-count ...) */,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[2]);}

/* k2978 in k6657 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2980,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3000,a[2]=t6,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3046,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:460: call-with-current-continuation */
t9=*((C_word*)lf[371]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* k2222 in history-add in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2((C_word*)lf[45]+1 /* (set! ##csi#history-list ...) */,t1);
t3=((C_word*)t0)[2];
f_2210(t3,t2);}

/* k6525 in map-loop1180 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in ... */
static void C_ccall f_6527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6527,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6498(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6498(t6,((C_word*)t0)[5],t5);}}

/* k2275 in k2272 in k2269 in k2266 in doloop134 in history-show in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2277,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2280,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:253: newline */
t3=*((C_word*)lf[22]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2272 in k2269 in k2266 in doloop134 in history-show in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2274,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2277,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2289,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:249: ##sys#with-print-length-limit */
((C_proc4)C_fast_retrieve_symbol_proc(lf[55]))(4,*((C_word*)lf[55]+1),t2,C_fix(80),t3);}

/* k2269 in k2266 in doloop134 in history-show in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2271,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2274,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:244: ##sys#print */
t3=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[56],C_SCHEME_FALSE,((C_word*)t0)[5]);}

/* k2886 in for-each-loop307 in k2849 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2878(t3,((C_word*)t0)[4],t2);}

/* k6093 in k6087 */
static void C_ccall f_6095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6095,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6098,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:1121: display */
t3=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[309],*((C_word*)lf[307]+1));}

/* k6096 in k6093 in k6087 */
static void C_ccall f_6098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6098,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6101,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6109,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_6109(t6,t2,C_fix(0));}

/* doloop134 in history-show in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_2255(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2255,NULL,3,t0,t1,t2);}
if(C_truep(C_i_greater_or_equalp(t2,C_fast_retrieve(lf[25])))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=*((C_word*)lf[52]+1);
t4=*((C_word*)lf[52]+1);
t5=C_i_check_port_2(*((C_word*)lf[52]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[53]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2268,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* csi.scm:244: ##sys#write-char-0 */
((C_proc4)C_fast_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t6,C_make_character(35),*((C_word*)lf[52]+1));}}

/* k2266 in doloop134 in history-show in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2268,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2271,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:244: ##sys#print */
t3=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[5]);}

/* for-each-loop307 in k2849 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_2878(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2878,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2888,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_i_caddr(t4);
if(C_truep(t5)){
/* csi.scm:414: print */
t6=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,C_make_character(32),t5);}
else{
t6=C_u_i_car(t4);
/* csi.scm:415: print */
t7=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,lf[121],t6);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2871 in k2849 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[48]+1));}

/* k3894 in loop-print in k3854 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 in ... */
static void C_ccall f_3896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3896,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[2];
t5=C_u_i_car(t4);
t6=C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
/* csi.scm:659: loop-print */
t7=((C_word*)((C_word*)t0)[4])[1];
f_3865(t7,((C_word*)t0)[5],t3,t6);}

/* k6273 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in ... */
static void C_ccall f_6275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6275,2,t0,t1);}
t2=C_i_check_list_2(t1,lf[239]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6281,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6328,a[2]=((C_word*)t0)[5],a[3]=t5,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_6328(t7,t3,t1);}

/* k6269 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in ... */
static void C_ccall f_6271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:1058: ##sys#nodups */
((C_proc4)C_fast_retrieve_symbol_proc(lf[333]))(4,*((C_word*)lf[333]+1),((C_word*)t0)[2],t1,*((C_word*)lf[334]+1));}

/* k2433 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[48]+1));}

/* k5350 in for-each-loop931 in doloop917 in a5200 in k5166 in k2821 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_5352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_slot(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_5342(t4,((C_word*)t0)[5],t2,t3);}

/* k6830 in g338 in k6822 in k6798 in k6795 in a6792 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_6832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:444: printf */
t2=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[386],((C_word*)((C_word*)t0)[3])[1]);}

/* k2801 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[48]+1));}

/* k2116 in k2107 in k2095 in lookup-script-file in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2118,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2121,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_a_i_bytevector(&a,1,C_fix(3));
t4=(C_truep(((C_word*)t0)[5])?C_i_foreign_block_argumentp(((C_word*)t0)[5]):C_SCHEME_FALSE);
t5=C_i_foreign_fixnum_argumentp(C_fix(256));
t6=stub77(t3,t4,t5);
/* csi.scm:195: ##sys#peek-nonnull-c-string */
t7=*((C_word*)lf[39]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t2,t6,C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2135,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:214: addext */
f_2042(t2,((C_word*)t0)[4]);}}

/* k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_2418(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2418,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_i_assq(t2,C_retrieve2(lf[65],"command-table"));
if(C_truep(t3)){
t4=((C_word*)t0)[3];
t5=C_i_cadr(t3);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2435,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:313: g216 */
t7=t5;
((C_proc2)C_fast_retrieve_proc(t7))(2,t7,t6);}
else{
t4=C_eqp(t2,lf[75]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2450,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:320: read */
t6=*((C_word*)lf[77]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=C_eqp(t2,lf[78]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2473,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:324: read */
t7=*((C_word*)lf[77]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=C_eqp(t2,lf[79]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2491,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:329: read */
t8=*((C_word*)lf[77]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=C_eqp(t2,lf[81]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2506,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:333: read */
t9=*((C_word*)lf[77]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=C_eqp(t2,lf[83]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2521,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:337: read */
t10=*((C_word*)lf[77]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t9=C_eqp(t2,lf[84]);
if(C_truep(t9)){
/* csi.scm:342: report */
t10=C_fast_retrieve(lf[85]);
f_3121(2,t10,((C_word*)t0)[3]);}
else{
t10=C_eqp(t2,lf[86]);
if(C_truep(t10)){
/* csi.scm:343: ##sys#quit-hook */
t11=C_fast_retrieve(lf[87]);
f_5902(2,t11,((C_word*)t0)[3]);}
else{
t11=C_eqp(t2,lf[88]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2560,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2593,a[2]=((C_word*)t0)[7],a[3]=t12,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:345: read-line */
t14=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,t13);}
else{
t12=C_eqp(t2,lf[90]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2602,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2652,a[2]=((C_word*)t0)[7],a[3]=t13,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:349: read-line */
t15=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,t14);}
else{
t13=C_eqp(t2,lf[95]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2661,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:353: read */
t15=*((C_word*)lf[77]+1);
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,t14);}
else{
t14=C_eqp(t2,lf[99]);
if(C_truep(t14)){
if(C_truep(C_fast_retrieve(lf[100]))){
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2713,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t16=C_a_i_list1(&a,1,C_fast_retrieve(lf[100]));
/* csi.scm:359: history-add */
t17=C_fast_retrieve(lf[47]);
f_2200(3,t17,t15,t16);}
else{
t15=C_SCHEME_UNDEFINED;
t16=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,t15);}}
else{
t15=C_eqp(t2,lf[101]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2729,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2747,a[2]=t16,tmp=(C_word)a,a+=3,tmp);
t18=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2751,a[2]=t17,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:364: editor-command */
t19=C_fast_retrieve(lf[6]);
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,t18);}
else{
t16=C_eqp(t2,lf[105]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2767,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t18=*((C_word*)lf[48]+1);
/* csi.scm:241: vector-fill! */
t19=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t19+1)))(4,t19,t17,C_fast_retrieve(lf[45]),*((C_word*)lf[48]+1));}
else{
t17=C_eqp(t2,lf[106]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2779,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:372: history-show */
t19=C_fast_retrieve(lf[51]);
f_2249(2,t19,t18);}
else{
t18=C_eqp(t2,lf[107]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2791,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:375: show-frameinfo */
f_4826(t19,C_retrieve2(lf[7],"selected-frame"));}
else{
t19=C_eqp(t2,lf[109]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2803,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2810,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:378: read */
t22=*((C_word*)lf[77]+1);
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,t21);}
else{
t20=C_eqp(t2,lf[112]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2823,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:381: read */
t22=*((C_word*)lf[77]+1);
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,t21);}
else{
t21=C_eqp(t2,lf[119]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2832,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:383: read-line */
t23=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,t22);}
else{
t22=C_eqp(t2,lf[120]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2851,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:388: display */
t24=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t24+1)))(3,t24,t23,lf[122]);}
else{
t23=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2902,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:419: printf */
t24=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t24+1)))(4,t24,t23,lf[123],((C_word*)t0)[2]);}}}}}}}}}}}}}}}}}}}}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2948,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2954,a[2]=((C_word*)t0)[10],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:422: ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],t2,t3);}}

/* k4896 in k4893 in k4890 in doloop799 in k4850 in show-frameinfo in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_4898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4898,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4901,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5070,a[2]=t2,a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[7])){
t4=C_slot(((C_word*)t0)[9],C_fix(2));
t5=t3;
f_5070(t5,C_i_pairp(t4));}
else{
t4=t3;
f_5070(t4,C_SCHEME_FALSE);}}

/* k2808 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2810,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t1;
t4=C_i_numberp(t3);
t5=C_i_not(t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5111,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t5)){
t7=t6;
f_5111(t7,t5);}
else{
t7=C_i_not(C_fast_retrieve(lf[111]));
if(C_truep(t7)){
t8=t6;
f_5111(t8,t7);}
else{
t8=C_fixnum_lessp(t3,C_fix(0));
if(C_truep(t8)){
t9=t6;
f_5111(t9,t8);}
else{
t9=C_i_length(C_fast_retrieve(lf[111]));
t10=t6;
f_5111(t10,C_fixnum_greater_or_equal_p(t3,t9));}}}}

/* k5764 in k5757 in evalstring in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in ... */
static void C_ccall f_5766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5766,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5768,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_5768(t5,((C_word*)t0)[4],t1);}

/* doloop1239 in k5764 in k5757 in evalstring in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in ... */
static void C_fcall f_5768(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5768,NULL,3,t0,t1,t2);}
if(C_truep(C_eofp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5778,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5789,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5791,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1032: ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,*((C_word*)lf[280]+1));}}

/* k6708 in k6695 in a6686 in k6679 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_6710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6710,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6750,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csi.scm:920: rename1013 */
t4=((C_word*)t0)[5];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,lf[378]);}

/* k2635 in for-each-loop260 in k2600 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2627(t3,((C_word*)t0)[4],t2);}

/* map-loop1330 in k6283 in k6279 in k6273 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in ... */
static void C_fcall f_6293(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6293,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6322,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:1060: g1336 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5776 in doloop1239 in k5764 in k5757 in evalstring in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in ... */
static void C_ccall f_5778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5778,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5785,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1030: read */
t3=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k6289 in k6283 in k6279 in k6273 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in ... */
static void C_ccall f_6291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:1059: append */
t2=*((C_word*)lf[240]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1,C_fast_retrieve(lf[142]),((C_word*)t0)[4]);}

/* k6283 in k6279 in k6273 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in ... */
static void C_ccall f_6285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6285,2,t0,t1);}
t2=C_i_check_list_2(t1,lf[239]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6291,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6293,a[2]=((C_word*)t0)[5],a[3]=t5,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_6293(t7,t3,t1);}

/* k6279 in k6273 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in ... */
static void C_ccall f_6281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6281,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_fast_retrieve(lf[30]);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6285,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t6,a[6]=t4,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* csi.scm:1060: collect-options */
t9=((C_word*)((C_word*)t0)[4])[1];
f_5670(t9,t8,lf[335]);}

/* k2849 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2851,2,t0,t1);}
t2=C_retrieve2(lf[65],"command-table");
t3=C_i_check_list_2(C_retrieve2(lf[65],"command-table"),lf[94]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2873,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2878,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_2878(t8,t4,C_retrieve2(lf[65],"command-table"));}

/* k6736 in k6728 in k6748 in k6708 in k6695 in a6686 in k6679 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 in ... */
static void C_ccall f_6738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6738,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=C_a_i_cons(&a,2,t1,t3);
t5=C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_cons(&a,2,((C_word*)t0)[7],t7));}

/* k6728 in k6748 in k6708 in k6695 in a6686 in k6679 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_6730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6730,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6738,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm:920: rename1013 */
t4=((C_word*)t0)[7];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,lf[267]);}

/* k3755 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_3757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3757,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3760,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:631: ##sys#qualified-symbol? */
((C_proc3)C_fast_retrieve_symbol_proc(lf[197]))(3,*((C_word*)lf[197]+1),t2,((C_word*)t0)[2]);}

/* k6491 in k6488 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in ... */
static void C_ccall f_6493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:1035: exit */
t2=C_fast_retrieve(lf[74]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k2611 in a2608 in g261 in k2600 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:350: print* */
t2=*((C_word*)lf[91]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[92]);}

/* k6488 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in ... */
static void C_ccall f_6490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6490,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6493,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1034: print-usage */
t3=C_fast_retrieve(lf[9]);
f_1894(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
f_5809(2,t2,C_SCHEME_UNDEFINED);}}

/* map-loop1180 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in ... */
static void C_fcall f_6498(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6498,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6527,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:1010: g1186 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5575 in k5484 in loop in canonicalize-args in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_5577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5577,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* for-each-loop260 in k2600 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_2627(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2627,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2637,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:349: g261 */
t5=((C_word*)t0)[3];
f_2603(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_3741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3741,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3748,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:627: ##sys#symbol->string */
((C_proc3)C_fast_retrieve_symbol_proc(lf[186]))(3,*((C_word*)lf[186]+1),t2,((C_word*)t0)[4]);}
else{
if(C_truep(C_i_symbolp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3757,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3841,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:629: ##sys#symbol-has-toplevel-binding? */
((C_proc3)C_fast_retrieve_symbol_proc(lf[199]))(3,*((C_word*)lf[199]+1),t3,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[4];
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3401,tmp=(C_word)a,a+=2,tmp);
t4=f_3401(t2,t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3853,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t4)){
t6=t5;
f_3853(t6,t4);}
else{
t6=((C_word*)t0)[4];
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3436,tmp=(C_word)a,a+=2,tmp);
t8=t5;
f_3853(t8,f_3436(t6));}}}}

/* k6653 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_6655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:984: canonicalize-args */
f_5458(((C_word*)t0)[2],t1);}

/* k3746 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_3748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:626: fprintf */
t2=*((C_word*)lf[162]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[185],t1);}

/* k6657 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_6659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6659,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[365]);
t3=((C_word*)t0)[2];
t4=t2;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2980,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:453: open-input-string */
t6=C_fast_retrieve(lf[281]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* k2830 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2832,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2835,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:384: system */
t3=C_fast_retrieve(lf[103]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k6649 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 in ... */
static void C_ccall f_6651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:1003: append */
t2=*((C_word*)lf[240]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)((C_word*)t0)[3])[1]);}

/* k6482 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in ... */
static void C_ccall f_6484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:1038: exit */
t2=C_fast_retrieve(lf[74]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k2620 in k2600 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[48]+1));}

/* k3223 in k3220 in k3217 in k3214 in k3211 in k3159 in k3156 in k3139 in k3136 in k3133 in a3130 in k3127 in report in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in ... */
static void C_ccall f_3225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* k3220 in k3217 in k3214 in k3211 in k3159 in k3156 in k3139 in k3136 in k3133 in a3130 in k3127 in report in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in ... */
static void C_ccall f_3222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3222,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3225,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_fudge(C_fix(15)))){
/* csi.scm:538: display */
t3=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[133]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_1865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1865,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1868,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_1868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1871,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1860 in k1857 in k1854 */
static void C_ccall f_1862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1862,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1865,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_chicken_2dsyntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2821 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2823,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_fast_retrieve(lf[111]);
t4=(C_truep(C_fast_retrieve(lf[111]))?C_fast_retrieve(lf[111]):C_SCHEME_END_OF_LIST);
t5=t4;
t6=C_i_length(t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5168,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_symbolp(t1))){
t8=t7;
f_5168(t8,C_slot(t1,C_fix(1)));}
else{
if(C_truep(C_i_stringp(t1))){
t8=t7;
f_5168(t8,t1);}
else{
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5395,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:876: display */
t9=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,lf[118]);}}}

/* k6748 in k6708 in k6695 in a6686 in k6679 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_6750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6750,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[2],t2);
t4=C_a_i_cons(&a,2,lf[376],t3);
t5=C_a_i_cons(&a,2,t1,t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6730,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm:920: rename1013 */
t8=((C_word*)t0)[6];
((C_proc3)C_fast_retrieve_proc(t8))(3,t8,t7,lf[377]);}

/* k6472 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in ... */
static void C_ccall f_6474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:1042: print */
t2=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3251 in k3247 in k3239 in k3211 in k3159 in k3156 in k3139 in k3136 in k3133 in a3130 in k3127 in report in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in ... */
static void C_ccall f_3253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3253,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3257,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* csi.scm:522: build-platform */
t4=C_fast_retrieve(lf[146]);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k1857 in k1854 */
static void C_ccall f_1859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1859,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1862,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_chicken_2dsyntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1854 */
static void C_ccall f_1856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1856,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1859,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2836 in k2833 in k2830 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* k2833 in k2830 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2835,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2838,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_list1(&a,1,t2);
/* csi.scm:385: history-add */
t5=C_fast_retrieve(lf[47]);
f_2200(3,t5,t3,t4);}

/* k4425 in k4344 in k4110 in k3996 in k3968 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in ... */
static void C_ccall f_4427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:734: descseq */
t2=((C_word*)t0)[2];
f_3474(6,t2,((C_word*)t0)[3],C_SCHEME_FALSE,*((C_word*)lf[182]+1),*((C_word*)lf[184]+1),C_fix(1));}

/* k3239 in k3211 in k3159 in k3156 in k3139 in k3136 in k3133 in a3130 in k3127 in report in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in ... */
static void C_ccall f_3241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3241,2,t0,t1);}
t2=t1;
t3=C_fudge(C_fix(3));
t4=(C_truep(t3)?lf[135]:lf[136]);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3249,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t5,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* csi.scm:520: software-type */
t7=C_fast_retrieve(lf[148]);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_1889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1889,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1892,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_1892(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6880,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:77: get-environment-variable */
t4=C_fast_retrieve(lf[43]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[406]);}}

/* k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_1884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1884,2,t0,t1);}
t2=C_mutate2((C_word*)lf[6]+1 /* (set! editor-command ...) */,t1);
t3=lf[7] /* selected-frame */ =C_SCHEME_FALSE;;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1889,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:76: get-environment-variable */
t5=C_fast_retrieve(lf[43]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[407]);}

/* k3255 in k3251 in k3247 in k3239 in k3211 in k3159 in k3156 in k3139 in k3136 in k3133 in a3130 in k3127 in report in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in ... */
static void C_ccall f_3257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3257,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3261,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* csi.scm:524: repository-path */
t4=C_fast_retrieve(lf[145]);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k4415 in map-loop663 in g658 in k4344 in k4110 in k3996 in k3968 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in ... */
static void C_ccall f_4417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4417,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4388(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4388(t6,((C_word*)t0)[5],t5);}}

/* k3271 in k3267 in k3263 in k3259 in k3255 in k3251 in k3247 in k3239 in k3211 in k3159 in k3156 in k3139 in k3136 in k3133 in a3130 in k3127 in report in k3118 in k3115 in k2972 in k2322 in k2021 in ... */
static void C_ccall f_3273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3273,2,t0,t1);}
t2=t1;
t3=C_i_vector_ref(((C_word*)t0)[2],C_fix(2));
t4=t3;
t5=C_i_vector_ref(((C_word*)t0)[3],C_fix(0));
t6=t5;
t7=C_fudge(C_fix(17));
t8=(C_truep(t7)?lf[137]:lf[138]);
t9=t8;
t10=C_i_vector_ref(((C_word*)t0)[3],C_fix(1));
t11=t10;
t12=C_i_vector_ref(((C_word*)t0)[3],C_fix(2));
t13=t12;
t14=C_fudge(C_fix(18));
t15=C_i_nequalp(C_fix(1),t14);
t16=(C_truep(t15)?lf[139]:lf[140]);
t17=t16;
t18=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_3301,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=t2,a[13]=t4,a[14]=t6,a[15]=t9,a[16]=t11,a[17]=t13,a[18]=t17,tmp=(C_word)a,a+=19,tmp);
/* csi.scm:535: argv */
t19=((C_word*)t0)[14];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,t18);}

/* k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_1871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1871,2,t0,t1);}
t2=C_mutate2(&lf[0] /* (set! constant22 ...) */,lf[1]);
t3=C_set_block_item(lf[2] /* ##sys#repl-print-length-limit */,0,C_fix(2048));
t4=C_a_i_cons(&a,2,lf[3],C_fast_retrieve(lf[4]));
t5=C_mutate2((C_word*)lf[4]+1 /* (set! ##sys#features ...) */,t4);
t6=C_set_block_item(lf[5] /* ##sys#notices-enabled */,0,C_SCHEME_TRUE);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1884,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:72: make-parameter */
t8=C_fast_retrieve(lf[408]);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,C_SCHEME_FALSE);}

/* k3247 in k3239 in k3211 in k3159 in k3156 in k3139 in k3136 in k3133 in a3130 in k3127 in report in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in ... */
static void C_ccall f_3249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3249,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3253,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* csi.scm:521: software-version */
t4=C_fast_retrieve(lf[147]);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5567 in k5484 in loop in canonicalize-args in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_5569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_fast_retrieve(lf[276]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5991 in doloop1370 in k5874 in k5871 in k5868 in k5865 in k5862 in k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in ... */
static void C_ccall f_5993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=((C_word*)((C_word*)t0)[2])[1];
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_u_i_cdr(t2));
t4=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t5=((C_word*)((C_word*)t0)[3])[1];
f_5881(t5,((C_word*)t0)[4],t4);}

/* k3259 in k3255 in k3251 in k3247 in k3239 in k3211 in k3159 in k3156 in k3139 in k3136 in k3133 in a3130 in k3127 in report in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in ... */
static void C_ccall f_3261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3261,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3265,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t2,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3323,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:526: keyword-style */
t5=C_fast_retrieve(lf[144]);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k5393 in k2821 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_5395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5168(t2,C_SCHEME_FALSE);}

/* k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_5398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5398,2,t0,t1);}
t2=C_establish_signal_handler(C_fix((C_word)SIGINT),C_fix((C_word)SIGINT));
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6673,tmp=(C_word)a,a+=2,tmp);
t4=C_i_setslot(C_fast_retrieve(lf[267]),C_fix((C_word)SIGINT),t3);
t5=C_mutate2(&lf[268] /* (set! member* ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5403,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate2(&lf[269] /* (set! canonicalize-args ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5458,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate2((C_word*)lf[278]+1 /* (set! ##csi#run ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5634,tmp=(C_word)a,a+=2,tmp));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6665,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1139: run */
t9=C_fast_retrieve(lf[278]);
f_5634(2,t9,t8);}

/* k6795 in a6792 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_6797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6797,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6800,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_stringp(((C_word*)t3)[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6856,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:435: ##sys#string->symbol */
((C_proc3)C_fast_retrieve_symbol_proc(lf[393]))(3,*((C_word*)lf[393]+1),t5,((C_word*)t3)[1]);}
else{
t5=t4;
f_6800(t5,C_SCHEME_UNDEFINED);}}

/* a6792 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_6793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6793,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6797,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:433: read */
t3=*((C_word*)lf[77]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5209 in k5206 in fail in a5200 in k5166 in k2821 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_5211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=*((C_word*)lf[48]+1);
/* csi.scm:889: return */
t3=((C_word*)t0)[2];
((C_proc3)C_fast_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],*((C_word*)lf[48]+1));}

/* k5959 in doloop1370 in k5874 in k5871 in k5868 in k5865 in k5862 in k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in ... */
static void C_ccall f_5961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5961,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=C_a_i_list(&a,3,lf[295],t2,C_SCHEME_TRUE);
/* csi.scm:1101: eval */
t4=C_fast_retrieve(lf[67]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_1892(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1892,NULL,2,t0,t1);}
t2=C_mutate2(&lf[8] /* (set! default-editor ...) */,t1);
t3=C_mutate2((C_word*)lf[9]+1 /* (set! ##csi#print-usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1894,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate2((C_word*)lf[16]+1 /* (set! ##csi#print-banner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1922,tmp=(C_word)a,a+=2,tmp));
t5=C_fast_retrieve(lf[23]);
t6=C_mutate2((C_word*)lf[23]+1 /* (set! ##sys#user-read-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1938,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=C_mutate2((C_word*)lf[27]+1 /* (set! ##sys#sharp-number-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1967,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate2(&lf[28] /* (set! dirseparator? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1977,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate2((C_word*)lf[30]+1 /* (set! ##csi#chop-separator ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1992,tmp=(C_word)a,a+=2,tmp));
t10=C_set_block_item(lf[32] /* @ */,0,C_SCHEME_FALSE);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2023,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#make-string */
((C_proc4)C_fast_retrieve_symbol_proc(lf[402]))(4,*((C_word*)lf[402]+1),t11,C_fix(256),C_make_character(32));}

/* ##csi#print-usage in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_1894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1898,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:86: display */
t3=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[15]);}

/* k1896 in print-usage in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_1898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1898,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1901,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1908,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_a_i_cons(&a,2,lf[12],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,lf[0],t4);
t6=C_a_i_cons(&a,2,lf[13],t5);
/* csi.scm:85: ##sys#print-to-string */
((C_proc3)C_fast_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),t3,t6);}

/* k3267 in k3263 in k3259 in k3255 in k3251 in k3247 in k3239 in k3211 in k3159 in k3156 in k3139 in k3136 in k3133 in a3130 in k3127 in report in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in ... */
static void C_ccall f_3269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3269,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3273,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t2,a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t4=C_i_vector_ref(((C_word*)t0)[2],C_fix(1));
/* csi.scm:528: shorten */
f_3143(t3,t4);}

/* k3263 in k3259 in k3255 in k3251 in k3247 in k3239 in k3211 in k3159 in k3156 in k3139 in k3136 in k3133 in a3130 in k3127 in report in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in ... */
static void C_ccall f_3265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3265,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3269,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t4=C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
/* csi.scm:527: shorten */
f_3143(t3,t4);}

/* doloop917 in a5200 in k5166 in k2821 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_5223(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
loop:
a=C_alloc(20);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5223,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
/* csi.scm:891: fail */
t3=((C_word*)t0)[2];
f_5204(t3,t1,lf[113]);}
else{
t3=C_i_car(t2);
t4=C_eqp(C_retrieve2(lf[7],"selected-frame"),t3);
t5=C_slot(t3,C_fix(2));
t6=C_i_structurep(t5,lf[114]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5248,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(C_truep(t4)?t6:C_SCHEME_FALSE);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5257,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t10=C_slot(t5,C_fix(2));
t11=C_slot(t5,C_fix(3));
t12=C_i_check_list_2(t10,lf[94]);
t13=C_i_check_list_2(t11,lf[94]);
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5333,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5342,a[2]=t16,a[3]=t9,tmp=(C_word)a,a+=4,tmp));
t18=((C_word*)t16)[1];
f_5342(t18,t14,t10,t11);}
else{
t9=t2;
t10=C_u_i_cdr(t9);
t21=t1;
t22=t10;
t1=t21;
t2=t22;
goto loop;}}}

/* k6569 in k6560 in k6557 in k6554 in k6551 in k6548 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in ... */
static void C_ccall f_6571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_u_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_5650(t3,C_i_set_car(t2,t1));}
else{
t2=((C_word*)t0)[3];
f_5650(t2,C_SCHEME_FALSE);}}

/* k2989 in map-loop348 in k3001 in k2998 in k2978 in k6657 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in ... */
static void C_ccall f_2991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2991,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2994,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:458: write */
t4=*((C_word*)lf[187]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],t2);}

/* k2992 in k2989 in map-loop348 in k3001 in k2998 in k2978 in k6657 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in ... */
static void C_ccall f_2994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:459: get-output-string */
t2=C_fast_retrieve(lf[366]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3507 in loop1 in k3479 in k3601 in descseq in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_3509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3509,2,t0,t1);}
t2=t1;
t3=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t4=C_fixnum_plus(((C_word*)t0)[3],t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3518,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t6,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));
t8=((C_word*)t6)[1];
f_3518(t8,((C_word*)t0)[9],C_fix(1),t4);}

/* k4184 in doloop590 in k4144 in k4141 in k4110 in k3996 in k3968 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in ... */
static void C_ccall f_4186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4157(t3,((C_word*)t0)[4],t2);}

/* k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2974,2,t0,t1);}
t2=C_fast_retrieve(lf[125]);
t3=C_fast_retrieve(lf[126]);
t4=C_fast_retrieve(lf[127]);
t5=C_fast_retrieve(lf[128]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3117,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:476: get-environment-variable */
t7=C_fast_retrieve(lf[43]);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[385]);}

/* k4553 in k4543 in k4500 in body700 in dump in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_4555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:758: hexdump */
t2=C_fast_retrieve(lf[224]);
f_4623(6,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1,*((C_word*)lf[225]+1),((C_word*)t0)[4]);}

/* for-each-loop595 in doloop590 in k4144 in k4141 in k4110 in k3996 in k3968 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in ... */
static void C_fcall f_4195(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4195,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4205,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:702: g596 */
t5=((C_word*)t0)[3];
f_4165(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* a3102 in a3063 in a3045 in k2978 in k6657 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 in ... */
static void C_ccall f_3103(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3103r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3103r(t0,t1,t2);}}

static void C_ccall f_3103r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3109,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:460: k368 */
t4=((C_word*)t0)[2];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t1,t3);}

/* def-out703 in dump in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_4583(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4583,NULL,3,t0,t1,t2);}
/* csi.scm:746: body700 */
t3=((C_word*)t0)[2];
f_4477(t3,t1,t2,*((C_word*)lf[52]+1));}

/* a3108 in a3102 in a3063 in a3045 in k2978 in k6657 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in ... */
static void C_ccall f_3109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3109,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* def-len702 in dump in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_4588(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4588,NULL,2,t0,t1);}
/* csi.scm:746: def-out703 */
t2=((C_word*)t0)[2];
f_4583(t2,t1,C_SCHEME_FALSE);}

/* k3299 in k3271 in k3267 in k3263 in k3259 in k3255 in k3251 in k3247 in k3239 in k3211 in k3159 in k3156 in k3139 in k3136 in k3133 in a3130 in k3127 in report in k3118 in k3115 in k2972 in k2322 in ... */
static void C_ccall f_3301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:503: printf */
t2=*((C_word*)lf[53]+1);
((C_proc21)(void*)(*((C_word*)t2+1)))(21,t2,((C_word*)t0)[2],lf[141],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[8],((C_word*)t0)[9],C_fast_retrieve(lf[142]),((C_word*)t0)[10],((C_word*)t0)[11],((C_word*)t0)[12],((C_word*)t0)[13],((C_word*)t0)[14],((C_word*)t0)[15],((C_word*)t0)[16],((C_word*)t0)[17],((C_word*)t0)[18],t1);}

/* k3194 in k3177 in k3164 in g437 in k3159 in k3156 in k3139 in k3136 in k3133 in a3130 in k3127 in report in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in ... */
static void C_ccall f_3196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:501: display */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* a3559 in loop2 in k3507 in loop1 in k3479 in k3601 in descseq in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in ... */
static void C_ccall f_3560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3560,2,t0,t1);}
/* csi.scm:595: fprintf */
t2=*((C_word*)lf[162]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[2],lf[167],((C_word*)t0)[3],((C_word*)t0)[4]);}

/* g647 in k4344 in k4110 in k3996 in k3968 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in ... */
static void C_fcall f_4350(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4350,NULL,3,t0,t1,t2);}
/* csi.scm:728: g655 */
t3=t2;
((C_proc4)C_fast_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in ... */
static void C_ccall f_5845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5845,2,t0,t1);}
t2=C_fast_retrieve(lf[283]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5848,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
/* csi.scm:1056: collect-options */
t4=((C_word*)((C_word*)t0)[11])[1];
f_5670(t4,t3,lf[337]);}

/* k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in ... */
static void C_ccall f_5848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5848,2,t0,t1);}
t2=C_i_check_list_2(t1,lf[94]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6363,a[2]=t5,a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_6363(t7,t3,t1);}

/* for-each-loop1287 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in ... */
static void C_fcall f_6363(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6363,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6373,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:1056: g1288 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g658 in k4344 in k4110 in k3996 in k3968 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in ... */
static void C_fcall f_4364(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4364,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4372,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_fast_retrieve(lf[67]);
t9=C_i_cdr(t2);
t10=C_i_check_list_2(t9,lf[239]);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4382,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4388,a[2]=t7,a[3]=t13,a[4]=t5,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_4388(t15,t11,t9);}

/* k3586 in loop2 in k3507 in loop1 in k3479 in k3601 in descseq in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in ... */
static void C_ccall f_3588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_eqp(((C_word*)t0)[2],t1);
if(C_truep(t2)){
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* csi.scm:602: loop2 */
t5=((C_word*)((C_word*)t0)[5])[1];
f_3518(t5,((C_word*)t0)[6],t3,t4);}
else{
/* csi.scm:603: loop2 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3518(t3,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[7]);}}

/* k4850 in show-frameinfo in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_4852(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4852,NULL,2,t0,t1);}
t2=C_mutate2(&lf[7] /* (set! selected-frame ...) */,t1);
t3=C_fixnum_difference(((C_word*)t0)[2],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4861,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4861(t7,((C_word*)t0)[4],((C_word*)t0)[5],t3);}

/* k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in ... */
static void C_ccall f_5854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6271,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_fast_retrieve(lf[30]);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6275,a[2]=t3,a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=t7,a[6]=t5,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
/* csi.scm:1059: collect-options */
t10=((C_word*)((C_word*)t0)[11])[1];
f_5670(t10,t9,lf[336]);}

/* k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in ... */
static void C_ccall f_5858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5858,2,t0,t1);}
t2=C_mutate2((C_word*)lf[142]+1 /* (set! ##sys#include-pathnames ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5861,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[9])){
t4=C_i_cdr(((C_word*)t0)[9]);
if(C_truep(C_i_pairp(t4))){
t5=C_i_cadr(((C_word*)t0)[9]);
if(C_truep(C_i_string_equal_p(lf[327],t5))){
/* csi.scm:1068: keyword-style */
t6=C_fast_retrieve(lf[144]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t3,lf[328]);}
else{
t6=C_u_i_cdr(((C_word*)t0)[9]);
t7=C_u_i_car(t6);
if(C_truep(C_i_string_equal_p(lf[329],t7))){
/* csi.scm:1070: keyword-style */
t8=C_fast_retrieve(lf[144]);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t3,lf[319]);}
else{
t8=C_u_i_cdr(((C_word*)t0)[9]);
t9=C_u_i_car(t8);
if(C_truep(C_i_string_equal_p(lf[330],t9))){
/* csi.scm:1072: keyword-style */
t10=C_fast_retrieve(lf[144]);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t3,lf[331]);}
else{
t10=t3;
f_5861(2,t10,C_SCHEME_UNDEFINED);}}}}
else{
/* csi.scm:1066: ##sys#error */
t5=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,lf[332]);}}
else{
t4=t3;
f_5861(2,t4,C_SCHEME_UNDEFINED);}}

/* k4370 in g658 in k4344 in k4110 in k3996 in k3968 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in ... */
static void C_ccall f_4372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k6355 in map-loop1304 in k6273 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in ... */
static void C_ccall f_6357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6357,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6328(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6328(t6,((C_word*)t0)[5],t5);}}

/* k4961 in doloop847 in k4943 in g834 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4893 in k4890 in doloop799 in k4850 in show-frameinfo in k3464 in k3118 in k3115 in k2972 in k2322 in ... */
static void C_ccall f_4963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4963,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4966,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* csi.scm:841: ##sys#print */
t4=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_TRUE,((C_word*)t0)[8]);}

/* k4967 in k4964 in k4961 in doloop847 in k4943 in g834 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4893 in k4890 in doloop799 in k4850 in show-frameinfo in k3464 in k3118 in k3115 in ... */
static void C_ccall f_4969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4969,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4972,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_slot(((C_word*)t0)[6],((C_word*)t0)[2]);
/* csi.scm:845: prin1 */
f_4829(t2,t3);}

/* k4380 in g658 in k4344 in k4110 in k3996 in k3968 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in ... */
static void C_ccall f_4382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4382,2,t0,t1);}
t2=C_a_i_list1(&a,1,C_fix(0));
/* csi.scm:731: append */
t3=*((C_word*)lf[240]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k4964 in k4961 in doloop847 in k4943 in g834 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4893 in k4890 in doloop799 in k4850 in show-frameinfo in k3464 in k3118 in k3115 in k2972 in ... */
static void C_ccall f_4966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4969,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* csi.scm:841: ##sys#print */
t3=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[259],C_SCHEME_FALSE,((C_word*)t0)[8]);}

/* k5054 in k5051 in k4908 in k4905 in k4902 in k4899 in k4896 in k4893 in k4890 in doloop799 in k4850 in show-frameinfo in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in ... */
static void C_ccall f_5056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:833: ##sys#print */
t2=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[262],C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* map-loop663 in g658 in k4344 in k4110 in k3996 in k3968 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in ... */
static void C_fcall f_4388(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4388,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4417,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:731: g669 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2956 in a2953 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k5051 in k4908 in k4905 in k4902 in k4899 in k4896 in k4893 in k4890 in doloop799 in k4850 in show-frameinfo in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in ... */
static void C_ccall f_5053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5053,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5056,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:833: ##sys#print */
t3=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* a2953 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2954(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2954r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2954r(t0,t1,t2);}}

static void C_ccall f_2954r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2958,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm:423: history-add */
t4=C_fast_retrieve(lf[47]);
f_2200(3,t4,t3,t2);}

/* a4834 in prin1 in show-frameinfo in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_4835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4835,2,t0,t1);}
/* csi.scm:812: ##sys#print */
t2=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[2],C_SCHEME_TRUE,*((C_word*)lf[52]+1));}

/* doloop799 in k4850 in show-frameinfo in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_4861(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4861,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_i_car(t2);
t5=t4;
t6=C_eqp(C_retrieve2(lf[7],"selected-frame"),t5);
t7=t6;
t8=C_slot(t5,C_fix(1));
t9=t8;
t10=C_slot(t5,C_fix(2));
t11=t10;
t12=C_i_structurep(t11,lf[114]);
t13=t12;
t14=(C_truep(t13)?C_slot(t11,C_fix(1)):t11);
t15=t14;
t16=*((C_word*)lf[52]+1);
t17=*((C_word*)lf[52]+1);
t18=C_i_check_port_2(*((C_word*)lf[52]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[53]);
t19=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4892,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=t7,a[7]=t13,a[8]=((C_word*)t0)[3],a[9]=t11,a[10]=t9,a[11]=t15,a[12]=t16,a[13]=t5,tmp=(C_word)a,a+=14,tmp);
if(C_truep(t7)){
/* csi.scm:819: ##sys#print */
t20=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t20+1)))(5,t20,t19,C_make_character(42),C_SCHEME_FALSE,*((C_word*)lf[52]+1));}
else{
/* csi.scm:819: ##sys#print */
t20=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t20+1)))(5,t20,t19,C_make_character(32),C_SCHEME_FALSE,t16);}}}

/* prin1 in show-frameinfo in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_4829(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4829,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4835,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:809: ##sys#with-print-length-limit */
((C_proc4)C_fast_retrieve_symbol_proc(lf[55]))(4,*((C_word*)lf[55]+1),t1,C_fix(100),t3);}

/* k4822 in doloop737 in hexdump in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_4824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:777: display */
t2=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* show-frameinfo in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_4826(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4826,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4829,tmp=(C_word)a,a+=2,tmp);
t4=C_fast_retrieve(lf[111]);
t5=(C_truep(C_fast_retrieve(lf[111]))?C_fast_retrieve(lf[111]):C_SCHEME_END_OF_LIST);
t6=t5;
t7=C_i_length(t6);
t8=t7;
t9=t2;
t10=(C_truep(C_u_i_memq(t9,t6))?t2:C_SCHEME_FALSE);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4852,a[2]=t8,a[3]=t3,a[4]=t1,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t10)){
t12=t11;
f_4852(t12,t10);}
else{
if(C_truep(C_fixnum_greaterp(t8,C_fix(0)))){
t12=C_fixnum_difference(t8,C_fix(1));
t13=t11;
f_4852(t13,C_i_list_ref(t6,t12));}
else{
t12=t11;
f_4852(t12,C_SCHEME_FALSE);}}}

/* k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in ... */
static void C_ccall f_5809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5809,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5812,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(C_i_member(lf[350],((C_word*)((C_word*)t0)[6])[1]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6484,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1037: print-banner */
t4=C_fast_retrieve(lf[16]);
f_1922(2,t4,t3);}
else{
t3=t2;
f_5812(2,t3,C_SCHEME_UNDEFINED);}}

/* k2765 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[48]+1));}

/* k5068 in k4896 in k4893 in k4890 in doloop799 in k4850 in show-frameinfo in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 in ... */
static void C_fcall f_5070(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm:819: ##sys#print */
t2=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[264],C_SCHEME_FALSE,((C_word*)t0)[3]);}
else{
/* csi.scm:819: ##sys#print */
t2=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[265],C_SCHEME_FALSE,((C_word*)t0)[3]);}}

/* k4811 in k4793 in doloop747 in k4667 in k4664 in doloop737 in hexdump in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 in ... */
static void C_ccall f_4813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:789: display */
t2=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* k4815 in k4793 in doloop747 in k4667 in k4664 in doloop737 in hexdump in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 in ... */
static void C_ccall f_4817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:789: justify */
f_4626(((C_word*)t0)[3],t1,C_fix(2),C_fix(16),C_make_character(48));}

/* map-loop410 in k3156 in k3139 in k3136 in k3133 in a3130 in k3127 in report in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 in ... */
static void C_fcall f_3355(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3355,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3384,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:486: g416 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in ... */
static void C_ccall f_5812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5812,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5815,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(C_i_member(lf[348],((C_word*)((C_word*)t0)[6])[1]))){
t3=C_set_block_item(lf[349] /* ##sys#setup-mode */,0,C_SCHEME_TRUE);
t4=t2;
f_5815(t4,t3);}
else{
t3=t2;
f_5815(t3,C_SCHEME_UNDEFINED);}}

/* k3351 in k3156 in k3139 in k3136 in k3133 in a3130 in k3127 in report in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 in ... */
static void C_ccall f_3353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:486: sort */
t2=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,*((C_word*)lf[151]+1));}

/* k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in ... */
static void C_fcall f_5815(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5815,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5818,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(C_i_member(lf[347],((C_word*)((C_word*)t0)[6])[1]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6467,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6474,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1042: chicken-version */
t5=C_fast_retrieve(lf[20]);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t3=t2;
f_5818(2,t3,C_SCHEME_UNDEFINED);}}

/* k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in ... */
static void C_ccall f_5818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5821,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6454,a[2]=t2,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1044: member* */
f_5403(t3,lf[346],((C_word*)((C_word*)t0)[6])[1]);}

/* k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_3120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3120,2,t0,t1);}
t2=t1;
t3=C_mutate2((C_word*)lf[85]+1 /* (set! ##csi#report ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3121,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t4=C_mutate2(&lf[156] /* (set! ##csi#bytevector-data ...) */,lf[157]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3466,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:571: make-vector */
t6=*((C_word*)lf[383]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_fix(37),C_SCHEME_END_OF_LIST);}

/* ##csi#report in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_3121(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_3121r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3121r(t0,t1,t2);}}

static void C_ccall f_3121r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3129,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_pairp(t2))){
t4=t2;
t5=t3;
f_3129(t5,C_u_i_car(t4));}
else{
t4=t3;
f_3129(t4,*((C_word*)lf[52]+1));}}

/* for-each-loop833 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4893 in k4890 in doloop799 in k4850 in show-frameinfo in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in ... */
static void C_fcall f_5009(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5009,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5019,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
/* csi.scm:837: g834 */
t9=((C_word*)t0)[3];
f_4935(t9,t6,t7,t8);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k3996 in k3968 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_3998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3998,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4005,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:676: ##sys#peek-unsigned-integer */
((C_proc4)C_fast_retrieve_symbol_proc(lf[208]))(4,*((C_word*)lf[208]+1),t2,((C_word*)t0)[2],C_fix(0));}
else{
if(C_truep(C_anypointerp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4106,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:689: ##sys#peek-unsigned-integer */
((C_proc4)C_fast_retrieve_symbol_proc(lf[208]))(4,*((C_word*)lf[208]+1),t2,((C_word*)t0)[2],C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4112,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:690: ##sys#bytevector? */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[244]+1)))(3,*((C_word*)lf[244]+1),t2,((C_word*)t0)[2]);}}}

/* k3127 in report in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_3129(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3129,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3131,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:479: with-output-to-port */
t3=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[6],t1,t2);}

/* k4203 in for-each-loop595 in doloop590 in k4144 in k4141 in k4110 in k3996 in k3968 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in ... */
static void C_ccall f_4205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4195(t3,((C_word*)t0)[4],t2);}

/* k2003 in chop-separator in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* csi.scm:185: substring */
t2=*((C_word*)lf[31]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in ... */
static void C_ccall f_5824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5827,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6433,a[2]=t2,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1050: member* */
f_5403(t3,lf[342],((C_word*)((C_word*)t0)[6])[1]);}

/* k3382 in map-loop410 in k3156 in k3139 in k3136 in k3133 in a3130 in k3127 in report in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in ... */
static void C_ccall f_3384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3384,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3355(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3355(t6,((C_word*)t0)[5],t5);}}

/* k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in ... */
static void C_fcall f_5821(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5821,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5824,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[8])){
t3=t2;
f_5824(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6448,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1048: load-verbose */
t4=C_fast_retrieve(lf[343]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_SCHEME_TRUE);}}

/* k2900 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[48]+1));}

/* k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in ... */
static void C_ccall f_5827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5827,2,t0,t1);}
t2=C_fast_retrieve(lf[282]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5830,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
/* csi.scm:1054: collect-options */
t4=((C_word*)((C_word*)t0)[11])[1];
f_5670(t4,t3,lf[339]);}

/* k4783 in doloop755 in doloop747 in k4667 in k4664 in doloop737 in hexdump in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 in ... */
static void C_ccall f_4785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_difference(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4775(t3,((C_word*)t0)[4],t2);}

/* k5017 in for-each-loop833 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4893 in k4890 in doloop799 in k4850 in show-frameinfo in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in ... */
static void C_ccall f_5019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_slot(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_5009(t4,((C_word*)t0)[5],t2,t3);}

/* k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_3117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3117,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3120,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_3120(2,t3,t1);}
else{
/* ##sys#peek-c-string */
t3=*((C_word*)lf[384]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_PREFIX),C_fix(0));}}

/* k4893 in k4890 in doloop799 in k4850 in show-frameinfo in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_4895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4898,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* csi.scm:819: ##sys#write-char-0 */
((C_proc4)C_fast_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t2,C_make_character(58),((C_word*)t0)[12]);}

/* k4890 in doloop799 in k4850 in show-frameinfo in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_4892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4892,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4895,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* csi.scm:819: ##sys#print */
t3=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[12]);}

/* k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in ... */
static void C_ccall f_5836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5836,2,t0,t1);}
t2=C_fast_retrieve(lf[282]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5839,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
/* csi.scm:1055: collect-options */
t4=((C_word*)((C_word*)t0)[11])[1];
f_5670(t4,t3,lf[338]);}

/* k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in ... */
static void C_ccall f_5830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5830,2,t0,t1);}
t2=C_i_check_list_2(t1,lf[94]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5836,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6409,a[2]=t5,a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_6409(t7,t3,t1);}

/* k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in ... */
static void C_ccall f_5839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5839,2,t0,t1);}
t2=C_i_check_list_2(t1,lf[94]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5845,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6386,a[2]=t5,a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_6386(t7,t3,t1);}

/* k3139 in k3136 in k3133 in a3130 in k3127 in report in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_3141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3141,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3143,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3158,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* csi.scm:485: printf */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[152]);}

/* shorten in k3139 in k3136 in k3133 in a3130 in k3127 in report in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_3143(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3143,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3151,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_a_i_times(&a,2,t2,C_fix(100));
/* csi.scm:484: truncate */
t5=*((C_word*)lf[129]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* member* in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_5403(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5403,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5409,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5409(t7,t1,t3);}

/* loop in member* in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_5409(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5409,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5421,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_5421(t6,t1,((C_word*)t0)[3]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k4262 in loop in k4243 in g618 in k4238 in k4110 in k3996 in k3968 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in ... */
static void C_ccall f_4264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cddr(((C_word*)t0)[2]);
/* csi.scm:724: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4254(t3,((C_word*)t0)[4],t2);}

/* a3130 in k3127 in report in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_3131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3131,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3135,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:481: gc */
t3=C_fast_retrieve(lf[155]);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3133 in a3130 in k3127 in report in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_3135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3135,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3138,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:482: ##sys#symbol-table-info */
((C_proc2)C_fast_retrieve_symbol_proc(lf[154]))(2,*((C_word*)lf[154]+1),t2);}

/* k3136 in k3133 in a3130 in k3127 in report in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_3138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3138,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3141,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csi.scm:483: memory-statistics */
t4=C_fast_retrieve(lf[153]);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* loop in k2107 in k2095 in lookup-script-file in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_2071(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2071,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2084,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=C_subchar(((C_word*)t0)[4],t2);
/* csi.scm:205: proc */
t5=((C_word*)t0)[5];
((C_proc3)C_fast_retrieve_proc(t5))(3,t5,t3,t4);}}

/* k3159 in k3156 in k3139 in k3136 in k3133 in a3130 in k3127 in report in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 in ... */
static void C_ccall f_3161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3161,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3162,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_i_check_list_2(t1,lf[94]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3213,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3328,a[2]=t8,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_3328(t10,t6,t1);}

/* g437 in k3159 in k3156 in k3139 in k3136 in k3133 in a3130 in k3127 in report in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in ... */
static void C_fcall f_3162(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3162,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3166,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm:490: printf */
t4=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[132],t2);}

/* a2947 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2948,2,t0,t1);}
/* csi.scm:422: eval */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[3]);}

/* k4644 in k4628 in justify in hexdump in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_4646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#string-append */
((C_proc4)C_fast_retrieve_symbol_proc(lf[34]))(4,*((C_word*)lf[34]+1),((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* k4243 in g618 in k4238 in k4110 in k3996 in k3968 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in ... */
static void C_ccall f_4245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4245,2,t0,t1);}
t2=C_slot(((C_word*)t0)[2],C_fix(2));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4254,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_4254(t6,((C_word*)t0)[5],t2);}

/* k3164 in g437 in k3159 in k3156 in k3139 in k3136 in k3133 in a3130 in k3127 in report in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in ... */
static void C_ccall f_3166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3166,2,t0,t1);}
t2=C_i_string_length(((C_word*)t0)[2]);
t3=C_a_i_minus(&a,2,C_fix(16),t2);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3179,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_less_or_equalp(((C_word*)t5)[1],C_fix(0)))){
t9=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t10=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t9);
t11=C_a_i_plus(&a,2,((C_word*)t5)[1],C_fix(18));
t12=C_set_block_item(t5,0,t11);
t13=t8;
f_3179(t13,t12);}
else{
t9=t8;
f_3179(t9,C_SCHEME_UNDEFINED);}}

/* g618 in k4238 in k4110 in k3996 in k3968 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in ... */
static void C_fcall f_4241(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4241,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4245,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm:715: fprintf */
t4=*((C_word*)lf[162]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],lf[237],t2);}

/* k2047 in addext in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2049,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2052,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[2];
/* ##sys#string-append */
((C_proc4)C_fast_retrieve_symbol_proc(lf[34]))(4,*((C_word*)lf[34]+1),t2,t3,lf[35]);}}

/* k4238 in k4110 in k3996 in k3968 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in ... */
static void C_ccall f_4240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4241,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_slot(((C_word*)t0)[2],C_fix(1));
t4=C_i_check_list_2(t3,lf[94]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4309,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_4309(t8,((C_word*)t0)[4],t3);}

/* addext in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_2042(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2042,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2049,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:197: file-exists? */
t4=C_fast_retrieve(lf[33]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k3149 in shorten in k3139 in k3136 in k3133 in a3130 in k3127 in report in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 in ... */
static void C_ccall f_3151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3151,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_divide(&a,2,t1,C_fix(100)));}

/* k4628 in justify in hexdump in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_4630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4630,2,t0,t1);}
t2=t1;
t3=C_block_size(t2);
if(C_truep(C_fixnum_lessp(t3,((C_word*)t0)[2]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4646,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=C_fixnum_difference(((C_word*)t0)[2],t3);
/* csi.scm:772: make-string */
t6=*((C_word*)lf[131]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[4]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k3156 in k3139 in k3136 in k3133 in a3130 in k3127 in report in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_3158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3158,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3161,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_fast_retrieve(lf[150]);
t8=C_fast_retrieve(lf[4]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3353,a[2]=((C_word*)t0)[8],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3355,a[2]=t6,a[3]=t11,a[4]=t4,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_3355(t13,t9,C_fast_retrieve(lf[4]));}

/* k4275 in loop in k4243 in g618 in k4238 in k4110 in k3996 in k3968 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in ... */
static void C_ccall f_4277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:723: newline */
t2=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2056 in k2050 in k2047 in addext in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[3]:C_SCHEME_FALSE));}

/* k2451 in k2448 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[48]+1));}

/* k2050 in k2047 in addext in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2052,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2058,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:200: file-exists? */
t4=C_fast_retrieve(lf[33]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2448 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2453,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2460,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2464,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:321: expand */
t5=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t1);}

/* k3186 in k3177 in k3164 in g437 in k3159 in k3156 in k3139 in k3136 in k3133 in a3130 in k3127 in report in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in ... */
static void C_ccall f_3188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[2],0,C_fix(0));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##csi#hexdump in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_4623(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4623,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4626,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4656,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t4,a[6]=t2,a[7]=t6,tmp=(C_word)a,a+=8,tmp));
t10=((C_word*)t8)[1];
f_4656(t10,t1,C_fix(0));}

/* justify in hexdump in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_4626(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4626,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4630,a[2]=t3,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* csi.scm:769: number->string */
C_number_to_string(4,0,t6,t2,t4);}

/* k2462 in k2448 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:321: ##sys#strip-syntax */
((C_proc3)C_fast_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),((C_word*)t0)[2],t1);}

/* k2458 in k2448 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:321: pretty-print */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* map-loop1304 in k6273 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in ... */
static void C_fcall f_6328(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6328,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6357,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:1059: g1310 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6320 in map-loop1330 in k6283 in k6279 in k6273 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in ... */
static void C_ccall f_6322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6322,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6293(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6293(t6,((C_word*)t0)[5],t5);}}

/* k3177 in k3164 in g437 in k3159 in k3156 in k3139 in k3136 in k3133 in a3130 in k3127 in report in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in ... */
static void C_fcall f_3179(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3179,NULL,2,t0,t1);}
if(C_truep(C_i_greater_or_equalp(((C_word*)((C_word*)t0)[2])[1],C_fix(3)))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3188,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:498: display */
t3=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[130]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3196,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:501: make-string */
t3=*((C_word*)lf[131]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],C_make_character(32));}}

/* loop in k4243 in g618 in k4238 in k4110 in k3996 in k3968 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in ... */
static void C_fcall f_4254(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(13);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4254,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4264,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_i_caar(t2);
t5=C_eqp(((C_word*)t0)[3],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4277,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4282,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:719: ##sys#with-print-length-limit */
((C_proc4)C_fast_retrieve_symbol_proc(lf[55]))(4,*((C_word*)lf[55]+1),t6,C_fix(100),t7);}
else{
t6=C_i_cddr(t2);
/* csi.scm:724: loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* k3773 in k3761 in k3758 in k3755 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 in ... */
static void C_ccall f_3775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3775,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3780,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3780(t5,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* loop in k5498 in k5484 in loop in canonicalize-args in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static C_word C_fcall f_5608(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_overflow_check;
loop:
t2=C_i_nullp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=C_i_car(t1);
if(C_truep((C_truep(C_eqp(t3,C_make_character(107)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(115)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(118)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(104)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(68)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(101)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(105)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(82)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(98)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(110)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(113)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(119)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(45)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(73)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(112)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(80)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))))))))))))){
t4=t1;
t5=C_u_i_cdr(t4);
t7=t5;
t1=t7;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* k2507 in k2504 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:335: dump */
t2=C_fast_retrieve(lf[82]);
f_4475(3,t2,((C_word*)t0)[2],t1);}

/* k2504 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2506,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2509,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:334: eval */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k1899 in k1896 in print-usage in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_1901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:112: display */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[11]);}

/* k1906 in k1896 in print-usage in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_1908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:107: display */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2489 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2491,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2494,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:330: eval */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k2492 in k2489 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:331: describe */
t2=C_fast_retrieve(lf[80]);
f_3468(3,t2,((C_word*)t0)[2],t1);}

/* k3526 in loop2 in k3507 in loop1 in k3479 in k3601 in descseq in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in ... */
static void C_ccall f_3528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3528,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3531,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_greaterp(((C_word*)t0)[3],C_fix(1)))){
t3=C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
t4=C_eqp(((C_word*)t0)[3],C_fix(2));
if(C_truep(t4)){
/* csi.scm:597: fprintf */
t5=*((C_word*)lf[162]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t2,((C_word*)t0)[6],lf[164],t3,lf[165]);}
else{
/* csi.scm:597: fprintf */
t5=*((C_word*)lf[162]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t2,((C_word*)t0)[6],lf[164],t3,lf[166]);}}
else{
/* csi.scm:600: newline */
t3=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}}

/* a2674 in k2668 in a2665 in k2659 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2675,2,t0,t1);}
/* csi.scm:354: eval */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[3]);}

/* k2668 in a2665 in k2659 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2670,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2681,tmp=(C_word)a,a+=2,tmp);
/* csi.scm:353: ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[4],t2,t3);}

/* ##csi#run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_5634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5638,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6659,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:983: get-environment-variable */
t4=C_fast_retrieve(lf[43]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[372]);}

/* k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_5638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5638,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5641,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6655,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:984: command-line-arguments */
t5=C_fast_retrieve(lf[305]);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* ##csi#history-ref in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2299(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2299,3,t0,t1,t2);}
t3=C_i_inexact_to_exact(t2);
t4=C_fixnum_greaterp(t3,C_fix(0));
t5=(C_truep(t4)?C_fixnum_less_or_equal_p(t3,C_fast_retrieve(lf[25])):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_i_vector_ref(C_fast_retrieve(lf[45]),t3));}
else{
/* csi.scm:259: ##sys#error */
t6=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,lf[59],t2);}}

/* a6000 in doloop1370 in k5874 in k5871 in k5868 in k5865 in k5862 in k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in ... */
static void C_ccall f_6001(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_6001r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6001r(t0,t1,t2);}}

static void C_ccall f_6001r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_apply(5,0,t1,*((C_word*)lf[94]+1),*((C_word*)lf[17]+1),t2);}

/* loop2 in k3507 in loop1 in k3479 in k3601 in descseq in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 in ... */
static void C_fcall f_3518(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3518,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[2]))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3528,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3560,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:592: ##sys#with-print-length-limit */
((C_proc4)C_fast_retrieve_symbol_proc(lf[55]))(4,*((C_word*)lf[55]+1),t4,C_fix(1000),t5);}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3588,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* csi.scm:602: pref */
t5=((C_word*)t0)[8];
((C_proc4)C_fast_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[9],t3);}}

/* k2683 in a2680 in k2668 in a2665 in k2659 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* a2680 in k2668 in a2665 in k2659 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2681(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_2681r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2681r(t0,t1,t2);}}

static void C_ccall f_2681r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2685,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2692,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:353: ##sys#stop-timer */
t5=*((C_word*)lf[97]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k6032 in doloop1370 in k5874 in k5871 in k5868 in k5865 in k5862 in k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in ... */
static void C_ccall f_6034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6034,2,t0,t1);}
if(C_truep(C_i_equalp(lf[303],((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6045,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6055,tmp=(C_word)a,a+=2,tmp);
/* csi.scm:1132: call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],t2,t3);}
else{
t2=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=((C_word*)((C_word*)t0)[5])[1];
f_5881(t3,((C_word*)t0)[6],t2);}}

/* k2477 in k2474 in k2471 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[48]+1));}

/* k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_5641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5641,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5644,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:986: member* */
f_5403(t4,lf[364],((C_word*)t3)[1]);}

/* k2474 in k2471 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2476,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2479,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:326: pretty-print */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_5644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5644,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5647,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:987: member* */
f_5403(t3,lf[363],((C_word*)((C_word*)t0)[2])[1]);}

/* k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_5647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5647,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5650,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6550,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_i_cdr(t2);
t6=C_i_pairp(t5);
t7=C_i_not(t6);
if(C_truep(t7)){
if(C_truep(t7)){
/* csi.scm:992: ##sys#error */
t8=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t4,lf[361]);}
else{
t8=t4;
f_6550(2,t8,C_SCHEME_UNDEFINED);}}
else{
t8=C_i_cadr(t2);
t9=C_i_string_length(t8);
t10=C_eqp(t9,C_fix(0));
if(C_truep(t10)){
if(C_truep(t10)){
/* csi.scm:992: ##sys#error */
t11=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t4,lf[361]);}
else{
t11=t4;
f_6550(2,t11,C_SCHEME_UNDEFINED);}}
else{
t11=C_u_i_cdr(t2);
t12=C_u_i_car(t11);
t13=C_i_string_ref(t12,C_fix(0));
if(C_truep(C_i_char_equalp(C_make_character(45),t13))){
/* csi.scm:992: ##sys#error */
t14=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t14+1)))(3,t14,t4,lf[361]);}
else{
t14=t4;
f_6550(2,t14,C_SCHEME_UNDEFINED);}}}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6638,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6651,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1003: canonicalize-args */
f_5458(t5,((C_word*)t0)[5]);}}

/* k2471 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2476,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:325: eval */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k2650 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:349: string-split */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* find in loop in member* in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_5421(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5421,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=C_i_cdr(((C_word*)t0)[2]);
/* csi.scm:935: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5409(t4,t1,t3);}
else{
t3=C_i_car(t2);
t4=C_i_car(((C_word*)t0)[2]);
if(C_truep(C_i_equalp(t3,t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[2]);}
else{
t5=t2;
t6=C_u_i_cdr(t5);
/* csi.scm:937: find */
t9=t1;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}}

/* k6157 in k5868 in k5865 in k5862 in k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in ... */
static void C_ccall f_6159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6159,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_truep(((C_word*)t0)[2])?((C_word*)t0)[2]:((C_word*)t0)[3]));
if(C_truep(t2)){
t3=((C_word*)t0)[4];
f_5873(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5721,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1023: get-environment-variable */
t5=C_fast_retrieve(lf[43]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[315]);}}

/* k3529 in k3526 in loop2 in k3507 in loop1 in k3479 in k3601 in descseq in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in ... */
static void C_ccall f_3531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[2],((C_word*)t0)[3]);
/* csi.scm:601: loop1 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3486(t3,((C_word*)t0)[5],t2);}

/* a2665 in k2659 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2670,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm:353: ##sys#start-timer */
t3=*((C_word*)lf[98]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2659 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2661,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2666,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2694,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:353: ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[4],t3,t4);}

/* k4129 in k4110 in k3996 in k3968 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in ... */
static void C_ccall f_4131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:695: fprintf */
t2=*((C_word*)lf[162]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[227],t1);}

/* k6014 in doloop1370 in k5874 in k5871 in k5868 in k5865 in k5862 in k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in ... */
static void C_ccall f_6016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=((C_word*)((C_word*)t0)[2])[1];
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_u_i_cdr(t2));
t4=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t5=((C_word*)((C_word*)t0)[3])[1];
f_5881(t5,((C_word*)t0)[4],t4);}

/* k4003 in k3996 in k3968 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 in ... */
static void C_ccall f_4005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_slot(((C_word*)t0)[2],C_fix(2));
switch(t3){
case C_fix(0):
/* csi.scm:675: fprintf */
t4=*((C_word*)lf[162]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,((C_word*)t0)[3],((C_word*)t0)[4],lf[212],t1,t2,lf[213]);
case C_fix(1):
/* csi.scm:675: fprintf */
t4=*((C_word*)lf[162]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,((C_word*)t0)[3],((C_word*)t0)[4],lf[212],t1,t2,lf[214]);
case C_fix(2):
/* csi.scm:675: fprintf */
t4=*((C_word*)lf[162]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,((C_word*)t0)[3],((C_word*)t0)[4],lf[212],t1,t2,lf[215]);
case C_fix(3):
/* csi.scm:675: fprintf */
t4=*((C_word*)lf[162]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,((C_word*)t0)[3],((C_word*)t0)[4],lf[212],t1,t2,lf[216]);
case C_fix(4):
/* csi.scm:675: fprintf */
t4=*((C_word*)lf[162]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,((C_word*)t0)[3],((C_word*)t0)[4],lf[212],t1,t2,lf[217]);
case C_fix(5):
/* csi.scm:675: fprintf */
t4=*((C_word*)lf[162]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,((C_word*)t0)[3],((C_word*)t0)[4],lf[212],t1,t2,lf[218]);
case C_fix(6):
/* csi.scm:675: fprintf */
t4=*((C_word*)lf[162]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,((C_word*)t0)[3],((C_word*)t0)[4],lf[212],t1,t2,lf[219]);
case C_fix(7):
/* csi.scm:675: fprintf */
t4=*((C_word*)lf[162]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,((C_word*)t0)[3],((C_word*)t0)[4],lf[212],t1,t2,lf[220]);
case C_fix(8):
/* csi.scm:675: fprintf */
t4=*((C_word*)lf[162]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,((C_word*)t0)[3],((C_word*)t0)[4],lf[212],t1,t2,lf[221]);
case C_fix(9):
/* csi.scm:675: fprintf */
t4=*((C_word*)lf[162]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,((C_word*)t0)[3],((C_word*)t0)[4],lf[212],t1,t2,lf[222]);
default:
t4=C_SCHEME_UNDEFINED;
/* csi.scm:675: fprintf */
t5=*((C_word*)lf[162]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,((C_word*)t0)[3],((C_word*)t0)[4],lf[212],t1,t2,t4);}}

/* k1934 in k1927 in k1924 in print-banner in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_1936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:154: print */
t2=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[18],t1,lf[19]);}

/* a6139 */
static void C_ccall f_6140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6140,2,t0,t1);}
t2=C_fast_retrieve(lf[71]);
/* csi.scm:1118: g1424 */
t3=C_fast_retrieve(lf[71]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_1938(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1938,4,t0,t1,t2,t3);}
t4=C_i_char_equalp(C_make_character(41),t2);
t5=(C_truep(t4)?t4:C_u_i_char_whitespacep(t2));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1955,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=C_fixnum_difference(C_fast_retrieve(lf[25]),C_fix(1));
/* csi.scm:165: history-ref */
t8=C_fast_retrieve(lf[26]);
f_2299(3,t8,t6,t7);}
else{
/* csi.scm:166: old-hook */
t6=((C_word*)t0)[2];
((C_proc4)C_fast_retrieve_proc(t6))(4,t6,t1,t2,t3);}}

/* a6044 in k6032 in doloop1370 in k5874 in k5871 in k5868 in k5865 in k5862 in k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in ... */
static void C_ccall f_6045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6045,2,t0,t1);}
t2=C_fast_retrieve(lf[304]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6053,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1132: command-line-arguments */
t4=C_fast_retrieve(lf[305]);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6175 in k6172 in k6169 in k5865 in k5862 in k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in ... */
static void C_ccall f_6177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6177,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6180,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1082: keyword-style */
t3=C_fast_retrieve(lf[144]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[319]);}

/* k6172 in k6169 in k5865 in k5862 in k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in ... */
static void C_ccall f_6174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6174,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6177,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1081: case-sensitive */
t3=C_fast_retrieve(lf[320]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_SCHEME_FALSE);}

/* k6169 in k5865 in k5862 in k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in ... */
static void C_ccall f_6171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6171,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6174,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_6174(2,t3,C_SCHEME_UNDEFINED);}
else{
/* csi.scm:1080: display */
t3=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[321]);}}
else{
t2=((C_word*)t0)[2];
f_5870(2,t2,C_SCHEME_UNDEFINED);}}

/* k3321 in k3259 in k3255 in k3251 in k3247 in k3239 in k3211 in k3159 in k3156 in k3139 in k3136 in k3133 in a3130 in k3127 in report in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in ... */
static void C_ccall f_3323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:526: symbol->string */
t2=*((C_word*)lf[143]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* for-each-loop436 in k3159 in k3156 in k3139 in k3136 in k3133 in a3130 in k3127 in report in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in ... */
static void C_fcall f_3328(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3328,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3338,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:486: g437 */
t5=((C_word*)t0)[3];
f_3162(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2606)){
C_save(t1);
C_rereclaim2(2606*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,409);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\006.csirc");
lf[2]=C_h_intern(&lf[2],27,"\003sysrepl-print-length-limit");
lf[3]=C_h_intern(&lf[3],4,"\000csi");
lf[4]=C_h_intern(&lf[4],12,"\003sysfeatures");
lf[5]=C_h_intern(&lf[5],19,"\003sysnotices-enabled");
lf[6]=C_h_intern(&lf[6],14,"editor-command");
lf[9]=C_h_intern(&lf[9],15,"\003csiprint-usage");
lf[10]=C_h_intern(&lf[10],7,"display");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\004V    -b  -batch                    terminate after command-line processing\012 "
"   -w  -no-warnings              disable all warnings\012    -K  -keyword-style STY"
"LE      enable alternative keyword-syntax\012                                   (pr"
"efix, suffix or none)\012        -no-parentheses-synonyms  disables list delimiter "
"synonyms\012        -no-symbol-escape         disables support for escaped symbols\012"
"        -r5rs-syntax              disables the Chicken extensions to\012           "
"                        R5RS syntax\012    -s  -script PATHNAME          use interp"
"reter for shell scripts\012        -ss PATHNAME              shell script with `mai"
"n\047 procedure\012        -sx PATHNAME              same as `-s\047, but print each expr"
"ession\012                                   as it is evaluated\012        -setup-mode"
"               prefer the current directory when locating extensions\012    -R  -re"
"quire-extension NAME   require extension and import before\012                     "
"              executing code\012    -I  -include-path PATHNAME    add PATHNAME to i"
"nclude path\012    --                            ignore all following options\012");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\003 \047\012");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\000D    -n  -no-init                  do not load initialization file ` ");
lf[14]=C_h_intern(&lf[14],19,"\003sysprint-to-string");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\003\052usage: csi [FILENAME | OPTION ...]\012\012  `csi\047 is the CHICKEN interpreter.\012  \012"
"  FILENAME is a Scheme source file name with optional extension. OPTION may be\012 "
" one of the following:\012\012    -h  -help  --help             display this text and "
"exit\012        -version                  display version and exit\012        -release"
"                  print release number and exit\012    -i  -case-insensitive       "
"  enable case-insensitive reading\012    -e  -eval EXPRESSION          evaluate giv"
"en expression\012    -p  -print EXPRESSION         evaluate and print result(s)\012   "
" -P  -pretty-print EXPRESSION  evaluate and print result(s) prettily\012    -D  -fe"
"ature SYMBOL           register feature identifier\012        -no-feature SYMBOL   "
"     disable built-in feature identifier\012    -q  -quiet                    do no"
"t print banner\012");
lf[16]=C_h_intern(&lf[16],16,"\003csiprint-banner");
lf[17]=C_h_intern(&lf[17],5,"print");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000C(c) 2008-2014, The Chicken Team\012(c) 2000-2007, Felix L. Winkelmann\012");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[20]=C_h_intern(&lf[20],15,"chicken-version");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\007CHICKEN");
lf[22]=C_h_intern(&lf[22],7,"newline");
lf[23]=C_h_intern(&lf[23],18,"\003sysuser-read-hook");
lf[24]=C_h_intern(&lf[24],5,"quote");
lf[25]=C_h_intern(&lf[25],17,"\003csihistory-count");
lf[26]=C_h_intern(&lf[26],15,"\003csihistory-ref");
lf[27]=C_h_intern(&lf[27],21,"\003syssharp-number-hook");
lf[29]=C_h_intern(&lf[29],20,"\003syswindows-platform");
lf[30]=C_h_intern(&lf[30],18,"\003csichop-separator");
lf[31]=C_h_intern(&lf[31],9,"substring");
lf[32]=C_h_intern(&lf[32],1,"@");
lf[33]=C_h_intern(&lf[33],12,"file-exists\077");
lf[34]=C_h_intern(&lf[34],17,"\003sysstring-append");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\004.bat");
lf[36]=C_h_intern(&lf[36],22,"\003csilookup-script-file");
lf[37]=C_h_intern(&lf[37],13,"string-append");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[39]=C_h_intern(&lf[39],25,"\003syspeek-nonnull-c-string");
lf[40]=C_h_intern(&lf[40],12,"string-split");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[43]=C_h_intern(&lf[43],24,"get-environment-variable");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\004PATH");
lf[45]=C_h_intern(&lf[45],16,"\003csihistory-list");
lf[46]=C_h_intern(&lf[46],13,"vector-resize");
lf[47]=C_h_intern(&lf[47],15,"\003csihistory-add");
lf[48]=C_h_intern(&lf[48],19,"\003sysundefined-value");
lf[49]=C_h_intern(&lf[49],17,"\003csihistory-clear");
lf[50]=C_h_intern(&lf[50],12,"vector-fill!");
lf[51]=C_h_intern(&lf[51],16,"\003csihistory-show");
lf[52]=C_h_intern(&lf[52],19,"\003sysstandard-output");
lf[53]=C_h_intern(&lf[53],6,"printf");
lf[54]=C_h_intern(&lf[54],9,"\003sysprint");
lf[55]=C_h_intern(&lf[55],27,"\003syswith-print-length-limit");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[57]=C_h_intern(&lf[57],16,"\003syswrite-char-0");
lf[58]=C_h_intern(&lf[58],9,"\003syserror");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000 history entry index out of range");
lf[60]=C_h_intern(&lf[60],14,"\003csitty-input\077");
lf[61]=C_h_intern(&lf[61],13,"\003systty-port\077");
lf[62]=C_h_intern(&lf[62],18,"\003sysstandard-input");
lf[63]=C_h_intern(&lf[63],18,"\003sysbreak-on-error");
lf[64]=C_h_intern(&lf[64],20,"\003sysread-prompt-hook");
lf[66]=C_h_intern(&lf[66],16,"toplevel-command");
lf[67]=C_h_intern(&lf[67],4,"eval");
lf[68]=C_h_intern(&lf[68],12,"load-noisily");
lf[69]=C_h_intern(&lf[69],9,"read-line");
lf[70]=C_h_intern(&lf[70],6,"expand");
lf[71]=C_h_intern(&lf[71],12,"pretty-print");
lf[72]=C_h_intern(&lf[72],6,"values");
lf[74]=C_h_intern(&lf[74],4,"exit");
lf[75]=C_h_intern(&lf[75],1,"x");
lf[76]=C_h_intern(&lf[76],16,"\003sysstrip-syntax");
lf[77]=C_h_intern(&lf[77],4,"read");
lf[78]=C_h_intern(&lf[78],1,"p");
lf[79]=C_h_intern(&lf[79],1,"d");
lf[80]=C_h_intern(&lf[80],12,"\003csidescribe");
lf[81]=C_h_intern(&lf[81],2,"du");
lf[82]=C_h_intern(&lf[82],8,"\003csidump");
lf[83]=C_h_intern(&lf[83],3,"dur");
lf[84]=C_h_intern(&lf[84],1,"r");
lf[85]=C_h_intern(&lf[85],10,"\003csireport");
lf[86]=C_h_intern(&lf[86],1,"q");
lf[87]=C_h_intern(&lf[87],13,"\003sysquit-hook");
lf[88]=C_h_intern(&lf[88],1,"l");
lf[89]=C_h_intern(&lf[89],4,"load");
lf[90]=C_h_intern(&lf[90],2,"ln");
lf[91]=C_h_intern(&lf[91],6,"print\052");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\004==> ");
lf[93]=C_h_intern(&lf[93],8,"\000printer");
lf[94]=C_h_intern(&lf[94],8,"for-each");
lf[95]=C_h_intern(&lf[95],1,"t");
lf[96]=C_h_intern(&lf[96],17,"\003sysdisplay-times");
lf[97]=C_h_intern(&lf[97],14,"\003sysstop-timer");
lf[98]=C_h_intern(&lf[98],15,"\003sysstart-timer");
lf[99]=C_h_intern(&lf[99],3,"exn");
lf[100]=C_h_intern(&lf[100],18,"\003syslast-exception");
lf[101]=C_h_intern(&lf[101],1,"e");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000,editor returned with non-zero exit status ~a");
lf[103]=C_h_intern(&lf[103],6,"system");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[105]=C_h_intern(&lf[105],2,"ch");
lf[106]=C_h_intern(&lf[106],1,"h");
lf[107]=C_h_intern(&lf[107],1,"c");
lf[109]=C_h_intern(&lf[109],1,"f");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\016no such frame\012");
lf[111]=C_h_intern(&lf[111],26,"\003sysrepl-recent-call-chain");
lf[112]=C_h_intern(&lf[112],1,"g");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\027no environment in frame");
lf[114]=C_h_intern(&lf[114],9,"frameinfo");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\012; getting ");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\022no such variable: ");
lf[117]=C_h_intern(&lf[117],7,"call/cc");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000#string or symbol required for `,g\047\012");
lf[119]=C_h_intern(&lf[119],1,"s");
lf[120]=C_h_intern(&lf[120],1,"\077");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\002 ,");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\003\266Toplevel commands:\012\012 ,\077                Show this text\012 ,p EXP            Pr"
"etty print evaluated expression EXP\012 ,d EXP            Describe result of evalua"
"ted expression EXP\012 ,du EXP           Dump data of expression EXP\012 ,dur EXP N   "
"     Dump range\012 ,q                Quit interpreter\012 ,l FILENAME ...   Load one "
"or more files\012 ,ln FILENAME ...  Load one or more files and print result of each"
" top-level expression\012 ,r                Show system information\012 ,h            "
"    Show history of expression results\012 ,ch               Clear history of expre"
"ssion results\012 ,e FILENAME       Run external editor\012 ,s TEXT ...       Execute "
"shell-command\012 ,exn              Describe last exception\012 ,c                Show"
" call-chain of most recent error\012 ,f N              Select frame N\012 ,g NAME     "
"      Get variable NAME from current frame\012 ,t EXP            Evaluate form and "
"print elapsed time\012 ,x EXP            Pretty print expanded expression EXP\012");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\0005undefined toplevel command ~s - enter `,\077\047 for help~%");
lf[124]=C_h_intern(&lf[124],7,"unquote");
lf[125]=C_h_intern(&lf[125],4,"chop");
lf[126]=C_h_intern(&lf[126],4,"sort");
lf[127]=C_h_intern(&lf[127],19,"with-output-to-port");
lf[128]=C_h_intern(&lf[128],4,"argv");
lf[129]=C_h_intern(&lf[129],8,"truncate");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[131]=C_h_intern(&lf[131],11,"make-string");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\004  ~a");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\025symbol gc is enabled\012");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\027interrupts are enabled\012");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\010(64-bit)");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\010 (fixed)");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\010downward");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\006upward");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\002\262~%~%~\012                   Machine type:    \011~A ~A~%~\012                   Soft"
"ware type:   \011~A~%~\012                   Software version:\011~A~%~\012                 "
"  Build platform:  \011~A~%~\012                   Installation prefix:\011~A~%~\012        "
"           Extension path:  \011~A~%~\012                   Include path:    \011~A~%~\012  "
"                 Keyword style:   \011~A~%~\012                   Symbol-table load:\011~"
"S~%  ~\012                     Avg bucket length:\011~S~%  ~\012                     Tota"
"l symbol count:\011~S~%~\012                   Memory:\011heap size is ~S bytes~A with ~S"
" bytes currently in use~%~  \012                     nursery size is ~S bytes, stac"
"k grows ~A~%~\012                   Command line:    \011~S~%");
lf[142]=C_h_intern(&lf[142],21,"\003sysinclude-pathnames");
lf[143]=C_h_intern(&lf[143],14,"symbol->string");
lf[144]=C_h_intern(&lf[144],13,"keyword-style");
lf[145]=C_h_intern(&lf[145],15,"repository-path");
lf[146]=C_h_intern(&lf[146],14,"build-platform");
lf[147]=C_h_intern(&lf[147],16,"software-version");
lf[148]=C_h_intern(&lf[148],13,"software-type");
lf[149]=C_h_intern(&lf[149],12,"machine-type");
lf[150]=C_h_intern(&lf[150],15,"keyword->string");
lf[151]=C_h_intern(&lf[151],8,"string<\077");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\015Features:~%~%");
lf[153]=C_h_intern(&lf[153],17,"memory-statistics");
lf[154]=C_h_intern(&lf[154],21,"\003syssymbol-table-info");
lf[155]=C_h_intern(&lf[155],2,"gc");
lf[157]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376B\000\000\030vector of unsigned bytes\376\003\000\000\002\376\001\000\000\017u8vector-leng"
"th\376\003\000\000\002\376\001\000\000\014u8vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010s8vector\376\003\000\000\002\376B\000\000\026vector of signed byt"
"es\376\003\000\000\002\376\001\000\000\017s8vector-length\376\003\000\000\002\376\001\000\000\014s8vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000"
"\002\376B\000\000\037vector of unsigned 16-bit words\376\003\000\000\002\376\001\000\000\020u16vector-length\376\003\000\000\002\376\001\000\000\015u16vect"
"or-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376B\000\000\035vector of signed 16-bit words\376\003\000\000\002\376\001\000"
"\000\020s16vector-length\376\003\000\000\002\376\001\000\000\015s16vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011u32vector\376\003\000\000\002\376B\000\000\037ve"
"ctor of unsigned 32-bit words\376\003\000\000\002\376\001\000\000\020u32vector-length\376\003\000\000\002\376\001\000\000\015u32vector-ref\376\377"
"\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376B\000\000\035vector of signed 32-bit words\376\003\000\000\002\376\001\000\000\020s32vec"
"tor-length\376\003\000\000\002\376\001\000\000\015s32vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376B\000\000\027vector of "
"32-bit floats\376\003\000\000\002\376\001\000\000\020f32vector-length\376\003\000\000\002\376\001\000\000\015f32vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011"
"f64vector\376\003\000\000\002\376B\000\000\027vector of 64-bit floats\376\003\000\000\002\376\001\000\000\020f64vector-length\376\003\000\000\002\376\001\000\000\015f6"
"4vector-ref\376\377\016\376\377\016");
lf[159]=C_h_intern(&lf[159],6,"length");
lf[160]=C_h_intern(&lf[160],8,"list-ref");
lf[161]=C_h_intern(&lf[161],10,"string-ref");
lf[162]=C_h_intern(&lf[162],7,"fprintf");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000 ~% (~A elements not displayed)~%");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000.\011(followed by ~A identical instance~a)~% ...~%");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\001s");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\007 ~S: ~S");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\021~A of length ~S~%");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000$character ~S, code: ~S, #x~X, #o~O~%");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\016boolean true~%");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\017boolean false~%");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\014empty list~%");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\024end-of-file object~%");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\024unspecified object~%");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\016, character ~S");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000(exact integer ~S~%  #x~X~%  #o~O~%  #b~B");
lf[177]=C_h_intern(&lf[177],28,"\003sysarbitrary-unbound-symbol");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\017unbound value~%");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\023inexact number ~S~%");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\013number ~S~%");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\006string");
lf[182]=C_h_intern(&lf[182],8,"\003syssize");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\006vector");
lf[184]=C_h_intern(&lf[184],8,"\003sysslot");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\035keyword symbol with name ~s~%");
lf[186]=C_h_intern(&lf[186],18,"\003syssymbol->string");
lf[187]=C_h_intern(&lf[187],5,"write");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\005  ~s\011");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\020  \012properties:\012\012");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\013uninterned ");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\012qualified ");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\031~a~asymbol with name ~S~%");
lf[195]=C_h_intern(&lf[195],28,"\003syssymbol->qualified-string");
lf[196]=C_h_intern(&lf[196],20,"\003sysinterned-symbol\077");
lf[197]=C_h_intern(&lf[197],21,"\003sysqualified-symbol\077");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\010unbound ");
lf[199]=C_h_intern(&lf[199],32,"\003syssymbol-has-toplevel-binding\077");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\005eol~%");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\012(circle)~%");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\006~S -> ");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\024circular structure: ");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\004list");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\036pair with car ~S~%and cdr ~S~%");
lf[206]=C_h_intern(&lf[206],7,"sprintf");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000 procedure with code pointer 0x~X");
lf[208]=C_h_intern(&lf[208],25,"\003syspeek-unsigned-integer");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\005input");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\006output");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\0005~A port of type ~A with name ~S and file pointer ~X~%");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000/locative~%  pointer ~X~%  index ~A~%  type ~A~%");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\004slot");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\004char");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\010u8vector");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\010s8vector");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\011u16vector");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\011s16vector");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\011u32vector");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\011s32vector");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\011f32vector");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\011f64vector");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\024machine pointer ~X~%");
lf[224]=C_h_intern(&lf[224],11,"\003csihexdump");
lf[225]=C_h_intern(&lf[225],8,"\003sysbyte");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\022blob of size ~S:~%");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\030lambda information: ~s~%");
lf[228]=C_h_intern(&lf[228],23,"\003syslambda-info->string");
lf[229]=C_h_intern(&lf[229],10,"hash-table");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\013 ~S\011-> ~S~%");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\025  hash function: ~a~%");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\001s");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000:hash-table with ~S element~a~%  comparison procedure: ~A~%");
lf[235]=C_h_intern(&lf[235],9,"condition");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\007\011~s: ~s");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\005 ~s~%");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\017condition: ~s~%");
lf[239]=C_h_intern(&lf[239],3,"map");
lf[240]=C_h_intern(&lf[240],6,"append");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\031structure of type `~S\047:~%");
lf[242]=C_h_intern(&lf[242],18,"\003syshash-table-ref");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\020unknown object~%");
lf[244]=C_h_intern(&lf[244],15,"\003sysbytevector\077");
lf[245]=C_h_intern(&lf[245],13,"\003syslocative\077");
lf[246]=C_h_intern(&lf[246],5,"port\077");
lf[247]=C_h_intern(&lf[247],8,"keyword\077");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\034statically allocated (0x~X) ");
lf[249]=C_h_intern(&lf[249],17,"\003sysblock-address");
lf[250]=C_h_intern(&lf[250],14,"set-describer!");
lf[251]=C_h_intern(&lf[251],19,"\003syshash-table-set!");
lf[252]=C_h_intern(&lf[252],3,"min");
lf[253]=C_h_intern(&lf[253],4,"dump");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot dump immediate object");
lf[255]=C_h_intern(&lf[255],13,"\003syspeek-byte");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot dump object");
lf[257]=C_h_intern(&lf[257],19,"\003syswrite-char/port");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000\004:\011  ");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\006  ---\012");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\002] ");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\003\011  ");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\002[]");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[266]=C_h_intern(&lf[266],23,"\003sysuser-interrupt-hook");
lf[267]=C_h_intern(&lf[267],17,"\003syssignal-vector");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\003-ss");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\007-script");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\003-sx");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\002--");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid option");
lf[276]=C_h_intern(&lf[276],16,"\003sysstring->list");
lf[277]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000\002\376B\000\000\003-sx\376\003\000\000\002\376B\000\000\007-script\376\003\000\000\002\376B\000\000\010-version\376\003\000\000\002\376B\000\000\005-help\376\003\000\000"
"\002\376B\000\000\006--help\376\003\000\000\002\376B\000\000\010-feature\376\003\000\000\002\376B\000\000\013-no-feature\376\003\000\000\002\376B\000\000\005-eval\376\003\000\000\002\376B\000\000\021-cas"
"e-insensitive\376\003\000\000\002\376B\000\000\016-keyword-style\376\003\000\000\002\376B\000\000\030-no-parentheses-synonyms\376\003\000\000\002\376B\000\000"
"\021-no-symbol-escape\376\003\000\000\002\376B\000\000\014-r5rs-syntax\376\003\000\000\002\376B\000\000\013-setup-mode\376\003\000\000\002\376B\000\000\022-require-"
"extension\376\003\000\000\002\376B\000\000\006-batch\376\003\000\000\002\376B\000\000\006-quiet\376\003\000\000\002\376B\000\000\014-no-warnings\376\003\000\000\002\376B\000\000\010-no-ini"
"t\376\003\000\000\002\376B\000\000\015-include-path\376\003\000\000\002\376B\000\000\010-release\376\003\000\000\002\376B\000\000\006-print\376\003\000\000\002\376B\000\000\015-pretty-prin"
"t\376\003\000\000\002\376B\000\000\002--\376\377\016");
lf[278]=C_h_intern(&lf[278],7,"\003csirun");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\047missing argument to command-line option");
lf[280]=C_h_intern(&lf[280],8,"\003syslist");
lf[281]=C_h_intern(&lf[281],17,"open-input-string");
lf[282]=C_h_intern(&lf[282],17,"register-feature!");
lf[283]=C_h_intern(&lf[283],19,"unregister-feature!");
lf[284]=C_h_intern(&lf[284],4,"repl");
lf[285]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002--\376\003\000\000\002\376B\000\000\002-b\376\003\000\000\002\376B\000\000\006-batch\376\003\000\000\002\376B\000\000\002-q\376\003\000\000\002\376B\000\000\006-quiet\376\003\000\000\002\376B\000\000\002-n"
"\376\003\000\000\002\376B\000\000\010-no-init\376\003\000\000\002\376B\000\000\002-w\376\003\000\000\002\376B\000\000\014-no-warnings\376\003\000\000\002\376B\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-"
"insensitive\376\003\000\000\002\376B\000\000\030-no-parentheses-synonyms\376\003\000\000\002\376B\000\000\021-no-symbol-escape\376\003\000\000\002\376B\000"
"\000\014-r5rs-syntax\376\003\000\000\002\376B\000\000\013-setup-mode\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000\002\376B\000\000\003-sx\376\003\000\000\002\376B\000\000\002-s\376\003\000\000\002\376B"
"\000\000\007-script\376\377\016");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\002-D");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\002-I");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\002-K");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\016-keyword-style");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\013-no-feature");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\002-R");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\022-require-extension");
lf[295]=C_h_intern(&lf[295],22,"\004corerequire-extension");
lf[296]=C_h_intern(&lf[296],14,"string->symbol");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\002-e");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\005-eval");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\002-p");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\006-print");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\002-P");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\015-pretty-print");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\003-ss");
lf[304]=C_h_intern(&lf[304],4,"main");
lf[305]=C_h_intern(&lf[305],22,"command-line-arguments");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\003-sx");
lf[307]=C_h_intern(&lf[307],18,"\003sysstandard-error");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\002; ");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\003\012; ");
lf[310]=C_h_intern(&lf[310],12,"flush-output");
lf[311]=C_h_intern(&lf[311],21,"with-output-to-string");
lf[312]=C_h_intern(&lf[312],8,"\003sysload");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\004HOME");
lf[316]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-n\376\003\000\000\002\376B\000\000\010-no-init\376\377\016");
lf[317]=C_h_intern(&lf[317],13,"symbol-escape");
lf[318]=C_h_intern(&lf[318],20,"parentheses-synonyms");
lf[319]=C_h_intern(&lf[319],5,"\000none");
lf[320]=C_h_intern(&lf[320],14,"case-sensitive");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000/Disabled the Chicken extensions to R5RS syntax\012");
lf[322]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014-r5rs-syntax\376\377\016");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000%Disabled support for escaped symbols\012");
lf[324]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\021-no-symbol-escape\376\377\016");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\052Disabled support for parentheses synonyms\012");
lf[326]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\030-no-parentheses-synonyms\376\377\016");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\006prefix");
lf[328]=C_h_intern(&lf[328],7,"\000prefix");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\006suffix");
lf[331]=C_h_intern(&lf[331],7,"\000suffix");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000+missing argument to `-keyword-style\047 option");
lf[333]=C_h_intern(&lf[333],10,"\003sysnodups");
lf[334]=C_h_intern(&lf[334],8,"string=\077");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\002-I");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\013-no-feature");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\002-D");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[340]=C_h_intern(&lf[340],16,"case-insensitive");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000-Identifiers and symbols are case insensitive\012");
lf[342]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-insensitive\376\377\016");
lf[343]=C_h_intern(&lf[343],12,"load-verbose");
lf[344]=C_h_intern(&lf[344],20,"\003syswarnings-enabled");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\026Warnings are disabled\012");
lf[346]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-w\376\003\000\000\002\376B\000\000\014-no-warnings\376\377\016");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\010-release");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\013-setup-mode");
lf[349]=C_h_intern(&lf[349],14,"\003syssetup-mode");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\010-version");
lf[351]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-h\376\003\000\000\002\376B\000\000\005-help\376\003\000\000\002\376B\000\000\006--help\376\377\016");
lf[352]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[353]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN_INCLUDE_PATH");
lf[355]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-q\376\003\000\000\002\376B\000\000\006-quiet\376\377\016");
lf[356]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-b\376\003\000\000\002\376B\000\000\006-batch\376\377\016");
lf[357]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-e\376\003\000\000\002\376B\000\000\002-p\376\003\000\000\002\376B\000\000\002-P\376\003\000\000\002\376B\000\000\005-eval\376\003\000\000\002\376B\000\000\006-print\376\003\000\000\002\376B\000\000\015-pr"
"etty-print\376\377\016");
lf[358]=C_h_intern(&lf[358],14,"chicken-script");
lf[359]=C_h_intern(&lf[359],6,"script");
lf[360]=C_h_intern(&lf[360],12,"program-name");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000\042missing or invalid script argument");
lf[362]=C_decode_literal(C_heaptop,"\376B\000\000\002--");
lf[363]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000\002\376B\000\000\003-sx\376\003\000\000\002\376B\000\000\002-s\376\003\000\000\002\376B\000\000\007-script\376\377\016");
lf[364]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-K\376\003\000\000\002\376B\000\000\016-keyword-style\376\377\016");
lf[365]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[366]=C_h_intern(&lf[366],17,"get-output-string");
lf[367]=C_h_intern(&lf[367],18,"open-output-string");
lf[368]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid option syntax");
lf[369]=C_h_intern(&lf[369],7,"reverse");
lf[370]=C_h_intern(&lf[370],22,"with-exception-handler");
lf[371]=C_h_intern(&lf[371],30,"call-with-current-continuation");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\013CSI_OPTIONS");
lf[373]=C_h_intern(&lf[373],25,"\003sysimplicit-exit-handler");
lf[374]=C_h_intern(&lf[374],28,"\003sysextend-macro-environment");
lf[375]=C_h_intern(&lf[375],10,"defhandler");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000\032C_establish_signal_handler");
lf[377]=C_h_intern(&lf[377],11,"\003syssetslot");
lf[378]=C_h_intern(&lf[378],11,"\004coreinline");
lf[379]=C_h_intern(&lf[379],5,"begin");
lf[380]=C_h_intern(&lf[380],25,"\003syssyntax-rules-mismatch");
lf[381]=C_h_intern(&lf[381],18,"\003syser-transformer");
lf[382]=C_h_intern(&lf[382],23,"\003syscurrent-environment");
lf[383]=C_h_intern(&lf[383],11,"make-vector");
lf[384]=C_h_intern(&lf[384],17,"\003syspeek-c-string");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[386]=C_decode_literal(C_heaptop,"\376B\000\000$; switching current module to `~a\047~%");
lf[387]=C_h_intern(&lf[387],17,"\003sysswitch-module");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000\027undefined module `~a\047~%");
lf[389]=C_h_intern(&lf[389],15,"\003sysfind-module");
lf[390]=C_h_intern(&lf[390],23,"\003sysresolve-module-name");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid module name `~a\047~%");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000(; resetting current module to toplevel~%");
lf[393]=C_h_intern(&lf[393],18,"\003sysstring->symbol");
lf[394]=C_h_intern(&lf[394],1,"m");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\0005,m MODULE         switch to module with name `MODULE\047");
lf[396]=C_decode_literal(C_heaptop,"\376B\000\000\010#;~A~A> ");
lf[397]=C_decode_literal(C_heaptop,"\376B\000\000\003~a:");
lf[398]=C_h_intern(&lf[398],15,"\003sysmodule-name");
lf[399]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[400]=C_h_intern(&lf[400],18,"\003syscurrent-module");
lf[401]=C_h_intern(&lf[401],11,"repl-prompt");
lf[402]=C_h_intern(&lf[402],15,"\003sysmake-string");
lf[403]=C_decode_literal(C_heaptop,"\376B\000\000\013emacsclient");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\002vi");
lf[405]=C_decode_literal(C_heaptop,"\376B\000\000\005EMACS");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\006VISUAL");
lf[407]=C_decode_literal(C_heaptop,"\376B\000\000\006EDITOR");
lf[408]=C_h_intern(&lf[408],14,"make-parameter");
C_register_lf2(lf,409,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1856,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2696 in a2693 in k2659 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k2690 in a2680 in k2668 in a2665 in k2659 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:353: ##sys#display-times */
((C_proc3)C_fast_retrieve_symbol_proc(lf[96]))(3,*((C_word*)lf[96]+1),((C_word*)t0)[2],t1);}

/* a2693 in k2659 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2694(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2694r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2694r(t0,t1,t2);}}

static void C_ccall f_2694r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2698,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm:355: history-add */
t4=C_fast_retrieve(lf[47]);
f_2200(3,t4,t3,t2);}

/* a6023 in doloop1370 in k5874 in k5871 in k5868 in k5865 in k5862 in k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in ... */
static void C_ccall f_6024(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_6024r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6024r(t0,t1,t2);}}

static void C_ccall f_6024r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_apply(5,0,t1,*((C_word*)lf[94]+1),C_fast_retrieve(lf[71]),t2);}

/* k6807 in k6798 in k6795 in a6792 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_6809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:438: printf */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[392]);}

/* doloop1370 in k5874 in k5871 in k5868 in k5865 in k5862 in k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in ... */
static void C_fcall f_5881(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word *a;
loop:
a=C_alloc(17);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5881,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
if(C_truep(C_i_nullp(((C_word*)t3)[1]))){
if(C_truep(((C_word*)t0)[2])){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5894,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5899,tmp=(C_word)a,a+=2,tmp);
/* csi.scm:1091: call/cc */
t6=*((C_word*)lf[117]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}
else{
t4=C_i_car(((C_word*)t3)[1]);
t5=C_i_member(t4,lf[285]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5918,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=C_i_cdr(((C_word*)t3)[1]);
t37=t1;
t38=t7;
t1=t37;
t2=t38;
goto loop;}
else{
if(C_truep((C_truep(C_i_equalp(t4,lf[286]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[287]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[288]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[289]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[290]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[291]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[292]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))))))){
t7=C_i_cdr(((C_word*)t3)[1]);
t8=C_set_block_item(t3,0,t7);
t9=C_i_cdr(((C_word*)t3)[1]);
t37=t1;
t38=t9;
t1=t37;
t2=t38;
goto loop;}
else{
t7=C_i_string_equal_p(lf[293],t4);
t8=(C_truep(t7)?t7:C_u_i_string_equal_p(lf[294],t4));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5947,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5961,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=C_i_cadr(((C_word*)t3)[1]);
/* csi.scm:1101: string->symbol */
t12=*((C_word*)lf[296]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}
else{
t9=C_u_i_string_equal_p(lf[297],t4);
t10=(C_truep(t9)?t9:C_u_i_string_equal_p(lf[298],t4));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5976,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t12=C_i_cadr(((C_word*)t3)[1]);
/* csi.scm:1104: evalstring */
f_5752(t11,t12,C_SCHEME_END_OF_LIST);}
else{
t11=C_u_i_string_equal_p(lf[299],t4);
t12=(C_truep(t11)?t11:C_u_i_string_equal_p(lf[300],t4));
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5993,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t14=C_i_cadr(((C_word*)t3)[1]);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6001,tmp=(C_word)a,a+=2,tmp);
/* csi.scm:1107: evalstring */
f_5752(t13,t14,C_a_i_list(&a,1,t15));}
else{
t13=C_u_i_string_equal_p(lf[301],t4);
t14=(C_truep(t13)?t13:C_u_i_string_equal_p(lf[302],t4));
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6016,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t16=C_i_cadr(((C_word*)t3)[1]);
t17=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6024,tmp=(C_word)a,a+=2,tmp);
/* csi.scm:1110: evalstring */
f_5752(t15,t16,C_a_i_list(&a,1,t17));}
else{
t15=(C_truep(((C_word*)t0)[5])?C_i_car(((C_word*)t0)[5]):C_SCHEME_FALSE);
t16=t15;
t17=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6034,a[2]=t16,a[3]=t6,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_equalp(lf[306],t16))){
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6085,tmp=(C_word)a,a+=2,tmp);
/* csi.scm:1114: ##sys#load */
((C_proc5)C_fast_retrieve_symbol_proc(lf[312]))(5,*((C_word*)lf[312]+1),t17,t4,t18,C_SCHEME_FALSE);}
else{
/* csi.scm:1114: ##sys#load */
((C_proc5)C_fast_retrieve_symbol_proc(lf[312]))(5,*((C_word*)lf[312]+1),t17,t4,C_SCHEME_FALSE,C_SCHEME_FALSE);}}}}}}}}}

/* a6054 in k6032 in doloop1370 in k5874 in k5871 in k5868 in k5865 in k5862 in k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in ... */
static void C_ccall f_6055(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_6055r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6055r(t0,t1,t2);}}

static void C_ccall f_6055r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
if(C_truep(C_i_pairp(t2))){
t3=t2;
t4=C_u_i_car(t3);
if(C_truep(C_fixnump(t4))){
t5=C_i_car(t2);
/* csi.scm:1134: exit */
t6=C_fast_retrieve(lf[74]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t5);}
else{
/* csi.scm:1134: exit */
t5=C_fast_retrieve(lf[74]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,C_fix(0));}}
else{
/* csi.scm:1134: exit */
t3=C_fast_retrieve(lf[74]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,C_fix(0));}}

/* k6798 in k6795 in a6792 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_6800(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6800,NULL,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[2])[1];
if(C_truep(t2)){
if(C_truep(C_i_symbolp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6824,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6845,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:441: ##sys#resolve-module-name */
((C_proc4)C_fast_retrieve_symbol_proc(lf[390]))(4,*((C_word*)lf[390]+1),t4,((C_word*)((C_word*)t0)[2])[1],C_SCHEME_FALSE);}
else{
/* csi.scm:440: printf */
t3=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],lf[391],((C_word*)((C_word*)t0)[2])[1]);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6809,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:437: ##sys#switch-module */
((C_proc3)C_fast_retrieve_symbol_proc(lf[387]))(3,*((C_word*)lf[387]+1),t3,C_SCHEME_FALSE);}}

/* k6051 in a6044 in k6032 in doloop1370 in k5874 in k5871 in k5868 in k5865 in k5862 in k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in ... */
static void C_ccall f_6053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:1132: g1441 */
t2=((C_word*)t0)[2];
((C_proc3)C_fast_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],t1);}

/* k6102 in k6099 in k6096 in k6093 in k6087 */
static void C_ccall f_6104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:1129: eval */
t2=C_fast_retrieve(lf[67]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* doloop1427 in k6096 in k6093 in k6087 */
static void C_fcall f_6109(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6109,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_i_string_ref(((C_word*)t0)[3],t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6122,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t6=C_fast_retrieve(lf[257]);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,*((C_word*)lf[307]+1));}}

/* k6099 in k6096 in k6093 in k6087 */
static void C_ccall f_6101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6101,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6104,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1128: newline */
t3=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[307]+1));}

/* k5892 in doloop1370 in k5874 in k5871 in k5868 in k5865 in k5862 in k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in ... */
static void C_ccall f_5894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:1095: ##sys#write-char-0 */
((C_proc4)C_fast_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[52]+1));}

/* k3336 in for-each-loop436 in k3159 in k3156 in k3139 in k3136 in k3133 in a3130 in k3127 in report in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in ... */
static void C_ccall f_3338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3328(t3,((C_word*)t0)[4],t2);}

/* a5898 in doloop1370 in k5874 in k5871 in k5868 in k5865 in k5862 in k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in ... */
static void C_ccall f_5899(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5899,3,t0,t1,t2);}
t3=C_mutate2((C_word*)lf[87]+1 /* (set! ##sys#quit-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5902,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
/* csi.scm:1094: repl */
t4=C_fast_retrieve(lf[284]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,C_retrieve2(lf[73],"csi-eval"));}

/* ##csi#print-banner in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_1922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1926,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:135: newline */
t3=*((C_word*)lf[22]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1924 in print-banner in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_1926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1926,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1929,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:153: print */
t3=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[21]);}

/* k1927 in k1924 in print-banner in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_1929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1929,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1936,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:154: chicken-version */
t3=C_fast_retrieve(lf[20]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_SCHEME_TRUE);}

/* k6123 in k6120 in doloop1427 in k6096 in k6093 in k6087 */
static void C_ccall f_6125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6109(t3,((C_word*)t0)[4],t2);}

/* k6120 in doloop1427 in k6096 in k6093 in k6087 */
static void C_ccall f_6122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6125,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_char_equalp(C_make_character(10),((C_word*)t0)[5]))){
/* csi.scm:1127: display */
t3=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[308],*((C_word*)lf[307]+1));}
else{
t3=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_6109(t4,((C_word*)t0)[4],t3);}}

/* k6843 in k6798 in k6795 in a6792 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_6845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:441: ##sys#find-module */
((C_proc4)C_fast_retrieve_symbol_proc(lf[389]))(4,*((C_word*)lf[389]+1),((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k2278 in k2275 in k2272 in k2269 in k2266 in doloop134 in history-show in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2255(t3,((C_word*)t0)[4],t2);}

/* k6874 in k6864 in a6857 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_6876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:267: sprintf */
t2=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[397],t1);}

/* k4973 in k4970 in k4967 in k4964 in k4961 in doloop847 in k4943 in g834 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4893 in k4890 in doloop799 in k4850 in show-frameinfo in k3464 in ... */
static void C_ccall f_4975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
t5=((C_word*)((C_word*)t0)[4])[1];
f_4950(t5,((C_word*)t0)[5],t2,t4);}

/* k4970 in k4967 in k4964 in k4961 in doloop847 in k4943 in g834 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4893 in k4890 in doloop799 in k4850 in show-frameinfo in k3464 in k3118 in ... */
static void C_ccall f_4972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4975,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:846: newline */
t3=*((C_word*)lf[22]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* a2288 in k2272 in k2269 in k2266 in doloop134 in history-show in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2289,2,t0,t1);}
t2=C_i_vector_ref(C_fast_retrieve(lf[45]),((C_word*)t0)[2]);
/* csi.scm:252: ##sys#print */
t3=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,t2,C_SCHEME_TRUE,*((C_word*)lf[52]+1));}

/* loop in k2146 in k2139 in k2133 in k2116 in k2107 in k2095 in lookup-script-file in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_2150(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2150,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2160,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2177,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=C_slot(t2,C_fix(0));
/* csi.scm:219: chop-separator */
t6=C_fast_retrieve(lf[30]);
f_1992(3,t6,t4,t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k6822 in k6798 in k6795 in a6792 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_6824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6824,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6828,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:436: g338 */
t3=t2;
f_6828(t3,((C_word*)t0)[3],t1);}
else{
/* csi.scm:446: printf */
t2=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],lf[388],((C_word*)((C_word*)t0)[2])[1]);}}

/* g338 in k6822 in k6798 in k6795 in a6792 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_6828(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6828,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6832,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:443: ##sys#switch-module */
((C_proc3)C_fast_retrieve_symbol_proc(lf[387]))(3,*((C_word*)lf[387]+1),t3,t2);}

/* k2126 in k2119 in k2116 in k2107 in k2095 in lookup-script-file in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:213: addext */
f_2042(((C_word*)t0)[3],t1);}

/* k2119 in k2116 in k2107 in k2095 in lookup-script-file in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2121,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2128,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2132,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:213: chop-separator */
t4=C_fast_retrieve(lf[30]);
f_1992(3,t4,t3,t1);}

/* a6857 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_6858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6866,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:265: ##sys#current-module */
((C_proc2)C_fast_retrieve_symbol_proc(lf[400]))(2,*((C_word*)lf[400]+1),t2);}

/* k6854 in k6795 in a6792 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_6856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_6800(t3,t2);}

/* k2133 in k2116 in k2107 in k2095 in lookup-script-file in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2135,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2141,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[5];
/* ##sys#string-append */
((C_proc4)C_fast_retrieve_symbol_proc(lf[34]))(4,*((C_word*)lf[34]+1),t2,lf[42],t3);}}

/* k2130 in k2119 in k2116 in k2107 in k2095 in lookup-script-file in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:213: string-append */
t2=*((C_word*)lf[37]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,lf[38],((C_word*)t0)[3]);}

/* k6878 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_6880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6880,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
f_1892(t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6889,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:78: get-environment-variable */
t3=C_fast_retrieve(lf[43]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[405]);}}

/* k2107 in k2095 in lookup-script-file in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2109,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm:210: addext */
f_2042(((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2118,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_retrieve2(lf[28],"dirseparator\077");
t4=((C_word*)t0)[4];
t5=C_block_size(t4);
t6=t5;
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2071,a[2]=t6,a[3]=t8,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_2071(t10,t2,C_fix(0));}}

/* k6887 in k6878 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_6889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1892(t2,(C_truep(t1)?lf[403]:lf[404]));}

/* k2789 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[48]+1));}

/* k6864 in a6857 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_6866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6869,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6876,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:267: ##sys#module-name */
((C_proc3)C_fast_retrieve_symbol_proc(lf[398]))(3,*((C_word*)lf[398]+1),t3,t1);}
else{
/* csi.scm:264: sprintf */
t3=*((C_word*)lf[206]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[396],lf[399],C_fast_retrieve(lf[25]));}}

/* k6636 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 in ... */
static void C_ccall f_6638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_i_member(lf[362],((C_word*)((C_word*)t0)[2])[1]);
t4=((C_word*)t0)[3];
f_5650(t4,(C_truep(t3)?C_i_set_cdr(t3,C_SCHEME_END_OF_LIST):C_SCHEME_FALSE));}

/* k3962 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_3964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:665: sprintf */
t2=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[207],t1);}

/* k2161 in k2158 in loop in k2146 in k2139 in k2133 in k2116 in k2107 in k2095 in lookup-script-file in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_slot(((C_word*)t0)[3],C_fix(1));
/* csi.scm:221: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2150(t3,((C_word*)t0)[2],t2);}}

/* k2158 in loop in k2146 in k2139 in k2133 in k2116 in k2107 in k2095 in lookup-script-file in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2160,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2163,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:220: addext */
f_2042(t2,t1);}

/* k3958 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_3960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:664: descseq */
t2=((C_word*)t0)[2];
f_3474(6,t2,((C_word*)t0)[3],t1,*((C_word*)lf[182]+1),*((C_word*)lf[184]+1),C_fix(1));}

/* k6867 in k6864 in a6857 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_6869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:264: sprintf */
t2=*((C_word*)lf[206]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[396],t1,C_fast_retrieve(lf[25]));}

/* k2777 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[48]+1));}

/* doloop755 in doloop747 in k4667 in k4664 in doloop737 in hexdump in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_4775(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4775,NULL,3,t0,t1,t2);}
t3=C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4785,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm:787: display */
t5=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[258],((C_word*)t0)[3]);}}

/* k2175 in loop in k2146 in k2139 in k2133 in k2116 in k2107 in k2095 in lookup-script-file in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#string-append */
((C_proc4)C_fast_retrieve_symbol_proc(lf[34]))(4,*((C_word*)lf[34]+1),((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* k6695 in a6686 in k6679 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_6697(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6697,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=C_i_cdr(((C_word*)t0)[2]);
t5=C_i_car(t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6710,a[2]=t3,a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:920: rename1013 */
t8=((C_word*)t0)[4];
((C_proc3)C_fast_retrieve_proc(t8))(3,t8,t7,lf[379]);}
else{
/* csi.scm:920: ##sys#syntax-rules-mismatch */
((C_proc3)C_fast_retrieve_symbol_proc(lf[380]))(3,*((C_word*)lf[380]+1),((C_word*)t0)[3],((C_word*)t0)[5]);}}

/* k2146 in k2139 in k2133 in k2116 in k2107 in k2095 in lookup-script-file in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2148,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2150,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2150(t5,((C_word*)t0)[4],t1);}

/* k2139 in k2133 in k2116 in k2107 in k2095 in lookup-script-file in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2141,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2148,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:217: string-split */
t4=C_fast_retrieve(lf[40]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],lf[41]);}

/* k3987 in k3968 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_3989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:668: fprintf */
t2=*((C_word*)lf[162]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[211],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],t1);}

/* k6683 in k6679 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_6685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:919: ##sys#extend-macro-environment */
((C_proc5)C_fast_retrieve_symbol_proc(lf[374]))(5,*((C_word*)lf[374]+1),((C_word*)t0)[2],lf[375],((C_word*)t0)[3],t1);}

/* ##csi#history-add in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2200(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2200,3,t0,t1,t2);}
t3=C_i_nullp(t2);
t4=(C_truep(t3)?*((C_word*)lf[48]+1):C_slot(t2,C_fix(0)));
t5=t4;
t6=C_block_size(C_fast_retrieve(lf[45]));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2210,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_fixnum_greater_or_equal_p(C_fast_retrieve(lf[25]),t6))){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2224,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=C_fixnum_times(C_fix(2),t6);
/* csi.scm:235: vector-resize */
t10=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,C_fast_retrieve(lf[45]),t9);}
else{
t8=t7;
f_2210(t8,C_SCHEME_UNDEFINED);}}

/* k4793 in doloop747 in k4667 in k4664 in doloop737 in hexdump in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_4795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4798,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4813,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4817,a[2]=((C_word*)t0)[7],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:789: ref */
t5=((C_word*)t0)[8];
((C_proc4)C_fast_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[9],((C_word*)t0)[3]);}

/* a6686 in k6679 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_6687(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6687,5,t0,t1,t2,t3,t4);}
t5=C_i_cdr(t2);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6697,a[2]=t6,a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t6))){
t8=C_i_cdr(t6);
if(C_truep(C_i_pairp(t8))){
t9=C_i_cdr(t8);
t10=t7;
f_6697(t10,C_eqp(t9,C_SCHEME_END_OF_LIST));}
else{
t9=t7;
f_6697(t9,C_SCHEME_FALSE);}}
else{
t8=t7;
f_6697(t8,C_SCHEME_FALSE);}}

/* k6679 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_6681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6681,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6685,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6687,tmp=(C_word)a,a+=2,tmp);
/* csi.scm:920: ##sys#er-transformer */
((C_proc3)C_fast_retrieve_symbol_proc(lf[381]))(3,*((C_word*)lf[381]+1),t3,t4);}

/* k4796 in k4793 in doloop747 in k4667 in k4664 in doloop737 in hexdump in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 in ... */
static void C_ccall f_4798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_4741(t4,((C_word*)t0)[5],t2,t3);}

/* k3968 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_3970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3970,2,t0,t1);}
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=(C_truep(t2)?lf[209]:lf[210]);
t4=t3;
t5=C_slot(((C_word*)t0)[2],C_fix(7));
t6=t5;
t7=C_slot(((C_word*)t0)[2],C_fix(3));
t8=t7;
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3989,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t6,a[6]=t8,tmp=(C_word)a,a+=7,tmp);
/* csi.scm:673: ##sys#peek-unsigned-integer */
((C_proc4)C_fast_retrieve_symbol_proc(lf[208]))(4,*((C_word*)lf[208]+1),t9,((C_word*)t0)[2],C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3998,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:674: ##sys#locative? */
((C_proc3)C_fast_retrieve_symbol_proc(lf[245]))(3,*((C_word*)lf[245]+1),t2,((C_word*)t0)[2]);}}

/* a6672 in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_6673(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6673,3,t0,t1,t2);}
/* csi.scm:926: ##sys#user-interrupt-hook */
((C_proc2)C_fast_retrieve_symbol_proc(lf[266]))(2,*((C_word*)lf[266]+1),t1);}

/* k6669 in k6663 in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_6671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_fast_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k6666 in k6663 in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_6668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* k6663 in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_6665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6665,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6668,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6671,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_fast_retrieve_symbol_proc(lf[373]))(2,*((C_word*)lf[373]+1),t3);}

/* ##sys#read-prompt-hook in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2339,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2346,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=C_fudge(C_fix(12));
if(C_truep(t3)){
if(C_truep(t3)){
/* csi.scm:279: old */
t4=((C_word*)t0)[2];
((C_proc2)C_fast_retrieve_proc(t4))(2,t4,t1);}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}
else{
/* csi.scm:272: ##sys#tty-port? */
((C_proc3)C_fast_retrieve_symbol_proc(lf[61]))(3,*((C_word*)lf[61]+1),t2,*((C_word*)lf[62]+1));}}

/* k3761 in k3758 in k3755 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_3763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3763,2,t0,t1);}
t2=C_slot(((C_word*)t0)[2],C_fix(2));
t3=t2;
if(C_truep(C_i_nullp(t3))){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[48]+1));}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3775,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* csi.scm:640: display */
t5=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[189],((C_word*)t0)[4]);}}

/* k3758 in k3755 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_3760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3760,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3763,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3838,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:633: ##sys#interned-symbol? */
((C_proc3)C_fast_retrieve_symbol_proc(lf[196]))(3,*((C_word*)lf[196]+1),t4,((C_word*)t0)[2]);}

/* k2344 in read-prompt-hook in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* csi.scm:279: old */
t2=((C_word*)t0)[2];
((C_proc2)C_fast_retrieve_proc(t2))(2,t2,((C_word*)t0)[3]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3791 in k3788 in doloop552 in k3773 in k3761 in k3758 in k3755 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in ... */
static void C_ccall f_3793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3793,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3796,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:648: newline */
t3=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* for-each-loop617 in k4238 in k4110 in k3996 in k3968 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in ... */
static void C_fcall f_4309(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4309,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4319,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:713: g618 */
t5=((C_word*)t0)[3];
f_4241(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3794 in k3791 in k3788 in doloop552 in k3773 in k3761 in k3758 in k3755 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in ... */
static void C_ccall f_3796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cddr(((C_word*)t0)[2]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_3780(t3,((C_word*)t0)[4],t2);}

/* for-each-loop1270 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in ... */
static void C_fcall f_6386(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6386,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6396,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:1055: g1271 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3788 in doloop552 in k3773 in k3761 in k3758 in k3755 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in ... */
static void C_ccall f_3790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3790,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3793,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3805,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:644: ##sys#with-print-length-limit */
((C_proc4)C_fast_retrieve_symbol_proc(lf[55]))(4,*((C_word*)lf[55]+1),t2,C_fix(1000),t3);}

/* k6371 in for-each-loop1287 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in ... */
static void C_ccall f_6373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6363(t3,((C_word*)t0)[4],t2);}

/* doloop552 in k3773 in k3761 in k3758 in k3755 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in ... */
static void C_fcall f_3780(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3780,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3790,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=C_i_car(t2);
/* csi.scm:643: fprintf */
t5=*((C_word*)lf[162]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,((C_word*)t0)[3],lf[188],t4);}}

/* loop in canonicalize-args in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_5464(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5464,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=C_i_car(t2);
t4=t3;
if(C_truep((C_truep(C_i_equalp(t4,lf[270]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[271]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[272]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[273]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[274]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5486,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=C_block_size(t4);
if(C_truep(C_fixnum_greaterp(t6,C_fix(2)))){
t7=C_subchar(t4,C_fix(0));
if(C_truep(C_i_char_equalp(C_make_character(45),t7))){
t8=C_i_member(t4,lf[277]);
t9=t5;
f_5486(t9,C_i_not(t8));}
else{
t8=t5;
f_5486(t8,C_SCHEME_FALSE);}}
else{
t7=t5;
f_5486(t7,C_SCHEME_FALSE);}}}}

/* k2711 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:360: describe */
t2=C_fast_retrieve(lf[80]);
f_3468(3,t2,((C_word*)t0)[2],C_fast_retrieve(lf[100]));}

/* g932 in doloop917 in a5200 in k5166 in k2821 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_5257(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5257,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5263,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_5263(t7,t1,C_fix(0),t2);}

/* ##csi#tty-input? in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2326,2,t0,t1);}
t2=C_fudge(C_fix(12));
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* csi.scm:272: ##sys#tty-port? */
((C_proc3)C_fast_retrieve_symbol_proc(lf[61]))(3,*((C_word*)lf[61]+1),t1,*((C_word*)lf[62]+1));}}

/* k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2324,2,t0,t1);}
t2=C_mutate2((C_word*)lf[60]+1 /* (set! ##csi#tty-input? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2326,tmp=(C_word)a,a+=2,tmp));
t3=C_set_block_item(lf[63] /* ##sys#break-on-error */,0,C_SCHEME_FALSE);
t4=C_fast_retrieve(lf[64]);
t5=C_mutate2((C_word*)lf[64]+1 /* (set! ##sys#read-prompt-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2339,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=lf[65] /* command-table */ =C_SCHEME_END_OF_LIST;;
t7=C_mutate2((C_word*)lf[66]+1 /* (set! toplevel-command ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2352,tmp=(C_word)a,a+=2,tmp));
t8=C_fast_retrieve(lf[67]);
t9=C_fast_retrieve(lf[68]);
t10=C_fast_retrieve(lf[69]);
t11=C_fast_retrieve(lf[40]);
t12=C_fast_retrieve(lf[70]);
t13=C_fast_retrieve(lf[71]);
t14=*((C_word*)lf[72]+1);
t15=C_mutate2(&lf[73] /* (set! csi-eval ...) */,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2402,a[2]=t13,a[3]=t12,a[4]=t8,a[5]=t11,a[6]=t10,a[7]=t9,a[8]=t14,tmp=(C_word)a,a+=9,tmp));
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2974,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6793,tmp=(C_word)a,a+=2,tmp);
/* csi.scm:429: toplevel-command */
t18=C_fast_retrieve(lf[66]);
f_2352(5,t18,t16,lf[394],t17,lf[395]);}

/* k4899 in k4896 in k4893 in k4890 in doloop799 in k4850 in show-frameinfo in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 in ... */
static void C_ccall f_4901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4901,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4904,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* csi.scm:819: ##sys#write-char-0 */
((C_proc4)C_fast_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t2,C_make_character(9),((C_word*)t0)[12]);}

/* k4902 in k4899 in k4896 in k4893 in k4890 in doloop799 in k4850 in show-frameinfo in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in ... */
static void C_ccall f_4904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4904,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4907,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t3=C_slot(((C_word*)t0)[13],C_fix(0));
/* csi.scm:819: ##sys#print */
t4=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_FALSE,((C_word*)t0)[12]);}

/* k4905 in k4902 in k4899 in k4896 in k4893 in k4890 in doloop799 in k4850 in show-frameinfo in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in ... */
static void C_ccall f_4907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4907,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4910,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* csi.scm:819: ##sys#print */
t3=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[263],C_SCHEME_FALSE,((C_word*)t0)[12]);}

/* a3804 in k3788 in doloop552 in k3773 in k3761 in k3758 in k3755 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in ... */
static void C_ccall f_3805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3805,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
/* csi.scm:647: write */
t3=*((C_word*)lf[187]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[3]);}

/* doloop945 in g932 in doloop917 in a5200 in k5166 in k2821 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_5263(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5263,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t3))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5273,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5285,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=t3,a[7]=((C_word*)t0)[2],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t6=C_i_car(t3);
/* csi.scm:903: compare */
t7=((C_word*)t0)[5];
f_5170(t7,t5,t6);}}

/* k6394 in for-each-loop1270 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in ... */
static void C_ccall f_6396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6386(t3,((C_word*)t0)[4],t2);}

/* k5484 in loop in canonicalize-args in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_5486(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5486,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_subchar(((C_word*)t0)[2],C_fix(1));
if(C_truep(C_i_char_equalp(C_make_character(58),t2))){
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
/* csi.scm:959: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5464(t5,((C_word*)t0)[5],t4);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5500,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5569,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:960: substring */
t5=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_fix(1));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5577,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
/* csi.scm:964: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5464(t5,t2,t4);}}

/* k5271 in doloop945 in g932 in doloop917 in a5200 in k5166 in k2821 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_5273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
t5=((C_word*)((C_word*)t0)[4])[1];
f_5263(t5,((C_word*)t0)[5],t2,t4);}

/* canonicalize-args in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_5458(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5458,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5464,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_5464(t6,t1,t2);}

/* k2528 in k2525 in k2522 in k2519 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:341: dump */
t2=C_fast_retrieve(lf[82]);
f_4475(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k5206 in fail in a5200 in k5166 in k2821 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_5208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5208,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5211,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:888: newline */
t3=*((C_word*)lf[22]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* a5200 in k5166 in k2821 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_5201(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5201,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5204,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5223,a[2]=t3,a[3]=t5,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_5223(t7,t1,((C_word*)t0)[4]);}

/* fail in a5200 in k5166 in k2821 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_5204(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5204,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5208,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:887: display */
t4=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2756 in k2749 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:363: string-append */
t2=*((C_word*)lf[37]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[104],t1);}

/* k4908 in k4905 in k4902 in k4899 in k4896 in k4893 in k4890 in doloop799 in k4850 in show-frameinfo in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in ... */
static void C_ccall f_4910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4910,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4913,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[11])){
t3=*((C_word*)lf[52]+1);
t4=*((C_word*)lf[52]+1);
t5=C_i_check_port_2(*((C_word*)lf[52]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[53]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5053,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:833: ##sys#write-char-0 */
((C_proc4)C_fast_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t6,C_make_character(91),*((C_word*)lf[52]+1));}
else{
t3=t2;
f_4913(2,t3,C_SCHEME_UNDEFINED);}}

/* k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4893 in k4890 in doloop799 in k4850 in show-frameinfo in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in ... */
static void C_ccall f_4913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4916,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[10])){
/* csi.scm:834: prin1 */
f_4829(t2,((C_word*)t0)[10]);}
else{
t3=t2;
f_4916(2,t3,C_SCHEME_UNDEFINED);}}

/* k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_3606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3606,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3609,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_charp(((C_word*)t0)[3]))){
t3=C_fix(C_character_code(((C_word*)t0)[3]));
/* csi.scm:608: fprintf */
t4=*((C_word*)lf[162]+1);
((C_proc8)(void*)(*((C_word*)t4+1)))(8,t4,t2,((C_word*)t0)[4],lf[169],((C_word*)t0)[3],t3,t3,t3);}
else{
switch(((C_word*)t0)[3]){
case C_SCHEME_TRUE:
/* csi.scm:609: fprintf */
t3=*((C_word*)lf[162]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],lf[170]);
case C_SCHEME_FALSE:
/* csi.scm:610: fprintf */
t3=*((C_word*)lf[162]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],lf[171]);
default:
if(C_truep(C_i_nullp(((C_word*)t0)[3]))){
/* csi.scm:611: fprintf */
t3=*((C_word*)lf[162]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],lf[172]);}
else{
if(C_truep(C_eofp(((C_word*)t0)[3]))){
/* csi.scm:612: fprintf */
t3=*((C_word*)lf[162]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],lf[173]);}
else{
t3=*((C_word*)lf[48]+1);
t4=C_eqp(*((C_word*)lf[48]+1),((C_word*)t0)[3]);
if(C_truep(t4)){
/* csi.scm:613: fprintf */
t5=*((C_word*)lf[162]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,((C_word*)t0)[4],lf[174]);}
else{
if(C_truep(C_fixnump(((C_word*)t0)[3]))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3675,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:615: fprintf */
t6=*((C_word*)lf[162]+1);
((C_proc8)(void*)(*((C_word*)t6+1)))(8,t6,t5,((C_word*)t0)[4],lf[176],((C_word*)t0)[3],((C_word*)t0)[3],((C_word*)t0)[3],((C_word*)t0)[3]);}
else{
t5=C_slot(lf[177],C_fix(0));
t6=C_eqp(((C_word*)t0)[3],t5);
if(C_truep(t6)){
/* csi.scm:620: fprintf */
t7=*((C_word*)lf[162]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t2,((C_word*)t0)[4],lf[178]);}
else{
if(C_truep(C_i_flonump(((C_word*)t0)[3]))){
/* csi.scm:621: fprintf */
t7=*((C_word*)lf[162]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t2,((C_word*)t0)[4],lf[179],((C_word*)t0)[3]);}
else{
if(C_truep(C_i_numberp(((C_word*)t0)[3]))){
/* csi.scm:622: fprintf */
t7=*((C_word*)lf[162]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t2,((C_word*)t0)[4],lf[180],((C_word*)t0)[3]);}
else{
if(C_truep(C_i_stringp(((C_word*)t0)[3]))){
/* csi.scm:623: descseq */
t7=((C_word*)t0)[5];
f_3474(6,t7,t2,lf[181],*((C_word*)lf[182]+1),((C_word*)t0)[6],C_fix(0));}
else{
if(C_truep(C_i_vectorp(((C_word*)t0)[3]))){
/* csi.scm:624: descseq */
t7=((C_word*)t0)[5];
f_3474(6,t7,t2,lf[183],*((C_word*)lf[182]+1),*((C_word*)lf[184]+1),C_fix(0));}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3741,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* csi.scm:625: keyword? */
t8=C_fast_retrieve(lf[247]);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t0)[3]);}}}}}}}}}}}}

/* k3601 in descseq in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_3603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3603,2,t0,t1);}
t2=C_fixnum_difference(t1,((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3481,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[7])){
/* csi.scm:583: fprintf */
t5=*((C_word*)lf[162]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,((C_word*)t0)[3],lf[168],((C_word*)t0)[7],t3);}
else{
t5=t4;
f_3481(2,t5,C_SCHEME_UNDEFINED);}}

/* k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4893 in k4890 in doloop799 in k4850 in show-frameinfo in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in ... */
static void C_ccall f_4916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4919,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* csi.scm:835: newline */
t3=*((C_word*)lf[22]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4893 in k4890 in doloop799 in k4850 in show-frameinfo in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in ... */
static void C_ccall f_4919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4922,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep(((C_word*)t0)[6])?((C_word*)t0)[7]:C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4935,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t5=C_slot(((C_word*)t0)[9],C_fix(2));
t6=C_slot(((C_word*)t0)[9],C_fix(3));
t7=C_i_check_list_2(t5,lf[94]);
t8=C_i_check_list_2(t6,lf[94]);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5009,a[2]=t10,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t12=((C_word*)t10)[1];
f_5009(t12,t2,t5,t6);}
else{
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
t7=((C_word*)((C_word*)t0)[4])[1];
f_4861(t7,((C_word*)t0)[5],t5,t6);}}

/* k2749 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2751,2,t0,t1);}
t2=(C_truep(t1)?t1:C_retrieve2(lf[8],"default-editor"));
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2758,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:365: read-line */
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k5862 in k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in ... */
static void C_ccall f_5864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5867,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6192,a[2]=t2,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1076: member* */
f_5403(t3,lf[324],((C_word*)((C_word*)t0)[6])[1]);}

/* k5865 in k5862 in k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in ... */
static void C_ccall f_5867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5867,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5870,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6171,a[2]=t2,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1079: member* */
f_5403(t3,lf[322],((C_word*)((C_word*)t0)[6])[1]);}

/* k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in ... */
static void C_ccall f_5861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6204,a[2]=t2,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1073: member* */
f_5403(t3,lf[326],((C_word*)((C_word*)t0)[6])[1]);}

/* k5289 in k5286 in k5283 in doloop945 in g932 in doloop917 in a5200 in k5166 in k2821 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 in ... */
static void C_ccall f_5291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5294,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:906: newline */
t3=*((C_word*)lf[22]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5295 in k5292 in k5289 in k5286 in k5283 in doloop945 in g932 in doloop917 in a5200 in k5166 in k2821 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in ... */
static void C_ccall f_5297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],((C_word*)t0)[3]);
/* csi.scm:908: return */
t3=((C_word*)t0)[4];
((C_proc3)C_fast_retrieve_proc(t3))(3,t3,((C_word*)t0)[5],t2);}

/* k5292 in k5289 in k5286 in k5283 in doloop945 in g932 in doloop917 in a5200 in k5166 in k2821 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in ... */
static void C_ccall f_5294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5297,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_slot(((C_word*)t0)[2],((C_word*)t0)[3]);
t4=C_a_i_list1(&a,1,t3);
/* csi.scm:907: history-add */
t5=C_fast_retrieve(lf[47]);
f_2200(3,t5,t2,t4);}

/* k4943 in g834 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4893 in k4890 in doloop799 in k4850 in show-frameinfo in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in ... */
static void C_ccall f_4945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4945,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4950,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4950(t5,((C_word*)t0)[4],C_fix(0),((C_word*)t0)[5]);}

/* k3839 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_3841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_3757(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csi.scm:630: display */
t2=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[198],((C_word*)t0)[3]);}}

/* k3607 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_3609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[48]+1));}

/* k3836 in k3758 in k3755 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_3838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3838,2,t0,t1);}
t2=(C_truep(t1)?lf[190]:lf[191]);
t3=t2;
t4=(C_truep(((C_word*)t0)[2])?lf[192]:lf[193]);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3829,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
/* csi.scm:636: ##sys#symbol->qualified-string */
((C_proc3)C_fast_retrieve_symbol_proc(lf[195]))(3,*((C_word*)lf[195]+1),t6,((C_word*)t0)[5]);}
else{
/* csi.scm:637: ##sys#symbol->string */
((C_proc3)C_fast_retrieve_symbol_proc(lf[186]))(3,*((C_word*)lf[186]+1),t6,((C_word*)t0)[5]);}}

/* k5871 in k5868 in k5865 in k5862 in k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in ... */
static void C_ccall f_5873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5873,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5876,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=C_set_block_item(lf[5] /* ##sys#notices-enabled */,0,C_SCHEME_FALSE);
t4=t2;
f_5876(t4,t3);}
else{
t3=t2;
f_5876(t3,C_SCHEME_UNDEFINED);}}

/* k5874 in k5871 in k5868 in k5865 in k5862 in k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in ... */
static void C_fcall f_5876(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5876,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5881,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_5881(t5,((C_word*)t0)[5],((C_word*)((C_word*)t0)[6])[1]);}

/* k5868 in k5865 in k5862 in k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in ... */
static void C_ccall f_5870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5873,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6159,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm:1085: member* */
f_5403(t3,lf[316],((C_word*)((C_word*)t0)[6])[1]);}

/* g834 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4893 in k4890 in doloop799 in k4850 in show-frameinfo in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in ... */
static void C_fcall f_4935(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4935,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4945,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm:840: display */
t5=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[261]);}}

/* k2522 in k2519 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2524,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2527,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm:339: eval */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k2525 in k2522 in k2519 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2527,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2530,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:340: eval */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k4456 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_4458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:605: fprintf */
t2=*((C_word*)lf[162]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[248],t1);}

/* k2519 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2521,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2524,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm:338: read */
t4=*((C_word*)lf[77]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k2745 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:362: system */
t2=C_fast_retrieve(lf[103]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* set-describer! in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_4466(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4466,4,t0,t1,t2,t3);}
t4=C_i_check_symbol_2(t2,lf[250]);
/* csi.scm:740: ##sys#hash-table-set! */
((C_proc5)C_fast_retrieve_symbol_proc(lf[251]))(5,*((C_word*)lf[251]+1),t1,C_retrieve2(lf[158],"describer-table"),t2,t3);}

/* k1953 in user-read-hook in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_1955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1955,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,2,lf[24],t1));}

/* k5246 in doloop917 in a5200 in k5166 in k2821 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_5248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)((C_word*)t0)[3])[1];
f_5223(t4,((C_word*)t0)[4],t3);}

/* bestlen in body700 in dump in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_4480(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4480,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)t0)[2])){
/* csi.scm:750: min */
t3=*((C_word*)lf[252]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,((C_word*)t0)[2],t2);}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* doloop847 in k4943 in g834 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4893 in k4890 in doloop799 in k4850 in show-frameinfo in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in ... */
static void C_fcall f_4950(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4950,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t3))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=*((C_word*)lf[52]+1);
t5=*((C_word*)lf[52]+1);
t6=C_i_check_port_2(*((C_word*)lf[52]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[53]);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4963,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t4,tmp=(C_word)a,a+=9,tmp);
/* csi.scm:841: ##sys#print */
t8=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,lf[260],C_SCHEME_FALSE,*((C_word*)lf[52]+1));}}

/* k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_3853(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3853,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3856,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:650: fprintf */
t3=*((C_word*)lf[162]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],lf[203]);}
else{
if(C_truep(C_i_listp(((C_word*)t0)[2]))){
/* csi.scm:660: descseq */
t2=((C_word*)t0)[5];
f_3474(6,t2,((C_word*)t0)[4],lf[204],((C_word*)t0)[6],((C_word*)t0)[7],C_fix(0));}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
/* csi.scm:661: fprintf */
t6=*((C_word*)lf[162]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,((C_word*)t0)[4],((C_word*)t0)[3],lf[205],t3,t5);}
else{
if(C_truep(C_i_closurep(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3960,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3964,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:665: ##sys#peek-unsigned-integer */
((C_proc4)C_fast_retrieve_symbol_proc(lf[208]))(4,*((C_word*)lf[208]+1),t3,((C_word*)t0)[2],C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3970,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:667: port? */
t3=C_fast_retrieve(lf[246]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}}}}

/* k3854 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_3856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3856,2,t0,t1);}
t2=C_a_i_list1(&a,1,((C_word*)t0)[2]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3865,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_3865(t6,((C_word*)t0)[4],((C_word*)t0)[2],t2);}

/* body700 in dump in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_4477(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4477,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4480,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_immp(((C_word*)t0)[2]))){
/* csi.scm:751: ##sys#error */
t5=*((C_word*)lf[58]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[253],lf[254],((C_word*)t0)[2]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4502,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* csi.scm:752: ##sys#bytevector? */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[244]+1)))(3,*((C_word*)lf[244]+1),t5,((C_word*)t0)[2]);}}

/* ##csi#dump in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_4475(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_4475r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4475r(t0,t1,t2,t3);}}

static void C_ccall f_4475r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4477,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4583,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4588,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(t3))){
/* csi.scm:746: def-len702 */
t7=t6;
f_4588(t7,t1);}
else{
t7=C_i_car(t3);
t8=C_u_i_cdr(t3);
if(C_truep(C_i_nullp(t8))){
/* csi.scm:746: def-out703 */
t9=t5;
f_4583(t9,t1,t7);}
else{
t9=C_i_car(t8);
t10=C_u_i_cdr(t8);
/* csi.scm:746: body700 */
t11=t4;
f_4477(t11,t1,t7,t9);}}}

/* k2727 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* csi.scm:367: printf */
t3=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],lf[102],t1);}}

/* dirseparator? in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_1977(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1977,3,t0,t1,t2);}
if(C_truep(*((C_word*)lf[29]+1))){
t3=C_i_char_equalp(t2,C_make_character(92));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:C_i_char_equalp(t2,C_make_character(47))));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_char_equalp(t2,C_make_character(47)));}}

/* k1973 in sharp-number-hook in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_1975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1975,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,2,lf[24],t1));}

/* k3827 in k3836 in k3758 in k3755 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 in ... */
static void C_ccall f_3829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:632: fprintf */
t2=*((C_word*)lf[162]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[194],((C_word*)t0)[4],((C_word*)t0)[5],t1);}

/* k4920 in k4917 in k4914 in k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4893 in k4890 in doloop799 in k4850 in show-frameinfo in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in ... */
static void C_ccall f_4922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
t5=((C_word*)((C_word*)t0)[4])[1];
f_4861(t5,((C_word*)t0)[5],t3,t4);}

/* ##csi#chop-separator in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_1992(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1992,3,t0,t1,t2);}
t3=C_block_size(t2);
t4=C_a_i_minus(&a,2,t3,C_fix(1));
t5=t4;
t6=C_i_string_ref(t2,t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2005,a[2]=t1,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_fixnum_greaterp(t5,C_fix(0)))){
/* csi.scm:184: dirseparator? */
t8=C_retrieve2(lf[28],"dirseparator\077");
f_1977(3,t8,t7,t6);}
else{
t8=t7;
f_2005(2,t8,C_SCHEME_FALSE);}}

/* lp in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static C_word C_fcall f_3401(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_stack_overflow_check;
loop:
if(C_truep(C_i_pairp(t1))){
t3=t1;
t4=C_u_i_cdr(t3);
if(C_truep(C_i_pairp(t4))){
t5=C_u_i_cdr(t4);
t6=C_i_cdr(t2);
t7=C_eqp(t5,t6);
if(C_truep(t7)){
return(t7);}
else{
t9=t5;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}

/* k5283 in doloop945 in g932 in doloop917 in a5200 in k5166 in k2821 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_5285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5285,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5288,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* csi.scm:904: display */
t3=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[115]);}
else{
t2=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t3=((C_word*)t0)[6];
t4=C_u_i_cdr(t3);
t5=((C_word*)((C_word*)t0)[7])[1];
f_5263(t5,((C_word*)t0)[8],t2,t4);}}

/* k5286 in k5283 in doloop945 in g932 in doloop917 in a5200 in k5166 in k2821 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_5288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5291,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[6];
t4=C_u_i_car(t3);
/* csi.scm:905: display */
t5=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t2,t4);}

/* k6446 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in ... */
static void C_ccall f_6448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:1049: print-banner */
t2=C_fast_retrieve(lf[16]);
f_1922(2,t2,((C_word*)t0)[2]);}

/* k3679 in k3673 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_3681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:618: ##sys#write-char-0 */
((C_proc4)C_fast_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[52]+1));}

/* k6431 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in ... */
static void C_ccall f_6433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6433,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6436,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f7552,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1052: register-feature! */
t4=C_fast_retrieve(lf[282]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[340]);}
else{
/* csi.scm:1051: display */
t3=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[341]);}}
else{
t2=((C_word*)t0)[2];
f_5827(2,t2,C_SCHEME_UNDEFINED);}}

/* k6434 in k6431 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in ... */
static void C_ccall f_6436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6436,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6439,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1052: register-feature! */
t3=C_fast_retrieve(lf[282]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[340]);}

/* k6437 in k6434 in k6431 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in ... */
static void C_ccall f_6439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:1053: case-sensitive */
t2=C_fast_retrieve(lf[320]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* ##sys#sharp-number-hook in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_1967(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1967,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1975,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:170: history-ref */
t5=C_fast_retrieve(lf[26]);
f_2299(3,t5,t4,t3);}

/* k3673 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_3675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3675,2,t0,t1);}
t2=C_make_character(C_unfix(((C_word*)t0)[2]));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3681,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_fixnum_lessp(((C_word*)t0)[2],C_fix(65536)))){
/* csi.scm:617: fprintf */
t4=*((C_word*)lf[162]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[4],lf[175],t2);}
else{
/* csi.scm:618: ##sys#write-char-0 */
((C_proc4)C_fast_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),((C_word*)t0)[3],C_make_character(10),*((C_word*)lf[52]+1));}}

/* k2082 in loop in k2107 in k2095 in lookup-script-file in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* csi.scm:206: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2071(t3,((C_word*)t0)[2],t2);}}

/* k6205 in k6202 in k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in ... */
static void C_ccall f_6207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:1075: parentheses-synonyms */
t2=C_fast_retrieve(lf[318]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k6202 in k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in ... */
static void C_ccall f_6204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6204,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6207,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
/* csi.scm:1075: parentheses-synonyms */
t3=C_fast_retrieve(lf[318]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
/* csi.scm:1074: display */
t3=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[325]);}}
else{
t2=((C_word*)t0)[2];
f_5864(2,t2,C_SCHEME_UNDEFINED);}}

/* doloop376 in k3076 in a3069 in a3063 in a3045 in k2978 in k6657 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in ... */
static void C_fcall f_3080(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3080,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_eofp(t2))){
/* csi.scm:463: reverse */
t4=*((C_word*)lf[369]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3097,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm:461: read */
t5=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}}

/* ##csi#lookup-script-file in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2093(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2093,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2097,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:208: get-environment-variable */
t4=C_fast_retrieve(lf[43]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[44]);}

/* k2095 in lookup-script-file in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2097,2,t0,t1);}
t2=t1;
t3=C_block_size(((C_word*)t0)[2]);
if(C_truep(C_fixnum_greaterp(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2109,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t5=C_i_string_ref(((C_word*)t0)[2],C_fix(0));
/* csi.scm:210: dirseparator? */
t6=C_retrieve2(lf[28],"dirseparator\077");
f_1977(3,t6,t4,t5);}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* ##csi#describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_3468(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_3468r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3468r(t0,t1,t2,t3);}}

static void C_ccall f_3468r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(17);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?*((C_word*)lf[52]+1):C_i_car(t3));
t6=t5;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3474,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3606,a[2]=t1,a[3]=t2,a[4]=t6,a[5]=t7,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_permanentp(t2))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4458,a[2]=t8,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:605: ##sys#block-address */
((C_proc3)C_fast_retrieve_symbol_proc(lf[249]))(3,*((C_word*)lf[249]+1),t9,t2);}
else{
t9=t8;
f_3606(2,t9,C_SCHEME_UNDEFINED);}}

/* k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_3466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3466,2,t0,t1);}
t2=C_mutate2(&lf[158] /* (set! describer-table ...) */,t1);
t3=*((C_word*)lf[159]+1);
t4=*((C_word*)lf[160]+1);
t5=*((C_word*)lf[161]+1);
t6=C_mutate2((C_word*)lf[80]+1 /* (set! ##csi#describe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3468,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t7=C_mutate2((C_word*)lf[250]+1 /* (set! set-describer! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4466,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate2((C_word*)lf[82]+1 /* (set! ##csi#dump ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4475,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate2((C_word*)lf[224]+1 /* (set! ##csi#hexdump ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4623,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate2(&lf[108] /* (set! show-frameinfo ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4826,tmp=(C_word)a,a+=2,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5398,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6681,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:919: ##sys#current-environment */
((C_proc2)C_fast_retrieve_symbol_proc(lf[382]))(2,*((C_word*)lf[382]+1),t12);}

/* k4500 in body700 in dump in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_4502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4502,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4509,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_block_size(((C_word*)t0)[3]);
/* csi.scm:752: bestlen */
t4=((C_word*)t0)[5];
f_4480(t4,t2,t3);}
else{
if(C_truep(C_i_stringp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4526,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_block_size(((C_word*)t0)[3]);
/* csi.scm:753: bestlen */
t4=((C_word*)t0)[5];
f_4480(t4,t2,t3);}
else{
t2=C_immp(((C_word*)t0)[3]);
t3=(C_truep(t2)?C_SCHEME_FALSE:C_anypointerp(((C_word*)t0)[3]));
if(C_truep(t3)){
/* csi.scm:755: hexdump */
t4=C_fast_retrieve(lf[224]);
f_4623(6,t4,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(32),*((C_word*)lf[255]+1),((C_word*)t0)[4]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4545,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_structurep(((C_word*)t0)[3]))){
t5=C_slot(((C_word*)t0)[3],C_fix(0));
t6=t4;
f_4545(t6,C_i_assq(t5,C_retrieve2(lf[156],"##csi#bytevector-data")));}
else{
t5=t4;
f_4545(t5,C_SCHEME_FALSE);}}}}}

/* k4507 in k4500 in body700 in dump in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_4509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:752: hexdump */
t2=C_fast_retrieve(lf[224]);
f_4623(6,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1,*((C_word*)lf[225]+1),((C_word*)t0)[4]);}

/* f7552 in k6431 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in ... */
static void C_ccall f7552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:1053: case-sensitive */
t2=C_fast_retrieve(lf[320]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* ##sys#quit-hook in a5898 in doloop1370 in k5874 in k5871 in k5868 in k5865 in k5862 in k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in ... */
static void C_ccall f_5902(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5902,2,t0,t1);}
/* csi.scm:1093: k */
t2=((C_word*)t0)[2];
((C_proc3)C_fast_retrieve_proc(t2))(3,t2,t1,C_SCHEME_FALSE);}

/* k3095 in doloop376 in k3076 in a3069 in a3063 in a3045 in k2978 in k6657 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in ... */
static void C_ccall f_3097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3097,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=((C_word*)((C_word*)t0)[4])[1];
f_3080(t3,((C_word*)t0)[5],t1,t2);}

/* loop1 in k3479 in k3601 in descseq in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_3486(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3486,NULL,3,t0,t1,t2);}
t3=C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep(C_fixnum_greater_or_equal_p(t2,C_fix(40)))){
t4=C_fixnum_difference(((C_word*)t0)[2],t2);
/* csi.scm:587: fprintf */
t5=*((C_word*)lf[162]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,((C_word*)t0)[3],lf[163],t4);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3509,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t5=C_fixnum_plus(((C_word*)t0)[4],t2);
/* csi.scm:589: pref */
t6=((C_word*)t0)[6];
((C_proc4)C_fast_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[7],t5);}}}

/* k3479 in k3601 in descseq in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_3481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3481,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3486,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_3486(t5,((C_word*)t0)[7],C_fix(0));}

/* k5916 in doloop1370 in k5874 in k5871 in k5868 in k5865 in k5862 in k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in ... */
static void C_ccall f_5918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_5881(t3,((C_word*)t0)[4],t2);}

/* descseq in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_3474(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3474,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3603,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* csi.scm:582: plen */
t7=t3;
((C_proc3)C_fast_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[3]);}

/* k3211 in k3159 in k3156 in k3139 in k3136 in k3133 in a3130 in k3127 in report in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in ... */
static void C_ccall f_3213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3213,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3216,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3241,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* csi.scm:518: machine-type */
t4=C_fast_retrieve(lf[149]);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5744 in k5719 in k6157 in k5868 in k5865 in k5862 in k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in ... */
static void C_ccall f_5746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:1025: string-append */
t2=*((C_word*)lf[37]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,lf[314],lf[0]);}

/* k3214 in k3211 in k3159 in k3156 in k3139 in k3136 in k3133 in a3130 in k3127 in report in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in ... */
static void C_ccall f_3216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3216,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3219,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:536: ##sys#write-char-0 */
((C_proc4)C_fast_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t2,C_make_character(10),*((C_word*)lf[52]+1));}

/* k3217 in k3214 in k3211 in k3159 in k3156 in k3139 in k3136 in k3133 in a3130 in k3127 in report in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in ... */
static void C_ccall f_3219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3219,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3222,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_fudge(C_fix(14)))){
/* csi.scm:537: display */
t3=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[134]);}
else{
t3=t2;
f_3222(2,t3,C_SCHEME_UNDEFINED);}}

/* evalstring in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in ... */
static void C_fcall f_5752(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5752,NULL,3,t1,t2,t3);}
t4=C_i_nullp(t3);
t5=(C_truep(t4)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5799,tmp=(C_word)a,a+=2,tmp):C_i_car(t3));
t6=t5;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5759,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1029: open-input-string */
t8=C_fast_retrieve(lf[281]);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k5757 in evalstring in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in ... */
static void C_ccall f_5759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5759,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5766,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:1030: read */
t4=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* for-each-loop931 in doloop917 in a5200 in k5166 in k2821 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_5342(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5342,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5352,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
/* csi.scm:898: g932 */
t9=((C_word*)t0)[3];
f_5257(t9,t6,t7,t8);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k5338 in k5331 in doloop917 in a5200 in k5166 in k2821 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_5340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:911: fail */
t2=((C_word*)t0)[2];
f_5204(t2,((C_word*)t0)[3],t1);}

/* k5719 in k6157 in k5868 in k5865 in k5862 in k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in ... */
static void C_ccall f_5721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5721,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_i_string_equal_p(t1,lf[313]))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5733,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5746,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1025: chop-separator */
t4=C_fast_retrieve(lf[30]);
f_1992(3,t4,t3,t1);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* doloop737 in hexdump in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_4656(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4656,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4666,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4824,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:777: justify */
f_4626(t4,t2,C_fix(4),C_fix(10),C_make_character(32));}}

/* k5179 in compare in k5166 in k2821 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_5181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_string_equal_p(((C_word*)t0)[3],t1));}

/* k5731 in k5719 in k6157 in k5868 in k5865 in k5862 in k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in ... */
static void C_ccall f_5733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5733,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5739,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1026: file-exists? */
t4=C_fast_retrieve(lf[33]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k5737 in k5731 in k5719 in k6157 in k5868 in k5865 in k5862 in k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in ... */
static void C_ccall f_5739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* csi.scm:1027: load */
t2=C_fast_retrieve(lf[89]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2998 in k2978 in k6657 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_3000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3000,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3003,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:460: g372 */
t3=t1;
((C_proc2)C_fast_retrieve_proc(t3))(2,t3,t2);}

/* k3001 in k2998 in k2978 in k6657 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_3003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3003,2,t0,t1);}
t2=C_i_check_list_2(t1,lf[239]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3011,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_3011(t6,((C_word*)t0)[4],t1);}

/* k6417 in for-each-loop1253 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in ... */
static void C_ccall f_6419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6409(t3,((C_word*)t0)[4],t2);}

/* k4667 in k4664 in doloop737 in hexdump in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_4669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4672,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4741,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_4741(t6,t2,C_fix(0),((C_word*)t0)[2]);}

/* k4664 in doloop737 in hexdump in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_4666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4669,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* write-char/port */
t3=C_fast_retrieve(lf[257]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(58),((C_word*)t0)[5]);}

/* k3076 in a3069 in a3063 in a3045 in k2978 in k6657 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in ... */
static void C_ccall f_3078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3078,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3080,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3080(t5,((C_word*)t0)[3],t1,C_SCHEME_END_OF_LIST);}

/* k5703 in g1219 in loop in collect-options in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in ... */
static void C_ccall f_5705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5705,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* loop-print in k3854 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_3865(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3865,NULL,4,t0,t1,t2,t3);}
t4=C_i_not_pair_p(t2);
t5=(C_truep(t4)?t4:C_i_nullp(t2));
if(C_truep(t5)){
/* csi.scm:654: printf */
t6=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,lf[200]);}
else{
t6=C_i_car(t2);
if(C_truep(C_i_memq(t6,t3))){
/* csi.scm:656: fprintf */
t7=*((C_word*)lf[162]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,((C_word*)t0)[2],lf[201]);}
else{
t7=t2;
t8=C_u_i_car(t7);
if(C_truep(C_i_memq(t8,t3))){
t9=C_SCHEME_UNDEFINED;
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3896,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t10=t2;
t11=C_u_i_car(t10);
/* csi.scm:658: fprintf */
t12=*((C_word*)lf[162]+1);
((C_proc5)(void*)(*((C_word*)t12+1)))(5,t12,t9,((C_word*)t0)[2],lf[202],t11);}}}}

/* for-each-loop1253 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in ... */
static void C_fcall f_6409(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6409,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6419,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:1054: g1254 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* a3069 in a3063 in a3045 in k2978 in k6657 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 in ... */
static void C_ccall f_3070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3070,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3078,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:461: read */
t3=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4673 in k4670 in k4667 in k4664 in doloop737 in hexdump in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_4675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4678,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4690,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_4690(t6,t2,C_fix(0),((C_word*)t0)[2]);}

/* k4676 in k4673 in k4670 in k4667 in k4664 in doloop737 in hexdump in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 in ... */
static void C_ccall f_4678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4681,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=C_fast_retrieve(lf[257]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[5]);}

/* k5331 in doloop917 in a5200 in k5166 in k2821 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_5333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5340,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:911: ##sys#string-append */
((C_proc4)C_fast_retrieve_symbol_proc(lf[34]))(4,*((C_word*)lf[34]+1),t2,lf[116],((C_word*)t0)[4]);}

/* csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2402(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2402,3,t0,t1,t2);}
if(C_truep(C_eofp(t2))){
/* csi.scm:308: exit */
t3=C_fast_retrieve(lf[74]);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2418,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
if(C_truep(C_i_pairp(t2))){
t4=C_slot(t2,C_fix(0));
t5=t3;
f_2418(t5,C_eqp(lf[124],t4));}
else{
t4=t3;
f_2418(t4,C_SCHEME_FALSE);}}}

/* a4281 in loop in k4243 in g618 in k4238 in k4110 in k3996 in k3968 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in ... */
static void C_ccall f_4282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4282,2,t0,t1);}
t2=C_i_cdar(((C_word*)t0)[2]);
t3=C_i_cadr(((C_word*)t0)[2]);
/* csi.scm:722: fprintf */
t4=*((C_word*)lf[162]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,((C_word*)t0)[3],lf[236],t2,t3);}

/* k4670 in k4667 in k4664 in doloop737 in hexdump in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_4672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4672,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* write-char/port */
t3=C_fast_retrieve(lf[257]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[5]);}

/* k6190 in k5862 in k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in ... */
static void C_ccall f_6192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6192,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6195,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
/* csi.scm:1078: symbol-escape */
t3=C_fast_retrieve(lf[317]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
/* csi.scm:1077: display */
t3=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[323]);}}
else{
t2=((C_word*)t0)[2];
f_5867(2,t2,C_SCHEME_UNDEFINED);}}

/* k6193 in k6190 in k5862 in k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in ... */
static void C_ccall f_6195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:1078: symbol-escape */
t2=C_fast_retrieve(lf[317]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k4679 in k4676 in k4673 in k4670 in k4667 in k4664 in doloop737 in hexdump in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in ... */
static void C_ccall f_4681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(16));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4656(t3,((C_word*)t0)[4],t2);}

/* compare in k5166 in k2821 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_5170(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5170,NULL,3,t0,t1,t2);}
t3=C_slot(t2,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5181,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=C_i_string_length(((C_word*)t0)[2]);
t6=C_i_string_length(t3);
t7=C_i_fixnum_min(t5,t6);
/* csi.scm:882: substring */
t8=*((C_word*)lf[31]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t4,t3,C_fix(0),t7);}

/* map-loop348 in k3001 in k2998 in k2978 in k6657 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 in ... */
static void C_fcall f_3011(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3011,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3040,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
if(C_truep(C_i_stringp(t6))){
t7=t5;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2991,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:457: open-output-string */
t8=C_fast_retrieve(lf[367]);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6178 in k6175 in k6172 in k6169 in k5865 in k5862 in k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in k5666 in ... */
static void C_ccall f_6180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6183,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1083: parentheses-synonyms */
t3=C_fast_retrieve(lf[318]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_SCHEME_FALSE);}

/* k6181 in k6178 in k6175 in k6172 in k6169 in k5865 in k5862 in k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in ... */
static void C_ccall f_6183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:1084: symbol-escape */
t2=C_fast_retrieve(lf[317]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k6465 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in ... */
static void C_ccall f_6467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:1043: exit */
t2=C_fast_retrieve(lf[74]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* a3045 in k2978 in k6657 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_3046(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3046,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3052,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3064,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:460: with-exception-handler */
t5=C_fast_retrieve(lf[370]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* doloop763 in k4673 in k4670 in k4667 in k4664 in doloop737 in hexdump in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 in ... */
static void C_fcall f_4690(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4690,NULL,4,t0,t1,t2,t3);}
t4=C_fixnum_greater_or_equal_p(t2,C_fix(16));
t5=(C_truep(t4)?t4:C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[2]));
if(C_truep(t5)){
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4703,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* csi.scm:794: ref */
t7=((C_word*)t0)[5];
((C_proc4)C_fast_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[6],t3);}}

/* k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in ... */
static void C_ccall f_5659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5659,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5662,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=t2;
f_5662(t3,((C_word*)t0)[4]);}
else{
if(C_truep(t1)){
t3=t1;
t4=t2;
f_5662(t4,t3);}
else{
t3=t2;
f_5662(t3,((C_word*)t0)[6]);}}}

/* k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in ... */
static void C_fcall f_5656(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5656,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5659,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm:1008: member* */
f_5403(t3,lf[355],((C_word*)((C_word*)t0)[2])[1]);}

/* k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in ... */
static void C_ccall f_5653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5653,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5656,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=t3;
f_5656(t4,((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6544,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1007: member* */
f_5403(t4,lf[356],((C_word*)((C_word*)t0)[2])[1]);}}

/* k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 in ... */
static void C_fcall f_5650(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5650,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5653,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:1006: member* */
f_5403(t2,lf[357],((C_word*)((C_word*)t0)[2])[1]);}

/* k3038 in map-loop348 in k3001 in k2998 in k2978 in k6657 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in ... */
static void C_ccall f_3040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3040,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3011(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3011(t6,((C_word*)t0)[5],t5);}}

/* k6452 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in ... */
static void C_ccall f_6454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6454,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6457,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=C_set_block_item(lf[344] /* ##sys#warnings-enabled */,0,C_SCHEME_FALSE);
t4=((C_word*)t0)[2];
f_5821(t4,t3);}
else{
/* csi.scm:1045: display */
t3=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[345]);}}
else{
t2=((C_word*)t0)[2];
f_5821(t2,C_SCHEME_UNDEFINED);}}

/* k6455 in k6452 in k5816 in k5813 in k5810 in k5807 in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in ... */
static void C_ccall f_6457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[344] /* ##sys#warnings-enabled */,0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_5821(t3,t2);}

/* k4317 in for-each-loop617 in k4238 in k4110 in k3996 in k3968 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in ... */
static void C_ccall f_4319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4309(t3,((C_word*)t0)[4],t2);}

/* k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in ... */
static void C_ccall f_5668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5668,2,t0,t1);}
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5670,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5752,tmp=(C_word)a,a+=2,tmp));
t9=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5809,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t2,a[11]=t4,tmp=(C_word)a,a+=12,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6490,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1033: member* */
f_5403(t10,lf[351],((C_word*)((C_word*)t0)[2])[1]);}

/* k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in ... */
static void C_ccall f_5665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5665,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5668,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6498,a[2]=((C_word*)t0)[9],a[3]=t4,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_6498(t6,t2,t1);}

/* k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in ... */
static void C_fcall f_5662(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5662,NULL,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_fast_retrieve(lf[30]);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5665,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=t6,a[10]=t4,a[11]=t7,tmp=(C_word)a,a+=12,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6535,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1012: get-environment-variable */
t10=C_fast_retrieve(lf[43]);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,lf[354]);}

/* k4344 in k4110 in k3996 in k3968 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in ... */
static void C_ccall f_4346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4346,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4350,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:727: g647 */
t3=t2;
f_4350(t3,((C_word*)t0)[4],t1);}
else{
t2=C_i_assq(((C_word*)t0)[5],C_retrieve2(lf[156],"##csi#bytevector-data"));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4364,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:727: g658 */
t4=t3;
f_4364(t4,((C_word*)t0)[4],t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4427,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=C_slot(((C_word*)t0)[2],C_fix(0));
/* csi.scm:733: fprintf */
t5=*((C_word*)lf[162]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,((C_word*)t0)[3],lf[241],t4);}}}

/* k5519 in k5498 in k5484 in loop in canonicalize-args in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_5521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5521,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5525,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* csi.scm:962: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5464(t6,t3,t5);}

/* k5523 in k5519 in k5498 in k5484 in loop in canonicalize-args in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 in ... */
static void C_ccall f_5525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:962: append */
t2=*((C_word*)lf[240]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* map-loop1075 in k5498 in k5484 in loop in canonicalize-args in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_5529(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5529,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_string(&a,2,C_make_character(45),t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* loop in collect-options in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in ... */
static void C_fcall f_5676(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5676,NULL,3,t0,t1,t2);}
t3=C_i_member(((C_word*)t0)[2],t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5684,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1006: g1219 */
t5=t4;
f_5684(t5,t1,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* k4104 in k3996 in k3968 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 in ... */
static void C_ccall f_4106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:689: fprintf */
t2=*((C_word*)lf[162]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[223],t1);}

/* collect-options in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in ... */
static void C_fcall f_5670(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5670,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5676,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_5676(t6,t1,((C_word*)((C_word*)t0)[2])[1]);}

/* a3063 in a3045 in k2978 in k6657 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_3064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3064,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3070,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3103,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:460: ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* k5945 in doloop1370 in k5874 in k5871 in k5868 in k5865 in k5862 in k5859 in k5856 in k5852 in k5846 in k5843 in k5837 in k5834 in k5828 in k5825 in k5822 in k5819 in k5816 in k5813 in k5810 in k5807 in ... */
static void C_ccall f_5947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=((C_word*)((C_word*)t0)[2])[1];
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_u_i_cdr(t2));
t4=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t5=((C_word*)((C_word*)t0)[3])[1];
f_5881(t5,((C_word*)t0)[4],t4);}

/* a3057 in a3051 in a3045 in k2978 in k6657 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 in ... */
static void C_ccall f_3058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3058,2,t0,t1);}
/* csi.scm:460: ##sys#error */
t2=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[368],((C_word*)t0)[2]);}

/* g1219 in loop in collect-options in k5666 in k5663 in k5660 in k5657 in k5654 in k5651 in k5648 in k5645 in k5642 in k5639 in k5636 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in ... */
static void C_fcall f_5684(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5684,NULL,3,t0,t1,t2);}
t3=C_i_cdr(t2);
if(C_truep(C_i_nullp(t3))){
/* csi.scm:1019: ##sys#error */
t4=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,lf[279],((C_word*)t0)[2]);}
else{
t4=C_i_cadr(t2);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5705,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=t2;
t8=C_u_i_cdr(t7);
t9=C_u_i_cdr(t8);
/* csi.scm:1020: loop */
t10=((C_word*)((C_word*)t0)[3])[1];
f_5676(t10,t6,t9);}}

/* a3051 in a3045 in k2978 in k6657 in run in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_3052(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3052,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3058,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:460: k368 */
t4=((C_word*)t0)[3];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t1,t3);}

/* k5498 in k5484 in loop in canonicalize-args in k5396 in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_5500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5608,tmp=(C_word)a,a+=2,tmp);
t3=f_5608(t1);
if(C_truep(t3)){
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_i_check_list_2(t1,lf[239]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5521,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5529,a[2]=t7,a[3]=t11,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_5529(t13,t9,t1);}
else{
/* csi.scm:963: ##sys#error */
t4=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],lf[275],((C_word*)t0)[5]);}}

/* a2608 in g261 in k2600 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2609(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2609,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2613,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:350: pretty-print */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* g261 in k2600 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_2603(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2603,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2609,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:350: g276 */
t4=((C_word*)t0)[3];
((C_proc5)C_fast_retrieve_proc(t4))(5,t4,t1,t2,lf[93],t3);}

/* k5109 in k2808 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_5111(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_truep(t1)){
/* csi.scm:857: display */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[110]);}
else{
t2=C_i_length(C_fast_retrieve(lf[111]));
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=C_fixnum_difference(t2,t3);
t5=C_i_list_ref(C_fast_retrieve(lf[111]),t4);
t6=C_mutate2(&lf[7] /* (set! selected-frame ...) */,t5);
/* csi.scm:863: show-frameinfo */
f_4826(((C_word*)t0)[2],C_retrieve2(lf[7],"selected-frame"));}}

/* k2600 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2602,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2603,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_check_list_2(t1,lf[94]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2622,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2627,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_2627(t8,t4,t1);}

/* k4110 in k3996 in k3968 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 in ... */
static void C_ccall f_4112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4112,2,t0,t1);}
if(C_truep(t1)){
t2=C_block_size(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4118,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:692: fprintf */
t5=*((C_word*)lf[162]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[4],lf[226],t3);}
else{
if(C_truep(C_lambdainfop(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4131,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:695: ##sys#lambda-info->string */
((C_proc3)C_fast_retrieve_symbol_proc(lf[228]))(3,*((C_word*)lf[228]+1),t2,((C_word*)t0)[2]);}
else{
if(C_truep(C_i_structurep(((C_word*)t0)[2],lf[229]))){
t2=C_slot(((C_word*)t0)[2],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4143,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=C_eqp(t2,C_fix(1));
t5=(C_truep(t4)?lf[232]:lf[233]);
t6=C_slot(((C_word*)t0)[2],C_fix(3));
/* csi.scm:698: fprintf */
t7=*((C_word*)lf[162]+1);
((C_proc7)(void*)(*((C_word*)t7+1)))(7,t7,t3,((C_word*)t0)[4],lf[234],t2,t5,t6);}
else{
if(C_truep(C_i_structurep(((C_word*)t0)[2],lf[235]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4240,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=C_slot(((C_word*)t0)[2],C_fix(1));
/* csi.scm:712: fprintf */
t4=*((C_word*)lf[162]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[4],lf[238],t3);}
else{
if(C_truep(C_structurep(((C_word*)t0)[2]))){
t2=C_slot(((C_word*)t0)[2],C_fix(0));
t3=t2;
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4346,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csi.scm:728: ##sys#hash-table-ref */
((C_proc4)C_fast_retrieve_symbol_proc(lf[242]))(4,*((C_word*)lf[242]+1),t4,C_retrieve2(lf[158],"describer-table"),t3);}
else{
/* csi.scm:735: fprintf */
t2=*((C_word*)lf[162]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[4],lf[243]);}}}}}}

/* k4116 in k4110 in k3996 in k3968 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in ... */
static void C_ccall f_4118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:693: hexdump */
t2=C_fast_retrieve(lf[224]);
f_4623(6,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],*((C_word*)lf[225]+1),((C_word*)t0)[5]);}

/* g181 in toplevel-command in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static C_word C_fcall f_2372(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_overflow_check;
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
return(C_i_set_cdr(t1,t2));}

/* k4701 in doloop763 in k4673 in k4670 in k4667 in k4664 in doloop737 in hexdump in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in ... */
static void C_ccall f_4703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4703,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4706,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_fixnum_greater_or_equal_p(t1,C_fix(32));
t4=(C_truep(t3)?C_fixnum_lessp(t1,C_fix(128)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_make_character(C_unfix(t1));
/* write-char/port */
t6=C_fast_retrieve(lf[257]);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t2,t5,((C_word*)t0)[6]);}
else{
/* write-char/port */
t5=C_fast_retrieve(lf[257]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,C_make_character(46),((C_word*)t0)[6]);}}

/* k4704 in k4701 in doloop763 in k4673 in k4670 in k4667 in k4664 in doloop737 in hexdump in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in ... */
static void C_ccall f_4706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_4690(t4,((C_word*)t0)[5],t2,t3);}

/* k5166 in k2821 in k2416 in csi-eval in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_5168(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5168,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5170,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5201,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:884: call/cc */
t5=*((C_word*)lf[117]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,((C_word*)t0)[3],t4);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[48]+1));}}

/* k4144 in k4141 in k4110 in k3996 in k3968 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in ... */
static void C_ccall f_4146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4146,2,t0,t1);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=t2;
t4=C_block_size(t3);
t5=t4;
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4157,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_4157(t9,((C_word*)t0)[4],C_fix(0));}

/* k4141 in k4110 in k3996 in k3968 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in ... */
static void C_ccall f_4143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4143,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4146,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_slot(((C_word*)t0)[2],C_fix(4));
/* csi.scm:700: fprintf */
t4=*((C_word*)lf[162]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[3],lf[231],t3);}

/* toplevel-command in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2352(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_2352r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2352r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2352r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(12);
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_car(t4));
t7=t6;
t8=C_i_check_symbol_2(t2,lf[66]);
t9=(C_truep(t7)?C_i_check_string_2(t7,lf[66]):C_SCHEME_UNDEFINED);
t10=C_i_assq(t2,C_retrieve2(lf[65],"command-table"));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2372,a[2]=t3,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t12=f_2372(C_a_i(&a,6),t11,t10);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,*((C_word*)lf[48]+1));}
else{
t11=C_a_i_list3(&a,3,t2,t3,t7);
t12=C_a_i_cons(&a,2,t11,C_retrieve2(lf[65],"command-table"));
t13=C_mutate2(&lf[65] /* (set! command-table ...) */,t12);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,*((C_word*)lf[48]+1));}}

/* g596 in doloop590 in k4144 in k4141 in k4110 in k3996 in k3968 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in ... */
static void C_fcall f_4165(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4165,NULL,3,t0,t1,t2);}
t3=C_slot(t2,C_fix(0));
t4=C_slot(t2,C_fix(1));
/* csi.scm:708: fprintf */
t5=*((C_word*)lf[162]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,((C_word*)t0)[2],lf[230],t3,t4);}

/* doloop590 in k4144 in k4141 in k4110 in k3996 in k3968 in k3851 in k3739 in k3604 in describe in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in ... */
static void C_fcall f_4157(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4157,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4165,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=C_slot(((C_word*)t0)[4],t2);
t5=C_i_check_list_2(t4,lf[94]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4186,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4195,a[2]=t8,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_4195(t10,t6,t4);}}

/* doloop747 in k4667 in k4664 in doloop737 in hexdump in k3464 in k3118 in k3115 in k2972 in k2322 in k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_fcall f_4741(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4741,NULL,4,t0,t1,t2,t3);}
t4=C_fixnum_greater_or_equal_p(t2,C_fix(16));
t5=(C_truep(t4)?t4:C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[2]));
if(C_truep(t5)){
if(C_truep(C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[2]))){
t6=C_fixnum_modulo(((C_word*)t0)[2],C_fix(16));
t7=C_eqp(t6,C_fix(0));
if(C_truep(t7)){
t8=C_SCHEME_UNDEFINED;
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=C_fixnum_difference(C_fix(16),t6);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4775,a[2]=t10,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t12=((C_word*)t10)[1];
f_4775(t12,t1,t8);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}
else{
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4795,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* write-char/port */
t7=C_fast_retrieve(lf[257]);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_make_character(32),((C_word*)t0)[3]);}}

/* k2021 in k1890 in k1887 in k1882 in k1869 in k1866 in k1863 in k1860 in k1857 in k1854 */
static void C_ccall f_2023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2023,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2042,tmp=(C_word)a,a+=2,tmp);
t4=C_mutate2((C_word*)lf[36]+1 /* (set! ##csi#lookup-script-file ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2093,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t5=C_SCHEME_UNDEFINED;
t6=C_a_i_vector(&a,32,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5);
t7=C_mutate2((C_word*)lf[45]+1 /* (set! ##csi#history-list ...) */,t6);
t8=C_set_block_item(lf[25] /* ##csi#history-count */,0,C_fix(1));
t9=C_fast_retrieve(lf[46]);
t10=C_mutate2((C_word*)lf[47]+1 /* (set! ##csi#history-add ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2200,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t11=C_mutate2((C_word*)lf[49]+1 /* (set! ##csi#history-clear ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2239,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate2((C_word*)lf[51]+1 /* (set! ##csi#history-show ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2249,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate2((C_word*)lf[26]+1 /* (set! ##csi#history-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2299,tmp=(C_word)a,a+=2,tmp));
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2324,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6858,tmp=(C_word)a,a+=2,tmp);
/* csi.scm:261: repl-prompt */
t16=C_fast_retrieve(lf[401]);
((C_proc3)(void*)(*((C_word*)t16+1)))(3,t16,t14,t15);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[506] = {
{"f_2578:csi_2escm",(void*)f_2578},
{"f_6535:csi_2escm",(void*)f_6535},
{"f_6553:csi_2escm",(void*)f_6553},
{"f_6559:csi_2escm",(void*)f_6559},
{"f_6556:csi_2escm",(void*)f_6556},
{"f_6550:csi_2escm",(void*)f_6550},
{"f_5785:csi_2escm",(void*)f_5785},
{"f_5789:csi_2escm",(void*)f_5789},
{"f_2568:csi_2escm",(void*)f_2568},
{"f_2563:csi_2escm",(void*)f_2563},
{"f_2560:csi_2escm",(void*)f_2560},
{"f_6544:csi_2escm",(void*)f_6544},
{"f_5799:csi_2escm",(void*)f_5799},
{"f_5791:csi_2escm",(void*)f_5791},
{"f_4526:csi_2escm",(void*)f_4526},
{"f_6562:csi_2escm",(void*)f_6562},
{"f_2593:csi_2escm",(void*)f_2593},
{"f_2239:csi_2escm",(void*)f_2239},
{"f_5976:csi_2escm",(void*)f_5976},
{"f_2249:csi_2escm",(void*)f_2249},
{"f_4545:csi_2escm",(void*)f_4545},
{"f_6085:csi_2escm",(void*)f_6085},
{"f_6089:csi_2escm",(void*)f_6089},
{"f_3436:csi_2escm",(void*)f_3436},
{"f_2210:csi_2escm",(void*)f_2210},
{"f_2980:csi_2escm",(void*)f_2980},
{"f_2224:csi_2escm",(void*)f_2224},
{"f_6527:csi_2escm",(void*)f_6527},
{"f_2277:csi_2escm",(void*)f_2277},
{"f_2274:csi_2escm",(void*)f_2274},
{"f_2271:csi_2escm",(void*)f_2271},
{"f_2888:csi_2escm",(void*)f_2888},
{"f_6095:csi_2escm",(void*)f_6095},
{"f_6098:csi_2escm",(void*)f_6098},
{"f_2255:csi_2escm",(void*)f_2255},
{"f_2268:csi_2escm",(void*)f_2268},
{"f_2878:csi_2escm",(void*)f_2878},
{"f_2873:csi_2escm",(void*)f_2873},
{"f_3896:csi_2escm",(void*)f_3896},
{"f_6275:csi_2escm",(void*)f_6275},
{"f_6271:csi_2escm",(void*)f_6271},
{"f_2435:csi_2escm",(void*)f_2435},
{"f_5352:csi_2escm",(void*)f_5352},
{"f_6832:csi_2escm",(void*)f_6832},
{"f_2803:csi_2escm",(void*)f_2803},
{"f_2118:csi_2escm",(void*)f_2118},
{"f_2418:csi_2escm",(void*)f_2418},
{"f_4898:csi_2escm",(void*)f_4898},
{"f_2810:csi_2escm",(void*)f_2810},
{"f_5766:csi_2escm",(void*)f_5766},
{"f_5768:csi_2escm",(void*)f_5768},
{"f_6710:csi_2escm",(void*)f_6710},
{"f_2637:csi_2escm",(void*)f_2637},
{"f_6293:csi_2escm",(void*)f_6293},
{"f_5778:csi_2escm",(void*)f_5778},
{"f_6291:csi_2escm",(void*)f_6291},
{"f_6285:csi_2escm",(void*)f_6285},
{"f_6281:csi_2escm",(void*)f_6281},
{"f_2851:csi_2escm",(void*)f_2851},
{"f_6738:csi_2escm",(void*)f_6738},
{"f_6730:csi_2escm",(void*)f_6730},
{"f_3757:csi_2escm",(void*)f_3757},
{"f_6493:csi_2escm",(void*)f_6493},
{"f_2613:csi_2escm",(void*)f_2613},
{"f_6490:csi_2escm",(void*)f_6490},
{"f_6498:csi_2escm",(void*)f_6498},
{"f_5577:csi_2escm",(void*)f_5577},
{"f_2627:csi_2escm",(void*)f_2627},
{"f_3741:csi_2escm",(void*)f_3741},
{"f_6655:csi_2escm",(void*)f_6655},
{"f_3748:csi_2escm",(void*)f_3748},
{"f_6659:csi_2escm",(void*)f_6659},
{"f_2832:csi_2escm",(void*)f_2832},
{"f_6651:csi_2escm",(void*)f_6651},
{"f_6484:csi_2escm",(void*)f_6484},
{"f_2622:csi_2escm",(void*)f_2622},
{"f_3225:csi_2escm",(void*)f_3225},
{"f_3222:csi_2escm",(void*)f_3222},
{"f_1865:csi_2escm",(void*)f_1865},
{"f_1868:csi_2escm",(void*)f_1868},
{"f_1862:csi_2escm",(void*)f_1862},
{"f_2823:csi_2escm",(void*)f_2823},
{"f_6750:csi_2escm",(void*)f_6750},
{"f_6474:csi_2escm",(void*)f_6474},
{"f_3253:csi_2escm",(void*)f_3253},
{"f_1859:csi_2escm",(void*)f_1859},
{"f_1856:csi_2escm",(void*)f_1856},
{"f_2838:csi_2escm",(void*)f_2838},
{"f_2835:csi_2escm",(void*)f_2835},
{"f_4427:csi_2escm",(void*)f_4427},
{"f_3241:csi_2escm",(void*)f_3241},
{"f_1889:csi_2escm",(void*)f_1889},
{"f_1884:csi_2escm",(void*)f_1884},
{"f_3257:csi_2escm",(void*)f_3257},
{"f_4417:csi_2escm",(void*)f_4417},
{"f_3273:csi_2escm",(void*)f_3273},
{"f_1871:csi_2escm",(void*)f_1871},
{"f_3249:csi_2escm",(void*)f_3249},
{"f_5569:csi_2escm",(void*)f_5569},
{"f_5993:csi_2escm",(void*)f_5993},
{"f_3261:csi_2escm",(void*)f_3261},
{"f_5395:csi_2escm",(void*)f_5395},
{"f_5398:csi_2escm",(void*)f_5398},
{"f_6797:csi_2escm",(void*)f_6797},
{"f_6793:csi_2escm",(void*)f_6793},
{"f_5211:csi_2escm",(void*)f_5211},
{"f_5961:csi_2escm",(void*)f_5961},
{"f_1892:csi_2escm",(void*)f_1892},
{"f_1894:csi_2escm",(void*)f_1894},
{"f_1898:csi_2escm",(void*)f_1898},
{"f_3269:csi_2escm",(void*)f_3269},
{"f_3265:csi_2escm",(void*)f_3265},
{"f_5223:csi_2escm",(void*)f_5223},
{"f_6571:csi_2escm",(void*)f_6571},
{"f_2991:csi_2escm",(void*)f_2991},
{"f_2994:csi_2escm",(void*)f_2994},
{"f_3509:csi_2escm",(void*)f_3509},
{"f_4186:csi_2escm",(void*)f_4186},
{"f_2974:csi_2escm",(void*)f_2974},
{"f_4555:csi_2escm",(void*)f_4555},
{"f_4195:csi_2escm",(void*)f_4195},
{"f_3103:csi_2escm",(void*)f_3103},
{"f_4583:csi_2escm",(void*)f_4583},
{"f_3109:csi_2escm",(void*)f_3109},
{"f_4588:csi_2escm",(void*)f_4588},
{"f_3301:csi_2escm",(void*)f_3301},
{"f_3196:csi_2escm",(void*)f_3196},
{"f_3560:csi_2escm",(void*)f_3560},
{"f_4350:csi_2escm",(void*)f_4350},
{"f_5845:csi_2escm",(void*)f_5845},
{"f_5848:csi_2escm",(void*)f_5848},
{"f_6363:csi_2escm",(void*)f_6363},
{"f_4364:csi_2escm",(void*)f_4364},
{"f_3588:csi_2escm",(void*)f_3588},
{"f_4852:csi_2escm",(void*)f_4852},
{"f_5854:csi_2escm",(void*)f_5854},
{"f_5858:csi_2escm",(void*)f_5858},
{"f_4372:csi_2escm",(void*)f_4372},
{"f_6357:csi_2escm",(void*)f_6357},
{"f_4963:csi_2escm",(void*)f_4963},
{"f_4969:csi_2escm",(void*)f_4969},
{"f_4382:csi_2escm",(void*)f_4382},
{"f_4966:csi_2escm",(void*)f_4966},
{"f_5056:csi_2escm",(void*)f_5056},
{"f_4388:csi_2escm",(void*)f_4388},
{"f_2958:csi_2escm",(void*)f_2958},
{"f_5053:csi_2escm",(void*)f_5053},
{"f_2954:csi_2escm",(void*)f_2954},
{"f_4835:csi_2escm",(void*)f_4835},
{"f_4861:csi_2escm",(void*)f_4861},
{"f_4829:csi_2escm",(void*)f_4829},
{"f_4824:csi_2escm",(void*)f_4824},
{"f_4826:csi_2escm",(void*)f_4826},
{"f_5809:csi_2escm",(void*)f_5809},
{"f_2767:csi_2escm",(void*)f_2767},
{"f_5070:csi_2escm",(void*)f_5070},
{"f_4813:csi_2escm",(void*)f_4813},
{"f_4817:csi_2escm",(void*)f_4817},
{"f_3355:csi_2escm",(void*)f_3355},
{"f_5812:csi_2escm",(void*)f_5812},
{"f_3353:csi_2escm",(void*)f_3353},
{"f_5815:csi_2escm",(void*)f_5815},
{"f_5818:csi_2escm",(void*)f_5818},
{"f_3120:csi_2escm",(void*)f_3120},
{"f_3121:csi_2escm",(void*)f_3121},
{"f_5009:csi_2escm",(void*)f_5009},
{"f_3998:csi_2escm",(void*)f_3998},
{"f_3129:csi_2escm",(void*)f_3129},
{"f_4205:csi_2escm",(void*)f_4205},
{"f_2005:csi_2escm",(void*)f_2005},
{"f_5824:csi_2escm",(void*)f_5824},
{"f_3384:csi_2escm",(void*)f_3384},
{"f_5821:csi_2escm",(void*)f_5821},
{"f_2902:csi_2escm",(void*)f_2902},
{"f_5827:csi_2escm",(void*)f_5827},
{"f_4785:csi_2escm",(void*)f_4785},
{"f_5019:csi_2escm",(void*)f_5019},
{"f_3117:csi_2escm",(void*)f_3117},
{"f_4895:csi_2escm",(void*)f_4895},
{"f_4892:csi_2escm",(void*)f_4892},
{"f_5836:csi_2escm",(void*)f_5836},
{"f_5830:csi_2escm",(void*)f_5830},
{"f_5839:csi_2escm",(void*)f_5839},
{"f_3141:csi_2escm",(void*)f_3141},
{"f_3143:csi_2escm",(void*)f_3143},
{"f_5403:csi_2escm",(void*)f_5403},
{"f_5409:csi_2escm",(void*)f_5409},
{"f_4264:csi_2escm",(void*)f_4264},
{"f_3131:csi_2escm",(void*)f_3131},
{"f_3135:csi_2escm",(void*)f_3135},
{"f_3138:csi_2escm",(void*)f_3138},
{"f_2071:csi_2escm",(void*)f_2071},
{"f_3161:csi_2escm",(void*)f_3161},
{"f_3162:csi_2escm",(void*)f_3162},
{"f_2948:csi_2escm",(void*)f_2948},
{"f_4646:csi_2escm",(void*)f_4646},
{"f_4245:csi_2escm",(void*)f_4245},
{"f_3166:csi_2escm",(void*)f_3166},
{"f_4241:csi_2escm",(void*)f_4241},
{"f_2049:csi_2escm",(void*)f_2049},
{"f_4240:csi_2escm",(void*)f_4240},
{"f_2042:csi_2escm",(void*)f_2042},
{"f_3151:csi_2escm",(void*)f_3151},
{"f_4630:csi_2escm",(void*)f_4630},
{"f_3158:csi_2escm",(void*)f_3158},
{"f_4277:csi_2escm",(void*)f_4277},
{"f_2058:csi_2escm",(void*)f_2058},
{"f_2453:csi_2escm",(void*)f_2453},
{"f_2052:csi_2escm",(void*)f_2052},
{"f_2450:csi_2escm",(void*)f_2450},
{"f_3188:csi_2escm",(void*)f_3188},
{"f_4623:csi_2escm",(void*)f_4623},
{"f_4626:csi_2escm",(void*)f_4626},
{"f_2464:csi_2escm",(void*)f_2464},
{"f_2460:csi_2escm",(void*)f_2460},
{"f_6328:csi_2escm",(void*)f_6328},
{"f_6322:csi_2escm",(void*)f_6322},
{"f_3179:csi_2escm",(void*)f_3179},
{"f_4254:csi_2escm",(void*)f_4254},
{"f_3775:csi_2escm",(void*)f_3775},
{"f_5608:csi_2escm",(void*)f_5608},
{"f_2509:csi_2escm",(void*)f_2509},
{"f_2506:csi_2escm",(void*)f_2506},
{"f_1901:csi_2escm",(void*)f_1901},
{"f_1908:csi_2escm",(void*)f_1908},
{"f_2491:csi_2escm",(void*)f_2491},
{"f_2494:csi_2escm",(void*)f_2494},
{"f_3528:csi_2escm",(void*)f_3528},
{"f_2675:csi_2escm",(void*)f_2675},
{"f_2670:csi_2escm",(void*)f_2670},
{"f_5634:csi_2escm",(void*)f_5634},
{"f_5638:csi_2escm",(void*)f_5638},
{"f_2299:csi_2escm",(void*)f_2299},
{"f_6001:csi_2escm",(void*)f_6001},
{"f_3518:csi_2escm",(void*)f_3518},
{"f_2685:csi_2escm",(void*)f_2685},
{"f_2681:csi_2escm",(void*)f_2681},
{"f_6034:csi_2escm",(void*)f_6034},
{"f_2479:csi_2escm",(void*)f_2479},
{"f_5641:csi_2escm",(void*)f_5641},
{"f_2476:csi_2escm",(void*)f_2476},
{"f_5644:csi_2escm",(void*)f_5644},
{"f_5647:csi_2escm",(void*)f_5647},
{"f_2473:csi_2escm",(void*)f_2473},
{"f_2652:csi_2escm",(void*)f_2652},
{"f_5421:csi_2escm",(void*)f_5421},
{"f_6159:csi_2escm",(void*)f_6159},
{"f_3531:csi_2escm",(void*)f_3531},
{"f_2666:csi_2escm",(void*)f_2666},
{"f_2661:csi_2escm",(void*)f_2661},
{"f_4131:csi_2escm",(void*)f_4131},
{"f_6016:csi_2escm",(void*)f_6016},
{"f_4005:csi_2escm",(void*)f_4005},
{"f_1936:csi_2escm",(void*)f_1936},
{"f_6140:csi_2escm",(void*)f_6140},
{"f_1938:csi_2escm",(void*)f_1938},
{"f_6045:csi_2escm",(void*)f_6045},
{"f_6177:csi_2escm",(void*)f_6177},
{"f_6174:csi_2escm",(void*)f_6174},
{"f_6171:csi_2escm",(void*)f_6171},
{"f_3323:csi_2escm",(void*)f_3323},
{"f_3328:csi_2escm",(void*)f_3328},
{"toplevel:csi_2escm",(void*)C_toplevel},
{"f_2698:csi_2escm",(void*)f_2698},
{"f_2692:csi_2escm",(void*)f_2692},
{"f_2694:csi_2escm",(void*)f_2694},
{"f_6024:csi_2escm",(void*)f_6024},
{"f_6809:csi_2escm",(void*)f_6809},
{"f_5881:csi_2escm",(void*)f_5881},
{"f_6055:csi_2escm",(void*)f_6055},
{"f_6800:csi_2escm",(void*)f_6800},
{"f_6053:csi_2escm",(void*)f_6053},
{"f_6104:csi_2escm",(void*)f_6104},
{"f_6109:csi_2escm",(void*)f_6109},
{"f_6101:csi_2escm",(void*)f_6101},
{"f_5894:csi_2escm",(void*)f_5894},
{"f_3338:csi_2escm",(void*)f_3338},
{"f_5899:csi_2escm",(void*)f_5899},
{"f_1922:csi_2escm",(void*)f_1922},
{"f_1926:csi_2escm",(void*)f_1926},
{"f_1929:csi_2escm",(void*)f_1929},
{"f_6125:csi_2escm",(void*)f_6125},
{"f_6122:csi_2escm",(void*)f_6122},
{"f_6845:csi_2escm",(void*)f_6845},
{"f_2280:csi_2escm",(void*)f_2280},
{"f_6876:csi_2escm",(void*)f_6876},
{"f_4975:csi_2escm",(void*)f_4975},
{"f_4972:csi_2escm",(void*)f_4972},
{"f_2289:csi_2escm",(void*)f_2289},
{"f_2150:csi_2escm",(void*)f_2150},
{"f_6824:csi_2escm",(void*)f_6824},
{"f_6828:csi_2escm",(void*)f_6828},
{"f_2128:csi_2escm",(void*)f_2128},
{"f_2121:csi_2escm",(void*)f_2121},
{"f_6858:csi_2escm",(void*)f_6858},
{"f_6856:csi_2escm",(void*)f_6856},
{"f_2135:csi_2escm",(void*)f_2135},
{"f_2132:csi_2escm",(void*)f_2132},
{"f_6880:csi_2escm",(void*)f_6880},
{"f_2109:csi_2escm",(void*)f_2109},
{"f_6889:csi_2escm",(void*)f_6889},
{"f_2791:csi_2escm",(void*)f_2791},
{"f_6866:csi_2escm",(void*)f_6866},
{"f_6638:csi_2escm",(void*)f_6638},
{"f_3964:csi_2escm",(void*)f_3964},
{"f_2163:csi_2escm",(void*)f_2163},
{"f_2160:csi_2escm",(void*)f_2160},
{"f_3960:csi_2escm",(void*)f_3960},
{"f_6869:csi_2escm",(void*)f_6869},
{"f_2779:csi_2escm",(void*)f_2779},
{"f_4775:csi_2escm",(void*)f_4775},
{"f_2177:csi_2escm",(void*)f_2177},
{"f_6697:csi_2escm",(void*)f_6697},
{"f_2148:csi_2escm",(void*)f_2148},
{"f_2141:csi_2escm",(void*)f_2141},
{"f_3989:csi_2escm",(void*)f_3989},
{"f_6685:csi_2escm",(void*)f_6685},
{"f_2200:csi_2escm",(void*)f_2200},
{"f_4795:csi_2escm",(void*)f_4795},
{"f_6687:csi_2escm",(void*)f_6687},
{"f_6681:csi_2escm",(void*)f_6681},
{"f_4798:csi_2escm",(void*)f_4798},
{"f_3970:csi_2escm",(void*)f_3970},
{"f_6673:csi_2escm",(void*)f_6673},
{"f_6671:csi_2escm",(void*)f_6671},
{"f_6668:csi_2escm",(void*)f_6668},
{"f_6665:csi_2escm",(void*)f_6665},
{"f_2339:csi_2escm",(void*)f_2339},
{"f_3763:csi_2escm",(void*)f_3763},
{"f_3760:csi_2escm",(void*)f_3760},
{"f_2346:csi_2escm",(void*)f_2346},
{"f_3793:csi_2escm",(void*)f_3793},
{"f_4309:csi_2escm",(void*)f_4309},
{"f_3796:csi_2escm",(void*)f_3796},
{"f_6386:csi_2escm",(void*)f_6386},
{"f_3790:csi_2escm",(void*)f_3790},
{"f_6373:csi_2escm",(void*)f_6373},
{"f_3780:csi_2escm",(void*)f_3780},
{"f_5464:csi_2escm",(void*)f_5464},
{"f_2713:csi_2escm",(void*)f_2713},
{"f_5257:csi_2escm",(void*)f_5257},
{"f_2326:csi_2escm",(void*)f_2326},
{"f_2324:csi_2escm",(void*)f_2324},
{"f_4901:csi_2escm",(void*)f_4901},
{"f_4904:csi_2escm",(void*)f_4904},
{"f_4907:csi_2escm",(void*)f_4907},
{"f_3805:csi_2escm",(void*)f_3805},
{"f_5263:csi_2escm",(void*)f_5263},
{"f_6396:csi_2escm",(void*)f_6396},
{"f_5486:csi_2escm",(void*)f_5486},
{"f_5273:csi_2escm",(void*)f_5273},
{"f_5458:csi_2escm",(void*)f_5458},
{"f_2530:csi_2escm",(void*)f_2530},
{"f_5208:csi_2escm",(void*)f_5208},
{"f_5201:csi_2escm",(void*)f_5201},
{"f_5204:csi_2escm",(void*)f_5204},
{"f_2758:csi_2escm",(void*)f_2758},
{"f_4910:csi_2escm",(void*)f_4910},
{"f_4913:csi_2escm",(void*)f_4913},
{"f_3606:csi_2escm",(void*)f_3606},
{"f_3603:csi_2escm",(void*)f_3603},
{"f_4916:csi_2escm",(void*)f_4916},
{"f_4919:csi_2escm",(void*)f_4919},
{"f_2751:csi_2escm",(void*)f_2751},
{"f_5864:csi_2escm",(void*)f_5864},
{"f_5867:csi_2escm",(void*)f_5867},
{"f_5861:csi_2escm",(void*)f_5861},
{"f_5291:csi_2escm",(void*)f_5291},
{"f_5297:csi_2escm",(void*)f_5297},
{"f_5294:csi_2escm",(void*)f_5294},
{"f_4945:csi_2escm",(void*)f_4945},
{"f_3841:csi_2escm",(void*)f_3841},
{"f_3609:csi_2escm",(void*)f_3609},
{"f_3838:csi_2escm",(void*)f_3838},
{"f_5873:csi_2escm",(void*)f_5873},
{"f_5876:csi_2escm",(void*)f_5876},
{"f_5870:csi_2escm",(void*)f_5870},
{"f_4935:csi_2escm",(void*)f_4935},
{"f_2524:csi_2escm",(void*)f_2524},
{"f_2527:csi_2escm",(void*)f_2527},
{"f_4458:csi_2escm",(void*)f_4458},
{"f_2521:csi_2escm",(void*)f_2521},
{"f_2747:csi_2escm",(void*)f_2747},
{"f_4466:csi_2escm",(void*)f_4466},
{"f_1955:csi_2escm",(void*)f_1955},
{"f_5248:csi_2escm",(void*)f_5248},
{"f_4480:csi_2escm",(void*)f_4480},
{"f_4950:csi_2escm",(void*)f_4950},
{"f_3853:csi_2escm",(void*)f_3853},
{"f_3856:csi_2escm",(void*)f_3856},
{"f_4477:csi_2escm",(void*)f_4477},
{"f_4475:csi_2escm",(void*)f_4475},
{"f_2729:csi_2escm",(void*)f_2729},
{"f_1977:csi_2escm",(void*)f_1977},
{"f_1975:csi_2escm",(void*)f_1975},
{"f_3829:csi_2escm",(void*)f_3829},
{"f_4922:csi_2escm",(void*)f_4922},
{"f_1992:csi_2escm",(void*)f_1992},
{"f_3401:csi_2escm",(void*)f_3401},
{"f_5285:csi_2escm",(void*)f_5285},
{"f_5288:csi_2escm",(void*)f_5288},
{"f_6448:csi_2escm",(void*)f_6448},
{"f_3681:csi_2escm",(void*)f_3681},
{"f_6433:csi_2escm",(void*)f_6433},
{"f_6436:csi_2escm",(void*)f_6436},
{"f_6439:csi_2escm",(void*)f_6439},
{"f_1967:csi_2escm",(void*)f_1967},
{"f_3675:csi_2escm",(void*)f_3675},
{"f_2084:csi_2escm",(void*)f_2084},
{"f_6207:csi_2escm",(void*)f_6207},
{"f_6204:csi_2escm",(void*)f_6204},
{"f_3080:csi_2escm",(void*)f_3080},
{"f_2093:csi_2escm",(void*)f_2093},
{"f_2097:csi_2escm",(void*)f_2097},
{"f_3468:csi_2escm",(void*)f_3468},
{"f_3466:csi_2escm",(void*)f_3466},
{"f_4502:csi_2escm",(void*)f_4502},
{"f_4509:csi_2escm",(void*)f_4509},
{"f7552:csi_2escm",(void*)f7552},
{"f_5902:csi_2escm",(void*)f_5902},
{"f_3097:csi_2escm",(void*)f_3097},
{"f_3486:csi_2escm",(void*)f_3486},
{"f_3481:csi_2escm",(void*)f_3481},
{"f_5918:csi_2escm",(void*)f_5918},
{"f_3474:csi_2escm",(void*)f_3474},
{"f_3213:csi_2escm",(void*)f_3213},
{"f_5746:csi_2escm",(void*)f_5746},
{"f_3216:csi_2escm",(void*)f_3216},
{"f_3219:csi_2escm",(void*)f_3219},
{"f_5752:csi_2escm",(void*)f_5752},
{"f_5759:csi_2escm",(void*)f_5759},
{"f_5342:csi_2escm",(void*)f_5342},
{"f_5340:csi_2escm",(void*)f_5340},
{"f_5721:csi_2escm",(void*)f_5721},
{"f_4656:csi_2escm",(void*)f_4656},
{"f_5181:csi_2escm",(void*)f_5181},
{"f_5733:csi_2escm",(void*)f_5733},
{"f_5739:csi_2escm",(void*)f_5739},
{"f_3000:csi_2escm",(void*)f_3000},
{"f_3003:csi_2escm",(void*)f_3003},
{"f_6419:csi_2escm",(void*)f_6419},
{"f_4669:csi_2escm",(void*)f_4669},
{"f_4666:csi_2escm",(void*)f_4666},
{"f_3078:csi_2escm",(void*)f_3078},
{"f_5705:csi_2escm",(void*)f_5705},
{"f_3865:csi_2escm",(void*)f_3865},
{"f_6409:csi_2escm",(void*)f_6409},
{"f_3070:csi_2escm",(void*)f_3070},
{"f_4675:csi_2escm",(void*)f_4675},
{"f_4678:csi_2escm",(void*)f_4678},
{"f_5333:csi_2escm",(void*)f_5333},
{"f_2402:csi_2escm",(void*)f_2402},
{"f_4282:csi_2escm",(void*)f_4282},
{"f_4672:csi_2escm",(void*)f_4672},
{"f_6192:csi_2escm",(void*)f_6192},
{"f_6195:csi_2escm",(void*)f_6195},
{"f_4681:csi_2escm",(void*)f_4681},
{"f_5170:csi_2escm",(void*)f_5170},
{"f_3011:csi_2escm",(void*)f_3011},
{"f_6180:csi_2escm",(void*)f_6180},
{"f_6183:csi_2escm",(void*)f_6183},
{"f_6467:csi_2escm",(void*)f_6467},
{"f_3046:csi_2escm",(void*)f_3046},
{"f_4690:csi_2escm",(void*)f_4690},
{"f_5659:csi_2escm",(void*)f_5659},
{"f_5656:csi_2escm",(void*)f_5656},
{"f_5653:csi_2escm",(void*)f_5653},
{"f_5650:csi_2escm",(void*)f_5650},
{"f_3040:csi_2escm",(void*)f_3040},
{"f_6454:csi_2escm",(void*)f_6454},
{"f_6457:csi_2escm",(void*)f_6457},
{"f_4319:csi_2escm",(void*)f_4319},
{"f_5668:csi_2escm",(void*)f_5668},
{"f_5665:csi_2escm",(void*)f_5665},
{"f_5662:csi_2escm",(void*)f_5662},
{"f_4346:csi_2escm",(void*)f_4346},
{"f_5521:csi_2escm",(void*)f_5521},
{"f_5525:csi_2escm",(void*)f_5525},
{"f_5529:csi_2escm",(void*)f_5529},
{"f_5676:csi_2escm",(void*)f_5676},
{"f_4106:csi_2escm",(void*)f_4106},
{"f_5670:csi_2escm",(void*)f_5670},
{"f_3064:csi_2escm",(void*)f_3064},
{"f_5947:csi_2escm",(void*)f_5947},
{"f_3058:csi_2escm",(void*)f_3058},
{"f_5684:csi_2escm",(void*)f_5684},
{"f_3052:csi_2escm",(void*)f_3052},
{"f_5500:csi_2escm",(void*)f_5500},
{"f_2609:csi_2escm",(void*)f_2609},
{"f_2603:csi_2escm",(void*)f_2603},
{"f_5111:csi_2escm",(void*)f_5111},
{"f_2602:csi_2escm",(void*)f_2602},
{"f_4112:csi_2escm",(void*)f_4112},
{"f_4118:csi_2escm",(void*)f_4118},
{"f_2372:csi_2escm",(void*)f_2372},
{"f_4703:csi_2escm",(void*)f_4703},
{"f_4706:csi_2escm",(void*)f_4706},
{"f_5168:csi_2escm",(void*)f_5168},
{"f_4146:csi_2escm",(void*)f_4146},
{"f_4143:csi_2escm",(void*)f_4143},
{"f_2352:csi_2escm",(void*)f_2352},
{"f_4165:csi_2escm",(void*)f_4165},
{"f_4157:csi_2escm",(void*)f_4157},
{"f_4741:csi_2escm",(void*)f_4741},
{"f_2023:csi_2escm",(void*)f_2023},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  map		7
S|  for-each		11
S|  printf		4
o|eliminated procedure checks: 140 
o|eliminated procedure checks: 1 
o|specializations:
o|  7 (string=? string string)
o|  1 (set-cdr! pair *)
o|  2 (cddr (pair * pair))
o|  3 (cadr (pair * pair))
o|  1 (min fixnum fixnum)
o|  1 (memq * list)
o|  22 (cdr pair)
o|  1 (current-output-port)
o|  8 (car pair)
o|  2 (zero? fixnum)
o|  3 (##sys#check-list (or pair list) *)
o|  29 (eqv? * (not float))
o|  4 (##sys#check-output-port * * *)
o|  1 (> fixnum fixnum)
o|  4 (string-append string string)
o|  1 (make-string fixnum)
o|safe globals: (##sys#repl-print-length-limit constant22 constant17 constant14) 
o|Removed `not' forms: 8 
o|substituted constant variable: constant17 
o|substituted constant variable: constant14 
o|inlining procedure: k1940 
o|inlining procedure: k1940 
o|inlining procedure: k1982 
o|inlining procedure: k1982 
o|inlining procedure: k2000 
o|inlining procedure: k2000 
o|inlining procedure: k2044 
o|inlining procedure: k2044 
o|substituted constant variable: a2060 
o|inlining procedure: k2098 
o|inlining procedure: k2113 
o|contracted procedure: "(csi.scm:212) _getcwd74" 
o|inlining procedure: k2113 
o|inlining procedure: k2152 
o|inlining procedure: k2152 
o|substituted constant variable: a2183 
o|contracted procedure: "(csi.scm:211) string-index85" 
o|inlining procedure: k2073 
o|inlining procedure: k2073 
o|inlining procedure: k2098 
o|substituted constant variable: a2193 
o|inlining procedure: k2257 
o|propagated global variable: out137141 ##sys#standard-output 
o|substituted constant variable: a2264 
o|substituted constant variable: a2265 
o|inlining procedure: k2257 
o|propagated global variable: out137141 ##sys#standard-output 
o|inlining procedure: k2304 
o|inlining procedure: k2304 
o|inlining procedure: k2331 
o|inlining procedure: k2331 
o|inlining procedure: k2341 
o|inlining procedure: k2341 
o|inlining procedure: k2366 
o|inlining procedure: k2366 
o|inlining procedure: k2404 
o|inlining procedure: k2404 
o|inlining procedure: k2425 
o|contracted procedure: "(csi.scm:311) g213214" 
o|inlining procedure: k2425 
o|inlining procedure: k2465 
o|inlining procedure: k2465 
o|inlining procedure: k2498 
o|inlining procedure: k2498 
o|inlining procedure: k2534 
o|inlining procedure: k2534 
o|inlining procedure: k2552 
o|inlining procedure: k2570 
o|inlining procedure: k2570 
o|inlining procedure: k2552 
o|inlining procedure: k2629 
o|inlining procedure: k2629 
o|inlining procedure: k2653 
o|inlining procedure: k2653 
o|inlining procedure: k2708 
o|inlining procedure: k2708 
o|inlining procedure: k2721 
o|contracted procedure: k2733 
o|inlining procedure: k2721 
o|inlining procedure: k2771 
o|inlining procedure: k2771 
o|inlining procedure: k2795 
o|inlining procedure: k2795 
o|inlining procedure: k2824 
o|inlining procedure: k2824 
o|inlining procedure: k2880 
o|contracted procedure: "(csi.scm:410) g308315" 
o|inlining procedure: k2857 
o|inlining procedure: k2857 
o|inlining procedure: k2880 
o|propagated global variable: g314316 command-table 
o|substituted constant variable: a2907 
o|substituted constant variable: a2909 
o|substituted constant variable: a2911 
o|substituted constant variable: a2913 
o|substituted constant variable: a2915 
o|substituted constant variable: a2917 
o|substituted constant variable: a2919 
o|substituted constant variable: a2921 
o|substituted constant variable: a2923 
o|substituted constant variable: a2925 
o|substituted constant variable: a2927 
o|substituted constant variable: a2929 
o|substituted constant variable: a2931 
o|substituted constant variable: a2933 
o|substituted constant variable: a2935 
o|substituted constant variable: a2937 
o|substituted constant variable: a2939 
o|substituted constant variable: a2941 
o|substituted constant variable: a2943 
o|inlining procedure: k3180 
o|inlining procedure: k3180 
o|inlining procedure: k3223 
o|inlining procedure: k3223 
o|inlining procedure: k3330 
o|inlining procedure: k3330 
o|inlining procedure: k3357 
o|inlining procedure: k3357 
o|propagated global variable: g422426 ##sys#features 
o|inlining procedure: k3491 
o|inlining procedure: k3491 
o|inlining procedure: k3520 
o|inlining procedure: k3550 
o|inlining procedure: k3550 
o|inlining procedure: k3520 
o|inlining procedure: k3607 
o|inlining procedure: k3607 
o|inlining procedure: k3631 
o|inlining procedure: k3631 
o|inlining procedure: k3649 
o|inlining procedure: k3649 
o|inlining procedure: k3667 
o|inlining procedure: k3667 
o|inlining procedure: k3700 
o|inlining procedure: k3700 
o|inlining procedure: k3718 
o|inlining procedure: k3718 
o|inlining procedure: k3736 
o|inlining procedure: k3736 
o|inlining procedure: k3767 
o|inlining procedure: k3767 
o|inlining procedure: k3782 
o|inlining procedure: k3782 
o|inlining procedure: k3827 
o|inlining procedure: k3827 
o|inlining procedure: k3845 
o|inlining procedure: k3867 
o|inlining procedure: k3867 
o|contracted procedure: k3891 
o|inlining procedure: k3888 
o|inlining procedure: k3888 
o|inlining procedure: k3845 
o|inlining procedure: k3932 
o|inlining procedure: k3932 
o|inlining procedure: k3965 
o|inlining procedure: k3965 
o|inlining procedure: k4014 
o|inlining procedure: k4014 
o|inlining procedure: k4026 
o|inlining procedure: k4026 
o|inlining procedure: k4038 
o|inlining procedure: k4038 
o|inlining procedure: k4050 
o|inlining procedure: k4050 
o|inlining procedure: k4062 
o|inlining procedure: k4062 
o|substituted constant variable: a4075 
o|substituted constant variable: a4077 
o|substituted constant variable: a4079 
o|substituted constant variable: a4081 
o|substituted constant variable: a4083 
o|substituted constant variable: a4085 
o|substituted constant variable: a4087 
o|substituted constant variable: a4089 
o|substituted constant variable: a4091 
o|substituted constant variable: a4093 
o|inlining procedure: k4094 
o|inlining procedure: k4094 
o|inlining procedure: k4122 
o|inlining procedure: k4122 
o|inlining procedure: k4159 
o|inlining procedure: k4159 
o|inlining procedure: k4197 
o|inlining procedure: k4197 
o|inlining procedure: k4256 
o|inlining procedure: k4256 
o|inlining procedure: k4232 
o|inlining procedure: k4311 
o|inlining procedure: k4311 
o|inlining procedure: k4232 
o|inlining procedure: k4347 
o|inlining procedure: k4347 
o|inlining procedure: k4390 
o|inlining procedure: k4390 
o|contracted procedure: "(csi.scm:649) improper-pairs?" 
o|contracted procedure: k3441 
o|inlining procedure: k3438 
o|inlining procedure: k3438 
o|contracted procedure: "(csi.scm:649) circular-list?" 
o|inlining procedure: k3403 
o|inlining procedure: k3423 
o|inlining procedure: k3423 
o|inlining procedure: k3403 
o|inlining procedure: k4482 
o|inlining procedure: k4482 
o|inlining procedure: k4488 
o|inlining procedure: k4488 
o|inlining procedure: k4514 
o|inlining procedure: k4514 
o|inlining procedure: k4540 
o|inlining procedure: k4540 
o|contracted procedure: k4573 
o|inlining procedure: k4593 
o|inlining procedure: k4593 
o|inlining procedure: k4634 
o|inlining procedure: k4634 
o|inlining procedure: k4658 
o|inlining procedure: k4658 
o|inlining procedure: k4692 
o|inlining procedure: k4692 
o|inlining procedure: k4743 
o|inlining procedure: k4761 
o|inlining procedure: k4761 
o|inlining procedure: k4777 
o|inlining procedure: k4777 
o|inlining procedure: k4743 
o|inlining procedure: k4863 
o|propagated global variable: out809813 ##sys#standard-output 
o|substituted constant variable: a4888 
o|substituted constant variable: a4889 
o|inlining procedure: k4863 
o|inlining procedure: k4937 
o|inlining procedure: k4937 
o|inlining procedure: k4952 
o|propagated global variable: out851855 ##sys#standard-output 
o|substituted constant variable: a4959 
o|substituted constant variable: a4960 
o|inlining procedure: k4952 
o|propagated global variable: out851855 ##sys#standard-output 
o|inlining procedure: k5011 
o|inlining procedure: k5011 
o|propagated global variable: out822826 ##sys#standard-output 
o|substituted constant variable: a5049 
o|substituted constant variable: a5050 
o|propagated global variable: out822826 ##sys#standard-output 
o|inlining procedure: k5065 
o|inlining procedure: k5065 
o|inlining procedure: k5079 
o|propagated global variable: out809813 ##sys#standard-output 
o|inlining procedure: k5079 
o|inlining procedure: k5085 
o|inlining procedure: k5085 
o|propagated global variable: tmp790792 ##sys#repl-recent-call-chain 
o|propagated global variable: tmp790792 ##sys#repl-recent-call-chain 
o|inlining procedure: k5103 
o|inlining procedure: k5103 
o|inlining procedure: k5137 
o|inlining procedure: k5137 
o|inlining procedure: k5194 
o|inlining procedure: k5225 
o|inlining procedure: k5225 
o|inlining procedure: k5265 
o|inlining procedure: k5265 
o|inlining procedure: k5344 
o|inlining procedure: k5344 
o|inlining procedure: k5194 
o|inlining procedure: k5387 
o|inlining procedure: k5387 
o|propagated global variable: tmp903905 ##sys#repl-recent-call-chain 
o|propagated global variable: tmp903905 ##sys#repl-recent-call-chain 
o|inlining procedure: k5411 
o|inlining procedure: k5423 
o|inlining procedure: k5423 
o|inlining procedure: k5411 
o|inlining procedure: k5466 
o|inlining procedure: k5466 
o|inlining procedure: k5481 
o|inlining procedure: k5501 
o|inlining procedure: k5531 
o|contracted procedure: "(csi.scm:962) g10811090" 
o|inlining procedure: k5531 
o|inlining procedure: k5501 
o|contracted procedure: "(csi.scm:961) findall" 
o|substituted constant variable: constant1052 
o|inlining procedure: k5613 
o|inlining procedure: k5613 
o|inlining procedure: k5481 
o|inlining procedure: k5583 
o|substituted constant variable: constant1059 
o|inlining procedure: k5583 
o|inlining procedure: k5686 
o|inlining procedure: k5686 
o|inlining procedure: k5681 
o|inlining procedure: k5681 
o|merged explicitly consed rest parameter: tmp12291231 
o|inlining procedure: k5770 
o|inlining procedure: k5770 
o|inlining procedure: k5883 
o|inlining procedure: k5883 
o|inlining procedure: k5926 
o|inlining procedure: k5926 
o|substituted constant variable: a5969 
o|inlining procedure: k5966 
o|consed rest parameter at call site: "(csi.scm:1104) evalstring1209" 2 
o|inlining procedure: k5966 
o|substituted constant variable: a5986 
o|consed rest parameter at call site: "(csi.scm:1107) evalstring1209" 2 
o|substituted constant variable: a6009 
o|inlining procedure: k6006 
o|consed rest parameter at call site: "(csi.scm:1110) evalstring1209" 2 
o|inlining procedure: k6006 
o|inlining procedure: k6061 
o|inlining procedure: k6061 
o|inlining procedure: k6079 
o|inlining procedure: k6111 
o|inlining procedure: k6111 
o|propagated global variable: g14241425 pretty-print 
o|inlining procedure: k6079 
o|substituted constant variable: a6148 
o|substituted constant variable: a6150 
o|substituted constant variable: a6152 
o|substituted constant variable: a6154 
o|substituted constant variable: constant1133 
o|substituted constant variable: constant1124 
o|contracted procedure: "(csi.scm:1085) loadinit1208" 
o|inlining procedure: k5722 
o|contracted procedure: k5728 
o|inlining procedure: k5734 
o|inlining procedure: k5734 
o|inlining procedure: k5722 
o|inlining procedure: k6166 
o|inlining procedure: k6166 
o|inlining procedure: k6193 
o|inlining procedure: k6193 
o|inlining procedure: k6205 
o|inlining procedure: k6205 
o|contracted procedure: k6217 
o|inlining procedure: k6214 
o|inlining procedure: k6232 
o|inlining procedure: k6232 
o|inlining procedure: k6214 
o|inlining procedure: k6295 
o|inlining procedure: k6295 
o|inlining procedure: k6330 
o|inlining procedure: k6330 
o|inlining procedure: k6365 
o|inlining procedure: k6365 
o|inlining procedure: k6388 
o|inlining procedure: k6388 
o|inlining procedure: k6411 
o|inlining procedure: k6411 
o|inlining procedure: k6455 
o|inlining procedure: k6455 
o|inlining procedure: k6500 
o|inlining procedure: k6500 
o|inlining procedure: k6536 
o|inlining procedure: k6536 
o|inlining procedure: k6539 
o|inlining procedure: k6539 
o|inlining procedure: k6545 
o|inlining procedure: k6545 
o|inlining procedure: k6566 
o|inlining procedure: k6566 
o|substituted constant variable: a6586 
o|inlining procedure: k6606 
o|inlining procedure: k6606 
o|inlining procedure: k6642 
o|inlining procedure: k6642 
o|contracted procedure: "(csi.scm:983) parse-option-string" 
o|inlining procedure: k3013 
o|contracted procedure: "(csi.scm:452) g354363" 
o|inlining procedure: k2983 
o|inlining procedure: k2983 
o|inlining procedure: k3013 
o|inlining procedure: k3082 
o|inlining procedure: k3082 
o|inlining procedure: k6692 
o|inlining procedure: k6692 
o|inlining procedure: k6776 
o|inlining procedure: k6776 
o|contracted procedure: k6804 
o|inlining procedure: k6801 
o|contracted procedure: k6816 
o|inlining procedure: k6825 
o|inlining procedure: k6825 
o|inlining procedure: k6801 
o|inlining procedure: k6867 
o|inlining procedure: k6867 
o|substituted constant variable: a6877 
o|inlining procedure: k6881 
o|inlining procedure: k6881 
o|replaced variables: 921 
o|removed binding forms: 362 
o|removed side-effect free assignment to unused variable: constant14 
o|removed side-effect free assignment to unused variable: constant17 
o|substituted constant variable: int7681 
o|substituted constant variable: r21536902 
o|substituted constant variable: r20746903 
o|substituted constant variable: r20996905 
o|propagated global variable: out137141 ##sys#standard-output 
o|contracted procedure: "(csi.scm:378) select-frame" 
o|contracted procedure: "(csi.scm:381) copy-from-frame" 
o|converted assignments to bindings: (fail918) 
o|converted assignments to bindings: (compare913) 
o|substituted constant variable: r53887103 
o|converted assignments to bindings: (shorten404) 
o|substituted constant variable: r35516969 
o|substituted constant variable: r35516969 
o|substituted constant variable: r35516971 
o|substituted constant variable: r35516971 
o|inlining procedure: k3679 
o|inlining procedure: k3607 
o|inlining procedure: k3607 
o|removed call to pure procedure with unused result: "(csi.scm:663) size" 
o|substituted constant variable: r40157014 
o|substituted constant variable: r40157014 
o|inlining procedure: k4014 
o|inlining procedure: k4014 
o|substituted constant variable: r40277018 
o|inlining procedure: k4014 
o|inlining procedure: k4014 
o|substituted constant variable: r40397020 
o|inlining procedure: k4014 
o|inlining procedure: k4014 
o|substituted constant variable: r40517022 
o|inlining procedure: k4014 
o|inlining procedure: k4014 
o|substituted constant variable: r40637024 
o|inlining procedure: k4014 
o|inlining procedure: k4014 
o|substituted constant variable: r34397045 
o|substituted constant variable: r34047049 
o|converted assignments to bindings: (descseq514) 
o|converted assignments to bindings: (bestlen715) 
o|converted assignments to bindings: (justify738) 
o|propagated global variable: out809813 ##sys#standard-output 
o|propagated global variable: out851855 ##sys#standard-output 
o|propagated global variable: out822826 ##sys#standard-output 
o|substituted constant variable: r50667080 
o|substituted constant variable: r50667080 
o|substituted constant variable: r50667082 
o|substituted constant variable: r50667082 
o|substituted constant variable: r50807084 
o|substituted constant variable: r50807084 
o|substituted constant variable: r50807086 
o|substituted constant variable: r50807086 
o|substituted constant variable: r50867089 
o|converted assignments to bindings: (prin1787) 
o|substituted constant variable: r54127107 
o|removed side-effect free assignment to unused variable: constant1052 
o|removed side-effect free assignment to unused variable: constant1059 
o|substituted constant variable: r54677108 
o|substituted constant variable: clist1110 
o|substituted constant variable: r55847119 
o|removed side-effect free assignment to unused variable: constant1124 
o|removed side-effect free assignment to unused variable: constant1133 
o|substituted constant variable: r56827123 
o|substituted constant variable: r60627136 
o|substituted constant variable: r60627136 
o|substituted constant variable: r60807142 
o|substituted constant variable: r60807142 
o|substituted constant variable: r57237147 
o|substituted constant variable: r65377194 
o|substituted constant variable: r65377194 
o|substituted constant variable: r66437205 
o|substituted constant variable: r67777215 
o|substituted constant variable: r68687222 
o|substituted constant variable: r68687222 
o|converted assignments to bindings: (addext84) 
o|simplifications: ((let . 8)) 
o|replaced variables: 20 
o|removed binding forms: 925 
o|inlining procedure: k1979 
o|inlining procedure: "(csi.scm:369) history-clear" 
o|inlining procedure: k5246 
o|contracted procedure: k3951 
o|inlining procedure: k4262 
o|inlining procedure: k5916 
o|inlining procedure: k5916 
o|inlining procedure: k5916 
o|inlining procedure: k5916 
o|inlining procedure: k5916 
o|inlining procedure: k5916 
o|inlining procedure: k5916 
o|inlining procedure: k6123 
o|inlining procedure: k6434 
o|inlining procedure: k6597 
o|inlining procedure: k6597 
o|replaced variables: 13 
o|removed binding forms: 90 
o|substituted constant variable: r19807415 
o|substituted constant variable: r19807415 
o|substituted constant variable: r19807415 
o|substituted constant variable: r40157290 
o|substituted constant variable: r40157292 
o|substituted constant variable: r40157294 
o|substituted constant variable: r40157296 
o|substituted constant variable: r40157298 
o|substituted constant variable: r40157300 
o|substituted constant variable: r40157302 
o|substituted constant variable: r40157304 
o|substituted constant variable: r40157306 
o|inlining procedure: k6064 
o|replaced variables: 1 
o|removed binding forms: 26 
o|removed conditional forms: 1 
o|substituted constant variable: r60657636 
o|removed binding forms: 11 
o|removed conditional forms: 1 
o|removed binding forms: 1 
o|simplifications: ((if . 40) (##core#call . 546)) 
o|  call simplifications:
o|    make-vector
o|    ##sys#pair?	2
o|    ##sys#eq?
o|    ##sys#cdr	4
o|    ##sys#car	2
o|    ##sys#cons	11
o|    set-car!
o|    call-with-values
o|    void
o|    member	9
o|    string->list
o|    string
o|    equal?	3
o|    fxmod
o|    write-char	7
o|    number->string
o|    ##sys#immediate?	2
o|    ##sys#permanent?
o|    char?
o|    fixnum?	2
o|    flonum?
o|    vector?
o|    list?
o|    procedure?
o|    ##sys#pointer?	2
o|    ##sys#generic-structure?	2
o|    cdr	15
o|    caar
o|    cdar
o|    fx=	3
o|    atom?
o|    memq	3
o|    cddr	3
o|    integer->char	2
o|    char->integer
o|    ##sys#setslot	9
o|    =
o|    -
o|    <=
o|    add1	2
o|    +
o|    *
o|    /
o|    eof-object?	4
o|    caddr
o|    symbol?	3
o|    string?	5
o|    ##sys#structure?	4
o|    string-length	5
o|    fxmin
o|    string=?	6
o|    number?	2
o|    not	4
o|    fx<	4
o|    length	4
o|    list-ref	2
o|    eq?	43
o|    apply	5
o|    ##sys#call-with-values	5
o|    ##sys#apply	2
o|    ##sys#check-list	17
o|    cadr	13
o|    car	19
o|    ##sys#check-symbol	2
o|    ##sys#check-string
o|    assq	4
o|    list	7
o|    set-cdr!	2
o|    ##sys#fudge	6
o|    inexact->exact
o|    fx<=
o|    >=	2
o|    vector-ref	8
o|    null?	21
o|    ##sys#void	21
o|    fx*
o|    vector-set!
o|    fx>=	15
o|    fx+	20
o|    pair?	32
o|    ##sys#slot	80
o|    ##sys#foreign-block-argument
o|    ##sys#foreign-fixnum-argument
o|    ##sys#size	11
o|    sub1
o|    string-ref	4
o|    fx>	6
o|    char=?	8
o|    char-whitespace?
o|    fx-	11
o|    ##sys#list	4
o|    cons	16
o|contracted procedure: k1877 
o|contracted procedure: k1918 
o|contracted procedure: k1914 
o|contracted procedure: k1910 
o|contracted procedure: k1943 
o|contracted procedure: k1946 
o|contracted procedure: k1957 
o|contracted procedure: k1979 
o|contracted procedure: k2016 
o|contracted procedure: k1994 
o|contracted procedure: k1997 
o|contracted procedure: k2009 
o|contracted procedure: k2190 
o|contracted procedure: k2101 
o|contracted procedure: k2031 
o|contracted procedure: k2035 
o|contracted procedure: k2155 
o|contracted procedure: k2171 
o|contracted procedure: k2180 
o|contracted procedure: k2064 
o|contracted procedure: k2076 
o|contracted procedure: k2089 
o|contracted procedure: k2186 
o|contracted procedure: k2195 
o|contracted procedure: k2229 
o|contracted procedure: k2202 
o|contracted procedure: k2205 
o|contracted procedure: k2211 
o|contracted procedure: k2215 
o|contracted procedure: k2218 
o|contracted procedure: k2226 
o|contracted procedure: k2245 
o|propagated global variable: r2246 ##sys#undefined-value 
o|contracted procedure: k2260 
o|contracted procedure: k2285 
o|contracted procedure: k2295 
o|contracted procedure: k2301 
o|contracted procedure: k2316 
o|contracted procedure: k2307 
o|contracted procedure: k2328 
o|contracted procedure: k2395 
o|contracted procedure: k2354 
o|contracted procedure: k2357 
o|contracted procedure: k2360 
o|contracted procedure: k2363 
o|contracted procedure: k2378 
o|contracted procedure: k2389 
o|contracted procedure: k2385 
o|contracted procedure: k2407 
o|contracted procedure: k2419 
o|contracted procedure: k2422 
o|contracted procedure: k2430 
o|contracted procedure: k2445 
o|contracted procedure: k2468 
o|contracted procedure: k2486 
o|contracted procedure: k2501 
o|contracted procedure: k2516 
o|contracted procedure: k2537 
o|contracted procedure: k2546 
o|contracted procedure: k2555 
o|contracted procedure: k2573 
o|contracted procedure: k2583 
o|contracted procedure: k2587 
o|contracted procedure: k2597 
o|contracted procedure: k2617 
o|contracted procedure: k2632 
o|contracted procedure: k2642 
o|contracted procedure: k2646 
o|contracted procedure: k2656 
o|contracted procedure: k2705 
o|contracted procedure: k2718 
o|contracted procedure: k2724 
o|contracted procedure: k2740 
o|contracted procedure: k2752 
o|contracted procedure: k2762 
o|contracted procedure: k22457430 
o|propagated global variable: r22467428 ##sys#undefined-value 
o|contracted procedure: k2774 
o|contracted procedure: k2786 
o|contracted procedure: k2798 
o|contracted procedure: k5154 
o|contracted procedure: k5106 
o|contracted procedure: k5127 
o|contracted procedure: k5131 
o|contracted procedure: k5123 
o|contracted procedure: k5116 
o|contracted procedure: k5134 
o|contracted procedure: k5140 
o|contracted procedure: k5150 
o|contracted procedure: k2814 
o|contracted procedure: k5160 
o|contracted procedure: k5163 
o|contracted procedure: k5172 
o|contracted procedure: k5187 
o|contracted procedure: k5191 
o|contracted procedure: k5183 
o|contracted procedure: k5216 
o|propagated global variable: r5217 ##sys#undefined-value 
o|contracted procedure: k5228 
o|contracted procedure: k5234 
o|contracted procedure: k5237 
o|contracted procedure: k5240 
o|contracted procedure: k5243 
o|contracted procedure: k5254 
o|contracted procedure: k5268 
o|contracted procedure: k5278 
o|contracted procedure: k5302 
o|contracted procedure: k5310 
o|contracted procedure: k5306 
o|contracted procedure: k5316 
o|contracted procedure: k5319 
o|contracted procedure: k5322 
o|contracted procedure: k5325 
o|contracted procedure: k5328 
o|contracted procedure: k5372 
o|contracted procedure: k5347 
o|contracted procedure: k5357 
o|contracted procedure: k5361 
o|contracted procedure: k5365 
o|contracted procedure: k5369 
o|contracted procedure: k5381 
o|contracted procedure: k5390 
o|contracted procedure: k2827 
o|contracted procedure: k2840 
o|contracted procedure: k2846 
o|contracted procedure: k2868 
o|contracted procedure: k2883 
o|contracted procedure: k2893 
o|contracted procedure: k2897 
o|contracted procedure: k2854 
o|propagated global variable: g314316 command-table 
o|contracted procedure: k2962 
o|contracted procedure: k2969 
o|contracted procedure: k3153 
o|contracted procedure: k3167 
o|contracted procedure: k3170 
o|contracted procedure: k3174 
o|contracted procedure: k3183 
o|contracted procedure: k3197 
o|contracted procedure: k3201 
o|contracted procedure: k3205 
o|contracted procedure: k3208 
o|contracted procedure: k3226 
o|contracted procedure: k3232 
o|contracted procedure: k3324 
o|contracted procedure: k3243 
o|contracted procedure: k3275 
o|contracted procedure: k3279 
o|contracted procedure: k3309 
o|contracted procedure: k3283 
o|contracted procedure: k3287 
o|contracted procedure: k3291 
o|contracted procedure: k3306 
o|contracted procedure: k3302 
o|contracted procedure: k3295 
o|contracted procedure: k3313 
o|contracted procedure: k3317 
o|contracted procedure: k3333 
o|contracted procedure: k3343 
o|contracted procedure: k3347 
o|contracted procedure: k3360 
o|contracted procedure: k3363 
o|contracted procedure: k3374 
o|contracted procedure: k3386 
o|contracted procedure: k3389 
o|contracted procedure: k4459 
o|contracted procedure: k3470 
o|contracted procedure: k3476 
o|contracted procedure: k3488 
o|contracted procedure: k3497 
o|contracted procedure: k3504 
o|contracted procedure: k3590 
o|contracted procedure: k3514 
o|contracted procedure: k3523 
o|contracted procedure: k3536 
o|contracted procedure: k3539 
o|contracted procedure: k3546 
o|contracted procedure: k3553 
o|contracted procedure: k3568 
o|contracted procedure: k3575 
o|contracted procedure: k3579 
o|contracted procedure: k3594 
o|contracted procedure: k3613 
o|contracted procedure: k3616 
o|contracted procedure: k3625 
o|contracted procedure: k3634 
o|contracted procedure: k3643 
o|contracted procedure: k3652 
o|contracted procedure: k4446 
o|contracted procedure: k3661 
o|propagated global variable: r4447 ##sys#undefined-value 
o|contracted procedure: k3670 
o|contracted procedure: k3676 
o|contracted procedure: k3685 
o|contracted procedure: k4442 
o|contracted procedure: k3694 
o|contracted procedure: k3703 
o|contracted procedure: k3712 
o|contracted procedure: k3721 
o|contracted procedure: k3730 
o|contracted procedure: k3752 
o|contracted procedure: k3764 
o|contracted procedure: k3770 
o|contracted procedure: k3785 
o|contracted procedure: k3801 
o|contracted procedure: k3811 
o|contracted procedure: k3815 
o|contracted procedure: k3819 
o|contracted procedure: k3823 
o|contracted procedure: k3861 
o|contracted procedure: k3870 
o|contracted procedure: k3873 
o|contracted procedure: k3917 
o|contracted procedure: k3882 
o|contracted procedure: k3911 
o|contracted procedure: k3903 
o|contracted procedure: k3926 
o|contracted procedure: k3935 
o|contracted procedure: k3948 
o|contracted procedure: k3990 
o|contracted procedure: k3975 
o|contracted procedure: k3979 
o|contracted procedure: k3983 
o|contracted procedure: k4007 
o|contracted procedure: k4011 
o|contracted procedure: k4017 
o|contracted procedure: k4023 
o|contracted procedure: k4029 
o|contracted procedure: k4035 
o|contracted procedure: k4041 
o|contracted procedure: k4047 
o|contracted procedure: k4053 
o|contracted procedure: k4059 
o|contracted procedure: k4065 
o|contracted procedure: k4071 
o|contracted procedure: k4097 
o|contracted procedure: k4113 
o|contracted procedure: k4135 
o|contracted procedure: k4138 
o|contracted procedure: k4147 
o|contracted procedure: k4150 
o|contracted procedure: k4162 
o|contracted procedure: k4171 
o|contracted procedure: k4175 
o|contracted procedure: k4178 
o|contracted procedure: k4181 
o|contracted procedure: k4191 
o|contracted procedure: k4200 
o|contracted procedure: k4210 
o|contracted procedure: k4214 
o|contracted procedure: k4218 
o|contracted procedure: k4229 
o|contracted procedure: k4222 
o|contracted procedure: k4226 
o|contracted procedure: k4235 
o|contracted procedure: k4250 
o|contracted procedure: k4259 
o|contracted procedure: k4269 
o|contracted procedure: k4296 
o|contracted procedure: k4272 
o|contracted procedure: k4288 
o|contracted procedure: k4292 
o|contracted procedure: k42697461 
o|contracted procedure: k4299 
o|contracted procedure: k4302 
o|contracted procedure: k4314 
o|contracted procedure: k4324 
o|contracted procedure: k4328 
o|contracted procedure: k4332 
o|contracted procedure: k4338 
o|contracted procedure: k4341 
o|contracted procedure: k4358 
o|contracted procedure: k4374 
o|contracted procedure: k4377 
o|contracted procedure: k4384 
o|contracted procedure: k4393 
o|contracted procedure: k4396 
o|contracted procedure: k4407 
o|contracted procedure: k4419 
o|contracted procedure: k4432 
o|contracted procedure: k3460 
o|contracted procedure: k3456 
o|contracted procedure: k3444 
o|contracted procedure: k3406 
o|contracted procedure: k3413 
o|contracted procedure: k3417 
o|contracted procedure: k3420 
o|contracted procedure: k4449 
o|contracted procedure: k4468 
o|contracted procedure: k4491 
o|contracted procedure: k4511 
o|contracted procedure: k4517 
o|contracted procedure: k4528 
o|contracted procedure: k4580 
o|contracted procedure: k4534 
o|contracted procedure: k4546 
o|contracted procedure: k4557 
o|contracted procedure: k4563 
o|contracted procedure: k4570 
o|contracted procedure: k4596 
o|contracted procedure: k4602 
o|contracted procedure: k4609 
o|contracted procedure: k4615 
o|contracted procedure: k4631 
o|contracted procedure: k4637 
o|contracted procedure: k4649 
o|contracted procedure: k4661 
o|contracted procedure: k4686 
o|contracted procedure: k4695 
o|contracted procedure: k4698 
o|contracted procedure: k4711 
o|contracted procedure: k4715 
o|contracted procedure: k4731 
o|contracted procedure: k4718 
o|contracted procedure: k4725 
o|contracted procedure: k4746 
o|contracted procedure: k4749 
o|contracted procedure: k4755 
o|contracted procedure: k4758 
o|contracted procedure: k4764 
o|contracted procedure: k4771 
o|contracted procedure: k4780 
o|contracted procedure: k4790 
o|contracted procedure: k4803 
o|contracted procedure: k4807 
o|contracted procedure: k4840 
o|contracted procedure: k4843 
o|contracted procedure: k4847 
o|contracted procedure: k4857 
o|contracted procedure: k4866 
o|contracted procedure: k4869 
o|contracted procedure: k4872 
o|contracted procedure: k4875 
o|contracted procedure: k4878 
o|contracted procedure: k4881 
o|contracted procedure: k4884 
o|contracted procedure: k4929 
o|contracted procedure: k4932 
o|contracted procedure: k4940 
o|contracted procedure: k4955 
o|contracted procedure: k4980 
o|contracted procedure: k4986 
o|contracted procedure: k4990 
o|contracted procedure: k4993 
o|contracted procedure: k4996 
o|contracted procedure: k4999 
o|contracted procedure: k5002 
o|contracted procedure: k5039 
o|contracted procedure: k5014 
o|contracted procedure: k5024 
o|contracted procedure: k5028 
o|contracted procedure: k5032 
o|contracted procedure: k5036 
o|contracted procedure: k5061 
o|contracted procedure: k5075 
o|contracted procedure: k5088 
o|contracted procedure: k5095 
o|contracted procedure: k5399 
o|contracted procedure: k5414 
o|contracted procedure: k5426 
o|contracted procedure: k5433 
o|contracted procedure: k5448 
o|contracted procedure: k5452 
o|contracted procedure: k5439 
o|contracted procedure: k5469 
o|contracted procedure: k5472 
o|contracted procedure: k5478 
o|contracted procedure: k5490 
o|contracted procedure: k5516 
o|contracted procedure: k5534 
o|contracted procedure: k5560 
o|contracted procedure: k5556 
o|contracted procedure: k5537 
o|contracted procedure: k5548 
o|contracted procedure: k5610 
o|contracted procedure: k5628 
o|contracted procedure: k5619 
o|contracted procedure: k5598 
o|contracted procedure: k5580 
o|contracted procedure: k5586 
o|contracted procedure: k5593 
o|contracted procedure: k5678 
o|contracted procedure: k5710 
o|contracted procedure: k5689 
o|contracted procedure: k5699 
o|contracted procedure: k5796 
o|contracted procedure: k5754 
o|contracted procedure: k5773 
o|contracted procedure: k5831 
o|contracted procedure: k5840 
o|contracted procedure: k5849 
o|contracted procedure: k5886 
o|contracted procedure: k5910 
o|contracted procedure: k5913 
o|contracted procedure: k5923 
o|contracted procedure: k59237507 
o|contracted procedure: k5929 
o|contracted procedure: k5933 
o|contracted procedure: k59237511 
o|contracted procedure: k5939 
o|contracted procedure: k5942 
o|contracted procedure: k59237515 
o|contracted procedure: k5955 
o|contracted procedure: k5951 
o|contracted procedure: k5963 
o|contracted procedure: k5971 
o|contracted procedure: k59237519 
o|contracted procedure: k5980 
o|contracted procedure: k5988 
o|contracted procedure: k59237523 
o|contracted procedure: k5997 
o|contracted procedure: k6011 
o|contracted procedure: k59237527 
o|contracted procedure: k6020 
o|contracted procedure: k6029 
o|contracted procedure: k6038 
o|contracted procedure: k6070 
o|contracted procedure: k6064 
o|contracted procedure: k6061 
o|contracted procedure: k59237531 
o|contracted procedure: k6082 
o|contracted procedure: k6090 
o|contracted procedure: k6114 
o|contracted procedure: k6117 
o|contracted procedure: k6130 
o|contracted procedure: k6133 
o|contracted procedure: k61307535 
o|contracted procedure: k6160 
o|contracted procedure: k5748 
o|contracted procedure: k6265 
o|contracted procedure: k6261 
o|contracted procedure: k6257 
o|contracted procedure: k6226 
o|contracted procedure: k6235 
o|contracted procedure: k6244 
o|contracted procedure: k6276 
o|contracted procedure: k6286 
o|contracted procedure: k6298 
o|contracted procedure: k6301 
o|contracted procedure: k6312 
o|contracted procedure: k6324 
o|contracted procedure: k6333 
o|contracted procedure: k6336 
o|contracted procedure: k6347 
o|contracted procedure: k6359 
o|contracted procedure: k6368 
o|contracted procedure: k6378 
o|contracted procedure: k6382 
o|contracted procedure: k6391 
o|contracted procedure: k6401 
o|contracted procedure: k6405 
o|contracted procedure: k6414 
o|contracted procedure: k6424 
o|contracted procedure: k6428 
o|contracted procedure: k6462 
o|contracted procedure: k6475 
o|contracted procedure: k6479 
o|contracted procedure: k6503 
o|contracted procedure: k6506 
o|contracted procedure: k6517 
o|contracted procedure: k6529 
o|contracted procedure: k6563 
o|contracted procedure: k6581 
o|contracted procedure: k6591 
o|contracted procedure: k6632 
o|contracted procedure: k6628 
o|contracted procedure: k6594 
o|contracted procedure: k6624 
o|contracted procedure: k6620 
o|contracted procedure: k6603 
o|contracted procedure: k6613 
o|contracted procedure: k6597 
o|contracted procedure: k6639 
o|contracted procedure: k6660 
o|contracted procedure: k3004 
o|contracted procedure: k3016 
o|contracted procedure: k3019 
o|contracted procedure: k3030 
o|contracted procedure: k3042 
o|contracted procedure: k2986 
o|contracted procedure: k3085 
o|contracted procedure: k3099 
o|contracted procedure: k6689 
o|contracted procedure: k6698 
o|contracted procedure: k6764 
o|contracted procedure: k6701 
o|contracted procedure: k6760 
o|contracted procedure: k6756 
o|contracted procedure: k6752 
o|contracted procedure: k6716 
o|contracted procedure: k6744 
o|contracted procedure: k6740 
o|contracted procedure: k6732 
o|contracted procedure: k6724 
o|contracted procedure: k6720 
o|contracted procedure: k6712 
o|contracted procedure: k6770 
o|contracted procedure: k6773 
o|contracted procedure: k6779 
o|contracted procedure: k6786 
o|contracted procedure: k6847 
o|contracted procedure: k6850 
o|simplifications: ((if . 3) (let . 119)) 
o|removed binding forms: 497 
o|inlining procedure: "(csi.scm:279) tty-input?" 
o|inlining procedure: k5271 
o|inlining procedure: k3366 
o|inlining procedure: k3366 
o|inlining procedure: k4399 
o|inlining procedure: k4399 
o|inlining procedure: k4920 
o|inlining procedure: k5540 
o|inlining procedure: k5540 
o|inlining procedure: k6304 
o|inlining procedure: k6304 
o|inlining procedure: k6339 
o|inlining procedure: k6339 
o|inlining procedure: k6509 
o|inlining procedure: k6509 
o|inlining procedure: k3022 
o|inlining procedure: k3022 
o|replaced variables: 202 
o|simplifications: ((if . 1)) 
o|replaced variables: 3 
o|removed binding forms: 97 
o|inlining procedure: k2344 
o|replaced variables: 28 
o|removed binding forms: 2 
o|replaced variables: 1 
o|removed binding forms: 7 
o|removed binding forms: 1 
o|direct leaf routine/allocation: g181182 6 
o|direct leaf routine/allocation: lp488 0 
o|direct leaf routine/allocation: lp474 0 
o|direct leaf routine/allocation: loop1111 0 
o|contracted procedure: "(csi.scm:286) k2366" 
o|contracted procedure: k3848 
o|converted assignments to bindings: (lp488) 
o|converted assignments to bindings: (lp474) 
o|contracted procedure: k5504 
o|converted assignments to bindings: (loop1111) 
o|simplifications: ((let . 3)) 
o|removed binding forms: 3 
o|replaced variables: 3 
o|removed binding forms: 1 
o|customizable procedures: (k1890 k6798 g338339 k6695 doloop376377 map-loop348382 canonicalize-args k5648 k5654 k5660 map-loop11801200 k5813 k5819 for-each-loop12531263 for-each-loop12701280 for-each-loop12871297 map-loop13041321 collect-options1207 map-loop13301347 member* k5874 doloop14271428 evalstring1209 doloop13701371 doloop12391240 g12191220 loop1211 k5484 map-loop10751100 loop1063 find1040 loop1037 k4850 k5068 g834842 for-each-loop833864 prin1787 doloop847848 doloop799800 justify738 doloop747748 doloop755756 doloop763764 doloop737745 def-len702723 def-out703721 body700708 k4543 bestlen715 k3851 g658659 map-loop663680 g647648 g618625 for-each-loop617634 loop628 g596603 for-each-loop595606 doloop590591 loop-print565 doloop552553 loop2530 loop1520 k3127 map-loop410427 g437444 for-each-loop436458 shorten404 k3177 k2416 for-each-loop307319 k5166 g932940 for-each-loop931955 compare913 doloop945946 doloop917922 fail918 k5109 show-frameinfo g261268 for-each-loop260280 for-each-loop241251 doloop134135 k2208 loop92 loop111 addext84) 
o|calls to known targets: 273 
o|identified direct recursive calls: f_5223 1 
o|identified direct recursive calls: f_3401 1 
o|identified direct recursive calls: f_4254 1 
o|identified direct recursive calls: f_3436 1 
o|identified direct recursive calls: f_5421 1 
o|identified direct recursive calls: f_5608 1 
o|identified direct recursive calls: f_5529 2 
o|unused rest argument: _1237 f_5799 
o|unused rest argument: _1374 f_5902 
o|identified direct recursive calls: f_5881 2 
o|fast box initializations: 47 
o|fast global references: 37 
o|fast global assignments: 14 
o|dropping unused closure argument: f_3436 
o|dropping unused closure argument: f_4829 
o|dropping unused closure argument: f_4826 
o|dropping unused closure argument: f_3143 
o|dropping unused closure argument: f_5403 
o|dropping unused closure argument: f_2042 
o|dropping unused closure argument: f_4626 
o|dropping unused closure argument: f_5608 
o|dropping unused closure argument: f_5458 
o|dropping unused closure argument: f_3401 
o|dropping unused closure argument: f_5752 
*/
/* end of file */
