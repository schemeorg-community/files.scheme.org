/* Generated from data-structures.scm by the CHICKEN compiler
   http://www.call-cc.org
   2014-06-02 16:37
   Version 4.9.0 (rev 3f195ba)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2014-06-02 on yves (Linux)
   command line: data-structures.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -explicit-use -no-trace -output-file data-structures.c
   unit: data_2dstructures
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[119];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,14),40,105,100,101,110,116,105,116,121,32,120,54,52,41,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,112,114,101,100,115,54,57,41,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,12),40,102,95,49,51,53,52,32,120,54,55,41,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,19),40,99,111,110,106,111,105,110,32,46,32,112,114,101,100,115,54,54,41,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,112,114,101,100,115,56,49,41,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,12),40,102,95,49,51,56,55,32,120,55,57,41,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,19),40,100,105,115,106,111,105,110,32,46,32,112,114,101,100,115,55,56,41,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,14),40,102,95,49,52,51,51,32,46,32,95,57,50,41,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,14),40,102,95,49,52,51,53,32,46,32,95,57,51,41,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,19),40,99,111,110,115,116,97,110,116,108,121,32,46,32,120,115,57,48,41,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,16),40,102,95,49,52,52,53,32,120,57,54,32,121,57,55,41};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,13),40,102,108,105,112,32,112,114,111,99,57,53,41,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,18),40,102,95,49,52,53,51,32,46,32,97,114,103,115,49,48,48,41,0,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,16),40,99,111,109,112,108,101,109,101,110,116,32,112,57,57,41};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,7),40,97,49,52,55,57,41,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,18),40,102,95,49,52,55,52,32,46,32,97,114,103,115,49,48,54,41,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,20),40,114,101,99,32,102,48,49,48,52,32,46,32,102,110,115,49,48,53,41,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,18),40,99,111,109,112,111,115,101,32,46,32,102,110,115,49,48,50,41,0,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,13),40,102,95,49,53,50,53,32,120,49,49,52,41,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,102,110,115,49,49,49,41,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,12),40,111,32,46,32,102,110,115,49,48,57,41,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,108,115,116,49,50,50,41,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,15),40,102,95,49,53,52,48,32,108,115,116,49,50,48,41,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,18),40,108,105,115,116,45,111,102,63,32,112,114,101,100,49,49,57,41,0,0,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,15),40,102,95,49,53,56,54,32,46,32,95,49,51,52,41,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,112,114,111,99,115,49,51,55,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,18),40,102,95,49,54,48,48,32,46,32,97,114,103,115,49,51,53,41,0,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,17),40,101,97,99,104,32,46,32,112,114,111,99,115,49,50,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,11),40,97,110,121,63,32,120,49,52,51,41,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,12),40,97,116,111,109,63,32,120,49,52,53,41,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,17),40,116,97,105,108,63,32,120,49,52,55,32,121,49,52,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,110,115,49,54,52,41,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,25),40,105,110,116,101,114,115,112,101,114,115,101,32,108,115,116,49,54,49,32,120,49,54,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,108,115,116,49,55,48,41,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,16),40,98,117,116,108,97,115,116,32,108,115,116,49,54,56,41};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,108,105,115,116,115,49,55,56,32,114,101,115,116,49,55,57,41,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,21),40,102,108,97,116,116,101,110,32,46,32,108,105,115,116,115,48,49,55,54,41,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,28),40,100,111,108,111,111,112,49,57,56,32,104,100,50,48,48,32,116,108,50,48,49,32,99,50,48,50,41,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,108,115,116,49,57,50,32,105,49,57,51,41,0,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,18),40,99,104,111,112,32,108,115,116,49,56,56,32,110,49,56,57,41,0,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,108,115,116,115,50,49,50,41,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,23),40,106,111,105,110,32,108,115,116,115,50,48,56,32,46,32,108,115,116,50,48,57,41,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,98,108,115,116,50,50,54,32,108,115,116,50,50,55,41,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,25),40,99,111,109,112,114,101,115,115,32,98,108,115,116,50,50,50,32,108,115,116,50,50,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,108,115,116,50,53,55,41,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,20),40,102,95,50,48,51,53,32,120,50,53,52,32,108,115,116,50,53,53,41,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,44),40,97,108,105,115,116,45,117,112,100,97,116,101,33,32,120,50,52,48,32,121,50,52,49,32,108,115,116,50,52,50,32,46,32,116,109,112,50,51,57,50,52,51,41,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,108,115,116,50,56,48,41,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,43),40,97,108,105,115,116,45,117,112,100,97,116,101,32,107,50,55,48,32,118,50,55,49,32,108,115,116,50,55,50,32,46,32,116,109,112,50,54,57,50,55,51,41,0,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,108,115,116,51,49,56,41,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,20),40,102,95,50,50,50,55,32,120,51,49,53,32,108,115,116,51,49,54,41,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,35),40,97,108,105,115,116,45,114,101,102,32,120,50,57,55,32,108,115,116,50,57,56,32,46,32,116,109,112,50,57,54,50,57,57,41,0,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,108,51,51,48,41,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,29),40,114,97,115,115,111,99,32,120,51,50,53,32,108,115,116,51,50,54,32,46,32,116,115,116,51,50,55,41,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,107,51,52,54,41,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,29),40,114,101,118,45,115,116,114,105,110,103,45,97,112,112,101,110,100,32,108,51,51,57,32,105,51,52,48,41,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,28),40,114,101,118,101,114,115,101,45,115,116,114,105,110,103,45,97,112,112,101,110,100,32,108,51,51,55,41,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,15),40,45,62,115,116,114,105,110,103,32,120,51,53,49,41,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,51,54,50,32,103,51,55,52,51,56,48,41,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,16),40,99,111,110,99,32,46,32,97,114,103,115,51,53,57,41};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,24),40,108,111,111,112,32,105,115,116,97,114,116,51,57,53,32,105,101,110,100,51,57,54,41};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,52),40,116,114,97,118,101,114,115,101,32,119,104,105,99,104,51,56,55,32,119,104,101,114,101,51,56,56,32,115,116,97,114,116,51,56,57,32,116,101,115,116,51,57,48,32,108,111,99,51,57,49,41,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,17),40,97,50,53,53,53,32,105,52,48,56,32,108,52,48,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,50),40,35,35,115,121,115,35,115,117,98,115,116,114,105,110,103,45,105,110,100,101,120,32,119,104,105,99,104,52,48,53,32,119,104,101,114,101,52,48,54,32,115,116,97,114,116,52,48,55,41,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,17),40,97,50,53,54,52,32,105,52,49,51,32,108,52,49,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,53),40,35,35,115,121,115,35,115,117,98,115,116,114,105,110,103,45,105,110,100,101,120,45,99,105,32,119,104,105,99,104,52,49,48,32,119,104,101,114,101,52,49,49,32,115,116,97,114,116,52,49,50,41,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,47),40,115,117,98,115,116,114,105,110,103,45,105,110,100,101,120,32,119,104,105,99,104,52,50,51,32,119,104,101,114,101,52,50,52,32,46,32,116,109,112,52,50,50,52,50,53,41,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,50),40,115,117,98,115,116,114,105,110,103,45,105,110,100,101,120,45,99,105,32,119,104,105,99,104,52,51,55,32,119,104,101,114,101,52,51,56,32,46,32,116,109,112,52,51,54,52,51,57,41,0,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,29),40,115,116,114,105,110,103,45,99,111,109,112,97,114,101,51,32,115,49,52,52,54,32,115,50,52,52,55,41,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,32),40,115,116,114,105,110,103,45,99,111,109,112,97,114,101,51,45,99,105,32,115,49,52,53,53,32,115,50,52,53,54,41};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,56),40,35,35,115,121,115,35,115,117,98,115,116,114,105,110,103,61,63,32,115,49,52,54,52,32,115,50,52,54,53,32,115,116,97,114,116,49,52,54,54,32,115,116,97,114,116,50,52,54,55,32,110,52,54,56,41};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,37),40,115,117,98,115,116,114,105,110,103,61,63,32,115,49,52,56,51,32,115,50,52,56,52,32,46,32,116,109,112,52,56,50,52,56,53,41,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,59),40,35,35,115,121,115,35,115,117,98,115,116,114,105,110,103,45,99,105,61,63,32,115,49,52,57,57,32,115,50,53,48,48,32,115,116,97,114,116,49,53,48,49,32,115,116,97,114,116,50,53,48,50,32,110,53,48,51,41,0,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,40),40,115,117,98,115,116,114,105,110,103,45,99,105,61,63,32,115,49,53,49,56,32,115,50,53,49,57,32,46,32,116,109,112,53,49,55,53,50,48,41};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,27),40,97,100,100,32,102,114,111,109,53,52,50,32,116,111,53,52,51,32,108,97,115,116,53,52,52,41,0,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,11),40,115,99,97,110,32,106,53,54,52,41,0,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,27),40,108,111,111,112,32,105,53,52,56,32,108,97,115,116,53,52,57,32,102,114,111,109,53,53,48,41,0,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,42),40,115,116,114,105,110,103,45,115,112,108,105,116,32,115,116,114,53,51,52,32,46,32,100,101,108,115,116,114,45,97,110,100,45,102,108,97,103,53,51,53,41,0,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,50,32,110,50,54,48,50,41,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,49,32,115,115,53,57,51,32,110,53,57,52,41,0,0,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,40),40,115,116,114,105,110,103,45,105,110,116,101,114,115,112,101,114,115,101,32,115,116,114,115,53,56,52,32,46,32,116,109,112,53,56,51,53,56,53,41};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,13),40,102,95,51,48,57,56,32,99,54,50,51,41,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,15),40,105,110,115,116,114,105,110,103,32,115,54,50,49,41,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,105,54,53,49,32,106,54,53,50,41};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,13),40,102,95,51,50,55,48,32,99,54,51,54,41,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,41),40,115,116,114,105,110,103,45,116,114,97,110,115,108,97,116,101,32,115,116,114,54,49,55,32,102,114,111,109,54,49,56,32,46,32,116,111,54,49,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,115,109,97,112,54,55,53,41,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,37),40,99,111,108,108,101,99,116,32,105,54,55,48,32,102,114,111,109,54,55,49,32,116,111,116,97,108,54,55,50,32,102,115,54,55,51,41,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,34),40,115,116,114,105,110,103,45,116,114,97,110,115,108,97,116,101,42,32,115,116,114,54,54,54,32,115,109,97,112,54,54,55,41,0,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,116,111,116,97,108,54,57,49,32,112,111,115,54,57,50,41,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,27),40,115,116,114,105,110,103,45,99,104,111,112,32,115,116,114,54,56,55,32,108,101,110,54,56,56,41,0,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,33),40,115,116,114,105,110,103,45,99,104,111,109,112,32,115,116,114,55,48,54,32,46,32,116,109,112,55,48,53,55,48,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,55,50,55,32,105,55,50,57,41};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,108,97,115,116,55,51,53,32,110,101,120,116,55,51,54,41,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,25),40,115,111,114,116,101,100,63,32,115,101,113,55,50,48,32,108,101,115,115,63,55,50,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,32,120,55,53,49,32,97,55,53,50,32,121,55,53,51,32,98,55,53,52,41,0,0,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,26),40,109,101,114,103,101,32,97,55,52,51,32,98,55,52,52,32,108,101,115,115,63,55,52,53,41,0,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,114,55,54,53,32,97,55,54,54,32,98,55,54,55,41,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,27),40,109,101,114,103,101,33,32,97,55,53,55,32,98,55,53,56,32,108,101,115,115,63,55,53,57,41,0,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,11),40,115,116,101,112,32,110,55,55,55,41,0,0,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,21),40,100,111,108,111,111,112,55,57,56,32,112,56,48,48,32,105,56,48,49,41,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,23),40,115,111,114,116,33,32,115,101,113,55,55,52,32,108,101,115,115,63,55,55,53,41,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,22),40,115,111,114,116,32,115,101,113,56,48,55,32,108,101,115,115,63,56,48,56,41,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,24),40,119,97,108,107,32,101,100,103,101,115,56,50,56,32,115,116,97,116,101,56,50,57,41};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,48),40,118,105,115,105,116,32,100,97,103,56,49,51,32,110,111,100,101,56,49,52,32,101,100,103,101,115,56,49,53,32,112,97,116,104,56,49,54,32,115,116,97,116,101,56,49,55,41};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,100,97,103,56,51,54,32,115,116,97,116,101,56,51,55,41,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,33),40,116,111,112,111,108,111,103,105,99,97,108,45,115,111,114,116,32,100,97,103,56,49,48,32,112,114,101,100,56,49,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,112,115,56,52,54,32,112,101,56,52,55,41,0,0,0,0,0,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,30),40,98,105,110,97,114,121,45,115,101,97,114,99,104,32,118,101,99,56,52,49,32,112,114,111,99,56,52,50,41,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,12),40,109,97,107,101,45,113,117,101,117,101,41,0,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,13),40,113,117,101,117,101,63,32,120,56,54,49,41,0,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,19),40,113,117,101,117,101,45,108,101,110,103,116,104,32,113,56,54,51,41,0,0,0,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,19),40,113,117,101,117,101,45,101,109,112,116,121,63,32,113,56,54,54,41,0,0,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,18),40,113,117,101,117,101,45,102,105,114,115,116,32,113,56,54,57,41,0,0,0,0,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,17),40,113,117,101,117,101,45,108,97,115,116,32,113,56,55,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,26),40,113,117,101,117,101,45,97,100,100,33,32,113,56,55,57,32,100,97,116,117,109,56,56,48,41,0,0,0,0,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,20),40,113,117,101,117,101,45,114,101,109,111,118,101,33,32,113,56,57,49,41,0,0,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,108,115,116,57,48,50,32,108,115,116,50,57,48,51,41,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,18),40,113,117,101,117,101,45,62,108,105,115,116,32,113,57,48,48,41,0,0,0,0,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,57,48,56,32,108,115,116,57,49,48,41,0,0,0,0,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,21),40,108,105,115,116,45,62,113,117,101,117,101,32,108,115,116,48,57,48,55,41,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,31),40,113,117,101,117,101,45,112,117,115,104,45,98,97,99,107,33,32,113,57,49,56,32,105,116,101,109,57,49,57,41,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,57,51,50,41,0,0,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,40),40,113,117,101,117,101,45,112,117,115,104,45,98,97,99,107,45,108,105,115,116,33,32,113,57,50,53,32,105,116,101,109,108,105,115,116,57,50,54,41};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(f_1600)
static void C_ccall f_1600(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1600)
static void C_ccall f_1600r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1606)
static void C_fcall f_1606(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1674)
static void C_fcall f_1674(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3295)
static void C_ccall f_3295(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1916)
static void C_ccall f_1916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1668)
static void C_ccall f_1668(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3622)
static void C_ccall f_3622(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1967)
static void C_ccall f_1967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3616)
static void C_ccall f_3616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1906)
static void C_ccall f_1906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1652)
static C_word C_fcall f_1652(C_word t0,C_word t1);
C_noret_decl(f_3428)
static void C_fcall f_3428(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2299)
static void C_fcall f_2299(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1640)
static void C_ccall f_1640(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2292)
static void C_ccall f_2292(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2292)
static void C_ccall f_2292r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3413)
static void C_ccall f_3413(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2343)
static void C_fcall f_2343(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2340)
static void C_ccall f_2340(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3167)
static void C_ccall f_3167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3516)
static void C_ccall f_3516(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1499)
static void C_ccall f_1499(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1499)
static void C_ccall f_1499r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1488)
static void C_ccall f_1488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1480)
static void C_ccall f_1480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1925)
static void C_fcall f_1925(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1474)
static void C_ccall f_1474(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1474)
static void C_ccall f_1474r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1996)
static void C_ccall f_1996(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_1996)
static void C_ccall f_1996r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_2357)
static void C_ccall f_2357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1463)
static void C_ccall f_1463(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1463)
static void C_ccall f_1463r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1466)
static void C_ccall f_1466(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1466)
static void C_ccall f_1466r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1461)
static void C_ccall f_1461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3321)
static void C_ccall f_3321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1824)
static void C_ccall f_1824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1828)
static void C_ccall f_1828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2366)
static C_word C_fcall f_2366(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_4255)
static void C_ccall f_4255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3403)
static void C_ccall f_3403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3965)
static void C_ccall f_3965(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2323)
static void C_ccall f_2323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3999)
static void C_ccall f_3999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3995)
static void C_fcall f_3995(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3992)
static void C_ccall f_3992(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3990)
static void C_ccall f_3990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1810)
static void C_fcall f_1810(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4205)
static void C_ccall f_4205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3979)
static void C_ccall f_3979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1871)
static void C_fcall f_1871(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4336)
static void C_ccall f_4336(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3093)
static void C_fcall f_3093(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3098)
static void C_ccall f_3098(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3090)
static void C_ccall f_3090(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3090)
static void C_ccall f_3090r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4346)
static void C_fcall f_4346(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3983)
static void C_ccall f_3983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4605)
static C_word C_fcall f_4605(C_word t0);
C_noret_decl(f_4466)
static void C_ccall f_4466(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3307)
static void C_fcall f_3307(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2413)
static void C_ccall f_2413(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2458)
static void C_ccall f_2458(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2458)
static void C_ccall f_2458r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2453)
static void C_ccall f_2453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2450)
static void C_ccall f_2450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2466)
static void C_ccall f_2466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2468)
static void C_fcall f_2468(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2304)
static void C_fcall f_2304(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4497)
static void C_ccall f_4497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4439)
static void C_fcall f_4439(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3840)
static void C_fcall f_3840(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2559)
static void C_ccall f_2559(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2556)
static void C_ccall f_2556(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2550)
static void C_ccall f_2550(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4036)
static void C_ccall f_4036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2568)
static void C_ccall f_2568(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2568)
static void C_ccall f_2568r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2565)
static void C_ccall f_2565(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1546)
static void C_fcall f_1546(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1540)
static void C_ccall f_1540(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2537)
static void C_ccall f_2537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1538)
static void C_ccall f_1538(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1536)
static void C_ccall f_1536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1533)
static void C_ccall f_1533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2497)
static void C_ccall f_2497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3853)
static void C_ccall f_3853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3859)
static void C_ccall f_3859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3850)
static void C_ccall f_3850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1525)
static void C_ccall f_1525(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4103)
static void C_ccall f_4103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1360)
static void C_fcall f_1360(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3888)
static void C_ccall f_3888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4281)
static void C_ccall f_4281(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2598)
static void C_ccall f_2598(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1511)
static void C_fcall f_1511(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1354)
static void C_ccall f_1354(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1352)
static void C_ccall f_1352(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1352)
static void C_ccall f_1352r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4272)
static void C_ccall f_4272(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4260)
static void C_ccall f_4260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2503)
static void C_fcall f_2503(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4266)
static void C_ccall f_4266(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1453)
static void C_ccall f_1453(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1453)
static void C_ccall f_1453r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1451)
static void C_ccall f_1451(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1393)
static void C_fcall f_1393(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1443)
static void C_ccall f_1443(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1445)
static void C_ccall f_1445(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4510)
static void C_fcall f_4510(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1385)
static void C_ccall f_1385(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1385)
static void C_ccall f_1385r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1387)
static void C_ccall f_1387(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2660)
static void C_ccall f_2660(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1435)
static void C_ccall f_1435(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1433)
static void C_ccall f_1433(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4524)
static void C_ccall f_4524(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1376)
static void C_ccall f_1376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4477)
static void C_ccall f_4477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2006)
static void C_ccall f_2006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1586)
static void C_ccall f_1586(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1422)
static void C_ccall f_1422(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1422)
static void C_ccall f_1422r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4294)
static void C_ccall f_4294(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3659)
static void C_ccall f_3659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2003)
static void C_fcall f_2003(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3924)
static void C_ccall f_3924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3652)
static void C_fcall f_3652(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4487)
static void C_fcall f_4487(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2057)
static void C_ccall f_2057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1578)
static void C_ccall f_1578(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1578)
static void C_ccall f_1578r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1699)
static void C_ccall f_1699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2697)
static void C_ccall f_2697(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2697)
static void C_ccall f_2697r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1565)
static void C_ccall f_1565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1406)
static void C_ccall f_1406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4426)
static void C_ccall f_4426(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3794)
static void C_ccall f_3794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3791)
static void C_ccall f_3791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2035)
static void C_ccall f_2035(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3933)
static void C_fcall f_3933(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3931)
static void C_ccall f_3931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2583)
static void C_ccall f_2583(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2583)
static void C_ccall f_2583r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(C_data_2dstructures_toplevel)
C_externexport void C_ccall C_data_2dstructures_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2041)
static void C_fcall f_2041(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3553)
static void C_ccall f_3553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2132)
static void C_ccall f_2132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2524)
static void C_fcall f_2524(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3837)
static void C_ccall f_3837(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3543)
static void C_fcall f_3543(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4048)
static void C_ccall f_4048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3448)
static void C_ccall f_3448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2670)
static void C_fcall f_2670(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3812)
static void C_ccall f_3812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3128)
static void C_ccall f_3128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3592)
static void C_fcall f_3592(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2757)
static void C_ccall f_2757(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3104)
static C_word C_fcall f_3104(C_word t0,C_word t1);
C_noret_decl(f_4081)
static void C_ccall f_4081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2154)
static void C_ccall f_2154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3131)
static void C_ccall f_3131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4139)
static void C_fcall f_4139(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4067)
static void C_fcall f_4067(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3477)
static void C_ccall f_3477(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3477)
static void C_ccall f_3477r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1863)
static void C_fcall f_1863(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4061)
static void C_ccall f_4061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2854)
static void C_ccall f_2854(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2854)
static void C_ccall f_2854r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3006)
static void C_fcall f_3006(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4304)
static void C_ccall f_4304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3463)
static void C_ccall f_3463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3459)
static void C_ccall f_3459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2794)
static void C_ccall f_2794(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2794)
static void C_ccall f_2794r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4315)
static void C_ccall f_4315(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3723)
static void C_ccall f_3723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2767)
static void C_fcall f_2767(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4181)
static void C_fcall f_4181(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3143)
static void C_ccall f_3143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2629)
static void C_ccall f_2629(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2227)
static void C_ccall f_2227(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3148)
static void C_fcall f_3148(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3716)
static void C_fcall f_3716(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3713)
static void C_ccall f_3713(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2233)
static void C_fcall f_2233(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3016)
static void C_ccall f_3016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3705)
static void C_ccall f_3705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2895)
static void C_fcall f_2895(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2205)
static void C_ccall f_2205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2091)
static void C_fcall f_2091(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2890)
static void C_ccall f_2890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3335)
static void C_ccall f_3335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2202)
static void C_fcall f_2202(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1859)
static void C_ccall f_1859(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1859)
static void C_ccall f_1859r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3021)
static C_word C_fcall f_3021(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_2082)
static void C_ccall f_2082(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_2082)
static void C_ccall f_2082r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_4177)
static void C_ccall f_4177(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1701)
static void C_ccall f_1701(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4160)
static void C_ccall f_4160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2249)
static void C_ccall f_2249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3377)
static void C_fcall f_3377(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4379)
static void C_ccall f_4379(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1731)
static void C_ccall f_1731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1739)
static void C_fcall f_1739(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1733)
static void C_ccall f_1733(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1733)
static void C_ccall f_1733r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4195)
static void C_fcall f_4195(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2905)
static void C_ccall f_2905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1789)
static void C_fcall f_1789(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3340)
static void C_fcall f_3340(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1781)
static void C_ccall f_1781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4389)
static void C_ccall f_4389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1765)
static void C_ccall f_1765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2875)
static void C_fcall f_2875(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2988)
static void C_ccall f_2988(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2988)
static void C_ccall f_2988r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1347)
static void C_ccall f_1347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1349)
static void C_ccall f_1349(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4325)
static void C_ccall f_4325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1710)
static void C_fcall f_1710(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2961)
static void C_ccall f_2961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3287)
static void C_ccall f_3287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1772)
static void C_ccall f_1772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1774)
static void C_ccall f_1774(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4564)
static void C_ccall f_4564(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3270)
static void C_ccall f_3270(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2186)
static void C_ccall f_2186(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2186)
static void C_ccall f_2186r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4577)
static void C_fcall f_4577(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4574)
static void C_ccall f_4574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3679)
static void C_ccall f_3679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1637)
static void C_ccall f_1637(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1634)
static void C_ccall f_1634(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2922)
static void C_fcall f_2922(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1625)
static void C_ccall f_1625(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1606)
static void C_fcall trf_1606(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1606(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1606(t0,t1,t2);}

C_noret_decl(trf_1674)
static void C_fcall trf_1674(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1674(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1674(t0,t1,t2);}

C_noret_decl(trf_3428)
static void C_fcall trf_3428(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3428(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3428(t0,t1,t2,t3);}

C_noret_decl(trf_2299)
static void C_fcall trf_2299(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2299(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2299(t0,t1);}

C_noret_decl(trf_2343)
static void C_fcall trf_2343(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2343(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2343(t0,t1,t2,t3);}

C_noret_decl(trf_1925)
static void C_fcall trf_1925(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1925(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1925(t0,t1,t2,t3);}

C_noret_decl(trf_3995)
static void C_fcall trf_3995(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3995(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3995(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_1810)
static void C_fcall trf_1810(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1810(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1810(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1871)
static void C_fcall trf_1871(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1871(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1871(t0,t1,t2);}

C_noret_decl(trf_3093)
static void C_fcall trf_3093(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3093(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3093(t0,t1);}

C_noret_decl(trf_4346)
static void C_fcall trf_4346(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4346(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4346(t0,t1);}

C_noret_decl(trf_3307)
static void C_fcall trf_3307(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3307(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3307(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2468)
static void C_fcall trf_2468(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2468(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2468(t0,t1,t2);}

C_noret_decl(trf_2304)
static void C_fcall trf_2304(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2304(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2304(t0,t1,t2);}

C_noret_decl(trf_4439)
static void C_fcall trf_4439(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4439(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4439(t0,t1,t2,t3);}

C_noret_decl(trf_3840)
static void C_fcall trf_3840(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3840(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3840(t0,t1,t2);}

C_noret_decl(trf_1546)
static void C_fcall trf_1546(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1546(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1546(t0,t1,t2);}

C_noret_decl(trf_1360)
static void C_fcall trf_1360(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1360(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1360(t0,t1,t2);}

C_noret_decl(trf_1511)
static void C_fcall trf_1511(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1511(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1511(t0,t1,t2);}

C_noret_decl(trf_2503)
static void C_fcall trf_2503(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2503(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2503(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1393)
static void C_fcall trf_1393(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1393(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1393(t0,t1,t2);}

C_noret_decl(trf_4510)
static void C_fcall trf_4510(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4510(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4510(t0,t1);}

C_noret_decl(trf_2003)
static void C_fcall trf_2003(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2003(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2003(t0,t1);}

C_noret_decl(trf_3652)
static void C_fcall trf_3652(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3652(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3652(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4487)
static void C_fcall trf_4487(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4487(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4487(t0,t1,t2);}

C_noret_decl(trf_3933)
static void C_fcall trf_3933(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3933(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3933(t0,t1,t2,t3);}

C_noret_decl(trf_2041)
static void C_fcall trf_2041(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2041(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2041(t0,t1,t2);}

C_noret_decl(trf_2524)
static void C_fcall trf_2524(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2524(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2524(t0,t1,t2,t3);}

C_noret_decl(trf_3543)
static void C_fcall trf_3543(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3543(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3543(t0,t1,t2);}

C_noret_decl(trf_2670)
static void C_fcall trf_2670(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2670(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2670(t0,t1);}

C_noret_decl(trf_3592)
static void C_fcall trf_3592(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3592(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3592(t0,t1,t2,t3);}

C_noret_decl(trf_4139)
static void C_fcall trf_4139(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4139(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4139(t0,t1,t2,t3);}

C_noret_decl(trf_4067)
static void C_fcall trf_4067(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4067(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4067(t0,t1,t2,t3);}

C_noret_decl(trf_1863)
static void C_fcall trf_1863(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1863(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1863(t0,t1);}

C_noret_decl(trf_3006)
static void C_fcall trf_3006(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3006(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3006(t0,t1,t2,t3);}

C_noret_decl(trf_2767)
static void C_fcall trf_2767(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2767(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2767(t0,t1);}

C_noret_decl(trf_4181)
static void C_fcall trf_4181(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4181(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4181(t0,t1);}

C_noret_decl(trf_3148)
static void C_fcall trf_3148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3148(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3148(t0,t1,t2,t3);}

C_noret_decl(trf_3716)
static void C_fcall trf_3716(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3716(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3716(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2233)
static void C_fcall trf_2233(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2233(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2233(t0,t1,t2);}

C_noret_decl(trf_2895)
static void C_fcall trf_2895(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2895(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2895(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2091)
static void C_fcall trf_2091(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2091(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2091(t0,t1,t2);}

C_noret_decl(trf_2202)
static void C_fcall trf_2202(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2202(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2202(t0,t1);}

C_noret_decl(trf_3377)
static void C_fcall trf_3377(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3377(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3377(t0,t1);}

C_noret_decl(trf_1739)
static void C_fcall trf_1739(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1739(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1739(t0,t1,t2,t3);}

C_noret_decl(trf_4195)
static void C_fcall trf_4195(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4195(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4195(t0,t1,t2,t3);}

C_noret_decl(trf_1789)
static void C_fcall trf_1789(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1789(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1789(t0,t1,t2,t3);}

C_noret_decl(trf_3340)
static void C_fcall trf_3340(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3340(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3340(t0,t1,t2);}

C_noret_decl(trf_2875)
static void C_fcall trf_2875(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2875(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2875(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1710)
static void C_fcall trf_1710(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1710(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1710(t0,t1,t2);}

C_noret_decl(trf_4577)
static void C_fcall trf_4577(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4577(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4577(t0,t1);}

C_noret_decl(trf_2922)
static void C_fcall trf_2922(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2922(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2922(t0,t1,t2);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* f_1600 in each in k1345 */
static void C_ccall f_1600(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_1600r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1600r(t0,t1,t2);}}

static void C_ccall f_1600r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1606,a[2]=t2,a[3]=t4,a[4]=((C_word)li25),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1606(t6,t1,((C_word*)t0)[2]);}

/* loop */
static void C_fcall f_1606(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1606,NULL,3,t0,t1,t2);}
t3=C_slot(t2,C_fix(0));
t4=C_slot(t2,C_fix(1));
t5=t4;
if(C_truep(C_i_nullp(t5))){
C_apply(4,0,t1,t3,((C_word*)t0)[2]);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1625,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
C_apply(4,0,t6,t3,((C_word*)t0)[2]);}}

/* loop in intersperse in k1345 */
static void C_fcall f_1674(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1674,NULL,3,t0,t1,t2);}
if(C_truep(C_eqp(t2,C_SCHEME_END_OF_LIST))){
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_i_cdr(t2);
if(C_truep(C_eqp(t3,C_SCHEME_END_OF_LIST))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=C_slot(t2,C_fix(0));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1699,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm:134: loop */
t9=t6;
t10=t3;
t1=t9;
t2=t10;
goto loop;}}}

/* string-translate* in k1345 */
static void C_ccall f_3295(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3295,4,t0,t1,t2,t3);}
t4=C_i_check_string_2(t2,lf[73]);
t5=C_i_check_list_2(t3,lf[73]);
t6=C_block_size(t2);
t7=t6;
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3307,a[2]=t7,a[3]=t2,a[4]=t9,a[5]=t3,a[6]=((C_word)li89),tmp=(C_word)a,a+=7,tmp));
/* data-structures.scm:532: collect */
t11=((C_word*)t9)[1];
f_3307(t11,t1,C_fix(0),C_fix(0),C_fix(0),C_SCHEME_END_OF_LIST);}

/* compress in k1345 */
static void C_ccall f_1916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1916,4,t0,t1,t2,t3);}
t4=lf[26];
t5=C_i_check_list_2(t3,lf[25]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1925,a[2]=t7,a[3]=t4,a[4]=((C_word)li43),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_1925(t9,t1,t2,t3);}

/* intersperse in k1345 */
static void C_ccall f_1668(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1668,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1674,a[2]=t3,a[3]=t5,a[4]=((C_word)li32),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_1674(t7,t1,t2);}

/* merge in k1345 */
static void C_ccall f_3622(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3622,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_nullp(t2))){
t5=t3;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
if(C_truep(C_i_nullp(t3))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=C_i_car(t2);
t6=t2;
t7=C_u_i_cdr(t6);
t8=C_i_car(t3);
t9=t3;
t10=C_u_i_cdr(t9);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3652,a[2]=t12,a[3]=t4,a[4]=((C_word)li97),tmp=(C_word)a,a+=5,tmp));
t14=((C_word*)t12)[1];
f_3652(t14,t1,t5,t7,t8,t10);}}}

/* k1965 in loop in compress in k1345 */
static void C_ccall f_1967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1967,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k3614 in loop in sorted? in k1345 */
static void C_ccall f_3616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=((C_word*)t0)[3];
t3=C_u_i_car(t2);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* data-structures.scm:597: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3592(t6,((C_word*)t0)[2],t3,t5);}}

/* k1904 in loop in k1861 in join in k1345 */
static void C_ccall f_1906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm:181: ##sys#append */
t2=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* loop in tail? in k1345 */
static C_word C_fcall f_1652(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_overflow_check;
loop:
if(C_truep(C_eqp(t1,C_SCHEME_END_OF_LIST))){
return(C_SCHEME_FALSE);}
else{
if(C_truep(C_eqp(((C_word*)t0)[2],t1))){
return(C_SCHEME_TRUE);}
else{
t2=C_slot(t1,C_fix(1));
t4=t2;
t1=t4;
goto loop;}}}

/* loop in string-chop in k1345 */
static void C_fcall f_3428(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3428,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep(C_fixnum_less_or_equal_p(t2,((C_word*)t0)[2]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3448,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=C_fixnum_plus(t3,t2);
/* data-structures.scm:543: ##sys#substring */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[64]+1)))(5,*((C_word*)lf[64]+1),t4,((C_word*)t0)[3],t3,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3459,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_fixnum_plus(t3,((C_word*)t0)[2]);
/* data-structures.scm:544: ##sys#substring */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[64]+1)))(5,*((C_word*)lf[64]+1),t4,((C_word*)t0)[3],t3,t5);}}}

/* k2297 in rassoc in k1345 */
static void C_fcall f_2299(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2299,NULL,2,t0,t1);}
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2304,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word)li53),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2304(t6,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* tail? in k1345 */
static void C_ccall f_1640(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1640,4,t0,t1,t2,t3);}
t4=C_i_check_list_2(t3,lf[14]);
t5=C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1652,a[2]=t2,a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,f_1652(t6,t3));}}

/* rassoc in k1345 */
static void C_ccall f_2292(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_2292r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2292r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2292r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=C_i_check_list_2(t3,lf[41]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2299,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(t4))){
t7=t4;
t8=t6;
f_2299(t8,C_u_i_car(t7));}
else{
t7=t6;
f_2299(t7,*((C_word*)lf[30]+1));}}

/* string-chop in k1345 */
static void C_ccall f_3413(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3413,4,t0,t1,t2,t3);}
t4=C_i_check_string_2(t2,lf[76]);
t5=C_i_check_exact_2(t3,lf[76]);
t6=C_block_size(t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3428,a[2]=t3,a[3]=t2,a[4]=t8,a[5]=((C_word)li91),tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_3428(t10,t1,t6,C_fix(0));}

/* rev-string-append in reverse-string-append in k1345 */
static void C_fcall f_2343(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2343,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_pairp(t2))){
t4=t2;
t5=C_u_i_car(t4);
t6=C_i_string_length(t5);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2357,a[2]=t3,a[3]=t7,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=t2;
t10=C_u_i_cdr(t9);
t11=C_fixnum_plus(t3,t7);
/* data-structures.scm:272: rev-string-append */
t13=t8;
t14=t10;
t15=t11;
t1=t13;
t2=t14;
t3=t15;
goto loop;}
else{
/* data-structures.scm:279: make-string */
t4=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}}

/* reverse-string-append in k1345 */
static void C_ccall f_2340(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2340,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2343,a[2]=t4,a[3]=((C_word)li56),tmp=(C_word)a,a+=4,tmp));
/* data-structures.scm:280: rev-string-append */
t6=((C_word*)t4)[1];
f_2343(t6,t1,t2,C_fix(0));}

/* k3165 in loop in k3141 in k3129 in k3126 in string-translate in k1345 */
static void C_ccall f_3167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[2])){
if(C_truep(C_charp(((C_word*)t0)[2]))){
t2=C_setsubchar(((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[2]);
t3=C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t4=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* data-structures.scm:497: loop */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3148(t5,((C_word*)t0)[7],t3,t4);}
else{
if(C_truep(C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[8]))){
/* data-structures.scm:499: ##sys#error */
t2=*((C_word*)lf[20]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[7],lf[69],lf[70],((C_word*)t0)[5],((C_word*)t0)[2]);}
else{
t2=C_subchar(((C_word*)t0)[2],t1);
t3=C_setsubchar(((C_word*)t0)[3],((C_word*)t0)[4],t2);
t4=C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t5=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* data-structures.scm:502: loop */
t6=((C_word*)((C_word*)t0)[6])[1];
f_3148(t6,((C_word*)t0)[7],t4,t5);}}}
else{
t2=C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* data-structures.scm:494: loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_3148(t3,((C_word*)t0)[7],t2,((C_word*)t0)[4]);}}
else{
t2=C_setsubchar(((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[9]);
t3=C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t4=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* data-structures.scm:493: loop */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3148(t5,((C_word*)t0)[7],t3,t4);}}

/* sorted? in k1345 */
static void C_ccall f_3516(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3516,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}
else{
if(C_truep(C_i_vectorp(t2))){
t4=t2;
t5=C_block_size(t4);
t6=t5;
if(C_truep(C_fixnum_less_or_equal_p(t6,C_fix(1)))){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_TRUE);}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3543,a[2]=t6,a[3]=t8,a[4]=t2,a[5]=t3,a[6]=((C_word)li94),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_3543(t10,t1,C_fix(1));}}
else{
t4=C_i_car(t2);
t5=t2;
t6=C_u_i_cdr(t5);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3592,a[2]=t8,a[3]=t3,a[4]=((C_word)li95),tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_3592(t10,t1,t4,t6);}}}

/* o in k1345 */
static void C_ccall f_1499(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_1499r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1499r(t0,t1,t2);}}

static void C_ccall f_1499r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,*((C_word*)lf[0]+1));}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1511,a[2]=t4,a[3]=((C_word)li19),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_1511(t6,t1,t2);}}

/* k1486 in a1479 */
static void C_ccall f_1488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* a1479 */
static void C_ccall f_1480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1488,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[4]);}

/* loop in compress in k1345 */
static void C_fcall f_1925(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(4);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1925,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep(C_i_pairp(t2))){
if(C_truep(C_i_pairp(t3))){
if(C_truep(C_slot(t2,C_fix(0)))){
t4=C_slot(t3,C_fix(0));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1967,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_slot(t2,C_fix(1));
t8=C_slot(t3,C_fix(1));
/* data-structures.scm:194: loop */
t12=t6;
t13=t7;
t14=t8;
t1=t12;
t2=t13;
t3=t14;
goto loop;}
else{
t4=C_slot(t2,C_fix(1));
t5=C_slot(t3,C_fix(1));
/* data-structures.scm:195: loop */
t12=t1;
t13=t4;
t14=t5;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}
else{
/* data-structures.scm:192: ##sys#signal-hook */
t4=*((C_word*)lf[27]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[28],lf[25],((C_word*)t0)[3],t3);}}
else{
/* data-structures.scm:190: ##sys#signal-hook */
t4=*((C_word*)lf[27]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[28],lf[25],((C_word*)t0)[3],t2);}}}

/* f_1474 in rec in compose in k1345 */
static void C_ccall f_1474(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_1474r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1474r(t0,t1,t2);}}

static void C_ccall f_1474r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1480,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word)li14),tmp=(C_word)a,a+=6,tmp);
/* data-structures.scm:72: call-with-values */
C_call_with_values(4,0,t1,t3,((C_word*)t0)[4]);}

/* alist-update! in k1345 */
static void C_ccall f_1996(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr5r,(void*)f_1996r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_1996r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_1996r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(10);
t6=C_i_nullp(t5);
t7=(C_truep(t6)?*((C_word*)lf[30]+1):C_i_car(t5));
t8=t7;
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2003,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t10=C_eqp(*((C_word*)lf[31]+1),t8);
if(C_truep(t10)){
t11=t9;
f_2003(t11,*((C_word*)lf[32]+1));}
else{
t11=C_eqp(*((C_word*)lf[30]+1),t8);
if(C_truep(t11)){
t12=t9;
f_2003(t12,*((C_word*)lf[33]+1));}
else{
t12=C_eqp(*((C_word*)lf[34]+1),t8);
t13=t9;
f_2003(t13,(C_truep(t12)?*((C_word*)lf[35]+1):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2035,a[2]=t8,a[3]=((C_word)li46),tmp=(C_word)a,a+=4,tmp)));}}}

/* k2355 in rev-string-append in reverse-string-append in k1345 */
static void C_ccall f_2357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2357,2,t0,t1);}
t2=t1;
t3=C_i_string_length(t2);
t4=C_fixnum_difference(t3,((C_word*)t0)[2]);
t5=C_fixnum_difference(t4,((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2366,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word)li55),tmp=(C_word)a,a+=6,tmp);
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,f_2366(t6,C_fix(0),t5));}

/* compose in k1345 */
static void C_ccall f_1463(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_1463r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1463r(t0,t1,t2);}}

static void C_ccall f_1463r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1466,a[2]=t4,a[3]=((C_word)li16),tmp=(C_word)a,a+=4,tmp));
if(C_truep(C_i_nullp(t2))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,*((C_word*)lf[7]+1));}
else{
C_apply(4,0,t1,((C_word*)t4)[1],t2);}}

/* rec in compose in k1345 */
static void C_ccall f_1466(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_1466r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1466r(t0,t1,t2,t3);}}

static void C_ccall f_1466r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
if(C_truep(C_i_nullp(t3))){
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1474,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=((C_word)li15),tmp=(C_word)a,a+=6,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k1459 */
static void C_ccall f_1461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_not(t1));}

/* k3319 in collect in string-translate* in k1345 */
static void C_ccall f_3321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm:510: ##sys#fragments->string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[74]+1)))(4,*((C_word*)lf[74]+1),((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k1822 in doloop198 in loop in k1779 in chop in k1345 */
static void C_ccall f_1824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1824,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1828,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_fixnum_difference(((C_word*)t0)[3],((C_word*)t0)[4]);
/* data-structures.scm:167: loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_1789(t5,t3,((C_word*)t0)[6],t4);}

/* k1826 in k1822 in doloop198 in loop in k1779 in chop in k1345 */
static void C_ccall f_1828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1828,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* loop in k2355 in rev-string-append in reverse-string-append in k1345 */
static C_word C_fcall f_2366(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_stack_overflow_check;
loop:
if(C_truep(C_fixnum_lessp(t1,((C_word*)t0)[2]))){
t3=C_i_string_ref(((C_word*)t0)[3],t1);
t4=C_i_string_set(((C_word*)t0)[4],t2,t3);
t5=C_fixnum_plus(t1,C_fix(1));
t6=C_fixnum_plus(t2,C_fix(1));
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}
else{
return(((C_word*)t0)[4]);}}

/* k4253 in binary-search in k1345 */
static void C_ccall f_4255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_4181(t3,t2);}

/* k3401 in loop in collect in string-translate* in k1345 */
static void C_ccall f_3403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3403,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t4=((C_word*)t0)[3];
f_3377(t4,t3);}

/* sort in k1345 */
static void C_ccall f_3965(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3965,4,t0,t1,t2,t3);}
if(C_truep(C_i_vectorp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3979,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3983,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm:709: vector->list */
t6=*((C_word*)lf[83]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3990,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm:710: append */
t5=*((C_word*)lf[86]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_SCHEME_END_OF_LIST);}}

/* k2321 in loop in k2297 in rassoc in k1345 */
static void C_ccall f_2323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=C_slot(((C_word*)t0)[4],C_fix(1));
/* data-structures.scm:261: loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2304(t3,((C_word*)t0)[2],t2);}}

/* k3997 in visit in topological-sort in k1345 */
static void C_ccall f_3999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3999,2,t0,t1);}
t2=C_eqp(t1,lf[88]);
if(C_truep(t2)){
t3=C_a_i_cons(&a,2,lf[89],lf[90]);
t4=t3;
t5=C_a_i_cons(&a,2,lf[89],lf[91]);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4048,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t6,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* data-structures.scm:727: reverse */
t8=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t0)[4]);}
else{
t3=C_eqp(t1,lf[99]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[5]);}
else{
t4=((C_word*)t0)[6];
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4061,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t4)){
t6=t5;
f_4061(2,t6,t4);}
else{
/* data-structures.scm:733: alist-ref */
t6=*((C_word*)lf[40]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,((C_word*)t0)[2],((C_word*)t0)[9],((C_word*)t0)[7],C_SCHEME_END_OF_LIST);}}}}

/* visit in topological-sort in k1345 */
static void C_fcall f_3995(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3995,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3999,a[2]=t3,a[3]=t1,a[4]=t5,a[5]=t6,a[6]=t4,a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[3],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t8=C_i_car(t6);
/* data-structures.scm:720: alist-ref */
t9=*((C_word*)lf[40]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t7,t3,t8,((C_word*)t0)[2]);}

/* topological-sort in k1345 */
static void C_ccall f_3992(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3992,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3995,a[2]=t3,a[3]=t5,a[4]=((C_word)li106),tmp=(C_word)a,a+=5,tmp));
t7=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4139,a[2]=t9,a[3]=t5,a[4]=((C_word)li107),tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_4139(t11,t1,t2,t7);}

/* k3988 in sort in k1345 */
static void C_ccall f_3990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm:710: sort! */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* doloop198 in loop in k1779 in chop in k1345 */
static void C_fcall f_1810(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1810,NULL,5,t0,t1,t2,t3,t4);}
t5=C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1824,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* data-structures.scm:167: reverse */
t7=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}
else{
t6=C_slot(t3,C_fix(0));
t7=C_a_i_cons(&a,2,t6,t2);
t8=C_slot(t3,C_fix(1));
t9=C_fixnum_difference(t4,C_fix(1));
t12=t1;
t13=t7;
t14=t8;
t15=t9;
t1=t12;
t2=t13;
t3=t14;
t4=t15;
goto loop;}}

/* k4203 in loop in k4179 in binary-search in k1345 */
static void C_ccall f_4205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
if(C_truep(C_fixnum_lessp(t1,C_fix(0)))){
t3=C_eqp(((C_word*)t0)[4],((C_word*)t0)[3]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
/* data-structures.scm:773: loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4195(t4,((C_word*)t0)[2],((C_word*)t0)[6],((C_word*)t0)[3]);}}
else{
t3=C_eqp(((C_word*)t0)[6],((C_word*)t0)[3]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
/* data-structures.scm:774: loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4195(t4,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);}}}}

/* k3977 in sort in k1345 */
static void C_ccall f_3979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm:709: list->vector */
t2=*((C_word*)lf[85]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* loop in k1861 in join in k1345 */
static void C_fcall f_1871(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1871,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=t3;
t5=C_slot(t2,C_fix(1));
if(C_truep(C_i_nullp(t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t4);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1906,a[2]=t1,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm:181: loop */
t8=t6;
t9=t5;
t1=t8;
t2=t9;
goto loop;}}
else{
/* data-structures.scm:175: ##sys#error-not-a-proper-list */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[24]+1)))(3,*((C_word*)lf[24]+1),t1,t2);}}}

/* queue-add! in k1345 */
static void C_ccall f_4336(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4336,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[102],lf[110]);
t5=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4346,a[2]=t2,a[3]=t6,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=C_slot(t2,C_fix(1));
t9=C_eqp(C_SCHEME_END_OF_LIST,t8);
if(C_truep(t9)){
t10=t7;
f_4346(t10,C_i_setslot(t2,C_fix(1),t6));}
else{
t10=C_slot(t2,C_fix(2));
t11=t7;
f_4346(t11,C_i_setslot(t10,C_fix(1),t6));}}

/* instring in string-translate in k1345 */
static void C_fcall f_3093(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3093,NULL,2,t1,t2);}
t3=C_block_size(t2);
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3098,a[2]=t4,a[3]=t2,a[4]=((C_word)li83),tmp=(C_word)a,a+=5,tmp));}

/* f_3098 in instring in string-translate in k1345 */
static void C_ccall f_3098(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3098,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3104,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word)li82),tmp=(C_word)a,a+=6,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_3104(t3,C_fix(0)));}

/* string-translate in k1345 */
static void C_ccall f_3090(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3090r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3090r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3090r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(12);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3093,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3128,a[2]=t2,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_charp(t3))){
t7=t6;
f_3128(2,t7,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3270,a[2]=t3,a[3]=((C_word)li86),tmp=(C_word)a,a+=4,tmp));}
else{
if(C_truep(C_i_pairp(t3))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3287,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* list->string */
t8=*((C_word*)lf[72]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}
else{
t7=C_i_check_string_2(t3,lf[69]);
/* data-structures.scm:471: instring */
f_3093(t6,t3);}}}

/* k4344 in queue-add! in k1345 */
static void C_fcall f_4346(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_i_setslot(((C_word*)t0)[2],C_fix(2),((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[2],C_fix(3));
t4=C_fixnum_plus(t3,C_fix(1));
t5=C_i_set_i_slot(((C_word*)t0)[2],C_fix(3),t4);
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}

/* k3981 in sort in k1345 */
static void C_ccall f_3983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm:709: sort! */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* doloop932 in k4572 in queue-push-back-list! in k1345 */
static C_word C_fcall f_4605(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_overflow_check;
loop:
t2=C_slot(t1,C_fix(1));
t3=C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
return(t4);}
else{
t4=C_slot(t1,C_fix(1));
t7=t4;
t1=t7;
goto loop;}}

/* list->queue in k1345 */
static void C_ccall f_4466(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4466,3,t0,t1,t2);}
t3=C_i_check_list_2(t2,lf[114]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4477,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t2;
t7=C_u_i_length(t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_record4(&a,4,lf[102],t2,C_SCHEME_END_OF_LIST,t7));}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4487,a[2]=t7,a[3]=t2,a[4]=((C_word)li121),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_4487(t9,t4,t2);}}

/* collect in string-translate* in k1345 */
static void C_fcall f_3307(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3307,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3321,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_fixnum_greaterp(t2,t3))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3335,a[2]=t6,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm:514: ##sys#substring */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[64]+1)))(5,*((C_word*)lf[64]+1),t8,((C_word*)t0)[3],t3,t2);}
else{
t8=((C_word*)t6)[1];
/* data-structures.scm:512: ##sys#fast-reverse */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[75]+1)))(3,*((C_word*)lf[75]+1),t7,t8);}}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3340,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t6,a[7]=((C_word*)t0)[3],a[8]=t8,a[9]=((C_word)li88),tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_3340(t10,t1,((C_word*)t0)[5]);}}

/* ->string in k1345 */
static void C_ccall f_2413(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2413,3,t0,t1,t2);}
if(C_truep(C_i_stringp(t2))){
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep(C_i_symbolp(t2))){
/* data-structures.scm:287: symbol->string */
t3=*((C_word*)lf[45]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
if(C_truep(C_charp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_string(&a,1,t2));}
else{
if(C_truep(C_i_numberp(t2))){
/* data-structures.scm:289: ##sys#number->string */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[46]+1)))(3,*((C_word*)lf[46]+1),t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2450,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm:291: open-output-string */
t4=*((C_word*)lf[49]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}}}}

/* conc in k1345 */
static void C_ccall f_2458(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr2r,(void*)f_2458r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2458r(t0,t1,t2);}}

static void C_ccall f_2458r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(16);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=*((C_word*)lf[44]+1);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2466,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2468,a[2]=t6,a[3]=t10,a[4]=t4,a[5]=t7,a[6]=((C_word)li59),tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_2468(t12,t8,t2);}

/* k2451 in k2448 in ->string in k1345 */
static void C_ccall f_2453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm:293: get-output-string */
t2=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2448 in ->string in k1345 */
static void C_ccall f_2450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2450,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2453,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm:292: display */
t4=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],t2);}

/* k2464 in conc in k1345 */
static void C_ccall f_2466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[51]+1),t1);}

/* map-loop362 in conc in k1345 */
static void C_fcall f_2468(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2468,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2497,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* data-structures.scm:297: g368 */
t5=((C_word*)t0)[5];
((C_proc3)C_fast_retrieve_proc(t5))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* loop in k2297 in rassoc in k1345 */
static void C_fcall f_2304(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2304,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=t3;
t5=C_i_check_pair_2(t4,lf[41]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2323,a[2]=t1,a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t7=C_slot(t4,C_fix(1));
/* data-structures.scm:259: tst */
t8=((C_word*)t0)[3];
((C_proc4)C_fast_retrieve_proc(t8))(4,t8,t6,((C_word*)t0)[4],t7);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k4495 in doloop908 in list->queue in k1345 */
static void C_ccall f_4497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4487(t3,((C_word*)t0)[4],t2);}

/* loop in queue->list in k1345 */
static void C_fcall f_4439(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4439,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
/* data-structures.scm:845: ##sys#fast-reverse */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[75]+1)))(3,*((C_word*)lf[75]+1),t1,t3);}
else{
t4=C_slot(t2,C_fix(1));
t5=C_slot(t2,C_fix(0));
t6=C_a_i_cons(&a,2,t5,t3);
/* data-structures.scm:846: loop */
t8=t1;
t9=t4;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}

/* step in sort! in k1345 */
static void C_fcall f_3840(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3840,NULL,3,t0,t1,t2);}
if(C_truep(C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3850,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
C_quotient(4,0,t3,t2,C_fix(2));}
else{
if(C_truep(C_i_nequalp(t2,C_fix(2)))){
t3=C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t4=t3;
t5=C_i_cadr(((C_word*)((C_word*)t0)[4])[1]);
t6=t5;
t7=((C_word*)((C_word*)t0)[4])[1];
t8=((C_word*)((C_word*)t0)[4])[1];
t9=C_u_i_cdr(t8);
t10=C_mutate2(((C_word *)((C_word*)t0)[4])+1,C_u_i_cdr(t9));
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3888,a[2]=t7,a[3]=t6,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* data-structures.scm:677: less? */
t12=((C_word*)t0)[2];
((C_proc4)C_fast_retrieve_proc(t12))(4,t12,t11,t6,t4);}
else{
if(C_truep(C_i_nequalp(t2,C_fix(1)))){
t3=((C_word*)((C_word*)t0)[4])[1];
t4=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t4);
t6=C_i_set_cdr(t3,C_SCHEME_END_OF_LIST);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}}}}

/* ##sys#substring-index-ci in k1345 */
static void C_ccall f_2559(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2559,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2565,a[2]=t2,a[3]=t3,a[4]=((C_word)li65),tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm:323: traverse */
f_2503(t1,t2,t3,t4,t5,lf[55]);}

/* a2555 in substring-index in k1345 */
static void C_ccall f_2556(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2556,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_substring_compare(((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0),t2,t3));}

/* ##sys#substring-index in k1345 */
static void C_ccall f_2550(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2550,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2556,a[2]=t2,a[3]=t3,a[4]=((C_word)li63),tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm:317: traverse */
f_2503(t1,t2,t3,t4,t5,lf[53]);}

/* k4034 in k4046 in k3997 in visit in topological-sort in k1345 */
static void C_ccall f_4036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[31],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4036,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[89],lf[93]);
t3=C_a_i_list(&a,8,((C_word*)t0)[2],lf[94],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t1,t2,lf[87]);
t4=C_a_i_record3(&a,3,lf[95],lf[96],t3);
/* data-structures.scm:722: ##sys#abort */
t5=*((C_word*)lf[97]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,((C_word*)t0)[6],t4);}

/* substring-index in k1345 */
static void C_ccall f_2568(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4r,(void*)f_2568r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2568r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2568r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
if(C_truep(C_i_nullp(t4))){
/* data-structures.scm:329: ##sys#substring-index */
t5=*((C_word*)lf[52]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,t3,C_fix(0));}
else{
t5=C_i_car(t4);
/* data-structures.scm:329: ##sys#substring-index */
t6=*((C_word*)lf[52]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,t3,t5);}}

/* a2564 in substring-index-ci in k1345 */
static void C_ccall f_2565(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2565,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_substring_compare_case_insensitive(((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0),t2,t3));}

/* loop */
static void C_fcall f_1546(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1546,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}
else{
if(C_truep(C_i_not_pair_p(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1565,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* data-structures.scm:94: pred */
t5=((C_word*)t0)[3];
((C_proc3)C_fast_retrieve_proc(t5))(3,t5,t3,t4);}}}

/* f_1540 in list-of? in k1345 */
static void C_ccall f_1540(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1540,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1546,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word)li21),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1546(t6,t1,t2);}

/* k2535 in loop in traverse in k1345 */
static void C_ccall f_2537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t3=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* data-structures.scm:313: loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2524(t4,((C_word*)t0)[2],t2,t3);}}

/* list-of? in k1345 */
static void C_ccall f_1538(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1538,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1540,a[2]=t2,a[3]=((C_word)li22),tmp=(C_word)a,a+=4,tmp));}

/* k1534 in k1531 */
static void C_ccall f_1536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm:87: h */
t2=((C_word*)t0)[2];
((C_proc3)C_fast_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],t1);}

/* k1531 */
static void C_ccall f_1533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1533,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1536,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm:87: g115 */
t3=t1;
((C_proc3)C_fast_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}

/* k2495 in map-loop362 in conc in k1345 */
static void C_ccall f_2497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2497,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_2468(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_2468(t6,((C_word*)t0)[5],t5);}}

/* k3851 in k3848 in step in sort! in k1345 */
static void C_ccall f_3853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3853,2,t0,t1);}
t2=t1;
t3=C_a_i_minus(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3859,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm:670: step */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3840(t5,t4,t3);}

/* k3857 in k3851 in k3848 in step in sort! in k1345 */
static void C_ccall f_3859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm:671: merge! */
t2=*((C_word*)lf[81]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}

/* k3848 in step in sort! in k1345 */
static void C_ccall f_3850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3850,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3853,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* data-structures.scm:668: step */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3840(t4,t3,t2);}

/* f_1525 in loop in o in k1345 */
static void C_ccall f_1525(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1525,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1533,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm:87: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1511(t4,t3,((C_word*)t0)[4]);}

/* k4101 in walk in k4059 in k3997 in visit in topological-sort in k1345 */
static void C_ccall f_4103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm:740: walk */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4067(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* loop */
static void C_fcall f_1360(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1360,NULL,3,t0,t1,t2);}
t3=C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1376,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm:41: g74 */
t6=t4;
((C_proc3)C_fast_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[3]);}}

/* k3886 in step in sort! in k1345 */
static void C_ccall f_3888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_truep(t1)){
t2=C_i_setslot(((C_word*)t0)[2],C_fix(0),((C_word*)t0)[3]);
t3=C_u_i_cdr(((C_word*)t0)[2]);
t4=C_i_set_car(t3,((C_word*)t0)[4]);
t5=C_u_i_cdr(((C_word*)t0)[2]);
t6=C_i_set_cdr(t5,C_SCHEME_END_OF_LIST);
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,((C_word*)t0)[2]);}
else{
t2=C_u_i_cdr(((C_word*)t0)[2]);
t3=C_i_set_cdr(t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}}

/* queue-empty? in k1345 */
static void C_ccall f_4281(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4281,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[102],lf[105]);
t4=C_slot(t2,C_fix(1));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_eqp(C_SCHEME_END_OF_LIST,t4));}

/* string-compare3 in k1345 */
static void C_ccall f_2598(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2598,4,t0,t1,t2,t3);}
t4=C_i_check_string_2(t2,lf[56]);
t5=C_i_check_string_2(t3,lf[56]);
t6=C_block_size(t2);
t7=C_block_size(t3);
t8=C_fixnum_difference(t6,t7);
t9=C_fixnum_lessp(t8,C_fix(0));
t10=(C_truep(t9)?t6:t7);
t11=C_string_compare(t2,t3,t10);
t12=C_eqp(t11,C_fix(0));
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_truep(t12)?t8:t11));}

/* loop in o in k1345 */
static void C_fcall f_1511(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1511,NULL,3,t0,t1,t2);}
t3=C_slot(t2,C_fix(0));
t4=t3;
t5=C_slot(t2,C_fix(1));
t6=t5;
if(C_truep(C_i_nullp(t6))){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t4);}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1525,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=((C_word)li18),tmp=(C_word)a,a+=6,tmp);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* f_1354 in conjoin in k1345 */
static void C_ccall f_1354(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1354,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1360,a[2]=t4,a[3]=t2,a[4]=((C_word)li1),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1360(t6,t1,((C_word*)t0)[2]);}

/* conjoin in k1345 */
static void C_ccall f_1352(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1352r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1352r(t0,t1,t2);}}

static void C_ccall f_1352r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a=C_alloc(4);
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1354,a[2]=t2,a[3]=((C_word)li2),tmp=(C_word)a,a+=4,tmp));}

/* queue-length in k1345 */
static void C_ccall f_4272(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4272,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[102],lf[104]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(3)));}

/* make-queue in k1345 */
static void C_ccall f_4260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4260,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_record4(&a,4,lf[102],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_fix(0)));}

/* traverse in k1345 */
static void C_fcall f_2503(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2503,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=C_i_check_string_2(t2,t6);
t8=C_i_check_string_2(t3,t6);
t9=C_block_size(t3);
t10=t9;
t11=C_block_size(t2);
t12=t11;
t13=C_i_check_exact_2(t4,t6);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2524,a[2]=t10,a[3]=t15,a[4]=t5,a[5]=t12,a[6]=((C_word)li61),tmp=(C_word)a,a+=7,tmp));
t17=((C_word*)t15)[1];
f_2524(t17,t1,t4,t12);}

/* queue? in k1345 */
static void C_ccall f_4266(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4266,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_structurep(t2,lf[102]));}

/* f_1453 in complement in k1345 */
static void C_ccall f_1453(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1453r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1453r(t0,t1,t2);}}

static void C_ccall f_1453r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1461,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_apply(4,0,t3,((C_word*)t0)[2],t2);}

/* complement in k1345 */
static void C_ccall f_1451(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1451,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1453,a[2]=t2,a[3]=((C_word)li12),tmp=(C_word)a,a+=4,tmp));}

/* loop */
static void C_fcall f_1393(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1393,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1406,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm:48: g86 */
t5=t3;
((C_proc3)C_fast_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[3]);}}

/* flip in k1345 */
static void C_ccall f_1443(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1443,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1445,a[2]=t2,a[3]=((C_word)li10),tmp=(C_word)a,a+=4,tmp));}

/* f_1445 in flip in k1345 */
static void C_ccall f_1445(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1445,4,t0,t1,t2,t3);}
/* data-structures.scm:61: proc */
t4=((C_word*)t0)[2];
((C_proc4)C_fast_retrieve_proc(t4))(4,t4,t1,t3,t2);}

/* k4508 in doloop908 in list->queue in k1345 */
static void C_fcall f_4510(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* data-structures.scm:858: ##sys#error-not-a-proper-list */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[24]+1)))(4,*((C_word*)lf[24]+1),((C_word*)t0)[2],((C_word*)t0)[3],lf[114]);}
else{
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[5])[1];
f_4487(t3,((C_word*)t0)[6],t2);}}

/* disjoin in k1345 */
static void C_ccall f_1385(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1385r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1385r(t0,t1,t2);}}

static void C_ccall f_1385r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a=C_alloc(4);
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1387,a[2]=t2,a[3]=((C_word)li5),tmp=(C_word)a,a+=4,tmp));}

/* f_1387 in disjoin in k1345 */
static void C_ccall f_1387(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1387,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1393,a[2]=t4,a[3]=t2,a[4]=((C_word)li4),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1393(t6,t1,((C_word*)t0)[2]);}

/* ##sys#substring=? in k1345 */
static void C_ccall f_2660(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[7],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_2660,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_i_check_string_2(t2,lf[59]);
t8=C_i_check_string_2(t3,lf[59]);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2670,a[2]=t4,a[3]=t5,a[4]=t1,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t10=t9;
f_2670(t10,t6);}
else{
t10=C_block_size(t2);
t11=C_fixnum_difference(t10,t4);
t12=C_block_size(t3);
t13=C_fixnum_difference(t12,t5);
t14=t9;
f_2670(t14,C_i_fixnum_min(t11,t13));}}

/* f_1435 in constantly in k1345 */
static void C_ccall f_1435(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1435,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* f_1433 in constantly in k1345 */
static void C_ccall f_1433(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1433,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* queue-push-back! in k1345 */
static void C_ccall f_4524(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4524,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[102],lf[115]);
t5=C_slot(t2,C_fix(1));
t6=C_a_i_cons(&a,2,t3,t5);
t7=C_i_setslot(t2,C_fix(1),t6);
t8=C_slot(t2,C_fix(2));
t9=C_eqp(C_SCHEME_END_OF_LIST,t8);
t10=(C_truep(t9)?C_i_setslot(t2,C_fix(2),t6):C_SCHEME_UNDEFINED);
t11=C_slot(t2,C_fix(3));
t12=C_fixnum_plus(t11,C_fix(1));
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_i_set_i_slot(t2,C_fix(3),t12));}

/* k1374 in loop */
static void C_ccall f_1376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[2],C_fix(1));
/* data-structures.scm:46: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1360(t3,((C_word*)t0)[4],t2);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4475 in list->queue in k1345 */
static void C_ccall f_4477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4477,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_u_i_length(t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[102],((C_word*)t0)[2],t1,t3));}

/* k2004 in k2001 in alist-update! in k1345 */
static void C_ccall f_2006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2006,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_setslot(t1,C_fix(1),((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[2]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,t2,((C_word*)t0)[3]));}}

/* f_1586 in each in k1345 */
static void C_ccall f_1586(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1586,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[11]+1));}

/* constantly in k1345 */
static void C_ccall f_1422(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1422r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1422r(t0,t1,t2);}}

static void C_ccall f_1422r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(4);
t3=t2;
t4=C_u_i_length(t3);
t5=C_eqp(C_fix(1),t4);
if(C_truep(t5)){
t6=C_i_car(t2);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1433,a[2]=t7,a[3]=((C_word)li7),tmp=(C_word)a,a+=4,tmp);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1435,a[2]=t2,a[3]=((C_word)li8),tmp=(C_word)a,a+=4,tmp);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* queue-first in k1345 */
static void C_ccall f_4294(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4294,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[102],lf[106]);
t4=C_slot(t2,C_fix(1));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4304,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_eqp(C_SCHEME_END_OF_LIST,t5);
if(C_truep(t7)){
/* data-structures.scm:808: ##sys#error */
t8=*((C_word*)lf[20]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t6,lf[106],lf[107],t2);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_slot(t5,C_fix(0)));}}

/* k3657 in loop in merge in k1345 */
static void C_ccall f_3659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3659,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_i_nullp(((C_word*)t0)[2]))){
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,((C_word*)t0)[6],t2));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3679,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(((C_word*)t0)[2]);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
/* data-structures.scm:616: loop */
t6=((C_word*)((C_word*)t0)[7])[1];
f_3652(t6,t2,((C_word*)t0)[3],((C_word*)t0)[4],t3,t5);}}
else{
if(C_truep(C_i_nullp(((C_word*)t0)[4]))){
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[2]);
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,((C_word*)t0)[3],t2));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3705,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(((C_word*)t0)[4]);
t4=((C_word*)t0)[4];
t5=C_u_i_cdr(t4);
/* data-structures.scm:620: loop */
t6=((C_word*)((C_word*)t0)[7])[1];
f_3652(t6,t2,t3,t5,((C_word*)t0)[6],((C_word*)t0)[2]);}}}

/* k2001 in alist-update! in k1345 */
static void C_fcall f_2003(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2003,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2006,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* data-structures.scm:212: aq */
t3=t1;
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],((C_word*)t0)[3]);}

/* k3922 in sort! in k1345 */
static void C_ccall f_3924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3924,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3931,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm:693: step */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3840(t4,t3,((C_word*)t0)[6]);}

/* loop in merge in k1345 */
static void C_fcall f_3652(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3652,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3659,a[2]=t5,a[3]=t2,a[4]=t3,a[5]=t1,a[6]=t4,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* data-structures.scm:613: less? */
t7=((C_word*)t0)[3];
((C_proc4)C_fast_retrieve_proc(t7))(4,t7,t6,t4,t2);}

/* doloop908 in list->queue in k1345 */
static void C_fcall f_4487(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4487,NULL,3,t0,t1,t2);}
t3=C_slot(t2,C_fix(1));
t4=C_eqp(t3,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t2;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4497,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_blockp(t2);
t7=C_i_not(t6);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4510,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t7)){
t9=t8;
f_4510(t9,t7);}
else{
t9=C_pairp(t2);
t10=t8;
f_4510(t10,C_i_not(t9));}}}

/* k2055 in loop */
static void C_ccall f_2057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=C_slot(((C_word*)t0)[4],C_fix(1));
/* data-structures.scm:211: loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2041(t3,((C_word*)t0)[2],t2);}}

/* each in k1345 */
static void C_ccall f_1578(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1578r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1578r(t0,t1,t2);}}

static void C_ccall f_1578r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1586,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_slot(t2,C_fix(1));
t4=C_i_nullp(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?C_slot(t2,C_fix(0)):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1600,a[2]=t2,a[3]=((C_word)li26),tmp=(C_word)a,a+=4,tmp)));}}

/* k1697 in loop in intersperse in k1345 */
static void C_ccall f_1699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1699,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,((C_word*)t0)[4],t2));}

/* substring=? in k1345 */
static void C_ccall f_2697(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4r,(void*)f_2697r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2697r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2697r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_fix(0):C_i_car(t4));
t7=C_i_nullp(t4);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t4));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?C_fix(0):C_i_car(t8));
t11=C_i_nullp(t8);
t12=(C_truep(t11)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t13=C_i_nullp(t12);
t14=(C_truep(t13)?C_SCHEME_FALSE:C_i_car(t12));
if(C_truep(C_i_nullp(t12))){
/* data-structures.scm:373: ##sys#substring=? */
t15=*((C_word*)lf[58]+1);
((C_proc7)(void*)(*((C_word*)t15+1)))(7,t15,t1,t2,t3,t6,t10,t14);}
else{
t15=C_i_cdr(t12);
/* data-structures.scm:373: ##sys#substring=? */
t16=*((C_word*)lf[58]+1);
((C_proc7)(void*)(*((C_word*)t16+1)))(7,t16,t1,t2,t3,t6,t10,t14);}}

/* k1563 in loop */
static void C_ccall f_1565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[2],C_fix(1));
/* data-structures.scm:94: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1546(t3,((C_word*)t0)[4],t2);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1404 in loop */
static void C_ccall f_1406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_slot(((C_word*)t0)[3],C_fix(1));
/* data-structures.scm:53: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1393(t3,((C_word*)t0)[2],t2);}}

/* queue->list in k1345 */
static void C_ccall f_4426(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4426,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[102],lf[113]);
t4=C_slot(t2,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4439,a[2]=t6,a[3]=((C_word)li119),tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_4439(t8,t1,t4,C_SCHEME_END_OF_LIST);}

/* k3792 in k3789 in merge! in k1345 */
static void C_ccall f_3794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3789 in merge! in k1345 */
static void C_ccall f_3791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3791,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3794,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
if(C_truep(C_i_nullp(t4))){
t5=((C_word*)t0)[2];
t6=((C_word*)t0)[4];
t7=C_i_setslot(t5,C_fix(1),t6);
t8=((C_word*)t0)[2];
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
/* data-structures.scm:648: loop */
t7=((C_word*)((C_word*)t0)[5])[1];
f_3716(t7,t2,((C_word*)t0)[2],((C_word*)t0)[4],t6);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3812,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[4];
t4=C_u_i_cdr(t3);
if(C_truep(C_i_nullp(t4))){
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[2];
t7=C_i_setslot(t5,C_fix(1),t6);
t8=((C_word*)t0)[4];
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t5=((C_word*)t0)[4];
t6=C_u_i_cdr(t5);
/* data-structures.scm:653: loop */
t7=((C_word*)((C_word*)t0)[5])[1];
f_3716(t7,t2,((C_word*)t0)[4],t6,((C_word*)t0)[2]);}}}

/* f_2035 in alist-update! in k1345 */
static void C_ccall f_2035(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2035,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2041,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word)li45),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2041(t7,t1,t3);}

/* doloop798 in k3929 in k3922 in sort! in k1345 */
static void C_fcall f_3933(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(4);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3933,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}
else{
t4=C_i_car(t2);
t5=C_i_vector_set(((C_word*)t0)[2],t3,t4);
t6=t2;
t7=C_u_i_cdr(t6);
t8=C_a_i_plus(&a,2,t3,C_fix(1));
t10=t1;
t11=t7;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* k3929 in k3922 in sort! in k1345 */
static void C_ccall f_3931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3931,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3933,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word)li102),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3933(t5,((C_word*)t0)[3],t1,C_fix(0));}

/* substring-index-ci in k1345 */
static void C_ccall f_2583(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4r,(void*)f_2583r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2583r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2583r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
if(C_truep(C_i_nullp(t4))){
/* data-structures.scm:332: ##sys#substring-index-ci */
t5=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,t3,C_fix(0));}
else{
t5=C_i_car(t4);
/* data-structures.scm:332: ##sys#substring-index-ci */
t6=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,t3,t5);}}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_data_2dstructures_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_data_2dstructures_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("data_2dstructures_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1089)){
C_save(t1);
C_rereclaim2(1089*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,119);
lf[0]=C_h_intern(&lf[0],8,"identity");
lf[1]=C_h_intern(&lf[1],7,"conjoin");
lf[2]=C_h_intern(&lf[2],7,"disjoin");
lf[3]=C_h_intern(&lf[3],10,"constantly");
lf[4]=C_h_intern(&lf[4],4,"flip");
lf[5]=C_h_intern(&lf[5],10,"complement");
lf[6]=C_h_intern(&lf[6],7,"compose");
lf[7]=C_h_intern(&lf[7],6,"values");
lf[8]=C_h_intern(&lf[8],1,"o");
lf[9]=C_h_intern(&lf[9],8,"list-of\077");
lf[10]=C_h_intern(&lf[10],4,"each");
lf[11]=C_h_intern(&lf[11],19,"\003sysundefined-value");
lf[12]=C_h_intern(&lf[12],4,"any\077");
lf[13]=C_h_intern(&lf[13],5,"atom\077");
lf[14]=C_h_intern(&lf[14],5,"tail\077");
lf[15]=C_h_intern(&lf[15],11,"intersperse");
lf[16]=C_h_intern(&lf[16],7,"butlast");
lf[17]=C_h_intern(&lf[17],7,"flatten");
lf[18]=C_h_intern(&lf[18],4,"chop");
lf[19]=C_h_intern(&lf[19],7,"reverse");
lf[20]=C_h_intern(&lf[20],9,"\003syserror");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid numeric argument");
lf[22]=C_h_intern(&lf[22],4,"join");
lf[23]=C_h_intern(&lf[23],10,"\003sysappend");
lf[24]=C_h_intern(&lf[24],27,"\003syserror-not-a-proper-list");
lf[25]=C_h_intern(&lf[25],8,"compress");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000%bad argument type - not a proper list");
lf[27]=C_h_intern(&lf[27],15,"\003syssignal-hook");
lf[28]=C_h_intern(&lf[28],11,"\000type-error");
lf[29]=C_h_intern(&lf[29],13,"alist-update!");
lf[30]=C_h_intern(&lf[30],4,"eqv\077");
lf[31]=C_h_intern(&lf[31],3,"eq\077");
lf[32]=C_h_intern(&lf[32],4,"assq");
lf[33]=C_h_intern(&lf[33],4,"assv");
lf[34]=C_h_intern(&lf[34],6,"equal\077");
lf[35]=C_h_intern(&lf[35],5,"assoc");
lf[36]=C_h_intern(&lf[36],12,"alist-update");
lf[37]=C_h_intern(&lf[37],5,"error");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\021bad argument type");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\021bad argument type");
lf[40]=C_h_intern(&lf[40],9,"alist-ref");
lf[41]=C_h_intern(&lf[41],6,"rassoc");
lf[42]=C_h_intern(&lf[42],21,"reverse-string-append");
lf[43]=C_h_intern(&lf[43],11,"make-string");
lf[44]=C_h_intern(&lf[44],8,"->string");
lf[45]=C_h_intern(&lf[45],14,"symbol->string");
lf[46]=C_h_intern(&lf[46],18,"\003sysnumber->string");
lf[47]=C_h_intern(&lf[47],17,"get-output-string");
lf[48]=C_h_intern(&lf[48],7,"display");
lf[49]=C_h_intern(&lf[49],18,"open-output-string");
lf[50]=C_h_intern(&lf[50],4,"conc");
lf[51]=C_h_intern(&lf[51],13,"string-append");
lf[52]=C_h_intern(&lf[52],19,"\003syssubstring-index");
lf[53]=C_h_intern(&lf[53],15,"substring-index");
lf[54]=C_h_intern(&lf[54],22,"\003syssubstring-index-ci");
lf[55]=C_h_intern(&lf[55],18,"substring-index-ci");
lf[56]=C_h_intern(&lf[56],15,"string-compare3");
lf[57]=C_h_intern(&lf[57],18,"string-compare3-ci");
lf[58]=C_h_intern(&lf[58],15,"\003syssubstring=\077");
lf[59]=C_h_intern(&lf[59],11,"substring=\077");
lf[60]=C_h_intern(&lf[60],18,"\003syssubstring-ci=\077");
lf[61]=C_h_intern(&lf[61],14,"substring-ci=\077");
lf[62]=C_h_intern(&lf[62],12,"string-split");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\003\011\012 ");
lf[64]=C_h_intern(&lf[64],13,"\003syssubstring");
lf[65]=C_h_intern(&lf[65],18,"string-intersperse");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[68]=C_h_intern(&lf[68],19,"\003sysallocate-vector");
lf[69]=C_h_intern(&lf[69],16,"string-translate");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\037invalid translation destination");
lf[71]=C_h_intern(&lf[71],15,"\003sysmake-string");
lf[72]=C_h_intern(&lf[72],16,"\003syslist->string");
lf[73]=C_h_intern(&lf[73],17,"string-translate\052");
lf[74]=C_h_intern(&lf[74],21,"\003sysfragments->string");
lf[75]=C_h_intern(&lf[75],16,"\003sysfast-reverse");
lf[76]=C_h_intern(&lf[76],11,"string-chop");
lf[77]=C_h_intern(&lf[77],12,"string-chomp");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[79]=C_h_intern(&lf[79],7,"sorted\077");
lf[80]=C_h_intern(&lf[80],5,"merge");
lf[81]=C_h_intern(&lf[81],6,"merge!");
lf[82]=C_h_intern(&lf[82],5,"sort!");
lf[83]=C_h_intern(&lf[83],12,"vector->list");
lf[84]=C_h_intern(&lf[84],4,"sort");
lf[85]=C_h_intern(&lf[85],12,"list->vector");
lf[86]=C_h_intern(&lf[86],6,"append");
lf[87]=C_h_intern(&lf[87],16,"topological-sort");
lf[88]=C_h_intern(&lf[88],4,"grey");
lf[89]=C_h_intern(&lf[89],3,"exn");
lf[90]=C_h_intern(&lf[90],7,"message");
lf[91]=C_h_intern(&lf[91],9,"arguments");
lf[92]=C_h_intern(&lf[92],10,"call-chain");
lf[93]=C_h_intern(&lf[93],8,"location");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\016cycle detected");
lf[95]=C_h_intern(&lf[95],9,"condition");
lf[96]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\003\000\000\002\376\001\000\000\007runtime\376\003\000\000\002\376\001\000\000\005cycle\376\377\016");
lf[97]=C_h_intern(&lf[97],9,"\003sysabort");
lf[98]=C_h_intern(&lf[98],18,"\003sysget-call-chain");
lf[99]=C_h_intern(&lf[99],5,"black");
lf[100]=C_h_intern(&lf[100],13,"binary-search");
lf[101]=C_h_intern(&lf[101],10,"make-queue");
lf[102]=C_h_intern(&lf[102],5,"queue");
lf[103]=C_h_intern(&lf[103],6,"queue\077");
lf[104]=C_h_intern(&lf[104],12,"queue-length");
lf[105]=C_h_intern(&lf[105],12,"queue-empty\077");
lf[106]=C_h_intern(&lf[106],11,"queue-first");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\016queue is empty");
lf[108]=C_h_intern(&lf[108],10,"queue-last");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\016queue is empty");
lf[110]=C_h_intern(&lf[110],10,"queue-add!");
lf[111]=C_h_intern(&lf[111],13,"queue-remove!");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\016queue is empty");
lf[113]=C_h_intern(&lf[113],11,"queue->list");
lf[114]=C_h_intern(&lf[114],11,"list->queue");
lf[115]=C_h_intern(&lf[115],16,"queue-push-back!");
lf[116]=C_h_intern(&lf[116],21,"queue-push-back-list!");
lf[117]=C_h_intern(&lf[117],17,"register-feature!");
lf[118]=C_h_intern(&lf[118],15,"data-structures");
C_register_lf2(lf,119,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1347,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* data-structures.scm:33: register-feature! */
t3=*((C_word*)lf[117]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[118]);}

/* loop */
static void C_fcall f_2041(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2041,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=t3;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2057,a[2]=t1,a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t4))){
t6=C_slot(t4,C_fix(0));
/* data-structures.scm:209: cmp */
t7=((C_word*)t0)[3];
((C_proc4)C_fast_retrieve_proc(t7))(4,t7,t5,t6,((C_word*)t0)[4]);}
else{
t6=t5;
f_2057(2,t6,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k3551 in doloop727 in sorted? in k1345 */
static void C_ccall f_3553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3553,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_nequalp(((C_word*)t0)[3],((C_word*)t0)[4]));}
else{
t2=C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
t3=((C_word*)((C_word*)t0)[5])[1];
f_3543(t3,((C_word*)t0)[2],t2);}}

/* k2130 in loop in alist-update in k1345 */
static void C_ccall f_2132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2132,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,t2,t3));}
else{
t2=C_slot(((C_word*)t0)[6],C_fix(0));
t3=C_slot(((C_word*)t0)[6],C_fix(1));
t4=C_a_i_cons(&a,2,t2,t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2154,a[2]=((C_word*)t0)[5],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_slot(((C_word*)t0)[4],C_fix(1));
/* data-structures.scm:233: loop */
t8=((C_word*)((C_word*)t0)[7])[1];
f_2091(t8,t6,t7);}}

/* loop in traverse in k1345 */
static void C_fcall f_2524(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2524,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_fixnum_greaterp(t3,((C_word*)t0)[2]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2537,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* data-structures.scm:311: test */
t5=((C_word*)t0)[4];
((C_proc4)C_fast_retrieve_proc(t5))(4,t5,t4,t2,((C_word*)t0)[5]);}}

/* sort! in k1345 */
static void C_ccall f_3837(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[17],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3837,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3840,a[2]=t3,a[3]=t6,a[4]=t4,a[5]=((C_word)li101),tmp=(C_word)a,a+=6,tmp));
if(C_truep(C_i_vectorp(((C_word*)t4)[1]))){
t8=C_i_vector_length(((C_word*)t4)[1]);
t9=t8;
t10=((C_word*)t4)[1];
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3924,a[2]=t4,a[3]=t10,a[4]=t1,a[5]=t6,a[6]=t9,tmp=(C_word)a,a+=7,tmp);
/* data-structures.scm:692: vector->list */
t12=*((C_word*)lf[83]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,((C_word*)t4)[1]);}
else{
t8=C_i_length(((C_word*)t4)[1]);
/* data-structures.scm:698: step */
t9=((C_word*)t6)[1];
f_3840(t9,t1,t8);}}

/* doloop727 in sorted? in k1345 */
static void C_fcall f_3543(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3543,NULL,3,t0,t1,t2);}
t3=C_i_nequalp(t2,((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3553,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_3553(2,t5,t3);}
else{
t5=C_i_vector_ref(((C_word*)t0)[4],t2);
t6=C_a_i_minus(&a,2,t2,C_fix(1));
t7=C_i_vector_ref(((C_word*)t0)[4],t6);
/* data-structures.scm:590: less? */
t8=((C_word*)t0)[5];
((C_proc4)C_fast_retrieve_proc(t8))(4,t8,t4,t5,t7);}}

/* k4046 in k3997 in visit in topological-sort in k1345 */
static void C_ccall f_4048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4048,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_list1(&a,1,t2);
t4=t3;
t5=C_a_i_cons(&a,2,lf[89],lf[92]);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4036,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t6,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* data-structures.scm:728: ##sys#get-call-chain */
((C_proc2)C_fast_retrieve_proc(*((C_word*)lf[98]+1)))(2,*((C_word*)lf[98]+1),t7);}

/* k3446 in loop in string-chop in k1345 */
static void C_ccall f_3448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3448,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list1(&a,1,t1));}

/* k2668 in substring=? in k1345 */
static void C_fcall f_2670(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_check_exact_2(((C_word*)t0)[2],lf[59]);
t3=C_i_check_exact_2(((C_word*)t0)[3],lf[59]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_substring_compare(((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[2],((C_word*)t0)[3],t1));}

/* k3810 in k3789 in merge! in k1345 */
static void C_ccall f_3812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3126 in string-translate in k1345 */
static void C_ccall f_3128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3128,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3131,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t4=C_slot(((C_word*)t0)[4],C_fix(0));
if(C_truep(C_charp(t4))){
t5=t3;
f_3131(2,t5,t4);}
else{
if(C_truep(C_i_pairp(t4))){
/* list->string */
t5=*((C_word*)lf[72]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t5=C_i_check_string_2(t4,lf[69]);
t6=t3;
f_3131(2,t6,t4);}}}
else{
t4=t3;
f_3131(2,t4,C_SCHEME_FALSE);}}

/* loop in sorted? in k1345 */
static void C_fcall f_3592(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3592,NULL,4,t0,t1,t2,t3);}
t4=C_i_nullp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3616,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=C_i_car(t3);
/* data-structures.scm:596: less? */
t7=((C_word*)t0)[3];
((C_proc4)C_fast_retrieve_proc(t7))(4,t7,t5,t6,t2);}}

/* ##sys#substring-ci=? in k1345 */
static void C_ccall f_2757(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[7],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_2757,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_i_check_string_2(t2,lf[61]);
t8=C_i_check_string_2(t3,lf[61]);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2767,a[2]=t4,a[3]=t5,a[4]=t1,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t10=t9;
f_2767(t10,t6);}
else{
t10=C_block_size(t2);
t11=C_fixnum_difference(t10,t4);
t12=C_block_size(t3);
t13=C_fixnum_difference(t12,t5);
t14=t9;
f_2767(t14,C_i_fixnum_min(t11,t13));}}

/* loop */
static C_word C_fcall f_3104(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_stack_overflow_check;
loop:
if(C_truep(C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[2]))){
return(C_SCHEME_FALSE);}
else{
t2=C_subchar(((C_word*)t0)[3],t1);
t3=C_eqp(((C_word*)t0)[4],t2);
if(C_truep(t3)){
return(t1);}
else{
t4=C_fixnum_plus(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}}}

/* k4079 in walk in k4059 in k3997 in visit in topological-sort in k1345 */
static void C_ccall f_4081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4081,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_cons(&a,2,t1,t4));}

/* k2152 in k2130 in loop in alist-update in k1345 */
static void C_ccall f_2154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2154,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k3129 in k3126 in string-translate in k1345 */
static void C_ccall f_3131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3131,2,t0,t1);}
t2=t1;
t3=C_i_stringp(t2);
t4=(C_truep(t3)?C_block_size(t2):C_SCHEME_FALSE);
t5=t4;
t6=C_i_check_string_2(((C_word*)t0)[2],lf[69]);
t7=C_block_size(((C_word*)t0)[2]);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3143,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t5,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* ##sys#make-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[71]+1)))(4,*((C_word*)lf[71]+1),t9,t8,C_make_character(32));}

/* loop in topological-sort in k1345 */
static void C_fcall f_4139(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4139,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_cdr(t3));}
else{
t4=C_i_cdr(t2);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4160,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=C_i_caar(t2);
t8=t2;
t9=C_u_i_car(t8);
t10=C_u_i_cdr(t9);
/* data-structures.scm:751: visit */
t11=((C_word*)((C_word*)t0)[3])[1];
f_3995(t11,t6,t2,t7,t10,C_SCHEME_END_OF_LIST,t3);}}

/* walk in k4059 in k3997 in visit in topological-sort in k1345 */
static void C_fcall f_4067(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4067,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4081,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=C_i_car(t3);
/* data-structures.scm:737: alist-update! */
t6=*((C_word*)lf[29]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t4,((C_word*)t0)[2],lf[99],t5,((C_word*)t0)[3]);}
else{
t4=C_i_car(t2);
t5=t2;
t6=C_u_i_cdr(t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4103,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=C_a_i_cons(&a,2,t4,((C_word*)t0)[5]);
/* data-structures.scm:741: visit */
t9=((C_word*)((C_word*)t0)[6])[1];
f_3995(t9,t7,((C_word*)t0)[7],t4,C_SCHEME_FALSE,t8,t3);}}

/* string-chomp in k1345 */
static void C_ccall f_3477(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_3477r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3477r(t0,t1,t2,t3);}}

static void C_ccall f_3477r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?lf[78]:C_i_car(t3));
t6=C_i_check_string_2(t2,lf[77]);
t7=C_i_check_string_2(t5,lf[77]);
t8=C_block_size(t2);
t9=C_block_size(t5);
t10=C_fixnum_difference(t8,t9);
t11=C_fixnum_greater_or_equal_p(t8,t9);
t12=(C_truep(t11)?C_substring_compare(t2,t5,t10,C_fix(0),t9):C_SCHEME_FALSE);
if(C_truep(t12)){
/* data-structures.scm:557: ##sys#substring */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[64]+1)))(5,*((C_word*)lf[64]+1),t1,t2,C_fix(0),t10);}
else{
t13=t2;
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,t13);}}

/* k1861 in join in k1345 */
static void C_fcall f_1863(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1863,NULL,2,t0,t1);}
t2=t1;
t3=C_i_check_list_2(t2,lf[22]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1871,a[2]=t2,a[3]=t5,a[4]=((C_word)li41),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_1871(t7,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k4059 in k3997 in visit in topological-sort in k1345 */
static void C_ccall f_4061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4061,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],lf[88]);
t3=((C_word*)t0)[3];
t4=C_u_i_car(t3);
t5=C_a_i_cons(&a,2,t2,t4);
t6=((C_word*)t0)[3];
t7=C_u_i_cdr(t6);
t8=C_a_i_cons(&a,2,t5,t7);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4067,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t10,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li105),tmp=(C_word)a,a+=9,tmp));
t12=((C_word*)t10)[1];
f_4067(t12,((C_word*)t0)[8],t1,t8);}

/* string-split in k1345 */
static void C_ccall f_2854(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+20)){
C_save_and_reclaim((void*)tr3r,(void*)f_2854r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2854r(t0,t1,t2,t3);}}

static void C_ccall f_2854r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word *a=C_alloc(20);
t4=C_i_check_string_2(t2,lf[62]);
t5=C_i_nullp(t3);
t6=(C_truep(t5)?lf[63]:C_i_car(t3));
t7=t6;
t8=t3;
t9=C_u_i_length(t8);
t10=C_eqp(t9,C_fix(2));
t11=(C_truep(t10)?C_i_cadr(t3):C_SCHEME_FALSE);
t12=t11;
t13=C_block_size(t2);
t14=t13;
t15=C_i_check_string_2(t7,lf[62]);
t16=C_block_size(t7);
t17=t16;
t18=C_SCHEME_FALSE;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2875,a[2]=t19,a[3]=t2,a[4]=((C_word)li75),tmp=(C_word)a,a+=5,tmp);
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_set_block_item(t22,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2895,a[2]=t14,a[3]=t19,a[4]=t12,a[5]=t20,a[6]=t2,a[7]=t17,a[8]=t22,a[9]=t7,a[10]=((C_word)li77),tmp=(C_word)a,a+=11,tmp));
t24=((C_word*)t22)[1];
f_2895(t24,t1,C_fix(0),C_SCHEME_FALSE,C_fix(0));}

/* loop1 in string-intersperse in k1345 */
static void C_fcall f_3006(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3006,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_eqp(t2,C_SCHEME_END_OF_LIST))){
if(C_truep(C_eqp(((C_word*)t0)[2],C_SCHEME_END_OF_LIST))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[67]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3016,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=C_fixnum_difference(t3,((C_word*)t0)[4]);
/* data-structures.scm:433: ##sys#allocate-vector */
t6=*((C_word*)lf[68]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t4,t5,C_SCHEME_TRUE,C_make_character(32),C_SCHEME_FALSE);}}
else{
t4=(C_truep(C_blockp(t2))?C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_slot(t2,C_fix(0));
t6=C_i_check_string_2(t5,lf[65]);
t7=C_slot(t2,C_fix(1));
t8=C_block_size(t5);
t9=C_fixnum_plus(((C_word*)t0)[4],t3);
t10=C_fixnum_plus(t8,t9);
/* data-structures.scm:448: loop1 */
t14=t1;
t15=t7;
t16=t10;
t1=t14;
t2=t15;
t3=t16;
goto loop;}
else{
/* data-structures.scm:450: ##sys#error-not-a-proper-list */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[24]+1)))(3,*((C_word*)lf[24]+1),t1,((C_word*)t0)[2]);}}}

/* k4302 in queue-first in k1345 */
static void C_ccall f_4304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_slot(((C_word*)t0)[3],C_fix(0)));}

/* k3461 in k3457 in loop in string-chop in k1345 */
static void C_ccall f_3463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3463,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k3457 in loop in string-chop in k1345 */
static void C_ccall f_3459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3459,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3463,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_fixnum_difference(((C_word*)t0)[3],((C_word*)t0)[4]);
t5=C_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
/* data-structures.scm:544: loop */
t6=((C_word*)((C_word*)t0)[6])[1];
f_3428(t6,t3,t4,t5);}

/* substring-ci=? in k1345 */
static void C_ccall f_2794(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4r,(void*)f_2794r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2794r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2794r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_fix(0):C_i_car(t4));
t7=C_i_nullp(t4);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t4));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?C_fix(0):C_i_car(t8));
t11=C_i_nullp(t8);
t12=(C_truep(t11)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t13=C_i_nullp(t12);
t14=(C_truep(t13)?C_SCHEME_FALSE:C_i_car(t12));
if(C_truep(C_i_nullp(t12))){
/* data-structures.scm:387: ##sys#substring-ci=? */
t15=*((C_word*)lf[60]+1);
((C_proc7)(void*)(*((C_word*)t15+1)))(7,t15,t1,t2,t3,t6,t10,t14);}
else{
t15=C_i_cdr(t12);
/* data-structures.scm:387: ##sys#substring-ci=? */
t16=*((C_word*)lf[60]+1);
((C_proc7)(void*)(*((C_word*)t16+1)))(7,t16,t1,t2,t3,t6,t10,t14);}}

/* queue-last in k1345 */
static void C_ccall f_4315(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4315,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[102],lf[108]);
t4=C_slot(t2,C_fix(2));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4325,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_eqp(C_SCHEME_END_OF_LIST,t5);
if(C_truep(t7)){
/* data-structures.scm:816: ##sys#error */
t8=*((C_word*)lf[20]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t6,lf[108],lf[109],t2);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_slot(t5,C_fix(0)));}}

/* k3721 in loop in merge! in k1345 */
static void C_ccall f_3723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(C_truep(t1)){
t2=C_i_set_cdr(((C_word*)t0)[2],((C_word*)t0)[3]);
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
if(C_truep(C_i_nullp(t4))){
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[4];
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_i_setslot(t5,C_fix(1),t6));}
else{
t5=((C_word*)t0)[3];
t6=C_u_i_cdr(t5);
/* data-structures.scm:635: loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_3716(t7,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[4],t6);}}
else{
t2=C_i_set_cdr(((C_word*)t0)[2],((C_word*)t0)[4]);
t3=((C_word*)t0)[4];
t4=C_u_i_cdr(t3);
if(C_truep(C_i_nullp(t4))){
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_i_setslot(t5,C_fix(1),t6));}
else{
t5=((C_word*)t0)[4];
t6=C_u_i_cdr(t5);
/* data-structures.scm:641: loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_3716(t7,((C_word*)t0)[5],((C_word*)t0)[4],t6,((C_word*)t0)[3]);}}}

/* k2765 in substring-ci=? in k1345 */
static void C_fcall f_2767(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_check_exact_2(((C_word*)t0)[2],lf[61]);
t3=C_i_check_exact_2(((C_word*)t0)[3],lf[61]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_substring_compare_case_insensitive(((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[2],((C_word*)t0)[3],t1));}

/* k4179 in binary-search in k1345 */
static void C_fcall f_4181(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4181,NULL,2,t0,t1);}
t2=C_block_size(((C_word*)((C_word*)t0)[2])[1]);
if(C_truep(C_fixnum_greaterp(t2,C_fix(0)))){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4195,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word)li109),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_4195(t6,((C_word*)t0)[4],C_fix(0),t2);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k3141 in k3129 in k3126 in string-translate in k1345 */
static void C_ccall f_3143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3143,2,t0,t1);}
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3148,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word)li85),tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_3148(t6,((C_word*)t0)[7],C_fix(0),C_fix(0));}

/* string-compare3-ci in k1345 */
static void C_ccall f_2629(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2629,4,t0,t1,t2,t3);}
t4=C_i_check_string_2(t2,lf[57]);
t5=C_i_check_string_2(t3,lf[57]);
t6=C_block_size(t2);
t7=C_block_size(t3);
t8=C_fixnum_difference(t6,t7);
t9=C_fixnum_lessp(t8,C_fix(0));
t10=(C_truep(t9)?t6:t7);
t11=C_string_compare_case_insensitive(t2,t3,t10);
t12=C_eqp(t11,C_fix(0));
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_truep(t12)?t8:t11));}

/* f_2227 in alist-ref in k1345 */
static void C_ccall f_2227(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2227,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2233,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word)li50),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2233(t7,t1,t3);}

/* loop in k3141 in k3129 in k3126 in string-translate in k1345 */
static void C_fcall f_3148(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3148,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
if(C_truep(C_fixnum_lessp(t3,t2))){
/* data-structures.scm:487: ##sys#substring */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[64]+1)))(5,*((C_word*)lf[64]+1),t1,((C_word*)t0)[3],C_fix(0),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}}
else{
t4=C_subchar(((C_word*)t0)[4],t2);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3167,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=t4,tmp=(C_word)a,a+=10,tmp);
/* data-structures.scm:490: from */
t6=((C_word*)t0)[8];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}}

/* loop in merge! in k1345 */
static void C_fcall f_3716(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3716,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3723,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t6=C_i_car(t4);
t7=C_i_car(t3);
/* data-structures.scm:630: less? */
t8=((C_word*)t0)[3];
((C_proc4)C_fast_retrieve_proc(t8))(4,t8,t5,t6,t7);}

/* merge! in k1345 */
static void C_ccall f_3713(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3713,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3716,a[2]=t6,a[3]=t4,a[4]=((C_word)li99),tmp=(C_word)a,a+=5,tmp));
if(C_truep(C_i_nullp(t2))){
t8=t3;
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
if(C_truep(C_i_nullp(t3))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t2);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3791,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t9=C_i_car(t3);
t10=C_i_car(t2);
/* data-structures.scm:645: less? */
t11=t4;
((C_proc4)C_fast_retrieve_proc(t11))(4,t11,t8,t9,t10);}}}

/* loop */
static void C_fcall f_2233(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2233,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=t3;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2249,a[2]=t1,a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t4))){
t6=C_slot(t4,C_fix(0));
/* data-structures.scm:244: cmp */
t7=((C_word*)t0)[3];
((C_proc4)C_fast_retrieve_proc(t7))(4,t7,t5,t6,((C_word*)t0)[4]);}
else{
t6=t5;
f_2249(2,t6,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k3014 in loop1 in string-intersperse in k1345 */
static void C_ccall f_3016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3016,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3021,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word)li79),tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_3021(t3,((C_word*)t0)[5],C_fix(0)));}

/* k3703 in k3657 in loop in merge in k1345 */
static void C_ccall f_3705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3705,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* loop in string-split in k1345 */
static void C_fcall f_2895(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2895,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2905,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=C_fixnum_greaterp(t2,t4);
t7=(C_truep(t6)?t6:((C_word*)t0)[4]);
if(C_truep(t7)){
/* data-structures.scm:409: add */
t8=((C_word*)t0)[5];
f_2875(t8,t5,t4,t2,t3);}
else{
t8=((C_word*)((C_word*)t0)[3])[1];
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_truep(t8)?t8:C_SCHEME_END_OF_LIST));}}
else{
t5=C_subchar(((C_word*)t0)[6],t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2922,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[8],a[5]=t3,a[6]=t4,a[7]=((C_word*)t0)[9],a[8]=t5,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=t7,a[12]=((C_word)li76),tmp=(C_word)a,a+=13,tmp));
t9=((C_word*)t7)[1];
f_2922(t9,t1,C_fix(0));}}

/* k2203 in k2200 in alist-ref in k1345 */
static void C_ccall f_2205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_slot(t1,C_fix(1)):((C_word*)t0)[3]));}

/* loop in alist-update in k1345 */
static void C_fcall f_2091(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2091,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list1(&a,1,t3));}
else{
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=t3;
if(C_truep(C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2132,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=t4,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t6=C_slot(t4,C_fix(0));
/* data-structures.scm:229: cmp */
t7=((C_word*)t0)[5];
((C_proc4)C_fast_retrieve_proc(t7))(4,t7,t5,t6,((C_word*)t0)[2]);}
else{
/* data-structures.scm:228: error */
t5=*((C_word*)lf[37]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[36],lf[38],t4);}}
else{
/* data-structures.scm:224: error */
t3=*((C_word*)lf[37]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,lf[36],lf[39],t2);}}}

/* k2888 in add in string-split in k1345 */
static void C_ccall f_2890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2890,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)t0)[3],C_fix(1),t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k3333 in collect in string-translate* in k1345 */
static void C_ccall f_3335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3335,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]);
/* data-structures.scm:512: ##sys#fast-reverse */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[75]+1)))(3,*((C_word*)lf[75]+1),((C_word*)t0)[3],t2);}

/* k2200 in alist-ref in k1345 */
static void C_fcall f_2202(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2202,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2205,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm:247: aq */
t3=t1;
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* join in k1345 */
static void C_ccall f_1859(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1859r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1859r(t0,t1,t2,t3);}}

static void C_ccall f_1859r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1863,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(t3))){
t5=t3;
t6=t4;
f_1863(t6,C_u_i_car(t5));}
else{
t5=t4;
f_1863(t5,C_SCHEME_END_OF_LIST);}}

/* loop2 in k3014 in loop1 in string-intersperse in k1345 */
static C_word C_fcall f_3021(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_stack_overflow_check;
loop:
t3=C_slot(t1,C_fix(0));
t4=C_slot(t1,C_fix(1));
t5=C_block_size(t3);
t6=C_substring_copy(t3,((C_word*)t0)[2],C_fix(0),t5,t2);
t7=C_fixnum_plus(t2,t5);
if(C_truep(C_eqp(t4,C_SCHEME_END_OF_LIST))){
return(((C_word*)t0)[2]);}
else{
t8=C_substring_copy(((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),((C_word*)t0)[4],t7);
t9=C_fixnum_plus(t7,((C_word*)t0)[4]);
t11=t4;
t12=t9;
t1=t11;
t2=t12;
goto loop;}}

/* alist-update in k1345 */
static void C_ccall f_2082(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr5r,(void*)f_2082r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_2082r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_2082r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t6=C_i_nullp(t5);
t7=(C_truep(t6)?*((C_word*)lf[30]+1):C_i_car(t5));
t8=t7;
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2091,a[2]=t2,a[3]=t3,a[4]=t10,a[5]=t8,a[6]=((C_word)li48),tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_2091(t12,t1,t4);}

/* binary-search in k1345 */
static void C_ccall f_4177(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4177,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4181,a[2]=t4,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(((C_word*)t4)[1]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4255,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm:763: list->vector */
t7=*((C_word*)lf[85]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t4)[1]);}
else{
t6=t5;
f_4181(t6,C_i_check_vector_2(((C_word*)t4)[1],lf[100]));}}

/* butlast in k1345 */
static void C_ccall f_1701(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1701,3,t0,t1,t2);}
t3=C_i_check_pair_2(t2,lf[16]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1710,a[2]=t5,a[3]=((C_word)li34),tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_1710(t7,t1,t2);}

/* k4158 in loop in topological-sort in k1345 */
static void C_ccall f_4160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm:750: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4139(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k2247 in loop */
static void C_ccall f_2249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=C_slot(((C_word*)t0)[4],C_fix(1));
/* data-structures.scm:246: loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2233(t3,((C_word*)t0)[2],t2);}}

/* k3375 in loop in collect in string-translate* in k1345 */
static void C_fcall f_3377(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3377,NULL,2,t0,t1);}
t2=C_i_string_length(((C_word*)t0)[2]);
t3=C_fixnum_plus(((C_word*)t0)[3],t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);
/* data-structures.scm:527: collect */
t5=((C_word*)((C_word*)t0)[5])[1];
f_3307(t5,((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[7],t3,t4);}

/* queue-remove! in k1345 */
static void C_ccall f_4379(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4379,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[102],lf[111]);
t4=C_slot(t2,C_fix(1));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4389,a[2]=t5,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=C_eqp(C_SCHEME_END_OF_LIST,t5);
if(C_truep(t7)){
/* data-structures.scm:833: ##sys#error */
t8=*((C_word*)lf[20]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t6,lf[111],lf[112],t2);}
else{
t8=t6;
f_4389(2,t8,C_SCHEME_UNDEFINED);}}

/* k1729 in loop in butlast in k1345 */
static void C_ccall f_1731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1731,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* loop in flatten in k1345 */
static void C_fcall f_1739(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1739,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_slot(t2,C_fix(0));
t5=t4;
t6=C_slot(t2,C_fix(1));
if(C_truep(C_i_listp(t5))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1765,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm:151: loop */
t11=t7;
t12=t6;
t13=t3;
t1=t11;
t2=t12;
t3=t13;
goto loop;}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1772,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm:152: loop */
t11=t7;
t12=t6;
t13=t3;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}}

/* flatten in k1345 */
static void C_ccall f_1733(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_1733r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1733r(t0,t1,t2);}}

static void C_ccall f_1733r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1739,a[2]=t4,a[3]=((C_word)li36),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_1739(t6,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in k4179 in binary-search in k1345 */
static void C_fcall f_4195(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4195,NULL,4,t0,t1,t2,t3);}
t4=C_fixnum_difference(t3,t2);
t5=C_fixnum_shift_right(t4,C_fix(1));
t6=C_fixnum_plus(t2,t5);
t7=t6;
t8=C_slot(((C_word*)((C_word*)t0)[2])[1],t7);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4205,a[2]=t1,a[3]=t7,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* data-structures.scm:771: proc */
t10=((C_word*)t0)[4];
((C_proc3)C_fast_retrieve_proc(t10))(3,t10,t9,t8);}

/* k2903 in loop in string-split in k1345 */
static void C_ccall f_2905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)((C_word*)t0)[2])[1];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?t2:C_SCHEME_END_OF_LIST));}

/* loop in k1779 in chop in k1345 */
static void C_fcall f_1789(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1789,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep(C_fixnum_lessp(t3,((C_word*)t0)[2]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list1(&a,1,t2));}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1810,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=((C_word)li38),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_1810(t7,t1,C_SCHEME_END_OF_LIST,t2,((C_word*)t0)[2]);}}}

/* loop in collect in string-translate* in k1345 */
static void C_fcall f_3340(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(12);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3340,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t4=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* data-structures.scm:518: collect */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3307(t5,t1,t3,((C_word*)t0)[5],t4,((C_word*)((C_word*)t0)[6])[1]);}
else{
t3=C_i_car(t2);
t4=C_i_car(t3);
t5=C_i_string_length(t4);
t6=C_u_i_cdr(t3);
if(C_truep(C_substring_compare(((C_word*)t0)[7],t4,((C_word*)t0)[2],C_fix(0),t5))){
t7=C_fixnum_plus(((C_word*)t0)[2],t5);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3377,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_fixnum_greaterp(((C_word*)t0)[2],((C_word*)t0)[5]))){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3403,a[2]=((C_word*)t0)[6],a[3]=t9,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm:526: ##sys#substring */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[64]+1)))(5,*((C_word*)lf[64]+1),t10,((C_word*)t0)[7],((C_word*)t0)[5],((C_word*)t0)[2]);}
else{
t10=t9;
f_3377(t10,C_SCHEME_UNDEFINED);}}
else{
t7=t2;
t8=C_u_i_cdr(t7);
/* data-structures.scm:531: loop */
t16=t1;
t17=t8;
t1=t16;
t2=t17;
goto loop;}}}

/* k1779 in chop in k1345 */
static void C_ccall f_1781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1781,2,t0,t1);}
t2=C_i_length(((C_word*)t0)[2]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1789,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word)li39),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1789(t6,((C_word*)t0)[4],((C_word*)t0)[2],t2);}

/* k4387 in queue-remove! in k1345 */
static void C_ccall f_4389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_i_setslot(((C_word*)t0)[3],C_fix(1),t2);
t4=C_eqp(C_SCHEME_END_OF_LIST,t2);
t5=(C_truep(t4)?C_i_set_i_slot(((C_word*)t0)[3],C_fix(2),C_SCHEME_END_OF_LIST):C_SCHEME_UNDEFINED);
t6=C_slot(((C_word*)t0)[3],C_fix(3));
t7=C_fixnum_difference(t6,C_fix(1));
t8=C_i_set_i_slot(((C_word*)t0)[3],C_fix(3),t7);
t9=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_slot(((C_word*)t0)[2],C_fix(0)));}

/* k1763 in loop in flatten in k1345 */
static void C_ccall f_1765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm:151: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_1739(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* add in string-split in k1345 */
static void C_fcall f_2875(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2875,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2890,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm:402: ##sys#substring */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[64]+1)))(5,*((C_word*)lf[64]+1),t5,((C_word*)t0)[3],t2,t3);}

/* string-intersperse in k1345 */
static void C_ccall f_2988(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_2988r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2988r(t0,t1,t2,t3);}}

static void C_ccall f_2988r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(9);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?lf[66]:C_i_car(t3));
t6=t5;
t7=C_i_check_list_2(t2,lf[65]);
t8=C_i_check_string_2(t6,lf[65]);
t9=C_block_size(t6);
t10=t9;
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3006,a[2]=t2,a[3]=t6,a[4]=t10,a[5]=t12,a[6]=((C_word)li80),tmp=(C_word)a,a+=7,tmp));
t14=((C_word*)t12)[1];
f_3006(t14,t1,t2,C_fix(0));}

/* k1345 */
static void C_ccall f_1347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word ab[188],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1347,2,t0,t1);}
t2=C_mutate2((C_word*)lf[0]+1 /* (set! identity ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1349,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate2((C_word*)lf[1]+1 /* (set! conjoin ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1352,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate2((C_word*)lf[2]+1 /* (set! disjoin ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1385,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate2((C_word*)lf[3]+1 /* (set! constantly ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1422,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate2((C_word*)lf[4]+1 /* (set! flip ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1443,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate2((C_word*)lf[5]+1 /* (set! complement ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1451,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate2((C_word*)lf[6]+1 /* (set! compose ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1463,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate2((C_word*)lf[8]+1 /* (set! o ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1499,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate2((C_word*)lf[9]+1 /* (set! list-of? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1538,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate2((C_word*)lf[10]+1 /* (set! each ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1578,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate2((C_word*)lf[12]+1 /* (set! any? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1634,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate2((C_word*)lf[13]+1 /* (set! atom? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1637,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate2((C_word*)lf[14]+1 /* (set! tail? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1640,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate2((C_word*)lf[15]+1 /* (set! intersperse ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1668,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate2((C_word*)lf[16]+1 /* (set! butlast ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1701,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate2((C_word*)lf[17]+1 /* (set! flatten ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1733,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate2((C_word*)lf[18]+1 /* (set! chop ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1774,a[2]=((C_word)li40),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate2((C_word*)lf[22]+1 /* (set! join ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1859,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate2((C_word*)lf[25]+1 /* (set! compress ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1916,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate2((C_word*)lf[29]+1 /* (set! alist-update! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1996,a[2]=((C_word)li47),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate2((C_word*)lf[36]+1 /* (set! alist-update ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2082,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate2((C_word*)lf[40]+1 /* (set! alist-ref ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2186,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate2((C_word*)lf[41]+1 /* (set! rassoc ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2292,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate2((C_word*)lf[42]+1 /* (set! reverse-string-append ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2340,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate2((C_word*)lf[44]+1 /* (set! ->string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2413,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp));
t27=C_mutate2((C_word*)lf[50]+1 /* (set! conc ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2458,a[2]=((C_word)li60),tmp=(C_word)a,a+=3,tmp));
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2503,a[2]=((C_word)li62),tmp=(C_word)a,a+=3,tmp);
t29=C_mutate2((C_word*)lf[52]+1 /* (set! ##sys#substring-index ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2550,a[2]=t28,a[3]=((C_word)li64),tmp=(C_word)a,a+=4,tmp));
t30=C_mutate2((C_word*)lf[54]+1 /* (set! ##sys#substring-index-ci ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2559,a[2]=t28,a[3]=((C_word)li66),tmp=(C_word)a,a+=4,tmp));
t31=C_mutate2((C_word*)lf[53]+1 /* (set! substring-index ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2568,a[2]=((C_word)li67),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate2((C_word*)lf[55]+1 /* (set! substring-index-ci ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2583,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate2((C_word*)lf[56]+1 /* (set! string-compare3 ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2598,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp));
t34=C_mutate2((C_word*)lf[57]+1 /* (set! string-compare3-ci ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2629,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp));
t35=C_mutate2((C_word*)lf[58]+1 /* (set! ##sys#substring=? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2660,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp));
t36=C_mutate2((C_word*)lf[59]+1 /* (set! substring=? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2697,a[2]=((C_word)li72),tmp=(C_word)a,a+=3,tmp));
t37=C_mutate2((C_word*)lf[60]+1 /* (set! ##sys#substring-ci=? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2757,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp));
t38=C_mutate2((C_word*)lf[61]+1 /* (set! substring-ci=? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2794,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp));
t39=C_mutate2((C_word*)lf[62]+1 /* (set! string-split ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2854,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t40=C_mutate2((C_word*)lf[65]+1 /* (set! string-intersperse ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2988,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp));
t41=C_mutate2((C_word*)lf[69]+1 /* (set! string-translate ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3090,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t42=C_mutate2((C_word*)lf[73]+1 /* (set! string-translate* ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3295,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp));
t43=C_mutate2((C_word*)lf[76]+1 /* (set! string-chop ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3413,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp));
t44=C_mutate2((C_word*)lf[77]+1 /* (set! string-chomp ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3477,a[2]=((C_word)li93),tmp=(C_word)a,a+=3,tmp));
t45=C_mutate2((C_word*)lf[79]+1 /* (set! sorted? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3516,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp));
t46=C_mutate2((C_word*)lf[80]+1 /* (set! merge ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3622,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp));
t47=C_mutate2((C_word*)lf[81]+1 /* (set! merge! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3713,a[2]=((C_word)li100),tmp=(C_word)a,a+=3,tmp));
t48=C_mutate2((C_word*)lf[82]+1 /* (set! sort! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3837,a[2]=((C_word)li103),tmp=(C_word)a,a+=3,tmp));
t49=C_mutate2((C_word*)lf[84]+1 /* (set! sort ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3965,a[2]=((C_word)li104),tmp=(C_word)a,a+=3,tmp));
t50=C_mutate2((C_word*)lf[87]+1 /* (set! topological-sort ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3992,a[2]=((C_word)li108),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate2((C_word*)lf[100]+1 /* (set! binary-search ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4177,a[2]=((C_word)li110),tmp=(C_word)a,a+=3,tmp));
t52=C_mutate2((C_word*)lf[101]+1 /* (set! make-queue ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4260,a[2]=((C_word)li111),tmp=(C_word)a,a+=3,tmp));
t53=C_mutate2((C_word*)lf[103]+1 /* (set! queue? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4266,a[2]=((C_word)li112),tmp=(C_word)a,a+=3,tmp));
t54=C_mutate2((C_word*)lf[104]+1 /* (set! queue-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4272,a[2]=((C_word)li113),tmp=(C_word)a,a+=3,tmp));
t55=C_mutate2((C_word*)lf[105]+1 /* (set! queue-empty? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4281,a[2]=((C_word)li114),tmp=(C_word)a,a+=3,tmp));
t56=C_mutate2((C_word*)lf[106]+1 /* (set! queue-first ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4294,a[2]=((C_word)li115),tmp=(C_word)a,a+=3,tmp));
t57=C_mutate2((C_word*)lf[108]+1 /* (set! queue-last ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4315,a[2]=((C_word)li116),tmp=(C_word)a,a+=3,tmp));
t58=C_mutate2((C_word*)lf[110]+1 /* (set! queue-add! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4336,a[2]=((C_word)li117),tmp=(C_word)a,a+=3,tmp));
t59=C_mutate2((C_word*)lf[111]+1 /* (set! queue-remove! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4379,a[2]=((C_word)li118),tmp=(C_word)a,a+=3,tmp));
t60=C_mutate2((C_word*)lf[113]+1 /* (set! queue->list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4426,a[2]=((C_word)li120),tmp=(C_word)a,a+=3,tmp));
t61=C_mutate2((C_word*)lf[114]+1 /* (set! list->queue ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4466,a[2]=((C_word)li122),tmp=(C_word)a,a+=3,tmp));
t62=C_mutate2((C_word*)lf[115]+1 /* (set! queue-push-back! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4524,a[2]=((C_word)li123),tmp=(C_word)a,a+=3,tmp));
t63=C_mutate2((C_word*)lf[116]+1 /* (set! queue-push-back-list! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4564,a[2]=((C_word)li125),tmp=(C_word)a,a+=3,tmp));
t64=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t64+1)))(2,t64,C_SCHEME_UNDEFINED);}

/* identity in k1345 */
static void C_ccall f_1349(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1349,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4323 in queue-last in k1345 */
static void C_ccall f_4325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_slot(((C_word*)t0)[3],C_fix(0)));}

/* loop in butlast in k1345 */
static void C_fcall f_1710(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1710,NULL,3,t0,t1,t2);}
t3=C_slot(t2,C_fix(1));
t4=(C_truep(C_blockp(t3))?C_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_slot(t2,C_fix(0));
t6=t5;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1731,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm:141: loop */
t9=t7;
t10=t3;
t1=t9;
t2=t10;
goto loop;}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}}

/* k2959 in scan in loop in string-split in k1345 */
static void C_ccall f_2961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm:418: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_2895(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1,((C_word*)t0)[4]);}

/* k3285 in string-translate in k1345 */
static void C_ccall f_3287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm:468: instring */
f_3093(((C_word*)t0)[3],t1);}

/* k1770 in loop in flatten in k1345 */
static void C_ccall f_1772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1772,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* chop in k1345 */
static void C_ccall f_1774(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1774,4,t0,t1,t2,t3);}
t4=C_i_check_exact_2(t3,lf[18]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1781,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_fixnum_less_or_equal_p(t3,C_fix(0)))){
/* data-structures.scm:157: ##sys#error */
t6=*((C_word*)lf[20]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[18],lf[21],t3);}
else{
t6=t5;
f_1781(2,t6,C_SCHEME_UNDEFINED);}}

/* queue-push-back-list! in k1345 */
static void C_ccall f_4564(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4564,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[102],lf[116]);
t5=C_i_check_list_2(t3,lf[116]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4574,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=C_slot(t2,C_fix(1));
/* data-structures.scm:884: append */
t8=*((C_word*)lf[86]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t3,t7);}

/* f_3270 in string-translate in k1345 */
static void C_ccall f_3270(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3270,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_eqp(t2,((C_word*)t0)[2]));}

/* alist-ref in k1345 */
static void C_ccall f_2186(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_2186r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2186r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2186r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a=C_alloc(10);
t5=C_i_nullp(t4);
t6=(C_truep(t5)?*((C_word*)lf[30]+1):C_i_car(t4));
t7=t6;
t8=C_i_nullp(t4);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:C_i_cdr(t4));
t10=C_i_nullp(t9);
t11=(C_truep(t10)?C_SCHEME_FALSE:C_i_car(t9));
t12=t11;
t13=C_i_nullp(t9);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:C_i_cdr(t9));
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2202,a[2]=t1,a[3]=t12,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t16=C_eqp(*((C_word*)lf[31]+1),t7);
if(C_truep(t16)){
t17=t15;
f_2202(t17,*((C_word*)lf[32]+1));}
else{
t17=C_eqp(*((C_word*)lf[30]+1),t7);
if(C_truep(t17)){
t18=t15;
f_2202(t18,*((C_word*)lf[33]+1));}
else{
t18=C_eqp(*((C_word*)lf[34]+1),t7);
t19=t15;
f_2202(t19,(C_truep(t18)?*((C_word*)lf[35]+1):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2227,a[2]=t7,a[3]=((C_word)li51),tmp=(C_word)a,a+=4,tmp)));}}}

/* k4575 in k4572 in queue-push-back-list! in k1345 */
static void C_fcall f_4577(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=C_i_setslot(((C_word*)t0)[2],C_fix(1),((C_word*)t0)[3]);
t3=C_i_setslot(((C_word*)t0)[2],C_fix(2),t1);
t4=C_slot(((C_word*)t0)[2],C_fix(3));
t5=C_i_length(((C_word*)t0)[4]);
t6=C_fixnum_plus(t4,t5);
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_i_set_i_slot(((C_word*)t0)[2],C_fix(3),t6));}

/* k4572 in queue-push-back-list! in k1345 */
static void C_ccall f_4574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4574,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4577,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t3;
f_4577(t5,C_SCHEME_END_OF_LIST);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4605,a[2]=((C_word)li124),tmp=(C_word)a,a+=3,tmp);
t6=t3;
f_4577(t6,f_4605(t2));}}

/* k3677 in k3657 in loop in merge in k1345 */
static void C_ccall f_3679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3679,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* atom? in k1345 */
static void C_ccall f_1637(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1637,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_not_pair_p(t2));}

/* any? in k1345 */
static void C_ccall f_1634(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1634,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* scan in loop in string-split in k1345 */
static void C_fcall f_2922(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2922,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* data-structures.scm:414: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2895(t4,t1,t3,((C_word*)t0)[5],((C_word*)t0)[6]);}
else{
t3=C_subchar(((C_word*)t0)[7],t2);
t4=C_eqp(((C_word*)t0)[8],t3);
if(C_truep(t4)){
t5=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t6=t5;
t7=C_fixnum_greaterp(((C_word*)t0)[3],((C_word*)t0)[6]);
t8=(C_truep(t7)?t7:((C_word*)t0)[9]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2961,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm:418: add */
t10=((C_word*)t0)[10];
f_2875(t10,t9,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
/* data-structures.scm:419: loop */
t9=((C_word*)((C_word*)t0)[4])[1];
f_2895(t9,t1,t6,((C_word*)t0)[5],t6);}}
else{
t5=C_fixnum_plus(t2,C_fix(1));
/* data-structures.scm:420: scan */
t13=t1;
t14=t5;
t1=t13;
t2=t14;
goto loop;}}}

/* k1623 in loop */
static void C_ccall f_1625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm:109: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_1606(t2,((C_word*)t0)[3],((C_word*)t0)[4]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[218] = {
{"f_1600:data_2dstructures_2escm",(void*)f_1600},
{"f_1606:data_2dstructures_2escm",(void*)f_1606},
{"f_1674:data_2dstructures_2escm",(void*)f_1674},
{"f_3295:data_2dstructures_2escm",(void*)f_3295},
{"f_1916:data_2dstructures_2escm",(void*)f_1916},
{"f_1668:data_2dstructures_2escm",(void*)f_1668},
{"f_3622:data_2dstructures_2escm",(void*)f_3622},
{"f_1967:data_2dstructures_2escm",(void*)f_1967},
{"f_3616:data_2dstructures_2escm",(void*)f_3616},
{"f_1906:data_2dstructures_2escm",(void*)f_1906},
{"f_1652:data_2dstructures_2escm",(void*)f_1652},
{"f_3428:data_2dstructures_2escm",(void*)f_3428},
{"f_2299:data_2dstructures_2escm",(void*)f_2299},
{"f_1640:data_2dstructures_2escm",(void*)f_1640},
{"f_2292:data_2dstructures_2escm",(void*)f_2292},
{"f_3413:data_2dstructures_2escm",(void*)f_3413},
{"f_2343:data_2dstructures_2escm",(void*)f_2343},
{"f_2340:data_2dstructures_2escm",(void*)f_2340},
{"f_3167:data_2dstructures_2escm",(void*)f_3167},
{"f_3516:data_2dstructures_2escm",(void*)f_3516},
{"f_1499:data_2dstructures_2escm",(void*)f_1499},
{"f_1488:data_2dstructures_2escm",(void*)f_1488},
{"f_1480:data_2dstructures_2escm",(void*)f_1480},
{"f_1925:data_2dstructures_2escm",(void*)f_1925},
{"f_1474:data_2dstructures_2escm",(void*)f_1474},
{"f_1996:data_2dstructures_2escm",(void*)f_1996},
{"f_2357:data_2dstructures_2escm",(void*)f_2357},
{"f_1463:data_2dstructures_2escm",(void*)f_1463},
{"f_1466:data_2dstructures_2escm",(void*)f_1466},
{"f_1461:data_2dstructures_2escm",(void*)f_1461},
{"f_3321:data_2dstructures_2escm",(void*)f_3321},
{"f_1824:data_2dstructures_2escm",(void*)f_1824},
{"f_1828:data_2dstructures_2escm",(void*)f_1828},
{"f_2366:data_2dstructures_2escm",(void*)f_2366},
{"f_4255:data_2dstructures_2escm",(void*)f_4255},
{"f_3403:data_2dstructures_2escm",(void*)f_3403},
{"f_3965:data_2dstructures_2escm",(void*)f_3965},
{"f_2323:data_2dstructures_2escm",(void*)f_2323},
{"f_3999:data_2dstructures_2escm",(void*)f_3999},
{"f_3995:data_2dstructures_2escm",(void*)f_3995},
{"f_3992:data_2dstructures_2escm",(void*)f_3992},
{"f_3990:data_2dstructures_2escm",(void*)f_3990},
{"f_1810:data_2dstructures_2escm",(void*)f_1810},
{"f_4205:data_2dstructures_2escm",(void*)f_4205},
{"f_3979:data_2dstructures_2escm",(void*)f_3979},
{"f_1871:data_2dstructures_2escm",(void*)f_1871},
{"f_4336:data_2dstructures_2escm",(void*)f_4336},
{"f_3093:data_2dstructures_2escm",(void*)f_3093},
{"f_3098:data_2dstructures_2escm",(void*)f_3098},
{"f_3090:data_2dstructures_2escm",(void*)f_3090},
{"f_4346:data_2dstructures_2escm",(void*)f_4346},
{"f_3983:data_2dstructures_2escm",(void*)f_3983},
{"f_4605:data_2dstructures_2escm",(void*)f_4605},
{"f_4466:data_2dstructures_2escm",(void*)f_4466},
{"f_3307:data_2dstructures_2escm",(void*)f_3307},
{"f_2413:data_2dstructures_2escm",(void*)f_2413},
{"f_2458:data_2dstructures_2escm",(void*)f_2458},
{"f_2453:data_2dstructures_2escm",(void*)f_2453},
{"f_2450:data_2dstructures_2escm",(void*)f_2450},
{"f_2466:data_2dstructures_2escm",(void*)f_2466},
{"f_2468:data_2dstructures_2escm",(void*)f_2468},
{"f_2304:data_2dstructures_2escm",(void*)f_2304},
{"f_4497:data_2dstructures_2escm",(void*)f_4497},
{"f_4439:data_2dstructures_2escm",(void*)f_4439},
{"f_3840:data_2dstructures_2escm",(void*)f_3840},
{"f_2559:data_2dstructures_2escm",(void*)f_2559},
{"f_2556:data_2dstructures_2escm",(void*)f_2556},
{"f_2550:data_2dstructures_2escm",(void*)f_2550},
{"f_4036:data_2dstructures_2escm",(void*)f_4036},
{"f_2568:data_2dstructures_2escm",(void*)f_2568},
{"f_2565:data_2dstructures_2escm",(void*)f_2565},
{"f_1546:data_2dstructures_2escm",(void*)f_1546},
{"f_1540:data_2dstructures_2escm",(void*)f_1540},
{"f_2537:data_2dstructures_2escm",(void*)f_2537},
{"f_1538:data_2dstructures_2escm",(void*)f_1538},
{"f_1536:data_2dstructures_2escm",(void*)f_1536},
{"f_1533:data_2dstructures_2escm",(void*)f_1533},
{"f_2497:data_2dstructures_2escm",(void*)f_2497},
{"f_3853:data_2dstructures_2escm",(void*)f_3853},
{"f_3859:data_2dstructures_2escm",(void*)f_3859},
{"f_3850:data_2dstructures_2escm",(void*)f_3850},
{"f_1525:data_2dstructures_2escm",(void*)f_1525},
{"f_4103:data_2dstructures_2escm",(void*)f_4103},
{"f_1360:data_2dstructures_2escm",(void*)f_1360},
{"f_3888:data_2dstructures_2escm",(void*)f_3888},
{"f_4281:data_2dstructures_2escm",(void*)f_4281},
{"f_2598:data_2dstructures_2escm",(void*)f_2598},
{"f_1511:data_2dstructures_2escm",(void*)f_1511},
{"f_1354:data_2dstructures_2escm",(void*)f_1354},
{"f_1352:data_2dstructures_2escm",(void*)f_1352},
{"f_4272:data_2dstructures_2escm",(void*)f_4272},
{"f_4260:data_2dstructures_2escm",(void*)f_4260},
{"f_2503:data_2dstructures_2escm",(void*)f_2503},
{"f_4266:data_2dstructures_2escm",(void*)f_4266},
{"f_1453:data_2dstructures_2escm",(void*)f_1453},
{"f_1451:data_2dstructures_2escm",(void*)f_1451},
{"f_1393:data_2dstructures_2escm",(void*)f_1393},
{"f_1443:data_2dstructures_2escm",(void*)f_1443},
{"f_1445:data_2dstructures_2escm",(void*)f_1445},
{"f_4510:data_2dstructures_2escm",(void*)f_4510},
{"f_1385:data_2dstructures_2escm",(void*)f_1385},
{"f_1387:data_2dstructures_2escm",(void*)f_1387},
{"f_2660:data_2dstructures_2escm",(void*)f_2660},
{"f_1435:data_2dstructures_2escm",(void*)f_1435},
{"f_1433:data_2dstructures_2escm",(void*)f_1433},
{"f_4524:data_2dstructures_2escm",(void*)f_4524},
{"f_1376:data_2dstructures_2escm",(void*)f_1376},
{"f_4477:data_2dstructures_2escm",(void*)f_4477},
{"f_2006:data_2dstructures_2escm",(void*)f_2006},
{"f_1586:data_2dstructures_2escm",(void*)f_1586},
{"f_1422:data_2dstructures_2escm",(void*)f_1422},
{"f_4294:data_2dstructures_2escm",(void*)f_4294},
{"f_3659:data_2dstructures_2escm",(void*)f_3659},
{"f_2003:data_2dstructures_2escm",(void*)f_2003},
{"f_3924:data_2dstructures_2escm",(void*)f_3924},
{"f_3652:data_2dstructures_2escm",(void*)f_3652},
{"f_4487:data_2dstructures_2escm",(void*)f_4487},
{"f_2057:data_2dstructures_2escm",(void*)f_2057},
{"f_1578:data_2dstructures_2escm",(void*)f_1578},
{"f_1699:data_2dstructures_2escm",(void*)f_1699},
{"f_2697:data_2dstructures_2escm",(void*)f_2697},
{"f_1565:data_2dstructures_2escm",(void*)f_1565},
{"f_1406:data_2dstructures_2escm",(void*)f_1406},
{"f_4426:data_2dstructures_2escm",(void*)f_4426},
{"f_3794:data_2dstructures_2escm",(void*)f_3794},
{"f_3791:data_2dstructures_2escm",(void*)f_3791},
{"f_2035:data_2dstructures_2escm",(void*)f_2035},
{"f_3933:data_2dstructures_2escm",(void*)f_3933},
{"f_3931:data_2dstructures_2escm",(void*)f_3931},
{"f_2583:data_2dstructures_2escm",(void*)f_2583},
{"toplevel:data_2dstructures_2escm",(void*)C_data_2dstructures_toplevel},
{"f_2041:data_2dstructures_2escm",(void*)f_2041},
{"f_3553:data_2dstructures_2escm",(void*)f_3553},
{"f_2132:data_2dstructures_2escm",(void*)f_2132},
{"f_2524:data_2dstructures_2escm",(void*)f_2524},
{"f_3837:data_2dstructures_2escm",(void*)f_3837},
{"f_3543:data_2dstructures_2escm",(void*)f_3543},
{"f_4048:data_2dstructures_2escm",(void*)f_4048},
{"f_3448:data_2dstructures_2escm",(void*)f_3448},
{"f_2670:data_2dstructures_2escm",(void*)f_2670},
{"f_3812:data_2dstructures_2escm",(void*)f_3812},
{"f_3128:data_2dstructures_2escm",(void*)f_3128},
{"f_3592:data_2dstructures_2escm",(void*)f_3592},
{"f_2757:data_2dstructures_2escm",(void*)f_2757},
{"f_3104:data_2dstructures_2escm",(void*)f_3104},
{"f_4081:data_2dstructures_2escm",(void*)f_4081},
{"f_2154:data_2dstructures_2escm",(void*)f_2154},
{"f_3131:data_2dstructures_2escm",(void*)f_3131},
{"f_4139:data_2dstructures_2escm",(void*)f_4139},
{"f_4067:data_2dstructures_2escm",(void*)f_4067},
{"f_3477:data_2dstructures_2escm",(void*)f_3477},
{"f_1863:data_2dstructures_2escm",(void*)f_1863},
{"f_4061:data_2dstructures_2escm",(void*)f_4061},
{"f_2854:data_2dstructures_2escm",(void*)f_2854},
{"f_3006:data_2dstructures_2escm",(void*)f_3006},
{"f_4304:data_2dstructures_2escm",(void*)f_4304},
{"f_3463:data_2dstructures_2escm",(void*)f_3463},
{"f_3459:data_2dstructures_2escm",(void*)f_3459},
{"f_2794:data_2dstructures_2escm",(void*)f_2794},
{"f_4315:data_2dstructures_2escm",(void*)f_4315},
{"f_3723:data_2dstructures_2escm",(void*)f_3723},
{"f_2767:data_2dstructures_2escm",(void*)f_2767},
{"f_4181:data_2dstructures_2escm",(void*)f_4181},
{"f_3143:data_2dstructures_2escm",(void*)f_3143},
{"f_2629:data_2dstructures_2escm",(void*)f_2629},
{"f_2227:data_2dstructures_2escm",(void*)f_2227},
{"f_3148:data_2dstructures_2escm",(void*)f_3148},
{"f_3716:data_2dstructures_2escm",(void*)f_3716},
{"f_3713:data_2dstructures_2escm",(void*)f_3713},
{"f_2233:data_2dstructures_2escm",(void*)f_2233},
{"f_3016:data_2dstructures_2escm",(void*)f_3016},
{"f_3705:data_2dstructures_2escm",(void*)f_3705},
{"f_2895:data_2dstructures_2escm",(void*)f_2895},
{"f_2205:data_2dstructures_2escm",(void*)f_2205},
{"f_2091:data_2dstructures_2escm",(void*)f_2091},
{"f_2890:data_2dstructures_2escm",(void*)f_2890},
{"f_3335:data_2dstructures_2escm",(void*)f_3335},
{"f_2202:data_2dstructures_2escm",(void*)f_2202},
{"f_1859:data_2dstructures_2escm",(void*)f_1859},
{"f_3021:data_2dstructures_2escm",(void*)f_3021},
{"f_2082:data_2dstructures_2escm",(void*)f_2082},
{"f_4177:data_2dstructures_2escm",(void*)f_4177},
{"f_1701:data_2dstructures_2escm",(void*)f_1701},
{"f_4160:data_2dstructures_2escm",(void*)f_4160},
{"f_2249:data_2dstructures_2escm",(void*)f_2249},
{"f_3377:data_2dstructures_2escm",(void*)f_3377},
{"f_4379:data_2dstructures_2escm",(void*)f_4379},
{"f_1731:data_2dstructures_2escm",(void*)f_1731},
{"f_1739:data_2dstructures_2escm",(void*)f_1739},
{"f_1733:data_2dstructures_2escm",(void*)f_1733},
{"f_4195:data_2dstructures_2escm",(void*)f_4195},
{"f_2905:data_2dstructures_2escm",(void*)f_2905},
{"f_1789:data_2dstructures_2escm",(void*)f_1789},
{"f_3340:data_2dstructures_2escm",(void*)f_3340},
{"f_1781:data_2dstructures_2escm",(void*)f_1781},
{"f_4389:data_2dstructures_2escm",(void*)f_4389},
{"f_1765:data_2dstructures_2escm",(void*)f_1765},
{"f_2875:data_2dstructures_2escm",(void*)f_2875},
{"f_2988:data_2dstructures_2escm",(void*)f_2988},
{"f_1347:data_2dstructures_2escm",(void*)f_1347},
{"f_1349:data_2dstructures_2escm",(void*)f_1349},
{"f_4325:data_2dstructures_2escm",(void*)f_4325},
{"f_1710:data_2dstructures_2escm",(void*)f_1710},
{"f_2961:data_2dstructures_2escm",(void*)f_2961},
{"f_3287:data_2dstructures_2escm",(void*)f_3287},
{"f_1772:data_2dstructures_2escm",(void*)f_1772},
{"f_1774:data_2dstructures_2escm",(void*)f_1774},
{"f_4564:data_2dstructures_2escm",(void*)f_4564},
{"f_3270:data_2dstructures_2escm",(void*)f_3270},
{"f_2186:data_2dstructures_2escm",(void*)f_2186},
{"f_4577:data_2dstructures_2escm",(void*)f_4577},
{"f_4574:data_2dstructures_2escm",(void*)f_4574},
{"f_3679:data_2dstructures_2escm",(void*)f_3679},
{"f_1637:data_2dstructures_2escm",(void*)f_1637},
{"f_1634:data_2dstructures_2escm",(void*)f_1634},
{"f_2922:data_2dstructures_2escm",(void*)f_2922},
{"f_1625:data_2dstructures_2escm",(void*)f_1625},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  map		1
o|eliminated procedure checks: 112 
o|eliminated procedure checks: 1 
o|eliminated procedure checks: 1 
o|eliminated procedure checks: 1 
o|eliminated procedure checks: 1 
o|eliminated procedure checks: 1 
o|specializations:
o|  1 (##sys#length list)
o|  1 (cdar (pair pair *))
o|  2 (eqv? * (not float))
o|  1 (set-car! pair *)
o|  1 (cddr (pair * pair))
o|  4 (set-cdr! pair *)
o|  1 (<= fixnum fixnum)
o|  1 (vector-length vector)
o|  1 (make-string fixnum)
o|  1 (##sys#check-list (or pair list) *)
o|  23 (cdr pair)
o|  5 (car pair)
o|  2 (length list)
o|Removed `not' forms: 11 
o|inlining procedure: k1365 
o|inlining procedure: k1365 
o|contracted procedure: k1398 
o|inlining procedure: k1395 
o|inlining procedure: k1395 
o|inlining procedure: k1424 
o|inlining procedure: k1424 
o|inlining procedure: k1468 
o|inlining procedure: k1468 
o|inlining procedure: k1489 
o|propagated global variable: r14904639 values 
o|inlining procedure: k1489 
o|inlining procedure: k1501 
o|propagated global variable: r15024641 identity 
o|inlining procedure: k1501 
o|inlining procedure: k1519 
o|inlining procedure: k1519 
o|inlining procedure: k1548 
o|inlining procedure: k1548 
o|inlining procedure: k1560 
o|inlining procedure: k1560 
o|inlining procedure: k1580 
o|inlining procedure: k1580 
o|inlining procedure: k1614 
o|inlining procedure: k1614 
o|inlining procedure: k1645 
o|inlining procedure: k1645 
o|inlining procedure: k1654 
o|inlining procedure: k1654 
o|inlining procedure: k1676 
o|inlining procedure: k1676 
o|inlining procedure: k1715 
o|inlining procedure: k1715 
o|inlining procedure: k1741 
o|inlining procedure: k1741 
o|inlining procedure: k1791 
o|inlining procedure: k1791 
o|inlining procedure: k1812 
o|inlining procedure: k1812 
o|inlining procedure: k1873 
o|inlining procedure: k1873 
o|contracted procedure: k1882 
o|inlining procedure: k1894 
o|inlining procedure: k1894 
o|inlining procedure: k1927 
o|inlining procedure: k1927 
o|contracted procedure: k1936 
o|contracted procedure: k1945 
o|inlining procedure: k1942 
o|inlining procedure: k1942 
o|inlining procedure: k2007 
o|inlining procedure: k2007 
o|inlining procedure: k2023 
o|propagated global variable: r20244677 assv 
o|inlining procedure: k2023 
o|inlining procedure: k2043 
o|inlining procedure: k2043 
o|inlining procedure: k2093 
o|inlining procedure: k2093 
o|contracted procedure: k2109 
o|contracted procedure: k2121 
o|inlining procedure: k2118 
o|inlining procedure: k2118 
o|inlining procedure: k2206 
o|inlining procedure: k2206 
o|inlining procedure: k2215 
o|propagated global variable: r22164687 assv 
o|inlining procedure: k2215 
o|inlining procedure: k2235 
o|inlining procedure: k2235 
o|inlining procedure: k2306 
o|inlining procedure: k2306 
o|inlining procedure: k2345 
o|inlining procedure: k2368 
o|inlining procedure: k2368 
o|inlining procedure: k2345 
o|inlining procedure: k2415 
o|inlining procedure: k2415 
o|inlining procedure: k2430 
o|inlining procedure: k2430 
o|inlining procedure: k2470 
o|inlining procedure: k2470 
o|inlining procedure: k2526 
o|inlining procedure: k2526 
o|inlining procedure: k2619 
o|inlining procedure: k2619 
o|inlining procedure: k2650 
o|inlining procedure: k2650 
o|inlining procedure: k2880 
o|inlining procedure: k2880 
o|inlining procedure: k2897 
o|inlining procedure: k2897 
o|inlining procedure: k2924 
o|inlining procedure: k2924 
o|inlining procedure: k2946 
o|inlining procedure: k2946 
o|inlining procedure: k3008 
o|inlining procedure: k3035 
o|inlining procedure: k3035 
o|inlining procedure: k3008 
o|inlining procedure: k3106 
o|inlining procedure: k3106 
o|inlining procedure: k3150 
o|inlining procedure: k3150 
o|contracted procedure: k3171 
o|contracted procedure: k3188 
o|inlining procedure: k3185 
o|inlining procedure: k3215 
o|inlining procedure: k3215 
o|inlining procedure: k3185 
o|inlining procedure: k3249 
o|inlining procedure: k3249 
o|inlining procedure: k3275 
o|inlining procedure: k3275 
o|inlining procedure: k3309 
o|inlining procedure: k3323 
o|inlining procedure: k3323 
o|inlining procedure: k3309 
o|inlining procedure: k3342 
o|inlining procedure: k3342 
o|inlining procedure: k3430 
o|inlining procedure: k3430 
o|inlining procedure: k3497 
o|inlining procedure: k3497 
o|inlining procedure: k3518 
o|inlining procedure: k3518 
o|inlining procedure: k3533 
o|inlining procedure: k3533 
o|inlining procedure: k3545 
o|inlining procedure: k3545 
o|substituted constant variable: a3580 
o|inlining procedure: k3597 
o|inlining procedure: k3597 
o|contracted procedure: k3603 
o|inlining procedure: k3624 
o|inlining procedure: k3624 
o|inlining procedure: k3654 
o|inlining procedure: k3654 
o|inlining procedure: k3718 
o|inlining procedure: k3718 
o|inlining procedure: k3774 
o|inlining procedure: k3774 
o|inlining procedure: k3786 
o|inlining procedure: k3786 
o|inlining procedure: k3842 
o|inlining procedure: k3842 
o|inlining procedure: k3899 
o|inlining procedure: k3899 
o|inlining procedure: k3912 
o|inlining procedure: k3935 
o|inlining procedure: k3935 
o|inlining procedure: k3912 
o|inlining procedure: k3967 
o|inlining procedure: k3967 
o|inlining procedure: k4000 
o|inlining procedure: k4000 
o|inlining procedure: k4069 
o|inlining procedure: k4069 
o|substituted constant variable: a4124 
o|substituted constant variable: a4126 
o|inlining procedure: k4141 
o|inlining procedure: k4141 
o|inlining procedure: k4185 
o|inlining procedure: k4206 
o|inlining procedure: k4206 
o|contracted procedure: k4221 
o|inlining procedure: k4218 
o|inlining procedure: k4218 
o|contracted procedure: k4234 
o|inlining procedure: k4231 
o|inlining procedure: k4231 
o|inlining procedure: k4185 
o|inlining procedure: k4302 
o|inlining procedure: k4302 
o|inlining procedure: k4323 
o|inlining procedure: k4323 
o|inlining procedure: k4441 
o|inlining procedure: k4441 
o|inlining procedure: k4475 
o|inlining procedure: k4475 
o|inlining procedure: k4489 
o|inlining procedure: k4489 
o|contracted procedure: "(data-structures.scm:887) g929930" 
o|inlining procedure: k4607 
o|inlining procedure: k4607 
o|replaced variables: 516 
o|removed binding forms: 210 
o|substituted constant variable: r13964633 
o|substituted constant variable: r15494645 
o|substituted constant variable: r15614648 
o|substituted constant variable: r16554655 
o|substituted constant variable: r17164660 
o|substituted constant variable: r17924663 
o|substituted constant variable: r18744667 
o|substituted constant variable: r19284671 
o|substituted constant variable: r20444680 
o|substituted constant variable: r22364690 
o|substituted constant variable: r23074692 
o|substituted constant variable: r25274703 
o|converted assignments to bindings: (add541) 
o|substituted constant variable: r31074723 
o|converted assignments to bindings: (instring620) 
o|substituted constant variable: r34314743 
o|substituted constant variable: r35194747 
o|substituted constant variable: r35344749 
o|substituted constant variable: r39004768 
o|substituted constant variable: r42194784 
o|substituted constant variable: r42324786 
o|substituted constant variable: r41864788 
o|substituted constant variable: r44764811 
o|substituted constant variable: r44764811 
o|converted assignments to bindings: (traverse386) 
o|simplifications: ((let . 3)) 
o|replaced variables: 20 
o|removed binding forms: 521 
o|inlining procedure: k2570 
o|inlining procedure: k2585 
o|inlining procedure: k2714 
o|inlining procedure: k2811 
o|inlining procedure: k2903 
o|inlining procedure: k4495 
o|replaced variables: 10 
o|removed binding forms: 45 
o|substituted constant variable: r25715032 
o|substituted constant variable: r25865033 
o|removed binding forms: 14 
o|removed binding forms: 2 
o|simplifications: ((if . 38) (##core#call . 505)) 
o|  call simplifications:
o|    ##sys#setislot	4
o|    ##sys#check-structure	9
o|    ##sys#structure?
o|    ##sys#check-vector
o|    caar
o|    ##sys#cons	4
o|    ##sys#list
o|    ##sys#make-structure	4
o|    vector-length
o|    vector-set!
o|    >
o|    set-car!
o|    quotient
o|    set-cdr!	4
o|    vector?	3
o|    -	2
o|    vector-ref	2
o|    +	2
o|    =	4
o|    list->string	2
o|    cadr	2
o|    fx>=	7
o|    fxmin	2
o|    ##sys#check-string	21
o|    ##sys#size	24
o|    fx>	6
o|    string?	2
o|    symbol?
o|    char?	4
o|    number?
o|    string
o|    string-length	4
o|    string-ref
o|    string-set!
o|    fx+	31
o|    ##sys#setslot	17
o|    pair?	18
o|    ##sys#check-exact	7
o|    fx<=	4
o|    length	2
o|    fx<	6
o|    fx=	7
o|    fx-	15
o|    list	6
o|    list?
o|    ##sys#check-pair	2
o|    cdr	12
o|    cons	37
o|    ##sys#check-list	8
o|    void
o|    not-pair?
o|    call-with-values
o|    not	3
o|    eq?	23
o|    apply	8
o|    car	33
o|    null?	56
o|    ##sys#slot	80
o|contracted procedure: k1362 
o|contracted procedure: k1371 
o|contracted procedure: k1381 
o|contracted procedure: k1418 
o|contracted procedure: k1401 
o|contracted procedure: k1414 
o|contracted procedure: k1427 
o|contracted procedure: k1430 
o|contracted procedure: k1471 
o|contracted procedure: k1492 
o|contracted procedure: k1504 
o|contracted procedure: k1513 
o|contracted procedure: k1516 
o|contracted procedure: k1522 
o|contracted procedure: k1551 
o|contracted procedure: k1557 
o|contracted procedure: k1570 
o|contracted procedure: k1574 
o|contracted procedure: k1583 
o|contracted procedure: k1630 
o|contracted procedure: k1594 
o|contracted procedure: k1608 
o|contracted procedure: k1611 
o|contracted procedure: k1617 
o|contracted procedure: k1642 
o|contracted procedure: k1664 
o|contracted procedure: k1679 
o|contracted procedure: k1689 
o|contracted procedure: k1693 
o|contracted procedure: k1703 
o|contracted procedure: k1712 
o|contracted procedure: k1718 
o|contracted procedure: k1725 
o|contracted procedure: k1744 
o|contracted procedure: k1747 
o|contracted procedure: k1750 
o|contracted procedure: k1756 
o|contracted procedure: k1776 
o|contracted procedure: k1782 
o|contracted procedure: k1794 
o|contracted procedure: k1800 
o|contracted procedure: k1815 
o|contracted procedure: k1830 
o|contracted procedure: k1849 
o|contracted procedure: k1837 
o|contracted procedure: k1841 
o|contracted procedure: k1845 
o|contracted procedure: k1852 
o|contracted procedure: k1864 
o|contracted procedure: k1876 
o|contracted procedure: k1908 
o|contracted procedure: k1888 
o|contracted procedure: k1891 
o|contracted procedure: k1897 
o|contracted procedure: k1911 
o|contracted procedure: k1918 
o|contracted procedure: k1930 
o|contracted procedure: k1992 
o|contracted procedure: k1988 
o|contracted procedure: k1954 
o|contracted procedure: k1961 
o|contracted procedure: k1969 
o|contracted procedure: k1973 
o|contracted procedure: k1980 
o|contracted procedure: k1984 
o|contracted procedure: k2075 
o|contracted procedure: k1998 
o|contracted procedure: k2010 
o|contracted procedure: k2017 
o|contracted procedure: k2020 
o|contracted procedure: k2026 
o|contracted procedure: k2032 
o|contracted procedure: k2046 
o|contracted procedure: k2049 
o|contracted procedure: k2062 
o|contracted procedure: k2065 
o|contracted procedure: k2072 
o|contracted procedure: k2179 
o|contracted procedure: k2084 
o|contracted procedure: k2096 
o|contracted procedure: k2103 
o|contracted procedure: k2176 
o|contracted procedure: k2115 
o|contracted procedure: k2172 
o|contracted procedure: k2137 
o|contracted procedure: k2141 
o|contracted procedure: k2160 
o|contracted procedure: k2164 
o|contracted procedure: k2148 
o|contracted procedure: k2156 
o|contracted procedure: k2168 
o|contracted procedure: k2285 
o|contracted procedure: k2188 
o|contracted procedure: k2279 
o|contracted procedure: k2191 
o|contracted procedure: k2273 
o|contracted procedure: k2194 
o|contracted procedure: k2267 
o|contracted procedure: k2197 
o|contracted procedure: k2212 
o|contracted procedure: k2218 
o|contracted procedure: k2224 
o|contracted procedure: k2238 
o|contracted procedure: k2241 
o|contracted procedure: k2254 
o|contracted procedure: k2257 
o|contracted procedure: k2264 
o|contracted procedure: k2294 
o|contracted procedure: k2309 
o|contracted procedure: k2312 
o|contracted procedure: k2315 
o|contracted procedure: k2328 
o|contracted procedure: k2332 
o|contracted procedure: k2335 
o|contracted procedure: k2348 
o|contracted procedure: k2352 
o|contracted procedure: k2397 
o|contracted procedure: k2393 
o|contracted procedure: k2362 
o|contracted procedure: k2371 
o|contracted procedure: k2389 
o|contracted procedure: k2374 
o|contracted procedure: k2381 
o|contracted procedure: k2385 
o|contracted procedure: k2403 
o|contracted procedure: k2418 
o|contracted procedure: k2424 
o|contracted procedure: k2433 
o|contracted procedure: k2442 
o|contracted procedure: k2473 
o|contracted procedure: k2476 
o|contracted procedure: k2487 
o|contracted procedure: k2499 
o|contracted procedure: k2505 
o|contracted procedure: k2508 
o|contracted procedure: k2511 
o|contracted procedure: k2514 
o|contracted procedure: k2517 
o|contracted procedure: k2529 
o|contracted procedure: k2542 
o|contracted procedure: k2546 
o|contracted procedure: k2576 
o|contracted procedure: k2570 
o|contracted procedure: k2591 
o|contracted procedure: k2585 
o|contracted procedure: k2600 
o|contracted procedure: k2603 
o|contracted procedure: k2606 
o|contracted procedure: k2609 
o|contracted procedure: k2612 
o|contracted procedure: k2625 
o|contracted procedure: k2616 
o|contracted procedure: k2622 
o|contracted procedure: k2631 
o|contracted procedure: k2634 
o|contracted procedure: k2637 
o|contracted procedure: k2640 
o|contracted procedure: k2643 
o|contracted procedure: k2656 
o|contracted procedure: k2647 
o|contracted procedure: k2653 
o|contracted procedure: k2662 
o|contracted procedure: k2665 
o|contracted procedure: k2671 
o|contracted procedure: k2674 
o|contracted procedure: k2693 
o|contracted procedure: k2681 
o|contracted procedure: k2689 
o|contracted procedure: k2685 
o|contracted procedure: k2750 
o|contracted procedure: k2699 
o|contracted procedure: k2744 
o|contracted procedure: k2702 
o|contracted procedure: k2738 
o|contracted procedure: k2705 
o|contracted procedure: k2732 
o|contracted procedure: k2708 
o|contracted procedure: k2726 
o|contracted procedure: k2711 
o|contracted procedure: k2720 
o|contracted procedure: k2714 
o|contracted procedure: k2759 
o|contracted procedure: k2762 
o|contracted procedure: k2768 
o|contracted procedure: k2771 
o|contracted procedure: k2790 
o|contracted procedure: k2778 
o|contracted procedure: k2786 
o|contracted procedure: k2782 
o|contracted procedure: k2847 
o|contracted procedure: k2796 
o|contracted procedure: k2841 
o|contracted procedure: k2799 
o|contracted procedure: k2835 
o|contracted procedure: k2802 
o|contracted procedure: k2829 
o|contracted procedure: k2805 
o|contracted procedure: k2823 
o|contracted procedure: k2808 
o|contracted procedure: k2817 
o|contracted procedure: k2811 
o|contracted procedure: k2856 
o|contracted procedure: k2981 
o|contracted procedure: k2859 
o|contracted procedure: k2973 
o|contracted procedure: k2862 
o|contracted procedure: k2865 
o|contracted procedure: k2868 
o|contracted procedure: k2871 
o|contracted procedure: k2877 
o|contracted procedure: k2880 
o|contracted procedure: k2900 
o|contracted procedure: k2909 
o|contracted procedure: k2912 
o|contracted procedure: k2927 
o|contracted procedure: k2934 
o|contracted procedure: k2940 
o|contracted procedure: k2943 
o|contracted procedure: k2949 
o|contracted procedure: k2952 
o|contracted procedure: k2969 
o|contracted procedure: k3083 
o|contracted procedure: k2990 
o|contracted procedure: k2993 
o|contracted procedure: k2996 
o|contracted procedure: k2999 
o|contracted procedure: k3023 
o|contracted procedure: k3026 
o|contracted procedure: k3029 
o|contracted procedure: k3032 
o|contracted procedure: k3042 
o|contracted procedure: k3046 
o|contracted procedure: k3052 
o|contracted procedure: k3055 
o|contracted procedure: k3058 
o|contracted procedure: k3065 
o|contracted procedure: k3073 
o|contracted procedure: k3077 
o|contracted procedure: k3069 
o|contracted procedure: k3095 
o|contracted procedure: k3109 
o|contracted procedure: k3115 
o|contracted procedure: k3122 
o|contracted procedure: k3237 
o|contracted procedure: k3132 
o|contracted procedure: k3135 
o|contracted procedure: k3138 
o|contracted procedure: k3153 
o|contracted procedure: k3159 
o|contracted procedure: k3201 
o|contracted procedure: k3208 
o|contracted procedure: k3212 
o|contracted procedure: k3218 
o|contracted procedure: k3229 
o|contracted procedure: k3233 
o|contracted procedure: k3195 
o|contracted procedure: k3178 
o|contracted procedure: k3182 
o|contracted procedure: k3243 
o|contracted procedure: k3246 
o|contracted procedure: k3252 
o|contracted procedure: k3258 
o|contracted procedure: k3264 
o|contracted procedure: k3267 
o|contracted procedure: k3278 
o|contracted procedure: k3288 
o|contracted procedure: k3297 
o|contracted procedure: k3300 
o|contracted procedure: k3303 
o|contracted procedure: k3312 
o|contracted procedure: k3326 
o|contracted procedure: k3323 
o|contracted procedure: k3345 
o|contracted procedure: k3352 
o|contracted procedure: k3356 
o|contracted procedure: k3359 
o|contracted procedure: k3362 
o|contracted procedure: k3365 
o|contracted procedure: k3372 
o|contracted procedure: k3390 
o|contracted procedure: k3382 
o|contracted procedure: k3386 
o|contracted procedure: k3393 
o|contracted procedure: k3397 
o|contracted procedure: k3415 
o|contracted procedure: k3418 
o|contracted procedure: k3421 
o|contracted procedure: k3433 
o|contracted procedure: k3439 
o|contracted procedure: k3450 
o|contracted procedure: k3465 
o|contracted procedure: k3469 
o|contracted procedure: k3473 
o|contracted procedure: k3509 
o|contracted procedure: k3479 
o|contracted procedure: k3482 
o|contracted procedure: k3485 
o|contracted procedure: k3488 
o|contracted procedure: k3491 
o|contracted procedure: k3494 
o|contracted procedure: k3506 
o|contracted procedure: k3500 
o|contracted procedure: k3521 
o|contracted procedure: k3527 
o|contracted procedure: k3530 
o|contracted procedure: k3536 
o|contracted procedure: k3548 
o|contracted procedure: k3561 
o|contracted procedure: k3568 
o|contracted procedure: k3576 
o|contracted procedure: k3572 
o|contracted procedure: k3586 
o|contracted procedure: k3594 
o|contracted procedure: k3618 
o|contracted procedure: k3627 
o|contracted procedure: k3633 
o|contracted procedure: k3640 
o|contracted procedure: k3646 
o|contracted procedure: k3663 
o|contracted procedure: k3670 
o|contracted procedure: k3681 
o|contracted procedure: k3689 
o|contracted procedure: k3696 
o|contracted procedure: k3707 
o|contracted procedure: k3724 
o|contracted procedure: k3730 
o|contracted procedure: k3745 
o|contracted procedure: k3751 
o|contracted procedure: k3767 
o|contracted procedure: k3771 
o|contracted procedure: k3777 
o|contracted procedure: k3783 
o|contracted procedure: k3795 
o|inlining procedure: k3792 
o|contracted procedure: k3813 
o|inlining procedure: k3810 
o|contracted procedure: k3829 
o|contracted procedure: k3833 
o|contracted procedure: k3845 
o|contracted procedure: k3854 
o|contracted procedure: k3866 
o|contracted procedure: k3869 
o|contracted procedure: k3872 
o|contracted procedure: k3881 
o|contracted procedure: k3889 
o|contracted procedure: k3902 
o|contracted procedure: k3906 
o|contracted procedure: k3909 
o|contracted procedure: k3915 
o|contracted procedure: k3918 
o|contracted procedure: k3938 
o|contracted procedure: k3954 
o|contracted procedure: k3941 
o|contracted procedure: k3950 
o|contracted procedure: k3961 
o|contracted procedure: k3970 
o|contracted procedure: k4003 
o|contracted procedure: k4018 
o|contracted procedure: k4022 
o|contracted procedure: k4042 
o|contracted procedure: k4026 
o|contracted procedure: k4030 
o|contracted procedure: k4038 
o|contracted procedure: k4014 
o|contracted procedure: k4010 
o|contracted procedure: k4052 
o|contracted procedure: k4115 
o|contracted procedure: k4109 
o|contracted procedure: k4063 
o|contracted procedure: k4072 
o|contracted procedure: k4083 
o|contracted procedure: k4089 
o|contracted procedure: k4092 
o|contracted procedure: k4105 
o|contracted procedure: k4128 
o|contracted procedure: k4169 
o|contracted procedure: k4173 
o|contracted procedure: k4135 
o|contracted procedure: k4144 
o|contracted procedure: k4154 
o|contracted procedure: k4162 
o|contracted procedure: k4182 
o|contracted procedure: k4188 
o|contracted procedure: k4246 
o|contracted procedure: k4197 
o|contracted procedure: k4200 
o|contracted procedure: k4209 
o|contracted procedure: k4215 
o|contracted procedure: k4228 
o|contracted procedure: k4241 
o|contracted procedure: k4249 
o|contracted procedure: k4274 
o|contracted procedure: k4283 
o|contracted procedure: k4290 
o|contracted procedure: k4296 
o|contracted procedure: k4299 
o|contracted procedure: k4308 
o|contracted procedure: k4317 
o|contracted procedure: k4320 
o|contracted procedure: k4329 
o|contracted procedure: k4338 
o|contracted procedure: k4341 
o|contracted procedure: k4347 
o|contracted procedure: k4358 
o|contracted procedure: k4354 
o|contracted procedure: k4350 
o|contracted procedure: k4375 
o|contracted procedure: k4361 
o|contracted procedure: k4371 
o|contracted procedure: k4381 
o|contracted procedure: k4384 
o|contracted procedure: k4390 
o|contracted procedure: k4393 
o|contracted procedure: k4413 
o|contracted procedure: k4396 
o|contracted procedure: k4410 
o|contracted procedure: k4406 
o|contracted procedure: k4399 
o|contracted procedure: k4419 
o|contracted procedure: k4428 
o|contracted procedure: k4435 
o|contracted procedure: k4444 
o|contracted procedure: k4454 
o|contracted procedure: k4462 
o|contracted procedure: k4458 
o|contracted procedure: k4468 
o|contracted procedure: k4480 
o|contracted procedure: k4520 
o|contracted procedure: k4492 
o|contracted procedure: k4502 
o|contracted procedure: k4505 
o|contracted procedure: k45025081 
o|contracted procedure: k4526 
o|contracted procedure: k4560 
o|contracted procedure: k4529 
o|contracted procedure: k4532 
o|contracted procedure: k4556 
o|contracted procedure: k4549 
o|contracted procedure: k4535 
o|contracted procedure: k4546 
o|contracted procedure: k4542 
o|contracted procedure: k4566 
o|contracted procedure: k4569 
o|contracted procedure: k4578 
o|contracted procedure: k4581 
o|contracted procedure: k4592 
o|contracted procedure: k4588 
o|contracted procedure: k4596 
o|contracted procedure: k4621 
o|contracted procedure: k4610 
o|contracted procedure: k4617 
o|contracted procedure: k4628 
o|simplifications: ((let . 86)) 
o|removed binding forms: 450 
o|inlining procedure: k2479 
o|inlining procedure: k2479 
o|inlining procedure: k3878 
o|inlining procedure: k3878 
o|substituted constant variable: r4170 
o|substituted constant variable: r4170 
o|substituted constant variable: r4174 
o|replaced variables: 159 
o|removed binding forms: 89 
o|replaced variables: 4 
o|removed binding forms: 1 
o|direct leaf routine/allocation: loop152 0 
o|direct leaf routine/allocation: loop344 0 
o|direct leaf routine/allocation: loop2600 0 
o|direct leaf routine/allocation: loop624 0 
o|direct leaf routine/allocation: doloop932933 0 
o|converted assignments to bindings: (loop152) 
o|converted assignments to bindings: (loop344) 
o|converted assignments to bindings: (loop2600) 
o|converted assignments to bindings: (loop624) 
o|converted assignments to bindings: (doloop932933) 
o|simplifications: ((let . 5)) 
o|customizable procedures: (k4575 k4508 doloop908909 loop901 k4344 k4179 loop845 loop835 visit812 walk827 doloop798799 step776 loop764 loop750 loop734 doloop727728 loop690 loop674 k3375 collect669 instring620 loop650 loop1592 scan563 loop547 add541 k2765 k2668 traverse386 loop394 map-loop362379 rev-string-append338 k2297 loop329 loop317 k2200 loop279 loop256 k2001 loop225 k1861 loop211 doloop198199 loop191 loop177 loop169 loop163 loop136 loop121 loop110 loop80 loop68) 
o|calls to known targets: 133 
o|unused rest argument: _92 f_1433 
o|unused rest argument: _93 f_1435 
o|unused rest argument: _134 f_1586 
o|identified direct recursive calls: f_1652 1 
o|identified direct recursive calls: f_1674 1 
o|identified direct recursive calls: f_1710 1 
o|identified direct recursive calls: f_1739 2 
o|identified direct recursive calls: f_1810 1 
o|identified direct recursive calls: f_1871 1 
o|identified direct recursive calls: f_1925 2 
o|identified direct recursive calls: f_2366 1 
o|identified direct recursive calls: f_2343 1 
o|identified direct recursive calls: f_2922 1 
o|identified direct recursive calls: f_3021 1 
o|identified direct recursive calls: f_3006 1 
o|identified direct recursive calls: f_3104 1 
o|identified direct recursive calls: f_3340 1 
o|identified direct recursive calls: f_3933 1 
o|identified direct recursive calls: f_4439 1 
o|identified direct recursive calls: f_4605 1 
o|fast box initializations: 39 
o|dropping unused closure argument: f_3093 
o|dropping unused closure argument: f_4605 
o|dropping unused closure argument: f_2503 
*/
/* end of file */
