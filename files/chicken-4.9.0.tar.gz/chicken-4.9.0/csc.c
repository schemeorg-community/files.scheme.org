/* Generated from csc.scm by the CHICKEN compiler
   http://www.call-cc.org
   2014-06-02 16:40
   Version 4.9.0 (rev 3f195ba)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2014-06-02 on yves (Linux)
   command line: csc.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -no-lambda-info -local -no-trace -output-file csc.c
   used units: library eval chicken_2dsyntax data_2dstructures ports srfi_2d1 srfi_2d13 utils files extras
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_chicken_2dsyntax_toplevel)
C_externimport void C_ccall C_chicken_2dsyntax_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_2dstructures_toplevel)
C_externimport void C_ccall C_data_2dstructures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_2d1_toplevel)
C_externimport void C_ccall C_srfi_2d1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_2d13_toplevel)
C_externimport void C_ccall C_srfi_2d13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[430];
static double C_possibly_force_alignment;


C_noret_decl(f_1700)
static void C_ccall f_1700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4178)
static void C_ccall f_4178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4170)
static void C_ccall f_4170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2108)
static void C_ccall f_2108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3576)
static void C_fcall f_3576(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3572)
static void C_ccall f_3572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2136)
static void C_ccall f_2136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3584)
static void C_ccall f_3584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4982)
static void C_ccall f_4982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2120)
static void C_ccall f_2120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2127)
static void C_ccall f_2127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4475)
static void C_fcall f_4475(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1739)
static void C_ccall f_1739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4992)
static void C_ccall f_4992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4996)
static void C_ccall f_4996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4488)
static void C_ccall f_4488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1746)
static void C_ccall f_1746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4968)
static void C_ccall f_4968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4964)
static void C_ccall f_4964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f6337)
static void C_ccall f6337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1716)
static void C_ccall f_1716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4186)
static void C_ccall f_4186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4978)
static void C_ccall f_4978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4182)
static void C_ccall f_4182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3177)
static void C_ccall f_3177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4468)
static void C_ccall f_4468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1723)
static void C_ccall f_1723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4195)
static void C_ccall f_4195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4198)
static void C_ccall f_4198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4460)
static void C_fcall f_4460(C_word t0) C_noret;
C_noret_decl(f_4191)
static void C_ccall f_4191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2989)
static void C_ccall f_2989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4953)
static void C_ccall f_4953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1779)
static void C_fcall f_1779(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2805)
static void C_fcall f_2805(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2537)
static void C_ccall f_2537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2809)
static void C_ccall f_2809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1784)
static void C_ccall f_1784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1786)
static void C_fcall f_1786(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4498)
static void C_ccall f_4498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4490)
static void C_fcall f_4490(C_word t0) C_noret;
C_noret_decl(f_4245)
static void C_ccall f_4245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2557)
static void C_ccall f_2557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4248)
static void C_ccall f_4248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2956)
static void C_fcall f_2956(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4255)
static void C_ccall f_4255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2547)
static void C_ccall f_2547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2817)
static void C_ccall f_2817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3182)
static void C_ccall f_3182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3188)
static void C_ccall f_3188(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2946)
static void C_ccall f_2946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f6332)
static void C_ccall f6332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3199)
static void C_ccall f_3199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4202)
static void C_ccall f_4202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4206)
static void C_ccall f_4206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3753)
static void C_ccall f_3753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4212)
static void C_ccall f_4212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4215)
static void C_ccall f_4215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3047)
static void C_ccall f_3047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3765)
static void C_ccall f_3765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3769)
static void C_fcall f_3769(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3768)
static void C_fcall f_3768(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2907)
static C_word C_fcall f_2907(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_3043)
static void C_fcall f_3043(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2900)
static void C_fcall f_2900(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3730)
static void C_ccall f_3730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3734)
static void C_ccall f_3734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3738)
static void C_fcall f_3738(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2937)
static void C_ccall f_2937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5981)
static void C_ccall f5981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3742)
static void C_ccall f_3742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4588)
static void C_ccall f_4588(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4580)
static void C_ccall f_4580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5971)
static void C_ccall f5971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5976)
static void C_ccall f5976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1469)
static void C_ccall f_1469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3681)
static void C_ccall f_3681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3033)
static void C_ccall f_3033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4595)
static void C_ccall f_4595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5961)
static void C_ccall f5961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1403)
static void C_fcall f_1403(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1400)
static void C_ccall f_1400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5966)
static void C_ccall f5966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4939)
static void C_ccall f_4939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4791)
static void C_ccall f_4791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3696)
static void C_fcall f_3696(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3003)
static void C_ccall f_3003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1416)
static void C_ccall f_1416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1413)
static void C_ccall f_1413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4225)
static void C_ccall f_4225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1410)
static void C_ccall f_1410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4905)
static void C_ccall f_4905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4573)
static void C_fcall f_4573(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1426)
static void C_ccall f_1426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4235)
static void C_ccall f_4235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4775)
static void C_ccall f_4775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4778)
static void C_ccall f_4778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4772)
static void C_ccall f_4772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2049)
static void C_ccall f_2049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1419)
static void C_ccall f_1419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4910)
static void C_fcall f_4910(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4783)
static void C_ccall f_4783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2075)
static void C_ccall f_2075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2022)
static void C_ccall f_2022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2052)
static void C_ccall f_2052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2058)
static void C_ccall f_2058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2055)
static void C_ccall f_2055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2082)
static void C_ccall f_2082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2086)
static void C_ccall f_2086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3671)
static void C_fcall f_3671(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2887)
static void C_ccall f_2887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1473)
static void C_ccall f_1473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4271)
static void C_ccall f_4271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4267)
static void C_ccall f_4267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4264)
static void C_ccall f_4264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1481)
static void C_ccall f_1481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3264)
static void C_ccall f_3264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2378)
static void C_ccall f_2378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4718)
static void C_ccall f_4718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2068)
static void C_ccall f_2068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2766)
static void C_ccall f_2766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1477)
static void C_ccall f_1477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2866)
static void C_ccall f_2866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2869)
static void C_ccall f_2869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4275)
static void C_ccall f_4275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3089)
static void C_fcall f_3089(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4279)
static void C_ccall f_4279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3087)
static void C_ccall f_3087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3276)
static void C_fcall f_3276(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1493)
static void C_ccall f_1493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4727)
static void C_ccall f_4727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2093)
static void C_ccall f_2093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4724)
static void C_ccall f_4724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2096)
static void C_ccall f_2096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2753)
static void C_ccall f_2753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1489)
static void C_ccall f_1489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1485)
static void C_ccall f_1485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2897)
static void C_fcall f_2897(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2894)
static void C_ccall f_2894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3280)
static void C_ccall f_3280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3288)
static void C_ccall f_3288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2012)
static void C_fcall f_2012(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2015)
static void C_fcall f_2015(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3020)
static void C_ccall f_3020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2385)
static void C_ccall f_2385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2382)
static void C_ccall f_2382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3297)
static void C_ccall f_3297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3070)
static void C_ccall f_3070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4291)
static void C_ccall f_4291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4031)
static void C_ccall f_4031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4285)
static void C_ccall f_4285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4288)
static void C_ccall f_4288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4261)
static void C_ccall f_4261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4042)
static void C_fcall f_4042(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4295)
static void C_ccall f_4295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4299)
static void C_ccall f_4299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3303)
static void C_ccall f_3303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4016)
static void C_ccall f_4016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4019)
static void C_ccall f_4019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4022)
static void C_ccall f_4022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4025)
static void C_ccall f_4025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4028)
static void C_ccall f_4028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5008)
static void C_ccall f_5008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3335)
static void C_ccall f_3335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4086)
static void C_ccall f_4086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4082)
static void C_ccall f_4082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4356)
static void C_ccall f_4356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5903)
static void C_ccall f5903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5035)
static void C_ccall f_5035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5049)
static void C_ccall f_5049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4336)
static void C_fcall f_4336(C_word t0) C_noret;
C_noret_decl(f_4330)
static void C_ccall f_4330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4757)
static void C_ccall f_4757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4754)
static void C_ccall f_4754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5039)
static void C_ccall f_5039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4301)
static void C_fcall f_4301(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4766)
static void C_ccall f_4766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4769)
static void C_ccall f_4769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4763)
static void C_ccall f_4763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4760)
static void C_ccall f_4760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4736)
static void C_ccall f_4736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5004)
static void C_ccall f_5004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5000)
static void C_ccall f_5000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5946)
static void C_ccall f5946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4730)
static void C_ccall f_4730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4733)
static void C_ccall f_4733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5931)
static void C_ccall f5931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4744)
static void C_ccall f_4744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4748)
static void C_ccall f_4748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1609)
static void C_fcall f_1609(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5076)
static void C_ccall f_5076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4740)
static void C_ccall f_4740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1605)
static void C_fcall f_1605(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2270)
static void C_fcall f_2270(C_word t0,C_word t1) C_noret;
C_noret_decl(f5920)
static void C_ccall f5920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2273)
static void C_ccall f_2273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5062)
static void C_ccall f_5062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5925)
static void C_ccall f5925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1943)
static void C_ccall f_1943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1940)
static void C_ccall f_1940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3996)
static void C_ccall f_3996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4344)
static void C_ccall f_4344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4568)
static void C_ccall f_4568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1613)
static void C_ccall f_1613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1616)
static void C_ccall f_1616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1947)
static void C_ccall f_1947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5069)
static void C_ccall f_5069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5106)
static void C_ccall f_5106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1951)
static void C_ccall f_1951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1430)
static void C_ccall f_1430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1434)
static void C_ccall f_1434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1626)
static void C_ccall f_1626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1955)
static void C_ccall f_1955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1922)
static void C_ccall f_1922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4545)
static void C_fcall f_4545(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1631)
static void C_fcall f_1631(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1928)
static void C_ccall f_1928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2247)
static void C_ccall f_2247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4543)
static void C_ccall f_4543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1457)
static void C_ccall f_1457(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3860)
static void C_ccall f_3860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3951)
static void C_fcall f_3951(C_word t0) C_noret;
C_noret_decl(f_4525)
static void C_ccall f_4525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1465)
static void C_ccall f_1465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3959)
static void C_ccall f_3959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5951)
static void C_ccall f5951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5142)
static void C_ccall f_5142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5096)
static void C_ccall f_5096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2235)
static void C_ccall f_2235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5956)
static void C_ccall f5956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5146)
static void C_ccall f_5146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4535)
static void C_ccall f_4535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3837)
static void C_ccall f_3837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4539)
static void C_ccall f_4539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5134)
static void C_ccall f_5134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5130)
static void C_ccall f_5130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1677)
static void C_ccall f_1677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2223)
static void C_ccall f_2223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5086)
static void C_ccall f_5086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5138)
static void C_ccall f_5138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3806)
static void C_ccall f_3806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3800)
static void C_ccall f_3800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2285)
static void C_ccall f_2285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4502)
static void C_fcall f_4502(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2975)
static void C_ccall f_2975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1689)
static void C_ccall f_1689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1685)
static void C_ccall f_1685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2211)
static void C_ccall f_2211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5126)
static void C_ccall f_5126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3850)
static void C_fcall f_3850(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2965)
static void C_fcall f_2965(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3560)
static void C_ccall f_3560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5116)
static void C_ccall f_5116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3564)
static void C_ccall f_3564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3568)
static void C_ccall f_3568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1693)
static void C_ccall f_1693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3827)
static void C_fcall f_3827(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4606)
static void C_ccall f_4606(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3537)
static void C_ccall f_3537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3534)
static void C_ccall f_3534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3540)
static void C_ccall f_3540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3544)
static void C_ccall f_3544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3548)
static void C_ccall f_3548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1931)
static void C_ccall f_1931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1934)
static void C_ccall f_1934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1937)
static void C_ccall f_1937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5156)
static void C_ccall f_5156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1900)
static void C_ccall f_1900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1903)
static void C_ccall f_1903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1909)
static void C_ccall f_1909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1906)
static void C_ccall f_1906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3150)
static void C_ccall f_3150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1915)
static void C_ccall f_1915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1912)
static void C_ccall f_1912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4699)
static void C_ccall f_4699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4695)
static void C_ccall f_4695(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4693)
static void C_ccall f_4693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3129)
static void C_ccall f_3129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1373)
static void C_ccall f_1373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1376)
static void C_ccall f_1376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1370)
static void C_ccall f_1370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1379)
static void C_ccall f_1379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4679)
static void C_fcall f_4679(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4895)
static void C_ccall f_4895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4892)
static void C_ccall f_4892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1355)
static void C_ccall f_1355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1352)
static void C_ccall f_1352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3118)
static void C_ccall f_3118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1358)
static void C_ccall f_1358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1364)
static void C_ccall f_1364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1361)
static void C_ccall f_1361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4878)
static void C_ccall f_4878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4871)
static void C_ccall f_4871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1367)
static void C_ccall f_1367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4888)
static void C_fcall f_4888(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2567)
static void C_ccall f_2567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4052)
static void C_ccall f_4052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4069)
static void C_ccall f_4069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4066)
static void C_fcall f_4066(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2517)
static void C_ccall f_2517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1660)
static void C_ccall f_1660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4397)
static void C_ccall f_4397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1888)
static void C_ccall f_1888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4390)
static void C_ccall f_4390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2527)
static void C_ccall f_2527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2441)
static void C_ccall f_2441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2445)
static void C_ccall f_2445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3133)
static void C_ccall f_3133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4816)
static void C_ccall f_4816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4362)
static void C_ccall f_4362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2437)
static void C_ccall f_2437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1515)
static void C_ccall f_1515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1511)
static void C_ccall f_1511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1519)
static void C_ccall f_1519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4827)
static void C_ccall f_4827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4822)
static void C_ccall f_4822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3642)
static void C_ccall f_3642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1524)
static void C_ccall f_1524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1529)
static void C_ccall f_1529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2577)
static void C_ccall f_2577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1852)
static void C_fcall f_1852(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4809)
static void C_ccall f_4809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1505)
static void C_fcall f_1505(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4661)
static void C_ccall f_4661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2597)
static void C_ccall f_2597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2469)
static void C_ccall f_2469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4655)
static void C_ccall f_4655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4658)
static void C_ccall f_4658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1559)
static void C_ccall f_1559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2706)
static void C_ccall f_2706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4632)
static void C_ccall f_4632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5846)
static void C_ccall f5846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2587)
static void C_ccall f_2587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4146)
static void C_ccall f_4146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4664)
static void C_ccall f_4664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1563)
static void C_ccall f_1563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3245)
static void C_ccall f_3245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3240)
static void C_fcall f_3240(C_word t0,C_word t1) C_noret;
C_noret_decl(f5836)
static void C_ccall f5836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4158)
static void C_ccall f_4158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4635)
static void C_ccall f_4635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4638)
static void C_ccall f_4638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5814)
static void C_ccall f5814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2727)
static void C_ccall f_2727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1812)
static void C_fcall f_1812(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3796)
static void C_ccall f_3796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2710)
static void C_ccall f_2710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1821)
static void C_ccall f_1821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3621)
static void C_ccall f_3621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5819)
static void C_ccall f5819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1817)
static void C_ccall f_1817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4401)
static void C_ccall f_4401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4618)
static void C_ccall f_4618(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1594)
static void C_ccall f_1594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2496)
static void C_ccall f_2496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5871)
static void C_ccall f5871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5888)
static void C_ccall f5888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4102)
static void C_fcall f_4102(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4105)
static void C_ccall f_4105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3776)
static void C_ccall f_3776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3773)
static void C_ccall f_3773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4629)
static void C_ccall f_4629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2731)
static void C_ccall f_2731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5866)
static void C_ccall f5866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4601)
static void C_ccall f_4601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2739)
static void C_ccall f_2739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5861)
static void C_ccall f5861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5878)
static void C_ccall f5878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2480)
static void C_ccall f_2480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1835)
static C_word C_fcall f_1835(C_word *a);
C_noret_decl(f_3788)
static void C_ccall f_3788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5856)
static void C_ccall f5856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3213)
static void C_ccall f_3213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5851)
static void C_ccall f5851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1578)
static void C_ccall f_1578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4437)
static void C_ccall f_4437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4431)
static void C_ccall f_4431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4434)
static void C_ccall f_4434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5841)
static void C_ccall f5841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1586)
static void C_ccall f_1586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4446)
static void C_ccall f_4446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4443)
static void C_ccall f_4443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4440)
static void C_ccall f_4440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4415)
static void C_ccall f_4415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4417)
static void C_fcall f_4417(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4856)
static void C_ccall f_4856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4859)
static void C_ccall f_4859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2778)
static void C_ccall f_2778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2770)
static void C_ccall f_2770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4853)
static void C_ccall f_4853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4425)
static void C_ccall f_4425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4867)
static void C_ccall f_4867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3938)
static void C_ccall f_3938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4863)
static void C_ccall f_4863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5893)
static void C_ccall f5893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4129)
static void C_ccall f_4129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4125)
static void C_ccall f_4125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4835)
static void C_ccall f_4835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4121)
static void C_ccall f_4121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3901)
static void C_fcall f_3901(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3718)
static void C_ccall f_3718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3907)
static void C_ccall f_3907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3904)
static void C_ccall f_3904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2791)
static void C_ccall f_2791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5883)
static void C_ccall f5883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5898)
static void C_ccall f5898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f6342)
static void C_ccall f6342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4136)
static void C_ccall f_4136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4133)
static void C_ccall f_4133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3919)
static void C_ccall f_3919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4454)
static void C_ccall f_4454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4450)
static void C_ccall f_4450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3965)
static void C_ccall f_3965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3967)
static void C_fcall f_3967(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3703)
static void C_ccall f_3703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3706)
static void C_ccall f_3706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3700)
static void C_ccall f_3700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3227)
static void C_ccall f_3227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1863)
static void C_ccall f_1863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1867)
static void C_ccall f_1867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1870)
static void C_ccall f_1870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1873)
static void C_ccall f_1873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1876)
static void C_fcall f_1876(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3926)
static void C_ccall f_3926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3928)
static void C_fcall f_3928(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1882)
static void C_ccall f_1882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1974)
static void C_ccall f_1974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1977)
static void C_ccall f_1977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2655)
static void C_ccall f_2655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2638)
static void C_ccall f_2638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2614)
static void C_fcall f_2614(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1984)
static void C_ccall f_1984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3810)
static void C_ccall f_3810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2689)
static void C_ccall f_2689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3819)
static void C_ccall f_3819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2672)
static void C_ccall f_2672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2185)
static void C_ccall f_2185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3887)
static void C_ccall f_3887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2846)
static void C_ccall f_2846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2849)
static void C_ccall f_2849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2143)
static void C_ccall f_2143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3875)
static void C_ccall f_3875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3877)
static void C_fcall f_3877(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2821)
static void C_ccall f_2821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5160)
static void C_ccall f_5160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2174)
static void C_ccall f_2174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5164)
static void C_ccall f_5164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5168)
static void C_ccall f_5168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3592)
static void C_fcall f_3592(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3590)
static void C_ccall f_3590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4162)
static void C_ccall f_4162(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_3576)
static void C_fcall trf_3576(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3576(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3576(t0,t1);}

C_noret_decl(trf_4475)
static void C_fcall trf_4475(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4475(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4475(t0,t1);}

C_noret_decl(trf_4460)
static void C_fcall trf_4460(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4460(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_4460(t0);}

C_noret_decl(trf_1779)
static void C_fcall trf_1779(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1779(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1779(t0,t1);}

C_noret_decl(trf_2805)
static void C_fcall trf_2805(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2805(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2805(t0,t1);}

C_noret_decl(trf_1786)
static void C_fcall trf_1786(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1786(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1786(t0,t1,t2,t3);}

C_noret_decl(trf_4490)
static void C_fcall trf_4490(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4490(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_4490(t0);}

C_noret_decl(trf_2956)
static void C_fcall trf_2956(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2956(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2956(t0,t1);}

C_noret_decl(trf_3769)
static void C_fcall trf_3769(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3769(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3769(t0,t1,t2);}

C_noret_decl(trf_3768)
static void C_fcall trf_3768(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3768(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3768(t0,t1);}

C_noret_decl(trf_3043)
static void C_fcall trf_3043(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3043(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3043(t0,t1);}

C_noret_decl(trf_2900)
static void C_fcall trf_2900(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2900(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2900(t0,t1);}

C_noret_decl(trf_3738)
static void C_fcall trf_3738(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3738(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3738(t0,t1);}

C_noret_decl(trf_1403)
static void C_fcall trf_1403(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1403(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1403(t0,t1,t2);}

C_noret_decl(trf_3696)
static void C_fcall trf_3696(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3696(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3696(t0,t1,t2);}

C_noret_decl(trf_4573)
static void C_fcall trf_4573(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4573(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4573(t0,t1);}

C_noret_decl(trf_4910)
static void C_fcall trf_4910(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4910(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4910(t0,t1,t2);}

C_noret_decl(trf_3671)
static void C_fcall trf_3671(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3671(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3671(t0,t1,t2);}

C_noret_decl(trf_3089)
static void C_fcall trf_3089(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3089(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3089(t0,t1,t2);}

C_noret_decl(trf_3276)
static void C_fcall trf_3276(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3276(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3276(t0,t1);}

C_noret_decl(trf_2897)
static void C_fcall trf_2897(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2897(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2897(t0,t1);}

C_noret_decl(trf_2012)
static void C_fcall trf_2012(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2012(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2012(t0,t1);}

C_noret_decl(trf_2015)
static void C_fcall trf_2015(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2015(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2015(t0,t1);}

C_noret_decl(trf_4042)
static void C_fcall trf_4042(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4042(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4042(t0,t1,t2);}

C_noret_decl(trf_4336)
static void C_fcall trf_4336(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4336(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_4336(t0);}

C_noret_decl(trf_4301)
static void C_fcall trf_4301(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4301(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4301(t0,t1,t2);}

C_noret_decl(trf_1609)
static void C_fcall trf_1609(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1609(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1609(t0,t1);}

C_noret_decl(trf_1605)
static void C_fcall trf_1605(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1605(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1605(t0,t1);}

C_noret_decl(trf_2270)
static void C_fcall trf_2270(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2270(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2270(t0,t1);}

C_noret_decl(trf_4545)
static void C_fcall trf_4545(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4545(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4545(t0,t1,t2);}

C_noret_decl(trf_1631)
static void C_fcall trf_1631(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1631(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1631(t0,t1,t2);}

C_noret_decl(trf_3951)
static void C_fcall trf_3951(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3951(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_3951(t0);}

C_noret_decl(trf_4502)
static void C_fcall trf_4502(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4502(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4502(t0,t1);}

C_noret_decl(trf_3850)
static void C_fcall trf_3850(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3850(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3850(t0,t1,t2);}

C_noret_decl(trf_2965)
static void C_fcall trf_2965(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2965(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2965(t0,t1);}

C_noret_decl(trf_3827)
static void C_fcall trf_3827(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3827(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3827(t0,t1,t2);}

C_noret_decl(trf_4679)
static void C_fcall trf_4679(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4679(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4679(t0,t1);}

C_noret_decl(trf_4888)
static void C_fcall trf_4888(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4888(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4888(t0,t1);}

C_noret_decl(trf_4066)
static void C_fcall trf_4066(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4066(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4066(t0,t1);}

C_noret_decl(trf_1852)
static void C_fcall trf_1852(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1852(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1852(t0,t1,t2);}

C_noret_decl(trf_1505)
static void C_fcall trf_1505(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1505(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1505(t0,t1);}

C_noret_decl(trf_3240)
static void C_fcall trf_3240(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3240(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3240(t0,t1);}

C_noret_decl(trf_1812)
static void C_fcall trf_1812(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1812(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1812(t0,t1);}

C_noret_decl(trf_4102)
static void C_fcall trf_4102(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4102(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4102(t0,t1);}

C_noret_decl(trf_4417)
static void C_fcall trf_4417(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4417(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4417(t0,t1,t2);}

C_noret_decl(trf_3901)
static void C_fcall trf_3901(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3901(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3901(t0,t1);}

C_noret_decl(trf_3967)
static void C_fcall trf_3967(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3967(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3967(t0,t1,t2);}

C_noret_decl(trf_1876)
static void C_fcall trf_1876(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1876(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1876(t0,t1);}

C_noret_decl(trf_3928)
static void C_fcall trf_3928(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3928(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3928(t0,t1,t2);}

C_noret_decl(trf_2614)
static void C_fcall trf_2614(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2614(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2614(t0,t1);}

C_noret_decl(trf_3877)
static void C_fcall trf_3877(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3877(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3877(t0,t1,t2);}

C_noret_decl(trf_3592)
static void C_fcall trf_3592(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3592(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3592(t0,t1,t2);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

/* k1698 in k1683 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in ... */
static void C_ccall f_1700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1700,2,t0,t1);}
if(C_truep(C_retrieve2(lf[18],"chicken-prefix"))){
t2=C_a_i_list2(&a,2,C_retrieve2(lf[18],"chicken-prefix"),lf[239]);
/* csc.scm:88: make-pathname */
t3=C_fast_retrieve(lf[103]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,lf[240]);}
else{
/* csc.scm:266: conc */
t2=C_fast_retrieve(lf[235]);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[236],t1,lf[237]);}}

/* k4176 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in ... */
static void C_ccall f_4178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4178,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4182,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:933: linker-options */
f_4460(t3);}

/* k4168 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in ... */
static void C_ccall f_4170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:928: cons* */
t2=C_fast_retrieve(lf[125]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k2106 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_2108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:587: exit */
t2=C_fast_retrieve(lf[13]);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3574 in k3566 in k3535 in k3532 in for-each-loop469 in k2013 in k2010 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in ... */
static void C_fcall f_3576(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3576,NULL,2,t0,t1);}
t2=t1;
t3=C_fudge(C_fix(13));
t4=(C_truep(t3)?lf[213]:C_SCHEME_END_OF_LIST);
t5=t4;
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_retrieve2(lf[97],"quote-option");
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3584,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t5,a[5]=t9,a[6]=t7,a[7]=t10,tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve2(lf[58],"cpp-mode"))){
/* csc.scm:838: append */
t12=*((C_word*)lf[100]+1);
((C_proc6)(void*)(*((C_word*)t12+1)))(6,t12,t11,C_retrieve2(lf[50],"extra-features"),C_retrieve2(lf[76],"translate-options"),lf[214],C_retrieve2(lf[81],"translation-optimization-options"));}
else{
if(C_truep(C_retrieve2(lf[59],"objc-mode"))){
/* csc.scm:838: append */
t12=*((C_word*)lf[100]+1);
((C_proc6)(void*)(*((C_word*)t12+1)))(6,t12,t11,C_retrieve2(lf[50],"extra-features"),C_retrieve2(lf[76],"translate-options"),lf[215],C_retrieve2(lf[81],"translation-optimization-options"));}
else{
/* csc.scm:838: append */
t12=*((C_word*)lf[100]+1);
((C_proc6)(void*)(*((C_word*)t12+1)))(6,t12,t11,C_retrieve2(lf[50],"extra-features"),C_retrieve2(lf[76],"translate-options"),C_SCHEME_END_OF_LIST,C_retrieve2(lf[81],"translation-optimization-options"));}}}

/* k3570 in k3566 in k3535 in k3532 in for-each-loop469 in k2013 in k2010 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in ... */
static void C_ccall f_3572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:829: cons* */
t2=C_fast_retrieve(lf[125]);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],C_retrieve2(lf[27],"translator"),((C_word*)t0)[3],t1);}

/* k2134 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_2136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:593: exit */
t2=C_fast_retrieve(lf[13]);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3582 in k3574 in k3566 in k3535 in k3532 in for-each-loop469 in k2013 in k2010 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in ... */
static void C_ccall f_3584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3584,2,t0,t1);}
t2=C_i_check_list_2(t1,lf[98]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3590,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3592,a[2]=((C_word*)t0)[5],a[3]=t5,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_3592(t7,t3,t1);}

/* k4980 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in ... */
static void C_ccall f_4982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:224: string-append */
t2=*((C_word*)lf[119]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[415],t1);}

/* k2118 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_2120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:590: exit */
t2=C_fast_retrieve(lf[13]);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2125 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_2127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:589: print */
t2=*((C_word*)lf[136]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4473 in k4466 in linker-options in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in ... */
static void C_fcall f_4475(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* ##sys#string-append */
((C_proc4)C_fast_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[2],((C_word*)t0)[3],lf[114]);}
else{
/* ##sys#string-append */
((C_proc4)C_fast_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[2],((C_word*)t0)[3],lf[115]);}}

/* k1737 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_1739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1739,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1746,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_a_i_cons(&a,2,lf[249],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,t1,t3);
t5=C_a_i_cons(&a,2,lf[250],t4);
t6=C_a_i_cons(&a,2,t1,t5);
t7=C_a_i_cons(&a,2,lf[251],t6);
t8=C_a_i_cons(&a,2,t1,t7);
t9=C_a_i_cons(&a,2,lf[252],t8);
/* csc.scm:300: ##sys#print-to-string */
((C_proc3)C_fast_retrieve_symbol_proc(lf[153]))(3,*((C_word*)lf[153]+1),t2,t9);}

/* k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in ... */
static void C_ccall f_4992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4992,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
t3=C_mutate2(&lf[72] /* (set! default-library-files ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4978,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4982,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[21],"host-mode"))){
/* ##sys#peek-c-string */
t6=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_INSTALL_LIB_NAME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t6=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_TARGET_LIB_NAME),C_fix(0));}}

/* k4994 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in ... */
static void C_ccall f_4996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4996,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5946,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t4=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k4486 in linker-options in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in ... */
static void C_ccall f_4488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:999: string-intersperse */
t2=C_fast_retrieve(lf[99]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1744 in k1737 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in ... */
static void C_ccall f_1746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:302: print */
t2=*((C_word*)lf[136]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4966 in k4962 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in ... */
static void C_ccall f_4968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4968,2,t0,t1);}
if(C_truep(C_retrieve2(lf[18],"chicken-prefix"))){
t2=C_a_i_list2(&a,2,C_retrieve2(lf[18],"chicken-prefix"),((C_word*)t0)[2]);
/* csc.scm:88: make-pathname */
t3=C_fast_retrieve(lf[103]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,lf[412]);}
else{
t2=((C_word*)t0)[3];
f_1578(2,t2,t1);}}

/* k4962 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in ... */
static void C_ccall f_4964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4964,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4968,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[21],"host-mode"))){
/* ##sys#peek-c-string */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_INSTALL_INCLUDE_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_INCLUDE_HOME),C_fix(0));}}

/* f6337 in k5128 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f6337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1714 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_1716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1716,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1605(t2,C_a_i_list1(&a,1,t1));}

/* k4184 in k4180 in k4176 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in ... */
static void C_ccall f_4186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4186,2,t0,t1);}
t2=C_a_i_list3(&a,3,((C_word*)t0)[2],((C_word*)t0)[3],t1);
/* csc.scm:930: append */
t3=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[4],((C_word*)t0)[5],t2);}

/* k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in ... */
static void C_ccall f_4978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4978,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
t3=C_mutate2(&lf[73] /* (set! default-shared-library-files ...) */,t2);
t4=C_mutate2(&lf[74] /* (set! library-files ...) */,C_retrieve2(lf[72],"default-library-files"));
t5=C_mutate2(&lf[75] /* (set! shared-library-files ...) */,C_retrieve2(lf[73],"default-shared-library-files"));
t6=lf[76] /* translate-options */ =C_SCHEME_END_OF_LIST;;
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1578,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4964,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:233: make-pathname */
t9=C_fast_retrieve(lf[103]);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,lf[413],lf[414]);}

/* k4180 in k4176 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in ... */
static void C_ccall f_4182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4182,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4186,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm:934: linker-libraries */
f_4490(t3);}

/* k3175 in k2963 in k2954 in k2898 in k2895 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in ... */
static void C_ccall f_3177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3177,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3182,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3188,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:785: ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3297,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* ##sys#string-append */
((C_proc4)C_fast_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),t2,((C_word*)t0)[2],lf[394]);}}

/* k4466 in linker-options in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in ... */
static void C_ccall f_4468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4468,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4475,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[93],"static"))){
t4=C_retrieve2(lf[1],"mingw");
t5=t3;
f_4475(t5,(C_truep(C_retrieve2(lf[1],"mingw"))?C_SCHEME_FALSE:C_i_not(C_retrieve2(lf[3],"osx"))));}
else{
t4=t3;
f_4475(t4,C_SCHEME_FALSE);}}

/* k1721 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_1723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1723,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1605(t2,C_a_i_list1(&a,1,t1));}

/* k4193 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in ... */
static void C_ccall f_4195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4195,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4198,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(C_retrieve2(lf[3],"osx"))?C_retrieve2(lf[66],"gui"):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4245,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csc.scm:912: make-pathname */
t6=C_fast_retrieve(lf[103]);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1],lf[187]);}
else{
t5=t3;
f_4198(2,t5,C_SCHEME_UNDEFINED);}}

/* k4196 in k4193 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in ... */
static void C_ccall f_4198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4198,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4202,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4225,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_truep(C_retrieve2(lf[3],"osx"))?C_retrieve2(lf[66],"gui"):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4235,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:919: pathname-file */
t6=C_fast_retrieve(lf[163]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,C_retrieve2(lf[86],"target-filename"));}
else{
/* csc.scm:920: pathname-file */
t5=C_fast_retrieve(lf[163]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,C_retrieve2(lf[86],"target-filename"));}}

/* linker-options in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in ... */
static void C_fcall f_4460(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4460,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4468,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4488,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:1000: append */
t4=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_retrieve2(lf[83],"linking-optimization-options"),C_retrieve2(lf[85],"link-options"));}

/* k4189 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in ... */
static void C_ccall f_4191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#string-append */
((C_proc4)C_fast_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[178],t1);}

/* k2987 in k2963 in k2954 in k2898 in k2895 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in ... */
static void C_ccall f_2989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(&lf[85] /* (set! link-options ...) */,t1);
/* csc.scm:808: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1852(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}

/* k4951 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in ... */
static void C_ccall f_4953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4953,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4888(t2,C_a_i_list1(&a,1,t1));}

/* t-options in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in ... */
static void C_fcall f_1779(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1779,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1784,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:513: append */
t4=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_retrieve2(lf[76],"translate-options"),t2);}

/* k2803 in k2789 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in ... */
static void C_fcall f_2805(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2805,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2809,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2817,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:730: string-append */
t4=*((C_word*)lf[119]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[356],C_retrieve2(lf[69],"rpath"));}
else{
t2=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
/* csc.scm:808: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1852(t4,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}}

/* k2535 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_2537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
/* csc.scm:808: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1852(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k2807 in k2803 in k2789 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in ... */
static void C_ccall f_2809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate2(&lf[85] /* (set! link-options ...) */,t1);
t3=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t3);
/* csc.scm:808: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1852(t5,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k1782 in t-options in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in ... */
static void C_ccall f_1784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(&lf[76] /* (set! translate-options ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* check in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in ... */
static void C_fcall f_1786(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1786,NULL,4,t1,t2,t3,t4);}
t5=C_i_length(t3);
if(C_truep(C_i_nullp(t4))){
if(C_truep(C_i_greater_or_equalp(t5,C_fix(1)))){
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
/* csc.scm:517: stop */
f_1403(t1,lf[141],C_a_i_list(&a,1,t2));}}
else{
t6=C_i_car(t4);
if(C_truep(C_i_greater_or_equalp(t5,t6))){
t7=C_SCHEME_UNDEFINED;
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
/* csc.scm:517: stop */
f_1403(t1,lf[141],C_a_i_list(&a,1,t2));}}}

/* k4496 in linker-libraries in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in ... */
static void C_ccall f_4498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:1004: string-intersperse */
t2=C_fast_retrieve(lf[99]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* linker-libraries in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in ... */
static void C_fcall f_4490(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4490,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4498,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4502,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_retrieve2(lf[93],"static");
if(C_truep(C_retrieve2(lf[93],"static"))){
t5=C_retrieve2(lf[93],"static");
t6=t3;
f_4502(t6,(C_truep(C_retrieve2(lf[93],"static"))?C_retrieve2(lf[74],"library-files"):C_retrieve2(lf[75],"shared-library-files")));}
else{
t5=C_retrieve2(lf[94],"static-libs");
t6=t3;
f_4502(t6,(C_truep(C_retrieve2(lf[94],"static-libs"))?C_retrieve2(lf[74],"library-files"):C_retrieve2(lf[75],"shared-library-files")));}}

/* k4243 in k4193 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in ... */
static void C_ccall f_4245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4245,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4248,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4279,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:913: open-output-string */
t5=C_fast_retrieve(lf[111]);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k2555 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_2557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
/* csc.scm:808: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1852(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k4246 in k4243 in k4193 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in ... */
static void C_ccall f_4248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4248,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4255,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:914: open-output-string */
t3=C_fast_retrieve(lf[111]);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2954 in k2898 in k2895 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in ... */
static void C_fcall f_2956(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2956,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csc.scm:761: t-options */
f_1779(((C_word*)t0)[3],C_a_i_list(&a,1,((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2965,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_block_size(((C_word*)t0)[4]);
if(C_truep(C_fixnum_greaterp(t3,C_fix(1)))){
t4=C_subchar(((C_word*)t0)[4],C_fix(0));
t5=t2;
f_2965(t5,C_i_char_equalp(C_make_character(45),t4));}
else{
t4=t2;
f_2965(t4,C_SCHEME_FALSE);}}}

/* k4253 in k4246 in k4243 in k4193 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in ... */
static void C_ccall f_4255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4255,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[106]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4261,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csc.scm:914: ##sys#print */
t6=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[184],C_SCHEME_FALSE,t3);}

/* k2545 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_2547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
/* csc.scm:808: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1852(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k2815 in k2803 in k2789 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in ... */
static void C_ccall f_2817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2817,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
/* csc.scm:730: append */
t3=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],C_retrieve2(lf[85],"link-options"),t2);}

/* a3181 in k3175 in k2963 in k2954 in k2898 in k2895 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in ... */
static void C_ccall f_3182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3182,2,t0,t1);}
/* csc.scm:785: decompose-pathname */
t2=C_fast_retrieve(lf[380]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a3187 in k3175 in k2963 in k2954 in k2898 in k2895 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in ... */
static void C_ccall f_3188(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3188,5,t0,t1,t2,t3,t4);}
if(C_truep(t4)){
if(C_truep((C_truep(C_i_equalp(t4,lf[381]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[382]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3213,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_a_i_list1(&a,1,((C_word*)t0)[2]);
/* csc.scm:789: append */
t7=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,C_retrieve2(lf[52],"c-files"),t6);}
else{
if(C_truep(C_i_string_ci_equal_p(t4,lf[383]))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3227,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_a_i_list1(&a,1,((C_word*)t0)[2]);
/* csc.scm:791: append */
t7=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,C_retrieve2(lf[53],"rc-files"),t6);}
else{
if(C_truep((C_truep(C_i_equalp(t4,lf[384]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[385]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[386]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[387]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[388]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3240,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[3],"osx"))){
t6=C_a_i_cons(&a,2,lf[389],C_retrieve2(lf[79],"compile-options"));
t7=C_mutate2(&lf[79] /* (set! compile-options ...) */,t6);
t8=t5;
f_3240(t8,t7);}
else{
t6=t5;
f_3240(t6,C_SCHEME_UNDEFINED);}}
else{
if(C_truep((C_truep(C_i_equalp(t4,lf[390]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[391]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[392]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
t5=lf[59] /* objc-mode */ =C_SCHEME_TRUE;;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3264,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=C_a_i_list1(&a,1,((C_word*)t0)[2]);
/* csc.scm:798: append */
t8=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,C_retrieve2(lf[52],"c-files"),t7);}
else{
t5=C_retrieve2(lf[33],"object-extension");
t6=C_u_i_string_equal_p(t4,C_retrieve2(lf[33],"object-extension"));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3276,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t6)){
t8=t7;
f_3276(t8,t6);}
else{
t8=C_retrieve2(lf[35],"library-extension");
t9=t7;
f_3276(t9,C_u_i_string_equal_p(t4,C_retrieve2(lf[35],"library-extension")));}}}}}}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3199,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_a_i_list1(&a,1,((C_word*)t0)[2]);
/* csc.scm:787: append */
t7=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,C_retrieve2(lf[51],"scheme-files"),t6);}}

/* k2944 in k2935 in k2898 in k2895 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in ... */
static void C_ccall f_2946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
/* csc.scm:808: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1852(t4,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* f6332 in k4998 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in ... */
static void C_ccall f6332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3197 in a3187 in k3175 in k2963 in k2954 in k2898 in k2895 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in ... */
static void C_ccall f_3199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(&lf[51] /* (set! scheme-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4200 in k4196 in k4193 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in ... */
static void C_ccall f_4202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4202,2,t0,t1);}
t2=C_mutate2(&lf[86] /* (set! target-filename ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4206,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=t3;
t5=C_retrieve2(lf[86],"target-filename");
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5856,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t7=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,C_retrieve2(lf[86],"target-filename"));}

/* k4204 in k4200 in k4196 in k4193 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in ... */
static void C_ccall f_4206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4206,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4212,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:922: directory-exists? */
t4=C_fast_retrieve(lf[181]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[4])[1]);}

/* k3751 in k3728 in k3701 in k3698 in g530 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in ... */
static void C_ccall f_3753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#string-append */
((C_proc4)C_fast_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[199],t1);}

/* k4210 in k4204 in k4200 in k4196 in k4193 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in ... */
static void C_ccall f_4212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4212,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_4022(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4215,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[87],"verbose"))){
/* csc.scm:924: print */
t3=*((C_word*)lf[136]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[180],((C_word*)((C_word*)t0)[3])[1]);}
else{
/* csc.scm:925: create-directory */
t3=C_fast_retrieve(lf[179]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);}}}

/* k4213 in k4210 in k4204 in k4200 in k4196 in k4193 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in ... */
static void C_ccall f_4215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:925: create-directory */
t2=C_fast_retrieve(lf[179]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);}

/* k3045 in k3041 in k2963 in k2954 in k2898 in k2895 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in ... */
static void C_ccall f_3047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(&lf[85] /* (set! link-options ...) */,t1);
/* csc.scm:808: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1852(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}

/* k3763 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in ... */
static void C_ccall f_3765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3765,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3768,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3901,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[43],"generate-manifest"))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3926,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:875: software-type */
t5=C_fast_retrieve(lf[209]);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_3901(t4,C_SCHEME_FALSE);}}

/* g560 in k3766 in k3763 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in ... */
static void C_fcall f_3769(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3769,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3773,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csc.scm:882: string-append */
t4=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,lf[202],C_retrieve2(lf[33],"object-extension"));}

/* k3766 in k3763 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in ... */
static void C_fcall f_3768(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3768,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3769,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve2(lf[53],"rc-files");
t4=C_i_check_list_2(C_retrieve2(lf[53],"rc-files"),lf[150]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3806,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3877,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_3877(t9,t5,C_retrieve2(lf[53],"rc-files"));}

/* g393 in k2898 in k2895 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in ... */
static C_word C_fcall f_2907(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_stack_overflow_check;
t2=C_i_cadr(t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t3);
return(t4);}

/* k3041 in k2963 in k2954 in k2898 in k2895 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in ... */
static void C_fcall f_3043(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3043,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3047,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_a_i_list1(&a,1,((C_word*)t0)[5]);
/* csc.scm:776: append */
t4=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,C_retrieve2(lf[85],"link-options"),t3);}
else{
t2=C_block_size(((C_word*)t0)[5]);
if(C_truep(C_fixnum_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3133,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* string->list */
t4=C_fast_retrieve(lf[126]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}
else{
/* csc.scm:783: stop */
f_1403(((C_word*)t0)[6],lf[378],C_a_i_list(&a,1,((C_word*)t0)[7]));}}}

/* k2898 in k2895 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in ... */
static void C_fcall f_2900(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2900,NULL,2,t0,t1);}
t2=C_i_assq(((C_word*)t0)[2],lf[368]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2907,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=f_2907(C_a_i(&a,3),t3,t2);
/* csc.scm:808: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_1852(t5,((C_word*)t0)[5],((C_word*)((C_word*)t0)[3])[1]);}
else{
if(C_truep(C_i_memq(((C_word*)t0)[2],lf[369]))){
/* csc.scm:753: t-options */
f_1779(((C_word*)t0)[7],C_a_i_list(&a,1,((C_word*)t0)[8]));}
else{
if(C_truep(C_i_memq(((C_word*)t0)[2],lf[370]))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2937,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* csc.scm:755: check */
f_1786(t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1],C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2956,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
t4=C_block_size(((C_word*)t0)[8]);
if(C_truep(C_fixnum_greaterp(t4,C_fix(2)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3335,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:760: substring */
t6=*((C_word*)lf[372]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[8],C_fix(0),C_fix(2));}
else{
t5=t3;
f_2956(t5,C_SCHEME_FALSE);}}}}}

/* k3728 in k3701 in k3698 in g530 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in ... */
static void C_ccall f_3730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3730,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3734,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3753,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5888,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t7=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[4]);}

/* k3732 in k3728 in k3701 in k3698 in g530 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in ... */
static void C_ccall f_3734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3734,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3738,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[58],"cpp-mode"))){
t4=C_i_string_equal_p(lf[196],C_retrieve2(lf[29],"c++-compiler"));
t5=t3;
f_3738(t5,(C_truep(t4)?lf[197]:lf[198]));}
else{
t4=t3;
f_3738(t4,lf[198]);}}

/* k3736 in k3732 in k3728 in k3701 in k3698 in g530 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in ... */
static void C_fcall f_3738(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3738,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3742,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csc.scm:871: compiler-options */
f_3951(t3);}

/* k2935 in k2898 in k2895 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in ... */
static void C_ccall f_2937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2937,2,t0,t1);}
t2=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t3=C_a_i_string_to_number(&a,2,t2,C_fix(10));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2946,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:758: t-options */
f_1779(t4,C_a_i_list(&a,2,((C_word*)t0)[6],t2));}

/* f5981 in k5140 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f5981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3740 in k3736 in k3732 in k3728 in k3701 in k3698 in g530 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in ... */
static void C_ccall f_3742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3742,2,t0,t1);}
t2=C_a_i_list6(&a,6,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],lf[195],((C_word*)t0)[5],t1);
/* csc.scm:862: string-intersperse */
t3=C_fast_retrieve(lf[99]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[6],t2);}

/* quote-option in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in ... */
static void C_ccall f_4588(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4588,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4595,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4618,tmp=(C_word)a,a+=2,tmp);
/* csc.scm:1034: string-any */
t5=C_fast_retrieve(lf[127]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* k4578 in k4571 in fold in k4541 in k4599 in k4593 in quote-option in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in ... */
static void C_ccall f_4580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4580,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* f5971 in k5114 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f5971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f5976 in k5124 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f5976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f_1469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1469,2,t0,t1);}
t2=C_mutate2(&lf[26] /* (set! home ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1473,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5126,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5130,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5134,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}

/* k3679 in for-each-loop469 in k2013 in k2010 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in ... */
static void C_ccall f_3681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3671(t3,((C_word*)t0)[4],t2);}

/* k3031 in k2963 in k2954 in k2898 in k2895 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in ... */
static void C_ccall f_3033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(&lf[79] /* (set! compile-options ...) */,t1);
/* csc.scm:808: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1852(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}

/* k4593 in quote-option in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in ... */
static void C_ccall f_4595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4595,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4601,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4606,tmp=(C_word)a,a+=2,tmp);
/* csc.scm:1035: string-any */
t4=C_fast_retrieve(lf[127]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}}

/* f5961 in k5094 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in ... */
static void C_ccall f5961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* stop in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_fcall f_1403(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1403,NULL,3,t1,t2,t3);}
t4=*((C_word*)lf[11]+1);
t5=*((C_word*)lf[11]+1);
t6=C_i_check_port_2(*((C_word*)lf[11]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[12]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1410,a[2]=t1,a[3]=t4,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1426,a[2]=t7,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t9=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,C_mpointer(&a,(void*)C_CSC_PROGRAM),C_fix(0));}

/* k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f_1400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1400,2,t0,t1);}
t2=C_mutate2(&lf[8] /* (set! elf ...) */,C_u_i_memq(t1,lf[9]));
t3=C_mutate2(&lf[10] /* (set! stop ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1403,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1430,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:81: get-environment-variable */
t5=C_fast_retrieve(lf[168]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[429]);}

/* f5966 in k5104 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in ... */
static void C_ccall f5966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4937 in map-loop108 in k4903 in k4890 in k4886 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in ... */
static void C_ccall f_4939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4939,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4910(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4910(t6,((C_word*)t0)[5],t5);}}

/* k4789 in a4782 in k4776 in k4773 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4080 in k4067 in k4064 in k4026 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in ... */
static void C_ccall f_4791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:1084: g880 */
t2=*((C_word*)lf[136]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* g530 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in ... */
static void C_fcall f_3696(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3696,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3700,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csc.scm:857: pathname-replace-extension */
t4=C_fast_retrieve(lf[201]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,C_retrieve2(lf[33],"object-extension"));}

/* k3001 in k2963 in k2954 in k2898 in k2895 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in ... */
static void C_ccall f_3003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(&lf[79] /* (set! compile-options ...) */,t1);
/* csc.scm:808: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1852(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}

/* k1414 in k1411 in k1408 in stop in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f_1416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1419,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:77: ##sys#write-char-0 */
((C_proc4)C_fast_retrieve_symbol_proc(lf[14]))(4,*((C_word*)lf[14]+1),t2,C_make_character(10),((C_word*)t0)[3]);}

/* k1411 in k1408 in stop in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f_1413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1413,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1416,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_apply(6,0,t2,*((C_word*)lf[12]+1),((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k4223 in k4196 in k4193 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in ... */
static void C_ccall f_4225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:916: make-pathname */
t2=C_fast_retrieve(lf[103]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1],t1);}

/* k1408 in stop in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f_1410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1413,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csc.scm:77: ##sys#print */
t3=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[16],C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k4903 in k4890 in k4886 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in ... */
static void C_ccall f_4905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4905,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4910,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4910(t5,((C_word*)t0)[4],t1);}

/* k4571 in fold in k4541 in k4599 in k4593 in quote-option in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in ... */
static void C_fcall f_4573(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4573,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4580,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[4];
t4=C_u_i_cdr(t3);
/* csc.scm:1028: fold */
t5=((C_word*)((C_word*)t0)[5])[1];
f_4545(t5,t2,t4);}

/* k1424 in stop in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f_1426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:77: ##sys#print */
t2=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k4233 in k4196 in k4193 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in ... */
static void C_ccall f_4235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:919: string-append */
t2=*((C_word*)lf[119]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[182],t1);}

/* k4773 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4080 in k4067 in k4064 in k4026 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in ... */
static void C_ccall f_4775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4775,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4778,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve2(lf[87],"verbose"))){
/* csc.scm:1082: print */
t3=*((C_word*)lf[136]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[155],((C_word*)t0)[6]);}
else{
t3=t2;
f_4778(2,t3,C_SCHEME_UNDEFINED);}}}

/* k4776 in k4773 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4080 in k4067 in k4064 in k4026 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in ... */
static void C_ccall f_4778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4778,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4783,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:1083: with-output-to-file */
t3=C_fast_retrieve(lf[154]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[4],t2);}

/* k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4080 in k4067 in k4064 in k4026 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in ... */
static void C_ccall f_4772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* k2047 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in ... */
static void C_ccall f_2049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2052,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[63],"show-ldflags"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2075,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:542: linker-options */
f_4460(t3);}
else{
t3=t2;
f_2052(2,t3,C_SCHEME_UNDEFINED);}}

/* k1417 in k1414 in k1411 in k1408 in stop in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f_1419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:79: exit */
t2=C_fast_retrieve(lf[13]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(64));}

/* map-loop108 in k4903 in k4890 in k4886 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in ... */
static void C_fcall f_4910(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4910,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4939,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* csc.scm:245: g131 */
t5=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,lf[406],t4,lf[407]);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* a4782 in k4776 in k4773 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4080 in k4067 in k4064 in k4026 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in ... */
static void C_ccall f_4783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4783,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4791,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=C_a_i_cons(&a,2,lf[151],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
t5=C_a_i_cons(&a,2,lf[152],t4);
/* csc.scm:1071: ##sys#print-to-string */
((C_proc3)C_fast_retrieve_symbol_proc(lf[153]))(3,*((C_word*)lf[153]+1),t2,t5);}

/* k2073 in k2047 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in ... */
static void C_ccall f_2075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:542: print* */
t2=*((C_word*)lf[224]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_make_character(32));}

/* k2020 in k2010 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in ... */
static void C_ccall f_2022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(&lf[86] /* (set! target-filename ...) */,t1);
t3=((C_word*)t0)[2];
f_2015(t3,t2);}

/* k2050 in k2047 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in ... */
static void C_ccall f_2052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2052,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2055,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[64],"show-libs"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2068,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:543: linker-libraries */
f_4490(t3);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5931,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:544: newline */
t4=*((C_word*)lf[223]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2056 in k2053 in k2050 in k2047 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in ... */
static void C_ccall f_2058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:545: exit */
t2=C_fast_retrieve(lf[13]);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2053 in k2050 in k2047 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in ... */
static void C_ccall f_2055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2058,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:544: newline */
t3=*((C_word*)lf[223]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2080 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in ... */
static void C_ccall f_2082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:541: print* */
t2=*((C_word*)lf[224]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_make_character(32));}

/* k2084 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_2086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:538: append */
t2=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[85],"link-options"),t1);}

/* for-each-loop469 in k2013 in k2010 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in ... */
static void C_fcall f_3671(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3671,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3681,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=C_i_length(C_retrieve2(lf[51],"scheme-files"));
t8=C_eqp(C_fix(1),t7);
t9=(C_truep(t8)?C_retrieve2(lf[86],"target-filename"):t6);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3534,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[58],"cpp-mode"))){
/* csc.scm:819: pathname-replace-extension */
t11=C_fast_retrieve(lf[201]);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,t9,lf[219]);}
else{
if(C_truep(C_retrieve2(lf[59],"objc-mode"))){
/* csc.scm:819: pathname-replace-extension */
t11=C_fast_retrieve(lf[201]);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,t9,lf[220]);}
else{
/* csc.scm:819: pathname-replace-extension */
t11=C_fast_retrieve(lf[201]);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,t9,lf[221]);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2885 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in ... */
static void C_ccall f_2887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2887,2,t0,t1);}
t2=C_mutate2(&lf[51] /* (set! scheme-files ...) */,t1);
if(C_truep(C_retrieve2(lf[86],"target-filename"))){
/* csc.scm:808: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1852(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2894,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:744: make-pathname */
t4=C_fast_retrieve(lf[103]);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,C_SCHEME_FALSE,lf[366],C_retrieve2(lf[37],"executable-extension"));}}

/* k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f_1473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1473,2,t0,t1);}
t2=C_mutate2(&lf[27] /* (set! translator ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1477,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5116,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[21],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CC),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}}

/* k4269 in k4259 in k4253 in k4246 in k4243 in k4193 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in ... */
static void C_ccall f_4271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:914: ##sys#print */
t2=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k4265 in k4262 in k4259 in k4253 in k4246 in k4243 in k4193 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in ... */
static void C_ccall f_4267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:914: command */
f_4679(((C_word*)t0)[2],t1);}

/* k4262 in k4259 in k4253 in k4246 in k4243 in k4193 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in ... */
static void C_ccall f_4264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4264,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4267,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:914: get-output-string */
t3=C_fast_retrieve(lf[108]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f_1481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1481,2,t0,t1);}
t2=C_mutate2(&lf[29] /* (set! c++-compiler ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1485,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5096,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[21],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_RC_COMPILER),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_RC_COMPILER),C_fix(0));}}

/* k3262 in a3187 in k3175 in k2963 in k2954 in k2898 in k2895 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in ... */
static void C_ccall f_3264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(&lf[52] /* (set! c-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2376 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_2378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2378,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2382,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=C_a_i_list1(&a,1,t3);
/* csc.scm:645: append */
t5=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,C_retrieve2(lf[95],"required-extensions"),t4);}

/* k4716 in k4103 in k4100 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in ... */
static void C_ccall f_4718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4718,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[106]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4724,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csc.scm:1067: ##sys#print */
t6=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[172],C_SCHEME_FALSE,t3);}

/* k2066 in k2050 in k2047 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in ... */
static void C_ccall f_2068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:543: print* */
t2=*((C_word*)lf[224]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_make_character(32));}

/* k2764 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in ... */
static void C_ccall f_2766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2770,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2778,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
/* csc.scm:723: string-split */
t5=C_fast_retrieve(lf[227]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f_1477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1477,2,t0,t1);}
t2=C_mutate2(&lf[28] /* (set! compiler ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1481,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5106,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[21],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CXX),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CXX),C_fix(0));}}

/* k2864 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in ... */
static void C_ccall f_2866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2869,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
/* csc.scm:739: t-options */
f_1779(t2,C_a_i_list(&a,2,lf[364],t3));}

/* k2867 in k2864 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in ... */
static void C_ccall f_2869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
/* csc.scm:808: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1852(t4,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k4273 in k4259 in k4253 in k4246 in k4243 in k4193 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in ... */
static void C_ccall f_4275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4275,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5861,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t4=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* map-loop410 in k3127 in k3131 in k3041 in k2963 in k2954 in k2898 in k2895 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in ... */
static void C_fcall f_3089(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3089,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3118,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_a_i_string(&a,1,t4);
/* ##sys#string-append */
((C_proc4)C_fast_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),t3,lf[373],t5);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4277 in k4243 in k4193 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in ... */
static void C_ccall f_4279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4279,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[106]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4285,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csc.scm:913: ##sys#print */
t6=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[186],C_SCHEME_FALSE,t3);}

/* k3085 in k3127 in k3131 in k3041 in k2963 in k2954 in k2898 in k2895 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in ... */
static void C_ccall f_3087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:781: append */
t2=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)((C_word*)t0)[3])[1]);}

/* k3274 in a3187 in k3175 in k2963 in k2954 in k2898 in k2895 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in ... */
static void C_fcall f_3276(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3276,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3280,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_a_i_list1(&a,1,((C_word*)t0)[3]);
/* csc.scm:801: append */
t4=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,C_retrieve2(lf[56],"object-files"),t3);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3288,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_a_i_list1(&a,1,((C_word*)t0)[3]);
/* csc.scm:802: append */
t4=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,C_retrieve2(lf[51],"scheme-files"),t3);}}

/* k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in ... */
static void C_ccall f_1493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1493,2,t0,t1);}
t2=C_mutate2(&lf[32] /* (set! c++-linker ...) */,t1);
t3=C_mutate2(&lf[33] /* (set! object-extension ...) */,lf[34]);
t4=C_mutate2(&lf[35] /* (set! library-extension ...) */,lf[36]);
t5=C_mutate2(&lf[37] /* (set! executable-extension ...) */,lf[38]);
t6=C_mutate2(&lf[39] /* (set! shared-library-extension ...) */,C_fast_retrieve(lf[40]));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1505,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=C_retrieve2(lf[1],"mingw");
if(C_truep(C_retrieve2(lf[1],"mingw"))){
t9=C_retrieve2(lf[1],"mingw");
t10=t7;
f_1505(t10,(C_truep(C_retrieve2(lf[1],"mingw"))?lf[422]:lf[423]));}
else{
t9=C_retrieve2(lf[5],"cygwin");
t10=t7;
f_1505(t10,(C_truep(C_retrieve2(lf[5],"cygwin"))?lf[422]:lf[423]));}}

/* k4725 in k4722 in k4716 in k4103 in k4100 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in ... */
static void C_ccall f_4727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4730,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:1067: ##sys#write-char-0 */
((C_proc4)C_fast_retrieve_symbol_proc(lf[14]))(4,*((C_word*)lf[14]+1),t2,C_make_character(32),((C_word*)t0)[4]);}

/* k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in ... */
static void C_ccall f_2093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2093,2,t0,t1);}
t2=t1;
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2096,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=C_eqp(t3,lf[247]);
t6=(C_truep(t5)?t5:C_eqp(t3,lf[248]));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2108,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1739,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t10=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,C_mpointer(&a,(void*)C_CSC_PROGRAM),C_fix(0));}
else{
t7=C_eqp(t3,lf[253]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2120,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2127,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:589: chicken-version */
t10=C_fast_retrieve(lf[254]);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t8=C_eqp(t3,lf[255]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2136,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2143,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:592: sprintf */
t11=*((C_word*)lf[106]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,C_retrieve2(lf[27],"translator"),lf[256]);}
else{
t9=C_eqp(t3,lf[257]);
if(C_truep(t9)){
t10=lf[58] /* cpp-mode */ =C_SCHEME_TRUE;;
if(C_truep(C_retrieve2(lf[3],"osx"))){
t11=C_a_i_cons(&a,2,lf[258],C_retrieve2(lf[79],"compile-options"));
t12=C_mutate2(&lf[79] /* (set! compile-options ...) */,t11);
/* csc.scm:808: loop */
t13=((C_word*)((C_word*)t0)[2])[1];
f_1852(t13,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
/* csc.scm:808: loop */
t11=((C_word*)((C_word*)t0)[2])[1];
f_1852(t11,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}}
else{
t10=C_eqp(t3,lf[259]);
if(C_truep(t10)){
t11=lf[59] /* objc-mode */ =C_SCHEME_TRUE;;
/* csc.scm:808: loop */
t12=((C_word*)((C_word*)t0)[2])[1];
f_1852(t12,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t11=C_eqp(t3,lf[260]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2174,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:601: cons* */
t13=C_fast_retrieve(lf[125]);
((C_proc5)(void*)(*((C_word*)t13+1)))(5,t13,t12,lf[261],lf[262],C_retrieve2(lf[76],"translate-options"));}
else{
t12=C_eqp(t3,lf[263]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2185,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:605: cons* */
t14=C_fast_retrieve(lf[125]);
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,t13,lf[264],lf[265],C_retrieve2(lf[76],"translate-options"));}
else{
t13=C_eqp(t3,lf[266]);
if(C_truep(t13)){
t14=lf[61] /* inquiry-only */ =C_SCHEME_TRUE;;
t15=lf[62] /* show-cflags */ =C_SCHEME_TRUE;;
/* csc.scm:808: loop */
t16=((C_word*)((C_word*)t0)[2])[1];
f_1852(t16,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t14=C_eqp(t3,lf[267]);
if(C_truep(t14)){
t15=lf[61] /* inquiry-only */ =C_SCHEME_TRUE;;
t16=lf[63] /* show-ldflags */ =C_SCHEME_TRUE;;
/* csc.scm:808: loop */
t17=((C_word*)((C_word*)t0)[2])[1];
f_1852(t17,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t15=C_eqp(t3,lf[268]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2211,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:613: print */
t17=*((C_word*)lf[136]+1);
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t16,C_retrieve2(lf[28],"compiler"));}
else{
t16=C_eqp(t3,lf[269]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2223,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:614: print */
t18=*((C_word*)lf[136]+1);
((C_proc3)(void*)(*((C_word*)t18+1)))(3,t18,t17,C_retrieve2(lf[29],"c++-compiler"));}
else{
t17=C_eqp(t3,lf[270]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2235,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:615: print */
t19=*((C_word*)lf[136]+1);
((C_proc3)(void*)(*((C_word*)t19+1)))(3,t19,t18,C_retrieve2(lf[31],"linker"));}
else{
t18=C_eqp(t3,lf[271]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2247,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:616: print */
t20=*((C_word*)lf[136]+1);
((C_proc3)(void*)(*((C_word*)t20+1)))(3,t20,t19,C_retrieve2(lf[26],"home"));}
else{
t19=C_eqp(t3,lf[272]);
if(C_truep(t19)){
t20=lf[61] /* inquiry-only */ =C_SCHEME_TRUE;;
t21=lf[64] /* show-libs */ =C_SCHEME_TRUE;;
/* csc.scm:808: loop */
t22=((C_word*)((C_word*)t0)[2])[1];
f_1852(t22,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t20=C_eqp(t3,lf[273]);
t21=(C_truep(t20)?t20:C_eqp(t3,lf[274]));
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2270,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_numberp(C_retrieve2(lf[87],"verbose")))){
t23=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2285,a[2]=t22,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:622: cons* */
t24=C_fast_retrieve(lf[125]);
((C_proc5)(void*)(*((C_word*)t24+1)))(5,t24,t23,lf[277],lf[278],C_retrieve2(lf[79],"compile-options"));}
else{
t23=t22;
f_2270(t23,C_SCHEME_UNDEFINED);}}
else{
t22=C_eqp(t3,lf[279]);
t23=(C_truep(t22)?t22:C_eqp(t3,lf[280]));
if(C_truep(t23)){
t24=C_a_i_cons(&a,2,lf[281],C_retrieve2(lf[79],"compile-options"));
t25=C_mutate2(&lf[79] /* (set! compile-options ...) */,t24);
/* csc.scm:630: t-options */
f_1779(t4,C_a_i_list(&a,1,lf[282]));}
else{
t24=C_eqp(t3,lf[283]);
t25=(C_truep(t24)?t24:C_eqp(t3,lf[284]));
if(C_truep(t25)){
t26=lf[89] /* translate-only */ =C_SCHEME_TRUE;;
/* csc.scm:633: t-options */
f_1779(t4,C_a_i_list(&a,1,lf[285]));}
else{
t26=C_eqp(t3,lf[286]);
t27=(C_truep(t26)?t26:C_eqp(t3,lf[287]));
if(C_truep(t27)){
t28=lf[89] /* translate-only */ =C_SCHEME_TRUE;;
/* csc.scm:636: t-options */
f_1779(t4,C_a_i_list(&a,1,lf[288]));}
else{
t28=C_eqp(t3,lf[289]);
if(C_truep(t28)){
t29=lf[88] /* keep-files */ =C_SCHEME_TRUE;;
/* csc.scm:808: loop */
t30=((C_word*)((C_word*)t0)[2])[1];
f_1852(t30,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t29=C_eqp(t3,lf[290]);
if(C_truep(t29)){
t30=lf[90] /* compile-only */ =C_SCHEME_TRUE;;
/* csc.scm:808: loop */
t31=((C_word*)((C_word*)t0)[2])[1];
f_1852(t31,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t30=C_eqp(t3,lf[291]);
if(C_truep(t30)){
t31=lf[89] /* translate-only */ =C_SCHEME_TRUE;;
/* csc.scm:808: loop */
t32=((C_word*)((C_word*)t0)[2])[1];
f_1852(t32,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t31=C_eqp(t3,lf[292]);
t32=(C_truep(t31)?t31:C_eqp(t3,lf[293]));
if(C_truep(t32)){
t33=lf[60] /* embedded */ =C_SCHEME_TRUE;;
t34=C_a_i_cons(&a,2,lf[294],C_retrieve2(lf[79],"compile-options"));
t35=C_mutate2(&lf[79] /* (set! compile-options ...) */,t34);
/* csc.scm:808: loop */
t36=((C_word*)((C_word*)t0)[2])[1];
f_1852(t36,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t33=C_eqp(t3,lf[295]);
t34=(C_truep(t33)?t33:C_eqp(t3,lf[296]));
if(C_truep(t34)){
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2378,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csc.scm:644: check */
f_1786(t35,t2,((C_word*)((C_word*)t0)[4])[1],C_SCHEME_END_OF_LIST);}
else{
t35=C_eqp(t3,lf[298]);
if(C_truep(t35)){
t36=f_1835(C_a_i(&a,6));
/* csc.scm:808: loop */
t37=((C_word*)((C_word*)t0)[2])[1];
f_1852(t37,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t36=C_eqp(t3,lf[299]);
if(C_truep(t36)){
t37=lf[43] /* generate-manifest */ =C_SCHEME_TRUE;;
/* csc.scm:808: loop */
t38=((C_word*)((C_word*)t0)[2])[1];
f_1852(t38,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t37=C_eqp(t3,lf[300]);
if(C_truep(t37)){
t38=lf[66] /* gui */ =C_SCHEME_TRUE;;
t39=C_a_i_cons(&a,2,lf[301],C_retrieve2(lf[79],"compile-options"));
t40=C_mutate2(&lf[79] /* (set! compile-options ...) */,t39);
if(C_truep(C_retrieve2(lf[1],"mingw"))){
t41=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2441,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t42=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2445,a[2]=t41,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t43=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t43+1)))(4,t43,t42,C_mpointer(&a,(void*)C_INSTALL_SHARE_HOME),C_fix(0));}
else{
/* csc.scm:808: loop */
t41=((C_word*)((C_word*)t0)[2])[1];
f_1852(t41,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}}
else{
t38=C_eqp(t3,lf[307]);
if(C_truep(t38)){
t39=lf[67] /* deploy */ =C_SCHEME_TRUE;;
t40=lf[68] /* deployed */ =C_SCHEME_TRUE;;
/* csc.scm:808: loop */
t41=((C_word*)((C_word*)t0)[2])[1];
f_1852(t41,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t39=C_eqp(t3,lf[308]);
if(C_truep(t39)){
t40=lf[68] /* deployed */ =C_SCHEME_TRUE;;
/* csc.scm:808: loop */
t41=((C_word*)((C_word*)t0)[2])[1];
f_1852(t41,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t40=C_eqp(t3,lf[309]);
if(C_truep(t40)){
t41=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2469,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:670: check */
f_1786(t41,t2,((C_word*)((C_word*)t0)[4])[1],C_SCHEME_END_OF_LIST);}
else{
t41=C_eqp(t3,lf[311]);
t42=(C_truep(t41)?t41:C_eqp(t3,lf[312]));
if(C_truep(t42)){
t43=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2496,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:675: check */
f_1786(t43,t2,((C_word*)((C_word*)t0)[4])[1],C_SCHEME_END_OF_LIST);}
else{
t43=C_eqp(t3,lf[313]);
t44=(C_truep(t43)?t43:C_eqp(t3,lf[314]));
if(C_truep(t44)){
t45=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2517,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:679: cons* */
t46=C_fast_retrieve(lf[125]);
((C_proc5)(void*)(*((C_word*)t46+1)))(5,t46,t45,lf[315],lf[316],((C_word*)((C_word*)t0)[4])[1]);}
else{
t45=C_eqp(t3,lf[317]);
if(C_truep(t45)){
t46=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2527,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:680: cons* */
t47=C_fast_retrieve(lf[125]);
((C_proc5)(void*)(*((C_word*)t47+1)))(5,t47,t46,lf[318],lf[319],((C_word*)((C_word*)t0)[4])[1]);}
else{
t46=C_eqp(t3,lf[320]);
if(C_truep(t46)){
t47=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2537,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:681: cons* */
t48=C_fast_retrieve(lf[125]);
((C_proc5)(void*)(*((C_word*)t48+1)))(5,t48,t47,lf[321],lf[322],((C_word*)((C_word*)t0)[4])[1]);}
else{
t47=C_eqp(t3,lf[323]);
if(C_truep(t47)){
t48=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2547,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:682: cons* */
t49=C_fast_retrieve(lf[125]);
((C_proc5)(void*)(*((C_word*)t49+1)))(5,t49,t48,lf[324],lf[325],((C_word*)((C_word*)t0)[4])[1]);}
else{
t48=C_eqp(t3,lf[326]);
if(C_truep(t48)){
t49=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2557,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:683: cons* */
t50=C_fast_retrieve(lf[125]);
((C_proc5)(void*)(*((C_word*)t50+1)))(5,t50,t49,lf[327],lf[328],((C_word*)((C_word*)t0)[4])[1]);}
else{
t49=C_eqp(t3,lf[329]);
if(C_truep(t49)){
t50=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2567,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:685: cons* */
t51=C_fast_retrieve(lf[125]);
((C_proc5)(void*)(*((C_word*)t51+1)))(5,t51,t50,lf[330],lf[331],((C_word*)((C_word*)t0)[4])[1]);}
else{
t50=C_eqp(t3,lf[332]);
if(C_truep(t50)){
t51=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2577,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:686: cons* */
t52=C_fast_retrieve(lf[125]);
((C_proc5)(void*)(*((C_word*)t52+1)))(5,t52,t51,lf[333],lf[334],((C_word*)((C_word*)t0)[4])[1]);}
else{
t51=C_eqp(t3,lf[335]);
if(C_truep(t51)){
t52=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2587,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:687: cons* */
t53=C_fast_retrieve(lf[125]);
((C_proc5)(void*)(*((C_word*)t53+1)))(5,t53,t52,lf[336],lf[337],((C_word*)((C_word*)t0)[4])[1]);}
else{
t52=C_eqp(t3,lf[338]);
if(C_truep(t52)){
t53=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2597,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:688: cons* */
t54=C_fast_retrieve(lf[125]);
((C_proc5)(void*)(*((C_word*)t54+1)))(5,t54,t53,lf[339],lf[340],((C_word*)((C_word*)t0)[4])[1]);}
else{
t53=C_eqp(t3,lf[341]);
if(C_truep(t53)){
t54=lf[87] /* verbose */ =C_SCHEME_TRUE;;
t55=lf[65] /* dry-run */ =C_SCHEME_TRUE;;
/* csc.scm:808: loop */
t56=((C_word*)((C_word*)t0)[2])[1];
f_1852(t56,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t54=C_eqp(t3,lf[342]);
t55=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2614,a[2]=((C_word*)t0)[8],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[6],a[9]=t2,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t54)){
t56=t55;
f_2614(t56,t54);}
else{
t56=C_eqp(t3,lf[399]);
t57=t55;
f_2614(t57,(C_truep(t56)?t56:C_eqp(t3,lf[400])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k4722 in k4716 in k4103 in k4100 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in ... */
static void C_ccall f_4724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4727,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4748,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5841,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t6=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[5]);}

/* k2094 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_2096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:808: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_1852(t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}

/* k2751 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in ... */
static void C_ccall f_2753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(&lf[85] /* (set! link-options ...) */,t1);
/* csc.scm:808: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1852(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}

/* k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in ... */
static void C_ccall f_1489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1489,2,t0,t1);}
t2=C_mutate2(&lf[31] /* (set! linker ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1493,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5076,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[21],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CXX),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CXX),C_fix(0));}}

/* k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in ... */
static void C_ccall f_1485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1485,2,t0,t1);}
t2=C_mutate2(&lf[30] /* (set! rc-compiler ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1489,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5086,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[21],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CC),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2817)){
C_save(t1);
C_rereclaim2(2817*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,430);
lf[0]=C_h_intern(&lf[0],7,"mingw32");
lf[2]=C_h_intern(&lf[2],6,"macosx");
lf[4]=C_h_intern(&lf[4],6,"cygwin");
lf[6]=C_h_intern(&lf[6],3,"aix");
lf[9]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005linux\376\003\000\000\002\376\001\000\000\006netbsd\376\003\000\000\002\376\001\000\000\007freebsd\376\003\000\000\002\376\001\000\000\007solaris\376\003\000\000\002\376\001\000\000\007openb"
"sd\376\003\000\000\002\376\001\000\000\004hurd\376\003\000\000\002\376\001\000\000\005haiku\376\377\016");
lf[11]=C_h_intern(&lf[11],18,"\003sysstandard-error");
lf[12]=C_h_intern(&lf[12],7,"fprintf");
lf[13]=C_h_intern(&lf[13],4,"exit");
lf[14]=C_h_intern(&lf[14],16,"\003syswrite-char-0");
lf[15]=C_h_intern(&lf[15],9,"\003sysprint");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[17]=C_h_intern(&lf[17],17,"\003syspeek-c-string");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\005-host");
lf[24]=C_h_intern(&lf[24],2,"qs");
lf[25]=C_h_intern(&lf[25],18,"normalize-pathname");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\001o");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[40]=C_h_intern(&lf[40],26,"\003sysload-dynamic-extension");
lf[77]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014/usr/include\376\003\000\000\002\376B\000\000\000\376\377\016");
lf[98]=C_h_intern(&lf[98],3,"map");
lf[99]=C_h_intern(&lf[99],18,"string-intersperse");
lf[100]=C_h_intern(&lf[100],6,"append");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[103]=C_h_intern(&lf[103],13,"make-pathname");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[106]=C_h_intern(&lf[106],7,"sprintf");
lf[108]=C_h_intern(&lf[108],17,"get-output-string");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\007copy /Y");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\002cp");
lf[111]=C_h_intern(&lf[111],18,"open-output-string");
lf[113]=C_h_intern(&lf[113],17,"\003sysstring-append");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\010 -static");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[118]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000#\376\377\016");
lf[119]=C_h_intern(&lf[119],13,"string-append");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[122]=C_h_intern(&lf[122],17,"string-translate\052");
lf[123]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\001\042\376B\000\000\002\134\042\376\377\016");
lf[124]=C_h_intern(&lf[124],16,"\003syslist->string");
lf[125]=C_h_intern(&lf[125],5,"cons\052");
lf[126]=C_h_intern(&lf[126],16,"\003sysstring->list");
lf[127]=C_h_intern(&lf[127],10,"string-any");
lf[129]=C_h_intern(&lf[129],19,"\003sysstandard-output");
lf[130]=C_h_intern(&lf[130],6,"printf");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000;\012Error: shell command terminated with non-zero exit status ");
lf[133]=C_h_intern(&lf[133],6,"system");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[136]=C_h_intern(&lf[136],5,"print");
lf[138]=C_h_intern(&lf[138],11,"delete-file");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\003rm ");
lf[140]=C_h_intern(&lf[140],25,"\003sysimplicit-exit-handler");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000#not enough arguments to option `~A\047");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\013-dynamiclib");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000$-bundle -headerpad_max_install_names");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\007-shared");
lf[145]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012-DC_SHARED\376\377\016");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-shared");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\026-DC_PRIVATE_REPOSITORY");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\031-framework CoreFoundation");
lf[150]=C_h_intern(&lf[150],8,"for-each");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\032</string>\012</dict>\012</plist>");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\001\262<\077xml version=\0421.0\042 encoding=\042UTF-8\042\077>\012<!DOCTYPE plist SYSTEM \042file://local"
"host/System/Library/DTDs/PropertyList.dtd\042>\012<plist version=\0420.9\042>\012<dict>\012\011<key>C"
"FBundlePackageType</key>\012\011<string>APPL</string>\012\011<key>CFBundleIconFile</key>\012\011<s"
"tring>CHICKEN.icns</string>\012        <key>CFBundleGetInfoString</key>\012\011<string>Cr"
"eated by CHICKEN</string>\012\011<key>CFBundleSignature</key>\012\011<string>\077\077\077\077</string>\012\011"
"<key>CFBundleExecutable</key>\012\011<string>");
lf[153]=C_h_intern(&lf[153],19,"\003sysprint-to-string");
lf[154]=C_h_intern(&lf[154],19,"with-output-to-file");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\013generating ");
lf[156]=C_h_intern(&lf[156],12,"file-exists\077");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\012Info.plist");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\024chicken/CHICKEN.icns");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\014CHICKEN.icns");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\022Contents/Resources");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\016Contents/MacOS");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\010Contents");
lf[163]=C_h_intern(&lf[163],13,"pathname-file");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\005dylib");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\003dll");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\003so.");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[168]=C_h_intern(&lf[168],24,"get-environment-variable");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\017TARGET_LIB_PATH");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\016Contents/MacOS");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\005mac.r");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000 /Developer/Tools/Rez -t APPL -o ");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\011 -change ");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\007.dylib ");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\020@executable_path");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\006.dylib");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\003-o ");
lf[179]=C_h_intern(&lf[179],16,"create-directory");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\006mkdir ");
lf[181]=C_h_intern(&lf[181],17,"directory-exists\077");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\017Contents/MacOS/");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\022Contents/Resources");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\011mkdir -p ");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\016Contents/MacOS");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\011mkdir -p ");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\003app");
lf[188]=C_h_intern(&lf[188],24,"pathname-strip-extension");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\004.old");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\004move");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\002mv");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\005.old\047");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\030\047 - renaming source to `");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\0001Warning: output file will overwrite source file `");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\003g++");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\022-Wno-write-strings");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\003-o ");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000Pobject file generated from `~a\047 will overwrite explicitly given object file"
" `~a\047");
lf[201]=C_h_intern(&lf[201],26,"pathname-replace-extension");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[203]=C_h_intern(&lf[203],7,"reverse");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\001\232\042\042 type=\042\042win32\042\042/>\134r\134n\042\012  \042  <ms_asmv2:trustInfo xmlns:ms_asmv2=\042\042urn:sche"
"mas-microsoft-com:asm.v2\042\042>\134r\134n\042\012  \042    <ms_asmv2:security>\134r\134n\042\012  \042      <ms_as"
"mv2:requestedPrivileges>\134r\134n\042\012  \042        <ms_asmv2:requestedExecutionLevel level"
"=\042\042asInvoker\042\042 uiAccess=\042\042false\042\042/>\134r\134n\042\012  \042      </ms_asmv2:requestedPrivileges"
">\134r\134n\042\012  \042    </ms_asmv2:security>\134r\134n\042\012  \042  </ms_asmv2:trustInfo>\134r\134n\042\012  \042</ass"
"embly>\134r\134n\042\012END");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\001\0031 24 MOVEABLE PURE\012BEGIN\012  \042<\077xml version=\042\0421.0\042\042 encoding=\042\042UTF-8\042\042 standa"
"lone=\042\042yes\042\042\077>\134r\134n\042\012  \042<assembly xmlns=\042\042urn:schemas-microsoft-com:asm.v1\042\042 mani"
"festVersion=\042\0421.0\042\042>\134r\134n\042\012  \042  <assemblyIdentity version=\042\0421.0.0.0\042\042 processorAr"
"chitecture=\042\042\052\042\042 name=\042\042");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\013generating ");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\002rc");
lf[208]=C_h_intern(&lf[208],7,"windows");
lf[209]=C_h_intern(&lf[209],13,"software-type");
lf[210]=C_h_intern(&lf[210],4,"last");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\031no source files specified");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[213]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\003-:d\376\377\016");
lf[214]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\010-feature\376\003\000\000\002\376B\000\000\025chicken-scheme-to-c++\376\377\016");
lf[215]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\010-feature\376\003\000\000\002\376B\000\000\026chicken-scheme-to-objc\376\377\016");
lf[216]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012-to-stdout\376\377\016");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\014-output-file");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000KC file generated from `~a\047 will overwrite explicitly given source file `~a\047"
);
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\003cpp");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\001m");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\010-dynamic");
lf[223]=C_h_intern(&lf[223],7,"newline");
lf[224]=C_h_intern(&lf[224],6,"print\052");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\003-L\042");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[227]=C_h_intern(&lf[227],12,"string-split");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\002:;");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\026CHICKEN_C_LIBRARY_PATH");
lf[230]=C_h_intern(&lf[230],7,"freebsd");
lf[231]=C_h_intern(&lf[231],7,"openbsd");
lf[232]=C_h_intern(&lf[232],6,"netbsd");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\015-Wl,-z,origin");
lf[234]=C_h_intern(&lf[234],16,"software-version");
lf[235]=C_h_intern(&lf[235],4,"conc");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\010 -Wl,-R\042");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\010\134$ORIGIN");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\003-L\042");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\007-Wl,-R\042");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\003-L\042");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[247]=C_h_intern(&lf[247],5,"-help");
lf[248]=C_h_intern(&lf[248],6,"--help");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\003\047.\012");
lf[250]=C_decode_literal(C_heaptop,"\376B\000(\355\047 is a driver program for the CHICKEN compiler. Files given on the\012  comman"
"d line are translated, compiled or linked as needed.\012\012  FILENAME is a Scheme sou"
"rce file name with optional extension or a\012  C/C++/Objective-C source, object or"
" library file name with extension. OPTION\012  may be one of the following:\012\012  Gene"
"ral options:\012\012    -h  -help                      display this text and exit\012    "
"-v  -verbose                   show compiler notes and tool-invocations\012    -vv "
"                           display information about translation\012               "
"                     progress\012    -vvv                           display informa"
"tion about all compilation\012                                    stages\012    -versi"
"on                       display Scheme compiler version and exit\012    -release  "
"                     display release number and exit\012\012  File and pathname option"
"s:\012\012    -o -output-file FILENAME       specifies target executable name\012    -I -"
"include-path PATHNAME      specifies alternative path for included\012             "
"                       files\012    -to-stdout                     write compiler t"
"o stdout (implies -t)\012    -s -shared -dynamic            generate dynamically lo"
"adable shared object\012                                    file\012\012  Language option"
"s:\012\012    -D  -DSYMBOL  -feature SYMBOL  register feature identifier\012    -no-featu"
"re SYMBOL             disable builtin feature identifier\012    -c++               "
"            compile via a C++ source file (.cpp) \012    -objc                     "
"     compile via Objective-C source file (.m)\012\012  Syntax related options:\012\012    -i"
" -case-insensitive           don\047t preserve case of read symbols    \012    -K -key"
"word-style STYLE        enable alternative keyword-syntax\012                      "
"              (prefix, suffix or none)\012       -no-parentheses-synonyms    disabl"
"es list delimiter synonyms\012       -no-symbol-escape           disables support f"
"or escaped symbols\012       -r5rs-syntax                disables the Chicken exten"
"sions to\012                                    R5RS syntax\012    -compile-syntax    "
"            macros are made available at run-time\012    -j -emit-import-library MO"
"DULE write compile-time module information into\012                                "
"    separate file\012    -J -emit-all-import-libraries  emit import-libraries for a"
"ll defined modules\012    -no-module-registration        do not generate module reg"
"istration code\012    -no-compiler-syntax            disable expansion of compiler-"
"macros\012    -M -module                     wrap compiled code into implicit modul"
"e\012\012  Translation options:\012\012    -x  -explicit-use              do not use units `"
"library\047 and `eval\047 by\012                                    default\012    -P  -chec"
"k-syntax              stop compilation after macro-expansion\012    -A  -analyze-on"
"ly              stop compilation after first analysis pass\012\012  Debugging options:"
"\012\012    -w  -no-warnings               disable warnings\012    -d0 -d1 -d2 -debug-lev"
"el NUMBER\012                                   set level of available debugging in"
"formation\012    -no-trace                      disable rudimentary debugging infor"
"mation\012    -profile                       executable emits profiling information"
" \012    -accumulate-profile            executable emits profiling information in\012 "
"                                   append mode\012    -profile-name FILENAME       "
"  name of the generated profile information\012                                    "
"file\012    -types FILENAME                load additional type database\012\012  Optimiz"
"ation options:\012\012    -O -O0 -O1 -O2 -O3 -O4 -O5 -optimize-level NUMBER\012          "
"                         enable certain sets of optimization options\012    -optimi"
"ze-leaf-routines        enable leaf routine optimization\012    -no-usual-integrati"
"ons         standard procedures may be redefined\012    -u  -unsafe                "
"    disable safety checks\012    -local                         assume globals are "
"only modified in current\012                                    file\012    -b  -block"
"                     enable block-compilation\012    -disable-interrupts           "
" disable interrupts in compiled code\012    -f  -fixnum-arithmetic         assume a"
"ll numbers are fixnums\012    -disable-stack-overflow-checks disables detection of "
"stack-overflows\012    -inline                        enable inlining\012    -inline-l"
"imit LIMIT            set inlining threshold\012    -inline-global                 "
"enable cross-module inlining\012    -specialize                    perform type-bas"
"ed specialization of primitive calls\012    -oi -emit-inline-file FILENAME  generat"
"e file with globally inlinable\012                                    procedures (i"
"mplies -inline -local)\012    -consult-inline-file FILENAME  explicitly load inline"
" file\012    -ot  -emit-type-file FILENAME  write type-declaration information into"
" file\012    -no-argc-checks                disable argument count checks\012    -no-b"
"ound-checks               disable bound variable checks\012    -no-procedure-checks"
"           disable procedure call checks\012    -no-procedure-checks-for-usual-bind"
"ings\012                                   disable procedure call checks only for u"
"sual\012                                    bindings\012    -no-procedure-checks-for-t"
"oplevel-bindings\012                                   disable procedure call check"
"s for toplevel\012                                    bindings\012    -strict-types   "
"               assume variable do not change their type\012    -clustering         "
"           combine groups of local procedures into dispatch\012                    "
"                 loop\012    -lfa2                          perform additional ligh"
"tweight flow-analysis pass\012\012  Configuration options:\012\012    -unit NAME            "
"         compile file as a library unit\012    -uses NAME                     decla"
"re library unit as used.\012    -heap-size NUMBER              specifies heap-size "
"of compiled executable\012    -nursery NUMBER  -stack-size NUMBER\012                 "
"                  specifies nursery size of compiled\012                           "
"        executable\012    -X -extend FILENAME            load file before compilati"
"on commences\012    -prelude EXPRESSION            add expression to beginning of s"
"ource file\012    -postlude EXPRESSION           add expression to end of source fi"
"le\012    -prologue FILENAME             include file before main source file\012    -"
"epilogue FILENAME             include file after main source file\012\012    -e  -embe"
"dded                  compile as embedded\012                                    (d"
"on\047t generate `main()\047)\012    -gui                           compile as GUI applic"
"ation\012    -R  -require-extension NAME    require extension and import in compile"
"d\012                                    code\012    -dll -library                  co"
"mpile multiple units into a dynamic\012                                    library\012"
"    -deploy                        deploy self-contained application bundle\012\012  O"
"ptions to other passes:\012\012    -C OPTION                      pass option to C com"
"piler\012    -L OPTION                      pass option to linker\012    -I<DIR>      "
"                  pass \134\042-I<DIR>\134\042 to C compiler\012                               "
"     (add include path)\012    -L<DIR>                        pass \134\042-L<DIR>\134\042 to l"
"inker\012                                    (add library path)\012    -k             "
"                keep intermediate files\012    -c                             stop "
"after compilation to object files\012    -t                             stop after "
"translation to C\012    -cc COMPILER                   select other C compiler than"
" the default\012    -cxx COMPILER                  select other C++ compiler than t"
"he default\012    -ld COMPILER                   select other linker than the defau"
"lt \012    -lLIBNAME                      link with given library\012                 "
"                   (`libLIBNAME\047 on UNIX,\012                                     `"
"LIBNAME.lib\047 on Windows)\012    -static-libs                   link with static CHI"
"CKEN libraries\012    -static                        generate completely statically"
" linked\012                                    executable\012    -F<DIR>              "
"          pass \134\042-F<DIR>\134\042 to C compiler\012                                    (ad"
"d framework header path on Mac OS X)\012    -framework NAME                passed t"
"o linker on Mac OS X\012    -rpath PATHNAME                add directory to runtime"
" library search path\012    -Wl,...                        pass linker options\012    "
"-strip                         strip resulting binary\012\012  Inquiry options:\012\012    -"
"home                          show home-directory (where support files go)\012    -"
"cflags                        show required C-compiler flags and exit\012    -ldfla"
"gs                       show required linker flags and exit\012    -libs          "
"                show required libraries and exit\012    -cc-name                   "
"    show name of default C compiler used\012    -cxx-name                      show"
" name of default C++ compiler used\012    -ld-name                       show name "
"of default linker used\012    -dry-run                       just show commands exe"
"cuted, don\047t run them\012                                    (implies `-v\047)\012\012  Obsc"
"ure options:\012\012    -debug MODES                   display debugging output for th"
"e given modes\012    -compiler PATHNAME             use other compiler than default"
" `chicken\047\012    -raw                           do not generate implicit init- and"
" exit code\012    -emit-external-prototypes-first\012                                 "
"  emit prototypes for callbacks before foreign\012                                 "
"   declarations\012    -ignore-repository             do not refer to repository fo"
"r extensions\012    -keep-shadowed-macros          do not remove shadowed macro\012   "
" -host                          compile for host when configured for\012           "
"                         cross-compiling\012    -private-repository            load"
" extensions from executable path\012    -deployed                      link support"
" file to be used from a deployed \012                                    executable"
" (sets `rpath\047 accordingly, if supported\012                                    on "
"this platform)\012    -no-elevation                  embed manifest on Windows to s"
"upress elevation\012                                    warnings for programs named"
" `install\047 or `setup\047\012\012  Options can be collapsed if unambiguous, so\012\012    -vkfO\012"
"\012  is the same as\012\012    -v -k -fixnum-arithmetic -optimize\012\012  The contents of the"
" environment variable CSC_OPTIONS are implicitly passed to\012  every invocation of"
" `");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\033 FILENAME | OPTION ...\012\012  `");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\007Usage: ");
lf[253]=C_h_intern(&lf[253],8,"-release");
lf[254]=C_h_intern(&lf[254],15,"chicken-version");
lf[255]=C_h_intern(&lf[255],8,"-version");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\011 -version");
lf[257]=C_h_intern(&lf[257],4,"-c++");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000\017-no-cpp-precomp");
lf[259]=C_h_intern(&lf[259],5,"-objc");
lf[260]=C_h_intern(&lf[260],7,"-static");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-static");
lf[263]=C_h_intern(&lf[263],12,"-static-libs");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-static");
lf[266]=C_h_intern(&lf[266],7,"-cflags");
lf[267]=C_h_intern(&lf[267],8,"-ldflags");
lf[268]=C_h_intern(&lf[268],8,"-cc-name");
lf[269]=C_h_intern(&lf[269],9,"-cxx-name");
lf[270]=C_h_intern(&lf[270],8,"-ld-name");
lf[271]=C_h_intern(&lf[271],5,"-home");
lf[272]=C_h_intern(&lf[272],5,"-libs");
lf[273]=C_h_intern(&lf[273],2,"-v");
lf[274]=C_h_intern(&lf[274],8,"-verbose");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\010-verbose");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\002-Q");
lf[279]=C_h_intern(&lf[279],2,"-w");
lf[280]=C_h_intern(&lf[280],12,"-no-warnings");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\002-w");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000\014-no-warnings");
lf[283]=C_h_intern(&lf[283],2,"-A");
lf[284]=C_h_intern(&lf[284],13,"-analyze-only");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\015-analyze-only");
lf[286]=C_h_intern(&lf[286],2,"-P");
lf[287]=C_h_intern(&lf[287],13,"-check-syntax");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\015-check-syntax");
lf[289]=C_h_intern(&lf[289],2,"-k");
lf[290]=C_h_intern(&lf[290],2,"-c");
lf[291]=C_h_intern(&lf[291],2,"-t");
lf[292]=C_h_intern(&lf[292],2,"-e");
lf[293]=C_h_intern(&lf[293],9,"-embedded");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\014-DC_EMBEDDED");
lf[295]=C_h_intern(&lf[295],18,"-require-extension");
lf[296]=C_h_intern(&lf[296],2,"-R");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\022-require-extension");
lf[298]=C_h_intern(&lf[298],19,"-private-repository");
lf[299]=C_h_intern(&lf[299],13,"-no-elevation");
lf[300]=C_h_intern(&lf[300],4,"-gui");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\007-DC_GUI");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\012-lkernel32");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\010-luser32");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\007-lgdi32");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\011-mwindows");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\012chicken.rc");
lf[307]=C_h_intern(&lf[307],7,"-deploy");
lf[308]=C_h_intern(&lf[308],9,"-deployed");
lf[309]=C_h_intern(&lf[309],10,"-framework");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\012-framework");
lf[311]=C_h_intern(&lf[311],2,"-o");
lf[312]=C_h_intern(&lf[312],12,"-output-file");
lf[313]=C_h_intern(&lf[313],2,"-O");
lf[314]=C_h_intern(&lf[314],3,"-O1");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\0011");
lf[317]=C_h_intern(&lf[317],3,"-O0");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[320]=C_h_intern(&lf[320],3,"-O2");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\0012");
lf[323]=C_h_intern(&lf[323],3,"-O3");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\0013");
lf[326]=C_h_intern(&lf[326],3,"-O4");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\0014");
lf[329]=C_h_intern(&lf[329],3,"-O5");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\0015");
lf[332]=C_h_intern(&lf[332],3,"-d0");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[335]=C_h_intern(&lf[335],3,"-d1");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\0011");
lf[338]=C_h_intern(&lf[338],3,"-d2");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000\0012");
lf[341]=C_h_intern(&lf[341],8,"-dry-run");
lf[342]=C_h_intern(&lf[342],2,"-s");
lf[343]=C_h_intern(&lf[343],4,"-dll");
lf[344]=C_h_intern(&lf[344],8,"-library");
lf[345]=C_h_intern(&lf[345],9,"-compiler");
lf[346]=C_h_intern(&lf[346],3,"-cc");
lf[347]=C_h_intern(&lf[347],4,"-cxx");
lf[348]=C_h_intern(&lf[348],3,"-ld");
lf[349]=C_h_intern(&lf[349],2,"-I");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[351]=C_h_intern(&lf[351],2,"-C");
lf[352]=C_h_intern(&lf[352],6,"-strip");
lf[353]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[354]=C_h_intern(&lf[354],2,"-L");
lf[355]=C_h_intern(&lf[355],6,"-rpath");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\006-Wl,-R");
lf[357]=C_h_intern(&lf[357],3,"gnu");
lf[358]=C_h_intern(&lf[358],5,"clang");
lf[359]=C_h_intern(&lf[359],14,"build-platform");
lf[360]=C_h_intern(&lf[360],5,"-host");
lf[361]=C_h_intern(&lf[361],3,"-oi");
lf[362]=C_decode_literal(C_heaptop,"\376B\000\000\021-emit-inline-file");
lf[363]=C_h_intern(&lf[363],3,"-ot");
lf[364]=C_decode_literal(C_heaptop,"\376B\000\000\017-emit-type-file");
lf[365]=C_h_intern(&lf[365],1,"-");
lf[366]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[367]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\001-\376\377\016");
lf[368]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-h\376\003\000\000\002\376B\000\000\005-help\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-s\376\003\000\000\002\376B\000\000\007-shared\376\377\016\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\002-S\376\003\000\000\002\376B\000\000\013-scrutinize\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-M\376\003\000\000\002\376B\000\000\007-module\376\377\016\376\003\000\000\002\376\003\000\000\002"
"\376\001\000\000\002-P\376\003\000\000\002\376B\000\000\015-check-syntax\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-f\376\003\000\000\002\376B\000\000\022-fixnum-arithmetic\376\377"
"\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-D\376\003\000\000\002\376B\000\000\010-feature\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-insensit"
"ive\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-K\376\003\000\000\002\376B\000\000\016-keyword-style\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-X\376\003\000\000\002\376B\000\000\007-ex"
"tend\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-J\376\003\000\000\002\376B\000\000\032-emit-all-import-libraries\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-x"
"\376\003\000\000\002\376B\000\000\015-explicit-use\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-u\376\003\000\000\002\376B\000\000\007-unsafe\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-j"
"\376\003\000\000\002\376B\000\000\024-emit-import-library\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-n\376\003\000\000\002\376B\000\000\021-emit-inline-file\376\377\016"
"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-b\376\003\000\000\002\376B\000\000\006-block\376\377\016\376\377\016");
lf[369]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015-explicit-use\376\003\000\000\002\376\001\000\000\011-no-trace\376\003\000\000\002\376\001\000\000\014-no-warnings\376\003\000\000\002\376\001\000\000\026-no-us"
"ual-integrations\376\003\000\000\002\376\001\000\000\027-optimize-leaf-routines\376\003\000\000\002\376\001\000\000\007-unsafe\376\003\000\000\002\376\001\000\000\006-blo"
"ck\376\003\000\000\002\376\001\000\000\023-disable-interrupts\376\003\000\000\002\376\001\000\000\022-fixnum-arithmetic\376\003\000\000\002\376\001\000\000\012-to-stdout\376"
"\003\000\000\002\376\001\000\000\010-profile\376\003\000\000\002\376\001\000\000\004-raw\376\003\000\000\002\376\001\000\000\023-accumulate-profile\376\003\000\000\002\376\001\000\000\015-check-syn"
"tax\376\003\000\000\002\376\001\000\000\021-case-insensitive\376\003\000\000\002\376\001\000\000\007-shared\376\003\000\000\002\376\001\000\000\017-compile-syntax\376\003\000\000\002\376\001\000"
"\000\017-no-lambda-info\376\003\000\000\002\376\001\000\000\010-dynamic\376\003\000\000\002\376\001\000\000\036-disable-stack-overflow-checks\376\003\000\000\002"
"\376\001\000\000\006-local\376\003\000\000\002\376\001\000\000\037-emit-external-prototypes-first\376\003\000\000\002\376\001\000\000\007-inline\376\003\000\000\002\376\001\000\000\010-"
"release\376\003\000\000\002\376\001\000\000\013-scrutinize\376\003\000\000\002\376\001\000\000\015-analyze-only\376\003\000\000\002\376\001\000\000\025-keep-shadowed-macr"
"os\376\003\000\000\002\376\001\000\000\016-inline-global\376\003\000\000\002\376\001\000\000\022-ignore-repository\376\003\000\000\002\376\001\000\000\021-no-symbol-escap"
"e\376\003\000\000\002\376\001\000\000\030-no-parentheses-synonyms\376\003\000\000\002\376\001\000\000\014-r5rs-syntax\376\003\000\000\002\376\001\000\000\017-no-argc-chec"
"ks\376\003\000\000\002\376\001\000\000\020-no-bound-checks\376\003\000\000\002\376\001\000\000\024-no-procedure-checks\376\003\000\000\002\376\001\000\000\023-no-compiler"
"-syntax\376\003\000\000\002\376\001\000\000\032-emit-all-import-libraries\376\003\000\000\002\376\001\000\000\013-setup-mode\376\003\000\000\002\376\001\000\000\015-no-el"
"evation\376\003\000\000\002\376\001\000\000\027-no-module-registration\376\003\000\000\002\376\001\000\000\047-no-procedure-checks-for-usual"
"-bindings\376\003\000\000\002\376\001\000\000\007-module\376\003\000\000\002\376\001\000\000\013-specialize\376\003\000\000\002\376\001\000\000\015-strict-types\376\003\000\000\002\376\001\000\000\013"
"-clustering\376\003\000\000\002\376\001\000\000\005-lfa2\376\003\000\000\002\376\001\000\000\052-no-procedure-checks-for-toplevel-bindings\376\377"
"\016");
lf[370]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006-debug\376\003\000\000\002\376\001\000\000\012-heap-size\376\003\000\000\002\376\001\000\000\010-nursery\376\003\000\000\002\376\001\000\000\013-stack-size\376\003\000\000\002"
"\376\001\000\000\011-compiler\376\003\000\000\002\376\001\000\000\005-unit\376\003\000\000\002\376\001\000\000\005-uses\376\003\000\000\002\376\001\000\000\016-keyword-style\376\003\000\000\002\376\001\000\000\017-o"
"ptimize-level\376\003\000\000\002\376\001\000\000\015-include-path\376\003\000\000\002\376\001\000\000\016-database-size\376\003\000\000\002\376\001\000\000\007-extend\376\003\000"
"\000\002\376\001\000\000\010-prelude\376\003\000\000\002\376\001\000\000\011-postlude\376\003\000\000\002\376\001\000\000\011-prologue\376\003\000\000\002\376\001\000\000\011-epilogue\376\003\000\000\002\376\001\000"
"\000\015-inline-limit\376\003\000\000\002\376\001\000\000\015-profile-name\376\003\000\000\002\376\001\000\000\021-emit-inline-file\376\003\000\000\002\376\001\000\000\006-type"
"s\376\003\000\000\002\376\001\000\000\017-emit-type-file\376\003\000\000\002\376\001\000\000\010-feature\376\003\000\000\002\376\001\000\000\014-debug-level\376\003\000\000\002\376\001\000\000\024-con"
"sult-inline-file\376\003\000\000\002\376\001\000\000\024-emit-import-library\376\003\000\000\002\376\001\000\000\013-no-feature\376\377\016");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[372]=C_h_intern(&lf[372],9,"substring");
lf[373]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid option `~A\047");
lf[375]=C_h_intern(&lf[375],15,"lset-difference");
lf[376]=C_h_intern(&lf[376],6,"char=\077");
lf[377]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000P\376\003\000\000\002\376\377\012\000\000H\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000s\376\003\000\000\002\376\377\012\000\000f\376\003\000\000\002\376\377\012\000\000i\376\003\000\000\002\376\377\012\000\000E\376\003\000"
"\000\002\376\377\012\000\000N\376\003\000\000\002\376\377\012\000\000x\376\003\000\000\002\376\377\012\000\000u\376\003\000\000\002\376\377\012\000\000b\376\003\000\000\002\376\377\012\000\000v\376\003\000\000\002\376\377\012\000\000w\376\003\000\000\002\376\377\012\000\000A\376\003\000\000\002\376"
"\377\012\000\000O\376\003\000\000\002\376\377\012\000\000e\376\003\000\000\002\376\377\012\000\000W\376\003\000\000\002\376\377\012\000\000k\376\003\000\000\002\376\377\012\000\000c\376\003\000\000\002\376\377\012\000\000t\376\003\000\000\002\376\377\012\000\000g\376\003\000\000\002\376\377\012\000"
"\000S\376\003\000\000\002\376\377\012\000\000J\376\003\000\000\002\376\377\012\000\000M\376\377\016");
lf[378]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid option `~A\047");
lf[379]=C_decode_literal(C_heaptop,"\376B\000\000\004-Wl,");
lf[380]=C_h_intern(&lf[380],18,"decompose-pathname");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000\001h");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[383]=C_decode_literal(C_heaptop,"\376B\000\000\002rc");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000\003cpp");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000\001C");
lf[386]=C_decode_literal(C_heaptop,"\376B\000\000\002cc");
lf[387]=C_decode_literal(C_heaptop,"\376B\000\000\003cxx");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000\003hpp");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000\017-no-cpp-precomp");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000\001m");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000\001M");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\002mm");
lf[393]=C_decode_literal(C_heaptop,"\376B\000\000\030file `~A\047 does not exist");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\004.scm");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\002-:");
lf[396]=C_h_intern(&lf[396],15,"-optimize-level");
lf[397]=C_h_intern(&lf[397],15,"-benchmark-mode");
lf[398]=C_h_intern(&lf[398],10,"-to-stdout");
lf[399]=C_h_intern(&lf[399],7,"-shared");
lf[400]=C_h_intern(&lf[400],8,"-dynamic");
lf[401]=C_h_intern(&lf[401],14,"string->symbol");
lf[402]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[403]=C_decode_literal(C_heaptop,"\376B\000\000\013CSC_OPTIONS");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[405]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\003-I\042");
lf[407]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[408]=C_decode_literal(C_heaptop,"\376B\000\000\002:;");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000\026CHICKEN_C_INCLUDE_PATH");
lf[410]=C_decode_literal(C_heaptop,"\376B\000\000\003-I\042");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[412]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[413]=C_decode_literal(C_heaptop,"\376B\000\000\007include");
lf[414]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000\002-l");
lf[416]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[417]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[418]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[419]=C_decode_literal(C_heaptop,"\376B\000\000\003cyg");
lf[420]=C_decode_literal(C_heaptop,"\376B\000\000\002-0");
lf[421]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[422]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005-DPIC\376\377\016");
lf[423]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005-fPIC\376\003\000\000\002\376B\000\000\005-DPIC\376\377\016");
lf[424]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[425]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[426]=C_decode_literal(C_heaptop,"\376B\000\000\005share");
lf[427]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[428]=C_h_intern(&lf[428],22,"command-line-arguments");
lf[429]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
C_register_lf2(lf,430,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1352,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2895 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in ... */
static void C_fcall f_2897(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2897,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2900,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_truep(C_eqp(((C_word*)t0)[2],lf[396]))?C_SCHEME_TRUE:(C_truep(C_eqp(((C_word*)t0)[2],lf[397]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t3=C_mutate2(&lf[82] /* (set! compilation-optimization-options ...) */,C_retrieve2(lf[47],"best-compilation-optimization-options"));
t4=C_mutate2(&lf[83] /* (set! linking-optimization-options ...) */,C_retrieve2(lf[49],"best-linking-optimization-options"));
t5=t2;
f_2900(t5,t4);}
else{
t3=t2;
f_2900(t3,C_SCHEME_UNDEFINED);}}

/* k2892 in k2885 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in ... */
static void C_ccall f_2894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(&lf[86] /* (set! target-filename ...) */,t1);
/* csc.scm:808: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1852(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}

/* k3278 in k3274 in a3187 in k3175 in k2963 in k2954 in k2898 in k2895 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in ... */
static void C_ccall f_3280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(&lf[56] /* (set! object-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3286 in k3274 in a3187 in k3175 in k2963 in k2954 in k2898 in k2895 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in ... */
static void C_ccall f_3288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(&lf[51] /* (set! scheme-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2010 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in ... */
static void C_fcall f_2012(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2012,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2015,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[86],"target-filename"))){
t3=t2;
f_2015(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2022,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[92],"shared"))){
t4=C_i_car(C_retrieve2(lf[51],"scheme-files"));
/* csc.scm:562: pathname-replace-extension */
t5=C_fast_retrieve(lf[201]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_retrieve2(lf[39],"shared-library-extension"));}
else{
t4=C_i_car(C_retrieve2(lf[51],"scheme-files"));
/* csc.scm:563: pathname-replace-extension */
t5=C_fast_retrieve(lf[201]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_retrieve2(lf[37],"executable-extension"));}}}

/* k2013 in k2010 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in ... */
static void C_fcall f_2015(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2015,NULL,2,t0,t1);}
t2=C_retrieve2(lf[51],"scheme-files");
t3=C_i_check_list_2(C_retrieve2(lf[51],"scheme-files"),lf[150]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3671,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_3671(t7,((C_word*)t0)[2],C_retrieve2(lf[51],"scheme-files"));}

/* k3018 in k2963 in k2954 in k2898 in k2895 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in ... */
static void C_ccall f_3020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3020,2,t0,t1);}
/* csc.scm:771: t-options */
f_1779(((C_word*)t0)[3],C_a_i_list(&a,2,lf[371],t1));}

/* k2383 in k2380 in k2376 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in ... */
static void C_ccall f_2385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)((C_word*)t0)[2])[1];
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_u_i_cdr(t2));
/* csc.scm:808: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1852(t4,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k2380 in k2376 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in ... */
static void C_ccall f_2382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2382,2,t0,t1);}
t2=C_mutate2(&lf[95] /* (set! required-extensions ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2385,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
/* csc.scm:646: t-options */
f_1779(t3,C_a_i_list(&a,2,lf[297],t4));}

/* k3295 in k3175 in k2963 in k2954 in k2898 in k2895 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in ... */
static void C_ccall f_3297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3297,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3303,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csc.scm:805: file-exists? */
t4=C_fast_retrieve(lf[156]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k3068 in k3127 in k3131 in k3041 in k2963 in k2954 in k2898 in k2895 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in ... */
static void C_ccall f_3070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
/* csc.scm:808: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1852(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k4289 in k4286 in k4283 in k4277 in k4243 in k4193 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in ... */
static void C_ccall f_4291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:913: command */
f_4679(((C_word*)t0)[2],t1);}

/* k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in ... */
static void C_ccall f_4031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4031,2,t0,t1);}
if(C_truep(C_retrieve2(lf[88],"keep-files"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_retrieve2(lf[137],"$delete-file");
t3=C_retrieve2(lf[57],"generated-object-files");
t4=C_i_check_list_2(C_retrieve2(lf[57],"generated-object-files"),lf[150]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4042,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_4042(t8,((C_word*)t0)[2],C_retrieve2(lf[57],"generated-object-files"));}}

/* k4283 in k4277 in k4243 in k4193 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in ... */
static void C_ccall f_4285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4288,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4295,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4299,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:913: make-pathname */
t5=C_fast_retrieve(lf[103]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[5])[1],lf[185]);}

/* k4286 in k4283 in k4277 in k4243 in k4193 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in ... */
static void C_ccall f_4288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4291,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:913: get-output-string */
t3=C_fast_retrieve(lf[108]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k4259 in k4253 in k4246 in k4243 in k4193 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in ... */
static void C_ccall f_4261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4264,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4271,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4275,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:914: make-pathname */
t5=C_fast_retrieve(lf[103]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[5])[1],lf[183]);}

/* for-each-loop729 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in ... */
static void C_fcall f_4042(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4042,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4052,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csc.scm:959: g730 */
t5=((C_word*)t0)[3];
((C_proc3)C_fast_retrieve_proc(t5))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4293 in k4283 in k4277 in k4243 in k4193 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in ... */
static void C_ccall f_4295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:913: ##sys#print */
t2=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k4297 in k4283 in k4277 in k4243 in k4193 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in ... */
static void C_ccall f_4299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4299,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5866,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t4=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k3301 in k3295 in k3175 in k2963 in k2954 in k2898 in k2895 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in ... */
static void C_ccall f_3303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3303,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t2);
/* csc.scm:808: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1852(t4,((C_word*)t0)[5],((C_word*)((C_word*)t0)[3])[1]);}
else{
/* csc.scm:807: stop */
f_1403(((C_word*)t0)[6],lf[393],C_a_i_list(&a,1,((C_word*)t0)[7]));}}

/* k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in ... */
static void C_ccall f_4016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4016,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4019,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=t3;
t5=C_retrieve2(lf[86],"target-filename");
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5871,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t7=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,C_retrieve2(lf[86],"target-filename"));}

/* k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in ... */
static void C_ccall f_4019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4019,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4022,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[67],"deploy"))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4195,a[2]=t5,a[3]=t3,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* csc.scm:910: pathname-strip-extension */
t8=C_fast_retrieve(lf[188]);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,C_retrieve2(lf[86],"target-filename"));}
else{
t7=t6;
f_4022(2,t7,C_SCHEME_UNDEFINED);}}

/* k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in ... */
static void C_ccall f_4022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4025,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4158,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4162,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_truep(C_retrieve2(lf[58],"cpp-mode"))?C_retrieve2(lf[32],"c++-linker"):C_retrieve2(lf[31],"linker"));
t6=t5;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4170,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4178,a[2]=t7,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4191,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=t9;
t11=C_retrieve2(lf[86],"target-filename");
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5851,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t13=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,C_retrieve2(lf[86],"target-filename"));}

/* k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in ... */
static void C_ccall f_4025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4028,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4102,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[3],"osx"))){
t4=C_i_not(C_retrieve2(lf[22],"cross-chicken"));
if(C_truep(t4)){
t5=t3;
f_4102(t5,t4);}
else{
t5=C_retrieve2(lf[21],"host-mode");
t6=t3;
f_4102(t6,C_retrieve2(lf[21],"host-mode"));}}
else{
t4=t3;
f_4102(t4,C_SCHEME_FALSE);}}

/* k4026 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in ... */
static void C_ccall f_4028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4031,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4066,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[67],"deploy"))){
t4=C_retrieve2(lf[93],"static");
if(C_truep(C_retrieve2(lf[93],"static"))){
t5=C_retrieve2(lf[93],"static");
t6=C_retrieve2(lf[93],"static");
t7=t3;
f_4066(t7,C_i_not(C_retrieve2(lf[93],"static")));}
else{
t5=C_retrieve2(lf[94],"static-libs");
t6=C_retrieve2(lf[94],"static-libs");
t7=t3;
f_4066(t7,C_i_not(C_retrieve2(lf[94],"static-libs")));}}
else{
t4=t3;
f_4066(t4,C_SCHEME_FALSE);}}

/* k5006 in k5002 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in ... */
static void C_ccall f_5008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:219: string-append */
t2=*((C_word*)lf[119]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k3333 in k2898 in k2895 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in ... */
static void C_ccall f_3335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2956(t2,C_u_i_string_equal_p(lf[395],t1));}

/* k4084 in k4064 in k4026 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in ... */
static void C_ccall f_4086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4086,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t1;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4390,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4397,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4356,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:969: get-environment-variable */
t8=C_fast_retrieve(lf[168]);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,lf[169]);}

/* k4080 in k4067 in k4064 in k4026 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in ... */
static void C_ccall f_4082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4082,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t1;
t4=((C_word*)((C_word*)t0)[3])[1];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4754,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* csc.scm:1072: make-pathname */
t6=C_fast_retrieve(lf[103]);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,lf[162]);}

/* k4354 in k4084 in k4064 in k4026 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in ... */
static void C_ccall f_4356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4356,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4362,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}

/* f5903 in k3771 in g560 in k3766 in k3763 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in ... */
static void C_ccall f5903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5033 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in ... */
static void C_ccall f_5035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:134: string-split */
t2=C_fast_retrieve(lf[227]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5047 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in ... */
static void C_ccall f_5049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:130: string-split */
t2=C_fast_retrieve(lf[227]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* lib-path in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in ... */
static void C_fcall f_4336(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4336,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4344,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[21],"host-mode"))){
/* ##sys#peek-c-string */
t3=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t3=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_TARGET_RUN_LIB_HOME),C_fix(0));}}

/* k4328 in map-loop651 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in ... */
static void C_ccall f_4330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4330,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4301(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4301(t6,((C_word*)t0)[5],t5);}}

/* k4755 in k4752 in k4080 in k4067 in k4064 in k4026 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in ... */
static void C_ccall f_4757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4757,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4760,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm:1074: make-pathname */
t4=C_fast_retrieve(lf[103]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[5],lf[160]);}

/* k4752 in k4080 in k4067 in k4064 in k4026 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in ... */
static void C_ccall f_4754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4754,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4757,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm:1073: make-pathname */
t4=C_fast_retrieve(lf[103]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],lf[161]);}

/* k5037 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in ... */
static void C_ccall f_5039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:132: string-split */
t2=C_fast_retrieve(lf[227]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* map-loop651 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in ... */
static void C_fcall f_4301(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4301,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4330,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* csc.scm:906: g657 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4764 in k4761 in k4758 in k4755 in k4752 in k4080 in k4067 in k4064 in k4026 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in ... */
static void C_ccall f_4766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4769,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:1080: make-pathname */
t3=C_fast_retrieve(lf[103]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],lf[157]);}

/* k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4080 in k4067 in k4064 in k4026 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in ... */
static void C_ccall f_4769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4769,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4772,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4775,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* csc.scm:1081: file-exists? */
t5=C_fast_retrieve(lf[156]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4761 in k4758 in k4755 in k4752 in k4080 in k4067 in k4064 in k4026 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in ... */
static void C_ccall f_4763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4763,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4766,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4809,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:1076: file-exists? */
t4=C_fast_retrieve(lf[156]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k4758 in k4755 in k4752 in k4080 in k4067 in k4064 in k4026 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in ... */
static void C_ccall f_4760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4760,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4763,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* csc.scm:1075: make-pathname */
t4=C_fast_retrieve(lf[103]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[159]);}

/* k4734 in k4731 in k4728 in k4725 in k4722 in k4716 in k4103 in k4100 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in ... */
static void C_ccall f_4736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:1066: command */
f_4679(((C_word*)t0)[2],t1);}

/* k5002 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in ... */
static void C_ccall f_5004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5004,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5008,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_retrieve2(lf[45],"default-library");
/* ##sys#string-append */
((C_proc4)C_fast_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),t3,lf[417],C_retrieve2(lf[45],"default-library"));}

/* k4998 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in ... */
static void C_ccall f_5000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5000,2,t0,t1);}
t2=C_retrieve2(lf[45],"default-library");
if(C_truep(C_retrieve2(lf[18],"chicken-prefix"))){
t3=C_a_i_list2(&a,2,C_retrieve2(lf[18],"chicken-prefix"),lf[416]);
/* csc.scm:88: make-pathname */
t4=C_fast_retrieve(lf[103]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t3,C_retrieve2(lf[45],"default-library"));}
else{
t3=((C_word*)t0)[3];
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f6332,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t5=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t1);}}

/* f5946 in k4994 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in ... */
static void C_ccall f5946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4728 in k4725 in k4722 in k4716 in k4103 in k4100 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in ... */
static void C_ccall f_4730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4730,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4733,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4740,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4744,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:1069: make-pathname */
t5=C_fast_retrieve(lf[103]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve2(lf[26],"home"),lf[171]);}

/* k4731 in k4728 in k4725 in k4722 in k4716 in k4103 in k4100 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in ... */
static void C_ccall f_4733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4736,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:1067: get-output-string */
t3=C_fast_retrieve(lf[108]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* f5931 in k2050 in k2047 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in ... */
static void C_ccall f5931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:545: exit */
t2=C_fast_retrieve(lf[13]);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4742 in k4728 in k4725 in k4722 in k4716 in k4103 in k4100 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in ... */
static void C_ccall f_4744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4744,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5836,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t4=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k4746 in k4722 in k4716 in k4103 in k4100 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in ... */
static void C_ccall f_4748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:1067: ##sys#print */
t2=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k1607 in k1603 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in ... */
static void C_fcall f_1609(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1609,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1613,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csc.scm:281: get-environment-variable */
t4=C_fast_retrieve(lf[168]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[229]);}

/* k5074 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in ... */
static void C_ccall f_5076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5076,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5951,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t4=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k4738 in k4728 in k4725 in k4722 in k4716 in k4103 in k4100 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in ... */
static void C_ccall f_4740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:1067: ##sys#print */
t2=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k1603 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_fcall f_1605(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1605,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1609,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[68],"deployed"))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1677,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:278: software-version */
t5=C_fast_retrieve(lf[234]);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_1609(t4,C_SCHEME_END_OF_LIST);}}

/* k2268 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_fcall f_2270(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2270,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2273,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:624: t-options */
f_1779(t2,C_a_i_list(&a,1,lf[275]));}

/* f5920 in k3566 in k3535 in k3532 in for-each-loop469 in k2013 in k2010 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in ... */
static void C_ccall f5920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2271 in k2268 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in ... */
static void C_ccall f_2273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(C_retrieve2(lf[87],"verbose"))){
t2=lf[87] /* verbose */ =C_fix(2);;
/* csc.scm:808: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1852(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=lf[87] /* verbose */ =C_SCHEME_TRUE;;
/* csc.scm:808: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1852(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}}

/* k5060 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in ... */
static void C_ccall f_5062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:124: string-append */
t2=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[419],t1,lf[420]);}

/* f5925 in k3535 in k3532 in for-each-loop469 in k2013 in k2010 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in ... */
static void C_ccall f5925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1920 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in ... */
static void C_ccall f_1943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:573: command */
f_4679(((C_word*)t0)[2],t1);}

/* k1938 in k1935 in k1932 in k1929 in k1926 in k1920 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in ... */
static void C_ccall f_1940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1940,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1943,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:574: get-output-string */
t3=C_fast_retrieve(lf[108]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k3994 in map-loop620 in k3957 in compiler-options in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_3996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3996,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3967(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3967(t6,((C_word*)t0)[5],t5);}}

/* k4342 in lib-path in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in ... */
static void C_ccall f_4344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4344,2,t0,t1);}
t2=((C_word*)t0)[2];
if(C_truep(C_retrieve2(lf[18],"chicken-prefix"))){
t3=C_a_i_list2(&a,2,C_retrieve2(lf[18],"chicken-prefix"),lf[102]);
/* csc.scm:88: make-pathname */
t4=C_fast_retrieve(lf[103]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,lf[104]);}
else{
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k4566 in fold in k4541 in k4599 in k4593 in quote-option in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in ... */
static void C_ccall f_4568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:1025: cons* */
t2=C_fast_retrieve(lf[125]);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],C_make_character(92),((C_word*)t0)[3],t1);}

/* k1611 in k1607 in k1603 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in ... */
static void C_ccall f_1613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1613,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1616,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
t4=t1;
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1626,a[2]=t8,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* csc.scm:283: string-split */
t10=C_fast_retrieve(lf[227]);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t4,lf[228]);}
else{
/* csc.scm:262: append */
t3=*((C_word*)lf[100]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}}

/* k1614 in k1611 in k1607 in k1603 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in ... */
static void C_ccall f_1616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:262: append */
t2=*((C_word*)lf[100]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k1945 in k1935 in k1932 in k1929 in k1926 in k1920 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in ... */
static void C_ccall f_1947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:574: ##sys#print */
t2=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k5067 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in ... */
static void C_ccall f_5069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:125: string-append */
t2=*((C_word*)lf[119]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[421],t1);}

/* k5104 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f_5106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5106,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5966,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t4=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k1949 in k1935 in k1932 in k1929 in k1926 in k1920 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in ... */
static void C_ccall f_1951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1951,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5878,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t4=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f_1430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1430,2,t0,t1);}
t2=C_mutate2(&lf[18] /* (set! chicken-prefix ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1434,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:82: command-line-arguments */
t4=C_fast_retrieve(lf[428]);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f_1434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1434,2,t0,t1);}
t2=C_mutate2(&lf[19] /* (set! arguments ...) */,t1);
t3=C_i_member(lf[20],C_retrieve2(lf[19],"arguments"));
t4=C_mutate2(&lf[21] /* (set! host-mode ...) */,t3);
t5=C_fudge(C_fix(39));
t6=C_mutate2(&lf[22] /* (set! cross-chicken ...) */,t5);
t7=C_mutate2(&lf[23] /* (set! quotewrap ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1457,tmp=(C_word)a,a+=2,tmp));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1469,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5142,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5146,a[2]=t9,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[21],"host-mode"))){
/* ##sys#peek-c-string */
t11=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,C_mpointer(&a,(void*)C_INSTALL_SHARE_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t11=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,C_mpointer(&a,(void*)C_TARGET_SHARE_HOME),C_fix(0));}}

/* k1624 in k1611 in k1607 in k1603 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in ... */
static void C_ccall f_1626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1626,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1631,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1631(t5,((C_word*)t0)[4],t1);}

/* k1953 in k1929 in k1926 in k1920 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in ... */
static void C_ccall f_1955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:574: ##sys#print */
t2=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k1920 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in ... */
static void C_ccall f_1922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1922,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[106]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1928,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve2(lf[42],"windows-shell"))){
/* csc.scm:574: ##sys#print */
t6=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[190],C_SCHEME_FALSE,t3);}
else{
/* csc.scm:574: ##sys#print */
t6=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[191],C_SCHEME_FALSE,t3);}}

/* fold in k4541 in k4599 in k4593 in quote-option in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in ... */
static void C_fcall f_4545(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4545,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=C_i_car(t2);
t4=t3;
if(C_truep(C_i_memq(t4,lf[117]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4568,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=t2;
t7=C_u_i_cdr(t6);
/* csc.scm:1025: fold */
t11=t5;
t12=t7;
t1=t11;
t2=t12;
goto loop;}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4573,a[2]=t1,a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_u_i_char_whitespacep(t4))){
t6=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t7=t5;
f_4573(t7,t6);}
else{
t6=t5;
f_4573(t6,C_SCHEME_UNDEFINED);}}}}

/* map-loop162 in k1624 in k1611 in k1607 in k1603 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in ... */
static void C_fcall f_1631(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1631,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1660,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* csc.scm:283: g185 */
t5=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,lf[225],t4,lf[226]);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1926 in k1920 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in ... */
static void C_ccall f_1928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1928,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1931,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:574: ##sys#write-char-0 */
((C_proc4)C_fast_retrieve_symbol_proc(lf[14]))(4,*((C_word*)lf[14]+1),t2,C_make_character(32),((C_word*)t0)[4]);}

/* k2245 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_2247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:616: exit */
t2=C_fast_retrieve(lf[13]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k4541 in k4599 in k4593 in quote-option in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_4543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4543,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4545,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4545(t5,((C_word*)t0)[3],t1);}

/* quotewrap in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f_1457(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1457,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1465,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t4=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k3858 in for-each-loop580 in k3808 in k3804 in k3766 in k3763 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in ... */
static void C_ccall f_3860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3850(t3,((C_word*)t0)[4],t2);}

/* compiler-options in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in ... */
static void C_fcall f_3951(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3951,NULL,1,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_retrieve2(lf[97],"quote-option");
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3959,a[2]=t1,a[3]=t5,a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=C_retrieve2(lf[93],"static");
t9=(C_truep(C_retrieve2(lf[93],"static"))?C_retrieve2(lf[93],"static"):C_retrieve2(lf[94],"static-libs"));
if(C_truep(t9)){
/* csc.scm:897: append */
t10=*((C_word*)lf[100]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t7,C_SCHEME_END_OF_LIST,C_retrieve2(lf[82],"compilation-optimization-options"),C_retrieve2(lf[79],"compile-options"));}
else{
/* csc.scm:897: append */
t10=*((C_word*)lf[100]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t7,C_SCHEME_END_OF_LIST,C_retrieve2(lf[82],"compilation-optimization-options"),C_retrieve2(lf[79],"compile-options"));}}

/* k4523 in k4599 in k4593 in quote-option in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_4525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4525,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4535,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:1030: string-translate* */
t3=C_fast_retrieve(lf[122]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,lf[123]);}
else{
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1463 in quotewrap in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f_1465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3957 in compiler-options in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in ... */
static void C_ccall f_3959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3959,2,t0,t1);}
t2=C_i_check_list_2(t1,lf[98]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3965,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3967,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_3967(t7,t3,t1);}

/* f5951 in k5074 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in ... */
static void C_ccall f5951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5140 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f_5142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5142,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5981,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t4=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k5094 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in ... */
static void C_ccall f_5096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5096,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5961,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t4=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k2233 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_2235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:615: exit */
t2=C_fast_retrieve(lf[13]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* f5956 in k5084 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in ... */
static void C_ccall f5956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5144 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f_5146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5146,2,t0,t1);}
if(C_truep(C_retrieve2(lf[18],"chicken-prefix"))){
t2=C_a_i_list2(&a,2,C_retrieve2(lf[18],"chicken-prefix"),lf[426]);
/* csc.scm:88: make-pathname */
t3=C_fast_retrieve(lf[103]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,lf[427]);}
else{
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f6342,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t4=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}}

/* k4533 in k4523 in k4599 in k4593 in quote-option in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in ... */
static void C_ccall f_4535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:1030: string-append */
t2=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[120],t1,lf[121]);}

/* k3835 in for-each-loop597 in k3817 in k3808 in k3804 in k3766 in k3763 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in ... */
static void C_ccall f_3837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3827(t3,((C_word*)t0)[4],t2);}

/* k4537 in k4599 in k4593 in quote-option in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_4539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* list->string */
t2=C_fast_retrieve(lf[124]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5132 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f_5134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5134,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5138,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_CHICKEN_PROGRAM),C_fix(0));}

/* k5128 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f_5130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5130,2,t0,t1);}
if(C_truep(C_retrieve2(lf[18],"chicken-prefix"))){
t2=C_a_i_list2(&a,2,C_retrieve2(lf[18],"chicken-prefix"),lf[424]);
/* csc.scm:88: make-pathname */
t3=C_fast_retrieve(lf[103]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,lf[425]);}
else{
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f6337,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t4=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}}

/* k1675 in k1603 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in ... */
static void C_ccall f_1677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1677,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1609(t2,(C_truep((C_truep(C_eqp(t1,lf[230]))?C_SCHEME_TRUE:(C_truep(C_eqp(t1,lf[231]))?C_SCHEME_TRUE:(C_truep(C_eqp(t1,lf[232]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))?C_a_i_list1(&a,1,lf[233]):C_SCHEME_END_OF_LIST));}

/* k2221 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_2223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:614: exit */
t2=C_fast_retrieve(lf[13]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k5084 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in ... */
static void C_ccall f_5086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5086,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5956,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t4=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k5136 in k5132 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f_5138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:101: make-pathname */
t2=C_fast_retrieve(lf[103]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k3804 in k3766 in k3763 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in ... */
static void C_ccall f_3806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3806,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3810,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3875,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:889: reverse */
t4=*((C_word*)lf[203]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[3])[1]);}

/* k3798 in k3794 in k3771 in g560 in k3766 in k3763 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in ... */
static void C_ccall f_3800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3800,2,t0,t1);}
t2=C_a_i_list3(&a,3,C_retrieve2(lf[30],"rc-compiler"),((C_word*)t0)[2],t1);
/* csc.scm:884: string-intersperse */
t3=C_fast_retrieve(lf[99]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],t2);}

/* k2283 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_2285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2285,2,t0,t1);}
t2=C_mutate2(&lf[79] /* (set! compile-options ...) */,t1);
t3=C_a_i_cons(&a,2,lf[276],C_retrieve2(lf[85],"link-options"));
t4=C_mutate2(&lf[85] /* (set! link-options ...) */,t3);
t5=((C_word*)t0)[2];
f_2270(t5,t4);}

/* k4500 in linker-libraries in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in ... */
static void C_fcall f_4502(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4502,NULL,2,t0,t1);}
t2=C_retrieve2(lf[93],"static");
if(C_truep(C_retrieve2(lf[93],"static"))){
t3=C_retrieve2(lf[93],"static");
t4=(C_truep(C_retrieve2(lf[93],"static"))?C_a_i_list1(&a,1,C_retrieve2(lf[70],"extra-libraries")):C_a_i_list1(&a,1,C_retrieve2(lf[71],"extra-shared-libraries")));
/* csc.scm:1005: append */
t5=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t1,t4);}
else{
t3=C_retrieve2(lf[94],"static-libs");
t4=(C_truep(C_retrieve2(lf[94],"static-libs"))?C_a_i_list1(&a,1,C_retrieve2(lf[70],"extra-libraries")):C_a_i_list1(&a,1,C_retrieve2(lf[71],"extra-shared-libraries")));
/* csc.scm:1005: append */
t5=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t1,t4);}}

/* k2973 in k2963 in k2954 in k2898 in k2895 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in ... */
static void C_ccall f_2975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(&lf[85] /* (set! link-options ...) */,t1);
/* csc.scm:808: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1852(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}

/* k1687 in k1683 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in ... */
static void C_ccall f_1689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1689,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1605(t2,C_a_i_list2(&a,2,((C_word*)t0)[3],t1));}

/* k1683 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_1685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1685,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1689,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1693,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[68],"deployed"))){
/* csc.scm:266: conc */
t5=C_fast_retrieve(lf[235]);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,lf[236],lf[238],lf[237]);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1700,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[21],"host-mode"))){
/* ##sys#peek-c-string */
t6=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t6=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_TARGET_RUN_LIB_HOME),C_fix(0));}}}

/* k2209 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_2211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:613: exit */
t2=C_fast_retrieve(lf[13]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k5124 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f_5126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5126,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5976,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t4=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* for-each-loop580 in k3808 in k3804 in k3766 in k3763 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in ... */
static void C_fcall f_3850(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3850,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3860,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csc.scm:891: g581 */
t5=((C_word*)t0)[3];
((C_proc3)C_fast_retrieve_proc(t5))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2963 in k2954 in k2898 in k2895 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in ... */
static void C_fcall f_2965(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2965,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_subchar(((C_word*)t0)[2],C_fix(1));
if(C_truep(C_i_char_equalp(C_make_character(108),t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2975,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=C_a_i_list1(&a,1,((C_word*)t0)[2]);
/* csc.scm:765: append */
t5=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,C_retrieve2(lf[85],"link-options"),t4);}
else{
t3=C_subchar(((C_word*)t0)[2],C_fix(1));
if(C_truep(C_i_char_equalp(C_make_character(76),t3))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2989,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=C_a_i_list1(&a,1,((C_word*)t0)[2]);
/* csc.scm:767: append */
t6=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,C_retrieve2(lf[85],"link-options"),t5);}
else{
t4=C_subchar(((C_word*)t0)[2],C_fix(1));
if(C_truep(C_i_char_equalp(C_make_character(73),t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3003,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=C_a_i_list1(&a,1,((C_word*)t0)[2]);
/* csc.scm:769: append */
t7=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,C_retrieve2(lf[79],"compile-options"),t6);}
else{
t5=C_subchar(((C_word*)t0)[2],C_fix(1));
if(C_truep(C_i_char_equalp(C_make_character(68),t5))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3020,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:771: substring */
t7=*((C_word*)lf[372]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[2],C_fix(2));}
else{
t6=C_subchar(((C_word*)t0)[2],C_fix(1));
if(C_truep(C_i_char_equalp(C_make_character(70),t6))){
if(C_truep(C_retrieve2(lf[3],"osx"))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3033,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t8=C_a_i_list1(&a,1,((C_word*)t0)[2]);
/* csc.scm:774: append */
t9=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,C_retrieve2(lf[79],"compile-options"),t8);}
else{
/* csc.scm:808: loop */
t7=((C_word*)((C_word*)t0)[3])[1];
f_1852(t7,((C_word*)t0)[4],((C_word*)((C_word*)t0)[5])[1]);}}
else{
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3043,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t8=C_block_size(((C_word*)t0)[2]);
if(C_truep(C_fixnum_greaterp(t8,C_fix(3)))){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3150,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:775: substring */
t10=*((C_word*)lf[372]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,((C_word*)t0)[2],C_fix(0),C_fix(4));}
else{
t9=t7;
f_3043(t9,C_SCHEME_FALSE);}}}}}}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3177,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* csc.scm:784: file-exists? */
t3=C_fast_retrieve(lf[156]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k3558 in k3535 in k3532 in for-each-loop469 in k2013 in k2010 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in ... */
static void C_ccall f_3560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:827: command */
f_4679(((C_word*)t0)[2],t1);}

/* k5114 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f_5116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5116,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5971,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t4=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k3562 in k3535 in k3532 in for-each-loop469 in k2013 in k2010 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in ... */
static void C_ccall f_3564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:828: string-intersperse */
t2=C_fast_retrieve(lf[99]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[212]);}

/* k3566 in k3535 in k3532 in for-each-loop469 in k2013 in k2010 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in ... */
static void C_ccall f_3568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3568,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3572,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3576,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[91],"to-stdout"))){
t5=t4;
f_3576(t5,lf[216]);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3642,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5920,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t8=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t0)[3]);}}

/* k1691 in k1683 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in ... */
static void C_ccall f_1693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:266: conc */
t2=C_fast_retrieve(lf[235]);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[236],t1,lf[237]);}

/* for-each-loop597 in k3817 in k3808 in k3804 in k3766 in k3763 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in ... */
static void C_fcall f_3827(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3827,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3837,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csc.scm:892: g598 */
t5=((C_word*)t0)[3];
((C_proc3)C_fast_retrieve_proc(t5))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* a4605 in k4593 in quote-option in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in ... */
static void C_ccall f_4606(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4606,3,t0,t1,t2);}
t3=C_u_i_char_whitespacep(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:C_i_memq(t2,lf[117])));}

/* k3535 in k3532 in for-each-loop469 in k2013 in k2010 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in ... */
static void C_ccall f_3537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3537,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3540,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3560,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3564,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3568,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5925,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t8=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t0)[4]);}

/* k3532 in for-each-loop469 in k2013 in k2010 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in ... */
static void C_ccall f_3534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3534,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3537,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_member(t2,C_retrieve2(lf[52],"c-files")))){
/* csc.scm:825: stop */
f_1403(t3,lf[218],C_a_i_list(&a,2,((C_word*)t0)[3],t2));}
else{
t4=t3;
f_3537(2,t4,C_SCHEME_UNDEFINED);}}

/* k3538 in k3535 in k3532 in for-each-loop469 in k2013 in k2010 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in ... */
static void C_ccall f_3540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3540,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3544,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_a_i_list1(&a,1,((C_word*)t0)[3]);
/* csc.scm:846: append */
t4=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve2(lf[52],"c-files"));}

/* k3542 in k3538 in k3535 in k3532 in for-each-loop469 in k2013 in k2010 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in ... */
static void C_ccall f_3544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3544,2,t0,t1);}
t2=C_mutate2(&lf[52] /* (set! c-files ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3548,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_a_i_list1(&a,1,((C_word*)t0)[3]);
/* csc.scm:847: append */
t5=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_retrieve2(lf[54],"generated-c-files"));}

/* k3546 in k3542 in k3538 in k3535 in k3532 in for-each-loop469 in k2013 in k2010 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in ... */
static void C_ccall f_3548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(&lf[54] /* (set! generated-c-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1929 in k1926 in k1920 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in ... */
static void C_ccall f_1931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1931,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1934,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1955,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=t3;
t5=C_retrieve2(lf[86],"target-filename");
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5883,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t7=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,C_retrieve2(lf[86],"target-filename"));}

/* k1932 in k1929 in k1926 in k1920 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in ... */
static void C_ccall f_1934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1934,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1937,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:574: ##sys#write-char-0 */
((C_proc4)C_fast_retrieve_symbol_proc(lf[14]))(4,*((C_word*)lf[14]+1),t2,C_make_character(32),((C_word*)t0)[4]);}

/* k1935 in k1932 in k1929 in k1926 in k1920 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in ... */
static void C_ccall f_1937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1937,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1940,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1947,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1951,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:578: string-append */
t5=*((C_word*)lf[119]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve2(lf[86],"target-filename"),lf[189]);}

/* k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f_5156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5156,2,t0,t1);}
t2=C_eqp(t1,lf[6]);
t3=C_mutate2(&lf[7] /* (set! aix ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1400,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:75: software-version */
t5=C_fast_retrieve(lf[234]);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k1898 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in ... */
static void C_ccall f_1900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1903,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:571: ##sys#print */
t3=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,C_retrieve2(lf[86],"target-filename"),C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k1901 in k1898 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in ... */
static void C_ccall f_1903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1903,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1906,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:571: ##sys#print */
t3=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[193],C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k1907 in k1904 in k1901 in k1898 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in ... */
static void C_ccall f_1909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1909,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1912,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:571: ##sys#print */
t3=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[192],C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k1904 in k1901 in k1898 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in ... */
static void C_ccall f_1906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1906,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1909,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:571: ##sys#print */
t3=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,C_retrieve2(lf[86],"target-filename"),C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k3148 in k2963 in k2954 in k2898 in k2895 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in ... */
static void C_ccall f_3150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3043(t2,C_u_i_string_equal_p(lf[379],t1));}

/* k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in ... */
static void C_ccall f_1915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1922,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:574: open-output-string */
t3=C_fast_retrieve(lf[111]);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1910 in k1907 in k1904 in k1901 in k1898 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in ... */
static void C_ccall f_1912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1912,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1915,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:571: ##sys#write-char-0 */
((C_proc4)C_fast_retrieve_symbol_proc(lf[14]))(4,*((C_word*)lf[14]+1),t2,C_make_character(10),((C_word*)t0)[3]);}

/* k4697 in $delete-file in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in ... */
static void C_ccall f_4699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_retrieve2(lf[65],"dry-run"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* csc.scm:1062: delete-file */
t2=C_fast_retrieve(lf[138]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* $delete-file in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in ... */
static void C_ccall f_4695(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4695,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4699,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[87],"verbose"))){
/* csc.scm:1061: print */
t4=*((C_word*)lf[136]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[139],t2);}
else{
if(C_truep(C_retrieve2(lf[65],"dry-run"))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
/* csc.scm:1062: delete-file */
t4=C_fast_retrieve(lf[138]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}}}

/* k4691 in command in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in ... */
static void C_ccall f_4693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_i_zerop(t1))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* csc.scm:1057: exit */
t2=C_fast_retrieve(lf[13]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_retrieve2(lf[128],"last-exit-code"));}}

/* k3127 in k3131 in k3041 in k2963 in k2954 in k2898 in k2895 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in ... */
static void C_ccall f_3129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3129,2,t0,t1);}
if(C_truep(C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3070,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_i_check_list_2(((C_word*)t0)[5],lf[98]);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3087,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3089,a[2]=t6,a[3]=t10,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_3089(t12,t8,((C_word*)t0)[5]);}
else{
/* csc.scm:782: stop */
f_1403(((C_word*)t0)[6],lf[374],C_a_i_list(&a,1,((C_word*)t0)[7]));}}

/* k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f_1373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1376,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f_1376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1379,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f_1370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1373,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f_1379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5168,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:69: build-platform */
t3=C_fast_retrieve(lf[359]);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* command in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in ... */
static void C_fcall f_4679(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4679,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4693,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=t3;
t5=t2;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4629,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[87],"verbose"))){
/* csc.scm:1044: print */
t7=*((C_word*)lf[136]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t5);}
else{
t7=t6;
f_4629(2,t7,C_SCHEME_UNDEFINED);}}

/* k4893 in k4890 in k4886 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in ... */
static void C_ccall f_4895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:241: append */
t2=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k4890 in k4886 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in ... */
static void C_ccall f_4892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4892,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4895,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
t4=t1;
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4905,a[2]=t8,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* csc.scm:245: string-split */
t10=C_fast_retrieve(lf[227]);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t4,lf[408]);}
else{
/* csc.scm:241: append */
t3=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}}

/* k1353 in k1350 */
static void C_ccall f_1355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1355,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1358,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_chicken_2dsyntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1350 */
static void C_ccall f_1352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1352,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1355,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3116 in map-loop410 in k3127 in k3131 in k3041 in k2963 in k2954 in k2898 in k2895 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in ... */
static void C_ccall f_3118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3118,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3089(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3089(t6,((C_word*)t0)[5],t5);}}

/* k1356 in k1353 in k1350 */
static void C_ccall f_1358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1358,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1361,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_2dstructures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f_1364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1364,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1367,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_2d1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1359 in k1356 in k1353 in k1350 */
static void C_ccall f_1361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1361,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1364,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k4876 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in ... */
static void C_ccall f_4878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4878,2,t0,t1);}
if(C_truep(C_retrieve2(lf[18],"chicken-prefix"))){
t2=C_a_i_list2(&a,2,C_retrieve2(lf[18],"chicken-prefix"),lf[404]);
/* csc.scm:88: make-pathname */
t3=C_fast_retrieve(lf[103]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,lf[405]);}
else{
t2=((C_word*)t0)[2];
f_1594(2,t2,t1);}}

/* k4869 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in ... */
static void C_ccall f_4871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
/* csc.scm:1132: string-split */
t3=C_fast_retrieve(lf[227]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}
else{
/* csc.scm:1132: string-split */
t2=C_fast_retrieve(lf[227]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[402]);}}

/* k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f_1367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1367,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1370,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_2d13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k4886 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in ... */
static void C_fcall f_4888(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4888,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4892,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csc.scm:243: get-environment-variable */
t4=C_fast_retrieve(lf[168]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[409]);}

/* k2565 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_2567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
/* csc.scm:808: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1852(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k4050 in for-each-loop729 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in ... */
static void C_ccall f_4052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4042(t3,((C_word*)t0)[4],t2);}

/* k4067 in k4064 in k4026 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in ... */
static void C_ccall f_4069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4069,2,t0,t1);}
t2=(C_truep(C_retrieve2(lf[3],"osx"))?C_retrieve2(lf[66],"gui"):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4082,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:957: pathname-file */
t4=C_fast_retrieve(lf[163]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_retrieve2(lf[86],"target-filename"));}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[2];
f_4031(2,t4,t3);}}

/* k4064 in k4026 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in ... */
static void C_fcall f_4066(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4066,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4069,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4086,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[3],"osx"))){
t4=C_retrieve2(lf[66],"gui");
if(C_truep(C_retrieve2(lf[66],"gui"))){
/* csc.scm:953: make-pathname */
t5=C_fast_retrieve(lf[103]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)((C_word*)t0)[3])[1],lf[170]);}
else{
t5=t3;
f_4086(2,t5,((C_word*)((C_word*)t0)[3])[1]);}}
else{
t4=t3;
f_4086(2,t4,((C_word*)((C_word*)t0)[3])[1]);}}
else{
t2=((C_word*)t0)[2];
f_4031(2,t2,C_SCHEME_UNDEFINED);}}

/* k2515 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_2517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
/* csc.scm:808: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1852(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k1658 in map-loop162 in k1624 in k1611 in k1607 in k1603 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in ... */
static void C_ccall f_1660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1660,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_1631(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_1631(t6,((C_word*)t0)[5],t5);}}

/* k4395 in k4084 in k4064 in k4026 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in ... */
static void C_ccall f_4397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4397,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4401,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[3],"osx"))){
/* csc.scm:978: make-pathname */
t4=C_fast_retrieve(lf[103]);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],t2,C_retrieve2(lf[44],"libchicken"),lf[164]);}
else{
t4=C_retrieve2(lf[1],"mingw");
t5=(C_truep(C_retrieve2(lf[1],"mingw"))?C_retrieve2(lf[1],"mingw"):C_retrieve2(lf[5],"cygwin"));
if(C_truep(t5)){
/* csc.scm:978: make-pathname */
t6=C_fast_retrieve(lf[103]);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,((C_word*)t0)[2],t2,C_retrieve2(lf[44],"libchicken"),lf[165]);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4415,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:985: number->string */
C_number_to_string(3,0,t6,C_fix((C_word)C_BINARY_VERSION));}}}

/* k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in ... */
static void C_ccall f_1888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1888,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_retrieve2(lf[23],"quotewrap");
t8=C_retrieve2(lf[56],"object-files");
t9=C_i_check_list_2(C_retrieve2(lf[56],"object-files"),lf[98]);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4016,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4301,a[2]=t6,a[3]=t12,a[4]=t4,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_4301(t14,t10,C_retrieve2(lf[56],"object-files"));}

/* k4388 in k4084 in k4064 in k4026 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in ... */
static void C_ccall f_4390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:986: copy-files */
f_4417(((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* k2525 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_2527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
/* csc.scm:808: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1852(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k2439 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_2441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2441,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_retrieve2(lf[56],"object-files"));
t3=C_mutate2(&lf[56] /* (set! object-files ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2437,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:662: cons* */
t5=C_fast_retrieve(lf[125]);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t4,lf[302],lf[303],lf[304],lf[305],C_retrieve2(lf[85],"link-options"));}

/* k2443 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_2445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:657: make-pathname */
t2=C_fast_retrieve(lf[103]);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,lf[306],C_retrieve2(lf[33],"object-extension"));}

/* k3131 in k3041 in k2963 in k2954 in k2898 in k2895 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in ... */
static void C_ccall f_3133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3133,2,t0,t1);}
t2=C_i_cdr(t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3129,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csc.scm:779: lset-difference */
t5=C_fast_retrieve(lf[375]);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,*((C_word*)lf[376]+1),t3,lf[377]);}

/* k4814 in k4807 in k4761 in k4758 in k4755 in k4752 in k4080 in k4067 in k4064 in k4026 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in ... */
static void C_ccall f_4816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:1077: copy-files */
f_4417(((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* k4360 in k4354 in k4084 in k4064 in k4026 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in ... */
static void C_ccall f_4362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_i_string_equal_p(t1,lf[167]))){
/* csc.scm:975: lib-path */
f_4336(((C_word*)t0)[2]);}
else{
if(C_truep(C_retrieve2(lf[22],"cross-chicken"))){
t2=C_retrieve2(lf[21],"host-mode");
if(C_truep(C_retrieve2(lf[21],"host-mode"))){
/* csc.scm:975: lib-path */
f_4336(((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}
else{
/* csc.scm:975: lib-path */
f_4336(((C_word*)t0)[2]);}}}

/* k2435 in k2439 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in ... */
static void C_ccall f_2437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(&lf[85] /* (set! link-options ...) */,t1);
/* csc.scm:808: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1852(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}

/* k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in ... */
static void C_ccall f_1515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1515,2,t0,t1);}
t2=C_mutate2(&lf[45] /* (set! default-library ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1519,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5049,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[21],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CFLAGS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CFLAGS),C_fix(0));}}

/* k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in ... */
static void C_ccall f_1511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1511,2,t0,t1);}
t2=C_mutate2(&lf[44] /* (set! libchicken ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1515,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:128: string-append */
t4=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,C_retrieve2(lf[44],"libchicken"),lf[418],C_retrieve2(lf[35],"library-extension"));}

/* k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in ... */
static void C_ccall f_1519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1519,2,t0,t1);}
t2=C_mutate2(&lf[46] /* (set! default-compilation-optimization-options ...) */,t1);
t3=C_mutate2(&lf[47] /* (set! best-compilation-optimization-options ...) */,C_retrieve2(lf[46],"default-compilation-optimization-options"));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1524,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5039,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[21],"host-mode"))){
/* ##sys#peek-c-string */
t6=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_INSTALL_LDFLAGS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t6=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_TARGET_LDFLAGS),C_fix(0));}}

/* a4826 in k4820 in k3917 in k3902 in k3899 in k3763 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in ... */
static void C_ccall f_4827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4827,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4835,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=C_a_i_cons(&a,2,lf[204],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
t5=C_a_i_cons(&a,2,lf[205],t4);
/* csc.scm:1105: ##sys#print-to-string */
((C_proc3)C_fast_retrieve_symbol_proc(lf[153]))(3,*((C_word*)lf[153]+1),t2,t5);}

/* k4820 in k3917 in k3902 in k3899 in k3763 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in ... */
static void C_ccall f_4822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4827,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:1107: with-output-to-file */
t3=C_fast_retrieve(lf[154]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[4],t2);}

/* k3640 in k3566 in k3535 in k3532 in for-each-loop469 in k2013 in k2010 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in ... */
static void C_ccall f_3642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3642,2,t0,t1);}
t2=((C_word*)t0)[2];
f_3576(t2,C_a_i_list(&a,2,lf[217],t1));}

/* k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in ... */
static void C_ccall f_1524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1524,2,t0,t1);}
t2=C_mutate2(&lf[48] /* (set! default-linking-optimization-options ...) */,t1);
t3=C_mutate2(&lf[49] /* (set! best-linking-optimization-options ...) */,C_retrieve2(lf[48],"default-linking-optimization-options"));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1529,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[21],"host-mode"))){
t5=t4;
f_1529(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5035,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_TARGET_FEATURES),C_fix(0));}}

/* k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in ... */
static void C_ccall f_1529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1529,2,t0,t1);}
t2=C_mutate2(&lf[50] /* (set! extra-features ...) */,t1);
t3=lf[51] /* scheme-files */ =C_SCHEME_END_OF_LIST;;
t4=lf[52] /* c-files */ =C_SCHEME_END_OF_LIST;;
t5=lf[53] /* rc-files */ =C_SCHEME_END_OF_LIST;;
t6=lf[54] /* generated-c-files */ =C_SCHEME_END_OF_LIST;;
t7=lf[55] /* generated-rc-files */ =C_SCHEME_END_OF_LIST;;
t8=lf[56] /* object-files */ =C_SCHEME_END_OF_LIST;;
t9=lf[57] /* generated-object-files */ =C_SCHEME_END_OF_LIST;;
t10=lf[58] /* cpp-mode */ =C_SCHEME_FALSE;;
t11=lf[59] /* objc-mode */ =C_SCHEME_FALSE;;
t12=lf[60] /* embedded */ =C_SCHEME_FALSE;;
t13=lf[61] /* inquiry-only */ =C_SCHEME_FALSE;;
t14=lf[62] /* show-cflags */ =C_SCHEME_FALSE;;
t15=lf[63] /* show-ldflags */ =C_SCHEME_FALSE;;
t16=lf[64] /* show-libs */ =C_SCHEME_FALSE;;
t17=lf[65] /* dry-run */ =C_SCHEME_FALSE;;
t18=lf[66] /* gui */ =C_SCHEME_FALSE;;
t19=lf[67] /* deploy */ =C_SCHEME_FALSE;;
t20=lf[68] /* deployed */ =C_SCHEME_FALSE;;
t21=lf[69] /* rpath */ =C_SCHEME_FALSE;;
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1559,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[21],"host-mode"))){
/* ##sys#peek-c-string */
t23=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t23+1)))(4,t23,t22,C_mpointer(&a,(void*)C_INSTALL_MORE_STATIC_LIBS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t23=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t23+1)))(4,t23,t22,C_mpointer(&a,(void*)C_TARGET_MORE_STATIC_LIBS),C_fix(0));}}

/* k2575 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_2577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
/* csc.scm:808: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1852(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in ... */
static void C_fcall f_1852(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1852,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1863,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:537: append */
t4=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_retrieve2(lf[79],"compile-options"),C_retrieve2(lf[80],"builtin-compile-options"));}
else{
t3=C_i_car(t2);
t4=t3;
t5=t2;
t6=C_u_i_cdr(t5);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2093,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t7,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[6],a[9]=t4,tmp=(C_word)a,a+=10,tmp);
/* csc.scm:583: string->symbol */
t9=*((C_word*)lf[401]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t4);}}

/* k4807 in k4761 in k4758 in k4755 in k4752 in k4080 in k4067 in k4064 in k4026 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in ... */
static void C_ccall f_4809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4809,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_4766(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4816,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:1078: make-pathname */
t3=C_fast_retrieve(lf[103]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve2(lf[26],"home"),lf[158]);}}

/* k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in ... */
static void C_fcall f_1505(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1505,NULL,2,t0,t1);}
t2=C_mutate2(&lf[41] /* (set! pic-options ...) */,t1);
t3=C_mutate2(&lf[42] /* (set! windows-shell ...) */,C_mk_bool(C_WINDOWS_SHELL));
t4=lf[43] /* generate-manifest */ =C_SCHEME_FALSE;;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1511,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"cygwin"))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5062,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_LIB_NAME),C_fix(0));}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5069,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_LIB_NAME),C_fix(0));}}

/* k4659 in k4656 in k4653 in k4633 in k4630 in k4627 in command in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in ... */
static void C_ccall f_4661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4661,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4664,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:1050: ##sys#print */
t3=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k2595 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_2597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
/* csc.scm:808: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1852(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k2467 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_2469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2469,2,t0,t1);}
if(C_truep(C_retrieve2(lf[3],"osx"))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2480,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
/* csc.scm:672: cons* */
t4=C_fast_retrieve(lf[125]);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[310],t3,C_retrieve2(lf[85],"link-options"));}
else{
t2=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
/* csc.scm:808: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1852(t4,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}}

/* k4653 in k4633 in k4630 in k4627 in command in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in ... */
static void C_ccall f_4655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4655,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4658,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:1050: ##sys#print */
t3=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[3]);}

/* k4656 in k4653 in k4633 in k4630 in k4627 in command in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in ... */
static void C_ccall f_4658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4658,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4661,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:1050: ##sys#print */
t3=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[131],C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in ... */
static void C_ccall f_1559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1559,2,t0,t1);}
t2=C_mutate2(&lf[70] /* (set! extra-libraries ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1563,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[21],"host-mode"))){
/* ##sys#peek-c-string */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_INSTALL_MORE_LIBS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_MORE_LIBS),C_fix(0));}}

/* k2704 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in ... */
static void C_ccall f_2706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2706,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2710,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
/* csc.scm:714: cons* */
t5=C_fast_retrieve(lf[125]);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,lf[350],t3,t4);}

/* k4630 in k4627 in command in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in ... */
static void C_ccall f_4632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4632,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4635,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[65],"dry-run"))){
t4=t3;
f_4635(2,t4,C_fix(0));}
else{
/* csc.scm:1048: system */
t4=C_fast_retrieve(lf[133]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}}

/* f5846 in k4134 in k4131 in k4123 in k4100 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in ... */
static void C_ccall f5846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2585 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_2587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
/* csc.scm:808: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1852(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k4144 in k4131 in k4123 in k4100 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in ... */
static void C_ccall f_4146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:943: make-pathname */
t2=C_fast_retrieve(lf[103]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* k4662 in k4659 in k4656 in k4653 in k4633 in k4630 in k4627 in command in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in ... */
static void C_ccall f_4664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:1050: ##sys#write-char-0 */
((C_proc4)C_fast_retrieve_symbol_proc(lf[14]))(4,*((C_word*)lf[14]+1),((C_word*)t0)[2],C_make_character(10),((C_word*)t0)[3]);}

/* k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in ... */
static void C_ccall f_1563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1563,2,t0,t1);}
t2=C_mutate2(&lf[71] /* (set! extra-shared-libraries ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4992,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4996,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5000,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5004,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[21],"host-mode"))){
/* ##sys#peek-c-string */
t7=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}

/* k3243 in k3238 in a3187 in k3175 in k2963 in k2954 in k2898 in k2895 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in ... */
static void C_ccall f_3245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(&lf[52] /* (set! c-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3238 in a3187 in k3175 in k2963 in k2954 in k2898 in k2895 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in ... */
static void C_fcall f_3240(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3240,NULL,2,t0,t1);}
t2=lf[58] /* cpp-mode */ =C_SCHEME_TRUE;;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3245,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_a_i_list1(&a,1,((C_word*)t0)[3]);
/* csc.scm:795: append */
t5=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,C_retrieve2(lf[52],"c-files"),t4);}

/* f5836 in k4742 in k4728 in k4725 in k4722 in k4716 in k4103 in k4100 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in ... */
static void C_ccall f5836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4156 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in ... */
static void C_ccall f_4158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:926: command */
f_4679(((C_word*)t0)[2],t1);}

/* k4633 in k4630 in k4627 in command in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_4635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4635,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4638,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=t3;
f_4638(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=*((C_word*)lf[129]+1);
t6=*((C_word*)lf[129]+1);
t7=C_i_check_port_2(*((C_word*)lf[129]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[130]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4655,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csc.scm:1050: ##sys#print */
t9=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[132],C_SCHEME_FALSE,*((C_word*)lf[129]+1));}}

/* k4636 in k4633 in k4630 in k4627 in command in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in ... */
static void C_ccall f_4638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_eqp(((C_word*)t0)[2],C_fix(0));
if(C_truep(t2)){
t3=lf[128] /* last-exit-code */ =C_fix(0);;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve2(lf[128],"last-exit-code"));}
else{
t3=lf[128] /* last-exit-code */ =C_fix(1);;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve2(lf[128],"last-exit-code"));}}

/* f5814 in k4438 in k4435 in k4432 in k4429 in k4423 in copy-files in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in ... */
static void C_ccall f5814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2725 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in ... */
static void C_ccall f_2727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2731,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2739,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
/* csc.scm:717: string-split */
t5=C_fast_retrieve(lf[227]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* shared-build in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in ... */
static void C_fcall f_1812(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1812,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1817,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csc.scm:520: cons* */
t4=C_fast_retrieve(lf[125]);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[146],lf[147],C_retrieve2(lf[76],"translate-options"));}

/* k3794 in k3771 in g560 in k3766 in k3763 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in ... */
static void C_ccall f_3796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3796,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3800,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5898,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t6=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[3]);}

/* k2708 in k2704 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in ... */
static void C_ccall f_2710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
/* csc.scm:808: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1852(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k1819 in k1815 in shared-build in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_1821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1821,2,t0,t1);}
t2=C_mutate2(&lf[79] /* (set! compile-options ...) */,t1);
t3=(C_truep(C_retrieve2(lf[3],"osx"))?(C_truep(((C_word*)t0)[2])?C_a_i_cons(&a,2,lf[142],C_retrieve2(lf[85],"link-options")):C_a_i_cons(&a,2,lf[143],C_retrieve2(lf[85],"link-options"))):C_a_i_cons(&a,2,lf[144],C_retrieve2(lf[85],"link-options")));
t4=C_mutate2(&lf[85] /* (set! link-options ...) */,t3);
t5=lf[92] /* shared */ =C_SCHEME_TRUE;;
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k3619 in map-loop490 in k3582 in k3574 in k3566 in k3535 in k3532 in for-each-loop469 in k2013 in k2010 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in ... */
static void C_ccall f_3621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3621,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3592(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3592(t6,((C_word*)t0)[5],t5);}}

/* f5819 in k4432 in k4429 in k4423 in copy-files in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in ... */
static void C_ccall f5819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1815 in shared-build in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in ... */
static void C_ccall f_1817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1817,2,t0,t1);}
t2=C_mutate2(&lf[76] /* (set! translate-options ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1821,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:521: append */
t4=*((C_word*)lf[100]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,C_retrieve2(lf[41],"pic-options"),lf[145],C_retrieve2(lf[79],"compile-options"));}

/* k4399 in k4395 in k4084 in k4064 in k4026 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in ... */
static void C_ccall f_4401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:978: make-pathname */
t2=C_fast_retrieve(lf[103]);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],C_retrieve2(lf[44],"libchicken"),t1);}

/* a4617 in quote-option in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in ... */
static void C_ccall f_4618(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4618,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_char_equalp(C_make_character(34),t2));}

/* k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in ... */
static void C_ccall f_1594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[28],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1594,2,t0,t1);}
t2=C_mutate2(&lf[84] /* (set! library-dir ...) */,t1);
t3=lf[85] /* link-options */ =C_SCHEME_END_OF_LIST;;
t4=lf[86] /* target-filename */ =C_SCHEME_FALSE;;
t5=lf[87] /* verbose */ =C_SCHEME_FALSE;;
t6=lf[88] /* keep-files */ =C_SCHEME_FALSE;;
t7=lf[89] /* translate-only */ =C_SCHEME_FALSE;;
t8=lf[90] /* compile-only */ =C_SCHEME_FALSE;;
t9=lf[91] /* to-stdout */ =C_SCHEME_FALSE;;
t10=lf[92] /* shared */ =C_SCHEME_FALSE;;
t11=lf[93] /* static */ =C_SCHEME_FALSE;;
t12=lf[94] /* static-libs */ =C_SCHEME_FALSE;;
t13=lf[95] /* required-extensions */ =C_SCHEME_END_OF_LIST;;
t14=C_mutate2(&lf[96] /* (set! compiler-options ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3951,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate2(&lf[101] /* (set! lib-path ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4336,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate2(&lf[105] /* (set! copy-files ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4417,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate2(&lf[112] /* (set! linker-options ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4460,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate2(&lf[116] /* (set! linker-libraries ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4490,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate2(&lf[117] /* (set! constant797 ...) */,lf[118]);
t20=C_mutate2(&lf[97] /* (set! quote-option ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4588,tmp=(C_word)a,a+=2,tmp));
t21=lf[128] /* last-exit-code */ =C_SCHEME_FALSE;;
t22=C_mutate2(&lf[107] /* (set! command ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4679,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate2(&lf[137] /* (set! $delete-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4695,tmp=(C_word)a,a+=2,tmp));
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4853,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4863,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4867,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4871,a[2]=t26,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:1132: get-environment-variable */
t28=C_fast_retrieve(lf[168]);
((C_proc3)(void*)(*((C_word*)t28+1)))(3,t28,t27,lf[403]);}

/* k2494 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_2496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t3=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t3);
t5=C_mutate2(&lf[86] /* (set! target-filename ...) */,t2);
/* csc.scm:808: loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1852(t6,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* f5871 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in ... */
static void C_ccall f5871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f5888 in k3728 in k3701 in k3698 in g530 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in ... */
static void C_ccall f5888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4100 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in ... */
static void C_fcall f_4102(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4102,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4105,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4121,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4125,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_POSTINSTALL_PROGRAM),C_fix(0));}
else{
t2=((C_word*)t0)[2];
f_4028(2,t2,C_SCHEME_UNDEFINED);}}

/* k4103 in k4100 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in ... */
static void C_ccall f_4105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4105,2,t0,t1);}
t2=(C_truep(C_retrieve2(lf[66],"gui"))?C_i_not(C_retrieve2(lf[67],"deploy")):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
t4=((C_word*)((C_word*)t0)[3])[1];
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4718,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* csc.scm:1067: open-output-string */
t6=C_fast_retrieve(lf[111]);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[2];
f_4028(2,t4,t3);}}

/* k3774 in k3771 in g560 in k3766 in k3763 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in ... */
static void C_ccall f_3776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3776,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],C_retrieve2(lf[57],"generated-object-files"));
t3=C_mutate2(&lf[57] /* (set! generated-object-files ...) */,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k3771 in g560 in k3766 in k3763 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in ... */
static void C_ccall f_3773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3773,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3776,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3788,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3796,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=t5;
t7=((C_word*)t0)[4];
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5903,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t9=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t7);}

/* k4627 in command in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in ... */
static void C_ccall f_4629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4629,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4632,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[42],"windows-shell"))){
/* csc.scm:1046: string-append */
t3=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[134],((C_word*)t0)[3],lf[135]);}
else{
t3=t2;
f_4632(2,t3,((C_word*)t0)[3]);}}

/* k2729 in k2725 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in ... */
static void C_ccall f_2731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate2(&lf[79] /* (set! compile-options ...) */,t1);
t3=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t3);
/* csc.scm:808: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1852(t5,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* f5866 in k4297 in k4283 in k4277 in k4243 in k4193 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in ... */
static void C_ccall f5866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4599 in k4593 in quote-option in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in ... */
static void C_ccall f_4601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4601,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4525,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4539,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4543,a[2]=t5,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t9=C_fast_retrieve(lf[126]);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* k2737 in k2725 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in ... */
static void C_ccall f_2739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:717: append */
t2=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[79],"compile-options"),t1);}

/* f5861 in k4273 in k4259 in k4253 in k4246 in k4243 in k4193 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in ... */
static void C_ccall f5861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f5878 in k1949 in k1935 in k1932 in k1929 in k1926 in k1920 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in ... */
static void C_ccall f5878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2478 in k2467 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in ... */
static void C_ccall f_2480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate2(&lf[85] /* (set! link-options ...) */,t1);
t3=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t3);
/* csc.scm:808: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1852(t5,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* use-private-repository in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in ... */
static C_word C_fcall f_1835(C_word *a){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_stack_overflow_check;
t1=C_a_i_cons(&a,2,lf[148],C_retrieve2(lf[79],"compile-options"));
t2=C_mutate2(&lf[79] /* (set! compile-options ...) */,t1);
if(C_truep(C_retrieve2(lf[3],"osx"))){
t3=C_a_i_cons(&a,2,lf[149],C_retrieve2(lf[85],"link-options"));
t4=C_mutate2(&lf[85] /* (set! link-options ...) */,t3);
return(t4);}
else{
t3=C_SCHEME_UNDEFINED;
return(t3);}}

/* k3786 in k3771 in g560 in k3766 in k3763 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in ... */
static void C_ccall f_3788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:883: command */
f_4679(((C_word*)t0)[2],t1);}

/* f5856 in k4200 in k4196 in k4193 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in ... */
static void C_ccall f5856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3211 in a3187 in k3175 in k2963 in k2954 in k2898 in k2895 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in ... */
static void C_ccall f_3213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(&lf[52] /* (set! c-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* f5851 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in ... */
static void C_ccall f5851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in k5154 in ... */
static void C_ccall f_1578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1578,2,t0,t1);}
t2=C_i_member(t1,lf[77]);
t3=(C_truep(t2)?C_SCHEME_FALSE:t1);
t4=C_mutate2(&lf[78] /* (set! include-dir ...) */,t3);
t5=lf[79] /* compile-options */ =C_SCHEME_END_OF_LIST;;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1586,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4888,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[78],"include-dir"))){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4953,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:242: conc */
t9=C_fast_retrieve(lf[235]);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[410],C_retrieve2(lf[78],"include-dir"),lf[411]);}
else{
t8=t7;
f_4888(t8,C_SCHEME_END_OF_LIST);}}

/* k4435 in k4432 in k4429 in k4423 in copy-files in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in ... */
static void C_ccall f_4437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4440,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csc.scm:990: ##sys#write-char-0 */
((C_proc4)C_fast_retrieve_symbol_proc(lf[14]))(4,*((C_word*)lf[14]+1),t2,C_make_character(32),((C_word*)t0)[4]);}

/* k4429 in k4423 in copy-files in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in ... */
static void C_ccall f_4431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4431,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4434,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* csc.scm:990: ##sys#write-char-0 */
((C_proc4)C_fast_retrieve_symbol_proc(lf[14]))(4,*((C_word*)lf[14]+1),t2,C_make_character(32),((C_word*)t0)[4]);}

/* k4432 in k4429 in k4423 in copy-files in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_4434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4434,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4437,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4454,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=t3;
t5=((C_word*)t0)[6];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5819,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t7=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t5);}

/* f5841 in k4722 in k4716 in k4103 in k4100 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in ... */
static void C_ccall f5841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in k1428 in k1398 in ... */
static void C_ccall f_1586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1586,2,t0,t1);}
t2=C_mutate2(&lf[80] /* (set! builtin-compile-options ...) */,t1);
t3=lf[81] /* translation-optimization-options */ =C_SCHEME_END_OF_LIST;;
t4=C_mutate2(&lf[82] /* (set! compilation-optimization-options ...) */,C_retrieve2(lf[46],"default-compilation-optimization-options"));
t5=C_mutate2(&lf[83] /* (set! linking-optimization-options ...) */,C_retrieve2(lf[48],"default-linking-optimization-options"));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1594,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4878,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[21],"host-mode"))){
/* ##sys#peek-c-string */
t8=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t8=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}

/* k4444 in k4441 in k4438 in k4435 in k4432 in k4429 in k4423 in copy-files in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in ... */
static void C_ccall f_4446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:989: command */
f_4679(((C_word*)t0)[2],t1);}

/* k4441 in k4438 in k4435 in k4432 in k4429 in k4423 in copy-files in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in ... */
static void C_ccall f_4443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4446,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:990: get-output-string */
t3=C_fast_retrieve(lf[108]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k4438 in k4435 in k4432 in k4429 in k4423 in copy-files in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in ... */
static void C_ccall f_4440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4443,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4450,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=t3;
t5=((C_word*)t0)[5];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5814,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t7=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t5);}

/* k4413 in k4395 in k4084 in k4064 in k4026 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in ... */
static void C_ccall f_4415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#string-append */
((C_proc4)C_fast_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[166],t1);}

/* copy-files in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in ... */
static void C_fcall f_4417(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4417,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4425,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csc.scm:990: open-output-string */
t5=C_fast_retrieve(lf[111]);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k4854 in k4851 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in ... */
static void C_ccall f_4856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* k4857 in k4851 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in ... */
static void C_ccall f_4859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_fast_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k2776 in k2764 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in ... */
static void C_ccall f_2778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:723: append */
t2=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[85],"link-options"),t1);}

/* k2768 in k2764 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in ... */
static void C_ccall f_2770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate2(&lf[85] /* (set! link-options ...) */,t1);
t3=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t3);
/* csc.scm:808: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1852(t5,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k4851 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in ... */
static void C_ccall f_4853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4853,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4856,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4859,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_fast_retrieve_symbol_proc(lf[140]))(2,*((C_word*)lf[140]+1),t3);}

/* k4423 in copy-files in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in ... */
static void C_ccall f_4425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4425,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[106]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4431,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve2(lf[42],"windows-shell"))){
/* csc.scm:990: ##sys#print */
t6=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[109],C_SCHEME_FALSE,t3);}
else{
/* csc.scm:990: ##sys#print */
t6=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[110],C_SCHEME_FALSE,t3);}}

/* k4865 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in ... */
static void C_ccall f_4867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:1131: append */
t2=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_retrieve2(lf[19],"arguments"));}

/* k3936 in for-each-loop529 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in ... */
static void C_ccall f_3938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3928(t3,((C_word*)t0)[4],t2);}

/* k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in k1467 in k1432 in ... */
static void C_ccall f_4863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4863,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1779,tmp=(C_word)a,a+=2,tmp));
t11=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1786,tmp=(C_word)a,a+=2,tmp));
t12=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1812,tmp=(C_word)a,a+=2,tmp));
t13=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1835,tmp=(C_word)a,a+=2,tmp));
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1852,a[2]=t9,a[3]=t15,a[4]=t3,a[5]=t5,a[6]=t7,tmp=(C_word)a,a+=7,tmp));
t17=((C_word*)t15)[1];
f_1852(t17,((C_word*)t0)[2],t1);}

/* f5893 in k3701 in k3698 in g530 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in ... */
static void C_ccall f5893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4127 in k4123 in k4100 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in ... */
static void C_ccall f_4129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:937: string-append */
t2=*((C_word*)lf[119]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[173],C_retrieve2(lf[44],"libchicken"),lf[174],t1,lf[175],((C_word*)((C_word*)t0)[4])[1]);}

/* k4123 in k4100 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in ... */
static void C_ccall f_4125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4125,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4129,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4133,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_retrieve2(lf[44],"libchicken");
/* ##sys#string-append */
((C_proc4)C_fast_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),t4,C_retrieve2(lf[44],"libchicken"),lf[177]);}

/* k4833 in a4826 in k4820 in k3917 in k3902 in k3899 in k3763 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in ... */
static void C_ccall f_4835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:1109: print */
t2=*((C_word*)lf[136]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4119 in k4100 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in ... */
static void C_ccall f_4121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:936: command */
f_4679(((C_word*)t0)[2],t1);}

/* k3899 in k3763 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in ... */
static void C_fcall f_3901(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3901,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3904,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:876: pathname-replace-extension */
t3=C_fast_retrieve(lf[201]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve2(lf[86],"target-filename"),lf[207]);}
else{
t2=((C_word*)t0)[2];
f_3768(t2,C_SCHEME_UNDEFINED);}}

/* k3716 in k3701 in k3698 in g530 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in ... */
static void C_ccall f_3718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:861: command */
f_4679(((C_word*)t0)[2],t1);}

/* k3905 in k3902 in k3899 in k3763 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in ... */
static void C_ccall f_3907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3907,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],C_retrieve2(lf[53],"rc-files"));
t3=C_mutate2(&lf[53] /* (set! rc-files ...) */,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[2],C_retrieve2(lf[55],"generated-rc-files"));
t5=C_mutate2(&lf[55] /* (set! generated-rc-files ...) */,t4);
t6=((C_word*)t0)[3];
f_3768(t6,t5);}

/* k3902 in k3899 in k3763 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in ... */
static void C_ccall f_3904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3904,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3907,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3919,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csc.scm:877: pathname-file */
t5=C_fast_retrieve(lf[163]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,C_retrieve2(lf[86],"target-filename"));}

/* k2789 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in ... */
static void C_ccall f_2791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2791,2,t0,t1);}
t2=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate2(&lf[69] /* (set! rpath ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2805,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2821,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:728: build-platform */
t6=C_fast_retrieve(lf[359]);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* f5883 in k1929 in k1926 in k1920 in k1913 in k1910 in k1907 in k1904 in k1901 in k1898 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in ... */
static void C_ccall f5883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f5898 in k3794 in k3771 in g560 in k3766 in k3763 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in ... */
static void C_ccall f5898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f6342 in k5144 in k1432 in k1428 in k1398 in k5154 in k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f6342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4134 in k4131 in k4123 in k4100 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in ... */
static void C_ccall f_4136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4136,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5846,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t4=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k4131 in k4123 in k4100 in k4023 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in ... */
static void C_ccall f_4133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4133,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4136,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[68],"deployed"))){
/* csc.scm:942: make-pathname */
t4=C_fast_retrieve(lf[103]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[176],t2);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4146,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csc.scm:944: lib-path */
f_4336(t4);}}

/* k3917 in k3902 in k3899 in k3763 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in ... */
static void C_ccall f_3919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3919,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t1;
t4=((C_word*)t0)[3];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4822,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve2(lf[87],"verbose"))){
/* csc.scm:1106: print */
t6=*((C_word*)lf[136]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,lf[206],t4);}
else{
t6=t5;
f_4822(2,t6,C_SCHEME_UNDEFINED);}}

/* k4452 in k4432 in k4429 in k4423 in copy-files in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in ... */
static void C_ccall f_4454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:990: ##sys#print */
t2=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k4448 in k4438 in k4435 in k4432 in k4429 in k4423 in copy-files in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in ... */
static void C_ccall f_4450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:990: ##sys#print */
t2=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k3963 in k3957 in compiler-options in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in ... */
static void C_ccall f_3965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:895: string-intersperse */
t2=C_fast_retrieve(lf[99]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* map-loop620 in k3957 in compiler-options in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in ... */
static void C_fcall f_3967(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3967,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3996,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* csc.scm:896: g626 */
t5=((C_word*)t0)[5];
((C_proc3)C_fast_retrieve_proc(t5))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3701 in k3698 in g530 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in ... */
static void C_ccall f_3703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3703,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3706,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3718,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve2(lf[58],"cpp-mode"))?C_retrieve2(lf[29],"c++-compiler"):C_retrieve2(lf[28],"compiler"));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3730,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t7=t6;
t8=((C_word*)t0)[5];
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5893,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t10=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t8);}

/* k3704 in k3701 in k3698 in g530 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in ... */
static void C_ccall f_3706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3706,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],C_retrieve2(lf[57],"generated-object-files"));
t3=C_mutate2(&lf[57] /* (set! generated-object-files ...) */,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k3698 in g530 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in ... */
static void C_ccall f_3700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3700,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3703,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_member(t2,C_retrieve2(lf[56],"object-files")))){
/* csc.scm:859: stop */
f_1403(t3,lf[200],C_a_i_list(&a,2,((C_word*)t0)[4],t2));}
else{
t4=t3;
f_3703(2,t4,C_SCHEME_UNDEFINED);}}

/* k3225 in a3187 in k3175 in k2963 in k2954 in k2898 in k2895 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in ... */
static void C_ccall f_3227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(&lf[53] /* (set! rc-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in k1471 in ... */
static void C_ccall f_1863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1863,2,t0,t1);}
t2=C_mutate2(&lf[79] /* (set! compile-options ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1867,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2086,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1605,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[8],"elf"))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1685,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:265: conc */
t8=C_fast_retrieve(lf[235]);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,lf[241],C_retrieve2(lf[84],"library-dir"),lf[242]);}
else{
if(C_truep(C_retrieve2(lf[7],"aix"))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1716,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:275: conc */
t8=C_fast_retrieve(lf[235]);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,lf[243],C_retrieve2(lf[84],"library-dir"),lf[244]);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1723,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:277: conc */
t8=C_fast_retrieve(lf[235]);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,lf[245],C_retrieve2(lf[84],"library-dir"),lf[246]);}}}

/* k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_1867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1867,2,t0,t1);}
t2=C_mutate2(&lf[85] /* (set! link-options ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1870,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[61],"inquiry-only"))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2049,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[62],"show-cflags"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2082,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:541: compiler-options */
f_3951(t5);}
else{
t5=t4;
f_2049(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_1870(2,t4,C_SCHEME_UNDEFINED);}}

/* k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in ... */
static void C_ccall f_1870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1873,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(C_retrieve2(lf[51],"scheme-files")))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1974,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(C_retrieve2(lf[52],"c-files")))){
if(C_truep(C_i_nullp(C_retrieve2(lf[56],"object-files")))){
/* csc.scm:549: stop */
f_1403(t3,lf[211],C_SCHEME_END_OF_LIST);}
else{
t4=t3;
f_1974(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_1974(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2012,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve2(lf[92],"shared"))?C_i_not(C_retrieve2(lf[60],"embedded")):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_a_i_cons(&a,2,lf[222],C_retrieve2(lf[76],"translate-options"));
t6=C_mutate2(&lf[76] /* (set! translate-options ...) */,t5);
t7=t3;
f_2012(t7,t6);}
else{
t5=t3;
f_2012(t5,C_SCHEME_UNDEFINED);}}}

/* k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in ... */
static void C_ccall f_1873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1873,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1876,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[67],"deploy"))){
t3=C_retrieve2(lf[92],"shared");
t4=t2;
f_1876(t4,(C_truep(C_retrieve2(lf[92],"shared"))?C_SCHEME_UNDEFINED:f_1835(C_a_i(&a,6))));}
else{
t3=t2;
f_1876(t3,C_SCHEME_UNDEFINED);}}

/* k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in ... */
static void C_fcall f_1876(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1876,NULL,2,t0,t1);}
if(C_truep(C_retrieve2(lf[89],"translate-only"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1882,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=t2;
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3696,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=C_retrieve2(lf[52],"c-files");
t8=C_i_check_list_2(C_retrieve2(lf[52],"c-files"),lf[150]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3765,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3928,a[2]=t11,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t13=((C_word*)t11)[1];
f_3928(t13,t9,C_retrieve2(lf[52],"c-files"));}}

/* k3924 in k3763 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in ... */
static void C_ccall f_3926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3901(t2,C_eqp(lf[208],t1));}

/* for-each-loop529 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in ... */
static void C_fcall f_3928(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3928,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3938,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csc.scm:853: g530 */
t5=((C_word*)t0)[3];
f_3696(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in ... */
static void C_ccall f_1882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1882,2,t0,t1);}
if(C_truep(C_retrieve2(lf[90],"compile-only"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1888,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_member(C_retrieve2(lf[86],"target-filename"),C_retrieve2(lf[51],"scheme-files")))){
t3=*((C_word*)lf[129]+1);
t4=*((C_word*)lf[129]+1);
t5=C_i_check_port_2(*((C_word*)lf[129]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[130]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1900,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csc.scm:571: ##sys#print */
t7=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[194],C_SCHEME_FALSE,*((C_word*)lf[129]+1));}
else{
t3=t2;
f_1888(2,t3,C_SCHEME_UNDEFINED);}}}

/* k1972 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in ... */
static void C_ccall f_1974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1977,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(C_retrieve2(lf[52],"c-files")))){
t3=C_retrieve2(lf[56],"object-files");
t4=C_retrieve2(lf[56],"object-files");
/* csc.scm:550: last */
t5=C_fast_retrieve(lf[210]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t2,C_retrieve2(lf[56],"object-files"));}
else{
t3=C_retrieve2(lf[52],"c-files");
t4=C_retrieve2(lf[52],"c-files");
/* csc.scm:550: last */
t5=C_fast_retrieve(lf[210]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t2,C_retrieve2(lf[52],"c-files"));}}

/* k1975 in k1972 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in ... */
static void C_ccall f_1977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1977,2,t0,t1);}
if(C_truep(C_retrieve2(lf[86],"target-filename"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_1873(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1984,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[92],"shared"))){
/* csc.scm:554: pathname-replace-extension */
t3=C_fast_retrieve(lf[201]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,C_retrieve2(lf[39],"shared-library-extension"));}
else{
/* csc.scm:555: pathname-replace-extension */
t3=C_fast_retrieve(lf[201]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,C_retrieve2(lf[37],"executable-extension"));}}}

/* k2653 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in ... */
static void C_ccall f_2655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate2(&lf[28] /* (set! compiler ...) */,t2);
t4=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t4);
/* csc.scm:808: loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1852(t6,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k2636 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in ... */
static void C_ccall f_2638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate2(&lf[27] /* (set! translator ...) */,t2);
t4=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t4);
/* csc.scm:808: loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1852(t6,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_fcall f_2614(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2614,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csc.scm:693: shared-build */
f_1812(((C_word*)t0)[3],C_SCHEME_FALSE);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[343]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[4],lf[344]));
if(C_truep(t3)){
/* csc.scm:695: shared-build */
f_1812(((C_word*)t0)[3],C_SCHEME_TRUE);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[345]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2638,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:697: check */
f_1786(t5,((C_word*)t0)[9],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[346]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2655,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:701: check */
f_1786(t6,((C_word*)t0)[9],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[347]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2672,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:705: check */
f_1786(t7,((C_word*)t0)[9],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t7=C_eqp(((C_word*)t0)[4],lf[348]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2689,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:709: check */
f_1786(t8,((C_word*)t0)[9],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t8=C_eqp(((C_word*)t0)[4],lf[349]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2706,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:713: check */
f_1786(t9,((C_word*)t0)[9],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t9=C_eqp(((C_word*)t0)[4],lf[351]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2727,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:716: check */
f_1786(t10,((C_word*)t0)[9],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t10=C_eqp(((C_word*)t0)[4],lf[352]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2753,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t12=C_a_i_list1(&a,1,lf[353]);
/* csc.scm:720: append */
t13=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t11,C_retrieve2(lf[85],"link-options"),t12);}
else{
t11=C_eqp(((C_word*)t0)[4],lf[354]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2766,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:722: check */
f_1786(t12,((C_word*)t0)[9],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t12=C_eqp(((C_word*)t0)[4],lf[355]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2791,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:726: check */
f_1786(t13,((C_word*)t0)[9],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t13=C_eqp(((C_word*)t0)[4],lf[360]);
if(C_truep(t13)){
/* csc.scm:808: loop */
t14=((C_word*)((C_word*)t0)[6])[1];
f_1852(t14,((C_word*)t0)[7],((C_word*)((C_word*)t0)[5])[1]);}
else{
t14=C_eqp(((C_word*)t0)[4],lf[361]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2846,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* csc.scm:734: check */
f_1786(t15,((C_word*)t0)[9],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t15=C_eqp(((C_word*)t0)[4],lf[363]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2866,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* csc.scm:738: check */
f_1786(t16,((C_word*)t0)[9],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t16=C_eqp(((C_word*)t0)[4],lf[365]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2887,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:742: append */
t18=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t17,C_retrieve2(lf[51],"scheme-files"),lf[367]);}
else{
t17=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2897,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t18=C_eqp(((C_word*)t0)[9],lf[398]);
if(C_truep(t18)){
t19=lf[91] /* to-stdout */ =C_SCHEME_TRUE;;
t20=lf[89] /* translate-only */ =C_SCHEME_TRUE;;
t21=t17;
f_2897(t21,t20);}
else{
t19=t17;
f_2897(t19,C_SCHEME_UNDEFINED);}}}}}}}}}}}}}}}}}

/* k1982 in k1975 in k1972 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in ... */
static void C_ccall f_1984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(&lf[86] /* (set! target-filename ...) */,t1);
t3=((C_word*)t0)[2];
f_1873(2,t3,t2);}

/* k3808 in k3804 in k3766 in k3763 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in ... */
static void C_ccall f_3810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3810,2,t0,t1);}
t2=C_mutate2(&lf[56] /* (set! object-files ...) */,t1);
if(C_truep(C_retrieve2(lf[88],"keep-files"))){
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_retrieve2(lf[137],"$delete-file");
t4=C_retrieve2(lf[54],"generated-c-files");
t5=C_i_check_list_2(C_retrieve2(lf[54],"generated-c-files"),lf[150]);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3819,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3850,a[2]=t8,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_3850(t10,t6,C_retrieve2(lf[54],"generated-c-files"));}}

/* k2687 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in ... */
static void C_ccall f_2689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate2(&lf[31] /* (set! linker ...) */,t2);
t4=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t4);
/* csc.scm:808: loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1852(t6,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k3817 in k3808 in k3804 in k3766 in k3763 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in ... */
static void C_ccall f_3819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3819,2,t0,t1);}
t2=C_retrieve2(lf[137],"$delete-file");
t3=C_retrieve2(lf[55],"generated-rc-files");
t4=C_i_check_list_2(C_retrieve2(lf[55],"generated-rc-files"),lf[150]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3827,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_3827(t8,((C_word*)t0)[2],C_retrieve2(lf[55],"generated-rc-files"));}

/* k2670 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in ... */
static void C_ccall f_2672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate2(&lf[29] /* (set! c++-compiler ...) */,t2);
t4=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t4);
/* csc.scm:808: loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1852(t6,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k2183 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_2185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate2(&lf[76] /* (set! translate-options ...) */,t1);
t3=lf[94] /* static-libs */ =C_SCHEME_TRUE;;
/* csc.scm:808: loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1852(t4,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}

/* k3885 in for-each-loop559 in k3766 in k3763 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in ... */
static void C_ccall f_3887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3877(t3,((C_word*)t0)[4],t2);}

/* k2844 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in ... */
static void C_ccall f_2846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2849,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
/* csc.scm:735: t-options */
f_1779(t2,C_a_i_list(&a,2,lf[362],t3));}

/* k2847 in k2844 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in ... */
static void C_ccall f_2849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
/* csc.scm:808: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1852(t4,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k2141 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_2143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:592: system */
t2=C_fast_retrieve(lf[133]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3873 in k3804 in k3766 in k3763 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in ... */
static void C_ccall f_3875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:889: append */
t2=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_retrieve2(lf[56],"object-files"));}

/* for-each-loop559 in k3766 in k3763 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in ... */
static void C_fcall f_3877(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3877,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3887,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csc.scm:880: g560 */
t5=((C_word*)t0)[3];
f_3769(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2819 in k2789 in k2612 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in ... */
static void C_ccall f_2821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_truep(C_eqp(t1,lf[357]))?C_SCHEME_TRUE:(C_truep(C_eqp(t1,lf[358]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t2=C_retrieve2(lf[1],"mingw");
t3=((C_word*)t0)[2];
f_2805(t3,(C_truep(C_retrieve2(lf[1],"mingw"))?C_SCHEME_FALSE:C_i_not(C_retrieve2(lf[3],"osx"))));}
else{
t2=((C_word*)t0)[2];
f_2805(t2,C_SCHEME_FALSE);}}

/* k5158 in k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f_5160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5160,2,t0,t1);}
t2=C_eqp(t1,lf[4]);
t3=C_mutate2(&lf[5] /* (set! cygwin ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5156,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:72: build-platform */
t5=C_fast_retrieve(lf[359]);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k2172 in k2091 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in k1517 in k1513 in k1509 in k1503 in k1491 in k1487 in k1483 in k1479 in k1475 in ... */
static void C_ccall f_2174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate2(&lf[76] /* (set! translate-options ...) */,t1);
t3=lf[93] /* static */ =C_SCHEME_TRUE;;
/* csc.scm:808: loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1852(t4,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}

/* k5162 in k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f_5164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5164,2,t0,t1);}
t2=C_eqp(t1,lf[2]);
t3=C_mutate2(&lf[3] /* (set! osx ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5160,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:71: build-platform */
t5=C_fast_retrieve(lf[359]);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k5166 in k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 */
static void C_ccall f_5168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5168,2,t0,t1);}
t2=C_eqp(t1,lf[0]);
t3=C_mutate2(&lf[1] /* (set! mingw ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5164,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:70: software-version */
t5=C_fast_retrieve(lf[234]);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* map-loop490 in k3582 in k3574 in k3566 in k3535 in k3532 in for-each-loop469 in k2013 in k2010 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in ... */
static void C_fcall f_3592(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3592,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3621,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* csc.scm:837: g496 */
t5=((C_word*)t0)[5];
((C_proc3)C_fast_retrieve_proc(t5))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3588 in k3582 in k3574 in k3566 in k3535 in k3532 in for-each-loop469 in k2013 in k2010 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in ... */
static void C_ccall f_3590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:830: append */
t2=*((C_word*)lf[100]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k4160 in k4020 in k4017 in k4014 in k1886 in k1880 in k1874 in k1871 in k1868 in k1865 in k1861 in loop in k4861 in k1592 in k1584 in k1576 in k4976 in k4990 in k1561 in k1557 in k1527 in k1522 in ... */
static void C_ccall f_4162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:927: string-intersperse */
t2=C_fast_retrieve(lf[99]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[453] = {
{"f_1700:csc_2escm",(void*)f_1700},
{"f_4178:csc_2escm",(void*)f_4178},
{"f_4170:csc_2escm",(void*)f_4170},
{"f_2108:csc_2escm",(void*)f_2108},
{"f_3576:csc_2escm",(void*)f_3576},
{"f_3572:csc_2escm",(void*)f_3572},
{"f_2136:csc_2escm",(void*)f_2136},
{"f_3584:csc_2escm",(void*)f_3584},
{"f_4982:csc_2escm",(void*)f_4982},
{"f_2120:csc_2escm",(void*)f_2120},
{"f_2127:csc_2escm",(void*)f_2127},
{"f_4475:csc_2escm",(void*)f_4475},
{"f_1739:csc_2escm",(void*)f_1739},
{"f_4992:csc_2escm",(void*)f_4992},
{"f_4996:csc_2escm",(void*)f_4996},
{"f_4488:csc_2escm",(void*)f_4488},
{"f_1746:csc_2escm",(void*)f_1746},
{"f_4968:csc_2escm",(void*)f_4968},
{"f_4964:csc_2escm",(void*)f_4964},
{"f6337:csc_2escm",(void*)f6337},
{"f_1716:csc_2escm",(void*)f_1716},
{"f_4186:csc_2escm",(void*)f_4186},
{"f_4978:csc_2escm",(void*)f_4978},
{"f_4182:csc_2escm",(void*)f_4182},
{"f_3177:csc_2escm",(void*)f_3177},
{"f_4468:csc_2escm",(void*)f_4468},
{"f_1723:csc_2escm",(void*)f_1723},
{"f_4195:csc_2escm",(void*)f_4195},
{"f_4198:csc_2escm",(void*)f_4198},
{"f_4460:csc_2escm",(void*)f_4460},
{"f_4191:csc_2escm",(void*)f_4191},
{"f_2989:csc_2escm",(void*)f_2989},
{"f_4953:csc_2escm",(void*)f_4953},
{"f_1779:csc_2escm",(void*)f_1779},
{"f_2805:csc_2escm",(void*)f_2805},
{"f_2537:csc_2escm",(void*)f_2537},
{"f_2809:csc_2escm",(void*)f_2809},
{"f_1784:csc_2escm",(void*)f_1784},
{"f_1786:csc_2escm",(void*)f_1786},
{"f_4498:csc_2escm",(void*)f_4498},
{"f_4490:csc_2escm",(void*)f_4490},
{"f_4245:csc_2escm",(void*)f_4245},
{"f_2557:csc_2escm",(void*)f_2557},
{"f_4248:csc_2escm",(void*)f_4248},
{"f_2956:csc_2escm",(void*)f_2956},
{"f_4255:csc_2escm",(void*)f_4255},
{"f_2547:csc_2escm",(void*)f_2547},
{"f_2817:csc_2escm",(void*)f_2817},
{"f_3182:csc_2escm",(void*)f_3182},
{"f_3188:csc_2escm",(void*)f_3188},
{"f_2946:csc_2escm",(void*)f_2946},
{"f6332:csc_2escm",(void*)f6332},
{"f_3199:csc_2escm",(void*)f_3199},
{"f_4202:csc_2escm",(void*)f_4202},
{"f_4206:csc_2escm",(void*)f_4206},
{"f_3753:csc_2escm",(void*)f_3753},
{"f_4212:csc_2escm",(void*)f_4212},
{"f_4215:csc_2escm",(void*)f_4215},
{"f_3047:csc_2escm",(void*)f_3047},
{"f_3765:csc_2escm",(void*)f_3765},
{"f_3769:csc_2escm",(void*)f_3769},
{"f_3768:csc_2escm",(void*)f_3768},
{"f_2907:csc_2escm",(void*)f_2907},
{"f_3043:csc_2escm",(void*)f_3043},
{"f_2900:csc_2escm",(void*)f_2900},
{"f_3730:csc_2escm",(void*)f_3730},
{"f_3734:csc_2escm",(void*)f_3734},
{"f_3738:csc_2escm",(void*)f_3738},
{"f_2937:csc_2escm",(void*)f_2937},
{"f5981:csc_2escm",(void*)f5981},
{"f_3742:csc_2escm",(void*)f_3742},
{"f_4588:csc_2escm",(void*)f_4588},
{"f_4580:csc_2escm",(void*)f_4580},
{"f5971:csc_2escm",(void*)f5971},
{"f5976:csc_2escm",(void*)f5976},
{"f_1469:csc_2escm",(void*)f_1469},
{"f_3681:csc_2escm",(void*)f_3681},
{"f_3033:csc_2escm",(void*)f_3033},
{"f_4595:csc_2escm",(void*)f_4595},
{"f5961:csc_2escm",(void*)f5961},
{"f_1403:csc_2escm",(void*)f_1403},
{"f_1400:csc_2escm",(void*)f_1400},
{"f5966:csc_2escm",(void*)f5966},
{"f_4939:csc_2escm",(void*)f_4939},
{"f_4791:csc_2escm",(void*)f_4791},
{"f_3696:csc_2escm",(void*)f_3696},
{"f_3003:csc_2escm",(void*)f_3003},
{"f_1416:csc_2escm",(void*)f_1416},
{"f_1413:csc_2escm",(void*)f_1413},
{"f_4225:csc_2escm",(void*)f_4225},
{"f_1410:csc_2escm",(void*)f_1410},
{"f_4905:csc_2escm",(void*)f_4905},
{"f_4573:csc_2escm",(void*)f_4573},
{"f_1426:csc_2escm",(void*)f_1426},
{"f_4235:csc_2escm",(void*)f_4235},
{"f_4775:csc_2escm",(void*)f_4775},
{"f_4778:csc_2escm",(void*)f_4778},
{"f_4772:csc_2escm",(void*)f_4772},
{"f_2049:csc_2escm",(void*)f_2049},
{"f_1419:csc_2escm",(void*)f_1419},
{"f_4910:csc_2escm",(void*)f_4910},
{"f_4783:csc_2escm",(void*)f_4783},
{"f_2075:csc_2escm",(void*)f_2075},
{"f_2022:csc_2escm",(void*)f_2022},
{"f_2052:csc_2escm",(void*)f_2052},
{"f_2058:csc_2escm",(void*)f_2058},
{"f_2055:csc_2escm",(void*)f_2055},
{"f_2082:csc_2escm",(void*)f_2082},
{"f_2086:csc_2escm",(void*)f_2086},
{"f_3671:csc_2escm",(void*)f_3671},
{"f_2887:csc_2escm",(void*)f_2887},
{"f_1473:csc_2escm",(void*)f_1473},
{"f_4271:csc_2escm",(void*)f_4271},
{"f_4267:csc_2escm",(void*)f_4267},
{"f_4264:csc_2escm",(void*)f_4264},
{"f_1481:csc_2escm",(void*)f_1481},
{"f_3264:csc_2escm",(void*)f_3264},
{"f_2378:csc_2escm",(void*)f_2378},
{"f_4718:csc_2escm",(void*)f_4718},
{"f_2068:csc_2escm",(void*)f_2068},
{"f_2766:csc_2escm",(void*)f_2766},
{"f_1477:csc_2escm",(void*)f_1477},
{"f_2866:csc_2escm",(void*)f_2866},
{"f_2869:csc_2escm",(void*)f_2869},
{"f_4275:csc_2escm",(void*)f_4275},
{"f_3089:csc_2escm",(void*)f_3089},
{"f_4279:csc_2escm",(void*)f_4279},
{"f_3087:csc_2escm",(void*)f_3087},
{"f_3276:csc_2escm",(void*)f_3276},
{"f_1493:csc_2escm",(void*)f_1493},
{"f_4727:csc_2escm",(void*)f_4727},
{"f_2093:csc_2escm",(void*)f_2093},
{"f_4724:csc_2escm",(void*)f_4724},
{"f_2096:csc_2escm",(void*)f_2096},
{"f_2753:csc_2escm",(void*)f_2753},
{"f_1489:csc_2escm",(void*)f_1489},
{"f_1485:csc_2escm",(void*)f_1485},
{"toplevel:csc_2escm",(void*)C_toplevel},
{"f_2897:csc_2escm",(void*)f_2897},
{"f_2894:csc_2escm",(void*)f_2894},
{"f_3280:csc_2escm",(void*)f_3280},
{"f_3288:csc_2escm",(void*)f_3288},
{"f_2012:csc_2escm",(void*)f_2012},
{"f_2015:csc_2escm",(void*)f_2015},
{"f_3020:csc_2escm",(void*)f_3020},
{"f_2385:csc_2escm",(void*)f_2385},
{"f_2382:csc_2escm",(void*)f_2382},
{"f_3297:csc_2escm",(void*)f_3297},
{"f_3070:csc_2escm",(void*)f_3070},
{"f_4291:csc_2escm",(void*)f_4291},
{"f_4031:csc_2escm",(void*)f_4031},
{"f_4285:csc_2escm",(void*)f_4285},
{"f_4288:csc_2escm",(void*)f_4288},
{"f_4261:csc_2escm",(void*)f_4261},
{"f_4042:csc_2escm",(void*)f_4042},
{"f_4295:csc_2escm",(void*)f_4295},
{"f_4299:csc_2escm",(void*)f_4299},
{"f_3303:csc_2escm",(void*)f_3303},
{"f_4016:csc_2escm",(void*)f_4016},
{"f_4019:csc_2escm",(void*)f_4019},
{"f_4022:csc_2escm",(void*)f_4022},
{"f_4025:csc_2escm",(void*)f_4025},
{"f_4028:csc_2escm",(void*)f_4028},
{"f_5008:csc_2escm",(void*)f_5008},
{"f_3335:csc_2escm",(void*)f_3335},
{"f_4086:csc_2escm",(void*)f_4086},
{"f_4082:csc_2escm",(void*)f_4082},
{"f_4356:csc_2escm",(void*)f_4356},
{"f5903:csc_2escm",(void*)f5903},
{"f_5035:csc_2escm",(void*)f_5035},
{"f_5049:csc_2escm",(void*)f_5049},
{"f_4336:csc_2escm",(void*)f_4336},
{"f_4330:csc_2escm",(void*)f_4330},
{"f_4757:csc_2escm",(void*)f_4757},
{"f_4754:csc_2escm",(void*)f_4754},
{"f_5039:csc_2escm",(void*)f_5039},
{"f_4301:csc_2escm",(void*)f_4301},
{"f_4766:csc_2escm",(void*)f_4766},
{"f_4769:csc_2escm",(void*)f_4769},
{"f_4763:csc_2escm",(void*)f_4763},
{"f_4760:csc_2escm",(void*)f_4760},
{"f_4736:csc_2escm",(void*)f_4736},
{"f_5004:csc_2escm",(void*)f_5004},
{"f_5000:csc_2escm",(void*)f_5000},
{"f5946:csc_2escm",(void*)f5946},
{"f_4730:csc_2escm",(void*)f_4730},
{"f_4733:csc_2escm",(void*)f_4733},
{"f5931:csc_2escm",(void*)f5931},
{"f_4744:csc_2escm",(void*)f_4744},
{"f_4748:csc_2escm",(void*)f_4748},
{"f_1609:csc_2escm",(void*)f_1609},
{"f_5076:csc_2escm",(void*)f_5076},
{"f_4740:csc_2escm",(void*)f_4740},
{"f_1605:csc_2escm",(void*)f_1605},
{"f_2270:csc_2escm",(void*)f_2270},
{"f5920:csc_2escm",(void*)f5920},
{"f_2273:csc_2escm",(void*)f_2273},
{"f_5062:csc_2escm",(void*)f_5062},
{"f5925:csc_2escm",(void*)f5925},
{"f_1943:csc_2escm",(void*)f_1943},
{"f_1940:csc_2escm",(void*)f_1940},
{"f_3996:csc_2escm",(void*)f_3996},
{"f_4344:csc_2escm",(void*)f_4344},
{"f_4568:csc_2escm",(void*)f_4568},
{"f_1613:csc_2escm",(void*)f_1613},
{"f_1616:csc_2escm",(void*)f_1616},
{"f_1947:csc_2escm",(void*)f_1947},
{"f_5069:csc_2escm",(void*)f_5069},
{"f_5106:csc_2escm",(void*)f_5106},
{"f_1951:csc_2escm",(void*)f_1951},
{"f_1430:csc_2escm",(void*)f_1430},
{"f_1434:csc_2escm",(void*)f_1434},
{"f_1626:csc_2escm",(void*)f_1626},
{"f_1955:csc_2escm",(void*)f_1955},
{"f_1922:csc_2escm",(void*)f_1922},
{"f_4545:csc_2escm",(void*)f_4545},
{"f_1631:csc_2escm",(void*)f_1631},
{"f_1928:csc_2escm",(void*)f_1928},
{"f_2247:csc_2escm",(void*)f_2247},
{"f_4543:csc_2escm",(void*)f_4543},
{"f_1457:csc_2escm",(void*)f_1457},
{"f_3860:csc_2escm",(void*)f_3860},
{"f_3951:csc_2escm",(void*)f_3951},
{"f_4525:csc_2escm",(void*)f_4525},
{"f_1465:csc_2escm",(void*)f_1465},
{"f_3959:csc_2escm",(void*)f_3959},
{"f5951:csc_2escm",(void*)f5951},
{"f_5142:csc_2escm",(void*)f_5142},
{"f_5096:csc_2escm",(void*)f_5096},
{"f_2235:csc_2escm",(void*)f_2235},
{"f5956:csc_2escm",(void*)f5956},
{"f_5146:csc_2escm",(void*)f_5146},
{"f_4535:csc_2escm",(void*)f_4535},
{"f_3837:csc_2escm",(void*)f_3837},
{"f_4539:csc_2escm",(void*)f_4539},
{"f_5134:csc_2escm",(void*)f_5134},
{"f_5130:csc_2escm",(void*)f_5130},
{"f_1677:csc_2escm",(void*)f_1677},
{"f_2223:csc_2escm",(void*)f_2223},
{"f_5086:csc_2escm",(void*)f_5086},
{"f_5138:csc_2escm",(void*)f_5138},
{"f_3806:csc_2escm",(void*)f_3806},
{"f_3800:csc_2escm",(void*)f_3800},
{"f_2285:csc_2escm",(void*)f_2285},
{"f_4502:csc_2escm",(void*)f_4502},
{"f_2975:csc_2escm",(void*)f_2975},
{"f_1689:csc_2escm",(void*)f_1689},
{"f_1685:csc_2escm",(void*)f_1685},
{"f_2211:csc_2escm",(void*)f_2211},
{"f_5126:csc_2escm",(void*)f_5126},
{"f_3850:csc_2escm",(void*)f_3850},
{"f_2965:csc_2escm",(void*)f_2965},
{"f_3560:csc_2escm",(void*)f_3560},
{"f_5116:csc_2escm",(void*)f_5116},
{"f_3564:csc_2escm",(void*)f_3564},
{"f_3568:csc_2escm",(void*)f_3568},
{"f_1693:csc_2escm",(void*)f_1693},
{"f_3827:csc_2escm",(void*)f_3827},
{"f_4606:csc_2escm",(void*)f_4606},
{"f_3537:csc_2escm",(void*)f_3537},
{"f_3534:csc_2escm",(void*)f_3534},
{"f_3540:csc_2escm",(void*)f_3540},
{"f_3544:csc_2escm",(void*)f_3544},
{"f_3548:csc_2escm",(void*)f_3548},
{"f_1931:csc_2escm",(void*)f_1931},
{"f_1934:csc_2escm",(void*)f_1934},
{"f_1937:csc_2escm",(void*)f_1937},
{"f_5156:csc_2escm",(void*)f_5156},
{"f_1900:csc_2escm",(void*)f_1900},
{"f_1903:csc_2escm",(void*)f_1903},
{"f_1909:csc_2escm",(void*)f_1909},
{"f_1906:csc_2escm",(void*)f_1906},
{"f_3150:csc_2escm",(void*)f_3150},
{"f_1915:csc_2escm",(void*)f_1915},
{"f_1912:csc_2escm",(void*)f_1912},
{"f_4699:csc_2escm",(void*)f_4699},
{"f_4695:csc_2escm",(void*)f_4695},
{"f_4693:csc_2escm",(void*)f_4693},
{"f_3129:csc_2escm",(void*)f_3129},
{"f_1373:csc_2escm",(void*)f_1373},
{"f_1376:csc_2escm",(void*)f_1376},
{"f_1370:csc_2escm",(void*)f_1370},
{"f_1379:csc_2escm",(void*)f_1379},
{"f_4679:csc_2escm",(void*)f_4679},
{"f_4895:csc_2escm",(void*)f_4895},
{"f_4892:csc_2escm",(void*)f_4892},
{"f_1355:csc_2escm",(void*)f_1355},
{"f_1352:csc_2escm",(void*)f_1352},
{"f_3118:csc_2escm",(void*)f_3118},
{"f_1358:csc_2escm",(void*)f_1358},
{"f_1364:csc_2escm",(void*)f_1364},
{"f_1361:csc_2escm",(void*)f_1361},
{"f_4878:csc_2escm",(void*)f_4878},
{"f_4871:csc_2escm",(void*)f_4871},
{"f_1367:csc_2escm",(void*)f_1367},
{"f_4888:csc_2escm",(void*)f_4888},
{"f_2567:csc_2escm",(void*)f_2567},
{"f_4052:csc_2escm",(void*)f_4052},
{"f_4069:csc_2escm",(void*)f_4069},
{"f_4066:csc_2escm",(void*)f_4066},
{"f_2517:csc_2escm",(void*)f_2517},
{"f_1660:csc_2escm",(void*)f_1660},
{"f_4397:csc_2escm",(void*)f_4397},
{"f_1888:csc_2escm",(void*)f_1888},
{"f_4390:csc_2escm",(void*)f_4390},
{"f_2527:csc_2escm",(void*)f_2527},
{"f_2441:csc_2escm",(void*)f_2441},
{"f_2445:csc_2escm",(void*)f_2445},
{"f_3133:csc_2escm",(void*)f_3133},
{"f_4816:csc_2escm",(void*)f_4816},
{"f_4362:csc_2escm",(void*)f_4362},
{"f_2437:csc_2escm",(void*)f_2437},
{"f_1515:csc_2escm",(void*)f_1515},
{"f_1511:csc_2escm",(void*)f_1511},
{"f_1519:csc_2escm",(void*)f_1519},
{"f_4827:csc_2escm",(void*)f_4827},
{"f_4822:csc_2escm",(void*)f_4822},
{"f_3642:csc_2escm",(void*)f_3642},
{"f_1524:csc_2escm",(void*)f_1524},
{"f_1529:csc_2escm",(void*)f_1529},
{"f_2577:csc_2escm",(void*)f_2577},
{"f_1852:csc_2escm",(void*)f_1852},
{"f_4809:csc_2escm",(void*)f_4809},
{"f_1505:csc_2escm",(void*)f_1505},
{"f_4661:csc_2escm",(void*)f_4661},
{"f_2597:csc_2escm",(void*)f_2597},
{"f_2469:csc_2escm",(void*)f_2469},
{"f_4655:csc_2escm",(void*)f_4655},
{"f_4658:csc_2escm",(void*)f_4658},
{"f_1559:csc_2escm",(void*)f_1559},
{"f_2706:csc_2escm",(void*)f_2706},
{"f_4632:csc_2escm",(void*)f_4632},
{"f5846:csc_2escm",(void*)f5846},
{"f_2587:csc_2escm",(void*)f_2587},
{"f_4146:csc_2escm",(void*)f_4146},
{"f_4664:csc_2escm",(void*)f_4664},
{"f_1563:csc_2escm",(void*)f_1563},
{"f_3245:csc_2escm",(void*)f_3245},
{"f_3240:csc_2escm",(void*)f_3240},
{"f5836:csc_2escm",(void*)f5836},
{"f_4158:csc_2escm",(void*)f_4158},
{"f_4635:csc_2escm",(void*)f_4635},
{"f_4638:csc_2escm",(void*)f_4638},
{"f5814:csc_2escm",(void*)f5814},
{"f_2727:csc_2escm",(void*)f_2727},
{"f_1812:csc_2escm",(void*)f_1812},
{"f_3796:csc_2escm",(void*)f_3796},
{"f_2710:csc_2escm",(void*)f_2710},
{"f_1821:csc_2escm",(void*)f_1821},
{"f_3621:csc_2escm",(void*)f_3621},
{"f5819:csc_2escm",(void*)f5819},
{"f_1817:csc_2escm",(void*)f_1817},
{"f_4401:csc_2escm",(void*)f_4401},
{"f_4618:csc_2escm",(void*)f_4618},
{"f_1594:csc_2escm",(void*)f_1594},
{"f_2496:csc_2escm",(void*)f_2496},
{"f5871:csc_2escm",(void*)f5871},
{"f5888:csc_2escm",(void*)f5888},
{"f_4102:csc_2escm",(void*)f_4102},
{"f_4105:csc_2escm",(void*)f_4105},
{"f_3776:csc_2escm",(void*)f_3776},
{"f_3773:csc_2escm",(void*)f_3773},
{"f_4629:csc_2escm",(void*)f_4629},
{"f_2731:csc_2escm",(void*)f_2731},
{"f5866:csc_2escm",(void*)f5866},
{"f_4601:csc_2escm",(void*)f_4601},
{"f_2739:csc_2escm",(void*)f_2739},
{"f5861:csc_2escm",(void*)f5861},
{"f5878:csc_2escm",(void*)f5878},
{"f_2480:csc_2escm",(void*)f_2480},
{"f_1835:csc_2escm",(void*)f_1835},
{"f_3788:csc_2escm",(void*)f_3788},
{"f5856:csc_2escm",(void*)f5856},
{"f_3213:csc_2escm",(void*)f_3213},
{"f5851:csc_2escm",(void*)f5851},
{"f_1578:csc_2escm",(void*)f_1578},
{"f_4437:csc_2escm",(void*)f_4437},
{"f_4431:csc_2escm",(void*)f_4431},
{"f_4434:csc_2escm",(void*)f_4434},
{"f5841:csc_2escm",(void*)f5841},
{"f_1586:csc_2escm",(void*)f_1586},
{"f_4446:csc_2escm",(void*)f_4446},
{"f_4443:csc_2escm",(void*)f_4443},
{"f_4440:csc_2escm",(void*)f_4440},
{"f_4415:csc_2escm",(void*)f_4415},
{"f_4417:csc_2escm",(void*)f_4417},
{"f_4856:csc_2escm",(void*)f_4856},
{"f_4859:csc_2escm",(void*)f_4859},
{"f_2778:csc_2escm",(void*)f_2778},
{"f_2770:csc_2escm",(void*)f_2770},
{"f_4853:csc_2escm",(void*)f_4853},
{"f_4425:csc_2escm",(void*)f_4425},
{"f_4867:csc_2escm",(void*)f_4867},
{"f_3938:csc_2escm",(void*)f_3938},
{"f_4863:csc_2escm",(void*)f_4863},
{"f5893:csc_2escm",(void*)f5893},
{"f_4129:csc_2escm",(void*)f_4129},
{"f_4125:csc_2escm",(void*)f_4125},
{"f_4835:csc_2escm",(void*)f_4835},
{"f_4121:csc_2escm",(void*)f_4121},
{"f_3901:csc_2escm",(void*)f_3901},
{"f_3718:csc_2escm",(void*)f_3718},
{"f_3907:csc_2escm",(void*)f_3907},
{"f_3904:csc_2escm",(void*)f_3904},
{"f_2791:csc_2escm",(void*)f_2791},
{"f5883:csc_2escm",(void*)f5883},
{"f5898:csc_2escm",(void*)f5898},
{"f6342:csc_2escm",(void*)f6342},
{"f_4136:csc_2escm",(void*)f_4136},
{"f_4133:csc_2escm",(void*)f_4133},
{"f_3919:csc_2escm",(void*)f_3919},
{"f_4454:csc_2escm",(void*)f_4454},
{"f_4450:csc_2escm",(void*)f_4450},
{"f_3965:csc_2escm",(void*)f_3965},
{"f_3967:csc_2escm",(void*)f_3967},
{"f_3703:csc_2escm",(void*)f_3703},
{"f_3706:csc_2escm",(void*)f_3706},
{"f_3700:csc_2escm",(void*)f_3700},
{"f_3227:csc_2escm",(void*)f_3227},
{"f_1863:csc_2escm",(void*)f_1863},
{"f_1867:csc_2escm",(void*)f_1867},
{"f_1870:csc_2escm",(void*)f_1870},
{"f_1873:csc_2escm",(void*)f_1873},
{"f_1876:csc_2escm",(void*)f_1876},
{"f_3926:csc_2escm",(void*)f_3926},
{"f_3928:csc_2escm",(void*)f_3928},
{"f_1882:csc_2escm",(void*)f_1882},
{"f_1974:csc_2escm",(void*)f_1974},
{"f_1977:csc_2escm",(void*)f_1977},
{"f_2655:csc_2escm",(void*)f_2655},
{"f_2638:csc_2escm",(void*)f_2638},
{"f_2614:csc_2escm",(void*)f_2614},
{"f_1984:csc_2escm",(void*)f_1984},
{"f_3810:csc_2escm",(void*)f_3810},
{"f_2689:csc_2escm",(void*)f_2689},
{"f_3819:csc_2escm",(void*)f_3819},
{"f_2672:csc_2escm",(void*)f_2672},
{"f_2185:csc_2escm",(void*)f_2185},
{"f_3887:csc_2escm",(void*)f_3887},
{"f_2846:csc_2escm",(void*)f_2846},
{"f_2849:csc_2escm",(void*)f_2849},
{"f_2143:csc_2escm",(void*)f_2143},
{"f_3875:csc_2escm",(void*)f_3875},
{"f_3877:csc_2escm",(void*)f_3877},
{"f_2821:csc_2escm",(void*)f_2821},
{"f_5160:csc_2escm",(void*)f_5160},
{"f_2174:csc_2escm",(void*)f_2174},
{"f_5164:csc_2escm",(void*)f_5164},
{"f_5168:csc_2escm",(void*)f_5168},
{"f_3592:csc_2escm",(void*)f_3592},
{"f_3590:csc_2escm",(void*)f_3590},
{"f_4162:csc_2escm",(void*)f_4162},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  for-each		6
S|  sprintf		5
S|  printf		2
S|  map		6
S|  fprintf		1
o|eliminated procedure checks: 98 
o|specializations:
o|  2 (zero? fixnum)
o|  1 (= fixnum fixnum)
o|  6 (string-ref string fixnum)
o|  4 (string=? string string)
o|  4 (> fixnum fixnum)
o|  4 (string-length string)
o|  67 (eqv? (not float) *)
o|  4 (cdr pair)
o|  2 (##sys#check-list (or pair list) *)
o|  8 (string-append string string)
o|  8 (##sys#check-output-port * * *)
o|  1 (current-error-port)
o|  4 (memq * list)
o|Removed `not' forms: 5 
o|substituted constant variable: a1401 
o|merged explicitly consed rest parameter: args7 
o|propagated global variable: out812 ##sys#standard-error 
o|substituted constant variable: a1406 
o|substituted constant variable: a1407 
o|inlining procedure: k1446 
o|inlining procedure: k1446 
o|substituted constant variable: default-translation-optimization-options 
o|inlining procedure: k3969 
o|inlining procedure: k3969 
o|inlining procedure: k4002 
o|inlining procedure: k4002 
o|substituted constant variable: nonstatic-compilation-options 
o|propagated global variable: r40035175 nonstatic-compilation-options 
o|propagated global variable: tmp637639 static 
o|propagated global variable: tmp637639 static 
o|inlining procedure: k4342 
o|inlining procedure: k4342 
o|substituted constant variable: a4427 
o|substituted constant variable: a4428 
o|inlining procedure: k4456 
o|inlining procedure: k4456 
o|inlining procedure: k4470 
o|inlining procedure: k4470 
o|contracted procedure: k4479 
o|propagated global variable: r4480 mingw 
o|inlining procedure: k4476 
o|inlining procedure: k4476 
o|inlining procedure: k4504 
o|inlining procedure: k4504 
o|propagated global variable: tmp791793 static 
o|propagated global variable: tmp791793 static 
o|propagated global variable: tmp788790 static 
o|inlining procedure: k4516 
o|propagated global variable: tmp788790 static 
o|inlining procedure: k4516 
o|propagated global variable: r45175196 static-libs 
o|inlining procedure: k4590 
o|inlining procedure: k4590 
o|contracted procedure: "(csc.scm:1038) cleanup" 
o|inlining procedure: k4526 
o|inlining procedure: k4526 
o|inlining procedure: k4547 
o|inlining procedure: k4547 
o|inlining procedure: k4611 
o|inlining procedure: k4611 
o|inlining procedure: k4681 
o|inlining procedure: k4681 
o|contracted procedure: "(csc.scm:1056) $system" 
o|inlining procedure: k4640 
o|inlining procedure: k4640 
o|propagated global variable: out835839 ##sys#standard-output 
o|substituted constant variable: a4651 
o|substituted constant variable: a4652 
o|propagated global variable: out835839 ##sys#standard-output 
o|inlining procedure: k4700 
o|inlining procedure: k4700 
o|contracted procedure: "(csc.scm:1130) run" 
o|merged explicitly consed rest parameter: os212 
o|merged explicitly consed rest parameter: n215 
o|inlining procedure: k1788 
o|inlining procedure: k1788 
o|consed rest parameter at call site: "(csc.scm:517) stop" 2 
o|inlining procedure: k1802 
o|inlining procedure: k1802 
o|inlining procedure: k1828 
o|inlining procedure: k1828 
o|inlining procedure: k1841 
o|inlining procedure: k1841 
o|inlining procedure: k1854 
o|inlining procedure: k1883 
o|inlining procedure: k1883 
o|contracted procedure: "(csc.scm:579) run-linking" 
o|inlining procedure: k4032 
o|inlining procedure: k4032 
o|inlining procedure: k4044 
o|inlining procedure: k4044 
o|propagated global variable: g736738 generated-object-files 
o|inlining procedure: k4070 
o|contracted procedure: "(csc.scm:956) create-mac-bundle" 
o|inlining procedure: k4770 
o|inlining procedure: k4770 
o|inlining procedure: k4070 
o|contracted procedure: "(csc.scm:951) copy-libraries" 
o|inlining procedure: k4399 
o|inlining procedure: k4399 
o|substituted constant variable: a4411 
o|contracted procedure: "(csc.scm:979) target-lib-path" 
o|inlining procedure: k4357 
o|inlining procedure: k4357 
o|contracted procedure: k4372 
o|inlining procedure: k4375 
o|inlining procedure: k4375 
o|propagated global variable: tmp721723 static 
o|inlining procedure: k4097 
o|propagated global variable: tmp721723 static 
o|inlining procedure: k4097 
o|propagated global variable: r40985250 static-libs 
o|inlining procedure: k4106 
o|contracted procedure: "(csc.scm:949) rez" 
o|substituted constant variable: a4720 
o|substituted constant variable: a4721 
o|inlining procedure: k4106 
o|inlining procedure: k4134 
o|inlining procedure: k4134 
o|substituted constant variable: a4148 
o|inlining procedure: k4152 
o|inlining procedure: k4152 
o|propagated global variable: r41535259 host-mode 
o|substituted constant variable: link-output-flag 
o|inlining procedure: k4207 
o|inlining procedure: k4207 
o|inlining procedure: k4223 
o|inlining procedure: k4223 
o|substituted constant variable: a4257 
o|substituted constant variable: a4258 
o|substituted constant variable: a4281 
o|substituted constant variable: a4282 
o|inlining procedure: k4303 
o|inlining procedure: k4303 
o|propagated global variable: g663667 object-files 
o|propagated global variable: out249253 ##sys#standard-output 
o|substituted constant variable: a1896 
o|substituted constant variable: a1897 
o|substituted constant variable: a1924 
o|substituted constant variable: a1925 
o|inlining procedure: k1957 
o|inlining procedure: k1957 
o|propagated global variable: out249253 ##sys#standard-output 
o|contracted procedure: "(csc.scm:568) run-compilation" 
o|substituted constant variable: compile-only-flag 
o|inlining procedure: k3743 
o|inlining procedure: k3743 
o|substituted constant variable: compile-output-flag 
o|consed rest parameter at call site: "(csc.scm:859) stop" 2 
o|inlining procedure: k3811 
o|inlining procedure: k3811 
o|inlining procedure: k3829 
o|inlining procedure: k3829 
o|propagated global variable: g604606 generated-rc-files 
o|inlining procedure: k3852 
o|inlining procedure: k3852 
o|propagated global variable: g587589 generated-c-files 
o|inlining procedure: k3879 
o|inlining procedure: k3879 
o|propagated global variable: g566568 rc-files 
o|contracted procedure: "(csc.scm:877) create-win-manifest" 
o|inlining procedure: k3930 
o|inlining procedure: k3930 
o|propagated global variable: g536538 c-files 
o|inlining procedure: k1978 
o|inlining procedure: k1978 
o|inlining procedure: k1992 
o|propagated global variable: r19935286 object-files 
o|inlining procedure: k1992 
o|propagated global variable: r19935288 c-files 
o|consed rest parameter at call site: "(csc.scm:549) stop" 2 
o|contracted procedure: "(csc.scm:564) run-translation" 
o|inlining procedure: k3673 
o|contracted procedure: "(csc.scm:813) g470477" 
o|inlining procedure: k3594 
o|inlining procedure: k3594 
o|inlining procedure: k3627 
o|inlining procedure: k3627 
o|consed rest parameter at call site: "(csc.scm:825) stop" 2 
o|inlining procedure: k3650 
o|inlining procedure: k3650 
o|substituted constant variable: a3659 
o|inlining procedure: k3673 
o|propagated global variable: g476478 scheme-files 
o|inlining procedure: k2020 
o|inlining procedure: k2020 
o|contracted procedure: "(csc.scm:538) builtin-link-options" 
o|inlining procedure: k1614 
o|contracted procedure: "(csc.scm:281) g157158" 
o|inlining procedure: k1633 
o|contracted procedure: "(csc.scm:282) g168177" 
o|inlining procedure: k1633 
o|inlining procedure: k1614 
o|substituted constant variable: a1678 
o|inlining procedure: k1691 
o|inlining procedure: k1691 
o|inlining procedure: k1698 
o|inlining procedure: k1698 
o|inlining procedure: k1707 
o|inlining procedure: k1707 
o|inlining procedure: k1854 
o|contracted procedure: "(csc.scm:586) usage" 
o|inlining procedure: k2112 
o|inlining procedure: k2112 
o|inlining procedure: k2144 
o|inlining procedure: k2144 
o|inlining procedure: k2165 
o|inlining procedure: k2165 
o|inlining procedure: k2187 
o|inlining procedure: k2187 
o|inlining procedure: k2203 
o|inlining procedure: k2203 
o|inlining procedure: k2227 
o|inlining procedure: k2227 
o|inlining procedure: k2251 
o|inlining procedure: k2251 
o|inlining procedure: k2274 
o|inlining procedure: k2274 
o|consed rest parameter at call site: "(csc.scm:624) t-options208" 1 
o|inlining procedure: k2290 
o|consed rest parameter at call site: "(csc.scm:630) t-options208" 1 
o|inlining procedure: k2290 
o|consed rest parameter at call site: "(csc.scm:633) t-options208" 1 
o|inlining procedure: k2319 
o|consed rest parameter at call site: "(csc.scm:636) t-options208" 1 
o|inlining procedure: k2319 
o|inlining procedure: k2339 
o|inlining procedure: k2339 
o|inlining procedure: k2353 
o|inlining procedure: k2353 
o|consed rest parameter at call site: "(csc.scm:646) t-options208" 1 
o|consed rest parameter at call site: "(csc.scm:644) check209" 3 
o|inlining procedure: k2400 
o|inlining procedure: k2400 
o|inlining procedure: k2416 
o|inlining procedure: k2416 
o|inlining procedure: k2454 
o|inlining procedure: k2454 
o|consed rest parameter at call site: "(csc.scm:670) check209" 3 
o|inlining procedure: k2485 
o|consed rest parameter at call site: "(csc.scm:675) check209" 3 
o|inlining procedure: k2485 
o|inlining procedure: k2518 
o|inlining procedure: k2518 
o|inlining procedure: k2538 
o|inlining procedure: k2538 
o|inlining procedure: k2558 
o|inlining procedure: k2558 
o|inlining procedure: k2578 
o|inlining procedure: k2578 
o|inlining procedure: k2598 
o|inlining procedure: k2598 
o|inlining procedure: k2618 
o|inlining procedure: k2618 
o|consed rest parameter at call site: "(csc.scm:697) check209" 3 
o|inlining procedure: k2647 
o|consed rest parameter at call site: "(csc.scm:701) check209" 3 
o|inlining procedure: k2647 
o|consed rest parameter at call site: "(csc.scm:705) check209" 3 
o|inlining procedure: k2681 
o|consed rest parameter at call site: "(csc.scm:709) check209" 3 
o|inlining procedure: k2681 
o|consed rest parameter at call site: "(csc.scm:713) check209" 3 
o|inlining procedure: k2719 
o|consed rest parameter at call site: "(csc.scm:716) check209" 3 
o|inlining procedure: k2719 
o|inlining procedure: k2758 
o|consed rest parameter at call site: "(csc.scm:722) check209" 3 
o|inlining procedure: k2758 
o|substituted constant variable: a2822 
o|contracted procedure: k2826 
o|propagated global variable: r2827 mingw 
o|inlining procedure: k2823 
o|inlining procedure: k2823 
o|consed rest parameter at call site: "(csc.scm:726) check209" 3 
o|inlining procedure: k2832 
o|inlining procedure: k2832 
o|consed rest parameter at call site: "(csc.scm:735) t-options208" 1 
o|consed rest parameter at call site: "(csc.scm:734) check209" 3 
o|inlining procedure: k2858 
o|consed rest parameter at call site: "(csc.scm:739) t-options208" 1 
o|consed rest parameter at call site: "(csc.scm:738) check209" 3 
o|inlining procedure: k2858 
o|inlining procedure: k2888 
o|inlining procedure: k2888 
o|inlining procedure: k2904 
o|inlining procedure: k2904 
o|consed rest parameter at call site: "(csc.scm:753) t-options208" 1 
o|inlining procedure: k2929 
o|consed rest parameter at call site: "(csc.scm:758) t-options208" 1 
o|consed rest parameter at call site: "(csc.scm:755) check209" 3 
o|inlining procedure: k2929 
o|consed rest parameter at call site: "(csc.scm:761) t-options208" 1 
o|inlining procedure: k2960 
o|inlining procedure: k2980 
o|inlining procedure: k2980 
o|inlining procedure: k3008 
o|consed rest parameter at call site: "(csc.scm:771) t-options208" 1 
o|inlining procedure: k3008 
o|inlining procedure: k3027 
o|inlining procedure: k3027 
o|inlining procedure: k3038 
o|inlining procedure: k3038 
o|inlining procedure: k3061 
o|inlining procedure: k3091 
o|contracted procedure: "(csc.scm:781) g416425" 
o|substituted constant variable: a3077 
o|inlining procedure: k3091 
o|inlining procedure: k3061 
o|consed rest parameter at call site: "(csc.scm:782) stop" 2 
o|consed rest parameter at call site: "(csc.scm:783) stop" 2 
o|substituted constant variable: a3141 
o|substituted constant variable: a3146 
o|substituted constant variable: a3155 
o|substituted constant variable: a3159 
o|substituted constant variable: a3162 
o|substituted constant variable: a3165 
o|substituted constant variable: a3168 
o|substituted constant variable: a3171 
o|inlining procedure: k2960 
o|contracted procedure: k3193 
o|inlining procedure: k3190 
o|inlining procedure: k3218 
o|inlining procedure: k3218 
o|inlining procedure: k3254 
o|inlining procedure: k3254 
o|inlining procedure: k3190 
o|inlining procedure: k3298 
o|inlining procedure: k3298 
o|consed rest parameter at call site: "(csc.scm:807) stop" 2 
o|substituted constant variable: a3312 
o|substituted constant variable: a3321 
o|substituted constant variable: a3326 
o|substituted constant variable: a3331 
o|substituted constant variable: a3340 
o|substituted constant variable: constant59 
o|substituted constant variable: constant56 
o|substituted constant variable: constant63 
o|substituted constant variable: a3343 
o|substituted constant variable: a3352 
o|substituted constant variable: a3354 
o|substituted constant variable: a3356 
o|substituted constant variable: a3358 
o|substituted constant variable: a3360 
o|substituted constant variable: a3362 
o|substituted constant variable: a3364 
o|substituted constant variable: a3366 
o|substituted constant variable: a3368 
o|substituted constant variable: a3370 
o|substituted constant variable: a3372 
o|substituted constant variable: a3374 
o|substituted constant variable: a3376 
o|substituted constant variable: a3381 
o|substituted constant variable: a3383 
o|inlining procedure: k3387 
o|inlining procedure: k3387 
o|substituted constant variable: a3394 
o|substituted constant variable: a3396 
o|substituted constant variable: a3398 
o|substituted constant variable: a3400 
o|substituted constant variable: a3402 
o|substituted constant variable: a3404 
o|substituted constant variable: a3406 
o|substituted constant variable: a3408 
o|substituted constant variable: a3410 
o|substituted constant variable: a3412 
o|substituted constant variable: a3414 
o|substituted constant variable: a3416 
o|substituted constant variable: a3421 
o|substituted constant variable: a3423 
o|substituted constant variable: a3428 
o|substituted constant variable: a3430 
o|substituted constant variable: a3432 
o|substituted constant variable: a3434 
o|substituted constant variable: a3436 
o|substituted constant variable: a3438 
o|substituted constant variable: a3440 
o|substituted constant variable: a3442 
o|substituted constant variable: a3447 
o|substituted constant variable: a3449 
o|substituted constant variable: a3454 
o|substituted constant variable: a3456 
o|substituted constant variable: a3458 
o|substituted constant variable: a3460 
o|substituted constant variable: a3462 
o|substituted constant variable: a3467 
o|substituted constant variable: a3469 
o|substituted constant variable: a3474 
o|substituted constant variable: a3476 
o|substituted constant variable: a3481 
o|substituted constant variable: a3483 
o|substituted constant variable: a3488 
o|substituted constant variable: a3490 
o|substituted constant variable: a3492 
o|substituted constant variable: a3494 
o|substituted constant variable: a3496 
o|substituted constant variable: a3498 
o|substituted constant variable: a3500 
o|substituted constant variable: a3502 
o|substituted constant variable: a3504 
o|substituted constant variable: a3506 
o|substituted constant variable: a3508 
o|substituted constant variable: a3510 
o|substituted constant variable: a3512 
o|substituted constant variable: a3514 
o|substituted constant variable: a3516 
o|substituted constant variable: a3521 
o|substituted constant variable: a3523 
o|inlining procedure: k4872 
o|inlining procedure: k4872 
o|inlining procedure: k4876 
o|inlining procedure: k4876 
o|inlining procedure: k4893 
o|contracted procedure: "(csc.scm:243) g103104" 
o|inlining procedure: k4912 
o|contracted procedure: "(csc.scm:244) g114123" 
o|inlining procedure: k4912 
o|inlining procedure: k4893 
o|contracted procedure: k4954 
o|inlining procedure: k4966 
o|inlining procedure: k4966 
o|inlining procedure: k4980 
o|inlining procedure: k4980 
o|substituted constant variable: a5009 
o|folded constant expression: (string->list (quote "PHhsfiENxubvwAOeWkctgSJM")) 
o|inlining procedure: k5037 
o|inlining procedure: k5037 
o|inlining procedure: k5047 
o|inlining procedure: k5047 
o|inlining procedure: k5070 
o|inlining procedure: k5070 
o|propagated global variable: r50715444 cygwin 
o|inlining procedure: k5074 
o|inlining procedure: k5074 
o|inlining procedure: k5084 
o|inlining procedure: k5084 
o|inlining procedure: k5094 
o|inlining procedure: k5094 
o|inlining procedure: k5104 
o|inlining procedure: k5104 
o|inlining procedure: k5114 
o|inlining procedure: k5114 
o|inlining procedure: k5144 
o|inlining procedure: k5144 
o|simplifications: ((if . 2)) 
o|replaced variables: 721 
o|removed binding forms: 335 
o|propagated global variable: out812 ##sys#standard-error 
o|removed side-effect free assignment to unused variable: link-output-flag 
o|removed side-effect free assignment to unused variable: compile-output-flag 
o|removed side-effect free assignment to unused variable: default-translation-optimization-options 
o|removed side-effect free assignment to unused variable: constant56 
o|removed side-effect free assignment to unused variable: constant59 
o|removed side-effect free assignment to unused variable: constant63 
o|contracted procedure: k1534 
o|removed side-effect free assignment to unused variable: compile-only-flag 
o|substituted constant variable: r40035173 
o|substituted constant variable: r40035173 
o|substituted constant variable: nonstatic-compilation-options 
o|substituted constant variable: nonstatic-compilation-options 
o|substituted constant variable: r44575181 
o|substituted constant variable: r44575181 
o|substituted constant variable: r44575183 
o|substituted constant variable: r44575183 
o|substituted constant variable: r44715185 
o|substituted constant variable: r44715185 
o|substituted constant variable: r44715187 
o|substituted constant variable: r44715187 
o|substituted constant variable: r44775189 
o|propagated global variable: r45175195 static 
o|substituted constant variable: r45485201 
o|substituted constant variable: r46415207 
o|substituted constant variable: r46415210 
o|propagated global variable: out835839 ##sys#standard-output 
o|substituted constant variable: r18035217 
o|substituted constant variable: r18035217 
o|inlining procedure: k1828 
o|inlining procedure: k1828 
o|substituted constant variable: r18295223 
o|substituted constant variable: r18295223 
o|substituted constant variable: r44005240 
o|substituted constant variable: r44005240 
o|inlining procedure: k4399 
o|substituted constant variable: r43765247 
o|propagated global variable: r40985248 static 
o|propagated global variable: a40965251 static-libs 
o|substituted constant variable: a4187 
o|inlining procedure: k4213 
o|propagated global variable: out249253 ##sys#standard-output 
o|substituted constant variable: r19585268 
o|substituted constant variable: r19585268 
o|substituted constant variable: r19585270 
o|substituted constant variable: r19585270 
o|substituted constant variable: r37445273 
o|substituted constant variable: a3749 
o|propagated global variable: a19915287 object-files 
o|propagated global variable: a19915289 c-files 
o|substituted constant variable: r36285293 
o|substituted constant variable: r36285293 
o|inlining procedure: k3627 
o|inlining procedure: k3627 
o|substituted constant variable: r36515297 
o|substituted constant variable: r36515297 
o|inlining procedure: k3650 
o|inlining procedure: k3650 
o|substituted constant variable: r16155310 
o|substituted constant variable: r16155310 
o|substituted constant variable: r16925312 
o|substituted constant variable: r16925312 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|substituted constant variable: r28245375 
o|inlining procedure: k2094 
o|substituted constant variable: r28335378 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|inlining procedure: k2094 
o|substituted constant variable: r48735415 
o|substituted constant variable: r48735415 
o|substituted constant variable: r48945425 
o|substituted constant variable: r48945425 
o|replaced variables: 38 
o|removed binding forms: 759 
o|removed conditional forms: 1 
o|removed side-effect free assignment to unused variable: nonstatic-compilation-options 
o|substituted constant variable: r1535 
o|inlining procedure: "(csc.scm:995) quotewrap" 
o|inlining procedure: "(csc.scm:994) quotewrap" 
o|inlining procedure: k4507 
o|propagated global variable: r45085821 static 
o|inlining procedure: k4507 
o|propagated global variable: r45085822 static-libs 
o|inlining procedure: k4697 
o|inlining procedure: k4366 
o|inlining procedure: k4366 
o|inlining procedure: k4087 
o|propagated global variable: r40885831 gui 
o|inlining procedure: k4087 
o|propagated global variable: r40985248 static 
o|inlining procedure: "(csc.scm:1069) quotewrap" 
o|inlining procedure: "(csc.scm:1068) quotewrap" 
o|inlining procedure: "(csc.scm:939) quotewrap" 
o|inlining procedure: "(csc.scm:932) quotewrap" 
o|propagated global variable: str275849 target-filename 
o|inlining procedure: "(csc.scm:921) quotewrap" 
o|propagated global variable: str275854 target-filename 
o|inlining procedure: "(csc.scm:914) quotewrap" 
o|inlining procedure: "(csc.scm:913) quotewrap" 
o|inlining procedure: "(csc.scm:907) quotewrap" 
o|propagated global variable: str275869 target-filename 
o|inlining procedure: "(csc.scm:578) quotewrap" 
o|inlining procedure: "(csc.scm:577) quotewrap" 
o|propagated global variable: str275881 target-filename 
o|inlining procedure: "(csc.scm:866) quotewrap" 
o|inlining procedure: "(csc.scm:865) quotewrap" 
o|inlining procedure: "(csc.scm:885) quotewrap" 
o|inlining procedure: "(csc.scm:885) quotewrap" 
o|inlining procedure: k1960 
o|inlining procedure: k1998 
o|inlining procedure: "(csc.scm:833) quotewrap" 
o|inlining procedure: "(csc.scm:829) quotewrap" 
o|inlining procedure: k2053 
o|inlining procedure: k1668 
o|inlining procedure: k1668 
o|inlining procedure: "(csc.scm:217) quotewrap" 
o|inlining procedure: "(csc.scm:109) quotewrap" 
o|inlining procedure: "(csc.scm:108) quotewrap" 
o|inlining procedure: "(csc.scm:107) quotewrap" 
o|inlining procedure: "(csc.scm:106) quotewrap" 
o|inlining procedure: "(csc.scm:105) quotewrap" 
o|inlining procedure: "(csc.scm:99) quotewrap" 
o|inlining procedure: "(csc.scm:95) quotewrap" 
o|replaced variables: 11 
o|removed binding forms: 208 
o|Removed `not' forms: 2 
o|substituted constant variable: r18295475 
o|substituted constant variable: r18295477 
o|substituted constant variable: r44005483 
o|substituted constant variable: r43675829 
o|contracted procedure: k4366 
o|propagated global variable: r4367 host-mode 
o|substituted constant variable: r43675830 
o|substituted constant variable: r40885832 
o|contracted procedure: k1960 
o|propagated global variable: r1961 shared 
o|substituted constant variable: r19615913 
o|substituted constant variable: r19995914 
o|substituted constant variable: r36285504 
o|substituted constant variable: r36285506 
o|substituted constant variable: r36515508 
o|substituted constant variable: r36515510 
o|substituted constant variable: r16695936 
o|substituted constant variable: short-options 
o|simplifications: ((if . 1) (let . 1)) 
o|replaced variables: 21 
o|removed binding forms: 21 
o|removed conditional forms: 6 
o|removed side-effect free assignment to unused variable: short-options 
o|replaced variables: 3 
o|removed binding forms: 32 
o|removed binding forms: 2 
o|simplifications: ((if . 34) (##core#call . 301)) 
o|  call simplifications:
o|    assq
o|    ##sys#call-with-values
o|    string-ci=?
o|    ##sys#size	4
o|    fx>	4
o|    string
o|    string->number
o|    cadr
o|    cdr	14
o|    number?
o|    first	2
o|    ##sys#list
o|    ##sys#fudge	2
o|    member	8
o|    string=?	2
o|    number->string
o|    length	2
o|    >=	2
o|    eq?	76
o|    zero?
o|    char=?	7
o|    string->list	2
o|    null?	8
o|    car	18
o|    memq	4
o|    char-whitespace?	2
o|    list->string
o|    not	7
o|    ##sys#check-list	10
o|    pair?	12
o|    cons	41
o|    ##sys#setslot	6
o|    ##sys#slot	24
o|    list	32
o|    ##sys#apply
o|contracted procedure: k1381 
o|contracted procedure: k1385 
o|contracted procedure: k1389 
o|contracted procedure: k1393 
o|contracted procedure: k1436 
o|contracted procedure: k1440 
o|contracted procedure: k1453 
o|contracted procedure: k1565 
o|contracted procedure: k1569 
o|contracted procedure: k4958 
o|contracted procedure: k1579 
o|contracted procedure: k3960 
o|contracted procedure: k3972 
o|contracted procedure: k3975 
o|contracted procedure: k3986 
o|contracted procedure: k3998 
o|contracted procedure: k4005 
o|inlining procedure: k4504 
o|inlining procedure: k4504 
o|contracted procedure: k4550 
o|contracted procedure: k4553 
o|contracted procedure: k4559 
o|contracted procedure: k4583 
o|contracted procedure: k4608 
o|contracted procedure: k4684 
o|contracted procedure: k4643 
o|contracted procedure: k4647 
o|contracted procedure: k1798 
o|contracted procedure: k1805 
o|inlining procedure: k1791 
o|contracted procedure: k1802 
o|inlining procedure: k1791 
o|contracted procedure: k1823 
o|contracted procedure: k1838 
o|contracted procedure: k1845 
o|contracted procedure: k1857 
o|contracted procedure: k4011 
o|contracted procedure: k4035 
o|contracted procedure: k4047 
o|contracted procedure: k4057 
o|contracted procedure: k4061 
o|propagated global variable: g736738 generated-object-files 
o|contracted procedure: k4073 
o|contracted procedure: k4801 
o|contracted procedure: k4797 
o|contracted procedure: k4793 
o|contracted procedure: k4405 
o|contracted procedure: k4382 
o|contracted procedure: k4109 
o|contracted procedure: k4149 
o|contracted procedure: k4164 
o|contracted procedure: k4172 
o|contracted procedure: k4226 
o|contracted procedure: k4239 
o|contracted procedure: k4306 
o|contracted procedure: k4309 
o|contracted procedure: k4320 
o|contracted procedure: k4332 
o|propagated global variable: g663667 object-files 
o|contracted procedure: k1892 
o|contracted procedure: k3708 
o|contracted procedure: k3712 
o|contracted procedure: k3724 
o|contracted procedure: k3720 
o|contracted procedure: k3743 
o|contracted procedure: k3754 
o|contracted procedure: k3760 
o|contracted procedure: k3778 
o|contracted procedure: k3782 
o|contracted procedure: k3790 
o|contracted procedure: k3801 
o|contracted procedure: k3814 
o|contracted procedure: k3820 
o|contracted procedure: k3832 
o|contracted procedure: k3842 
o|contracted procedure: k3846 
o|propagated global variable: g604606 generated-rc-files 
o|contracted procedure: k3855 
o|contracted procedure: k3865 
o|contracted procedure: k3869 
o|propagated global variable: g587589 generated-c-files 
o|contracted procedure: k3882 
o|contracted procedure: k3892 
o|contracted procedure: k3896 
o|propagated global variable: g566568 rc-files 
o|contracted procedure: k3909 
o|contracted procedure: k3913 
o|contracted procedure: k4845 
o|contracted procedure: k4841 
o|contracted procedure: k4837 
o|contracted procedure: k3933 
o|contracted procedure: k3943 
o|contracted procedure: k3947 
o|propagated global variable: g536538 c-files 
o|contracted procedure: k1969 
o|contracted procedure: k1995 
o|contracted procedure: k2004 
o|contracted procedure: k1998 
o|contracted procedure: k3664 
o|contracted procedure: k3676 
o|contracted procedure: k3686 
o|contracted procedure: k3690 
o|contracted procedure: k3661 
o|contracted procedure: k3656 
o|contracted procedure: k3529 
o|contracted procedure: k3550 
o|contracted procedure: k3554 
o|contracted procedure: k3633 
o|contracted procedure: k3578 
o|contracted procedure: k3585 
o|contracted procedure: k3597 
o|contracted procedure: k3600 
o|contracted procedure: k3611 
o|contracted procedure: k3623 
o|contracted procedure: k3643 
o|propagated global variable: g476478 scheme-files 
o|contracted procedure: k2027 
o|contracted procedure: k2034 
o|contracted procedure: k2037 
o|contracted procedure: k2041 
o|contracted procedure: k1636 
o|contracted procedure: k1639 
o|contracted procedure: k1650 
o|contracted procedure: k1662 
o|contracted procedure: k2087 
o|contracted procedure: k2100 
o|contracted procedure: k2103 
o|contracted procedure: k1772 
o|contracted procedure: k1768 
o|contracted procedure: k1764 
o|contracted procedure: k1760 
o|contracted procedure: k1756 
o|contracted procedure: k1752 
o|contracted procedure: k1748 
o|contracted procedure: k2115 
o|contracted procedure: k2131 
o|contracted procedure: k2147 
o|contracted procedure: k2155 
o|contracted procedure: k2161 
o|contracted procedure: k2168 
o|contracted procedure: k2179 
o|contracted procedure: k2190 
o|contracted procedure: k2198 
o|contracted procedure: k2206 
o|contracted procedure: k2218 
o|contracted procedure: k2230 
o|contracted procedure: k2242 
o|contracted procedure: k2254 
o|contracted procedure: k2262 
o|contracted procedure: k2265 
o|contracted procedure: k2279 
o|contracted procedure: k2287 
o|contracted procedure: k2293 
o|contracted procedure: k2296 
o|contracted procedure: k2300 
o|contracted procedure: k2309 
o|contracted procedure: k2312 
o|contracted procedure: k2322 
o|contracted procedure: k2325 
o|contracted procedure: k2335 
o|contracted procedure: k2342 
o|contracted procedure: k2349 
o|contracted procedure: k2356 
o|contracted procedure: k2359 
o|contracted procedure: k2364 
o|contracted procedure: k2370 
o|contracted procedure: k2373 
o|contracted procedure: k2389 
o|contracted procedure: k2397 
o|contracted procedure: k2393 
o|contracted procedure: k2403 
o|contracted procedure: k2412 
o|contracted procedure: k2419 
o|contracted procedure: k2424 
o|contracted procedure: k2431 
o|contracted procedure: k2449 
o|contracted procedure: k2457 
o|contracted procedure: k2464 
o|contracted procedure: k2474 
o|contracted procedure: k2482 
o|contracted procedure: k2488 
o|contracted procedure: k2491 
o|contracted procedure: k2497 
o|contracted procedure: k2501 
o|contracted procedure: k2508 
o|contracted procedure: k2511 
o|contracted procedure: k2521 
o|contracted procedure: k2531 
o|contracted procedure: k2541 
o|contracted procedure: k2551 
o|contracted procedure: k2561 
o|contracted procedure: k2571 
o|contracted procedure: k2581 
o|contracted procedure: k2591 
o|contracted procedure: k2601 
o|contracted procedure: k2609 
o|contracted procedure: k2621 
o|contracted procedure: k2624 
o|contracted procedure: k2633 
o|contracted procedure: k2640 
o|contracted procedure: k2644 
o|contracted procedure: k2650 
o|contracted procedure: k2657 
o|contracted procedure: k2661 
o|contracted procedure: k2667 
o|contracted procedure: k2674 
o|contracted procedure: k2678 
o|contracted procedure: k2684 
o|contracted procedure: k2691 
o|contracted procedure: k2695 
o|contracted procedure: k2701 
o|contracted procedure: k2712 
o|contracted procedure: k2716 
o|contracted procedure: k2722 
o|contracted procedure: k2733 
o|contracted procedure: k2741 
o|contracted procedure: k2747 
o|contracted procedure: k2755 
o|contracted procedure: k2761 
o|contracted procedure: k2772 
o|contracted procedure: k2780 
o|contracted procedure: k2786 
o|contracted procedure: k2793 
o|contracted procedure: k2800 
o|contracted procedure: k2811 
o|contracted procedure: k2835 
o|contracted procedure: k2841 
o|contracted procedure: k2851 
o|contracted procedure: k2855 
o|contracted procedure: k2861 
o|contracted procedure: k2871 
o|contracted procedure: k2875 
o|contracted procedure: k2881 
o|contracted procedure: k2901 
o|contracted procedure: k2914 
o|contracted procedure: k2910 
o|contracted procedure: k2923 
o|contracted procedure: k2932 
o|contracted procedure: k2938 
o|contracted procedure: k2941 
o|contracted procedure: k2948 
o|contracted procedure: k2969 
o|contracted procedure: k2977 
o|contracted procedure: k2983 
o|contracted procedure: k2991 
o|contracted procedure: k2997 
o|contracted procedure: k3005 
o|contracted procedure: k3011 
o|contracted procedure: k3024 
o|contracted procedure: k3035 
o|contracted procedure: k3049 
o|contracted procedure: k3138 
o|contracted procedure: k3055 
o|contracted procedure: k3058 
o|contracted procedure: k3064 
o|contracted procedure: k3082 
o|contracted procedure: k3094 
o|contracted procedure: k3097 
o|contracted procedure: k3108 
o|contracted procedure: k3120 
o|contracted procedure: k3079 
o|contracted procedure: k3152 
o|contracted procedure: k3143 
o|contracted procedure: k3207 
o|contracted procedure: k3215 
o|contracted procedure: k3221 
o|contracted procedure: k3229 
o|contracted procedure: k3235 
o|contracted procedure: k3247 
o|contracted procedure: k3251 
o|contracted procedure: k3257 
o|contracted procedure: k3266 
o|contracted procedure: k3282 
o|contracted procedure: k3290 
o|contracted procedure: k3201 
o|contracted procedure: k3305 
o|contracted procedure: k3323 
o|contracted procedure: k3313 
o|contracted procedure: k3337 
o|contracted procedure: k3328 
o|contracted procedure: k3346 
o|contracted procedure: k3384 
o|contracted procedure: k4915 
o|contracted procedure: k4918 
o|contracted procedure: k4929 
o|contracted procedure: k4941 
o|simplifications: ((if . 3) (let . 43)) 
o|removed binding forms: 275 
o|inlining procedure: k3978 
o|inlining procedure: k3978 
o|inlining procedure: "(csc.scm:962) prefix" 
o|inlining procedure: k4312 
o|inlining procedure: k4312 
o|inlining procedure: k3603 
o|inlining procedure: k3603 
o|inlining procedure: k1642 
o|inlining procedure: k1642 
o|inlining procedure: "(csc.scm:269) prefix" 
o|inlining procedure: k2470 
o|inlining procedure: k2470 
o|inlining procedure: k2796 
o|inlining procedure: k2796 
o|inlining procedure: k3100 
o|inlining procedure: k3100 
o|inlining procedure: "(csc.scm:254) prefix" 
o|inlining procedure: k4921 
o|inlining procedure: k4921 
o|inlining procedure: "(csc.scm:232) prefix" 
o|inlining procedure: "(csc.scm:218) prefix" 
o|propagated global variable: str236258 default-library 
o|inlining procedure: "(csc.scm:100) prefix" 
o|inlining procedure: "(csc.scm:96) prefix" 
o|simplifications: ((let . 2)) 
o|replaced variables: 43 
o|removed binding forms: 2 
o|removed side-effect free assignment to unused variable: prefix 
o|substituted constant variable: dir246171 
o|substituted constant variable: str236170 
o|substituted constant variable: dir246214 
o|substituted constant variable: str236213 
o|substituted constant variable: dir246241 
o|substituted constant variable: str236240 
o|substituted constant variable: str236253 
o|substituted constant variable: dir246259 
o|substituted constant variable: dir246264 
o|substituted constant variable: str236263 
o|substituted constant variable: dir246269 
o|substituted constant variable: str236268 
o|simplifications: ((if . 2)) 
o|replaced variables: 22 
o|removed binding forms: 38 
o|inlining procedure: k1691 
o|inlining procedure: k4994 
o|inlining procedure: k5124 
o|inlining procedure: k5140 
o|replaced variables: 24 
o|removed binding forms: 28 
o|replaced variables: 4 
o|removed binding forms: 6 
o|removed binding forms: 4 
o|direct leaf routine/allocation: use-private-repository211 6 
o|direct leaf routine/allocation: g393394 3 
o|inlining procedure: "(csc.scm:649) k2094" 
o|inlining procedure: "(csc.scm:752) k2094" 
o|simplifications: ((if . 1)) 
o|customizable procedures: (k1503 k4886 map-loop108133 k2612 k2895 k2898 k2954 k2963 k3274 k3238 k3041 map-loop410428 k2803 shared-build210 check209 k2268 t-options208 loop228 k1603 k1607 map-loop162187 k2010 k2013 k3574 map-loop490510 for-each-loop469520 k1874 g530537 for-each-loop529548 k3899 k3766 g560567 for-each-loop559573 for-each-loop580590 for-each-loop597607 k3736 compiler-options map-loop651668 linker-options linker-libraries k4100 k4064 lib-path copy-files for-each-loop729739 stop k4571 fold803 k4500 k4473 command map-loop620640) 
o|calls to known targets: 237 
o|identified direct recursive calls: f_4545 1 
o|fast box initializations: 18 
o|fast global references: 370 
o|fast global assignments: 176 
o|dropping unused closure argument: f_4460 
o|dropping unused closure argument: f_1779 
o|dropping unused closure argument: f_1786 
o|dropping unused closure argument: f_4490 
o|dropping unused closure argument: f_1403 
o|dropping unused closure argument: f_4336 
o|dropping unused closure argument: f_3951 
o|dropping unused closure argument: f_4679 
o|dropping unused closure argument: f_1812 
o|dropping unused closure argument: f_1835 
o|dropping unused closure argument: f_4417 
*/
/* end of file */
