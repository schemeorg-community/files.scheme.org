/* Generated from c-platform.scm by the CHICKEN compiler
   http://www.call-cc.org
   2014-06-02 16:40
   Version 4.9.0 (rev 3f195ba)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2014-06-02 on yves (Linux)
   command line: c-platform.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -no-lambda-info -local -no-trace -extend private-namespace.scm -no-trace -output-file c-platform.c
   unit: platform
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_chicken_2dsyntax_toplevel)
C_externimport void C_ccall C_chicken_2dsyntax_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[937];
static double C_possibly_force_alignment;


C_noret_decl(f_2728)
static void C_ccall f_2728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2725)
static void C_ccall f_2725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2713)
static void C_ccall f_2713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2710)
static void C_ccall f_2710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4282)
static void C_ccall f_4282(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2719)
static void C_ccall f_2719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2716)
static void C_ccall f_2716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2701)
static void C_ccall f_2701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2704)
static void C_ccall f_2704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2707)
static void C_ccall f_2707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3295)
static void C_ccall f_3295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3292)
static void C_ccall f_3292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3298)
static void C_ccall f_3298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3262)
static void C_ccall f_3262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3265)
static void C_ccall f_3265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3268)
static void C_ccall f_3268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4870)
static void C_fcall f_4870(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3280)
static void C_ccall f_3280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5497)
static void C_ccall f_5497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3283)
static void C_ccall f_3283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5493)
static void C_ccall f_5493(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2083)
static void C_ccall f_2083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3289)
static void C_ccall f_3289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3286)
static void C_ccall f_3286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2860)
static void C_ccall f_2860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5226)
static void C_fcall f_5226(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1778)
static void C_fcall f_1778(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4504)
static void C_ccall f_4504(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1908)
static void C_ccall f_1908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2875)
static void C_ccall f_2875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2872)
static void C_ccall f_2872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2878)
static void C_ccall f_2878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2061)
static void C_ccall f_2061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2064)
static void C_fcall f_2064(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1781)
static void C_fcall f_1781(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3628)
static void C_ccall f_3628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3625)
static void C_ccall f_3625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3622)
static void C_ccall f_3622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2863)
static void C_ccall f_2863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2869)
static void C_ccall f_2869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2866)
static void C_ccall f_2866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5242)
static void C_ccall f_5242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3616)
static void C_ccall f_3616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3613)
static void C_ccall f_3613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3610)
static void C_ccall f_3610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3379)
static void C_ccall f_3379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3376)
static void C_ccall f_3376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2044)
static void C_ccall f_2044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3619)
static void C_ccall f_3619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4534)
static void C_fcall f_4534(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3370)
static void C_ccall f_3370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3373)
static void C_ccall f_3373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2824)
static void C_ccall f_2824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2821)
static void C_ccall f_2821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2839)
static void C_ccall f_2839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3634)
static void C_ccall f_3634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3637)
static void C_ccall f_3637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3631)
static void C_ccall f_3631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3397)
static void C_ccall f_3397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3664)
static void C_ccall f_3664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2827)
static void C_ccall f_2827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3391)
static void C_ccall f_3391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3667)
static void C_ccall f_3667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3394)
static void C_ccall f_3394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3661)
static void C_ccall f_3661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3367)
static void C_ccall f_3367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3655)
static void C_ccall f_3655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3652)
static void C_ccall f_3652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3658)
static void C_ccall f_3658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3361)
static void C_ccall f_3361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3364)
static void C_ccall f_3364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3607)
static void C_ccall f_3607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3601)
static void C_ccall f_3601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3604)
static void C_ccall f_3604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4214)
static void C_ccall f_4214(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1600)
static void C_ccall f_1600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1748)
static void C_ccall f_1748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2507)
static void C_ccall f_2507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1740)
static void C_ccall f_1740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1753)
static void C_ccall f_1753(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2854)
static void C_ccall f_2854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2851)
static void C_ccall f_2851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1751)
static void C_ccall f_1751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3271)
static void C_ccall f_3271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3274)
static void C_ccall f_3274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1606)
static void C_ccall f_1606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3277)
static void C_ccall f_3277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1603)
static void C_ccall f_1603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1769)
static void C_fcall f_1769(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2845)
static void C_ccall f_2845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2842)
static void C_ccall f_2842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2857)
static void C_ccall f_2857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2836)
static void C_ccall f_2836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2833)
static void C_ccall f_2833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2830)
static void C_ccall f_2830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2848)
static void C_ccall f_2848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3643)
static void C_ccall f_3643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3646)
static void C_ccall f_3646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3649)
static void C_ccall f_3649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3640)
static void C_ccall f_3640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4095)
static void C_ccall f_4095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4092)
static void C_ccall f_4092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4098)
static void C_ccall f_4098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1629)
static void C_ccall f_1629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3778)
static void C_ccall f_3778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3775)
static void C_ccall f_3775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3772)
static void C_ccall f_3772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3388)
static void C_ccall f_3388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3780)
static void C_ccall f_3780(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3382)
static void C_ccall f_3382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3385)
static void C_ccall f_3385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5107)
static void C_ccall f_5107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4390)
static void C_ccall f_4390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3800)
static void C_ccall f_3800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2120)
static void C_ccall f_2120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5044)
static void C_ccall f_5044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5048)
static void C_ccall f_5048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3310)
static void C_ccall f_3310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3313)
static void C_ccall f_3313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3316)
static void C_ccall f_3316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3319)
static void C_ccall f_3319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5217)
static void C_ccall f_5217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5219)
static void C_ccall f_5219(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3340)
static void C_ccall f_3340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3349)
static void C_ccall f_3349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3343)
static void C_ccall f_3343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3346)
static void C_ccall f_3346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3815)
static void C_ccall f_3815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4076)
static void C_ccall f_4076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4073)
static void C_ccall f_4073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4086)
static void C_ccall f_4086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4083)
static void C_ccall f_4083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4080)
static void C_ccall f_4080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3322)
static void C_ccall f_3322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3328)
static void C_ccall f_3328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3325)
static void C_ccall f_3325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4089)
static void C_ccall f_4089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3352)
static void C_ccall f_3352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3358)
static void C_ccall f_3358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3355)
static void C_ccall f_3355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3868)
static void C_ccall f_3868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3331)
static void C_ccall f_3331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3337)
static void C_ccall f_3337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3334)
static void C_ccall f_3334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4022)
static void C_ccall f_4022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2812)
static void C_ccall f_2812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2815)
static void C_ccall f_2815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3583)
static void C_ccall f_3583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3586)
static void C_ccall f_3586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3580)
static void C_ccall f_3580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3577)
static void C_ccall f_3577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2800)
static void C_ccall f_2800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5703)
static void C_ccall f_5703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2803)
static void C_ccall f_2803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2806)
static void C_ccall f_2806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2818)
static void C_ccall f_2818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4365)
static void C_fcall f_4365(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4362)
static void C_ccall f_4362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3595)
static void C_ccall f_3595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3592)
static void C_ccall f_3592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3589)
static void C_ccall f_3589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2809)
static void C_ccall f_2809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3598)
static void C_ccall f_3598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3301)
static void C_ccall f_3301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3304)
static void C_ccall f_3304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3307)
static void C_ccall f_3307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4207)
static void C_ccall f_4207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4332)
static void C_ccall f_4332(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2992)
static void C_ccall f_2992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2995)
static void C_ccall f_2995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2998)
static void C_ccall f_2998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2983)
static void C_ccall f_2983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2986)
static void C_ccall f_2986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2989)
static void C_ccall f_2989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2980)
static void C_ccall f_2980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3574)
static void C_ccall f_3574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3571)
static void C_ccall f_3571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5644)
static void C_ccall f_5644(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2207)
static void C_ccall f_2207(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4867)
static void C_fcall f_4867(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4836)
static void C_fcall f_4836(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4830)
static void C_fcall f_4830(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2231)
static void C_ccall f_2231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2234)
static void C_fcall f_2234(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2195)
static void C_ccall f_2195(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4814)
static void C_ccall f_4814(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5297)
static void C_ccall f_5297(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5295)
static void C_ccall f_5295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2187)
static void C_ccall f_2187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2184)
static void C_ccall f_2184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2189)
static void C_fcall f_2189(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2974)
static void C_ccall f_2974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2977)
static void C_ccall f_2977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2971)
static void C_ccall f_2971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3211)
static void C_ccall f_3211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3217)
static void C_ccall f_3217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3214)
static void C_ccall f_3214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5175)
static void C_ccall f_5175(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2965)
static void C_ccall f_2965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2461)
static void C_ccall f_2461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2962)
static void C_ccall f_2962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2968)
static void C_ccall f_2968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3202)
static void C_ccall f_3202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3205)
static void C_ccall f_3205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3208)
static void C_ccall f_3208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5523)
static void C_ccall f_5523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2455)
static void C_ccall f_2455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3232)
static void C_ccall f_3232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3238)
static void C_ccall f_3238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3235)
static void C_ccall f_3235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2254)
static void C_ccall f_2254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3460)
static void C_ccall f_3460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3463)
static void C_ccall f_3463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2458)
static void C_ccall f_2458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3220)
static void C_ccall f_3220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3229)
static void C_ccall f_3229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3223)
static void C_ccall f_3223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3226)
static void C_ccall f_3226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3469)
static void C_ccall f_3469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3466)
static void C_ccall f_3466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2935)
static void C_ccall f_2935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2932)
static void C_ccall f_2932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2938)
static void C_ccall f_2938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3475)
static void C_ccall f_3475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3472)
static void C_ccall f_3472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3250)
static void C_ccall f_3250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3259)
static void C_ccall f_3259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3256)
static void C_ccall f_3256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3253)
static void C_ccall f_3253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3478)
static void C_ccall f_3478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2926)
static void C_ccall f_2926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2923)
static void C_ccall f_2923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2920)
static void C_ccall f_2920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4134)
static void C_ccall f_4134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2929)
static void C_ccall f_2929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4131)
static void C_ccall f_4131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3481)
static void C_ccall f_3481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4137)
static void C_ccall f_4137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4139)
static void C_ccall f_4139(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3484)
static void C_ccall f_3484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3241)
static void C_ccall f_3241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3247)
static void C_ccall f_3247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3244)
static void C_ccall f_3244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3487)
static void C_ccall f_3487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4101)
static void C_ccall f_4101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4107)
static void C_ccall f_4107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4104)
static void C_ccall f_4104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2428)
static void C_ccall f_2428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4010)
static void C_ccall f_4010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4014)
static void C_ccall f_4014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4018)
static void C_ccall f_4018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1670)
static void C_ccall f_1670(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4475)
static void C_ccall f_4475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4125)
static void C_ccall f_4125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4122)
static void C_ccall f_4122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4128)
static void C_ccall f_4128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(C_platform_toplevel)
C_externexport void C_ccall C_platform_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4791)
static void C_ccall f_4791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2953)
static void C_ccall f_2953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2956)
static void C_ccall f_2956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2950)
static void C_ccall f_2950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2959)
static void C_ccall f_2959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4149)
static void C_ccall f_4149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2944)
static void C_ccall f_2944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3001)
static void C_ccall f_3001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2941)
static void C_ccall f_2941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3007)
static void C_ccall f_3007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2947)
static void C_ccall f_2947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3004)
static void C_ccall f_3004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5447)
static void C_ccall f_5447(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5445)
static void C_ccall f_5445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3022)
static void C_ccall f_3022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3025)
static void C_ccall f_3025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3028)
static void C_ccall f_3028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3181)
static void C_ccall f_3181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3184)
static void C_ccall f_3184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3013)
static void C_ccall f_3013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3010)
static void C_ccall f_3010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3016)
static void C_ccall f_3016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3019)
static void C_ccall f_3019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3178)
static void C_ccall f_3178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3870)
static void C_ccall f_3870(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3490)
static void C_ccall f_3490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3493)
static void C_ccall f_3493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3496)
static void C_ccall f_3496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3499)
static void C_ccall f_3499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4940)
static void C_ccall f_4940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3190)
static void C_ccall f_3190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3193)
static void C_ccall f_3193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3187)
static void C_ccall f_3187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4999)
static void C_ccall f_4999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3199)
static void C_ccall f_3199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3196)
static void C_ccall f_3196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4449)
static void C_ccall f_4449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2668)
static void C_ccall f_2668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4612)
static void C_ccall f_4612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2665)
static void C_ccall f_2665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2662)
static void C_ccall f_2662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2659)
static void C_ccall f_2659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2656)
static void C_ccall f_2656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2650)
static void C_ccall f_2650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2653)
static void C_ccall f_2653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2647)
static void C_ccall f_2647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3451)
static void C_ccall f_3451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3457)
static void C_ccall f_3457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3454)
static void C_ccall f_3454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2641)
static void C_ccall f_2641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2644)
static void C_ccall f_2644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2638)
static void C_ccall f_2638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3400)
static void C_ccall f_3400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3403)
static void C_ccall f_3403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3406)
static void C_ccall f_3406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3409)
static void C_ccall f_3409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4608)
static void C_ccall f_4608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2632)
static void C_ccall f_2632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2635)
static void C_ccall f_2635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3421)
static void C_ccall f_3421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3427)
static void C_ccall f_3427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3424)
static void C_ccall f_3424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4661)
static void C_ccall f_4661(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4636)
static void C_ccall f_4636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4584)
static void C_fcall f_4584(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3442)
static void C_ccall f_3442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3448)
static void C_ccall f_3448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3445)
static void C_ccall f_3445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3430)
static void C_ccall f_3430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3439)
static void C_ccall f_3439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3436)
static void C_ccall f_3436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3433)
static void C_ccall f_3433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5598)
static void C_ccall f_5598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4907)
static void C_ccall f_4907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5582)
static void C_fcall f_5582(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3553)
static void C_ccall f_3553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3559)
static void C_ccall f_3559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3556)
static void C_ccall f_3556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3550)
static void C_ccall f_3550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3160)
static void C_ccall f_3160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3163)
static void C_ccall f_3163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5575)
static void C_ccall f_5575(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5573)
static void C_ccall f_5573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3544)
static void C_ccall f_3544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3547)
static void C_ccall f_3547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4741)
static C_word C_fcall f_4741(C_word *a,C_word t0,C_word t1,C_word t2);
C_noret_decl(f_3541)
static void C_ccall f_3541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2761)
static void C_ccall f_2761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2764)
static void C_ccall f_2764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3172)
static void C_ccall f_3172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3175)
static void C_ccall f_3175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3166)
static void C_ccall f_3166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2767)
static void C_ccall f_2767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3169)
static void C_ccall f_3169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3532)
static void C_ccall f_3532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3535)
static void C_ccall f_3535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3538)
static void C_ccall f_3538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3673)
static void C_ccall f_3673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3676)
static void C_ccall f_3676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3670)
static void C_ccall f_3670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2755)
static void C_ccall f_2755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2752)
static void C_ccall f_2752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3679)
static void C_ccall f_3679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2911)
static void C_ccall f_2911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2914)
static void C_ccall f_2914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2917)
static void C_ccall f_2917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2758)
static void C_ccall f_2758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3685)
static void C_ccall f_3685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3151)
static void C_ccall f_3151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3682)
static void C_ccall f_3682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2740)
static void C_ccall f_2740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2743)
static void C_ccall f_2743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3688)
static void C_ccall f_3688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3157)
static void C_ccall f_3157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2902)
static void C_ccall f_2902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3040)
static void C_ccall f_3040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3154)
static void C_ccall f_3154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2905)
static void C_ccall f_2905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3043)
static void C_ccall f_3043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2908)
static void C_ccall f_2908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3046)
static void C_ccall f_3046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3049)
static void C_ccall f_3049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2746)
static void C_ccall f_2746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2749)
static void C_ccall f_2749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3517)
static void C_ccall f_3517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3514)
static void C_ccall f_3514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3511)
static void C_ccall f_3511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3694)
static void C_ccall f_3694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3691)
static void C_ccall f_3691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3142)
static void C_ccall f_3142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3412)
static void C_ccall f_3412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2731)
static void C_ccall f_2731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3415)
static void C_ccall f_3415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2734)
static void C_ccall f_2734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3418)
static void C_ccall f_3418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3697)
static void C_ccall f_3697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3148)
static void C_ccall f_3148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3145)
static void C_ccall f_3145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3031)
static void C_ccall f_3031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3034)
static void C_ccall f_3034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3037)
static void C_ccall f_3037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2737)
static void C_ccall f_2737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3945)
static void C_ccall f_3945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3505)
static void C_ccall f_3505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3508)
static void C_ccall f_3508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3502)
static void C_ccall f_3502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4703)
static void C_ccall f_4703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3130)
static void C_ccall f_3130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5050)
static void C_ccall f_5050(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3139)
static void C_ccall f_3139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3133)
static void C_ccall f_3133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3136)
static void C_ccall f_3136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1999)
static void C_ccall f_1999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1993)
static void C_ccall f_1993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5089)
static void C_fcall f_5089(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3121)
static void C_ccall f_3121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3127)
static void C_ccall f_3127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3124)
static void C_ccall f_3124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3924)
static void C_ccall f_3924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3926)
static void C_ccall f_3926(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3565)
static void C_ccall f_3565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3921)
static void C_ccall f_3921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3562)
static void C_ccall f_3562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3568)
static void C_ccall f_3568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5338)
static void C_ccall f_5338(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3112)
static void C_ccall f_3112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3115)
static void C_ccall f_3115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3118)
static void C_ccall f_3118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2300)
static void C_ccall f_2300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4113)
static void C_ccall f_4113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4110)
static void C_ccall f_4110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4116)
static void C_ccall f_4116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3915)
static void C_ccall f_3915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4119)
static void C_ccall f_4119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3918)
static void C_ccall f_3918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4738)
static void C_ccall f_4738(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3103)
static void C_ccall f_3103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3100)
static void C_ccall f_3100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3106)
static void C_ccall f_3106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3109)
static void C_ccall f_3109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3727)
static void C_ccall f_3727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3721)
static void C_ccall f_3721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3724)
static void C_ccall f_3724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2015)
static void C_fcall f_2015(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2013)
static void C_ccall f_2013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2351)
static void C_ccall f_2351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2354)
static void C_ccall f_2354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5688)
static void C_ccall f_5688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3715)
static void C_ccall f_3715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3718)
static void C_ccall f_3718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3529)
static void C_ccall f_3529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3712)
static void C_ccall f_3712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3526)
static void C_ccall f_3526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3523)
static void C_ccall f_3523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2358)
static void C_ccall f_2358(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2357)
static void C_ccall f_2357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3520)
static void C_ccall f_3520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2698)
static void C_ccall f_2698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2695)
static void C_ccall f_2695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2342)
static void C_ccall f_2342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2692)
static void C_ccall f_2692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5417)
static void C_ccall f_5417(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5415)
static void C_ccall f_5415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3709)
static void C_ccall f_3709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3706)
static void C_ccall f_3706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3703)
static void C_ccall f_3703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2345)
static void C_ccall f_2345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3700)
static void C_ccall f_3700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2348)
static void C_ccall f_2348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2689)
static void C_ccall f_2689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2683)
static void C_ccall f_2683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2686)
static void C_ccall f_2686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2330)
static void C_ccall f_2330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2333)
static void C_ccall f_2333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2680)
static void C_ccall f_2680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2339)
static void C_ccall f_2339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2336)
static void C_ccall f_2336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2677)
static void C_ccall f_2677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2674)
static void C_ccall f_2674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2671)
static void C_ccall f_2671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3763)
static void C_ccall f_3763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3766)
static void C_ccall f_3766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3769)
static void C_ccall f_3769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3760)
static void C_ccall f_3760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2394)
static void C_ccall f_2394(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3754)
static void C_ccall f_3754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3757)
static void C_ccall f_3757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2392)
static void C_ccall f_2392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3751)
static void C_ccall f_3751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2389)
static void C_ccall f_2389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5678)
static void C_fcall f_5678(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3745)
static void C_ccall f_3745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3742)
static void C_ccall f_3742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3748)
static void C_ccall f_3748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3733)
static void C_ccall f_3733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3739)
static void C_ccall f_3739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3736)
static void C_ccall f_3736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3730)
static void C_ccall f_3730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1651)
static void C_ccall f_1651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1958)
static void C_ccall f_1958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1955)
static void C_ccall f_1955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1952)
static void C_ccall f_1952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2629)
static void C_ccall f_2629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2626)
static void C_ccall f_2626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1660)
static void C_ccall f_1660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2623)
static void C_ccall f_2623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4419)
static void C_ccall f_4419(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1960)
static void C_ccall f_1960(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3962)
static void C_ccall f_3962(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2620)
static void C_ccall f_2620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1654)
static void C_ccall f_1654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1657)
static void C_ccall f_1657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2617)
static void C_ccall f_2617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2614)
static void C_ccall f_2614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1970)
static void C_ccall f_1970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2611)
static void C_ccall f_2611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1663)
static void C_ccall f_1663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1668)
static void C_fcall f_1668(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1666)
static void C_ccall f_1666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2536)
static void C_ccall f_2536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2797)
static void C_ccall f_2797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2794)
static void C_ccall f_2794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3052)
static void C_ccall f_3052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2791)
static void C_ccall f_2791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3058)
static void C_ccall f_3058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3055)
static void C_ccall f_3055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2788)
static void C_ccall f_2788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2785)
static void C_ccall f_2785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3064)
static void C_ccall f_3064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3061)
static void C_ccall f_3061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2782)
static void C_ccall f_2782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3067)
static void C_ccall f_3067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2540)
static void C_ccall f_2540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2779)
static void C_ccall f_2779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2773)
static void C_ccall f_2773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2776)
static void C_ccall f_2776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3073)
static void C_ccall f_3073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3070)
static void C_ccall f_3070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2770)
static void C_ccall f_2770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3079)
static void C_ccall f_3079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3076)
static void C_ccall f_3076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2890)
static void C_ccall f_2890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3082)
static void C_ccall f_3082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3085)
static void C_ccall f_3085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3088)
static void C_ccall f_3088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2881)
static void C_ccall f_2881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3091)
static void C_ccall f_3091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3094)
static void C_ccall f_3094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2893)
static void C_ccall f_2893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2896)
static void C_ccall f_2896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2899)
static void C_ccall f_2899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3097)
static void C_ccall f_3097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2884)
static void C_ccall f_2884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2887)
static void C_ccall f_2887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5159)
static void C_ccall f_5159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2722)
static void C_ccall f_2722(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_4870)
static void C_fcall trf_4870(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4870(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4870(t0,t1);}

C_noret_decl(trf_5226)
static void C_fcall trf_5226(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5226(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5226(t0,t1);}

C_noret_decl(trf_1778)
static void C_fcall trf_1778(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1778(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1778(t0,t1);}

C_noret_decl(trf_2064)
static void C_fcall trf_2064(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2064(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2064(t0,t1);}

C_noret_decl(trf_1781)
static void C_fcall trf_1781(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1781(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1781(t0,t1);}

C_noret_decl(trf_4534)
static void C_fcall trf_4534(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4534(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4534(t0,t1);}

C_noret_decl(trf_1769)
static void C_fcall trf_1769(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1769(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1769(t0,t1);}

C_noret_decl(trf_4365)
static void C_fcall trf_4365(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4365(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4365(t0,t1);}

C_noret_decl(trf_4867)
static void C_fcall trf_4867(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4867(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4867(t0,t1);}

C_noret_decl(trf_4836)
static void C_fcall trf_4836(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4836(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4836(t0,t1);}

C_noret_decl(trf_4830)
static void C_fcall trf_4830(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4830(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4830(t0,t1);}

C_noret_decl(trf_2234)
static void C_fcall trf_2234(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2234(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2234(t0,t1);}

C_noret_decl(trf_2189)
static void C_fcall trf_2189(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2189(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2189(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4584)
static void C_fcall trf_4584(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4584(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4584(t0,t1);}

C_noret_decl(trf_5582)
static void C_fcall trf_5582(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5582(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5582(t0,t1);}

C_noret_decl(trf_5089)
static void C_fcall trf_5089(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5089(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5089(t0,t1);}

C_noret_decl(trf_2015)
static void C_fcall trf_2015(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2015(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2015(t0,t1,t2);}

C_noret_decl(trf_5678)
static void C_fcall trf_5678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5678(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5678(t0,t1,t2);}

C_noret_decl(trf_1668)
static void C_fcall trf_1668(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1668(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1668(t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

/* k2726 in k2723 in k2720 in k2717 in k2714 in k2711 in k2708 in k2705 in k2702 in k2699 in k2696 in k2693 in k2690 in k2687 in k2684 in k2681 in k2678 in k2675 in k2672 in k2669 in k2666 in k2663 in ... */
static void C_ccall f_2728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2728,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2731,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:582: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[805],C_fix(7),C_fix(1),lf[807],C_fix(1),C_SCHEME_FALSE);}

/* k2723 in k2720 in k2717 in k2714 in k2711 in k2708 in k2705 in k2702 in k2699 in k2696 in k2693 in k2690 in k2687 in k2684 in k2681 in k2678 in k2675 in k2672 in k2669 in k2666 in k2663 in k2660 in ... */
static void C_ccall f_2725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2725,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2728,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:580: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[808],C_fix(2),C_fix(1),lf[809],C_SCHEME_TRUE);}

/* k2711 in k2708 in k2705 in k2702 in k2699 in k2696 in k2693 in k2690 in k2687 in k2684 in k2681 in k2678 in k2675 in k2672 in k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in ... */
static void C_ccall f_2713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2713,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2716,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:576: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[816],C_fix(2),C_fix(1),lf[817],C_SCHEME_TRUE);}

/* k2708 in k2705 in k2702 in k2699 in k2696 in k2693 in k2690 in k2687 in k2684 in k2681 in k2678 in k2675 in k2672 in k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in ... */
static void C_ccall f_2710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2710,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2713,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:574: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[808],C_fix(2),C_fix(1),lf[818],C_SCHEME_FALSE);}

/* a4281 in k4099 in k4096 in k4093 in k4090 in k4087 in k4084 in k4081 in k4078 in k4074 in k4071 in k3922 in k3919 in k3916 in k3913 in k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in ... */
static void C_ccall f_4282(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4282,6,t0,t1,t2,t3,t4,t5);}
t6=C_i_length(t5);
t7=C_eqp(C_fix(2),t6);
if(C_truep(t7)){
t8=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t9=C_eqp(*((C_word*)lf[35]+1),lf[34]);
t10=(C_truep(t9)?C_a_i_list1(&a,1,lf[106]):C_a_i_list1(&a,1,lf[107]));
t11=t5;
t12=C_a_i_record4(&a,4,lf[37],lf[38],t10,t11);
t13=C_a_i_list2(&a,2,t4,t12);
t14=t1;
t15=t14;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_a_i_record4(&a,4,lf[37],lf[39],t8,t13));}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}

/* k2717 in k2714 in k2711 in k2708 in k2705 in k2702 in k2699 in k2696 in k2693 in k2690 in k2687 in k2684 in k2681 in k2678 in k2675 in k2672 in k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in ... */
static void C_ccall f_2719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2719,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2722,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:578: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[812],C_fix(2),C_fix(1),lf[813],C_SCHEME_TRUE);}

/* k2714 in k2711 in k2708 in k2705 in k2702 in k2699 in k2696 in k2693 in k2690 in k2687 in k2684 in k2681 in k2678 in k2675 in k2672 in k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in k2651 in ... */
static void C_ccall f_2716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2716,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2719,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:577: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[814],C_fix(2),C_fix(1),lf[815],C_SCHEME_TRUE);}

/* k2699 in k2696 in k2693 in k2690 in k2687 in k2684 in k2681 in k2678 in k2675 in k2672 in k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k2636 in ... */
static void C_ccall f_2701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2701,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2704,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:571: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[823],C_fix(2),C_fix(1),lf[824],C_SCHEME_FALSE);}

/* k2702 in k2699 in k2696 in k2693 in k2690 in k2687 in k2684 in k2681 in k2678 in k2675 in k2672 in k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in ... */
static void C_ccall f_2704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2704,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2707,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:572: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[821],C_fix(2),C_fix(1),lf[822],C_SCHEME_FALSE);}

/* k2705 in k2702 in k2699 in k2696 in k2693 in k2690 in k2687 in k2684 in k2681 in k2678 in k2675 in k2672 in k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in ... */
static void C_ccall f_2707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2707,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2710,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:573: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[819],C_fix(2),C_fix(1),lf[820],C_SCHEME_FALSE);}

/* k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 in k3266 in k3263 in k3260 in k3257 in k3254 in k3251 in k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in ... */
static void C_ccall f_3295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3295,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3298,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:789: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[354],C_fix(18),C_SCHEME_END_OF_LIST);}

/* k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 in k3266 in k3263 in k3260 in k3257 in k3254 in k3251 in k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in ... */
static void C_ccall f_3292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3292,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3295,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:788: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[463],C_fix(18),C_fix(1));}

/* k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 in k3266 in k3263 in k3260 in k3257 in k3254 in k3251 in k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in ... */
static void C_ccall f_3298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3298,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3301,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:791: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[461],C_fix(13),lf[462],C_SCHEME_TRUE);}

/* k3260 in k3257 in k3254 in k3251 in k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 in k3212 in k3209 in k3206 in k3203 in k3200 in k3197 in ... */
static void C_ccall f_3262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3262,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3265,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:775: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[476],C_fix(11),C_fix(3),lf[477],C_SCHEME_FALSE);}

/* k3263 in k3260 in k3257 in k3254 in k3251 in k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 in k3212 in k3209 in k3206 in k3203 in k3200 in ... */
static void C_ccall f_3265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3265,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3268,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:776: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[474],C_fix(11),C_fix(2),lf[475],C_SCHEME_FALSE);}

/* k3266 in k3263 in k3260 in k3257 in k3254 in k3251 in k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 in k3212 in k3209 in k3206 in k3203 in ... */
static void C_ccall f_3268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3268,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3271,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:777: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[472],C_fix(11),C_fix(1),lf[473],C_SCHEME_TRUE);}

/* k4868 in k4865 in k4828 in a4813 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_fcall f_4870(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4870,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
t4=C_a_i_record4(&a,4,lf[37],lf[38],lf[906],t3);
t5=C_a_i_list2(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[4];
f_4836(t6,C_a_i_record4(&a,4,lf[37],lf[39],t2,t5));}
else{
t2=((C_word*)t0)[4];
f_4836(t2,C_SCHEME_FALSE);}}

/* k3278 in k3275 in k3272 in k3269 in k3266 in k3263 in k3260 in k3257 in k3254 in k3251 in k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 in ... */
static void C_ccall f_3280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3280,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3283,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:783: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[464],C_fix(12),lf[467],C_SCHEME_TRUE,C_fix(2));}

/* k5495 in a5492 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_5497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5497,2,t0,t1);}
if(C_truep(C_i_nullp(t1))){
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5523,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* c-platform.scm:259: qnode */
t5=*((C_word*)lf[41]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,C_fix(0));}
else{
t2=C_i_cdr(t1);
if(C_truep(C_i_nullp(t2))){
t3=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t4=C_u_i_car(t1);
t5=C_a_i_list2(&a,2,((C_word*)t0)[2],t4);
t6=((C_word*)t0)[3];
t7=t6;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_record4(&a,4,lf[37],lf[39],t3,t5));}
else{
t3=C_eqp(*((C_word*)lf[35]+1),lf[34]);
if(C_truep(t3)){
t4=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5573,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5575,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:267: fold-inner */
t8=*((C_word*)lf[922]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,t1);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}}

/* k3281 in k3278 in k3275 in k3272 in k3269 in k3266 in k3263 in k3260 in k3257 in k3254 in k3251 in k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in ... */
static void C_ccall f_3283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3283,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3286,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:784: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[463],C_fix(12),lf[466],C_SCHEME_TRUE,C_fix(2));}

/* a5492 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_5493(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5493,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5497,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5644,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:254: remove */
t8=*((C_word*)lf[923]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,t5);}

/* k2081 in k2062 in k1968 in rewrite-apply in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_2083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2083,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record4(&a,4,lf[37],lf[39],((C_word*)t0)[3],t1));}

/* k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 in k3266 in k3263 in k3260 in k3257 in k3254 in k3251 in k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in ... */
static void C_ccall f_3289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3289,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3292,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:787: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[464],C_fix(18),C_fix(0));}

/* k3284 in k3281 in k3278 in k3275 in k3272 in k3269 in k3266 in k3263 in k3260 in k3257 in k3254 in k3251 in k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in ... */
static void C_ccall f_3286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3286,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3289,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:785: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[465],C_fix(12),C_SCHEME_FALSE,C_SCHEME_TRUE,C_fix(1));}

/* k2858 in k2855 in k2852 in k2849 in k2846 in k2843 in k2840 in k2837 in k2834 in k2831 in k2828 in k2825 in k2822 in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in k2798 in k2795 in ... */
static void C_ccall f_2860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2863,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:628: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[723],C_fix(2),C_fix(2),lf[725],C_SCHEME_FALSE);}

/* k5224 in a5218 in k5293 in a5174 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_fcall f_5226(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5226,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5242,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:336: qnode */
t3=*((C_word*)lf[41]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix(1));}
else{
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[37],lf[38],lf[921],t2));}}

/* k1776 in k1767 in eqv?-id in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_fcall f_1778(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1778,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1781,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_1781(t3,t1);}
else{
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_eqp(lf[43],t3);
if(C_truep(t4)){
t5=C_slot(((C_word*)t0)[5],C_fix(2));
t6=C_i_car(t5);
t7=C_i_flonump(t6);
t8=t2;
f_1781(t8,C_i_not(t7));}
else{
t5=t2;
f_1781(t5,C_SCHEME_FALSE);}}}

/* a4503 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in ... */
static void C_ccall f_4504(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4504,6,t0,t1,t2,t3,t4,t5);}
t6=C_i_length(t5);
t7=C_eqp(C_fix(2),t6);
if(C_truep(t7)){
t8=C_i_cadr(t5);
t9=t8;
t10=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t11=t10;
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4534,a[2]=t4,a[3]=t1,a[4]=t11,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t13=C_slot(t9,C_fix(1));
t14=C_eqp(lf[43],t13);
if(C_truep(t14)){
t15=C_eqp(*((C_word*)lf[35]+1),lf[34]);
if(C_truep(t15)){
t16=C_slot(t9,C_fix(2));
t17=C_i_car(t16);
t18=t17;
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4584,a[2]=t18,a[3]=t5,a[4]=t12,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnump(t18))){
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4636,a[2]=t19,tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:947: big-fixnum? */
t21=*((C_word*)lf[272]+1);
((C_proc3)(void*)(*((C_word*)t21+1)))(3,t21,t20,t18);}
else{
t20=t19;
f_4584(t20,C_SCHEME_FALSE);}}
else{
t19=t12;
f_4534(t19,C_SCHEME_FALSE);}}
else{
t16=t12;
f_4534(t16,C_SCHEME_FALSE);}}
else{
t15=t12;
f_4534(t15,C_SCHEME_FALSE);}}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}

/* k1906 in eqv?-id in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_1908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1908,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
f_1769(t3,C_a_i_record4(&a,4,lf[37],lf[39],((C_word*)t0)[4],t2));}

/* k2873 in k2870 in k2867 in k2864 in k2861 in k2858 in k2855 in k2852 in k2849 in k2846 in k2843 in k2840 in k2837 in k2834 in k2831 in k2828 in k2825 in k2822 in k2819 in k2816 in k2813 in k2810 in ... */
static void C_ccall f_2875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2875,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2878,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:633: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[717],C_fix(2),C_fix(2),lf[718],C_SCHEME_TRUE);}

/* k2870 in k2867 in k2864 in k2861 in k2858 in k2855 in k2852 in k2849 in k2846 in k2843 in k2840 in k2837 in k2834 in k2831 in k2828 in k2825 in k2822 in k2819 in k2816 in k2813 in k2810 in k2807 in ... */
static void C_ccall f_2872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2872,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2875,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:632: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[717],C_fix(2),C_fix(2),lf[719],C_SCHEME_FALSE);}

/* k2876 in k2873 in k2870 in k2867 in k2864 in k2861 in k2858 in k2855 in k2852 in k2849 in k2846 in k2843 in k2840 in k2837 in k2834 in k2831 in k2828 in k2825 in k2822 in k2819 in k2816 in k2813 in ... */
static void C_ccall f_2878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2878,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2881,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:634: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[715],C_fix(2),C_fix(2),lf[716],C_SCHEME_TRUE);}

/* k2059 in k1968 in rewrite-apply in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_2061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2061,2,t0,t1);}
t2=C_i_cdr(t1);
t3=t2;
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=*((C_word*)lf[41]+1);
t9=C_slot(((C_word*)t0)[2],C_fix(2));
t10=C_i_car(t9);
t11=C_i_check_list_2(t10,lf[46]);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2013,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2015,a[2]=t7,a[3]=t14,a[4]=t5,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_2015(t16,t12,t10);}

/* k2062 in k1968 in rewrite-apply in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_fcall f_2064(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2064,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2083,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_a_i_record4(&a,4,lf[37],lf[49],lf[50],C_SCHEME_END_OF_LIST);
/* c-platform.scm:457: cons* */
t6=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,t5,((C_word*)t0)[3],((C_word*)t0)[4]);}}

/* k1779 in k1776 in k1767 in eqv?-id in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_fcall f_1781(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1781,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
t4=C_a_i_record4(&a,4,lf[37],lf[38],lf[42],t3);
t5=C_a_i_list2(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[4];
t7=t6;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_record4(&a,4,lf[37],lf[39],t2,t5));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3581 in k3578 in k3575 in k3572 in k3569 in k3566 in k3563 in ... */
static void C_ccall f_3628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3628,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3631,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:976: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[231],C_fix(17),C_fix(1),lf[232],lf[233]);}

/* k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3581 in k3578 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in ... */
static void C_ccall f_3625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3625,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3628,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:975: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[234],C_fix(17),C_fix(1),lf[235],lf[236]);}

/* k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3581 in k3578 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in ... */
static void C_ccall f_3622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3622,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3625,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:974: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[237],C_fix(17),C_fix(1),lf[238]);}

/* k2861 in k2858 in k2855 in k2852 in k2849 in k2846 in k2843 in k2840 in k2837 in k2834 in k2831 in k2828 in k2825 in k2822 in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in k2798 in ... */
static void C_ccall f_2863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2866,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:629: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[723],C_fix(2),C_fix(2),lf[724],C_SCHEME_TRUE);}

/* k2867 in k2864 in k2861 in k2858 in k2855 in k2852 in k2849 in k2846 in k2843 in k2840 in k2837 in k2834 in k2831 in k2828 in k2825 in k2822 in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in ... */
static void C_ccall f_2869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2869,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2872,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:631: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[720],C_fix(2),C_fix(3),lf[721],C_SCHEME_TRUE);}

/* k2864 in k2861 in k2858 in k2855 in k2852 in k2849 in k2846 in k2843 in k2840 in k2837 in k2834 in k2831 in k2828 in k2825 in k2822 in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in ... */
static void C_ccall f_2866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2869,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:630: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[720],C_fix(2),C_fix(3),lf[722],C_SCHEME_FALSE);}

/* k5240 in k5224 in a5218 in k5293 in a5174 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_5242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5242,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[37],lf[38],lf[920],t2));}

/* k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3581 in k3578 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in ... */
static void C_ccall f_3616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3619,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:972: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[241],C_fix(17),C_fix(1),lf[242]);}

/* k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3581 in k3578 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in ... */
static void C_ccall f_3613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3613,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3616,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:971: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[243],C_fix(17),C_fix(1),lf[244]);}

/* k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3581 in k3578 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in ... */
static void C_ccall f_3610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3610,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3613,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:970: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[245],C_fix(17),C_fix(1),lf[246]);}

/* k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in k3338 in k3335 in k3332 in k3329 in k3326 in k3323 in k3320 in k3317 in k3314 in ... */
static void C_ccall f_3379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3382,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:822: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[416],C_fix(13),lf[417],C_SCHEME_TRUE);}

/* k3374 in k3371 in k3368 in k3365 in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in k3338 in k3335 in k3332 in k3329 in k3326 in k3323 in k3320 in k3317 in k3314 in k3311 in ... */
static void C_ccall f_3376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3379,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:821: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[418],C_fix(13),lf[419],C_SCHEME_TRUE);}

/* k2042 in map-loop435 in k2059 in k1968 in rewrite-apply in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_2044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2044,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_2015(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_2015(t6,((C_word*)t0)[5],t5);}}

/* k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3581 in k3578 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in ... */
static void C_ccall f_3619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3622,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:973: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[239],C_fix(17),C_fix(1),lf[240]);}

/* k4532 in a4503 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in ... */
static void C_fcall f_4534(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4534,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=C_a_i_list2(&a,2,((C_word*)t0)[2],t2);
t4=((C_word*)t0)[3];
t5=t4;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[37],lf[39],((C_word*)t0)[4],t3));}
else{
t2=C_eqp(*((C_word*)lf[35]+1),lf[34]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
t4=C_a_i_record4(&a,4,lf[37],lf[38],lf[268],t3);
t5=C_a_i_list2(&a,2,((C_word*)t0)[2],t4);
t6=((C_word*)t0)[3];
t7=t6;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_record4(&a,4,lf[37],lf[39],((C_word*)t0)[4],t5));}
else{
t3=C_a_i_list2(&a,2,lf[269],*((C_word*)lf[9]+1));
t4=((C_word*)t0)[5];
t5=C_a_i_record4(&a,4,lf[37],lf[40],t3,t4);
t6=C_a_i_list2(&a,2,((C_word*)t0)[2],t5);
t7=((C_word*)t0)[3];
t8=t7;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_record4(&a,4,lf[37],lf[39],((C_word*)t0)[4],t6));}}}

/* k3368 in k3365 in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in k3338 in k3335 in k3332 in k3329 in k3326 in k3323 in k3320 in k3317 in k3314 in k3311 in k3308 in k3305 in ... */
static void C_ccall f_3370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3373,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:819: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[422],C_fix(13),lf[423],C_SCHEME_TRUE);}

/* k3371 in k3368 in k3365 in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in k3338 in k3335 in k3332 in k3329 in k3326 in k3323 in k3320 in k3317 in k3314 in k3311 in k3308 in ... */
static void C_ccall f_3373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3376,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:820: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[420],C_fix(13),lf[421],C_SCHEME_TRUE);}

/* k2822 in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in k2798 in k2795 in k2792 in k2789 in k2786 in k2783 in k2780 in k2777 in k2774 in k2771 in k2768 in k2765 in k2762 in k2759 in ... */
static void C_ccall f_2824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2827,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:616: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[744],C_fix(2),C_fix(1),lf[745],C_SCHEME_TRUE);}

/* k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in k2798 in k2795 in k2792 in k2789 in k2786 in k2783 in k2780 in k2777 in k2774 in k2771 in k2768 in k2765 in k2762 in k2759 in k2756 in ... */
static void C_ccall f_2821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2824,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:615: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[746],C_fix(2),C_fix(1),lf[747],C_SCHEME_FALSE);}

/* k2837 in k2834 in k2831 in k2828 in k2825 in k2822 in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in k2798 in k2795 in k2792 in k2789 in k2786 in k2783 in k2780 in k2777 in k2774 in ... */
static void C_ccall f_2839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2839,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2842,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:621: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[736],C_fix(2),C_fix(1),lf[737],C_SCHEME_FALSE);}

/* k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3581 in k3578 in k3575 in k3572 in k3569 in ... */
static void C_ccall f_3634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3637,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:978: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[227],C_fix(17),C_fix(1),lf[228]);}

/* k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3581 in k3578 in k3575 in k3572 in ... */
static void C_ccall f_3637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3640,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:979: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[225],C_fix(17),C_fix(2),lf[226]);}

/* k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3581 in k3578 in k3575 in k3572 in k3569 in k3566 in ... */
static void C_ccall f_3631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3634,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:977: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[229],C_fix(17),C_fix(1),lf[230]);}

/* k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in k3338 in k3335 in k3332 in ... */
static void C_ccall f_3397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3400,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:831: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[401],C_fix(2),C_fix(1),lf[402],C_SCHEME_TRUE);}

/* k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in ... */
static void C_ccall f_3664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3664,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3667,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:988: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[207],C_fix(17),C_fix(1),lf[208]);}

/* k2825 in k2822 in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in k2798 in k2795 in k2792 in k2789 in k2786 in k2783 in k2780 in k2777 in k2774 in k2771 in k2768 in k2765 in k2762 in ... */
static void C_ccall f_2827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2827,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2830,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:617: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[742],C_fix(2),C_fix(1),lf[743],C_SCHEME_TRUE);}

/* k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in k3338 in k3335 in k3332 in k3329 in k3326 in ... */
static void C_ccall f_3391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3391,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3394,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:828: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[406],C_fix(17),C_fix(1),lf[407],lf[408]);}

/* k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in ... */
static void C_ccall f_3667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3667,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3670,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:989: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[205],C_fix(17),C_fix(2),lf[206]);}

/* k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in k3338 in k3335 in k3332 in k3329 in ... */
static void C_ccall f_3394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3397,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:829: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[403],C_fix(17),C_fix(1),lf[404],lf[405]);}

/* k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in ... */
static void C_ccall f_3661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3661,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3664,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:987: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[209],C_fix(17),C_fix(1),lf[210]);}

/* k3365 in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in k3338 in k3335 in k3332 in k3329 in k3326 in k3323 in k3320 in k3317 in k3314 in k3311 in k3308 in k3305 in k3302 in ... */
static void C_ccall f_3367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3367,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3370,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:818: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[424],C_fix(13),lf[425],C_SCHEME_TRUE);}

/* k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in ... */
static void C_ccall f_3655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3655,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3658,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:985: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[213],C_fix(17),C_fix(1),lf[214]);}

/* k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in ... */
static void C_ccall f_3652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3652,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3655,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:984: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[215],C_fix(17),C_fix(2),lf[216]);}

/* k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in ... */
static void C_ccall f_3658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3658,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3661,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:986: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[211],C_fix(17),C_fix(1),lf[212]);}

/* k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in k3338 in k3335 in k3332 in k3329 in k3326 in k3323 in k3320 in k3317 in k3314 in k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in ... */
static void C_ccall f_3361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3361,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3364,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:816: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[428],C_fix(13),lf[429],C_SCHEME_TRUE);}

/* k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in k3338 in k3335 in k3332 in k3329 in k3326 in k3323 in k3320 in k3317 in k3314 in k3311 in k3308 in k3305 in k3302 in k3299 in ... */
static void C_ccall f_3364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3364,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3367,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:817: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[426],C_fix(13),lf[427],C_SCHEME_TRUE);}

/* k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3581 in k3578 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in ... */
static void C_ccall f_3607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3610,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:969: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[247],C_fix(17),C_fix(2),lf[248]);}

/* k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3581 in k3578 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in ... */
static void C_ccall f_3601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3601,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3604,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:967: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[252],C_fix(17),C_fix(3),lf[253]);}

/* k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3581 in k3578 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in ... */
static void C_ccall f_3604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3604,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3607,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:968: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[249],C_fix(17),C_fix(2),lf[250],lf[251]);}

/* a4213 in k4129 in k4126 in k4123 in k4120 in k4117 in k4114 in k4111 in k4108 in k4105 in k4102 in k4099 in k4096 in k4093 in k4090 in k4087 in k4084 in k4081 in k4078 in k4074 in k4071 in k3922 in ... */
static void C_ccall f_4214(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4214,6,t0,t1,t2,t3,t4,t5);}
t6=C_i_length(t5);
t7=C_eqp(C_fix(3),t6);
if(C_truep(t7)){
t8=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t9=C_i_car(t5);
t10=C_i_cadr(t5);
t11=C_a_i_list2(&a,2,t9,t10);
t12=C_a_i_record4(&a,4,lf[37],lf[40],lf[83],t11);
t13=C_i_caddr(t5);
t14=C_a_i_list2(&a,2,t12,t13);
t15=C_a_i_record4(&a,4,lf[37],lf[40],lf[84],t14);
t16=C_a_i_list2(&a,2,t4,t15);
t17=t1;
t18=t17;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,C_a_i_record4(&a,4,lf[37],lf[39],t8,t16));}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}

/* k1598 */
static void C_ccall f_1600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1600,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1603,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_1748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1748,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1751,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5044,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:381: op1 */
f_1668(t3,lf[909],lf[910],lf[911]);}

/* k2505 in k2534 in k2538 in k2459 in k2456 in k2453 in k2426 in rewrite-c-w-v in k2390 in k2387 in k2355 in k2352 in k2349 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2328 in k2185 in k2182 in ... */
static void C_ccall f_2507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2507,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_record4(&a,4,lf[37],lf[39],((C_word*)t0)[3],t2);
t4=C_a_i_list2(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[5];
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_record4(&a,4,lf[37],lf[65],((C_word*)t0)[6],t4));}

/* k1738 */
static void C_ccall f_1740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1740,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_record4(&a,4,lf[37],lf[40],((C_word*)t0)[3],t2);
t4=C_a_i_list2(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[5];
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_record4(&a,4,lf[37],lf[39],((C_word*)t0)[6],t4));}

/* eqv?-id in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_1753(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1753,6,t0,t1,t2,t3,t4,t5);}
t6=C_i_length(t5);
t7=C_eqp(t6,C_fix(2));
if(C_truep(t7)){
t8=C_i_car(t5);
t9=t8;
t10=C_i_cadr(t5);
t11=t10;
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1769,a[2]=t1,a[3]=t5,a[4]=t4,a[5]=t11,a[6]=t9,tmp=(C_word)a,a+=7,tmp);
t13=C_slot(t9,C_fix(1));
t14=C_eqp(lf[44],t13);
if(C_truep(t14)){
t15=C_slot(t11,C_fix(1));
t16=C_eqp(lf[44],t15);
if(C_truep(t16)){
t17=C_slot(t9,C_fix(2));
t18=C_slot(t11,C_fix(2));
if(C_truep(C_i_equalp(t17,t18))){
t19=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t20=t19;
t21=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1908,a[2]=t4,a[3]=t12,a[4]=t20,tmp=(C_word)a,a+=5,tmp);
/* c-platform.scm:393: qnode */
t22=*((C_word*)lf[41]+1);
((C_proc3)(void*)(*((C_word*)t22+1)))(3,t22,t21,C_SCHEME_TRUE);}
else{
t19=t12;
f_1769(t19,C_SCHEME_FALSE);}}
else{
t17=t12;
f_1769(t17,C_SCHEME_FALSE);}}
else{
t15=t12;
f_1769(t15,C_SCHEME_FALSE);}}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}

/* k2852 in k2849 in k2846 in k2843 in k2840 in k2837 in k2834 in k2831 in k2828 in k2825 in k2822 in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in k2798 in k2795 in k2792 in k2789 in ... */
static void C_ccall f_2854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2857,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:626: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[728],C_fix(2),C_fix(1),lf[729],C_SCHEME_TRUE);}

/* k2849 in k2846 in k2843 in k2840 in k2837 in k2834 in k2831 in k2828 in k2825 in k2822 in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in k2798 in k2795 in k2792 in k2789 in k2786 in ... */
static void C_ccall f_2851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2854,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:625: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[730],C_fix(2),C_fix(1),lf[731],C_SCHEME_TRUE);}

/* k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_1751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1751,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1753,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1952,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:401: rewrite */
t4=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[799],C_fix(8),t2);}

/* k3269 in k3266 in k3263 in k3260 in k3257 in k3254 in k3251 in k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 in k3212 in k3209 in k3206 in ... */
static void C_ccall f_3271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3271,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3274,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:778: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[470],C_fix(11),C_fix(1),lf[471],C_SCHEME_TRUE);}

/* k3272 in k3269 in k3266 in k3263 in k3260 in k3257 in k3254 in k3251 in k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 in k3212 in k3209 in ... */
static void C_ccall f_3274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3274,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3277,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:780: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[468],C_fix(11),C_fix(3),lf[305],C_SCHEME_FALSE);}

/* k1604 in k1601 in k1598 */
static void C_ccall f_1606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1606,2,t0,t1);}
t2=C_set_block_item(lf[0] /* ##compiler#default-optimization-passes */,0,C_fix(3));
t3=C_mutate2((C_word*)lf[1]+1 /* (set! ##compiler#default-declarations ...) */,lf[2]);
t4=C_mutate2((C_word*)lf[3]+1 /* (set! ##compiler#default-debugging-declarations ...) */,lf[4]);
t5=C_mutate2((C_word*)lf[5]+1 /* (set! ##compiler#default-profiling-declarations ...) */,lf[6]);
t6=C_mutate2((C_word*)lf[7]+1 /* (set! ##compiler#units-used-by-default ...) */,lf[8]);
t7=C_set_block_item(lf[9] /* ##compiler#words-per-flonum */,0,C_fix(4));
t8=C_set_block_item(lf[10] /* ##compiler#parameter-limit */,0,C_fix(1024));
t9=C_set_block_item(lf[11] /* small-parameter-limit */,0,C_fix(128));
t10=C_mutate2((C_word*)lf[12]+1 /* (set! ##compiler#unlikely-variables ...) */,lf[13]);
t11=C_mutate2((C_word*)lf[14]+1 /* (set! ##compiler#eq-inline-operator ...) */,lf[15]);
t12=C_mutate2((C_word*)lf[16]+1 /* (set! ##compiler#membership-test-operators ...) */,lf[17]);
t13=C_set_block_item(lf[18] /* ##compiler#membership-unfold-limit */,0,C_fix(20));
t14=C_mutate2((C_word*)lf[19]+1 /* (set! ##compiler#target-include-file ...) */,lf[20]);
t15=C_mutate2((C_word*)lf[21]+1 /* (set! ##compiler#valid-compiler-options ...) */,lf[22]);
t16=C_mutate2((C_word*)lf[23]+1 /* (set! ##compiler#valid-compiler-options-with-argument ...) */,lf[24]);
t17=C_mutate2((C_word*)lf[25]+1 /* (set! ##compiler#default-standard-bindings ...) */,lf[26]);
t18=C_mutate2((C_word*)lf[27]+1 /* (set! ##compiler#default-extended-bindings ...) */,lf[28]);
t19=C_mutate2((C_word*)lf[29]+1 /* (set! ##compiler#internal-bindings ...) */,lf[30]);
t20=C_mutate2((C_word*)lf[31]+1 /* (set! ##compiler#non-foldable-bindings ...) */,lf[32]);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1629,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5703,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:226: lset-union */
t23=*((C_word*)lf[936]+1);
((C_proc5)(void*)(*((C_word*)t23+1)))(5,t23,t22,*((C_word*)lf[803]+1),*((C_word*)lf[25]+1),*((C_word*)lf[27]+1));}

/* k3275 in k3272 in k3269 in k3266 in k3263 in k3260 in k3257 in k3254 in k3251 in k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 in k3212 in ... */
static void C_ccall f_3277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3277,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3280,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:781: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[468],C_fix(2),C_fix(3),lf[469],C_SCHEME_TRUE);}

/* k1601 in k1598 */
static void C_ccall f_1603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1603,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1606,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_chicken_2dsyntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1767 in eqv?-id in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_fcall f_1769(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1769,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1778,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_slot(((C_word*)t0)[6],C_fix(1));
t4=C_eqp(lf[43],t3);
if(C_truep(t4)){
t5=C_slot(((C_word*)t0)[6],C_fix(2));
t6=C_i_car(t5);
t7=C_i_flonump(t6);
t8=t2;
f_1778(t8,C_i_not(t7));}
else{
t5=t2;
f_1778(t5,C_SCHEME_FALSE);}}}

/* k2843 in k2840 in k2837 in k2834 in k2831 in k2828 in k2825 in k2822 in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in k2798 in k2795 in k2792 in k2789 in k2786 in k2783 in k2780 in ... */
static void C_ccall f_2845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2848,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:623: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[732],C_fix(2),C_fix(1),lf[734],C_SCHEME_TRUE);}

/* k2840 in k2837 in k2834 in k2831 in k2828 in k2825 in k2822 in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in k2798 in k2795 in k2792 in k2789 in k2786 in k2783 in k2780 in k2777 in ... */
static void C_ccall f_2842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2842,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2845,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:622: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[732],C_fix(2),C_fix(1),lf[735],C_SCHEME_FALSE);}

/* k2855 in k2852 in k2849 in k2846 in k2843 in k2840 in k2837 in k2834 in k2831 in k2828 in k2825 in k2822 in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in k2798 in k2795 in k2792 in ... */
static void C_ccall f_2857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2857,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2860,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:627: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[726],C_fix(2),C_fix(1),lf[727],C_SCHEME_TRUE);}

/* k2834 in k2831 in k2828 in k2825 in k2822 in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in k2798 in k2795 in k2792 in k2789 in k2786 in k2783 in k2780 in k2777 in k2774 in k2771 in ... */
static void C_ccall f_2836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2836,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2839,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:620: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[736],C_fix(2),C_fix(1),lf[738],C_SCHEME_TRUE);}

/* k2831 in k2828 in k2825 in k2822 in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in k2798 in k2795 in k2792 in k2789 in k2786 in k2783 in k2780 in k2777 in k2774 in k2771 in k2768 in ... */
static void C_ccall f_2833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2833,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2836,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:619: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[736],C_fix(2),C_fix(1),lf[739],C_SCHEME_FALSE);}

/* k2828 in k2825 in k2822 in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in k2798 in k2795 in k2792 in k2789 in k2786 in k2783 in k2780 in k2777 in k2774 in k2771 in k2768 in k2765 in ... */
static void C_ccall f_2830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2830,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2833,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:618: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[740],C_fix(2),C_fix(1),lf[741],C_SCHEME_TRUE);}

/* k2846 in k2843 in k2840 in k2837 in k2834 in k2831 in k2828 in k2825 in k2822 in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in k2798 in k2795 in k2792 in k2789 in k2786 in k2783 in ... */
static void C_ccall f_2848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2848,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2851,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:624: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[732],C_fix(2),C_fix(1),lf[733],C_SCHEME_FALSE);}

/* k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3581 in k3578 in ... */
static void C_ccall f_3643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3643,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3646,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:981: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[221],C_fix(17),C_fix(1),lf[222]);}

/* k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3581 in ... */
static void C_ccall f_3646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3649,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:982: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[219],C_fix(17),C_fix(1),lf[220]);}

/* k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in ... */
static void C_ccall f_3649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3652,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:983: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[217],C_fix(17),C_fix(1),lf[218]);}

/* k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3581 in k3578 in k3575 in ... */
static void C_ccall f_3640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3643,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:980: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[223],C_fix(17),C_fix(1),lf[224]);}

/* k4093 in k4090 in k4087 in k4084 in k4081 in k4078 in k4074 in k4071 in k3922 in k3919 in k3916 in k3913 in k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in k3755 in k3752 in k3749 in ... */
static void C_ccall f_4095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4095,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4098,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1136: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[112],C_fix(3),lf[113],C_fix(0));}

/* k4090 in k4087 in k4084 in k4081 in k4078 in k4074 in k4071 in k3922 in k3919 in k3916 in k3913 in k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in k3755 in k3752 in k3749 in k3746 in ... */
static void C_ccall f_4092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4092,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4095,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1135: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[114],C_fix(3),lf[103],C_fix(0));}

/* k4096 in k4093 in k4090 in k4087 in k4084 in k4081 in k4078 in k4074 in k4071 in k3922 in k3919 in k3916 in k3913 in k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in k3755 in k3752 in ... */
static void C_ccall f_4098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4098,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4101,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4332,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:1138: rewrite */
t4=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[111],C_fix(8),t3);}

/* k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_1629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1629,2,t0,t1);}
t2=C_mutate2((C_word*)lf[33]+1 /* (set! ##compiler#foldable-bindings ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1651,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5678,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_5678(t7,t3,lf[934]);}

/* k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in k3755 in k3752 in k3749 in k3746 in k3743 in k3740 in k3737 in k3734 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in ... */
static void C_ccall f_3778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3778,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3780,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3915,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:1061: rewrite */
t4=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[129],C_fix(8),t2);}

/* k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in k3755 in k3752 in k3749 in k3746 in k3743 in k3740 in k3737 in k3734 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in ... */
static void C_ccall f_3775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3775,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3778,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1033: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[130],C_fix(7),C_fix(1),lf[131],C_fix(1),C_SCHEME_FALSE);}

/* k3770 in k3767 in k3764 in k3761 in k3758 in k3755 in k3752 in k3749 in k3746 in k3743 in k3740 in k3737 in k3734 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in ... */
static void C_ccall f_3772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3772,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3775,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1032: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[132],C_fix(7),C_fix(1),lf[133],C_fix(1),C_SCHEME_FALSE);}

/* k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in k3338 in k3335 in k3332 in k3329 in k3326 in k3323 in ... */
static void C_ccall f_3388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3388,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3391,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:826: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[409],C_fix(14),lf[34],C_fix(2),lf[410],lf[411]);}

/* rewrite-make-vector in k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in k3755 in k3752 in k3749 in k3746 in k3743 in k3740 in k3737 in k3734 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in ... */
static void C_ccall f_3780(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3780,6,t0,t1,t2,t3,t4,t5);}
t6=C_i_length(t5);
if(C_truep(C_i_pairp(t5))){
t7=t5;
t8=C_u_i_car(t7);
t9=C_slot(t8,C_fix(1));
t10=C_eqp(lf[43],t9);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3800,a[2]=t8,a[3]=t5,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-platform.scm:1043: gensym */
t12=*((C_word*)lf[67]+1);
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,t11);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}

/* k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in k3338 in k3335 in k3332 in k3329 in k3326 in k3323 in k3320 in k3317 in ... */
static void C_ccall f_3382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3382,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3385,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:824: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[406],C_fix(14),lf[34],C_fix(1),lf[414],lf[415]);}

/* k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in k3338 in k3335 in k3332 in k3329 in k3326 in k3323 in k3320 in ... */
static void C_ccall f_3385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3388,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:825: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[403],C_fix(14),lf[34],C_fix(1),lf[412],lf[413]);}

/* k5105 in k5087 in a5049 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_5107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5107,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_record4(&a,4,lf[37],lf[38],lf[916],t2);
t4=C_a_i_list2(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[4];
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_record4(&a,4,lf[37],lf[39],((C_word*)t0)[5],t4));}

/* k4388 in a4331 in k4096 in k4093 in k4090 in k4087 in k4084 in k4081 in k4078 in k4074 in k4071 in k3922 in k3919 in k3916 in k3913 in k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in ... */
static void C_ccall f_4390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4365(t2,C_i_not(t1));}

/* k3798 in rewrite-make-vector in k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in k3755 in k3752 in k3749 in k3746 in k3743 in k3740 in k3737 in k3734 in k3731 in k3728 in k3725 in k3722 in k3719 in ... */
static void C_ccall f_3800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3800,2,t0,t1);}
t2=t1;
t3=C_slot(((C_word*)t0)[2],C_fix(2));
t4=C_i_car(t3);
t5=t4;
if(C_truep(C_fixnump(t5))){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3815,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-platform.scm:1046: <= */
C_less_or_equal_p(5,0,t6,C_fix(0),t5,C_fix(32));}
else{
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k2118 in k1968 in rewrite-apply in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_2120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2120,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=C_a_i_record4(&a,4,lf[37],lf[49],lf[53],C_SCHEME_END_OF_LIST);
t4=C_i_cadr(((C_word*)t0)[2]);
t5=C_a_i_list3(&a,3,t3,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[4];
f_2064(t6,C_a_i_record4(&a,4,lf[37],lf[39],t2,t5));}
else{
t2=((C_word*)t0)[4];
f_2064(t2,C_SCHEME_FALSE);}}

/* k5042 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_5044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-platform.scm:381: rewrite */
t2=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[908],C_fix(8),t1);}

/* k5046 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_5048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-platform.scm:380: rewrite */
t2=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[912],C_fix(8),t1);}

/* k3308 in k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 in k3266 in k3263 in k3260 in k3257 in k3254 in k3251 in k3248 in k3245 in ... */
static void C_ccall f_3310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3313,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:796: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[442],C_fix(16),C_fix(2),lf[457],C_SCHEME_TRUE,C_fix(4));}

/* k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 in k3266 in k3263 in k3260 in k3257 in k3254 in k3251 in k3248 in ... */
static void C_ccall f_3313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3313,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3316,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:797: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[455],C_fix(16),C_fix(1),lf[456],C_SCHEME_TRUE,C_fix(4));}

/* k3314 in k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 in k3266 in k3263 in k3260 in k3257 in k3254 in k3251 in ... */
static void C_ccall f_3316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3316,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3319,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:799: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[440],C_fix(17),C_fix(2),lf[454]);}

/* k3317 in k3314 in k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 in k3266 in k3263 in k3260 in k3257 in k3254 in ... */
static void C_ccall f_3319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3319,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3322,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:800: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[438],C_fix(17),C_fix(2),lf[453]);}

/* k5215 in k5293 in a5174 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_5217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5217,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[37],lf[39],((C_word*)t0)[4],t2));}

/* a5218 in k5293 in a5174 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_5219(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5219,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5226,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=t3;
t6=C_slot(t5,C_fix(1));
t7=C_eqp(lf[43],t6);
if(C_truep(t7)){
t8=t3;
t9=C_slot(t8,C_fix(2));
t10=C_i_car(t9);
t11=t4;
f_5226(t11,C_eqp(C_fix(2),t10));}
else{
t8=t4;
f_5226(t8,C_SCHEME_FALSE);}}

/* k3338 in k3335 in k3332 in k3329 in k3326 in k3323 in k3320 in k3317 in k3314 in k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in ... */
static void C_ccall f_3340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3340,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3343,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:808: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[442],C_fix(13),lf[443],C_SCHEME_TRUE);}

/* k3347 in k3344 in k3341 in k3338 in k3335 in k3332 in k3329 in k3326 in k3323 in k3320 in k3317 in k3314 in k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in ... */
static void C_ccall f_3349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3349,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3352,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:811: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[436],C_fix(13),lf[437],C_SCHEME_TRUE);}

/* k3341 in k3338 in k3335 in k3332 in k3329 in k3326 in k3323 in k3320 in k3317 in k3314 in k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in ... */
static void C_ccall f_3343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3346,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:809: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[440],C_fix(13),lf[441],C_SCHEME_TRUE);}

/* k3344 in k3341 in k3338 in k3335 in k3332 in k3329 in k3326 in k3323 in k3320 in k3317 in k3314 in k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in ... */
static void C_ccall f_3346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3349,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:810: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[438],C_fix(13),lf[439],C_SCHEME_TRUE);}

/* k3813 in k3798 in rewrite-make-vector in k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in k3755 in k3752 in k3749 in k3746 in k3743 in k3740 in k3737 in k3734 in k3731 in k3728 in k3725 in k3722 in ... */
static void C_ccall f_3815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3815,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_i_pairp(t3);
t5=(C_truep(t4)?C_i_cadr(((C_word*)t0)[2]):C_a_i_record4(&a,4,lf[37],lf[74],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));
t6=t5;
t7=C_a_i_list1(&a,1,((C_word*)t0)[3]);
t8=t7;
t9=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t10=t9;
t11=C_a_i_plus(&a,2,((C_word*)t0)[4],C_fix(1));
t12=C_a_i_list2(&a,2,lf[75],t11);
t13=t12;
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3868,a[2]=t13,a[3]=((C_word*)t0)[5],a[4]=t10,a[5]=t6,a[6]=((C_word*)t0)[6],a[7]=t8,tmp=(C_word)a,a+=8,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3870,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1060: list-tabulate */
t16=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t14,((C_word*)t0)[4],t15);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4074 in k4071 in k3922 in k3919 in k3916 in k3913 in k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in k3755 in k3752 in k3749 in k3746 in k3743 in k3740 in k3737 in k3734 in k3731 in ... */
static void C_ccall f_4076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4076,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4080,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4419,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:1117: rewrite */
t4=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[122],C_fix(8),t3);}

/* k4071 in k3922 in k3919 in k3916 in k3913 in k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in k3755 in k3752 in k3749 in k3746 in k3743 in k3740 in k3737 in k3734 in k3731 in k3728 in ... */
static void C_ccall f_4073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4073,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4076,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1088: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[123],C_fix(8),((C_word*)t0)[3]);}

/* k4084 in k4081 in k4078 in k4074 in k4071 in k3922 in k3919 in k3916 in k3913 in k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in k3755 in k3752 in k3749 in k3746 in k3743 in k3740 in ... */
static void C_ccall f_4086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4089,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1133: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[116],C_fix(3),lf[117],C_fix(0));}

/* k4081 in k4078 in k4074 in k4071 in k3922 in k3919 in k3916 in k3913 in k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in k3755 in k3752 in k3749 in k3746 in k3743 in k3740 in k3737 in ... */
static void C_ccall f_4083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4083,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4086,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1132: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[118],C_fix(3),lf[119],C_SCHEME_FALSE);}

/* k4078 in k4074 in k4071 in k3922 in k3919 in k3916 in k3913 in k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in k3755 in k3752 in k3749 in k3746 in k3743 in k3740 in k3737 in k3734 in ... */
static void C_ccall f_4080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4080,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4083,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1131: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[120],C_fix(3),lf[119],C_fix(0));}

/* k3320 in k3317 in k3314 in k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 in k3266 in k3263 in k3260 in k3257 in ... */
static void C_ccall f_3322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3322,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3325,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:801: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[436],C_fix(17),C_fix(2),lf[452]);}

/* k3326 in k3323 in k3320 in k3317 in k3314 in k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 in k3266 in k3263 in ... */
static void C_ccall f_3328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3328,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3331,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:803: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[432],C_fix(17),C_fix(2),lf[450]);}

/* k3323 in k3320 in k3317 in k3314 in k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 in k3266 in k3263 in k3260 in ... */
static void C_ccall f_3325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3325,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3328,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:802: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[434],C_fix(17),C_fix(2),lf[451]);}

/* k4087 in k4084 in k4081 in k4078 in k4074 in k4071 in k3922 in k3919 in k3916 in k3913 in k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in k3755 in k3752 in k3749 in k3746 in k3743 in ... */
static void C_ccall f_4089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4089,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4092,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1134: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[115],C_fix(3),lf[100],C_fix(0));}

/* k3350 in k3347 in k3344 in k3341 in k3338 in k3335 in k3332 in k3329 in k3326 in k3323 in k3320 in k3317 in k3314 in k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in ... */
static void C_ccall f_3352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3352,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3355,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:812: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[434],C_fix(13),lf[435],C_SCHEME_TRUE);}

/* k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in k3338 in k3335 in k3332 in k3329 in k3326 in k3323 in k3320 in k3317 in k3314 in k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in k3293 in ... */
static void C_ccall f_3358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3358,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3361,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:815: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[430],C_fix(13),lf[431],C_SCHEME_TRUE);}

/* k3353 in k3350 in k3347 in k3344 in k3341 in k3338 in k3335 in k3332 in k3329 in k3326 in k3323 in k3320 in k3317 in k3314 in k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in ... */
static void C_ccall f_3355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3355,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3358,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:813: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[432],C_fix(13),lf[433],C_SCHEME_TRUE);}

/* k3866 in k3813 in k3798 in rewrite-make-vector in k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in k3755 in k3752 in k3749 in k3746 in k3743 in k3740 in k3737 in k3734 in k3731 in k3728 in k3725 in ... */
static void C_ccall f_3868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3868,2,t0,t1);}
t2=C_a_i_record4(&a,4,lf[37],lf[40],((C_word*)t0)[2],t1);
t3=C_a_i_list2(&a,2,((C_word*)t0)[3],t2);
t4=C_a_i_record4(&a,4,lf[37],lf[39],((C_word*)t0)[4],t3);
t5=C_a_i_list2(&a,2,((C_word*)t0)[5],t4);
t6=((C_word*)t0)[6];
t7=t6;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_record4(&a,4,lf[37],lf[65],((C_word*)t0)[7],t5));}

/* k3329 in k3326 in k3323 in k3320 in k3317 in k3314 in k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 in k3266 in ... */
static void C_ccall f_3331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3331,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3334,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:805: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[448],C_fix(13),lf[449],C_SCHEME_TRUE);}

/* k3335 in k3332 in k3329 in k3326 in k3323 in k3320 in k3317 in k3314 in k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in ... */
static void C_ccall f_3337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3337,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3340,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:807: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[444],C_fix(13),lf[445],C_SCHEME_TRUE);}

/* k3332 in k3329 in k3326 in k3323 in k3320 in k3317 in k3314 in k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 in ... */
static void C_ccall f_3334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3334,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3337,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:806: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[446],C_fix(13),lf[447],C_SCHEME_TRUE);}

/* k4020 in a3961 in k3943 in rewrite-call/cc in k3922 in k3919 in k3916 in k3913 in k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in k3755 in k3752 in k3749 in k3746 in k3743 in k3740 in k3737 in ... */
static void C_ccall f_4022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4022,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4018,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-platform.scm:1082: get */
t3=*((C_word*)lf[60]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[5],((C_word*)t0)[6],lf[78]);}}

/* k2810 in k2807 in k2804 in k2801 in k2798 in k2795 in k2792 in k2789 in k2786 in k2783 in k2780 in k2777 in k2774 in k2771 in k2768 in k2765 in k2762 in k2759 in k2756 in k2753 in k2750 in k2747 in ... */
static void C_ccall f_2812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2812,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2815,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:612: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[752],C_fix(2),C_fix(1),lf[753],C_SCHEME_TRUE);}

/* k2813 in k2810 in k2807 in k2804 in k2801 in k2798 in k2795 in k2792 in k2789 in k2786 in k2783 in k2780 in k2777 in k2774 in k2771 in k2768 in k2765 in k2762 in k2759 in k2756 in k2753 in k2750 in ... */
static void C_ccall f_2815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2815,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2818,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:613: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[750],C_fix(2),C_fix(1),lf[751],C_SCHEME_TRUE);}

/* k3581 in k3578 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in ... */
static void C_ccall f_3583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3583,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3586,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:961: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[264],C_fix(17),C_fix(3),lf[265]);}

/* k3584 in k3581 in k3578 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in ... */
static void C_ccall f_3586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3589,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:962: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[262],C_fix(17),C_fix(2),lf[263]);}

/* k3578 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in ... */
static void C_ccall f_3580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3580,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3583,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:960: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[266],C_fix(17),C_fix(2),lf[267]);}

/* k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in ... */
static void C_ccall f_3577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3577,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3580,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4504,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:932: rewrite */
t4=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[273],C_fix(8),t3);}

/* k2798 in k2795 in k2792 in k2789 in k2786 in k2783 in k2780 in k2777 in k2774 in k2771 in k2768 in k2765 in k2762 in k2759 in k2756 in k2753 in k2750 in k2747 in k2744 in k2741 in k2738 in k2735 in ... */
static void C_ccall f_2800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2800,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2803,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:608: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[760],C_fix(2),C_fix(1),lf[761],C_SCHEME_TRUE);}

/* k5701 in k1604 in k1601 in k1598 */
static void C_ccall f_5703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-platform.scm:224: lset-difference */
t2=*((C_word*)lf[935]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],*((C_word*)lf[803]+1),t1,*((C_word*)lf[31]+1));}

/* k2801 in k2798 in k2795 in k2792 in k2789 in k2786 in k2783 in k2780 in k2777 in k2774 in k2771 in k2768 in k2765 in k2762 in k2759 in k2756 in k2753 in k2750 in k2747 in k2744 in k2741 in k2738 in ... */
static void C_ccall f_2803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2803,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2806,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:609: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[758],C_fix(2),C_fix(1),lf[759],C_SCHEME_TRUE);}

/* k2804 in k2801 in k2798 in k2795 in k2792 in k2789 in k2786 in k2783 in k2780 in k2777 in k2774 in k2771 in k2768 in k2765 in k2762 in k2759 in k2756 in k2753 in k2750 in k2747 in k2744 in k2741 in ... */
static void C_ccall f_2806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2806,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2809,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:610: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[756],C_fix(2),C_fix(1),lf[757],C_SCHEME_TRUE);}

/* k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in k2798 in k2795 in k2792 in k2789 in k2786 in k2783 in k2780 in k2777 in k2774 in k2771 in k2768 in k2765 in k2762 in k2759 in k2756 in k2753 in ... */
static void C_ccall f_2818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2821,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:614: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[748],C_fix(2),C_fix(1),lf[749],C_SCHEME_FALSE);}

/* k4363 in a4331 in k4096 in k4093 in k4090 in k4087 in k4084 in k4081 in k4078 in k4074 in k4071 in k3922 in k3919 in k3916 in k3913 in k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in ... */
static void C_fcall f_4365(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4365,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-platform.scm:1148: qnode */
t2=*((C_word*)lf[41]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_TRUE);}
else{
t2=C_a_i_list1(&a,1,((C_word*)t0)[3]);
t3=C_a_i_record4(&a,4,lf[37],lf[38],lf[109],t2);
t4=C_a_i_list2(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[5];
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_record4(&a,4,lf[37],lf[39],((C_word*)t0)[6],t4));}}

/* k4360 in a4331 in k4096 in k4093 in k4090 in k4087 in k4084 in k4081 in k4078 in k4074 in k4071 in k3922 in k3919 in k3916 in k3913 in k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in ... */
static void C_ccall f_4362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4362,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[37],lf[39],((C_word*)t0)[4],t2));}

/* k3593 in k3590 in k3587 in k3584 in k3581 in k3578 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in ... */
static void C_ccall f_3595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3598,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:965: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[256],C_fix(17),C_fix(3),lf[257]);}

/* k3590 in k3587 in k3584 in k3581 in k3578 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in ... */
static void C_ccall f_3592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3595,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:964: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[258],C_fix(17),C_fix(2),lf[259]);}

/* k3587 in k3584 in k3581 in k3578 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in ... */
static void C_ccall f_3589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3592,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:963: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[260],C_fix(17),C_fix(2),lf[261]);}

/* k2807 in k2804 in k2801 in k2798 in k2795 in k2792 in k2789 in k2786 in k2783 in k2780 in k2777 in k2774 in k2771 in k2768 in k2765 in k2762 in k2759 in k2756 in k2753 in k2750 in k2747 in k2744 in ... */
static void C_ccall f_2809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2809,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2812,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:611: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[754],C_fix(2),C_fix(1),lf[755],C_SCHEME_TRUE);}

/* k3596 in k3593 in k3590 in k3587 in k3584 in k3581 in k3578 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in ... */
static void C_ccall f_3598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3598,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3601,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:966: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[254],C_fix(17),C_fix(3),lf[255]);}

/* k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 in k3266 in k3263 in k3260 in k3257 in k3254 in k3251 in k3248 in k3245 in k3242 in k3239 in k3236 in ... */
static void C_ccall f_3301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3304,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:793: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[448],C_fix(16),C_fix(2),lf[460],C_SCHEME_TRUE,C_fix(4));}

/* k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 in k3266 in k3263 in k3260 in k3257 in k3254 in k3251 in k3248 in k3245 in k3242 in k3239 in ... */
static void C_ccall f_3304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3304,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3307,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:794: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[444],C_fix(16),C_fix(2),lf[459],C_SCHEME_TRUE,C_fix(4));}

/* k3305 in k3302 in k3299 in k3296 in k3293 in k3290 in k3287 in k3284 in k3281 in k3278 in k3275 in k3272 in k3269 in k3266 in k3263 in k3260 in k3257 in k3254 in k3251 in k3248 in k3245 in k3242 in ... */
static void C_ccall f_3307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3310,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:795: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[446],C_fix(16),C_fix(2),lf[458],C_SCHEME_TRUE,C_fix(4));}

/* k4205 in k4147 in a4138 in k4132 in k4129 in k4126 in k4123 in k4120 in k4117 in k4114 in k4111 in k4108 in k4105 in k4102 in k4099 in k4096 in k4093 in k4090 in k4087 in k4084 in k4081 in k4078 in ... */
static void C_ccall f_4207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4207,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_record4(&a,4,lf[37],lf[40],lf[81],t2);
t4=C_a_i_list2(&a,2,((C_word*)t0)[3],t3);
t5=C_a_i_record4(&a,4,lf[37],lf[39],((C_word*)t0)[4],t4);
t6=C_a_i_list2(&a,2,((C_word*)t0)[5],t5);
t7=((C_word*)t0)[6];
t8=t7;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_record4(&a,4,lf[37],lf[65],((C_word*)t0)[7],t6));}

/* a4331 in k4096 in k4093 in k4090 in k4087 in k4084 in k4081 in k4078 in k4074 in k4071 in k3922 in k3919 in k3916 in k3913 in k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in k3755 in ... */
static void C_ccall f_4332(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4332,6,t0,t1,t2,t3,t4,t5);}
t6=C_i_length(t5);
t7=C_eqp(C_fix(1),t6);
if(C_truep(t7)){
t8=C_i_car(t5);
t9=t8;
t10=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t11=t10;
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4362,a[2]=t4,a[3]=t1,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4365,a[2]=t12,a[3]=t9,a[4]=t4,a[5]=t1,a[6]=t11,tmp=(C_word)a,a+=7,tmp);
t14=C_slot(t9,C_fix(1));
t15=C_eqp(lf[44],t14);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4390,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t17=C_slot(t9,C_fix(2));
t18=C_i_car(t17);
/* c-platform.scm:1147: get */
t19=*((C_word*)lf[60]+1);
((C_proc5)(void*)(*((C_word*)t19+1)))(5,t19,t16,t2,t18,lf[110]);}
else{
t16=t13;
f_4365(t16,C_SCHEME_FALSE);}}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}

/* k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in k2930 in k2927 in ... */
static void C_ccall f_2992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2992,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2995,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:672: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[639],C_fix(2),C_fix(2),lf[640],C_SCHEME_FALSE);}

/* k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in k2930 in ... */
static void C_ccall f_2995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2998,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:673: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[637],C_fix(2),C_fix(1),lf[638],C_SCHEME_FALSE);}

/* k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in ... */
static void C_ccall f_2998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2998,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3001,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:675: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[633],C_fix(14),lf[34],C_fix(2),lf[635],lf[636]);}

/* k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in k2930 in k2927 in k2924 in k2921 in k2918 in ... */
static void C_ccall f_2983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2986,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:669: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[645],C_fix(2),C_fix(2),lf[646],C_SCHEME_TRUE);}

/* k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in k2930 in k2927 in k2924 in k2921 in ... */
static void C_ccall f_2986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2989,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:670: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[643],C_fix(2),C_fix(2),lf[644],C_SCHEME_TRUE);}

/* k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in k2930 in k2927 in k2924 in ... */
static void C_ccall f_2989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2992,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:671: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[641],C_fix(2),C_fix(2),lf[642],C_SCHEME_TRUE);}

/* k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in k2930 in k2927 in k2924 in k2921 in k2918 in k2915 in ... */
static void C_ccall f_2980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2983,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:668: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[647],C_fix(2),C_fix(1),lf[648],C_SCHEME_TRUE);}

/* k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in ... */
static void C_ccall f_3574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3574,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3577,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:930: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[274],C_fix(17),C_fix(2),lf[275],lf[276]);}

/* k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in ... */
static void C_ccall f_3571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3574,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:929: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[277],C_fix(17),C_fix(2),lf[278],lf[279]);}

/* a5643 in a5492 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_5644(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5644,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=C_eqp(lf[43],t4);
if(C_truep(t5)){
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=C_i_car(t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_eqp(C_fix(1),t8));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* a2206 in a2194 in rewrite-c..r in k2185 in k2182 in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_2207(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2207,3,t0,t1,t2);}
t3=C_i_car(((C_word*)t0)[2]);
t4=t3;
t5=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2231,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2234,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t6,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[2],a[9]=((C_word*)t0)[6],a[10]=t2,a[11]=t7,tmp=(C_word)a,a+=12,tmp);
t9=C_slot(t4,C_fix(1));
t10=C_eqp(lf[44],t9);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2300,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t12=C_slot(t4,C_fix(2));
t13=C_i_car(t12);
/* c-platform.scm:479: get */
t14=*((C_word*)lf[60]+1);
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,t11,((C_word*)t0)[7],t13,lf[61]);}
else{
t11=t8;
f_2234(t11,C_SCHEME_FALSE);}}

/* k4865 in k4828 in a4813 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_fcall f_4867(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4867,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4870,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_4870(t3,t1);}
else{
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_eqp(lf[43],t3);
if(C_truep(t4)){
t5=C_slot(((C_word*)t0)[5],C_fix(2));
t6=C_i_car(t5);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4907,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:422: immediate? */
t9=*((C_word*)lf[304]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t7);}
else{
t5=t2;
f_4870(t5,C_SCHEME_FALSE);}}}

/* k4834 in k4828 in a4813 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_fcall f_4836(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4836,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=((C_word*)t0)[3];
t4=C_a_i_record4(&a,4,lf[37],lf[38],lf[905],t3);
t5=C_a_i_list2(&a,2,((C_word*)t0)[4],t4);
t6=((C_word*)t0)[2];
t7=t6;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_record4(&a,4,lf[37],lf[39],t2,t5));}}

/* k4828 in a4813 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_fcall f_4830(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4830,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4836,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4867,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=C_slot(((C_word*)t0)[6],C_fix(1));
t5=C_eqp(lf[43],t4);
if(C_truep(t5)){
t6=C_slot(((C_word*)t0)[6],C_fix(2));
t7=C_i_car(t6);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4940,a[2]=t3,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:419: immediate? */
t10=*((C_word*)lf[304]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t8);}
else{
t6=t3;
f_4867(t6,C_SCHEME_FALSE);}}}

/* k2229 in a2206 in a2194 in rewrite-c..r in k2185 in k2182 in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_2231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2231,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[37],lf[39],((C_word*)t0)[4],t2));}

/* k2232 in a2206 in a2194 in rewrite-c..r in k2185 in k2182 in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_fcall f_2234(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2234,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_truep(*((C_word*)lf[36]+1))?lf[57]:lf[58]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2254,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-platform.scm:485: qnode */
t5=*((C_word*)lf[41]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[6]);}
else{
t2=(C_truep(*((C_word*)lf[36]+1))?((C_word*)t0)[7]:C_SCHEME_FALSE);
if(C_truep(t2)){
t3=C_a_i_list1(&a,1,((C_word*)t0)[7]);
t4=((C_word*)t0)[8];
t5=C_a_i_record4(&a,4,lf[37],lf[38],t3,t4);
t6=C_a_i_list2(&a,2,((C_word*)t0)[3],t5);
t7=((C_word*)t0)[4];
t8=t7;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_record4(&a,4,lf[37],lf[39],((C_word*)t0)[5],t6));}
else{
if(C_truep(((C_word*)t0)[9])){
t3=C_a_i_list1(&a,1,((C_word*)t0)[9]);
t4=((C_word*)t0)[8];
t5=C_a_i_record4(&a,4,lf[37],lf[38],t3,t4);
t6=C_a_i_list2(&a,2,((C_word*)t0)[3],t5);
t7=((C_word*)t0)[4];
t8=t7;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_record4(&a,4,lf[37],lf[39],((C_word*)t0)[5],t6));}
else{
/* c-platform.scm:488: return */
t3=((C_word*)t0)[10];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[11],C_SCHEME_FALSE);}}}}

/* a2194 in rewrite-c..r in k2185 in k2182 in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_2195(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2195,6,t0,t1,t2,t3,t4,t5);}
t6=C_i_length(t5);
t7=C_eqp(t6,C_fix(1));
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2207,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* c-platform.scm:471: call-with-current-continuation */
t9=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t1,t8);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}

/* a4813 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_4814(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4814,6,t0,t1,t2,t3,t4,t5);}
t6=C_i_length(t5);
t7=C_eqp(t6,C_fix(2));
if(C_truep(t7)){
t8=C_i_car(t5);
t9=t8;
t10=C_i_cadr(t5);
t11=t10;
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4830,a[2]=t1,a[3]=t5,a[4]=t4,a[5]=t11,a[6]=t9,tmp=(C_word)a,a+=7,tmp);
t13=C_slot(t9,C_fix(1));
t14=C_eqp(lf[44],t13);
if(C_truep(t14)){
t15=C_slot(t11,C_fix(1));
t16=C_eqp(lf[44],t15);
if(C_truep(t16)){
t17=C_slot(t9,C_fix(2));
t18=C_slot(t11,C_fix(2));
if(C_truep(C_i_equalp(t17,t18))){
t19=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t20=t19;
t21=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4999,a[2]=t4,a[3]=t12,a[4]=t20,tmp=(C_word)a,a+=5,tmp);
/* c-platform.scm:416: qnode */
t22=*((C_word*)lf[41]+1);
((C_proc3)(void*)(*((C_word*)t22+1)))(3,t22,t21,C_SCHEME_TRUE);}
else{
t19=t12;
f_4830(t19,C_SCHEME_FALSE);}}
else{
t17=t12;
f_4830(t17,C_SCHEME_FALSE);}}
else{
t15=t12;
f_4830(t15,C_SCHEME_FALSE);}}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}

/* a5296 in a5174 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_5297(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5297,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=C_eqp(lf[43],t4);
if(C_truep(t5)){
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=C_i_car(t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_eqp(C_fix(1),t8));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k5293 in a5174 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_5295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5295,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_eqp(*((C_word*)lf[35]+1),lf[34]);
if(C_truep(t3)){
t4=C_i_length(t2);
if(C_truep(C_fixnum_greater_or_equal_p(t4,C_fix(2)))){
t5=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5217,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5219,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:333: fold-inner */
t9=*((C_word*)lf[922]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,t2);}
else{
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k2185 in k2182 in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_2187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2187,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2189,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2330,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:490: rewrite-c..r */
f_2189(t3,lf[900],lf[901],lf[902],C_fix(0));}

/* k2182 in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_2184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2184,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2187,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:460: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[903],C_fix(8),((C_word*)t0)[3]);}

/* rewrite-c..r in k2185 in k2182 in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_fcall f_2189(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2189,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2195,a[2]=t5,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* c-platform.scm:464: rewrite */
t7=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,t2,C_fix(8),t6);}

/* k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in k2930 in k2927 in k2924 in k2921 in k2918 in k2915 in k2912 in k2909 in ... */
static void C_ccall f_2974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2977,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:666: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[651],C_fix(2),C_fix(1),lf[652],C_SCHEME_TRUE);}

/* k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in k2930 in k2927 in k2924 in k2921 in k2918 in k2915 in k2912 in ... */
static void C_ccall f_2977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2980,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:667: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[649],C_fix(2),C_fix(1),lf[650],C_SCHEME_TRUE);}

/* k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in k2930 in k2927 in k2924 in k2921 in k2918 in k2915 in k2912 in k2909 in k2906 in ... */
static void C_ccall f_2971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2971,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2974,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:665: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[653],C_fix(2),C_fix(1),lf[654],C_SCHEME_TRUE);}

/* k3209 in k3206 in k3203 in k3200 in k3197 in k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in k3164 in k3161 in k3158 in k3155 in k3152 in k3149 in k3146 in ... */
static void C_ccall f_3211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3211,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3214,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:756: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[505],C_fix(2),C_fix(2),lf[506],C_SCHEME_TRUE);}

/* k3215 in k3212 in k3209 in k3206 in k3203 in k3200 in k3197 in k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in k3164 in k3161 in k3158 in k3155 in k3152 in ... */
static void C_ccall f_3217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3220,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:758: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[501],C_fix(2),C_fix(2),lf[502],C_SCHEME_TRUE);}

/* k3212 in k3209 in k3206 in k3203 in k3200 in k3197 in k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in k3164 in k3161 in k3158 in k3155 in k3152 in k3149 in ... */
static void C_ccall f_3214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3214,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3217,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:757: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[503],C_fix(2),C_fix(2),lf[504],C_SCHEME_TRUE);}

/* a5174 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_5175(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5175,6,t0,t1,t2,t3,t4,t5);}
t6=C_i_length(t5);
if(C_truep(C_fixnum_greater_or_equal_p(t6,C_fix(2)))){
t7=C_i_car(t5);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5295,a[2]=t8,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5297,tmp=(C_word)a,a+=2,tmp);
t11=t5;
t12=C_u_i_cdr(t11);
/* c-platform.scm:322: remove */
t13=*((C_word*)lf[923]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t9,t10,t12);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}

/* k2963 in k2960 in k2957 in k2954 in k2951 in k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in k2930 in k2927 in k2924 in k2921 in k2918 in k2915 in k2912 in k2909 in k2906 in k2903 in k2900 in ... */
static void C_ccall f_2965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2965,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2968,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:663: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[657],C_fix(2),C_fix(1),lf[658],C_SCHEME_TRUE);}

/* k2459 in k2456 in k2453 in k2426 in rewrite-c-w-v in k2390 in k2387 in k2355 in k2352 in k2349 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2328 in k2185 in k2182 in k1956 in k1953 in k1950 in ... */
static void C_ccall f_2461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2461,2,t0,t1);}
t2=C_a_i_list1(&a,1,((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2540,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t3,a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
/* c-platform.scm:531: gensym */
t5=*((C_word*)lf[67]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[68]);}

/* k2960 in k2957 in k2954 in k2951 in k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in k2930 in k2927 in k2924 in k2921 in k2918 in k2915 in k2912 in k2909 in k2906 in k2903 in k2900 in k2897 in ... */
static void C_ccall f_2962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2962,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2965,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:662: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[659],C_fix(2),C_fix(1),lf[660],C_SCHEME_TRUE);}

/* k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in k2930 in k2927 in k2924 in k2921 in k2918 in k2915 in k2912 in k2909 in k2906 in k2903 in ... */
static void C_ccall f_2968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2971,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:664: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[655],C_fix(2),C_fix(1),lf[656],C_SCHEME_TRUE);}

/* k3200 in k3197 in k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in k3164 in k3161 in k3158 in k3155 in k3152 in k3149 in k3146 in k3143 in k3140 in k3137 in ... */
static void C_ccall f_3202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3202,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3205,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:753: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[511],C_fix(2),C_fix(2),lf[512],C_SCHEME_TRUE);}

/* k3203 in k3200 in k3197 in k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in k3164 in k3161 in k3158 in k3155 in k3152 in k3149 in k3146 in k3143 in k3140 in ... */
static void C_ccall f_3205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3205,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3208,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:754: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[509],C_fix(2),C_fix(2),lf[510],C_SCHEME_TRUE);}

/* k3206 in k3203 in k3200 in k3197 in k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in k3164 in k3161 in k3158 in k3155 in k3152 in k3149 in k3146 in k3143 in ... */
static void C_ccall f_3208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3208,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3211,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:755: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[507],C_fix(2),C_fix(2),lf[508],C_SCHEME_TRUE);}

/* k5521 in k5495 in a5492 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_5523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5523,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[37],lf[39],((C_word*)t0)[4],t2));}

/* k2453 in k2426 in rewrite-c-w-v in k2390 in k2387 in k2355 in k2352 in k2349 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2328 in k2185 in k2182 in k1956 in k1953 in k1950 in k1749 in k1746 in ... */
static void C_ccall f_2455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2455,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2458,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-platform.scm:525: gensym */
t4=*((C_word*)lf[67]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[72]);}

/* k3230 in k3227 in k3224 in k3221 in k3218 in k3215 in k3212 in k3209 in k3206 in k3203 in k3200 in k3197 in k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in ... */
static void C_ccall f_3232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3232,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3235,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:764: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[438],C_fix(9),lf[491],lf[492],C_SCHEME_TRUE,C_SCHEME_FALSE);}

/* k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 in k3212 in k3209 in k3206 in k3203 in k3200 in k3197 in k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in ... */
static void C_ccall f_3238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3241,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:766: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[434],C_fix(9),lf[487],lf[488],C_SCHEME_TRUE,C_SCHEME_FALSE);}

/* k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 in k3212 in k3209 in k3206 in k3203 in k3200 in k3197 in k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in ... */
static void C_ccall f_3235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3235,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3238,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:765: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[436],C_fix(9),lf[489],lf[490],C_SCHEME_TRUE,C_SCHEME_FALSE);}

/* k2252 in k2232 in a2206 in a2194 in rewrite-c..r in k2185 in k2182 in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 in ... */
static void C_ccall f_2254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2254,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_record4(&a,4,lf[37],lf[38],((C_word*)t0)[3],t2);
t4=C_a_i_list2(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[5];
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_record4(&a,4,lf[37],lf[39],((C_word*)t0)[6],t4));}

/* k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in ... */
static void C_ccall f_3460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3463,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4738,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:855: rewrite */
t4=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[362],C_fix(8),t3);}

/* k3461 in k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in ... */
static void C_ccall f_3463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3463,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3466,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:873: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[359],C_fix(16),C_fix(2),lf[360],C_SCHEME_TRUE,C_fix(3));}

/* k2456 in k2453 in k2426 in rewrite-c-w-v in k2390 in k2387 in k2355 in k2352 in k2349 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2328 in k2185 in k2182 in k1956 in k1953 in k1950 in k1749 in ... */
static void C_ccall f_2458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2458,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2461,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=C_slot(((C_word*)t0)[7],C_fix(2));
/* c-platform.scm:526: debugging */
t5=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,lf[70],lf[71],t4);}

/* k3218 in k3215 in k3212 in k3209 in k3206 in k3203 in k3200 in k3197 in k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in k3164 in k3161 in k3158 in k3155 in ... */
static void C_ccall f_3220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3220,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3223,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:759: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[499],C_fix(2),C_fix(2),lf[500],C_SCHEME_TRUE);}

/* k3227 in k3224 in k3221 in k3218 in k3215 in k3212 in k3209 in k3206 in k3203 in k3200 in k3197 in k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in k3164 in ... */
static void C_ccall f_3229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3229,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3232,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:763: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[440],C_fix(9),lf[493],lf[494],C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k3221 in k3218 in k3215 in k3212 in k3209 in k3206 in k3203 in k3200 in k3197 in k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in k3164 in k3161 in k3158 in ... */
static void C_ccall f_3223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3223,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3226,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:760: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[497],C_fix(2),C_fix(3),lf[498],C_SCHEME_TRUE);}

/* k3224 in k3221 in k3218 in k3215 in k3212 in k3209 in k3206 in k3203 in k3200 in k3197 in k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in k3164 in k3161 in ... */
static void C_ccall f_3226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3226,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3229,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:761: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[495],C_fix(2),C_fix(2),lf[496],C_SCHEME_TRUE);}

/* k3467 in k3464 in k3461 in k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in ... */
static void C_ccall f_3469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3469,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3472,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:875: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc9)(void*)(*((C_word*)t3+1)))(9,t3,t2,lf[354],C_fix(16),C_SCHEME_FALSE,lf[355],C_SCHEME_TRUE,lf[356],C_SCHEME_TRUE);}

/* k3464 in k3461 in k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in ... */
static void C_ccall f_3466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3466,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3469,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:874: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[357],C_fix(16),C_fix(2),lf[358],C_SCHEME_TRUE,C_fix(3));}

/* k2933 in k2930 in k2927 in k2924 in k2921 in k2918 in k2915 in k2912 in k2909 in k2906 in k2903 in k2900 in k2897 in k2894 in k2891 in k2888 in k2885 in k2882 in k2879 in k2876 in k2873 in k2870 in ... */
static void C_ccall f_2935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2938,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:653: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[677],C_fix(2),C_fix(2),lf[678],C_SCHEME_FALSE);}

/* k2930 in k2927 in k2924 in k2921 in k2918 in k2915 in k2912 in k2909 in k2906 in k2903 in k2900 in k2897 in k2894 in k2891 in k2888 in k2885 in k2882 in k2879 in k2876 in k2873 in k2870 in k2867 in ... */
static void C_ccall f_2932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2932,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2935,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:652: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[679],C_fix(2),C_fix(2),lf[680],C_SCHEME_TRUE);}

/* k2936 in k2933 in k2930 in k2927 in k2924 in k2921 in k2918 in k2915 in k2912 in k2909 in k2906 in k2903 in k2900 in k2897 in k2894 in k2891 in k2888 in k2885 in k2882 in k2879 in k2876 in k2873 in ... */
static void C_ccall f_2938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2941,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:654: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[675],C_fix(2),C_fix(2),lf[676],C_SCHEME_FALSE);}

/* k3473 in k3470 in k3467 in k3464 in k3461 in k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in ... */
static void C_ccall f_3475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3475,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3478,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:877: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc9)(void*)(*((C_word*)t3+1)))(9,t3,t2,lf[59],C_fix(16),C_SCHEME_FALSE,lf[350],C_SCHEME_TRUE,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k3470 in k3467 in k3464 in k3461 in k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in ... */
static void C_ccall f_3472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3472,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3475,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:876: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[351],C_fix(16),C_SCHEME_FALSE,lf[352],C_SCHEME_TRUE,lf[353]);}

/* k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 in k3212 in k3209 in k3206 in k3203 in k3200 in k3197 in k3194 in k3191 in k3188 in k3185 in ... */
static void C_ccall f_3250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3250,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3253,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:771: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[46],C_fix(11),C_fix(2),lf[481],C_SCHEME_TRUE);}

/* k3257 in k3254 in k3251 in k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 in k3212 in k3209 in k3206 in k3203 in k3200 in k3197 in k3194 in ... */
static void C_ccall f_3259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3259,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3262,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:774: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[478],C_fix(11),C_SCHEME_FALSE,lf[346],C_SCHEME_FALSE);}

/* k3254 in k3251 in k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 in k3212 in k3209 in k3206 in k3203 in k3200 in k3197 in k3194 in k3191 in ... */
static void C_ccall f_3256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3256,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3259,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:773: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[479],C_fix(11),C_fix(3),lf[305],C_SCHEME_FALSE);}

/* k3251 in k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 in k3212 in k3209 in k3206 in k3203 in k3200 in k3197 in k3194 in k3191 in k3188 in ... */
static void C_ccall f_3253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3253,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3256,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:772: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[480],C_fix(11),C_fix(3),lf[305],C_SCHEME_TRUE);}

/* k3476 in k3473 in k3470 in k3467 in k3464 in k3461 in k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in ... */
static void C_ccall f_3478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3478,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3481,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:878: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[348],C_fix(16),C_SCHEME_FALSE,lf[349],C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k2924 in k2921 in k2918 in k2915 in k2912 in k2909 in k2906 in k2903 in k2900 in k2897 in k2894 in k2891 in k2888 in k2885 in k2882 in k2879 in k2876 in k2873 in k2870 in k2867 in k2864 in k2861 in ... */
static void C_ccall f_2926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2926,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2929,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:650: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[683],C_fix(2),C_fix(2),lf[684],C_SCHEME_TRUE);}

/* k2921 in k2918 in k2915 in k2912 in k2909 in k2906 in k2903 in k2900 in k2897 in k2894 in k2891 in k2888 in k2885 in k2882 in k2879 in k2876 in k2873 in k2870 in k2867 in k2864 in k2861 in k2858 in ... */
static void C_ccall f_2923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2923,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2926,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:649: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[685],C_fix(2),C_fix(2),lf[686],C_SCHEME_TRUE);}

/* k2918 in k2915 in k2912 in k2909 in k2906 in k2903 in k2900 in k2897 in k2894 in k2891 in k2888 in k2885 in k2882 in k2879 in k2876 in k2873 in k2870 in k2867 in k2864 in k2861 in k2858 in k2855 in ... */
static void C_ccall f_2920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2920,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2923,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:648: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[687],C_fix(2),C_fix(2),lf[688],C_SCHEME_TRUE);}

/* k4132 in k4129 in k4126 in k4123 in k4120 in k4117 in k4114 in k4111 in k4108 in k4105 in k4102 in k4099 in k4096 in k4093 in k4090 in k4087 in k4084 in k4081 in k4078 in k4074 in k4071 in k3922 in ... */
static void C_ccall f_4134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4134,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4137,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4139,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:1192: rewrite */
t4=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[82],C_fix(8),t3);}

/* k2927 in k2924 in k2921 in k2918 in k2915 in k2912 in k2909 in k2906 in k2903 in k2900 in k2897 in k2894 in k2891 in k2888 in k2885 in k2882 in k2879 in k2876 in k2873 in k2870 in k2867 in k2864 in ... */
static void C_ccall f_2929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2929,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2932,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:651: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[681],C_fix(2),C_fix(2),lf[682],C_SCHEME_TRUE);}

/* k4129 in k4126 in k4123 in k4120 in k4117 in k4114 in k4111 in k4108 in k4105 in k4102 in k4099 in k4096 in k4093 in k4090 in k4087 in k4084 in k4081 in k4078 in k4074 in k4071 in k3922 in k3919 in ... */
static void C_ccall f_4131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4131,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4134,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4214,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:1176: rewrite */
t4=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[85],C_fix(8),t3);}

/* k3479 in k3476 in k3473 in k3470 in k3467 in k3464 in k3461 in k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in ... */
static void C_ccall f_3481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3481,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3484,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:879: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc9)(void*)(*((C_word*)t3+1)))(9,t3,t2,lf[346],C_fix(16),C_SCHEME_FALSE,lf[347],C_SCHEME_TRUE,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k4135 in k4132 in k4129 in k4126 in k4123 in k4120 in k4117 in k4114 in k4111 in k4108 in k4105 in k4102 in k4099 in k4096 in k4093 in k4090 in k4087 in k4084 in k4081 in k4078 in k4074 in k4071 in ... */
static void C_ccall f_4137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* a4138 in k4132 in k4129 in k4126 in k4123 in k4120 in k4117 in k4114 in k4111 in k4108 in k4105 in k4102 in k4099 in k4096 in k4093 in k4090 in k4087 in k4084 in k4081 in k4078 in k4074 in k4071 in ... */
static void C_ccall f_4139(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4139,6,t0,t1,t2,t3,t4,t5);}
t6=C_i_length(t5);
t7=C_eqp(C_fix(2),t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4149,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-platform.scm:1196: gensym */
t9=*((C_word*)lf[67]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}

/* k3482 in k3479 in k3476 in k3473 in k3470 in k3467 in k3464 in k3461 in k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in ... */
static void C_ccall f_3484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3484,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3487,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:880: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[344],C_fix(16),C_SCHEME_FALSE,lf[345],C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 in k3212 in k3209 in k3206 in k3203 in k3200 in k3197 in k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in ... */
static void C_ccall f_3241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3241,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3244,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:767: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[432],C_fix(9),lf[485],lf[486],C_SCHEME_TRUE,C_SCHEME_FALSE);}

/* k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 in k3212 in k3209 in k3206 in k3203 in k3200 in k3197 in k3194 in k3191 in k3188 in k3185 in k3182 in ... */
static void C_ccall f_3247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3250,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:770: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[482],C_fix(11),C_fix(2),lf[483],C_SCHEME_TRUE);}

/* k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 in k3212 in k3209 in k3206 in k3203 in k3200 in k3197 in k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in ... */
static void C_ccall f_3244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3244,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3247,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:769: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[484],C_fix(11),C_fix(1),lf[122],C_SCHEME_TRUE);}

/* k3485 in k3482 in k3479 in k3476 in k3473 in k3470 in k3467 in k3464 in k3461 in k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in ... */
static void C_ccall f_3487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3490,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:881: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[342],C_fix(16),C_fix(1),lf[343],C_SCHEME_FALSE,C_fix(2));}

/* k4099 in k4096 in k4093 in k4090 in k4087 in k4084 in k4081 in k4078 in k4074 in k4071 in k3922 in k3919 in k3916 in k3913 in k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in k3755 in ... */
static void C_ccall f_4101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4101,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4104,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4282,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:1153: rewrite */
t4=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[108],C_fix(8),t3);}

/* k4105 in k4102 in k4099 in k4096 in k4093 in k4090 in k4087 in k4084 in k4081 in k4078 in k4074 in k4071 in k3922 in k3919 in k3916 in k3913 in k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in ... */
static void C_ccall f_4107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4107,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4110,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1166: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[101],C_fix(23),C_fix(1),lf[102],lf[103]);}

/* k4102 in k4099 in k4096 in k4093 in k4090 in k4087 in k4084 in k4081 in k4078 in k4074 in k4071 in k3922 in k3919 in k3916 in k3913 in k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in ... */
static void C_ccall f_4104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4104,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4107,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1165: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[104],C_fix(23),C_fix(0),lf[105],lf[100]);}

/* k2426 in rewrite-c-w-v in k2390 in k2387 in k2355 in k2352 in k2349 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2328 in k2185 in k2182 in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in ... */
static void C_ccall f_2428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2428,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=C_slot(t2,C_fix(1));
t4=C_eqp(lf[64],t3);
if(C_truep(t4)){
t5=C_slot(t2,C_fix(2));
t6=C_i_caddr(t5);
if(C_truep(C_i_listp(t6))){
t7=C_i_length(t6);
t8=C_eqp(C_fix(2),t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2455,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* c-platform.scm:524: gensym */
t10=*((C_word*)lf[67]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k4008 in k4012 in k4016 in k4020 in a3961 in k3943 in rewrite-call/cc in k3922 in k3919 in k3916 in k3913 in k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in k3755 in k3752 in k3749 in k3746 in ... */
static void C_ccall f_4010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4010,2,t0,t1);}
t2=C_a_i_list3(&a,3,((C_word*)t0)[2],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[4];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[37],lf[39],((C_word*)t0)[5],t2));}

/* k4012 in k4016 in k4020 in a3961 in k3943 in rewrite-call/cc in k3922 in k3919 in k3916 in k3913 in k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in k3755 in k3752 in k3749 in k3746 in k3743 in ... */
static void C_ccall f_4014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4014,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4010,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-platform.scm:1086: qnode */
t5=*((C_word*)lf[41]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,C_SCHEME_FALSE);}}

/* k4016 in k4020 in a3961 in k3943 in rewrite-call/cc in k3922 in k3919 in k3916 in k3913 in k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in k3755 in k3752 in k3749 in k3746 in k3743 in k3740 in ... */
static void C_ccall f_4018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4018,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4014,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-platform.scm:1083: get */
t3=*((C_word*)lf[60]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[5],((C_word*)t0)[6],lf[77]);}}

/* f_1670 in op1 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_1670(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1670,6,t0,t1,t2,t3,t4,t5);}
t6=C_i_length(t5);
t7=C_eqp(t6,C_fix(1));
if(C_truep(t7)){
t8=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t9=t8;
t10=C_eqp(lf[34],*((C_word*)lf[35]+1));
if(C_truep(t10)){
if(C_truep(*((C_word*)lf[36]+1))){
t11=((C_word*)t0)[2];
t12=C_a_i_list1(&a,1,t11);
t13=t5;
t14=C_a_i_record4(&a,4,lf[37],lf[38],t12,t13);
t15=C_a_i_list2(&a,2,t4,t14);
t16=t1;
t17=t16;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,C_a_i_record4(&a,4,lf[37],lf[39],t9,t15));}
else{
t11=((C_word*)t0)[3];
t12=C_a_i_list1(&a,1,t11);
t13=t5;
t14=C_a_i_record4(&a,4,lf[37],lf[38],t12,t13);
t15=C_a_i_list2(&a,2,t4,t14);
t16=t1;
t17=t16;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,C_a_i_record4(&a,4,lf[37],lf[39],t9,t15));}}
else{
t11=C_a_i_list2(&a,2,((C_word*)t0)[4],C_fix(4));
t12=t11;
t13=C_i_car(t5);
t14=t13;
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1740,a[2]=t14,a[3]=t12,a[4]=t4,a[5]=t1,a[6]=t9,tmp=(C_word)a,a+=7,tmp);
/* c-platform.scm:379: qnode */
t16=*((C_word*)lf[41]+1);
((C_proc3)(void*)(*((C_word*)t16+1)))(3,t16,t15,C_fix(1));}}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}

/* k4473 in k4447 in a4418 in k4074 in k4071 in k3922 in k3919 in k3916 in k3913 in k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in k3755 in k3752 in k3749 in k3746 in k3743 in k3740 in ... */
static void C_ccall f_4475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4475,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[37],lf[39],((C_word*)t0)[4],t2));}

/* k4123 in k4120 in k4117 in k4114 in k4111 in k4108 in k4105 in k4102 in k4099 in k4096 in k4093 in k4090 in k4087 in k4084 in k4081 in k4078 in k4074 in k4071 in k3922 in k3919 in k3916 in k3913 in ... */
static void C_ccall f_4125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4125,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4128,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1173: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[88],C_fix(7),C_fix(2),lf[89],C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k4120 in k4117 in k4114 in k4111 in k4108 in k4105 in k4102 in k4099 in k4096 in k4093 in k4090 in k4087 in k4084 in k4081 in k4078 in k4074 in k4071 in k3922 in k3919 in k3916 in k3913 in k3776 in ... */
static void C_ccall f_4122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4125,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1171: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[90],C_fix(23),C_fix(2),lf[91],C_fix(0));}

/* k4126 in k4123 in k4120 in k4117 in k4114 in k4111 in k4108 in k4105 in k4102 in k4099 in k4096 in k4093 in k4090 in k4087 in k4084 in k4081 in k4078 in k4074 in k4071 in k3922 in k3919 in k3916 in ... */
static void C_ccall f_4128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4128,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4131,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1174: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[86],C_fix(7),C_fix(2),lf[87],C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_platform_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_platform_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("platform_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(14509)){
C_save(t1);
C_rereclaim2(14509*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,937);
lf[0]=C_h_intern(&lf[0],36,"\010compilerdefault-optimization-passes");
lf[1]=C_h_intern(&lf[1],29,"\010compilerdefault-declarations");
lf[2]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014always-bound\376\003\000\000\002\376\001\000\000\022\003sysstandard-input\376\003\000\000\002\376\001\000\000\023\003sysstandard-ou"
"tput\376\003\000\000\002\376\001\000\000\022\003sysstandard-error\376\003\000\000\002\376\001\000\000\023\003sysundefined-value\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\022b"
"ound-to-procedure\376\003\000\000\002\376\001\000\000\014\003sysfor-each\376\003\000\000\002\376\001\000\000\007\003sysmap\376\003\000\000\002\376\001\000\000\011\003sysprint\376\003\000\000\002"
"\376\001\000\000\012\003syssetter\376\003\000\000\002\376\001\000\000\013\003syssetslot\376\003\000\000\002\376\001\000\000\020\003sysdynamic-wind\376\003\000\000\002\376\001\000\000\024\003syscall"
"-with-values\376\003\000\000\002\376\001\000\000\017\003sysstart-timer\376\003\000\000\002\376\001\000\000\016\003sysstop-timer\376\003\000\000\002\376\001\000\000\007\003sysgcd\376\003"
"\000\000\002\376\001\000\000\007\003syslcm\376\003\000\000\002\376\001\000\000\020\003sysmake-promise\376\003\000\000\002\376\001\000\000\016\003sysstructure\077\376\003\000\000\002\376\001\000\000\010\003syss"
"lot\376\003\000\000\002\376\001\000\000\023\003sysallocate-vector\376\003\000\000\002\376\001\000\000\020\003syslist->vector\376\003\000\000\002\376\001\000\000\015\003sysblock-re"
"f\376\003\000\000\002\376\001\000\000\016\003sysblock-set!\376\003\000\000\002\376\001\000\000\010\003syslist\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\012\003sysappen"
"d\376\003\000\000\002\376\001\000\000\012\003sysvector\376\003\000\000\002\376\001\000\000\031\003sysforeign-char-argument\376\003\000\000\002\376\001\000\000\033\003sysforeign-fi"
"xnum-argument\376\003\000\000\002\376\001\000\000\033\003sysforeign-flonum-argument\376\003\000\000\002\376\001\000\000\011\003syserror\376\003\000\000\002\376\001\000\000\021\003"
"syspeek-c-string\376\003\000\000\002\376\001\000\000\031\003syspeek-nonnull-c-string\376\003\000\000\002\376\001\000\000\032\003syspeek-and-free-c"
"-string\376\003\000\000\002\376\001\000\000\042\003syspeek-and-free-nonnull-c-string\376\003\000\000\002\376\001\000\000\032\003sysforeign-block-a"
"rgument\376\003\000\000\002\376\001\000\000\033\003sysforeign-string-argument\376\003\000\000\002\376\001\000\000\034\003sysforeign-pointer-argume"
"nt\376\003\000\000\002\376\001\000\000\034\003sysforeign-integer-argument\376\003\000\000\002\376\001\000\000\042\003syscall-with-current-continua"
"tion\376\377\016\376\377\016");
lf[3]=C_h_intern(&lf[3],39,"\010compilerdefault-debugging-declarations");
lf[4]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014\004coredeclare\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004uses\376\003\000\000\002\376\001\000\000\010debu"
"gger\376\377\016\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\003\000\000\002\376\001\000\000\022bound-to-procedure\376\003\000\000\002\376\001\000\000\024\003syspus"
"h-debug-frame\376\003\000\000\002\376\001\000\000\023\003syspop-debug-frame\376\003\000\000\002\376\001\000\000\025\003syscheck-debug-entry\376\003\000\000\002\376\001"
"\000\000\032\003syscheck-debug-assignment\376\003\000\000\002\376\001\000\000\032\003sysregister-debug-lambdas\376\003\000\000\002\376\001\000\000\034\003sysr"
"egister-debug-variables\376\003\000\000\002\376\001\000\000\016\003sysdebug-call\376\377\016\376\377\016\376\377\016\376\377\016");
lf[5]=C_h_intern(&lf[5],39,"\010compilerdefault-profiling-declarations");
lf[6]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014\004coredeclare\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004uses\376\003\000\000\002\376\001\000\000\010profiler\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000"
"\000\022bound-to-procedure\376\003\000\000\002\376\001\000\000\021\003sysprofile-entry\376\003\000\000\002\376\001\000\000\020\003sysprofile-exit\376\377\016\376\377\016\376"
"\377\016");
lf[7]=C_h_intern(&lf[7],30,"\010compilerunits-used-by-default");
lf[8]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007library\376\003\000\000\002\376\001\000\000\004eval\376\003\000\000\002\376\001\000\000\016chicken-syntax\376\377\016");
lf[9]=C_h_intern(&lf[9],25,"\010compilerwords-per-flonum");
lf[10]=C_h_intern(&lf[10],24,"\010compilerparameter-limit");
lf[11]=C_h_intern(&lf[11],21,"small-parameter-limit");
lf[12]=C_h_intern(&lf[12],27,"\010compilerunlikely-variables");
lf[13]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007unquote\376\003\000\000\002\376\001\000\000\020unquote-splicing\376\377\016");
lf[14]=C_h_intern(&lf[14],27,"\010compilereq-inline-operator");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\000\005C_eqp");
lf[16]=C_h_intern(&lf[16],34,"\010compilermembership-test-operators");
lf[17]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\010C_i_memq\376B\000\000\005C_eqp\376\003\000\000\002\376\003\000\000\002\376B\000\000\012C_u_i_memq\376B\000\000\005C_eqp\376\003\000\000\002\376\003\000\000\002\376B"
"\000\000\012C_i_member\376B\000\000\012C_i_equalp\376\003\000\000\002\376\003\000\000\002\376B\000\000\010C_i_memv\376B\000\000\010C_i_eqvp\376\377\016");
lf[18]=C_h_intern(&lf[18],32,"\010compilermembership-unfold-limit");
lf[19]=C_h_intern(&lf[19],28,"\010compilertarget-include-file");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\011chicken.h");
lf[21]=C_h_intern(&lf[21],31,"\010compilervalid-compiler-options");
lf[22]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005-help\376\003\000\000\002\376\001\000\000\001h\376\003\000\000\002\376\001\000\000\004help\376\003\000\000\002\376\001\000\000\007version\376\003\000\000\002\376\001\000\000\007verbose\376\003\000\000\002\376"
"\001\000\000\014explicit-use\376\003\000\000\002\376\001\000\000\010no-trace\376\003\000\000\002\376\001\000\000\013no-warnings\376\003\000\000\002\376\001\000\000\006unsafe\376\003\000\000\002\376\001\000\000"
"\005block\376\003\000\000\002\376\001\000\000\014check-syntax\376\003\000\000\002\376\001\000\000\011to-stdout\376\003\000\000\002\376\001\000\000\025no-usual-integrations\376\003"
"\000\000\002\376\001\000\000\020case-insensitive\376\003\000\000\002\376\001\000\000\016no-lambda-info\376\003\000\000\002\376\001\000\000\007profile\376\003\000\000\002\376\001\000\000\006inlin"
"e\376\003\000\000\002\376\001\000\000\024keep-shadowed-macros\376\003\000\000\002\376\001\000\000\021ignore-repository\376\003\000\000\002\376\001\000\000\021fixnum-arith"
"metic\376\003\000\000\002\376\001\000\000\022disable-interrupts\376\003\000\000\002\376\001\000\000\026optimize-leaf-routines\376\003\000\000\002\376\001\000\000\016compi"
"le-syntax\376\003\000\000\002\376\001\000\000\014tag-pointers\376\003\000\000\002\376\001\000\000\022accumulate-profile\376\003\000\000\002\376\001\000\000\035disable-sta"
"ck-overflow-checks\376\003\000\000\002\376\001\000\000\003raw\376\003\000\000\002\376\001\000\000\012specialize\376\003\000\000\002\376\001\000\000\036emit-external-proto"
"types-first\376\003\000\000\002\376\001\000\000\007release\376\003\000\000\002\376\001\000\000\005local\376\003\000\000\002\376\001\000\000\015inline-global\376\003\000\000\002\376\001\000\000\014anal"
"yze-only\376\003\000\000\002\376\001\000\000\007dynamic\376\003\000\000\002\376\001\000\000\012scrutinize\376\003\000\000\002\376\001\000\000\016no-argc-checks\376\003\000\000\002\376\001\000\000\023n"
"o-procedure-checks\376\003\000\000\002\376\001\000\000)no-procedure-checks-for-toplevel-bindings\376\003\000\000\002\376\001\000\000\006m"
"odule\376\003\000\000\002\376\001\000\000\017no-bound-checks\376\003\000\000\002\376\001\000\000&no-procedure-checks-for-usual-bindings\376\003"
"\000\000\002\376\001\000\000\022no-compiler-syntax\376\003\000\000\002\376\001\000\000\027no-parentheses-synonyms\376\003\000\000\002\376\001\000\000\020no-symbol-e"
"scape\376\003\000\000\002\376\001\000\000\013r5rs-syntax\376\003\000\000\002\376\001\000\000\031emit-all-import-libraries\376\003\000\000\002\376\001\000\000\014strict-ty"
"pes\376\003\000\000\002\376\001\000\000\012clustering\376\003\000\000\002\376\001\000\000\004lfa2\376\003\000\000\002\376\001\000\000\012setup-mode\376\003\000\000\002\376\001\000\000\026no-module-reg"
"istration\376\377\016");
lf[23]=C_h_intern(&lf[23],45,"\010compilervalid-compiler-options-with-argument");
lf[24]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005debug\376\003\000\000\002\376\001\000\000\013output-file\376\003\000\000\002\376\001\000\000\014include-path\376\003\000\000\002\376\001\000\000\011heap-size\376\003\000"
"\000\002\376\001\000\000\012stack-size\376\003\000\000\002\376\001\000\000\004unit\376\003\000\000\002\376\001\000\000\004uses\376\003\000\000\002\376\001\000\000\015keyword-style\376\003\000\000\002\376\001\000\000\021re"
"quire-extension\376\003\000\000\002\376\001\000\000\014inline-limit\376\003\000\000\002\376\001\000\000\014profile-name\376\003\000\000\002\376\001\000\000\024parenthesis"
"-synonyms\376\003\000\000\002\376\001\000\000\007prelude\376\003\000\000\002\376\001\000\000\010postlude\376\003\000\000\002\376\001\000\000\010prologue\376\003\000\000\002\376\001\000\000\010epilogue"
"\376\003\000\000\002\376\001\000\000\007nursery\376\003\000\000\002\376\001\000\000\006extend\376\003\000\000\002\376\001\000\000\007feature\376\003\000\000\002\376\001\000\000\012no-feature\376\003\000\000\002\376\001\000\000\005"
"types\376\003\000\000\002\376\001\000\000\023emit-import-library\376\003\000\000\002\376\001\000\000\020emit-inline-file\376\003\000\000\002\376\001\000\000\020static-ext"
"ension\376\003\000\000\002\376\001\000\000\023consult-inline-file\376\003\000\000\002\376\001\000\000\016emit-type-file\376\003\000\000\002\376\001\000\000\012ffi-define\376"
"\003\000\000\002\376\001\000\000\020ffi-include-path\376\377\016");
lf[25]=C_h_intern(&lf[25],34,"\010compilerdefault-standard-bindings");
lf[26]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003not\376\003\000\000\002\376\001\000\000\010boolean\077\376\003\000\000\002\376\001\000\000\005apply\376\003\000\000\002\376\001\000\000\036call-with-current-contin"
"uation\376\003\000\000\002\376\001\000\000\003eq\077\376\003\000\000\002\376\001\000\000\004eqv\077\376\003\000\000\002\376\001\000\000\006equal\077\376\003\000\000\002\376\001\000\000\005pair\077\376\003\000\000\002\376\001\000\000\004cons\376\003"
"\000\000\002\376\001\000\000\003car\376\003\000\000\002\376\001\000\000\003cdr\376\003\000\000\002\376\001\000\000\004caar\376\003\000\000\002\376\001\000\000\004cadr\376\003\000\000\002\376\001\000\000\004cdar\376\003\000\000\002\376\001\000\000\004cddr"
"\376\003\000\000\002\376\001\000\000\005caaar\376\003\000\000\002\376\001\000\000\005caadr\376\003\000\000\002\376\001\000\000\005cadar\376\003\000\000\002\376\001\000\000\005caddr\376\003\000\000\002\376\001\000\000\005cdaar\376\003\000\000\002"
"\376\001\000\000\005cdadr\376\003\000\000\002\376\001\000\000\005cddar\376\003\000\000\002\376\001\000\000\005cdddr\376\003\000\000\002\376\001\000\000\006caaaar\376\003\000\000\002\376\001\000\000\006caaadr\376\003\000\000\002\376\001\000"
"\000\006caadar\376\003\000\000\002\376\001\000\000\006caaddr\376\003\000\000\002\376\001\000\000\006cadaar\376\003\000\000\002\376\001\000\000\006cadadr\376\003\000\000\002\376\001\000\000\006caddar\376\003\000\000\002\376\001\000"
"\000\006cadddr\376\003\000\000\002\376\001\000\000\006cdaaar\376\003\000\000\002\376\001\000\000\006cdaadr\376\003\000\000\002\376\001\000\000\006cdadar\376\003\000\000\002\376\001\000\000\006cdaddr\376\003\000\000\002\376\001\000"
"\000\006cddaar\376\003\000\000\002\376\001\000\000\006cddadr\376\003\000\000\002\376\001\000\000\006cdddar\376\003\000\000\002\376\001\000\000\006cddddr\376\003\000\000\002\376\001\000\000\010set-car!\376\003\000\000\002\376"
"\001\000\000\010set-cdr!\376\003\000\000\002\376\001\000\000\005null\077\376\003\000\000\002\376\001\000\000\004list\376\003\000\000\002\376\001\000\000\005list\077\376\003\000\000\002\376\001\000\000\006length\376\003\000\000\002\376\001\000"
"\000\005zero\077\376\003\000\000\002\376\001\000\000\001\052\376\003\000\000\002\376\001\000\000\001-\376\003\000\000\002\376\001\000\000\001+\376\003\000\000\002\376\001\000\000\001/\376\003\000\000\002\376\001\000\000\001-\376\003\000\000\002\376\001\000\000\001>\376\003\000\000\002\376\001"
"\000\000\001<\376\003\000\000\002\376\001\000\000\002>=\376\003\000\000\002\376\001\000\000\002<=\376\003\000\000\002\376\001\000\000\001=\376\003\000\000\002\376\001\000\000\023current-output-port\376\003\000\000\002\376\001\000\000\022cu"
"rrent-input-port\376\003\000\000\002\376\001\000\000\012write-char\376\003\000\000\002\376\001\000\000\007newline\376\003\000\000\002\376\001\000\000\005write\376\003\000\000\002\376\001\000\000\007di"
"splay\376\003\000\000\002\376\001\000\000\006append\376\003\000\000\002\376\001\000\000\016symbol->string\376\003\000\000\002\376\001\000\000\010for-each\376\003\000\000\002\376\001\000\000\003map\376\003\000\000"
"\002\376\001\000\000\005char\077\376\003\000\000\002\376\001\000\000\015char->integer\376\003\000\000\002\376\001\000\000\015integer->char\376\003\000\000\002\376\001\000\000\013eof-object\077\376\003"
"\000\000\002\376\001\000\000\015vector-length\376\003\000\000\002\376\001\000\000\015string-length\376\003\000\000\002\376\001\000\000\012string-ref\376\003\000\000\002\376\001\000\000\013string"
"-set!\376\003\000\000\002\376\001\000\000\012vector-ref\376\003\000\000\002\376\001\000\000\013vector-set!\376\003\000\000\002\376\001\000\000\006char=\077\376\003\000\000\002\376\001\000\000\006char<\077\376\003"
"\000\000\002\376\001\000\000\006char>\077\376\003\000\000\002\376\001\000\000\007char>=\077\376\003\000\000\002\376\001\000\000\007char<=\077\376\003\000\000\002\376\001\000\000\003gcd\376\003\000\000\002\376\001\000\000\003lcm\376\003\000\000\002\376"
"\001\000\000\007reverse\376\003\000\000\002\376\001\000\000\007symbol\077\376\003\000\000\002\376\001\000\000\016string->symbol\376\003\000\000\002\376\001\000\000\007number\077\376\003\000\000\002\376\001\000\000\010c"
"omplex\077\376\003\000\000\002\376\001\000\000\005real\077\376\003\000\000\002\376\001\000\000\010integer\077\376\003\000\000\002\376\001\000\000\011rational\077\376\003\000\000\002\376\001\000\000\004odd\077\376\003\000\000\002\376\001"
"\000\000\005even\077\376\003\000\000\002\376\001\000\000\011positive\077\376\003\000\000\002\376\001\000\000\011negative\077\376\003\000\000\002\376\001\000\000\006exact\077\376\003\000\000\002\376\001\000\000\010inexact\077"
"\376\003\000\000\002\376\001\000\000\003max\376\003\000\000\002\376\001\000\000\003min\376\003\000\000\002\376\001\000\000\010quotient\376\003\000\000\002\376\001\000\000\011remainder\376\003\000\000\002\376\001\000\000\006modulo\376"
"\003\000\000\002\376\001\000\000\005floor\376\003\000\000\002\376\001\000\000\007ceiling\376\003\000\000\002\376\001\000\000\010truncate\376\003\000\000\002\376\001\000\000\005round\376\003\000\000\002\376\001\000\000\016exact-"
">inexact\376\003\000\000\002\376\001\000\000\016inexact->exact\376\003\000\000\002\376\001\000\000\003exp\376\003\000\000\002\376\001\000\000\003log\376\003\000\000\002\376\001\000\000\003sin\376\003\000\000\002\376\001\000\000"
"\004expt\376\003\000\000\002\376\001\000\000\004sqrt\376\003\000\000\002\376\001\000\000\003cos\376\003\000\000\002\376\001\000\000\003tan\376\003\000\000\002\376\001\000\000\004asin\376\003\000\000\002\376\001\000\000\004acos\376\003\000\000\002\376\001"
"\000\000\004atan\376\003\000\000\002\376\001\000\000\016number->string\376\003\000\000\002\376\001\000\000\016string->number\376\003\000\000\002\376\001\000\000\011char-ci=\077\376\003\000\000\002\376"
"\001\000\000\011char-ci<\077\376\003\000\000\002\376\001\000\000\011char-ci>\077\376\003\000\000\002\376\001\000\000\012char-ci>=\077\376\003\000\000\002\376\001\000\000\012char-ci<=\077\376\003\000\000\002\376\001\000"
"\000\020char-alphabetic\077\376\003\000\000\002\376\001\000\000\020char-whitespace\077\376\003\000\000\002\376\001\000\000\015char-numeric\077\376\003\000\000\002\376\001\000\000\020cha"
"r-lower-case\077\376\003\000\000\002\376\001\000\000\020char-upper-case\077\376\003\000\000\002\376\001\000\000\013char-upcase\376\003\000\000\002\376\001\000\000\015char-downc"
"ase\376\003\000\000\002\376\001\000\000\007string\077\376\003\000\000\002\376\001\000\000\010string=\077\376\003\000\000\002\376\001\000\000\010string>\077\376\003\000\000\002\376\001\000\000\010string<\077\376\003\000\000\002\376"
"\001\000\000\011string>=\077\376\003\000\000\002\376\001\000\000\011string<=\077\376\003\000\000\002\376\001\000\000\013string-ci=\077\376\003\000\000\002\376\001\000\000\013string-ci<\077\376\003\000\000\002\376"
"\001\000\000\013string-ci>\077\376\003\000\000\002\376\001\000\000\014string-ci<=\077\376\003\000\000\002\376\001\000\000\014string-ci>=\077\376\003\000\000\002\376\001\000\000\015string-appe"
"nd\376\003\000\000\002\376\001\000\000\014string->list\376\003\000\000\002\376\001\000\000\014list->string\376\003\000\000\002\376\001\000\000\007vector\077\376\003\000\000\002\376\001\000\000\014vector-"
">list\376\003\000\000\002\376\001\000\000\014list->vector\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\001\000\000\004read\376\003\000\000\002\376\001\000\000\011read-char\376\003\000\000"
"\002\376\001\000\000\011substring\376\003\000\000\002\376\001\000\000\014string-fill!\376\003\000\000\002\376\001\000\000\014vector-fill!\376\003\000\000\002\376\001\000\000\013make-string"
"\376\003\000\000\002\376\001\000\000\013make-vector\376\003\000\000\002\376\001\000\000\017open-input-file\376\003\000\000\002\376\001\000\000\020open-output-file\376\003\000\000\002\376\001\000"
"\000\024call-with-input-file\376\003\000\000\002\376\001\000\000\025call-with-output-file\376\003\000\000\002\376\001\000\000\020close-input-port\376"
"\003\000\000\002\376\001\000\000\021close-output-port\376\003\000\000\002\376\001\000\000\006values\376\003\000\000\002\376\001\000\000\020call-with-values\376\003\000\000\002\376\001\000\000\006ve"
"ctor\376\003\000\000\002\376\001\000\000\012procedure\077\376\003\000\000\002\376\001\000\000\004memq\376\003\000\000\002\376\001\000\000\004memv\376\003\000\000\002\376\001\000\000\006member\376\003\000\000\002\376\001\000\000\004as"
"sq\376\003\000\000\002\376\001\000\000\004assv\376\003\000\000\002\376\001\000\000\005assoc\376\003\000\000\002\376\001\000\000\011list-tail\376\003\000\000\002\376\001\000\000\010list-ref\376\003\000\000\002\376\001\000\000\003ab"
"s\376\003\000\000\002\376\001\000\000\013char-ready\077\376\003\000\000\002\376\001\000\000\011peek-char\376\003\000\000\002\376\001\000\000\014list->string\376\003\000\000\002\376\001\000\000\014string-"
">list\376\003\000\000\002\376\001\000\000\022current-input-port\376\003\000\000\002\376\001\000\000\023current-output-port\376\377\016");
lf[27]=C_h_intern(&lf[27],34,"\010compilerdefault-extended-bindings");
lf[28]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\013bitwise-and\376\003\000\000\002\376\001\000\000\012alist-cons\376\003\000\000\002\376\001\000\000\005xcons\376\003\000\000\002\376\001\000\000\013bitwise-ior\376\003\000"
"\000\002\376\001\000\000\013bitwise-xor\376\003\000\000\002\376\001\000\000\013bitwise-not\376\003\000\000\002\376\001\000\000\004add1\376\003\000\000\002\376\001\000\000\004sub1\376\003\000\000\002\376\001\000\000\003fx+"
"\376\003\000\000\002\376\001\000\000\003fx-\376\003\000\000\002\376\001\000\000\003fx\052\376\003\000\000\002\376\001\000\000\003fx/\376\003\000\000\002\376\001\000\000\004fx+\077\376\003\000\000\002\376\001\000\000\004fx-\077\376\003\000\000\002\376\001\000\000\004fx\052"
"\077\376\003\000\000\002\376\001\000\000\004fx/\077\376\003\000\000\002\376\001\000\000\005fxmod\376\003\000\000\002\376\001\000\000\001o\376\003\000\000\002\376\001\000\000\004fp/\077\376\003\000\000\002\376\001\000\000\003fx=\376\003\000\000\002\376\001\000\000\003fx"
">\376\003\000\000\002\376\001\000\000\003fx<\376\003\000\000\002\376\001\000\000\004fx>=\376\003\000\000\002\376\001\000\000\004fx<=\376\003\000\000\002\376\001\000\000\007fixnum\077\376\003\000\000\002\376\001\000\000\005fxneg\376\003\000\000\002\376"
"\001\000\000\005fxmax\376\003\000\000\002\376\001\000\000\005fxmin\376\003\000\000\002\376\001\000\000\010identity\376\003\000\000\002\376\001\000\000\003fp+\376\003\000\000\002\376\001\000\000\003fp-\376\003\000\000\002\376\001\000\000\003fp"
"\052\376\003\000\000\002\376\001\000\000\003fp/\376\003\000\000\002\376\001\000\000\005fpmin\376\003\000\000\002\376\001\000\000\005fpmax\376\003\000\000\002\376\001\000\000\005fpneg\376\003\000\000\002\376\001\000\000\003fp>\376\003\000\000\002\376\001\000"
"\000\003fp<\376\003\000\000\002\376\001\000\000\003fp=\376\003\000\000\002\376\001\000\000\004fp>=\376\003\000\000\002\376\001\000\000\004fp<=\376\003\000\000\002\376\001\000\000\005fxand\376\003\000\000\002\376\001\000\000\005fxnot\376\003\000\000"
"\002\376\001\000\000\005fxior\376\003\000\000\002\376\001\000\000\005fxxor\376\003\000\000\002\376\001\000\000\005fxshr\376\003\000\000\002\376\001\000\000\005fxshl\376\003\000\000\002\376\001\000\000\010bit-set\077\376\003\000\000\002\376"
"\001\000\000\006fxodd\077\376\003\000\000\002\376\001\000\000\007fxeven\077\376\003\000\000\002\376\001\000\000\007fpfloor\376\003\000\000\002\376\001\000\000\011fpceiling\376\003\000\000\002\376\001\000\000\012fptrunc"
"ate\376\003\000\000\002\376\001\000\000\007fpround\376\003\000\000\002\376\001\000\000\005fpsin\376\003\000\000\002\376\001\000\000\005fpcos\376\003\000\000\002\376\001\000\000\005fptan\376\003\000\000\002\376\001\000\000\006fpasi"
"n\376\003\000\000\002\376\001\000\000\006fpacos\376\003\000\000\002\376\001\000\000\006fpatan\376\003\000\000\002\376\001\000\000\007fpatan2\376\003\000\000\002\376\001\000\000\005fpexp\376\003\000\000\002\376\001\000\000\006fpexp"
"t\376\003\000\000\002\376\001\000\000\005fplog\376\003\000\000\002\376\001\000\000\006fpsqrt\376\003\000\000\002\376\001\000\000\005fpabs\376\003\000\000\002\376\001\000\000\012fpinteger\077\376\003\000\000\002\376\001\000\000\020ari"
"thmetic-shift\376\003\000\000\002\376\001\000\000\004void\376\003\000\000\002\376\001\000\000\014flush-output\376\003\000\000\002\376\001\000\000\017thread-specific\376\003\000\000\002\376"
"\001\000\000\024thread-specific-set!\376\003\000\000\002\376\001\000\000\011not-pair\077\376\003\000\000\002\376\001\000\000\005atom\077\376\003\000\000\002\376\001\000\000\012null-list\077\376\003"
"\000\000\002\376\001\000\000\005print\376\003\000\000\002\376\001\000\000\006print\052\376\003\000\000\002\376\001\000\000\005error\376\003\000\000\002\376\001\000\000\014proper-list\077\376\003\000\000\002\376\001\000\000\007call"
"/cc\376\003\000\000\002\376\001\000\000\011blob-size\376\003\000\000\002\376\001\000\000\025u8vector->blob/shared\376\003\000\000\002\376\001\000\000\025s8vector->blob/sh"
"ared\376\003\000\000\002\376\001\000\000\026u16vector->blob/shared\376\003\000\000\002\376\001\000\000\026s16vector->blob/shared\376\003\000\000\002\376\001\000\000\026u3"
"2vector->blob/shared\376\003\000\000\002\376\001\000\000\026s32vector->blob/shared\376\003\000\000\002\376\001\000\000\026f32vector->blob/sh"
"ared\376\003\000\000\002\376\001\000\000\026f64vector->blob/shared\376\003\000\000\002\376\001\000\000\025blob->u8vector/shared\376\003\000\000\002\376\001\000\000\025blo"
"b->s8vector/shared\376\003\000\000\002\376\001\000\000\026blob->u16vector/shared\376\003\000\000\002\376\001\000\000\026blob->s16vector/shar"
"ed\376\003\000\000\002\376\001\000\000\026blob->u32vector/shared\376\003\000\000\002\376\001\000\000\026blob->s32vector/shared\376\003\000\000\002\376\001\000\000\026blob"
"->f32vector/shared\376\003\000\000\002\376\001\000\000\026blob->f64vector/shared\376\003\000\000\002\376\001\000\000\011block-ref\376\003\000\000\002\376\001\000\000\012b"
"lock-set!\376\003\000\000\002\376\001\000\000\017number-of-slots\376\003\000\000\002\376\001\000\000\017substring-index\376\003\000\000\002\376\001\000\000\022substring-i"
"ndex-ci\376\003\000\000\002\376\001\000\000\016hash-table-ref\376\003\000\000\002\376\001\000\000\004any\077\376\003\000\000\002\376\001\000\000\013read-string\376\003\000\000\002\376\001\000\000\013subs"
"tring=\077\376\003\000\000\002\376\001\000\000\016substring-ci=\077\376\003\000\000\002\376\001\000\000\005first\376\003\000\000\002\376\001\000\000\006second\376\003\000\000\002\376\001\000\000\005third\376\003\000"
"\000\002\376\001\000\000\006fourth\376\003\000\000\002\376\001\000\000\024make-record-instance\376\003\000\000\002\376\001\000\000\005foldl\376\003\000\000\002\376\001\000\000\005foldr\376\003\000\000\002\376\001"
"\000\000\017u8vector-length\376\003\000\000\002\376\001\000\000\017s8vector-length\376\003\000\000\002\376\001\000\000\020u16vector-length\376\003\000\000\002\376\001\000\000\020s"
"16vector-length\376\003\000\000\002\376\001\000\000\020u32vector-length\376\003\000\000\002\376\001\000\000\020s32vector-length\376\003\000\000\002\376\001\000\000\020f32"
"vector-length\376\003\000\000\002\376\001\000\000\020f64vector-length\376\003\000\000\002\376\001\000\000\006setter\376\003\000\000\002\376\001\000\000\014u8vector-ref\376\003\000"
"\000\002\376\001\000\000\014s8vector-ref\376\003\000\000\002\376\001\000\000\015u16vector-ref\376\003\000\000\002\376\001\000\000\015s16vector-ref\376\003\000\000\002\376\001\000\000\015u32ve"
"ctor-ref\376\003\000\000\002\376\001\000\000\015s32vector-ref\376\003\000\000\002\376\001\000\000\015f32vector-ref\376\003\000\000\002\376\001\000\000\015f64vector-ref\376\003\000"
"\000\002\376\001\000\000\016f32vector-set!\376\003\000\000\002\376\001\000\000\016f64vector-set!\376\003\000\000\002\376\001\000\000\015u8vector-set!\376\003\000\000\002\376\001\000\000\015s8"
"vector-set!\376\003\000\000\002\376\001\000\000\016u16vector-set!\376\003\000\000\002\376\001\000\000\016s16vector-set!\376\003\000\000\002\376\001\000\000\016u32vector-s"
"et!\376\003\000\000\002\376\001\000\000\016s32vector-set!\376\003\000\000\002\376\001\000\000\014locative-ref\376\003\000\000\002\376\001\000\000\015locative-set!\376\003\000\000\002\376\001\000"
"\000\020locative->object\376\003\000\000\002\376\001\000\000\011locative\077\376\003\000\000\002\376\001\000\000\015null-pointer\077\376\003\000\000\002\376\001\000\000\017pointer->o"
"bject\376\003\000\000\002\376\001\000\000\007flonum\077\376\003\000\000\002\376\001\000\000\007finite\077\376\003\000\000\002\376\001\000\000\020address->pointer\376\003\000\000\002\376\001\000\000\020point"
"er->address\376\003\000\000\002\376\001\000\000\010pointer+\376\003\000\000\002\376\001\000\000\011pointer=\077\376\003\000\000\002\376\001\000\000\016pointer-u8-ref\376\003\000\000\002\376\001\000"
"\000\016pointer-s8-ref\376\003\000\000\002\376\001\000\000\017pointer-u16-ref\376\003\000\000\002\376\001\000\000\017pointer-s16-ref\376\003\000\000\002\376\001\000\000\017poin"
"ter-u32-ref\376\003\000\000\002\376\001\000\000\017pointer-s32-ref\376\003\000\000\002\376\001\000\000\017pointer-f32-ref\376\003\000\000\002\376\001\000\000\017pointer-f"
"64-ref\376\003\000\000\002\376\001\000\000\017pointer-u8-set!\376\003\000\000\002\376\001\000\000\017pointer-s8-set!\376\003\000\000\002\376\001\000\000\020pointer-u16-se"
"t!\376\003\000\000\002\376\001\000\000\020pointer-s16-set!\376\003\000\000\002\376\001\000\000\020pointer-u32-set!\376\003\000\000\002\376\001\000\000\020pointer-s32-set!"
"\376\003\000\000\002\376\001\000\000\020pointer-f32-set!\376\003\000\000\002\376\001\000\000\020pointer-f64-set!\376\003\000\000\002\376\001\000\000\022current-error-port"
"\376\003\000\000\002\376\001\000\000\016current-thread\376\003\000\000\002\376\001\000\000\006printf\376\003\000\000\002\376\001\000\000\007sprintf\376\003\000\000\002\376\001\000\000\006format\376\003\000\000\002\376\001"
"\000\000\007fprintf\376\003\000\000\002\376\001\000\000\013get-keyword\376\377\016");
lf[29]=C_h_intern(&lf[29],26,"\010compilerinternal-bindings");
lf[30]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysslot\376\003\000\000\002\376\001\000\000\013\003syssetslot\376\003\000\000\002\376\001\000\000\015\003sysblock-ref\376\003\000\000\002\376\001\000\000\016\003sysbloc"
"k-set!\376\003\000\000\002\376\001\000\000\042\003syscall-with-current-continuation\376\003\000\000\002\376\001\000\000\010\003syssize\376\003\000\000\002\376\001\000\000\010\003s"
"ysbyte\376\003\000\000\002\376\001\000\000\013\003syssetbyte\376\003\000\000\002\376\001\000\000\014\003syspointer\077\376\003\000\000\002\376\001\000\000\026\003sysgeneric-structure"
"\077\376\003\000\000\002\376\001\000\000\016\003sysstructure\077\376\003\000\000\002\376\001\000\000\023\003syscheck-structure\376\003\000\000\002\376\001\000\000\017\003syscheck-exact\376"
"\003\000\000\002\376\001\000\000\020\003syscheck-number\376\003\000\000\002\376\001\000\000\016\003syscheck-list\376\003\000\000\002\376\001\000\000\016\003syscheck-pair\376\003\000\000\002\376\001"
"\000\000\020\003syscheck-string\376\003\000\000\002\376\001\000\000\020\003syscheck-symbol\376\003\000\000\002\376\001\000\000\021\003syscheck-boolean\376\003\000\000\002\376\001\000"
"\000\022\003syscheck-locative\376\003\000\000\002\376\001\000\000\016\003syscheck-port\376\003\000\000\002\376\001\000\000\024\003syscheck-input-port\376\003\000\000\002\376"
"\001\000\000\025\003syscheck-output-port\376\003\000\000\002\376\001\000\000\023\003syscheck-open-port\376\003\000\000\002\376\001\000\000\016\003syscheck-char\376\003"
"\000\000\002\376\001\000\000\020\003syscheck-vector\376\003\000\000\002\376\001\000\000\025\003syscheck-byte-vector\376\003\000\000\002\376\001\000\000\010\003syslist\376\003\000\000\002\376\001"
"\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\024\003syscall-with-values\376\003\000\000\002\376\001\000\000\020\003sysfits-in-int\077\376\003\000\000\002\376\001\000\000\031\003sy"
"sfits-in-unsigned-int\077\376\003\000\000\002\376\001\000\000\033\003sysflonum-in-fixnum-range\077\376\003\000\000\002\376\001\000\000\011\003sysfudge\376\003"
"\000\000\002\376\001\000\000\016\003sysimmediate\077\376\003\000\000\002\376\001\000\000\021\003sysdirect-return\376\003\000\000\002\376\001\000\000\022\003syscontext-switch\376\003\000"
"\000\002\376\001\000\000\022\003sysmake-structure\376\003\000\000\002\376\001\000\000\011\003sysapply\376\003\000\000\002\376\001\000\000\020\003sysapply-values\376\003\000\000\002\376\001\000\000\026"
"\003syscontinuation-graft\376\003\000\000\002\376\001\000\000\017\003sysbytevector\077\376\003\000\000\002\376\001\000\000\017\003sysmake-vector\376\003\000\000\002\376\001\000"
"\000\012\003syssetter\376\003\000\000\002\376\001\000\000\007\003syscar\376\003\000\000\002\376\001\000\000\007\003syscdr\376\003\000\000\002\376\001\000\000\011\003syspair\077\376\003\000\000\002\376\001\000\000\007\003syse"
"q\077\376\003\000\000\002\376\001\000\000\011\003syslist\077\376\003\000\000\002\376\001\000\000\013\003sysvector\077\376\003\000\000\002\376\001\000\000\010\003syseqv\077\376\003\000\000\002\376\001\000\000\017\003sysget-ke"
"yword\376\003\000\000\002\376\001\000\000\031\003sysforeign-char-argument\376\003\000\000\002\376\001\000\000\033\003sysforeign-fixnum-argument\376\003\000"
"\000\002\376\001\000\000\033\003sysforeign-flonum-argument\376\003\000\000\002\376\001\000\000\032\003sysforeign-block-argument\376\003\000\000\002\376\001\000\000#"
"\003sysforeign-struct-wrapper-argument\376\003\000\000\002\376\001\000\000\033\003sysforeign-string-argument\376\003\000\000\002\376\001\000"
"\000\034\003sysforeign-pointer-argument\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\003\000\000\002\376\001\000\000\034\003sysforeign-integer-ar"
"gument\376\003\000\000\002\376\001\000\000%\003sysforeign-unsigned-integer-argument\376\003\000\000\002\376\001\000\000\017\003syspeek-fixnum\376\003"
"\000\000\002\376\001\000\000\014\003syssetislot\376\003\000\000\002\376\001\000\000\020\003syspoke-integer\376\003\000\000\002\376\001\000\000\016\003syspermanent\077\376\003\000\000\002\376\001\000\000\012"
"\003sysvalues\376\003\000\000\002\376\001\000\000\017\003syspoke-double\376\003\000\000\002\376\001\000\000\021\003sysintern-symbol\376\003\000\000\002\376\001\000\000\017\003sysmake"
"-symbol\376\003\000\000\002\376\001\000\000\021\003sysnull-pointer\077\376\003\000\000\002\376\001\000\000\015\003syspeek-byte\376\003\000\000\002\376\001\000\000\020\003sysfile-exis"
"ts\077\376\377\016");
lf[31]=C_h_intern(&lf[31],30,"\010compilernon-foldable-bindings");
lf[32]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006vector\376\003\000\000\002\376\001\000\000\004cons\376\003\000\000\002\376\001\000\000\004list\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\001\000\000\013make-vecto"
"r\376\003\000\000\002\376\001\000\000\013make-string\376\003\000\000\002\376\001\000\000\016string->symbol\376\003\000\000\002\376\001\000\000\006values\376\003\000\000\002\376\001\000\000\022current-"
"input-port\376\003\000\000\002\376\001\000\000\023current-output-port\376\003\000\000\002\376\001\000\000\011read-char\376\003\000\000\002\376\001\000\000\012write-char\376\003"
"\000\000\002\376\001\000\000\006printf\376\003\000\000\002\376\001\000\000\007fprintf\376\003\000\000\002\376\001\000\000\006format\376\003\000\000\002\376\001\000\000\005apply\376\003\000\000\002\376\001\000\000\036call-wit"
"h-current-continuation\376\003\000\000\002\376\001\000\000\010set-car!\376\003\000\000\002\376\001\000\000\010set-cdr!\376\003\000\000\002\376\001\000\000\012write-char\376\003"
"\000\000\002\376\001\000\000\007newline\376\003\000\000\002\376\001\000\000\005write\376\003\000\000\002\376\001\000\000\007display\376\003\000\000\002\376\001\000\000\011peek-char\376\003\000\000\002\376\001\000\000\013char"
"-ready\077\376\003\000\000\002\376\001\000\000\004read\376\003\000\000\002\376\001\000\000\011read-char\376\003\000\000\002\376\001\000\000\010for-each\376\003\000\000\002\376\001\000\000\003map\376\003\000\000\002\376\001\000\000"
"\013string-set!\376\003\000\000\002\376\001\000\000\013vector-set!\376\003\000\000\002\376\001\000\000\014string-fill!\376\003\000\000\002\376\001\000\000\014vector-fill!\376\003\000"
"\000\002\376\001\000\000\017open-input-file\376\003\000\000\002\376\001\000\000\020open-output-file\376\003\000\000\002\376\001\000\000\020close-input-port\376\003\000\000\002\376"
"\001\000\000\021close-output-port\376\003\000\000\002\376\001\000\000\024call-with-input-port\376\003\000\000\002\376\001\000\000\025call-with-output-po"
"rt\376\003\000\000\002\376\001\000\000\020call-with-values\376\003\000\000\002\376\001\000\000\004eval\376\003\000\000\002\376\001\000\000\010\003sysslot\376\003\000\000\002\376\001\000\000\013\003syssetslo"
"t\376\003\000\000\002\376\001\000\000\042\003syscall-with-current-continuation\376\003\000\000\002\376\001\000\000\011\003sysfudge\376\003\000\000\002\376\001\000\000\014flush-"
"output\376\003\000\000\002\376\001\000\000\005print\376\003\000\000\002\376\001\000\000\004void\376\003\000\000\002\376\001\000\000\025u8vector->blob/shared\376\003\000\000\002\376\001\000\000\025s8ve"
"ctor->blob/shared\376\003\000\000\002\376\001\000\000\026u16vector->blob/shared\376\003\000\000\002\376\001\000\000\026s16vector->blob/share"
"d\376\003\000\000\002\376\001\000\000\026u32vector->blob/shared\376\003\000\000\002\376\001\000\000\026f32vector->blob/shared\376\003\000\000\002\376\001\000\000\026f64ve"
"ctor->blob/shared\376\003\000\000\002\376\001\000\000\026s32vector->blob/shared\376\003\000\000\002\376\001\000\000\013read-string\376\003\000\000\002\376\001\000\000\014"
"read-string!\376\003\000\000\002\376\001\000\000\001o\376\003\000\000\002\376\001\000\000\020address->pointer\376\003\000\000\002\376\001\000\000\020pointer->address\376\003\000\000\002"
"\376\001\000\000\022\003sysmake-structure\376\003\000\000\002\376\001\000\000\006print\052\376\003\000\000\002\376\001\000\000\017\003sysmake-vector\376\003\000\000\002\376\001\000\000\011\003sysap"
"ply\376\003\000\000\002\376\001\000\000\014\003syssetislot\376\003\000\000\002\376\001\000\000\015\003sysblock-ref\376\003\000\000\002\376\001\000\000\010\003sysbyte\376\003\000\000\002\376\001\000\000\013\003sys"
"setbyte\376\003\000\000\002\376\001\000\000\017\003sysget-keyword\376\003\000\000\002\376\001\000\000\013get-keyword\376\003\000\000\002\376\001\000\000\017u8vector-length\376\003"
"\000\000\002\376\001\000\000\017s8vector-length\376\003\000\000\002\376\001\000\000\020u16vector-length\376\003\000\000\002\376\001\000\000\020s16vector-length\376\003\000\000\002"
"\376\001\000\000\020u32vector-length\376\003\000\000\002\376\001\000\000\020s32vector-length\376\003\000\000\002\376\001\000\000\020f32vector-length\376\003\000\000\002\376\001"
"\000\000\020f64vector-length\376\003\000\000\002\376\001\000\000\020\003sysapply-values\376\003\000\000\002\376\001\000\000\012\003syssetter\376\003\000\000\002\376\001\000\000\006sette"
"r\376\003\000\000\002\376\001\000\000\016f32vector-set!\376\003\000\000\002\376\001\000\000\016f64vector-set!\376\003\000\000\002\376\001\000\000\014u8vector-ref\376\003\000\000\002\376\001\000\000"
"\014s8vector-ref\376\003\000\000\002\376\001\000\000\015u16vector-ref\376\003\000\000\002\376\001\000\000\015s16vector-ref\376\003\000\000\002\376\001\000\000\015u32vector-r"
"ef\376\003\000\000\002\376\001\000\000\015s32vector-ref\376\003\000\000\002\376\001\000\000\015u8vector-set!\376\003\000\000\002\376\001\000\000\015s8vector-set!\376\003\000\000\002\376\001\000\000"
"\016u16vector-set!\376\003\000\000\002\376\001\000\000\016s16vector-set!\376\003\000\000\002\376\001\000\000\016u32vector-set!\376\003\000\000\002\376\001\000\000\016s32vect"
"or-set!\376\003\000\000\002\376\001\000\000\021\003sysintern-symbol\376\003\000\000\002\376\001\000\000\017\003sysmake-symbol\376\003\000\000\002\376\001\000\000\024make-record"
"-instance\376\003\000\000\002\376\001\000\000\005error\376\003\000\000\002\376\001\000\000\016\003sysblock-set!\376\003\000\000\002\376\001\000\000\022current-error-port\376\003\000\000"
"\002\376\001\000\000\016current-thread\376\003\000\000\002\376\001\000\000\016pointer-u8-ref\376\003\000\000\002\376\001\000\000\017pointer-u8-set!\376\003\000\000\002\376\001\000\000\016p"
"ointer-s8-ref\376\003\000\000\002\376\001\000\000\017pointer-s8-set!\376\003\000\000\002\376\001\000\000\017pointer-u16-ref\376\003\000\000\002\376\001\000\000\020pointer"
"-u16-set!\376\003\000\000\002\376\001\000\000\017pointer-s16-ref\376\003\000\000\002\376\001\000\000\020pointer-s16-set!\376\003\000\000\002\376\001\000\000\017pointer-u3"
"2-ref\376\003\000\000\002\376\001\000\000\020pointer-u32-set!\376\003\000\000\002\376\001\000\000\017pointer-s32-ref\376\003\000\000\002\376\001\000\000\020pointer-s32-se"
"t!\376\003\000\000\002\376\001\000\000\017pointer-f32-ref\376\003\000\000\002\376\001\000\000\020pointer-f32-set!\376\003\000\000\002\376\001\000\000\017pointer-f64-ref\376\003"
"\000\000\002\376\001\000\000\020pointer-f64-set!\376\377\016");
lf[33]=C_h_intern(&lf[33],26,"\010compilerfoldable-bindings");
lf[34]=C_h_intern(&lf[34],6,"fixnum");
lf[35]=C_h_intern(&lf[35],11,"number-type");
lf[36]=C_h_intern(&lf[36],6,"unsafe");
lf[37]=C_h_intern(&lf[37],4,"node");
lf[38]=C_h_intern(&lf[38],11,"\004coreinline");
lf[39]=C_h_intern(&lf[39],9,"\004corecall");
lf[40]=C_h_intern(&lf[40],20,"\004coreinline_allocate");
lf[41]=C_h_intern(&lf[41],14,"\010compilerqnode");
lf[42]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005C_eqp\376\377\016");
lf[43]=C_h_intern(&lf[43],5,"quote");
lf[44]=C_h_intern(&lf[44],13,"\004corevariable");
lf[45]=C_h_intern(&lf[45],5,"cons\052");
lf[46]=C_h_intern(&lf[46],3,"map");
lf[47]=C_h_intern(&lf[47],6,"append");
lf[48]=C_h_intern(&lf[48],7,"butlast");
lf[49]=C_h_intern(&lf[49],9,"\004coreproc");
lf[50]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\007C_apply\376\003\000\000\002\376\377\006\001\376\377\016");
lf[51]=C_h_intern(&lf[51],6,"values");
lf[52]=C_h_intern(&lf[52],10,"\003sysvalues");
lf[53]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\016C_apply_values\376\003\000\000\002\376\377\006\001\376\377\016");
lf[54]=C_h_intern(&lf[54],7,"\003sysget");
lf[55]=C_h_intern(&lf[55],18,"\010compilerintrinsic");
lf[56]=C_h_intern(&lf[56],4,"last");
lf[57]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\006C_slot\376\377\016");
lf[58]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\016C_i_vector_ref\376\377\016");
lf[59]=C_h_intern(&lf[59],6,"vector");
lf[60]=C_h_intern(&lf[60],12,"\010compilerget");
lf[61]=C_h_intern(&lf[61],14,"rest-parameter");
lf[62]=C_h_intern(&lf[62],30,"call-with-current-continuation");
lf[63]=C_h_intern(&lf[63],16,"\010compilerrewrite");
lf[64]=C_h_intern(&lf[64],11,"\004corelambda");
lf[65]=C_h_intern(&lf[65],3,"let");
lf[66]=C_h_intern(&lf[66],16,"\010compilervarnode");
lf[67]=C_h_intern(&lf[67],6,"gensym");
lf[68]=C_h_intern(&lf[68],2,"f_");
lf[69]=C_h_intern(&lf[69],18,"\010compilerdebugging");
lf[70]=C_h_intern(&lf[70],1,"o");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000)removing single-valued `call-with-values\047");
lf[72]=C_h_intern(&lf[72],1,"r");
lf[73]=C_h_intern(&lf[73],5,"value");
lf[74]=C_h_intern(&lf[74],14,"\004coreundefined");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\014C_a_i_vector");
lf[76]=C_h_intern(&lf[76],13,"list-tabulate");
lf[77]=C_h_intern(&lf[77],16,"inline-transient");
lf[78]=C_h_intern(&lf[78],8,"assigned");
lf[79]=C_h_intern(&lf[79],10,"references");
lf[80]=C_h_intern(&lf[80],30,"\010compilerdecompose-lambda-list");
lf[81]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012C_a_i_cons\376\003\000\000\002\376\377\001\000\000\000\003\376\377\016");
lf[82]=C_h_intern(&lf[82],5,"xcons");
lf[83]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012C_a_i_cons\376\003\000\000\002\376\377\001\000\000\000\003\376\377\016");
lf[84]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012C_a_i_cons\376\003\000\000\002\376\377\001\000\000\000\003\376\377\016");
lf[85]=C_h_intern(&lf[85],10,"alist-cons");
lf[86]=C_h_intern(&lf[86],15,"\003sysget-keyword");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\017C_i_get_keyword");
lf[88]=C_h_intern(&lf[88],11,"get-keyword");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\017C_i_get_keyword");
lf[90]=C_h_intern(&lf[90],18,"substring-index-ci");
lf[91]=C_h_intern(&lf[91],22,"\003syssubstring-index-ci");
lf[92]=C_h_intern(&lf[92],15,"substring-index");
lf[93]=C_h_intern(&lf[93],19,"\003syssubstring-index");
lf[94]=C_h_intern(&lf[94],14,"substring-ci=\077");
lf[95]=C_h_intern(&lf[95],18,"\003syssubstring-ci=\077");
lf[96]=C_h_intern(&lf[96],11,"substring=\077");
lf[97]=C_h_intern(&lf[97],15,"\003syssubstring=\077");
lf[98]=C_h_intern(&lf[98],11,"read-string");
lf[99]=C_h_intern(&lf[99],20,"\003sysread-string/port");
lf[100]=C_h_intern(&lf[100],18,"\003sysstandard-input");
lf[101]=C_h_intern(&lf[101],10,"write-char");
lf[102]=C_h_intern(&lf[102],19,"\003syswrite-char/port");
lf[103]=C_h_intern(&lf[103],19,"\003sysstandard-output");
lf[104]=C_h_intern(&lf[104],9,"read-char");
lf[105]=C_h_intern(&lf[105],18,"\003sysread-char/port");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\016C_u_i_bit_setp");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\014C_i_bit_setp");
lf[108]=C_h_intern(&lf[108],8,"bit-set\077");
lf[109]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\006C_anyp\376\377\016");
lf[110]=C_h_intern(&lf[110],6,"global");
lf[111]=C_h_intern(&lf[111],4,"any\077");
lf[112]=C_h_intern(&lf[112],18,"current-error-port");
lf[113]=C_h_intern(&lf[113],18,"\003sysstandard-error");
lf[114]=C_h_intern(&lf[114],19,"current-output-port");
lf[115]=C_h_intern(&lf[115],18,"current-input-port");
lf[116]=C_h_intern(&lf[116],14,"current-thread");
lf[117]=C_h_intern(&lf[117],18,"\003syscurrent-thread");
lf[118]=C_h_intern(&lf[118],8,"\003sysvoid");
lf[119]=C_h_intern(&lf[119],19,"\003sysundefined-value");
lf[120]=C_h_intern(&lf[120],4,"void");
lf[121]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\003car\376\001\000\000\010set-car!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\003cdr\376\001\000\000\010set-cdr!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016has"
"h-table-ref\376\001\000\000\017hash-table-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011block-ref\376\001\000\000\012block-set!\376\003\000\000\002\376\003\000\000\002"
"\376\001\000\000\014locative-ref\376\001\000\000\015locative-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014u8vector-ref\376\001\000\000\015u8vector-set!"
"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014s8vector-ref\376\001\000\000\015s8vector-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015u16vector-ref\376\001\000\000\016u1"
"6vector-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015s16vector-ref\376\001\000\000\016s16vector-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015u32vec"
"tor-ref\376\001\000\000\016u32vector-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015s32vector-ref\376\001\000\000\016s32vector-set!\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\015f32vector-ref\376\001\000\000\016f32vector-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015f64vector-ref\376\001\000\000\016f64vect"
"or-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016pointer-u8-ref\376\001\000\000\017pointer-u8-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016pointer-s"
"8-ref\376\001\000\000\017pointer-s8-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\017pointer-u16-ref\376\001\000\000\020pointer-u16-set!\376\003\000\000"
"\002\376\003\000\000\002\376\001\000\000\017pointer-s16-ref\376\001\000\000\020pointer-s16-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\017pointer-u32-ref\376\001\000"
"\000\020pointer-u32-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\017pointer-s32-ref\376\001\000\000\020pointer-s32-set!\376\003\000\000\002\376\003\000\000\002\376"
"\001\000\000\017pointer-f32-ref\376\001\000\000\020pointer-f32-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\017pointer-f64-ref\376\001\000\000\020point"
"er-f64-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012string-ref\376\001\000\000\013string-set!\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012vector-ref\376\001\000"
"\000\013vector-set!\376\377\016");
lf[122]=C_h_intern(&lf[122],10,"\003syssetter");
lf[123]=C_h_intern(&lf[123],7,"call/cc");
lf[124]=C_h_intern(&lf[124],20,"thread-specific-set!");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\013C_i_setslot");
lf[126]=C_h_intern(&lf[126],15,"thread-specific");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\006C_slot");
lf[128]=C_h_intern(&lf[128],15,"\003sysmake-vector");
lf[129]=C_h_intern(&lf[129],11,"make-vector");
lf[130]=C_h_intern(&lf[130],22,"f64vector->blob/shared");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\006C_slot");
lf[132]=C_h_intern(&lf[132],22,"f32vector->blob/shared");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\006C_slot");
lf[134]=C_h_intern(&lf[134],22,"s32vector->blob/shared");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\006C_slot");
lf[136]=C_h_intern(&lf[136],22,"u32vector->blob/shared");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\006C_slot");
lf[138]=C_h_intern(&lf[138],22,"s16vector->blob/shared");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\006C_slot");
lf[140]=C_h_intern(&lf[140],22,"u16vector->blob/shared");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\006C_slot");
lf[142]=C_h_intern(&lf[142],21,"s8vector->blob/shared");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\006C_slot");
lf[144]=C_h_intern(&lf[144],21,"u8vector->blob/shared");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\006C_slot");
lf[146]=C_h_intern(&lf[146],10,"null-list\077");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\017C_i_null_list_p");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\011C_i_nullp");
lf[149]=C_h_intern(&lf[149],5,"atom\077");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_not_pair_p");
lf[151]=C_h_intern(&lf[151],9,"not-pair\077");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_not_pair_p");
lf[153]=C_h_intern(&lf[153],16,"f64vector-length");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\025C_u_i_64vector_length");
lf[155]=C_h_intern(&lf[155],16,"f32vector-length");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\025C_u_i_32vector_length");
lf[157]=C_h_intern(&lf[157],16,"s32vector-length");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\025C_u_i_32vector_length");
lf[159]=C_h_intern(&lf[159],16,"u32vector-length");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\025C_u_i_32vector_length");
lf[161]=C_h_intern(&lf[161],16,"s16vector-length");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\025C_u_i_16vector_length");
lf[163]=C_h_intern(&lf[163],16,"u16vector-length");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\025C_u_i_16vector_length");
lf[165]=C_h_intern(&lf[165],15,"s8vector-length");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\024C_u_i_8vector_length");
lf[167]=C_h_intern(&lf[167],15,"u8vector-length");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\024C_u_i_8vector_length");
lf[169]=C_h_intern(&lf[169],14,"f64vector-set!");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\023C_u_i_f64vector_set");
lf[171]=C_h_intern(&lf[171],14,"f32vector-set!");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\023C_u_i_f32vector_set");
lf[173]=C_h_intern(&lf[173],14,"s32vector-set!");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\023C_u_i_s32vector_set");
lf[175]=C_h_intern(&lf[175],14,"u32vector-set!");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\023C_u_i_u32vector_set");
lf[177]=C_h_intern(&lf[177],14,"s16vector-set!");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\023C_u_i_s16vector_set");
lf[179]=C_h_intern(&lf[179],14,"u16vector-set!");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\023C_u_i_u16vector_set");
lf[181]=C_h_intern(&lf[181],13,"s8vector-set!");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\022C_u_i_s8vector_set");
lf[183]=C_h_intern(&lf[183],13,"u8vector-set!");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\022C_u_i_u8vector_set");
lf[185]=C_h_intern(&lf[185],13,"s32vector-ref");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\025C_a_u_i_s32vector_ref");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\023C_u_i_s32vector_ref");
lf[188]=C_h_intern(&lf[188],13,"u32vector-ref");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\025C_a_u_i_u32vector_ref");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\023C_u_i_u32vector_ref");
lf[191]=C_h_intern(&lf[191],13,"f64vector-ref");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\025C_a_u_i_f64vector_ref");
lf[193]=C_h_intern(&lf[193],13,"f32vector-ref");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\025C_a_u_i_f32vector_ref");
lf[195]=C_h_intern(&lf[195],13,"s16vector-ref");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\023C_u_i_s16vector_ref");
lf[197]=C_h_intern(&lf[197],13,"u16vector-ref");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\023C_u_i_u16vector_ref");
lf[199]=C_h_intern(&lf[199],12,"s8vector-ref");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\022C_u_i_s8vector_ref");
lf[201]=C_h_intern(&lf[201],12,"u8vector-ref");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\022C_u_i_u8vector_ref");
lf[203]=C_h_intern(&lf[203],9,"blob-size");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\014C_block_size");
lf[205]=C_h_intern(&lf[205],17,"\003sysdirect-return");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\017C_direct_return");
lf[207]=C_h_intern(&lf[207],37,"\003sysforeign-unsigned-integer-argument");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000&C_i_foreign_unsigned_integer_argumentp");
lf[209]=C_h_intern(&lf[209],28,"\003sysforeign-integer-argument");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\035C_i_foreign_integer_argumentp");
lf[211]=C_h_intern(&lf[211],28,"\003sysforeign-pointer-argument");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\035C_i_foreign_pointer_argumentp");
lf[213]=C_h_intern(&lf[213],27,"\003sysforeign-string-argument");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\034C_i_foreign_string_argumentp");
lf[215]=C_h_intern(&lf[215],35,"\003sysforeign-struct-wrapper-argument");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000$C_i_foreign_struct_wrapper_argumentp");
lf[217]=C_h_intern(&lf[217],26,"\003sysforeign-block-argument");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\033C_i_foreign_block_argumentp");
lf[219]=C_h_intern(&lf[219],27,"\003sysforeign-flonum-argument");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\034C_i_foreign_flonum_argumentp");
lf[221]=C_h_intern(&lf[221],25,"\003sysforeign-char-argument");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\032C_i_foreign_char_argumentp");
lf[223]=C_h_intern(&lf[223],27,"\003sysforeign-fixnum-argument");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\034C_i_foreign_fixnum_argumentp");
lf[225]=C_h_intern(&lf[225],13,"locative-set!");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\020C_i_locative_set");
lf[227]=C_h_intern(&lf[227],16,"locative->object");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\026C_i_locative_to_object");
lf[229]=C_h_intern(&lf[229],14,"\003sysimmediate\077");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\006C_immp");
lf[231]=C_h_intern(&lf[231],13,"null-pointer\077");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\021C_i_null_pointerp");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\017C_null_pointerp");
lf[234]=C_h_intern(&lf[234],17,"\003sysnull-pointer\077");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\017C_null_pointerp");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\017C_null_pointerp");
lf[237]=C_h_intern(&lf[237],14,"\003syspermanent\077");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\014C_permanentp");
lf[239]=C_h_intern(&lf[239],27,"\003sysflonum-in-fixnum-range\077");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\032C_flonum_in_fixnum_range_p");
lf[241]=C_h_intern(&lf[241],25,"\003sysfits-in-unsigned-int\077");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\030C_fits_in_unsigned_int_p");
lf[243]=C_h_intern(&lf[243],16,"\003sysfits-in-int\077");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\017C_fits_in_int_p");
lf[245]=C_h_intern(&lf[245],9,"\003sysfudge");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\007C_fudge");
lf[247]=C_h_intern(&lf[247],11,"string-ci=\077");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\025C_i_string_ci_equal_p");
lf[249]=C_h_intern(&lf[249],8,"string=\077");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\022C_i_string_equal_p");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\024C_u_i_string_equal_p");
lf[252]=C_h_intern(&lf[252],15,"\003syspoke-double");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\015C_poke_double");
lf[254]=C_h_intern(&lf[254],16,"\003syspoke-integer");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000\016C_poke_integer");
lf[256]=C_h_intern(&lf[256],12,"\003syssetislot");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_set_i_slot");
lf[258]=C_h_intern(&lf[258],15,"pointer->object");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000\023C_pointer_to_object");
lf[260]=C_h_intern(&lf[260],13,"\003syspeek-byte");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\013C_peek_byte");
lf[262]=C_h_intern(&lf[262],15,"\003syspeek-fixnum");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\015C_peek_fixnum");
lf[264]=C_h_intern(&lf[264],11,"\003syssetbyte");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\011C_setbyte");
lf[266]=C_h_intern(&lf[266],8,"\003sysbyte");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\011C_subbyte");
lf[268]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\033C_i_fixnum_arithmetic_shift\376\377\016");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\026C_a_i_arithmetic_shift");
lf[270]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\024C_fixnum_shift_right\376\377\016");
lf[271]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\023C_fixnum_shift_left\376\377\016");
lf[272]=C_h_intern(&lf[272],20,"\010compilerbig-fixnum\077");
lf[273]=C_h_intern(&lf[273],16,"arithmetic-shift");
lf[274]=C_h_intern(&lf[274],5,"fxmod");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\017C_fixnum_modulo");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\021C_u_fixnum_modulo");
lf[277]=C_h_intern(&lf[277],3,"fx/");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\017C_fixnum_divide");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\021C_u_fixnum_divide");
lf[280]=C_h_intern(&lf[280],5,"fxior");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\013C_fixnum_or");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000\015C_u_fixnum_or");
lf[283]=C_h_intern(&lf[283],5,"fxand");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fixnum_and");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\016C_u_fixnum_and");
lf[286]=C_h_intern(&lf[286],5,"fxxor");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fixnum_xor");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fixnum_xor");
lf[289]=C_h_intern(&lf[289],5,"fxneg");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\017C_fixnum_negate");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\021C_u_fixnum_negate");
lf[292]=C_h_intern(&lf[292],5,"fxshr");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\024C_fixnum_shift_right");
lf[294]=C_h_intern(&lf[294],5,"fxshl");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\023C_fixnum_shift_left");
lf[296]=C_h_intern(&lf[296],3,"fx-");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\023C_fixnum_difference");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\025C_u_fixnum_difference");
lf[299]=C_h_intern(&lf[299],3,"fx+");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\015C_fixnum_plus");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\017C_u_fixnum_plus");
lf[302]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\016C_i_set_i_slot\376\377\016");
lf[303]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\013C_i_setslot\376\377\016");
lf[304]=C_h_intern(&lf[304],19,"\010compilerimmediate\077");
lf[305]=C_h_intern(&lf[305],11,"\003syssetslot");
lf[306]=C_h_intern(&lf[306],15,"pointer-f64-ref");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\027C_a_u_i_pointer_f64_ref");
lf[308]=C_h_intern(&lf[308],15,"pointer-f32-ref");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\027C_a_u_i_pointer_f32_ref");
lf[310]=C_h_intern(&lf[310],15,"pointer-s32-ref");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\027C_a_u_i_pointer_s32_ref");
lf[312]=C_h_intern(&lf[312],15,"pointer-u32-ref");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\027C_a_u_i_pointer_u32_ref");
lf[314]=C_h_intern(&lf[314],16,"pointer-f64-set!");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\025C_u_i_pointer_f64_set");
lf[316]=C_h_intern(&lf[316],16,"pointer-f32-set!");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\025C_u_i_pointer_f32_set");
lf[318]=C_h_intern(&lf[318],16,"pointer-s32-set!");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\025C_u_i_pointer_s32_set");
lf[320]=C_h_intern(&lf[320],16,"pointer-u32-set!");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\025C_u_i_pointer_u32_set");
lf[322]=C_h_intern(&lf[322],16,"pointer-s16-set!");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\025C_u_i_pointer_s16_set");
lf[324]=C_h_intern(&lf[324],16,"pointer-u16-set!");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\025C_u_i_pointer_u16_set");
lf[326]=C_h_intern(&lf[326],15,"pointer-s8-set!");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\024C_u_i_pointer_s8_set");
lf[328]=C_h_intern(&lf[328],15,"pointer-u8-set!");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\024C_u_i_pointer_u8_set");
lf[330]=C_h_intern(&lf[330],15,"pointer-s16-ref");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\025C_u_i_pointer_s16_ref");
lf[332]=C_h_intern(&lf[332],15,"pointer-u16-ref");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\025C_u_i_pointer_u16_ref");
lf[334]=C_h_intern(&lf[334],14,"pointer-s8-ref");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\024C_u_i_pointer_s8_ref");
lf[336]=C_h_intern(&lf[336],14,"pointer-u8-ref");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\024C_u_i_pointer_u8_ref");
lf[338]=C_h_intern(&lf[338],8,"pointer+");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\023C_a_u_i_pointer_inc");
lf[340]=C_h_intern(&lf[340],16,"pointer->address");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\030C_a_i_pointer_to_address");
lf[342]=C_h_intern(&lf[342],16,"address->pointer");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\030C_a_i_address_to_pointer");
lf[344]=C_h_intern(&lf[344],6,"string");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\014C_a_i_string");
lf[346]=C_h_intern(&lf[346],18,"\003sysmake-structure");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\014C_a_i_record");
lf[348]=C_h_intern(&lf[348],10,"\003sysvector");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000\014C_a_i_vector");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\014C_a_i_vector");
lf[351]=C_h_intern(&lf[351],8,"\003syslist");
lf[352]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[353]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\003\376\377\016");
lf[354]=C_h_intern(&lf[354],4,"list");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[356]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\003\376\377\016");
lf[357]=C_h_intern(&lf[357],8,"\003syscons");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_cons");
lf[359]=C_h_intern(&lf[359],4,"cons");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_cons");
lf[361]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\026C_a_i_string_to_number\376\003\000\000\002\376\377\001\000\000\000\004\376\377\016");
lf[362]=C_h_intern(&lf[362],14,"string->number");
lf[363]=C_h_intern(&lf[363],7,"fpround");
lf[364]=C_decode_literal(C_heaptop,"\376B\000\000\022C_a_i_flonum_floor");
lf[365]=C_h_intern(&lf[365],9,"fpceiling");
lf[366]=C_decode_literal(C_heaptop,"\376B\000\000\024C_a_i_flonum_ceiling");
lf[367]=C_decode_literal(C_heaptop,"\376B\000\000\022C_a_i_flonum_round");
lf[368]=C_h_intern(&lf[368],10,"fptruncate");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000\025C_a_i_flonum_truncate");
lf[370]=C_h_intern(&lf[370],5,"fpabs");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\020C_a_i_flonum_abs");
lf[372]=C_h_intern(&lf[372],6,"fpsqrt");
lf[373]=C_decode_literal(C_heaptop,"\376B\000\000\021C_a_i_flonum_sqrt");
lf[374]=C_h_intern(&lf[374],5,"fplog");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000\020C_a_i_flonum_log");
lf[376]=C_h_intern(&lf[376],6,"fpexpt");
lf[377]=C_decode_literal(C_heaptop,"\376B\000\000\021C_a_i_flonum_expt");
lf[378]=C_h_intern(&lf[378],5,"fpexp");
lf[379]=C_decode_literal(C_heaptop,"\376B\000\000\020C_a_i_flonum_exp");
lf[380]=C_h_intern(&lf[380],7,"fpatan2");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000\022C_a_i_flonum_atan2");
lf[382]=C_h_intern(&lf[382],6,"fpatan");
lf[383]=C_decode_literal(C_heaptop,"\376B\000\000\021C_a_i_flonum_atan");
lf[384]=C_h_intern(&lf[384],6,"fpacos");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000\021C_a_i_flonum_acos");
lf[386]=C_h_intern(&lf[386],6,"fpasin");
lf[387]=C_decode_literal(C_heaptop,"\376B\000\000\021C_a_i_flonum_asin");
lf[388]=C_h_intern(&lf[388],5,"fptan");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000\020C_a_i_flonum_tan");
lf[390]=C_h_intern(&lf[390],5,"fpcos");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000\020C_a_i_flonum_cos");
lf[392]=C_h_intern(&lf[392],5,"fpsin");
lf[393]=C_decode_literal(C_heaptop,"\376B\000\000\020C_a_i_flonum_sin");
lf[394]=C_h_intern(&lf[394],8,"truncate");
lf[395]=C_h_intern(&lf[395],6,"flonum");
lf[396]=C_h_intern(&lf[396],7,"ceiling");
lf[397]=C_h_intern(&lf[397],5,"floor");
lf[398]=C_h_intern(&lf[398],7,"fpfloor");
lf[399]=C_h_intern(&lf[399],7,"fxeven\077");
lf[400]=C_decode_literal(C_heaptop,"\376B\000\000\017C_i_fixnumevenp");
lf[401]=C_h_intern(&lf[401],6,"fxodd\077");
lf[402]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_fixnumoddp");
lf[403]=C_h_intern(&lf[403],4,"odd\077");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\010C_i_oddp");
lf[405]=C_decode_literal(C_heaptop,"\376B\000\000\012C_u_i_oddp");
lf[406]=C_h_intern(&lf[406],5,"even\077");
lf[407]=C_decode_literal(C_heaptop,"\376B\000\000\011C_i_evenp");
lf[408]=C_decode_literal(C_heaptop,"\376B\000\000\013C_u_i_evenp");
lf[409]=C_h_intern(&lf[409],9,"remainder");
lf[410]=C_decode_literal(C_heaptop,"\376B\000\000\017C_fixnum_modulo");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000\017C_fixnum_modulo");
lf[412]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_fixnumoddp");
lf[413]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_fixnumoddp");
lf[414]=C_decode_literal(C_heaptop,"\376B\000\000\017C_i_fixnumevenp");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000\017C_i_fixnumevenp");
lf[416]=C_h_intern(&lf[416],15,"\003sysmake-symbol");
lf[417]=C_decode_literal(C_heaptop,"\376B\000\000\015C_make_symbol");
lf[418]=C_h_intern(&lf[418],17,"\003sysintern-symbol");
lf[419]=C_decode_literal(C_heaptop,"\376B\000\000\022C_string_to_symbol");
lf[420]=C_h_intern(&lf[420],18,"\003syscontext-switch");
lf[421]=C_decode_literal(C_heaptop,"\376B\000\000\020C_context_switch");
lf[422]=C_h_intern(&lf[422],14,"return-to-host");
lf[423]=C_decode_literal(C_heaptop,"\376B\000\000\020C_return_to_host");
lf[424]=C_h_intern(&lf[424],23,"\003sysensure-heap-reserve");
lf[425]=C_decode_literal(C_heaptop,"\376B\000\000\025C_ensure_heap_reserve");
lf[426]=C_h_intern(&lf[426],19,"\003sysallocate-vector");
lf[427]=C_decode_literal(C_heaptop,"\376B\000\000\021C_allocate_vector");
lf[428]=C_h_intern(&lf[428],34,"\003syscall-with-current-continuation");
lf[429]=C_decode_literal(C_heaptop,"\376B\000\000\011C_call_cc");
lf[430]=C_h_intern(&lf[430],14,"number->string");
lf[431]=C_decode_literal(C_heaptop,"\376B\000\000\022C_number_to_string");
lf[432]=C_h_intern(&lf[432],2,"<=");
lf[433]=C_decode_literal(C_heaptop,"\376B\000\000\021C_less_or_equal_p");
lf[434]=C_h_intern(&lf[434],2,">=");
lf[435]=C_decode_literal(C_heaptop,"\376B\000\000\024C_greater_or_equal_p");
lf[436]=C_h_intern(&lf[436],1,"<");
lf[437]=C_decode_literal(C_heaptop,"\376B\000\000\007C_lessp");
lf[438]=C_h_intern(&lf[438],1,">");
lf[439]=C_decode_literal(C_heaptop,"\376B\000\000\012C_greaterp");
lf[440]=C_h_intern(&lf[440],1,"=");
lf[441]=C_decode_literal(C_heaptop,"\376B\000\000\011C_nequalp");
lf[442]=C_h_intern(&lf[442],1,"/");
lf[443]=C_decode_literal(C_heaptop,"\376B\000\000\010C_divide");
lf[444]=C_h_intern(&lf[444],1,"+");
lf[445]=C_decode_literal(C_heaptop,"\376B\000\000\006C_plus");
lf[446]=C_h_intern(&lf[446],1,"-");
lf[447]=C_decode_literal(C_heaptop,"\376B\000\000\007C_minus");
lf[448]=C_h_intern(&lf[448],1,"\052");
lf[449]=C_decode_literal(C_heaptop,"\376B\000\000\007C_times");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\000\022C_i_less_or_equalp");
lf[451]=C_decode_literal(C_heaptop,"\376B\000\000\025C_i_greater_or_equalp");
lf[452]=C_decode_literal(C_heaptop,"\376B\000\000\011C_i_lessp");
lf[453]=C_decode_literal(C_heaptop,"\376B\000\000\014C_i_greaterp");
lf[454]=C_decode_literal(C_heaptop,"\376B\000\000\013C_i_nequalp");
lf[455]=C_h_intern(&lf[455],14,"exact->inexact");
lf[456]=C_decode_literal(C_heaptop,"\376B\000\000\026C_a_i_exact_to_inexact");
lf[457]=C_decode_literal(C_heaptop,"\376B\000\000\014C_a_i_divide");
lf[458]=C_decode_literal(C_heaptop,"\376B\000\000\013C_a_i_minus");
lf[459]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_plus");
lf[460]=C_decode_literal(C_heaptop,"\376B\000\000\013C_a_i_times");
lf[461]=C_h_intern(&lf[461],4,"argv");
lf[462]=C_decode_literal(C_heaptop,"\376B\000\000\012C_get_argv");
lf[463]=C_h_intern(&lf[463],3,"lcm");
lf[464]=C_h_intern(&lf[464],3,"gcd");
lf[465]=C_h_intern(&lf[465],8,"identity");
lf[466]=C_h_intern(&lf[466],7,"\003syslcm");
lf[467]=C_h_intern(&lf[467],7,"\003sysgcd");
lf[468]=C_h_intern(&lf[468],11,"vector-set!");
lf[469]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_vector_set");
lf[470]=C_h_intern(&lf[470],12,"list->string");
lf[471]=C_h_intern(&lf[471],16,"\003syslist->string");
lf[472]=C_h_intern(&lf[472],12,"string->list");
lf[473]=C_h_intern(&lf[473],16,"\003sysstring->list");
lf[474]=C_h_intern(&lf[474],13,"string-append");
lf[475]=C_h_intern(&lf[475],17,"\003sysstring-append");
lf[476]=C_h_intern(&lf[476],9,"substring");
lf[477]=C_h_intern(&lf[477],13,"\003syssubstring");
lf[478]=C_h_intern(&lf[478],20,"make-record-instance");
lf[479]=C_h_intern(&lf[479],14,"\003sysblock-set!");
lf[480]=C_h_intern(&lf[480],10,"block-set!");
lf[481]=C_h_intern(&lf[481],7,"\003sysmap");
lf[482]=C_h_intern(&lf[482],8,"for-each");
lf[483]=C_h_intern(&lf[483],12,"\003sysfor-each");
lf[484]=C_h_intern(&lf[484],6,"setter");
lf[485]=C_decode_literal(C_heaptop,"\376B\000\000\030C_fixnum_less_or_equal_p");
lf[486]=C_decode_literal(C_heaptop,"\376B\000\000\030C_flonum_less_or_equal_p");
lf[487]=C_decode_literal(C_heaptop,"\376B\000\000\033C_fixnum_greater_or_equal_p");
lf[488]=C_decode_literal(C_heaptop,"\376B\000\000\033C_flonum_greater_or_equal_p");
lf[489]=C_decode_literal(C_heaptop,"\376B\000\000\016C_fixnum_lessp");
lf[490]=C_decode_literal(C_heaptop,"\376B\000\000\016C_flonum_lessp");
lf[491]=C_decode_literal(C_heaptop,"\376B\000\000\021C_fixnum_greaterp");
lf[492]=C_decode_literal(C_heaptop,"\376B\000\000\021C_flonum_greaterp");
lf[493]=C_decode_literal(C_heaptop,"\376B\000\000\005C_eqp");
lf[494]=C_decode_literal(C_heaptop,"\376B\000\000\012C_i_equalp");
lf[495]=C_h_intern(&lf[495],14,"\003syscheck-char");
lf[496]=C_decode_literal(C_heaptop,"\376B\000\000\020C_i_check_char_2");
lf[497]=C_h_intern(&lf[497],19,"\003syscheck-structure");
lf[498]=C_decode_literal(C_heaptop,"\376B\000\000\025C_i_check_structure_2");
lf[499]=C_h_intern(&lf[499],16,"\003syscheck-vector");
lf[500]=C_decode_literal(C_heaptop,"\376B\000\000\022C_i_check_vector_2");
lf[501]=C_h_intern(&lf[501],21,"\003syscheck-byte-vector");
lf[502]=C_decode_literal(C_heaptop,"\376B\000\000\026C_i_check_bytevector_2");
lf[503]=C_h_intern(&lf[503],16,"\003syscheck-string");
lf[504]=C_decode_literal(C_heaptop,"\376B\000\000\022C_i_check_string_2");
lf[505]=C_h_intern(&lf[505],16,"\003syscheck-symbol");
lf[506]=C_decode_literal(C_heaptop,"\376B\000\000\022C_i_check_symbol_2");
lf[507]=C_h_intern(&lf[507],18,"\003syscheck-locative");
lf[508]=C_decode_literal(C_heaptop,"\376B\000\000\024C_i_check_locative_2");
lf[509]=C_h_intern(&lf[509],17,"\003syscheck-boolean");
lf[510]=C_decode_literal(C_heaptop,"\376B\000\000\023C_i_check_boolean_2");
lf[511]=C_h_intern(&lf[511],14,"\003syscheck-pair");
lf[512]=C_decode_literal(C_heaptop,"\376B\000\000\020C_i_check_pair_2");
lf[513]=C_h_intern(&lf[513],14,"\003syscheck-list");
lf[514]=C_decode_literal(C_heaptop,"\376B\000\000\020C_i_check_list_2");
lf[515]=C_h_intern(&lf[515],16,"\003syscheck-number");
lf[516]=C_decode_literal(C_heaptop,"\376B\000\000\022C_i_check_number_2");
lf[517]=C_h_intern(&lf[517],15,"\003syscheck-exact");
lf[518]=C_decode_literal(C_heaptop,"\376B\000\000\021C_i_check_exact_2");
lf[519]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_check_char");
lf[520]=C_decode_literal(C_heaptop,"\376B\000\000\023C_i_check_structure");
lf[521]=C_decode_literal(C_heaptop,"\376B\000\000\020C_i_check_vector");
lf[522]=C_decode_literal(C_heaptop,"\376B\000\000\024C_i_check_bytevector");
lf[523]=C_decode_literal(C_heaptop,"\376B\000\000\020C_i_check_string");
lf[524]=C_decode_literal(C_heaptop,"\376B\000\000\020C_i_check_symbol");
lf[525]=C_decode_literal(C_heaptop,"\376B\000\000\022C_i_check_locative");
lf[526]=C_decode_literal(C_heaptop,"\376B\000\000\021C_i_check_boolean");
lf[527]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_check_pair");
lf[528]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_check_list");
lf[529]=C_decode_literal(C_heaptop,"\376B\000\000\020C_i_check_number");
lf[530]=C_decode_literal(C_heaptop,"\376B\000\000\017C_i_check_exact");
lf[531]=C_h_intern(&lf[531],14,"inexact->exact");
lf[532]=C_decode_literal(C_heaptop,"\376B\000\000\024C_i_inexact_to_exact");
lf[533]=C_h_intern(&lf[533],13,"string-length");
lf[534]=C_decode_literal(C_heaptop,"\376B\000\000\021C_i_string_length");
lf[535]=C_h_intern(&lf[535],17,"\003sysvector-length");
lf[536]=C_decode_literal(C_heaptop,"\376B\000\000\021C_i_vector_length");
lf[537]=C_h_intern(&lf[537],13,"vector-length");
lf[538]=C_decode_literal(C_heaptop,"\376B\000\000\021C_i_vector_length");
lf[539]=C_h_intern(&lf[539],13,"integer->char");
lf[540]=C_decode_literal(C_heaptop,"\376B\000\000\020C_make_character");
lf[541]=C_decode_literal(C_heaptop,"\376B\000\000\007C_unfix");
lf[542]=C_h_intern(&lf[542],13,"char->integer");
lf[543]=C_decode_literal(C_heaptop,"\376B\000\000\005C_fix");
lf[544]=C_decode_literal(C_heaptop,"\376B\000\000\020C_character_code");
lf[545]=C_decode_literal(C_heaptop,"\376B\000\000\005C_fix");
lf[546]=C_decode_literal(C_heaptop,"\376B\000\000\015C_header_size");
lf[547]=C_decode_literal(C_heaptop,"\376B\000\000\005C_fix");
lf[548]=C_decode_literal(C_heaptop,"\376B\000\000\015C_header_size");
lf[549]=C_h_intern(&lf[549],9,"negative\077");
lf[550]=C_decode_literal(C_heaptop,"\376B\000\000\017C_u_i_negativep");
lf[551]=C_decode_literal(C_heaptop,"\376B\000\000\015C_i_negativep");
lf[552]=C_decode_literal(C_heaptop,"\376B\000\000\016C_flonum_lessp");
lf[553]=C_decode_literal(C_heaptop,"\376B\000\000\016C_fixnum_lessp");
lf[554]=C_h_intern(&lf[554],9,"positive\077");
lf[555]=C_decode_literal(C_heaptop,"\376B\000\000\017C_u_i_positivep");
lf[556]=C_decode_literal(C_heaptop,"\376B\000\000\015C_i_positivep");
lf[557]=C_decode_literal(C_heaptop,"\376B\000\000\021C_flonum_greaterp");
lf[558]=C_decode_literal(C_heaptop,"\376B\000\000\021C_fixnum_greaterp");
lf[559]=C_h_intern(&lf[559],5,"zero\077");
lf[560]=C_decode_literal(C_heaptop,"\376B\000\000\013C_u_i_zerop");
lf[561]=C_decode_literal(C_heaptop,"\376B\000\000\011C_i_zerop");
lf[562]=C_decode_literal(C_heaptop,"\376B\000\000\005C_eqp");
lf[563]=C_h_intern(&lf[563],4,"atan");
lf[564]=C_decode_literal(C_heaptop,"\376B\000\000\013C_a_i_atan2");
lf[565]=C_h_intern(&lf[565],4,"sqrt");
lf[566]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_sqrt");
lf[567]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_atan");
lf[568]=C_h_intern(&lf[568],4,"acos");
lf[569]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_acos");
lf[570]=C_h_intern(&lf[570],4,"asin");
lf[571]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_asin");
lf[572]=C_h_intern(&lf[572],3,"log");
lf[573]=C_decode_literal(C_heaptop,"\376B\000\000\011C_a_i_log");
lf[574]=C_h_intern(&lf[574],3,"tan");
lf[575]=C_decode_literal(C_heaptop,"\376B\000\000\011C_a_i_tan");
lf[576]=C_h_intern(&lf[576],3,"cos");
lf[577]=C_decode_literal(C_heaptop,"\376B\000\000\011C_a_i_cos");
lf[578]=C_h_intern(&lf[578],3,"sin");
lf[579]=C_decode_literal(C_heaptop,"\376B\000\000\011C_a_i_sin");
lf[580]=C_h_intern(&lf[580],3,"exp");
lf[581]=C_decode_literal(C_heaptop,"\376B\000\000\011C_a_i_exp");
lf[582]=C_h_intern(&lf[582],5,"fpneg");
lf[583]=C_decode_literal(C_heaptop,"\376B\000\000\023C_a_i_flonum_negate");
lf[584]=C_h_intern(&lf[584],4,"fp/\077");
lf[585]=C_decode_literal(C_heaptop,"\376B\000\000\035C_a_i_flonum_quotient_checked");
lf[586]=C_h_intern(&lf[586],3,"fp/");
lf[587]=C_decode_literal(C_heaptop,"\376B\000\000\025C_a_i_flonum_quotient");
lf[588]=C_h_intern(&lf[588],3,"fp\052");
lf[589]=C_decode_literal(C_heaptop,"\376B\000\000\022C_a_i_flonum_times");
lf[590]=C_h_intern(&lf[590],3,"fp-");
lf[591]=C_decode_literal(C_heaptop,"\376B\000\000\027C_a_i_flonum_difference");
lf[592]=C_h_intern(&lf[592],3,"fp+");
lf[593]=C_decode_literal(C_heaptop,"\376B\000\000\021C_a_i_flonum_plus");
lf[594]=C_h_intern(&lf[594],11,"bitwise-not");
lf[595]=C_decode_literal(C_heaptop,"\376B\000\000\021C_a_i_bitwise_not");
lf[596]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fixnum_not");
lf[597]=C_h_intern(&lf[597],11,"bitwise-ior");
lf[598]=C_decode_literal(C_heaptop,"\376B\000\000\013C_fixnum_or");
lf[599]=C_decode_literal(C_heaptop,"\376B\000\000\015C_u_fixnum_or");
lf[600]=C_decode_literal(C_heaptop,"\376B\000\000\021C_a_i_bitwise_ior");
lf[601]=C_h_intern(&lf[601],11,"bitwise-and");
lf[602]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fixnum_and");
lf[603]=C_decode_literal(C_heaptop,"\376B\000\000\016C_u_fixnum_and");
lf[604]=C_decode_literal(C_heaptop,"\376B\000\000\021C_a_i_bitwise_and");
lf[605]=C_h_intern(&lf[605],11,"bitwise-xor");
lf[606]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fixnum_xor");
lf[607]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fixnum_xor");
lf[608]=C_decode_literal(C_heaptop,"\376B\000\000\021C_a_i_bitwise_xor");
lf[609]=C_h_intern(&lf[609],3,"abs");
lf[610]=C_decode_literal(C_heaptop,"\376B\000\000\011C_a_i_abs");
lf[611]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fixnum_abs");
lf[612]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fixnum_abs");
lf[613]=C_h_intern(&lf[613],8,"set-cdr!");
lf[614]=C_decode_literal(C_heaptop,"\376B\000\000\013C_i_set_cdr");
lf[615]=C_decode_literal(C_heaptop,"\376B\000\000\015C_u_i_set_cdr");
lf[616]=C_h_intern(&lf[616],8,"set-car!");
lf[617]=C_decode_literal(C_heaptop,"\376B\000\000\013C_i_set_car");
lf[618]=C_decode_literal(C_heaptop,"\376B\000\000\015C_u_i_set_car");
lf[619]=C_h_intern(&lf[619],6,"member");
lf[620]=C_decode_literal(C_heaptop,"\376B\000\000\012C_i_member");
lf[621]=C_h_intern(&lf[621],5,"assoc");
lf[622]=C_decode_literal(C_heaptop,"\376B\000\000\011C_i_assoc");
lf[623]=C_h_intern(&lf[623],4,"memq");
lf[624]=C_decode_literal(C_heaptop,"\376B\000\000\010C_i_memq");
lf[625]=C_decode_literal(C_heaptop,"\376B\000\000\012C_u_i_memq");
lf[626]=C_h_intern(&lf[626],4,"assq");
lf[627]=C_decode_literal(C_heaptop,"\376B\000\000\010C_i_assq");
lf[628]=C_decode_literal(C_heaptop,"\376B\000\000\012C_u_i_assq");
lf[629]=C_h_intern(&lf[629],4,"memv");
lf[630]=C_decode_literal(C_heaptop,"\376B\000\000\010C_i_memv");
lf[631]=C_decode_literal(C_heaptop,"\376B\000\000\010C_i_memq");
lf[632]=C_decode_literal(C_heaptop,"\376B\000\000\012C_u_i_memq");
lf[633]=C_h_intern(&lf[633],4,"assv");
lf[634]=C_decode_literal(C_heaptop,"\376B\000\000\010C_i_assv");
lf[635]=C_decode_literal(C_heaptop,"\376B\000\000\010C_i_assq");
lf[636]=C_decode_literal(C_heaptop,"\376B\000\000\012C_u_i_assq");
lf[637]=C_h_intern(&lf[637],15,"number-of-slots");
lf[638]=C_decode_literal(C_heaptop,"\376B\000\000\014C_block_size");
lf[639]=C_h_intern(&lf[639],9,"block-ref");
lf[640]=C_decode_literal(C_heaptop,"\376B\000\000\006C_slot");
lf[641]=C_h_intern(&lf[641],15,"\003sysbytevector\077");
lf[642]=C_decode_literal(C_heaptop,"\376B\000\000\015C_bytevectorp");
lf[643]=C_h_intern(&lf[643],14,"\003sysstructure\077");
lf[644]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_structurep");
lf[645]=C_h_intern(&lf[645],9,"list-tail");
lf[646]=C_decode_literal(C_heaptop,"\376B\000\000\015C_i_list_tail");
lf[647]=C_h_intern(&lf[647],13,"char-downcase");
lf[648]=C_decode_literal(C_heaptop,"\376B\000\000\023C_u_i_char_downcase");
lf[649]=C_h_intern(&lf[649],11,"char-upcase");
lf[650]=C_decode_literal(C_heaptop,"\376B\000\000\021C_u_i_char_upcase");
lf[651]=C_h_intern(&lf[651],16,"char-lower-case\077");
lf[652]=C_decode_literal(C_heaptop,"\376B\000\000\026C_u_i_char_lower_casep");
lf[653]=C_h_intern(&lf[653],16,"char-upper-case\077");
lf[654]=C_decode_literal(C_heaptop,"\376B\000\000\026C_u_i_char_upper_casep");
lf[655]=C_h_intern(&lf[655],16,"char-whitespace\077");
lf[656]=C_decode_literal(C_heaptop,"\376B\000\000\026C_u_i_char_whitespacep");
lf[657]=C_h_intern(&lf[657],16,"char-alphabetic\077");
lf[658]=C_decode_literal(C_heaptop,"\376B\000\000\026C_u_i_char_alphabeticp");
lf[659]=C_h_intern(&lf[659],13,"char-numeric\077");
lf[660]=C_decode_literal(C_heaptop,"\376B\000\000\023C_u_i_char_numericp");
lf[661]=C_h_intern(&lf[661],5,"fpmin");
lf[662]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_flonum_min");
lf[663]=C_h_intern(&lf[663],5,"fpmax");
lf[664]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_flonum_max");
lf[665]=C_h_intern(&lf[665],5,"fxmin");
lf[666]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_fixnum_min");
lf[667]=C_h_intern(&lf[667],5,"fxmax");
lf[668]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_fixnum_max");
lf[669]=C_h_intern(&lf[669],4,"fp<=");
lf[670]=C_decode_literal(C_heaptop,"\376B\000\000\030C_flonum_less_or_equal_p");
lf[671]=C_h_intern(&lf[671],4,"fp>=");
lf[672]=C_decode_literal(C_heaptop,"\376B\000\000\033C_flonum_greater_or_equal_p");
lf[673]=C_h_intern(&lf[673],3,"fp<");
lf[674]=C_decode_literal(C_heaptop,"\376B\000\000\016C_flonum_lessp");
lf[675]=C_h_intern(&lf[675],3,"fp>");
lf[676]=C_decode_literal(C_heaptop,"\376B\000\000\021C_flonum_greaterp");
lf[677]=C_h_intern(&lf[677],3,"fp=");
lf[678]=C_decode_literal(C_heaptop,"\376B\000\000\017C_flonum_equalp");
lf[679]=C_h_intern(&lf[679],4,"fx<=");
lf[680]=C_decode_literal(C_heaptop,"\376B\000\000\030C_fixnum_less_or_equal_p");
lf[681]=C_h_intern(&lf[681],4,"fx>=");
lf[682]=C_decode_literal(C_heaptop,"\376B\000\000\033C_fixnum_greater_or_equal_p");
lf[683]=C_h_intern(&lf[683],3,"fx<");
lf[684]=C_decode_literal(C_heaptop,"\376B\000\000\016C_fixnum_lessp");
lf[685]=C_h_intern(&lf[685],3,"fx>");
lf[686]=C_decode_literal(C_heaptop,"\376B\000\000\021C_fixnum_greaterp");
lf[687]=C_h_intern(&lf[687],3,"fx=");
lf[688]=C_decode_literal(C_heaptop,"\376B\000\000\005C_eqp");
lf[689]=C_h_intern(&lf[689],4,"fx/\077");
lf[690]=C_decode_literal(C_heaptop,"\376B\000\000\025C_i_o_fixnum_quotient");
lf[691]=C_h_intern(&lf[691],4,"fx\052\077");
lf[692]=C_decode_literal(C_heaptop,"\376B\000\000\022C_i_o_fixnum_times");
lf[693]=C_h_intern(&lf[693],4,"fx-\077");
lf[694]=C_decode_literal(C_heaptop,"\376B\000\000\027C_i_o_fixnum_difference");
lf[695]=C_h_intern(&lf[695],4,"fx+\077");
lf[696]=C_decode_literal(C_heaptop,"\376B\000\000\021C_i_o_fixnum_plus");
lf[697]=C_h_intern(&lf[697],3,"fx\052");
lf[698]=C_decode_literal(C_heaptop,"\376B\000\000\016C_fixnum_times");
lf[699]=C_h_intern(&lf[699],5,"fxnot");
lf[700]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fixnum_not");
lf[701]=C_h_intern(&lf[701],8,"\003syssize");
lf[702]=C_decode_literal(C_heaptop,"\376B\000\000\014C_block_size");
lf[703]=C_h_intern(&lf[703],13,"\003sysblock-ref");
lf[704]=C_decode_literal(C_heaptop,"\376B\000\000\015C_i_block_ref");
lf[705]=C_h_intern(&lf[705],8,"\003sysslot");
lf[706]=C_decode_literal(C_heaptop,"\376B\000\000\006C_slot");
lf[707]=C_h_intern(&lf[707],7,"char<=\077");
lf[708]=C_decode_literal(C_heaptop,"\376B\000\000\030C_i_char_less_or_equal_p");
lf[709]=C_h_intern(&lf[709],7,"char>=\077");
lf[710]=C_decode_literal(C_heaptop,"\376B\000\000\033C_i_char_greater_or_equal_p");
lf[711]=C_h_intern(&lf[711],6,"char<\077");
lf[712]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_char_lessp");
lf[713]=C_h_intern(&lf[713],6,"char>\077");
lf[714]=C_decode_literal(C_heaptop,"\376B\000\000\021C_i_char_greaterp");
lf[715]=C_h_intern(&lf[715],6,"char=\077");
lf[716]=C_decode_literal(C_heaptop,"\376B\000\000\017C_i_char_equalp");
lf[717]=C_h_intern(&lf[717],10,"vector-ref");
lf[718]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_vector_ref");
lf[719]=C_decode_literal(C_heaptop,"\376B\000\000\006C_slot");
lf[720]=C_h_intern(&lf[720],11,"string-set!");
lf[721]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_string_set");
lf[722]=C_decode_literal(C_heaptop,"\376B\000\000\014C_setsubchar");
lf[723]=C_h_intern(&lf[723],10,"string-ref");
lf[724]=C_decode_literal(C_heaptop,"\376B\000\000\016C_i_string_ref");
lf[725]=C_decode_literal(C_heaptop,"\376B\000\000\011C_subchar");
lf[726]=C_h_intern(&lf[726],11,"eof-object\077");
lf[727]=C_decode_literal(C_heaptop,"\376B\000\000\006C_eofp");
lf[728]=C_h_intern(&lf[728],12,"proper-list\077");
lf[729]=C_decode_literal(C_heaptop,"\376B\000\000\011C_i_listp");
lf[730]=C_h_intern(&lf[730],5,"list\077");
lf[731]=C_decode_literal(C_heaptop,"\376B\000\000\011C_i_listp");
lf[732]=C_h_intern(&lf[732],8,"inexact\077");
lf[733]=C_decode_literal(C_heaptop,"\376B\000\000\016C_u_i_inexactp");
lf[734]=C_decode_literal(C_heaptop,"\376B\000\000\014C_i_inexactp");
lf[735]=C_decode_literal(C_heaptop,"\376B\000\000\012C_nfixnump");
lf[736]=C_h_intern(&lf[736],6,"exact\077");
lf[737]=C_decode_literal(C_heaptop,"\376B\000\000\014C_u_i_exactp");
lf[738]=C_decode_literal(C_heaptop,"\376B\000\000\012C_i_exactp");
lf[739]=C_decode_literal(C_heaptop,"\376B\000\000\011C_fixnump");
lf[740]=C_h_intern(&lf[740],22,"\003sysgeneric-structure\077");
lf[741]=C_decode_literal(C_heaptop,"\376B\000\000\014C_structurep");
lf[742]=C_h_intern(&lf[742],8,"pointer\077");
lf[743]=C_decode_literal(C_heaptop,"\376B\000\000\021C_i_safe_pointerp");
lf[744]=C_h_intern(&lf[744],12,"\003syspointer\077");
lf[745]=C_decode_literal(C_heaptop,"\376B\000\000\015C_anypointerp");
lf[746]=C_h_intern(&lf[746],10,"fpinteger\077");
lf[747]=C_decode_literal(C_heaptop,"\376B\000\000\020C_u_i_fpintegerp");
lf[748]=C_h_intern(&lf[748],7,"finite\077");
lf[749]=C_decode_literal(C_heaptop,"\376B\000\000\013C_i_finitep");
lf[750]=C_h_intern(&lf[750],7,"fixnum\077");
lf[751]=C_decode_literal(C_heaptop,"\376B\000\000\011C_fixnump");
lf[752]=C_h_intern(&lf[752],7,"flonum\077");
lf[753]=C_decode_literal(C_heaptop,"\376B\000\000\013C_i_flonump");
lf[754]=C_h_intern(&lf[754],8,"integer\077");
lf[755]=C_decode_literal(C_heaptop,"\376B\000\000\014C_i_integerp");
lf[756]=C_h_intern(&lf[756],5,"real\077");
lf[757]=C_decode_literal(C_heaptop,"\376B\000\000\013C_i_numberp");
lf[758]=C_h_intern(&lf[758],9,"rational\077");
lf[759]=C_decode_literal(C_heaptop,"\376B\000\000\015C_i_rationalp");
lf[760]=C_h_intern(&lf[760],8,"complex\077");
lf[761]=C_decode_literal(C_heaptop,"\376B\000\000\013C_i_numberp");
lf[762]=C_h_intern(&lf[762],7,"number\077");
lf[763]=C_decode_literal(C_heaptop,"\376B\000\000\013C_i_numberp");
lf[764]=C_h_intern(&lf[764],8,"boolean\077");
lf[765]=C_decode_literal(C_heaptop,"\376B\000\000\012C_booleanp");
lf[766]=C_h_intern(&lf[766],5,"port\077");
lf[767]=C_decode_literal(C_heaptop,"\376B\000\000\011C_i_portp");
lf[768]=C_h_intern(&lf[768],10,"procedure\077");
lf[769]=C_decode_literal(C_heaptop,"\376B\000\000\014C_i_closurep");
lf[770]=C_h_intern(&lf[770],9,"\003syspair\077");
lf[771]=C_decode_literal(C_heaptop,"\376B\000\000\011C_i_pairp");
lf[772]=C_h_intern(&lf[772],5,"pair\077");
lf[773]=C_decode_literal(C_heaptop,"\376B\000\000\011C_i_pairp");
lf[774]=C_h_intern(&lf[774],11,"\003sysvector\077");
lf[775]=C_decode_literal(C_heaptop,"\376B\000\000\013C_i_vectorp");
lf[776]=C_h_intern(&lf[776],7,"vector\077");
lf[777]=C_decode_literal(C_heaptop,"\376B\000\000\013C_i_vectorp");
lf[778]=C_h_intern(&lf[778],7,"symbol\077");
lf[779]=C_decode_literal(C_heaptop,"\376B\000\000\013C_i_symbolp");
lf[780]=C_h_intern(&lf[780],9,"locative\077");
lf[781]=C_decode_literal(C_heaptop,"\376B\000\000\015C_i_locativep");
lf[782]=C_h_intern(&lf[782],7,"string\077");
lf[783]=C_decode_literal(C_heaptop,"\376B\000\000\013C_i_stringp");
lf[784]=C_h_intern(&lf[784],5,"char\077");
lf[785]=C_decode_literal(C_heaptop,"\376B\000\000\007C_charp");
lf[786]=C_h_intern(&lf[786],3,"not");
lf[787]=C_decode_literal(C_heaptop,"\376B\000\000\007C_i_not");
lf[788]=C_h_intern(&lf[788],6,"length");
lf[789]=C_decode_literal(C_heaptop,"\376B\000\000\012C_i_length");
lf[790]=C_h_intern(&lf[790],9,"\003sysnull\077");
lf[791]=C_decode_literal(C_heaptop,"\376B\000\000\011C_i_nullp");
lf[792]=C_h_intern(&lf[792],5,"null\077");
lf[793]=C_decode_literal(C_heaptop,"\376B\000\000\011C_i_nullp");
lf[794]=C_h_intern(&lf[794],8,"list-ref");
lf[795]=C_decode_literal(C_heaptop,"\376B\000\000\014C_i_list_ref");
lf[796]=C_decode_literal(C_heaptop,"\376B\000\000\016C_u_i_list_ref");
lf[797]=C_h_intern(&lf[797],8,"\003syseqv\077");
lf[798]=C_decode_literal(C_heaptop,"\376B\000\000\010C_i_eqvp");
lf[799]=C_h_intern(&lf[799],4,"eqv\077");
lf[800]=C_decode_literal(C_heaptop,"\376B\000\000\010C_i_eqvp");
lf[801]=C_h_intern(&lf[801],7,"\003syseq\077");
lf[802]=C_decode_literal(C_heaptop,"\376B\000\000\005C_eqp");
lf[803]=C_h_intern(&lf[803],3,"eq\077");
lf[804]=C_decode_literal(C_heaptop,"\376B\000\000\005C_eqp");
lf[805]=C_h_intern(&lf[805],3,"cdr");
lf[806]=C_decode_literal(C_heaptop,"\376B\000\000\007C_i_cdr");
lf[807]=C_decode_literal(C_heaptop,"\376B\000\000\006C_slot");
lf[808]=C_h_intern(&lf[808],6,"cddddr");
lf[809]=C_decode_literal(C_heaptop,"\376B\000\000\012C_i_cddddr");
lf[810]=C_h_intern(&lf[810],5,"cdddr");
lf[811]=C_decode_literal(C_heaptop,"\376B\000\000\011C_i_cdddr");
lf[812]=C_h_intern(&lf[812],4,"cddr");
lf[813]=C_decode_literal(C_heaptop,"\376B\000\000\010C_i_cddr");
lf[814]=C_h_intern(&lf[814],4,"cdar");
lf[815]=C_decode_literal(C_heaptop,"\376B\000\000\010C_i_cdar");
lf[816]=C_h_intern(&lf[816],4,"caar");
lf[817]=C_decode_literal(C_heaptop,"\376B\000\000\010C_i_caar");
lf[818]=C_decode_literal(C_heaptop,"\376B\000\000\014C_u_i_cddddr");
lf[819]=C_h_intern(&lf[819],6,"cdddar");
lf[820]=C_decode_literal(C_heaptop,"\376B\000\000\014C_u_i_cdddar");
lf[821]=C_h_intern(&lf[821],6,"cddadr");
lf[822]=C_decode_literal(C_heaptop,"\376B\000\000\014C_u_i_cddadr");
lf[823]=C_h_intern(&lf[823],6,"cddaar");
lf[824]=C_decode_literal(C_heaptop,"\376B\000\000\014C_u_i_cddaar");
lf[825]=C_h_intern(&lf[825],6,"cdaddr");
lf[826]=C_decode_literal(C_heaptop,"\376B\000\000\014C_u_i_cdaddr");
lf[827]=C_h_intern(&lf[827],6,"cdadar");
lf[828]=C_decode_literal(C_heaptop,"\376B\000\000\014C_u_i_cdadar");
lf[829]=C_h_intern(&lf[829],6,"cdaadr");
lf[830]=C_decode_literal(C_heaptop,"\376B\000\000\014C_u_i_cdaadr");
lf[831]=C_h_intern(&lf[831],6,"cdaaar");
lf[832]=C_decode_literal(C_heaptop,"\376B\000\000\014C_u_i_cdaaar");
lf[833]=C_h_intern(&lf[833],6,"cadddr");
lf[834]=C_decode_literal(C_heaptop,"\376B\000\000\014C_u_i_cadddr");
lf[835]=C_h_intern(&lf[835],6,"caddar");
lf[836]=C_decode_literal(C_heaptop,"\376B\000\000\014C_u_i_caddar");
lf[837]=C_h_intern(&lf[837],6,"cadadr");
lf[838]=C_decode_literal(C_heaptop,"\376B\000\000\014C_u_i_cadadr");
lf[839]=C_h_intern(&lf[839],6,"cadaar");
lf[840]=C_decode_literal(C_heaptop,"\376B\000\000\014C_u_i_cadaar");
lf[841]=C_h_intern(&lf[841],6,"caaddr");
lf[842]=C_decode_literal(C_heaptop,"\376B\000\000\014C_u_i_caaddr");
lf[843]=C_h_intern(&lf[843],6,"caadar");
lf[844]=C_decode_literal(C_heaptop,"\376B\000\000\014C_u_i_caadar");
lf[845]=C_h_intern(&lf[845],6,"caaaar");
lf[846]=C_decode_literal(C_heaptop,"\376B\000\000\014C_u_i_caaaar");
lf[847]=C_decode_literal(C_heaptop,"\376B\000\000\013C_u_i_cdddr");
lf[848]=C_h_intern(&lf[848],5,"cddar");
lf[849]=C_decode_literal(C_heaptop,"\376B\000\000\013C_u_i_cddar");
lf[850]=C_h_intern(&lf[850],5,"cdadr");
lf[851]=C_decode_literal(C_heaptop,"\376B\000\000\013C_u_i_cdadr");
lf[852]=C_h_intern(&lf[852],5,"cdaar");
lf[853]=C_decode_literal(C_heaptop,"\376B\000\000\013C_u_i_cdaar");
lf[854]=C_h_intern(&lf[854],5,"caddr");
lf[855]=C_decode_literal(C_heaptop,"\376B\000\000\013C_u_i_caddr");
lf[856]=C_h_intern(&lf[856],5,"cadar");
lf[857]=C_decode_literal(C_heaptop,"\376B\000\000\013C_u_i_cadar");
lf[858]=C_h_intern(&lf[858],5,"caaar");
lf[859]=C_decode_literal(C_heaptop,"\376B\000\000\013C_u_i_caaar");
lf[860]=C_decode_literal(C_heaptop,"\376B\000\000\012C_u_i_cddr");
lf[861]=C_decode_literal(C_heaptop,"\376B\000\000\012C_u_i_cdar");
lf[862]=C_decode_literal(C_heaptop,"\376B\000\000\012C_u_i_caar");
lf[863]=C_h_intern(&lf[863],22,"\003syscontinuation-graft");
lf[864]=C_decode_literal(C_heaptop,"\376B\000\000\024C_continuation_graft");
lf[865]=C_h_intern(&lf[865],12,"locative-ref");
lf[866]=C_decode_literal(C_heaptop,"\376B\000\000\016C_locative_ref");
lf[867]=C_h_intern(&lf[867],20,"\003syscall-with-values");
lf[868]=C_decode_literal(C_heaptop,"\376B\000\000\022C_call_with_values");
lf[869]=C_decode_literal(C_heaptop,"\376B\000\000\024C_u_call_with_values");
lf[870]=C_h_intern(&lf[870],16,"call-with-values");
lf[871]=C_decode_literal(C_heaptop,"\376B\000\000\022C_call_with_values");
lf[872]=C_decode_literal(C_heaptop,"\376B\000\000\024C_u_call_with_values");
lf[873]=C_decode_literal(C_heaptop,"\376B\000\000\010C_values");
lf[874]=C_decode_literal(C_heaptop,"\376B\000\000\010C_values");
lf[875]=C_h_intern(&lf[875],6,"fourth");
lf[876]=C_decode_literal(C_heaptop,"\376B\000\000\012C_i_cadddr");
lf[877]=C_decode_literal(C_heaptop,"\376B\000\000\014C_u_i_cadddr");
lf[878]=C_h_intern(&lf[878],5,"third");
lf[879]=C_decode_literal(C_heaptop,"\376B\000\000\011C_i_caddr");
lf[880]=C_decode_literal(C_heaptop,"\376B\000\000\013C_u_i_caddr");
lf[881]=C_h_intern(&lf[881],6,"second");
lf[882]=C_decode_literal(C_heaptop,"\376B\000\000\010C_i_cadr");
lf[883]=C_decode_literal(C_heaptop,"\376B\000\000\012C_u_i_cadr");
lf[884]=C_h_intern(&lf[884],5,"first");
lf[885]=C_decode_literal(C_heaptop,"\376B\000\000\007C_i_car");
lf[886]=C_decode_literal(C_heaptop,"\376B\000\000\011C_u_i_car");
lf[887]=C_decode_literal(C_heaptop,"\376B\000\000\012C_i_cadddr");
lf[888]=C_decode_literal(C_heaptop,"\376B\000\000\014C_u_i_cadddr");
lf[889]=C_decode_literal(C_heaptop,"\376B\000\000\011C_i_caddr");
lf[890]=C_decode_literal(C_heaptop,"\376B\000\000\013C_u_i_caddr");
lf[891]=C_h_intern(&lf[891],4,"cadr");
lf[892]=C_decode_literal(C_heaptop,"\376B\000\000\010C_i_cadr");
lf[893]=C_decode_literal(C_heaptop,"\376B\000\000\012C_u_i_cadr");
lf[894]=C_h_intern(&lf[894],7,"\003syscdr");
lf[895]=C_decode_literal(C_heaptop,"\376B\000\000\007C_i_cdr");
lf[896]=C_decode_literal(C_heaptop,"\376B\000\000\011C_u_i_cdr");
lf[897]=C_h_intern(&lf[897],7,"\003syscar");
lf[898]=C_decode_literal(C_heaptop,"\376B\000\000\007C_i_car");
lf[899]=C_decode_literal(C_heaptop,"\376B\000\000\011C_u_i_car");
lf[900]=C_h_intern(&lf[900],3,"car");
lf[901]=C_decode_literal(C_heaptop,"\376B\000\000\007C_i_car");
lf[902]=C_decode_literal(C_heaptop,"\376B\000\000\011C_u_i_car");
lf[903]=C_h_intern(&lf[903],9,"\003sysapply");
lf[904]=C_h_intern(&lf[904],5,"apply");
lf[905]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012C_i_equalp\376\377\016");
lf[906]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005C_eqp\376\377\016");
lf[907]=C_h_intern(&lf[907],6,"equal\077");
lf[908]=C_h_intern(&lf[908],4,"sub1");
lf[909]=C_decode_literal(C_heaptop,"\376B\000\000\021C_fixnum_decrease");
lf[910]=C_decode_literal(C_heaptop,"\376B\000\000\023C_u_fixnum_decrease");
lf[911]=C_decode_literal(C_heaptop,"\376B\000\000\013C_a_i_minus");
lf[912]=C_h_intern(&lf[912],4,"add1");
lf[913]=C_decode_literal(C_heaptop,"\376B\000\000\021C_fixnum_increase");
lf[914]=C_decode_literal(C_heaptop,"\376B\000\000\023C_u_fixnum_increase");
lf[915]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_plus");
lf[916]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\024C_fixnum_shift_right\376\377\016");
lf[917]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\017C_fixnum_divide\376\377\016");
lf[918]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012C_quotient\376\003\000\000\002\376\377\006\001\376\377\016");
lf[919]=C_h_intern(&lf[919],8,"quotient");
lf[920]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\024C_fixnum_shift_right\376\377\016");
lf[921]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\017C_fixnum_divide\376\377\016");
lf[922]=C_h_intern(&lf[922],19,"\010compilerfold-inner");
lf[923]=C_h_intern(&lf[923],6,"remove");
lf[924]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\021C_u_fixnum_negate\376\377\016");
lf[925]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\017C_fixnum_negate\376\377\016");
lf[926]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\025C_u_fixnum_difference\376\377\016");
lf[927]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\023C_fixnum_difference\376\377\016");
lf[928]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\023C_fixnum_shift_left\376\377\016");
lf[929]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\016C_fixnum_times\376\377\016");
lf[930]=C_decode_literal(C_heaptop,"\376B\000\000\015C_fixnum_plus");
lf[931]=C_decode_literal(C_heaptop,"\376B\000\000\017C_u_fixnum_plus");
lf[932]=C_h_intern(&lf[932],8,"\003sysput!");
lf[933]=C_h_intern(&lf[933],13,"\010compilerpure");
lf[934]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysslot\376\003\000\000\002\376\001\000\000\015\003sysblock-ref\376\003\000\000\002\376\001\000\000\010\003syssize\376\003\000\000\002\376\001\000\000\010\003sysbyte\376\003\000"
"\000\002\376\001\000\000\014\003syspointer\077\376\003\000\000\002\376\001\000\000\026\003sysgeneric-structure\077\376\003\000\000\002\376\001\000\000\020\003sysfits-in-int\077\376\003\000"
"\000\002\376\001\000\000\031\003sysfits-in-unsigned-int\077\376\003\000\000\002\376\001\000\000\033\003sysflonum-in-fixnum-range\077\376\003\000\000\002\376\001\000\000\011\003"
"sysfudge\376\003\000\000\002\376\001\000\000\016\003sysimmediate\077\376\003\000\000\002\376\001\000\000\017\003sysbytevector\077\376\003\000\000\002\376\001\000\000\011\003syspair\077\376\003\000\000"
"\002\376\001\000\000\007\003syseq\077\376\003\000\000\002\376\001\000\000\011\003syslist\077\376\003\000\000\002\376\001\000\000\013\003sysvector\077\376\003\000\000\002\376\001\000\000\010\003syseqv\077\376\003\000\000\002\376\001\000\000"
"\017\003sysget-keyword\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\003\000\000\002\376\001\000\000\016\003syspermanent\077\376\377\016");
lf[935]=C_h_intern(&lf[935],15,"lset-difference");
lf[936]=C_h_intern(&lf[936],10,"lset-union");
C_register_lf2(lf,937,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1600,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k4789 in a4737 in k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in ... */
static void C_ccall f_4791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4791,2,t0,t1);}
/* c-platform.scm:869: build */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_4741(C_a_i(&a,25),((C_word*)t0)[3],((C_word*)t0)[4],t1));}

/* k2951 in k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in k2930 in k2927 in k2924 in k2921 in k2918 in k2915 in k2912 in k2909 in k2906 in k2903 in k2900 in k2897 in k2894 in k2891 in k2888 in ... */
static void C_ccall f_2953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2953,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2956,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:659: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[665],C_fix(2),C_fix(2),lf[666],C_SCHEME_TRUE);}

/* k2954 in k2951 in k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in k2930 in k2927 in k2924 in k2921 in k2918 in k2915 in k2912 in k2909 in k2906 in k2903 in k2900 in k2897 in k2894 in k2891 in ... */
static void C_ccall f_2956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2956,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2959,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:660: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[663],C_fix(2),C_fix(2),lf[664],C_SCHEME_FALSE);}

/* k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in k2930 in k2927 in k2924 in k2921 in k2918 in k2915 in k2912 in k2909 in k2906 in k2903 in k2900 in k2897 in k2894 in k2891 in k2888 in k2885 in ... */
static void C_ccall f_2950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2950,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2953,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:658: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[667],C_fix(2),C_fix(2),lf[668],C_SCHEME_TRUE);}

/* k2957 in k2954 in k2951 in k2948 in k2945 in k2942 in k2939 in k2936 in k2933 in k2930 in k2927 in k2924 in k2921 in k2918 in k2915 in k2912 in k2909 in k2906 in k2903 in k2900 in k2897 in k2894 in ... */
static void C_ccall f_2959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2959,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2962,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:661: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[661],C_fix(2),C_fix(2),lf[662],C_SCHEME_FALSE);}

/* k4147 in a4138 in k4132 in k4129 in k4126 in k4123 in k4120 in k4117 in k4114 in k4111 in k4108 in k4105 in k4102 in k4099 in k4096 in k4093 in k4090 in k4087 in k4084 in k4081 in k4078 in k4074 in ... */
static void C_ccall f_4149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4149,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
t3=t2;
t4=C_i_car(((C_word*)t0)[2]);
t5=t4;
t6=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t7=t6;
t8=C_i_cadr(((C_word*)t0)[2]);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4207,a[2]=t9,a[3]=((C_word*)t0)[3],a[4]=t7,a[5]=t5,a[6]=((C_word*)t0)[4],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* c-platform.scm:1207: varnode */
t11=*((C_word*)lf[66]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,t1);}

/* k2942 in k2939 in k2936 in k2933 in k2930 in k2927 in k2924 in k2921 in k2918 in k2915 in k2912 in k2909 in k2906 in k2903 in k2900 in k2897 in k2894 in k2891 in k2888 in k2885 in k2882 in k2879 in ... */
static void C_ccall f_2944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2944,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2947,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:656: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[671],C_fix(2),C_fix(2),lf[672],C_SCHEME_FALSE);}

/* k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in k2948 in k2945 in k2942 in k2939 in k2936 in ... */
static void C_ccall f_3001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3004,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:676: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[633],C_fix(2),C_fix(2),lf[634],C_SCHEME_TRUE);}

/* k2939 in k2936 in k2933 in k2930 in k2927 in k2924 in k2921 in k2918 in k2915 in k2912 in k2909 in k2906 in k2903 in k2900 in k2897 in k2894 in k2891 in k2888 in k2885 in k2882 in k2879 in k2876 in ... */
static void C_ccall f_2941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2941,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2944,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:655: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[673],C_fix(2),C_fix(2),lf[674],C_SCHEME_FALSE);}

/* k3005 in k3002 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in k2948 in k2945 in k2942 in ... */
static void C_ccall f_3007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3007,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3010,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:678: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[629],C_fix(2),C_fix(2),lf[630],C_SCHEME_TRUE);}

/* k2945 in k2942 in k2939 in k2936 in k2933 in k2930 in k2927 in k2924 in k2921 in k2918 in k2915 in k2912 in k2909 in k2906 in k2903 in k2900 in k2897 in k2894 in k2891 in k2888 in k2885 in k2882 in ... */
static void C_ccall f_2947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2947,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2950,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:657: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[669],C_fix(2),C_fix(2),lf[670],C_SCHEME_FALSE);}

/* k3002 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in k2948 in k2945 in k2942 in k2939 in ... */
static void C_ccall f_3004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3007,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:677: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[629],C_fix(14),lf[34],C_fix(2),lf[631],lf[632]);}

/* a5446 in a5337 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_5447(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5447,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=C_eqp(lf[43],t4);
if(C_truep(t5)){
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=C_i_car(t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_i_zerop(t8));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k5443 in a5337 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_5445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5445,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_eqp(*((C_word*)lf[35]+1),lf[34]);
if(C_truep(t3)){
t4=C_i_length(t2);
if(C_truep(C_fixnum_greater_or_equal_p(t4,C_fix(2)))){
t5=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5415,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5417,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:306: fold-inner */
t9=*((C_word*)lf[922]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,t2);}
else{
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k3020 in k3017 in k3014 in k3011 in k3008 in k3005 in k3002 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in ... */
static void C_ccall f_3022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3025,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:684: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[616],C_fix(4),lf[305],C_fix(0));}

/* k3023 in k3020 in k3017 in k3014 in k3011 in k3008 in k3005 in k3002 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in ... */
static void C_ccall f_3025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3028,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:685: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[613],C_fix(4),lf[305],C_fix(1));}

/* k3026 in k3023 in k3020 in k3017 in k3014 in k3011 in k3008 in k3005 in k3002 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in ... */
static void C_ccall f_3028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3031,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:686: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[616],C_fix(17),C_fix(2),lf[617],lf[618]);}

/* k3179 in k3176 in k3173 in k3170 in k3167 in k3164 in k3161 in k3158 in k3155 in k3152 in k3149 in k3146 in k3143 in k3140 in k3137 in k3134 in k3131 in k3128 in k3125 in k3122 in k3119 in k3116 in ... */
static void C_ccall f_3181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3181,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3184,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:746: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[501],C_fix(2),C_fix(1),lf[522],C_SCHEME_TRUE);}

/* k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in k3164 in k3161 in k3158 in k3155 in k3152 in k3149 in k3146 in k3143 in k3140 in k3137 in k3134 in k3131 in k3128 in k3125 in k3122 in k3119 in ... */
static void C_ccall f_3184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3184,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3187,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:747: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[499],C_fix(2),C_fix(1),lf[521],C_SCHEME_TRUE);}

/* k3011 in k3008 in k3005 in k3002 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in k2948 in ... */
static void C_ccall f_3013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3016,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:680: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[623],C_fix(17),C_fix(2),lf[624],lf[625]);}

/* k3008 in k3005 in k3002 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in k2948 in k2945 in ... */
static void C_ccall f_3010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3010,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3013,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:679: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[626],C_fix(17),C_fix(2),lf[627],lf[628]);}

/* k3014 in k3011 in k3008 in k3005 in k3002 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in ... */
static void C_ccall f_3016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3019,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:681: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[621],C_fix(2),C_fix(2),lf[622],C_SCHEME_TRUE);}

/* k3017 in k3014 in k3011 in k3008 in k3005 in k3002 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in ... */
static void C_ccall f_3019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3022,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:682: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[619],C_fix(2),C_fix(2),lf[620],C_SCHEME_TRUE);}

/* k3176 in k3173 in k3170 in k3167 in k3164 in k3161 in k3158 in k3155 in k3152 in k3149 in k3146 in k3143 in k3140 in k3137 in k3134 in k3131 in k3128 in k3125 in k3122 in k3119 in k3116 in k3113 in ... */
static void C_ccall f_3178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3178,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3181,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:745: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[503],C_fix(2),C_fix(1),lf[523],C_SCHEME_TRUE);}

/* a3869 in k3813 in k3798 in rewrite-make-vector in k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in k3755 in k3752 in k3749 in k3746 in k3743 in k3740 in k3737 in k3734 in k3731 in k3728 in k3725 in ... */
static void C_ccall f_3870(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3870,3,t0,t1,t2);}
/* c-platform.scm:1060: varnode */
t3=*((C_word*)lf[66]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,((C_word*)t0)[2]);}

/* k3488 in k3485 in k3482 in k3479 in k3476 in k3473 in k3470 in k3467 in k3464 in k3461 in k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in ... */
static void C_ccall f_3490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3490,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3493,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:882: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[340],C_fix(16),C_fix(1),lf[341],C_SCHEME_FALSE,*((C_word*)lf[9]+1));}

/* k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in k3473 in k3470 in k3467 in k3464 in k3461 in k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in ... */
static void C_ccall f_3493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3493,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3496,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:883: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[338],C_fix(16),C_fix(2),lf[339],C_SCHEME_FALSE,C_fix(2));}

/* k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in k3473 in k3470 in k3467 in k3464 in k3461 in k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in ... */
static void C_ccall f_3496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3496,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3499,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:885: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[336],C_fix(2),C_fix(1),lf[337],C_SCHEME_FALSE);}

/* k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in k3473 in k3470 in k3467 in k3464 in k3461 in k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in ... */
static void C_ccall f_3499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3499,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3502,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:886: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[334],C_fix(2),C_fix(1),lf[335],C_SCHEME_FALSE);}

/* k4938 in k4828 in a4813 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_4940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
f_4867(t3,t2);}
else{
t2=((C_word*)t0)[2];
f_4867(t2,C_i_symbolp(((C_word*)t0)[3]));}}

/* k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in k3164 in k3161 in k3158 in k3155 in k3152 in k3149 in k3146 in k3143 in k3140 in k3137 in k3134 in k3131 in k3128 in k3125 in ... */
static void C_ccall f_3190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3193,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:749: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[495],C_fix(2),C_fix(1),lf[519],C_SCHEME_TRUE);}

/* k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in k3164 in k3161 in k3158 in k3155 in k3152 in k3149 in k3146 in k3143 in k3140 in k3137 in k3134 in k3131 in k3128 in ... */
static void C_ccall f_3193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3193,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3196,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:750: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[517],C_fix(2),C_fix(2),lf[518],C_SCHEME_TRUE);}

/* k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in k3164 in k3161 in k3158 in k3155 in k3152 in k3149 in k3146 in k3143 in k3140 in k3137 in k3134 in k3131 in k3128 in k3125 in k3122 in ... */
static void C_ccall f_3187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3187,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3190,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:748: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[497],C_fix(2),C_fix(2),lf[520],C_SCHEME_TRUE);}

/* k4997 in a4813 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_4999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4999,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
f_4830(t3,C_a_i_record4(&a,4,lf[37],lf[39],((C_word*)t0)[4],t2));}

/* k3197 in k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in k3164 in k3161 in k3158 in k3155 in k3152 in k3149 in k3146 in k3143 in k3140 in k3137 in k3134 in ... */
static void C_ccall f_3199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3199,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3202,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:752: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[513],C_fix(2),C_fix(2),lf[514],C_SCHEME_TRUE);}

/* k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in k3164 in k3161 in k3158 in k3155 in k3152 in k3149 in k3146 in k3143 in k3140 in k3137 in k3134 in k3131 in ... */
static void C_ccall f_3196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3196,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3199,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:751: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[515],C_fix(2),C_fix(2),lf[516],C_SCHEME_TRUE);}

/* k4447 in a4418 in k4074 in k4071 in k3922 in k3919 in k3916 in k3913 in k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in k3755 in k3752 in k3749 in k3746 in k3743 in k3740 in k3737 in ... */
static void C_ccall f_4449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4449,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_assq(((C_word*)t0)[2],lf[121]);
if(C_truep(t2)){
t3=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4475,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=C_i_cdr(t2);
/* c-platform.scm:1129: varnode */
t7=*((C_word*)lf[66]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2666 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 in k2630 in k2627 in k2624 in k2621 in k2618 in k2615 in k2612 in k2609 in k2390 in k2387 in ... */
static void C_ccall f_2668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2668,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2671,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:560: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[845],C_fix(2),C_fix(1),lf[846],C_SCHEME_FALSE);}

/* k4610 in k4582 in a4503 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in ... */
static void C_ccall f_4612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-platform.scm:951: qnode */
t2=*((C_word*)lf[41]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 in k2630 in k2627 in k2624 in k2621 in k2618 in k2615 in k2612 in k2609 in k2390 in k2387 in k2355 in ... */
static void C_ccall f_2665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2665,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2668,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:559: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[810],C_fix(2),C_fix(1),lf[847],C_SCHEME_FALSE);}

/* k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 in k2630 in k2627 in k2624 in k2621 in k2618 in k2615 in k2612 in k2609 in k2390 in k2387 in k2355 in k2352 in ... */
static void C_ccall f_2662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2662,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2665,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:558: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[848],C_fix(2),C_fix(1),lf[849],C_SCHEME_FALSE);}

/* k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 in k2630 in k2627 in k2624 in k2621 in k2618 in k2615 in k2612 in k2609 in k2390 in k2387 in k2355 in k2352 in k2349 in ... */
static void C_ccall f_2659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2659,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2662,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:557: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[850],C_fix(2),C_fix(1),lf[851],C_SCHEME_FALSE);}

/* k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 in k2630 in k2627 in k2624 in k2621 in k2618 in k2615 in k2612 in k2609 in k2390 in k2387 in k2355 in k2352 in k2349 in k2346 in ... */
static void C_ccall f_2656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2656,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2659,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:556: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[852],C_fix(2),C_fix(1),lf[853],C_SCHEME_FALSE);}

/* k2648 in k2645 in k2642 in k2639 in k2636 in k2633 in k2630 in k2627 in k2624 in k2621 in k2618 in k2615 in k2612 in k2609 in k2390 in k2387 in k2355 in k2352 in k2349 in k2346 in k2343 in k2340 in ... */
static void C_ccall f_2650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2650,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2653,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:554: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[856],C_fix(2),C_fix(1),lf[857],C_SCHEME_FALSE);}

/* k2651 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 in k2630 in k2627 in k2624 in k2621 in k2618 in k2615 in k2612 in k2609 in k2390 in k2387 in k2355 in k2352 in k2349 in k2346 in k2343 in ... */
static void C_ccall f_2653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2653,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2656,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:555: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[854],C_fix(2),C_fix(1),lf[855],C_SCHEME_FALSE);}

/* k2645 in k2642 in k2639 in k2636 in k2633 in k2630 in k2627 in k2624 in k2621 in k2618 in k2615 in k2612 in k2609 in k2390 in k2387 in k2355 in k2352 in k2349 in k2346 in k2343 in k2340 in k2337 in ... */
static void C_ccall f_2647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2647,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2650,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:553: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[858],C_fix(2),C_fix(1),lf[859],C_SCHEME_FALSE);}

/* k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in ... */
static void C_ccall f_3451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3454,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:851: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[363],C_fix(16),C_fix(1),lf[367],C_SCHEME_FALSE,*((C_word*)lf[9]+1));}

/* k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in ... */
static void C_ccall f_3457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3460,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:853: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[363],C_fix(16),C_fix(1),lf[364],C_SCHEME_FALSE,*((C_word*)lf[9]+1));}

/* k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in ... */
static void C_ccall f_3454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3457,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:852: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[365],C_fix(16),C_fix(1),lf[366],C_SCHEME_FALSE,*((C_word*)lf[9]+1));}

/* k2639 in k2636 in k2633 in k2630 in k2627 in k2624 in k2621 in k2618 in k2615 in k2612 in k2609 in k2390 in k2387 in k2355 in k2352 in k2349 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in ... */
static void C_ccall f_2641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2644,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:551: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[814],C_fix(2),C_fix(1),lf[861],C_SCHEME_FALSE);}

/* k2642 in k2639 in k2636 in k2633 in k2630 in k2627 in k2624 in k2621 in k2618 in k2615 in k2612 in k2609 in k2390 in k2387 in k2355 in k2352 in k2349 in k2346 in k2343 in k2340 in k2337 in k2334 in ... */
static void C_ccall f_2644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2644,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2647,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:552: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[812],C_fix(2),C_fix(1),lf[860],C_SCHEME_FALSE);}

/* k2636 in k2633 in k2630 in k2627 in k2624 in k2621 in k2618 in k2615 in k2612 in k2609 in k2390 in k2387 in k2355 in k2352 in k2349 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2328 in ... */
static void C_ccall f_2638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2641,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:550: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[816],C_fix(2),C_fix(1),lf[862],C_SCHEME_FALSE);}

/* k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in k3338 in k3335 in ... */
static void C_ccall f_3400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3400,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3403,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:832: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[399],C_fix(2),C_fix(1),lf[400],C_SCHEME_TRUE);}

/* k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in k3338 in ... */
static void C_ccall f_3403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3403,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3406,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:834: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[397],C_fix(15),lf[395],lf[34],lf[398],C_SCHEME_FALSE);}

/* k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in ... */
static void C_ccall f_3406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3406,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3409,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:835: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[396],C_fix(15),lf[395],lf[34],lf[365],C_SCHEME_FALSE);}

/* k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in ... */
static void C_ccall f_3409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3409,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3412,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:836: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[394],C_fix(15),lf[395],lf[34],lf[368],C_SCHEME_FALSE);}

/* k4606 in k4582 in a4503 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in ... */
static void C_ccall f_4608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4608,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
f_4534(t3,C_a_i_record4(&a,4,lf[37],lf[38],lf[270],t2));}

/* k2630 in k2627 in k2624 in k2621 in k2618 in k2615 in k2612 in k2609 in k2390 in k2387 in k2355 in k2352 in k2349 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2328 in k2185 in k2182 in ... */
static void C_ccall f_2632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2632,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2635,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:547: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[865],C_fix(13),lf[866],C_SCHEME_TRUE);}

/* k2633 in k2630 in k2627 in k2624 in k2621 in k2618 in k2615 in k2612 in k2609 in k2390 in k2387 in k2355 in k2352 in k2349 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2328 in k2185 in ... */
static void C_ccall f_2635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2635,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2638,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:548: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[863],C_fix(13),lf[864],C_SCHEME_TRUE);}

/* k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in k3359 in k3356 in ... */
static void C_ccall f_3421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3421,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3424,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:841: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[386],C_fix(16),C_fix(1),lf[387],C_SCHEME_FALSE,*((C_word*)lf[9]+1));}

/* k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in ... */
static void C_ccall f_3427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3430,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:843: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[382],C_fix(16),C_fix(1),lf[383],C_SCHEME_FALSE,*((C_word*)lf[9]+1));}

/* k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in k3359 in ... */
static void C_ccall f_3424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3427,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:842: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[384],C_fix(16),C_fix(1),lf[385],C_SCHEME_FALSE,*((C_word*)lf[9]+1));}

/* a4660 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in ... */
static void C_ccall f_4661(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4661,6,t0,t1,t2,t3,t4,t5);}
t6=C_i_length(t5);
t7=C_eqp(t6,C_fix(3));
if(C_truep(t7)){
t8=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t9=t8;
t10=C_i_caddr(t5);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4703,a[2]=t5,a[3]=t4,a[4]=t1,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
t12=C_slot(t10,C_fix(1));
t13=C_eqp(lf[43],t12);
if(C_truep(t13)){
t14=C_slot(t10,C_fix(2));
t15=C_i_car(t14);
/* c-platform.scm:916: immediate? */
t16=*((C_word*)lf[304]+1);
((C_proc3)(void*)(*((C_word*)t16+1)))(3,t16,t11,t15);}
else{
t14=t5;
t15=C_a_i_record4(&a,4,lf[37],lf[38],lf[303],t14);
t16=C_a_i_list2(&a,2,t4,t15);
t17=t1;
t18=t17;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,C_a_i_record4(&a,4,lf[37],lf[39],t9,t16));}}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}

/* k4634 in a4503 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in ... */
static void C_ccall f_4636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4584(t2,C_i_not(t1));}

/* k4582 in a4503 in k3575 in k3572 in k3569 in k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in ... */
static void C_fcall f_4584(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4584,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_i_negativep(((C_word*)t0)[2]))){
t2=((C_word*)t0)[3];
t3=C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4608,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4612,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:951: - */
C_minus(3,0,t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
t3=C_u_i_car(t2);
t4=C_a_i_list2(&a,2,t3,((C_word*)t0)[5]);
t5=((C_word*)t0)[4];
f_4534(t5,C_a_i_record4(&a,4,lf[37],lf[38],lf[271],t4));}}
else{
t2=((C_word*)t0)[4];
f_4534(t2,C_SCHEME_FALSE);}}

/* k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in ... */
static void C_ccall f_3442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3445,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:848: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[372],C_fix(16),C_fix(1),lf[373],C_SCHEME_FALSE,*((C_word*)lf[9]+1));}

/* k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in ... */
static void C_ccall f_3448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3451,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:850: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[368],C_fix(16),C_fix(1),lf[369],C_SCHEME_FALSE,*((C_word*)lf[9]+1));}

/* k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in ... */
static void C_ccall f_3445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3448,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:849: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[370],C_fix(16),C_fix(1),lf[371],C_SCHEME_FALSE,*((C_word*)lf[9]+1));}

/* k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in ... */
static void C_ccall f_3430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3433,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:844: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[380],C_fix(16),C_fix(2),lf[381],C_SCHEME_FALSE,*((C_word*)lf[9]+1));}

/* k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in ... */
static void C_ccall f_3439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3442,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:847: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[374],C_fix(16),C_fix(1),lf[375],C_SCHEME_FALSE,*((C_word*)lf[9]+1));}

/* k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in ... */
static void C_ccall f_3436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3436,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3439,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:846: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[376],C_fix(16),C_fix(2),lf[377],C_SCHEME_FALSE,*((C_word*)lf[9]+1));}

/* k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in ... */
static void C_ccall f_3433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3436,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:845: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[378],C_fix(16),C_fix(1),lf[379],C_SCHEME_FALSE,*((C_word*)lf[9]+1));}

/* k5596 in k5580 in a5574 in k5495 in a5492 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_5598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5598,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[37],lf[38],lf[928],t2));}

/* k4905 in k4865 in k4828 in a4813 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_4907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4870(t2,(C_truep(t1)?t1:C_i_symbolp(((C_word*)t0)[3])));}

/* k5580 in a5574 in k5495 in a5492 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_fcall f_5582(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5582,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5598,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:270: qnode */
t3=*((C_word*)lf[41]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix(1));}
else{
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[37],lf[38],lf[929],t2));}}

/* k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in ... */
static void C_ccall f_3553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3553,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3556,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:923: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[294],C_fix(17),C_fix(2),lf[295]);}

/* k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in ... */
static void C_ccall f_3559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3562,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:925: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[289],C_fix(17),C_fix(1),lf[290],lf[291]);}

/* k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in ... */
static void C_ccall f_3556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3556,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3559,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:924: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[292],C_fix(17),C_fix(2),lf[293]);}

/* k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in ... */
static void C_ccall f_3550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3553,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:922: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[296],C_fix(17),C_fix(2),lf[297],lf[298]);}

/* k3158 in k3155 in k3152 in k3149 in k3146 in k3143 in k3140 in k3137 in k3134 in k3131 in k3128 in k3125 in k3122 in k3119 in k3116 in k3113 in k3110 in k3107 in k3104 in k3101 in k3098 in k3095 in ... */
static void C_ccall f_3160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3160,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3163,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:739: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[515],C_fix(2),C_fix(1),lf[529],C_SCHEME_TRUE);}

/* k3161 in k3158 in k3155 in k3152 in k3149 in k3146 in k3143 in k3140 in k3137 in k3134 in k3131 in k3128 in k3125 in k3122 in k3119 in k3116 in k3113 in k3110 in k3107 in k3104 in k3101 in k3098 in ... */
static void C_ccall f_3163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3163,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3166,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:740: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[513],C_fix(2),C_fix(1),lf[528],C_SCHEME_TRUE);}

/* a5574 in k5495 in a5492 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_5575(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5575,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5582,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=t3;
t6=C_slot(t5,C_fix(1));
t7=C_eqp(lf[43],t6);
if(C_truep(t7)){
t8=t3;
t9=C_slot(t8,C_fix(2));
t10=C_i_car(t9);
t11=t4;
f_5582(t11,C_eqp(C_fix(2),t10));}
else{
t8=t4;
f_5582(t8,C_SCHEME_FALSE);}}

/* k5571 in k5495 in a5492 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_5573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5573,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[37],lf[39],((C_word*)t0)[4],t2));}

/* k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in ... */
static void C_ccall f_3544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3544,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3547,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4661,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:903: rewrite */
t4=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[305],C_fix(8),t3);}

/* k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in ... */
static void C_ccall f_3547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3547,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3550,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:921: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[299],C_fix(17),C_fix(2),lf[300],lf[301]);}

/* build in a4737 in k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in ... */
static C_word C_fcall f_4741(C_word *a,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_overflow_check;
t3=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t4=C_a_i_list2(&a,2,t1,t2);
t5=C_a_i_record4(&a,4,lf[37],lf[40],lf[361],t4);
t6=C_a_i_list2(&a,2,((C_word*)t0)[2],t5);
return(C_a_i_record4(&a,4,lf[37],lf[39],t3,t6));}

/* k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in ... */
static void C_ccall f_3541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3541,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3544,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:901: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[306],C_fix(16),C_fix(1),lf[307],C_SCHEME_FALSE,*((C_word*)lf[9]+1));}

/* k2759 in k2756 in k2753 in k2750 in k2747 in k2744 in k2741 in k2738 in k2735 in k2732 in k2729 in k2726 in k2723 in k2720 in k2717 in k2714 in k2711 in k2708 in k2705 in k2702 in k2699 in k2696 in ... */
static void C_ccall f_2761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2761,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2764,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:595: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[786],C_fix(2),C_fix(1),lf[787],C_SCHEME_TRUE);}

/* k2762 in k2759 in k2756 in k2753 in k2750 in k2747 in k2744 in k2741 in k2738 in k2735 in k2732 in k2729 in k2726 in k2723 in k2720 in k2717 in k2714 in k2711 in k2708 in k2705 in k2702 in k2699 in ... */
static void C_ccall f_2764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2764,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2767,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:596: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[784],C_fix(2),C_fix(1),lf[785],C_SCHEME_TRUE);}

/* k3170 in k3167 in k3164 in k3161 in k3158 in k3155 in k3152 in k3149 in k3146 in k3143 in k3140 in k3137 in k3134 in k3131 in k3128 in k3125 in k3122 in k3119 in k3116 in k3113 in k3110 in k3107 in ... */
static void C_ccall f_3172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3172,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3175,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:743: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[507],C_fix(2),C_fix(1),lf[525],C_SCHEME_TRUE);}

/* k3173 in k3170 in k3167 in k3164 in k3161 in k3158 in k3155 in k3152 in k3149 in k3146 in k3143 in k3140 in k3137 in k3134 in k3131 in k3128 in k3125 in k3122 in k3119 in k3116 in k3113 in k3110 in ... */
static void C_ccall f_3175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3175,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3178,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:744: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[505],C_fix(2),C_fix(1),lf[524],C_SCHEME_TRUE);}

/* k3164 in k3161 in k3158 in k3155 in k3152 in k3149 in k3146 in k3143 in k3140 in k3137 in k3134 in k3131 in k3128 in k3125 in k3122 in k3119 in k3116 in k3113 in k3110 in k3107 in k3104 in k3101 in ... */
static void C_ccall f_3166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3166,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3169,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:741: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[511],C_fix(2),C_fix(1),lf[527],C_SCHEME_TRUE);}

/* k2765 in k2762 in k2759 in k2756 in k2753 in k2750 in k2747 in k2744 in k2741 in k2738 in k2735 in k2732 in k2729 in k2726 in k2723 in k2720 in k2717 in k2714 in k2711 in k2708 in k2705 in k2702 in ... */
static void C_ccall f_2767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2767,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2770,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:597: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[782],C_fix(2),C_fix(1),lf[783],C_SCHEME_TRUE);}

/* k3167 in k3164 in k3161 in k3158 in k3155 in k3152 in k3149 in k3146 in k3143 in k3140 in k3137 in k3134 in k3131 in k3128 in k3125 in k3122 in k3119 in k3116 in k3113 in k3110 in k3107 in k3104 in ... */
static void C_ccall f_3169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3169,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3172,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:742: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[509],C_fix(2),C_fix(1),lf[526],C_SCHEME_TRUE);}

/* k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in k3473 in k3470 in k3467 in ... */
static void C_ccall f_3532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3532,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3535,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:898: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[312],C_fix(16),C_fix(1),lf[313],C_SCHEME_FALSE,*((C_word*)lf[9]+1));}

/* k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in k3473 in k3470 in ... */
static void C_ccall f_3535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3535,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3538,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:899: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[310],C_fix(16),C_fix(1),lf[311],C_SCHEME_FALSE,*((C_word*)lf[9]+1));}

/* k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in k3473 in ... */
static void C_ccall f_3538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3538,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3541,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:900: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[308],C_fix(16),C_fix(1),lf[309],C_SCHEME_FALSE,*((C_word*)lf[9]+1));}

/* k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in ... */
static void C_ccall f_3673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3673,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3676,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:993: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[201],C_fix(2),C_fix(2),lf[202],C_SCHEME_FALSE);}

/* k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in ... */
static void C_ccall f_3676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3676,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3679,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:994: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[199],C_fix(2),C_fix(2),lf[200],C_SCHEME_FALSE);}

/* k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in ... */
static void C_ccall f_3670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3670,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3673,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:991: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[203],C_fix(2),C_fix(1),lf[204],C_SCHEME_FALSE);}

/* k2753 in k2750 in k2747 in k2744 in k2741 in k2738 in k2735 in k2732 in k2729 in k2726 in k2723 in k2720 in k2717 in k2714 in k2711 in k2708 in k2705 in k2702 in k2699 in k2696 in k2693 in k2690 in ... */
static void C_ccall f_2755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2755,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2758,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:593: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[790],C_fix(2),C_fix(1),lf[791],C_SCHEME_TRUE);}

/* k2750 in k2747 in k2744 in k2741 in k2738 in k2735 in k2732 in k2729 in k2726 in k2723 in k2720 in k2717 in k2714 in k2711 in k2708 in k2705 in k2702 in k2699 in k2696 in k2693 in k2690 in k2687 in ... */
static void C_ccall f_2752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2752,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2755,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:592: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[792],C_fix(2),C_fix(1),lf[793],C_SCHEME_TRUE);}

/* k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in ... */
static void C_ccall f_3679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3679,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3682,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:995: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[197],C_fix(2),C_fix(2),lf[198],C_SCHEME_FALSE);}

/* k2909 in k2906 in k2903 in k2900 in k2897 in k2894 in k2891 in k2888 in k2885 in k2882 in k2879 in k2876 in k2873 in k2870 in k2867 in k2864 in k2861 in k2858 in k2855 in k2852 in k2849 in k2846 in ... */
static void C_ccall f_2911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2911,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2914,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:645: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[693],C_fix(2),C_fix(2),lf[694],C_SCHEME_TRUE);}

/* k2912 in k2909 in k2906 in k2903 in k2900 in k2897 in k2894 in k2891 in k2888 in k2885 in k2882 in k2879 in k2876 in k2873 in k2870 in k2867 in k2864 in k2861 in k2858 in k2855 in k2852 in k2849 in ... */
static void C_ccall f_2914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2914,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2917,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:646: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[691],C_fix(2),C_fix(2),lf[692],C_SCHEME_TRUE);}

/* k2915 in k2912 in k2909 in k2906 in k2903 in k2900 in k2897 in k2894 in k2891 in k2888 in k2885 in k2882 in k2879 in k2876 in k2873 in k2870 in k2867 in k2864 in k2861 in k2858 in k2855 in k2852 in ... */
static void C_ccall f_2917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2917,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2920,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:647: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[689],C_fix(2),C_fix(2),lf[690],C_SCHEME_TRUE);}

/* k2756 in k2753 in k2750 in k2747 in k2744 in k2741 in k2738 in k2735 in k2732 in k2729 in k2726 in k2723 in k2720 in k2717 in k2714 in k2711 in k2708 in k2705 in k2702 in k2699 in k2696 in k2693 in ... */
static void C_ccall f_2758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2758,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2761,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:594: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[788],C_fix(2),C_fix(1),lf[789],C_SCHEME_TRUE);}

/* k3683 in k3680 in k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in ... */
static void C_ccall f_3685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3685,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3688,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:998: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[193],C_fix(16),C_fix(2),lf[194],C_SCHEME_FALSE,*((C_word*)lf[9]+1));}

/* k3149 in k3146 in k3143 in k3140 in k3137 in k3134 in k3131 in k3128 in k3125 in k3122 in k3119 in k3116 in k3113 in k3110 in k3107 in k3104 in k3101 in k3098 in k3095 in k3092 in k3089 in k3086 in ... */
static void C_ccall f_3151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3151,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3154,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:735: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[533],C_fix(2),C_fix(1),lf[534],C_SCHEME_TRUE);}

/* k3680 in k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in ... */
static void C_ccall f_3682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3682,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3685,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:996: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[195],C_fix(2),C_fix(2),lf[196],C_SCHEME_FALSE);}

/* k2738 in k2735 in k2732 in k2729 in k2726 in k2723 in k2720 in k2717 in k2714 in k2711 in k2708 in k2705 in k2702 in k2699 in k2696 in k2693 in k2690 in k2687 in k2684 in k2681 in k2678 in k2675 in ... */
static void C_ccall f_2740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2740,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2743,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:587: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[799],C_fix(1),C_fix(2),lf[800]);}

/* k2741 in k2738 in k2735 in k2732 in k2729 in k2726 in k2723 in k2720 in k2717 in k2714 in k2711 in k2708 in k2705 in k2702 in k2699 in k2696 in k2693 in k2690 in k2687 in k2684 in k2681 in k2678 in ... */
static void C_ccall f_2743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2743,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2746,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:588: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[797],C_fix(1),C_fix(2),lf[798]);}

/* k3686 in k3683 in k3680 in k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in ... */
static void C_ccall f_3688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3688,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3691,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:999: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[191],C_fix(16),C_fix(2),lf[192],C_SCHEME_FALSE,*((C_word*)lf[9]+1));}

/* k3155 in k3152 in k3149 in k3146 in k3143 in k3140 in k3137 in k3134 in k3131 in k3128 in k3125 in k3122 in k3119 in k3116 in k3113 in k3110 in k3107 in k3104 in k3101 in k3098 in k3095 in k3092 in ... */
static void C_ccall f_3157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3157,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3160,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:738: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[517],C_fix(2),C_fix(1),lf[530],C_SCHEME_TRUE);}

/* k2900 in k2897 in k2894 in k2891 in k2888 in k2885 in k2882 in k2879 in k2876 in k2873 in k2870 in k2867 in k2864 in k2861 in k2858 in k2855 in k2852 in k2849 in k2846 in k2843 in k2840 in k2837 in ... */
static void C_ccall f_2902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2902,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2905,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:642: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[699],C_fix(2),C_fix(1),lf[700],C_SCHEME_TRUE);}

/* k3038 in k3035 in k3032 in k3029 in k3026 in k3023 in k3020 in k3017 in k3014 in k3011 in k3008 in k3005 in k3002 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in ... */
static void C_ccall f_3040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3040,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3043,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:692: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc9)(void*)(*((C_word*)t3+1)))(9,t3,t2,lf[605],C_fix(21),C_fix(0),lf[606],lf[607],lf[608],*((C_word*)lf[9]+1));}

/* k3152 in k3149 in k3146 in k3143 in k3140 in k3137 in k3134 in k3131 in k3128 in k3125 in k3122 in k3119 in k3116 in k3113 in k3110 in k3107 in k3104 in k3101 in k3098 in k3095 in k3092 in k3089 in ... */
static void C_ccall f_3154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3154,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3157,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:736: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[531],C_fix(2),C_fix(1),lf[532],C_SCHEME_TRUE);}

/* k2903 in k2900 in k2897 in k2894 in k2891 in k2888 in k2885 in k2882 in k2879 in k2876 in k2873 in k2870 in k2867 in k2864 in k2861 in k2858 in k2855 in k2852 in k2849 in k2846 in k2843 in k2840 in ... */
static void C_ccall f_2905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2905,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2908,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:643: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[697],C_fix(2),C_fix(2),lf[698],C_SCHEME_TRUE);}

/* k3041 in k3038 in k3035 in k3032 in k3029 in k3026 in k3023 in k3020 in k3017 in k3014 in k3011 in k3008 in k3005 in k3002 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in ... */
static void C_ccall f_3043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3043,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3046,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:693: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc9)(void*)(*((C_word*)t3+1)))(9,t3,t2,lf[601],C_fix(21),C_fix(-1),lf[602],lf[603],lf[604],*((C_word*)lf[9]+1));}

/* k2906 in k2903 in k2900 in k2897 in k2894 in k2891 in k2888 in k2885 in k2882 in k2879 in k2876 in k2873 in k2870 in k2867 in k2864 in k2861 in k2858 in k2855 in k2852 in k2849 in k2846 in k2843 in ... */
static void C_ccall f_2908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2908,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2911,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:644: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[695],C_fix(2),C_fix(2),lf[696],C_SCHEME_TRUE);}

/* k3044 in k3041 in k3038 in k3035 in k3032 in k3029 in k3026 in k3023 in k3020 in k3017 in k3014 in k3011 in k3008 in k3005 in k3002 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in ... */
static void C_ccall f_3046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3046,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3049,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:694: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc9)(void*)(*((C_word*)t3+1)))(9,t3,t2,lf[597],C_fix(21),C_fix(0),lf[598],lf[599],lf[600],*((C_word*)lf[9]+1));}

/* k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in k3029 in k3026 in k3023 in k3020 in k3017 in k3014 in k3011 in k3008 in k3005 in k3002 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in ... */
static void C_ccall f_3049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3052,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:696: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc9)(void*)(*((C_word*)t3+1)))(9,t3,t2,lf[594],C_fix(22),C_fix(1),lf[595],C_SCHEME_TRUE,*((C_word*)lf[9]+1),lf[596]);}

/* k2744 in k2741 in k2738 in k2735 in k2732 in k2729 in k2726 in k2723 in k2720 in k2717 in k2714 in k2711 in k2708 in k2705 in k2702 in k2699 in k2696 in k2693 in k2690 in k2687 in k2684 in k2681 in ... */
static void C_ccall f_2746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2746,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2749,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:590: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[794],C_fix(2),C_fix(2),lf[796],C_SCHEME_FALSE);}

/* k2747 in k2744 in k2741 in k2738 in k2735 in k2732 in k2729 in k2726 in k2723 in k2720 in k2717 in k2714 in k2711 in k2708 in k2705 in k2702 in k2699 in k2696 in k2693 in k2690 in k2687 in k2684 in ... */
static void C_ccall f_2749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2749,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2752,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:591: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[794],C_fix(2),C_fix(2),lf[795],C_SCHEME_TRUE);}

/* k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in k3473 in k3470 in k3467 in k3464 in k3461 in k3458 in k3455 in k3452 in ... */
static void C_ccall f_3517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3517,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3520,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:892: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[322],C_fix(2),C_fix(2),lf[323],C_SCHEME_FALSE);}

/* k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in k3473 in k3470 in k3467 in k3464 in k3461 in k3458 in k3455 in k3452 in k3449 in ... */
static void C_ccall f_3514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3514,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3517,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:891: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[324],C_fix(2),C_fix(2),lf[325],C_SCHEME_FALSE);}

/* k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in k3473 in k3470 in k3467 in k3464 in k3461 in k3458 in k3455 in k3452 in k3449 in k3446 in ... */
static void C_ccall f_3511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3514,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:890: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[326],C_fix(2),C_fix(2),lf[327],C_SCHEME_FALSE);}

/* k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in ... */
static void C_ccall f_3694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3694,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3697,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1002: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc9)(void*)(*((C_word*)t3+1)))(9,t3,t2,lf[185],C_fix(22),C_fix(2),lf[186],C_SCHEME_FALSE,*((C_word*)lf[9]+1),lf[187]);}

/* k3689 in k3686 in k3683 in k3680 in k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in ... */
static void C_ccall f_3691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3691,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3694,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1001: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc9)(void*)(*((C_word*)t3+1)))(9,t3,t2,lf[188],C_fix(22),C_fix(2),lf[189],C_SCHEME_FALSE,*((C_word*)lf[9]+1),lf[190]);}

/* k3140 in k3137 in k3134 in k3131 in k3128 in k3125 in k3122 in k3119 in k3116 in k3113 in k3110 in k3107 in k3104 in k3101 in k3098 in k3095 in k3092 in k3089 in k3086 in k3083 in k3080 in k3077 in ... */
static void C_ccall f_3142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3142,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3145,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:731: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[539],C_fix(6),lf[540],lf[541],C_SCHEME_TRUE);}

/* k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in k3359 in k3356 in k3353 in k3350 in k3347 in ... */
static void C_ccall f_3412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3412,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3415,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:838: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[392],C_fix(16),C_fix(1),lf[393],C_SCHEME_FALSE,*((C_word*)lf[9]+1));}

/* k2729 in k2726 in k2723 in k2720 in k2717 in k2714 in k2711 in k2708 in k2705 in k2702 in k2699 in k2696 in k2693 in k2690 in k2687 in k2684 in k2681 in k2678 in k2675 in k2672 in k2669 in k2666 in ... */
static void C_ccall f_2731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2731,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2734,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:583: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[805],C_fix(2),C_fix(1),lf[806],C_SCHEME_TRUE);}

/* k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in k3359 in k3356 in k3353 in k3350 in ... */
static void C_ccall f_3415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3415,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3418,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:839: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[390],C_fix(16),C_fix(1),lf[391],C_SCHEME_FALSE,*((C_word*)lf[9]+1));}

/* k2732 in k2729 in k2726 in k2723 in k2720 in k2717 in k2714 in k2711 in k2708 in k2705 in k2702 in k2699 in k2696 in k2693 in k2690 in k2687 in k2684 in k2681 in k2678 in k2675 in k2672 in k2669 in ... */
static void C_ccall f_2734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2734,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2737,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:585: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[803],C_fix(1),C_fix(2),lf[804]);}

/* k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in k3395 in k3392 in k3389 in k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in k3368 in k3365 in k3362 in k3359 in k3356 in k3353 in ... */
static void C_ccall f_3418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3421,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:840: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[388],C_fix(16),C_fix(1),lf[389],C_SCHEME_FALSE,*((C_word*)lf[9]+1));}

/* k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in ... */
static void C_ccall f_3697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3697,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3700,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1004: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[183],C_fix(2),C_fix(3),lf[184],C_SCHEME_FALSE);}

/* k3146 in k3143 in k3140 in k3137 in k3134 in k3131 in k3128 in k3125 in k3122 in k3119 in k3116 in k3113 in k3110 in k3107 in k3104 in k3101 in k3098 in k3095 in k3092 in k3089 in k3086 in k3083 in ... */
static void C_ccall f_3148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3148,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3151,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:734: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[535],C_fix(2),C_fix(1),lf[536],C_SCHEME_TRUE);}

/* k3143 in k3140 in k3137 in k3134 in k3131 in k3128 in k3125 in k3122 in k3119 in k3116 in k3113 in k3110 in k3107 in k3104 in k3101 in k3098 in k3095 in k3092 in k3089 in k3086 in k3083 in k3080 in ... */
static void C_ccall f_3145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3145,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3148,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:733: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[537],C_fix(2),C_fix(1),lf[538],C_SCHEME_TRUE);}

/* k3029 in k3026 in k3023 in k3020 in k3017 in k3014 in k3011 in k3008 in k3005 in k3002 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in ... */
static void C_ccall f_3031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3034,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:687: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[613],C_fix(17),C_fix(2),lf[614],lf[615]);}

/* k3032 in k3029 in k3026 in k3023 in k3020 in k3017 in k3014 in k3011 in k3008 in k3005 in k3002 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in ... */
static void C_ccall f_3034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3037,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:689: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[609],C_fix(14),lf[34],C_fix(1),lf[611],lf[612]);}

/* k3035 in k3032 in k3029 in k3026 in k3023 in k3020 in k3017 in k3014 in k3011 in k3008 in k3005 in k3002 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in ... */
static void C_ccall f_3037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3037,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3040,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:690: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[609],C_fix(16),C_fix(1),lf[610],C_SCHEME_TRUE,*((C_word*)lf[9]+1));}

/* k2735 in k2732 in k2729 in k2726 in k2723 in k2720 in k2717 in k2714 in k2711 in k2708 in k2705 in k2702 in k2699 in k2696 in k2693 in k2690 in k2687 in k2684 in k2681 in k2678 in k2675 in k2672 in ... */
static void C_ccall f_2737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2737,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2740,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:586: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[801],C_fix(1),C_fix(2),lf[802]);}

/* k3943 in rewrite-call/cc in k3922 in k3919 in k3916 in k3913 in k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in k3755 in k3752 in k3749 in k3746 in k3743 in k3740 in k3737 in k3734 in k3731 in ... */
static void C_ccall f_3945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3945,2,t0,t1);}
if(C_truep(t1)){
t2=C_slot(t1,C_fix(1));
t3=C_eqp(lf[64],t2);
if(C_truep(t3)){
t4=C_slot(t1,C_fix(2));
t5=C_i_caddr(t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3962,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-platform.scm:1076: decompose-lambda-list */
t8=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[5],t6,t7);}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in k3473 in k3470 in k3467 in k3464 in k3461 in k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in ... */
static void C_ccall f_3505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3508,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:888: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[330],C_fix(2),C_fix(1),lf[331],C_SCHEME_FALSE);}

/* k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in k3473 in k3470 in k3467 in k3464 in k3461 in k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in ... */
static void C_ccall f_3508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3511,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:889: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[328],C_fix(2),C_fix(2),lf[329],C_SCHEME_FALSE);}

/* k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in k3473 in k3470 in k3467 in k3464 in k3461 in k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in ... */
static void C_ccall f_3502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3502,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3505,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:887: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[332],C_fix(2),C_fix(1),lf[333],C_SCHEME_FALSE);}

/* k4701 in a4660 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in ... */
static void C_ccall f_4703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4703,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_a_i_record4(&a,4,lf[37],lf[38],lf[302],t2);
t4=C_a_i_list2(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[4];
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_record4(&a,4,lf[37],lf[39],((C_word*)t0)[5],t4));}
else{
t2=((C_word*)t0)[2];
t3=C_a_i_record4(&a,4,lf[37],lf[38],lf[303],t2);
t4=C_a_i_list2(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[4];
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_record4(&a,4,lf[37],lf[39],((C_word*)t0)[5],t4));}}

/* k3128 in k3125 in k3122 in k3119 in k3116 in k3113 in k3110 in k3107 in k3104 in k3101 in k3098 in k3095 in k3092 in k3089 in k3086 in k3083 in k3080 in k3077 in k3074 in k3071 in k3068 in k3065 in ... */
static void C_ccall f_3130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3130,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3133,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:726: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[549],C_fix(2),C_fix(1),lf[550],C_SCHEME_FALSE);}

/* a5049 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_5050(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5050,6,t0,t1,t2,t3,t4,t5);}
t6=C_i_length(t5);
t7=C_eqp(t6,C_fix(2));
if(C_truep(t7)){
t8=C_eqp(lf[34],*((C_word*)lf[35]+1));
if(C_truep(t8)){
t9=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t10=t9;
t11=C_i_cadr(t5);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5089,a[2]=t5,a[3]=t4,a[4]=t1,a[5]=t10,tmp=(C_word)a,a+=6,tmp);
t13=C_slot(t11,C_fix(1));
t14=C_eqp(lf[43],t13);
if(C_truep(t14)){
t15=C_slot(t11,C_fix(2));
t16=C_i_car(t15);
t17=t12;
f_5089(t17,C_eqp(C_fix(2),t16));}
else{
t15=t12;
f_5089(t15,C_SCHEME_FALSE);}}
else{
t9=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t10=t9;
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5159,a[2]=t1,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
t12=C_a_i_record4(&a,4,lf[37],lf[49],lf[918],C_SCHEME_END_OF_LIST);
/* c-platform.scm:360: cons* */
t13=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t13+1)))(5,t13,t11,t12,t4,t5);}}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}

/* k3137 in k3134 in k3131 in k3128 in k3125 in k3122 in k3119 in k3116 in k3113 in k3110 in k3107 in k3104 in k3101 in k3098 in k3095 in k3092 in k3089 in k3086 in k3083 in k3080 in k3077 in k3074 in ... */
static void C_ccall f_3139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3139,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3142,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:730: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[542],C_fix(6),lf[543],lf[544],C_SCHEME_TRUE);}

/* k3131 in k3128 in k3125 in k3122 in k3119 in k3116 in k3113 in k3110 in k3107 in k3104 in k3101 in k3098 in k3095 in k3092 in k3089 in k3086 in k3083 in k3080 in k3077 in k3074 in k3071 in k3068 in ... */
static void C_ccall f_3133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3133,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3136,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:728: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[537],C_fix(6),lf[547],lf[548],C_SCHEME_FALSE);}

/* k3134 in k3131 in k3128 in k3125 in k3122 in k3119 in k3116 in k3113 in k3110 in k3107 in k3104 in k3101 in k3098 in k3095 in k3092 in k3089 in k3086 in k3083 in k3080 in k3077 in k3074 in k3071 in ... */
static void C_ccall f_3136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3136,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3139,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:729: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[533],C_fix(6),lf[545],lf[546],C_SCHEME_FALSE);}

/* k1997 in k1968 in rewrite-apply in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_1999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-platform.scm:442: cons* */
t2=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k1991 in k1968 in rewrite-apply in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_1993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1993,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record4(&a,4,lf[37],lf[39],((C_word*)t0)[3],t1));}

/* k5087 in a5049 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_fcall f_5089(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5089,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5107,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-platform.scm:356: qnode */
t5=*((C_word*)lf[41]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,C_fix(1));}
else{
t2=((C_word*)t0)[2];
t3=C_a_i_record4(&a,4,lf[37],lf[38],lf[917],t2);
t4=C_a_i_list2(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[4];
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_record4(&a,4,lf[37],lf[39],((C_word*)t0)[5],t4));}}

/* k3119 in k3116 in k3113 in k3110 in k3107 in k3104 in k3101 in k3098 in k3095 in k3092 in k3089 in k3086 in k3083 in k3080 in k3077 in k3074 in k3071 in k3068 in k3065 in k3062 in k3059 in k3056 in ... */
static void C_ccall f_3121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3121,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3124,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:723: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[549],C_fix(5),lf[553],C_fix(0),lf[34]);}

/* k3125 in k3122 in k3119 in k3116 in k3113 in k3110 in k3107 in k3104 in k3101 in k3098 in k3095 in k3092 in k3089 in k3086 in k3083 in k3080 in k3077 in k3074 in k3071 in k3068 in k3065 in k3062 in ... */
static void C_ccall f_3127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3127,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3130,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:725: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[549],C_fix(2),C_fix(1),lf[551],C_SCHEME_TRUE);}

/* k3122 in k3119 in k3116 in k3113 in k3110 in k3107 in k3104 in k3101 in k3098 in k3095 in k3092 in k3089 in k3086 in k3083 in k3080 in k3077 in k3074 in k3071 in k3068 in k3065 in k3062 in k3059 in ... */
static void C_ccall f_3124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3124,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3127,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:724: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[549],C_fix(5),lf[552],C_fix(0),lf[395]);}

/* k3922 in k3919 in k3916 in k3913 in k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in k3755 in k3752 in k3749 in k3746 in k3743 in k3740 in k3737 in k3734 in k3731 in k3728 in k3725 in ... */
static void C_ccall f_3924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3926,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4073,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:1087: rewrite */
t4=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[62],C_fix(8),t2);}

/* rewrite-call/cc in k3922 in k3919 in k3916 in k3913 in k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in k3755 in k3752 in k3749 in k3746 in k3743 in k3740 in k3737 in k3734 in k3731 in k3728 in ... */
static void C_ccall f_3926(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3926,6,t0,t1,t2,t3,t4,t5);}
t6=C_i_length(t5);
t7=C_eqp(C_fix(1),t6);
if(C_truep(t7)){
t8=C_i_car(t5);
t9=t8;
t10=C_slot(t9,C_fix(1));
t11=C_eqp(lf[44],t10);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3945,a[2]=t9,a[3]=t4,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t13=C_slot(t9,C_fix(2));
t14=C_i_car(t13);
/* c-platform.scm:1073: get */
t15=*((C_word*)lf[60]+1);
((C_proc5)(void*)(*((C_word*)t15+1)))(5,t15,t12,t2,t14,lf[73]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}

/* k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in ... */
static void C_ccall f_3565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3568,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:927: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[283],C_fix(17),C_fix(2),lf[284],lf[285]);}

/* k3919 in k3916 in k3913 in k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in k3755 in k3752 in k3749 in k3746 in k3743 in k3740 in k3737 in k3734 in k3731 in k3728 in k3725 in k3722 in ... */
static void C_ccall f_3921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3921,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3924,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1065: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[124],C_fix(20),C_fix(2),lf[125],C_fix(10),C_SCHEME_FALSE);}

/* k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in ... */
static void C_ccall f_3562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3562,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3565,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:926: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[286],C_fix(17),C_fix(2),lf[287],lf[288]);}

/* k3566 in k3563 in k3560 in k3557 in k3554 in k3551 in k3548 in k3545 in k3542 in k3539 in k3536 in k3533 in k3530 in k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in ... */
static void C_ccall f_3568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3571,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:928: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[280],C_fix(17),C_fix(2),lf[281],lf[282]);}

/* a5337 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_5338(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5338,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(C_i_nullp(t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=C_i_cdr(t5);
t7=C_i_nullp(t6);
t8=(C_truep(t7)?C_eqp(*((C_word*)lf[35]+1),lf[34]):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=C_a_i_list1(&a,1,C_SCHEME_TRUE);
if(C_truep(*((C_word*)lf[36]+1))){
t10=t5;
t11=C_a_i_record4(&a,4,lf[37],lf[38],lf[924],t10);
t12=C_a_i_list2(&a,2,t4,t11);
t13=t1;
t14=t13;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_a_i_record4(&a,4,lf[37],lf[39],t9,t12));}
else{
t10=t5;
t11=C_a_i_record4(&a,4,lf[37],lf[38],lf[925],t10);
t12=C_a_i_list2(&a,2,t4,t11);
t13=t1;
t14=t13;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_a_i_record4(&a,4,lf[37],lf[39],t9,t12));}}
else{
t9=t5;
t10=C_u_i_car(t9);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5445,a[2]=t10,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5447,tmp=(C_word)a,a+=2,tmp);
t13=t5;
t14=C_u_i_cdr(t13);
/* c-platform.scm:295: remove */
t15=*((C_word*)lf[923]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t11,t12,t14);}}}

/* k3110 in k3107 in k3104 in k3101 in k3098 in k3095 in k3092 in k3089 in k3086 in k3083 in k3080 in k3077 in k3074 in k3071 in k3068 in k3065 in k3062 in k3059 in k3056 in k3053 in k3050 in k3047 in ... */
static void C_ccall f_3112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3112,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3115,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:720: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[554],C_fix(5),lf[557],C_fix(0),lf[395]);}

/* k3113 in k3110 in k3107 in k3104 in k3101 in k3098 in k3095 in k3092 in k3089 in k3086 in k3083 in k3080 in k3077 in k3074 in k3071 in k3068 in k3065 in k3062 in k3059 in k3056 in k3053 in k3050 in ... */
static void C_ccall f_3115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3115,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3118,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:721: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[554],C_fix(2),C_fix(1),lf[556],C_SCHEME_TRUE);}

/* k3116 in k3113 in k3110 in k3107 in k3104 in k3101 in k3098 in k3095 in k3092 in k3089 in k3086 in k3083 in k3080 in k3077 in k3074 in k3071 in k3068 in k3065 in k3062 in k3059 in k3056 in k3053 in ... */
static void C_ccall f_3118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3118,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3121,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:722: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[554],C_fix(2),C_fix(1),lf[555],C_SCHEME_FALSE);}

/* k2298 in a2206 in a2194 in rewrite-c..r in k2185 in k2182 in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_2300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2234(t2,C_eqp(lf[59],t1));}

/* k4111 in k4108 in k4105 in k4102 in k4099 in k4096 in k4093 in k4090 in k4087 in k4084 in k4081 in k4078 in k4074 in k4071 in k3922 in k3919 in k3916 in k3913 in k3776 in k3773 in k3770 in k3767 in ... */
static void C_ccall f_4113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4113,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4116,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1168: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc9)(void*)(*((C_word*)t3+1)))(9,t3,t2,lf[96],C_fix(23),C_fix(2),lf[97],C_fix(0),C_fix(0),C_SCHEME_FALSE);}

/* k4108 in k4105 in k4102 in k4099 in k4096 in k4093 in k4090 in k4087 in k4084 in k4081 in k4078 in k4074 in k4071 in k3922 in k3919 in k3916 in k3913 in k3776 in k3773 in k3770 in k3767 in k3764 in ... */
static void C_ccall f_4110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4110,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4113,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1167: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[98],C_fix(23),C_fix(1),lf[99],lf[100]);}

/* k4114 in k4111 in k4108 in k4105 in k4102 in k4099 in k4096 in k4093 in k4090 in k4087 in k4084 in k4081 in k4078 in k4074 in k4071 in k3922 in k3919 in k3916 in k3913 in k3776 in k3773 in k3770 in ... */
static void C_ccall f_4116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4116,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4119,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1169: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc9)(void*)(*((C_word*)t3+1)))(9,t3,t2,lf[94],C_fix(23),C_fix(2),lf[95],C_fix(0),C_fix(0),C_SCHEME_FALSE);}

/* k3913 in k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in k3755 in k3752 in k3749 in k3746 in k3743 in k3740 in k3737 in k3734 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in ... */
static void C_ccall f_3915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3918,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1062: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[128],C_fix(8),((C_word*)t0)[3]);}

/* k4117 in k4114 in k4111 in k4108 in k4105 in k4102 in k4099 in k4096 in k4093 in k4090 in k4087 in k4084 in k4081 in k4078 in k4074 in k4071 in k3922 in k3919 in k3916 in k3913 in k3776 in k3773 in ... */
static void C_ccall f_4119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4119,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4122,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1170: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[92],C_fix(23),C_fix(2),lf[93],C_fix(0));}

/* k3916 in k3913 in k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in k3755 in k3752 in k3749 in k3746 in k3743 in k3740 in k3737 in k3734 in k3731 in k3728 in k3725 in k3722 in k3719 in ... */
static void C_ccall f_3918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3918,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3921,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1064: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[126],C_fix(7),C_fix(1),lf[127],C_fix(10),C_SCHEME_FALSE);}

/* a4737 in k3458 in k3455 in k3452 in k3449 in k3446 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 in k3425 in k3422 in k3419 in k3416 in k3413 in k3410 in k3407 in k3404 in k3401 in k3398 in ... */
static void C_ccall f_4738(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4738,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4741,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=C_i_length(t5);
switch(t7){
case C_fix(1):
t8=C_i_car(t5);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4791,a[2]=t1,a[3]=t6,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* c-platform.scm:869: qnode */
t11=*((C_word*)lf[41]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,C_fix(10));
case C_fix(2):
t8=C_i_car(t5);
t9=C_i_cadr(t5);
/* c-platform.scm:870: build */
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,f_4741(C_a_i(&a,25),t6,t8,t9));
default:
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}

/* k3101 in k3098 in k3095 in k3092 in k3089 in k3086 in k3083 in k3080 in k3077 in k3074 in k3071 in k3068 in k3065 in k3062 in k3059 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in ... */
static void C_ccall f_3103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3103,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3106,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:717: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[559],C_fix(2),C_fix(1),lf[561],C_SCHEME_TRUE);}

/* k3098 in k3095 in k3092 in k3089 in k3086 in k3083 in k3080 in k3077 in k3074 in k3071 in k3068 in k3065 in k3062 in k3059 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in ... */
static void C_ccall f_3100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3100,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3103,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:716: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[559],C_fix(5),lf[562],C_fix(0),lf[34]);}

/* k3104 in k3101 in k3098 in k3095 in k3092 in k3089 in k3086 in k3083 in k3080 in k3077 in k3074 in k3071 in k3068 in k3065 in k3062 in k3059 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in ... */
static void C_ccall f_3106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3106,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3109,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:718: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[559],C_fix(2),C_fix(1),lf[560],C_SCHEME_FALSE);}

/* k3107 in k3104 in k3101 in k3098 in k3095 in k3092 in k3089 in k3086 in k3083 in k3080 in k3077 in k3074 in k3071 in k3068 in k3065 in k3062 in k3059 in k3056 in k3053 in k3050 in k3047 in k3044 in ... */
static void C_ccall f_3109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3109,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3112,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:719: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[554],C_fix(5),lf[558],C_fix(0),lf[34]);}

/* k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in ... */
static void C_ccall f_3727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3730,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1015: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[163],C_fix(2),C_fix(1),lf[164],C_SCHEME_FALSE);}

/* k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in ... */
static void C_ccall f_3721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3721,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3724,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1013: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[167],C_fix(2),C_fix(1),lf[168],C_SCHEME_FALSE);}

/* k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in ... */
static void C_ccall f_3724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3727,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1014: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[165],C_fix(2),C_fix(1),lf[166],C_SCHEME_FALSE);}

/* map-loop435 in k2059 in k1968 in rewrite-apply in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_fcall f_2015(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2015,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2044,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* c-platform.scm:444: g441 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2011 in k2059 in k1968 in rewrite-apply in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_2013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-platform.scm:444: append */
t2=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k2349 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2328 in k2185 in k2182 in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in ... */
static void C_ccall f_2351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2354,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:498: rewrite-c..r */
f_2189(t2,lf[878],lf[879],lf[880],C_fix(2));}

/* k2352 in k2349 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2328 in k2185 in k2182 in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in ... */
static void C_ccall f_2354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2357,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:499: rewrite-c..r */
f_2189(t2,lf[875],lf[876],lf[877],C_fix(3));}

/* k5686 in for-each-loop44 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_5688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5678(t3,((C_word*)t0)[4],t2);}

/* k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in ... */
static void C_ccall f_3715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3718,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1010: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[171],C_fix(2),C_fix(3),lf[172],C_SCHEME_FALSE);}

/* k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in ... */
static void C_ccall f_3718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3718,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3721,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1011: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[169],C_fix(2),C_fix(3),lf[170],C_SCHEME_FALSE);}

/* k3527 in k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in k3473 in k3470 in k3467 in k3464 in ... */
static void C_ccall f_3529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3529,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3532,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:896: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[314],C_fix(2),C_fix(2),lf[315],C_SCHEME_FALSE);}

/* k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in ... */
static void C_ccall f_3712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3712,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3715,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1009: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[173],C_fix(2),C_fix(3),lf[174],C_SCHEME_FALSE);}

/* k3524 in k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in k3473 in k3470 in k3467 in k3464 in k3461 in ... */
static void C_ccall f_3526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3526,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3529,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:895: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[316],C_fix(2),C_fix(2),lf[317],C_SCHEME_FALSE);}

/* k3521 in k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in k3473 in k3470 in k3467 in k3464 in k3461 in k3458 in ... */
static void C_ccall f_3523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3523,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3526,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:894: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[318],C_fix(2),C_fix(2),lf[319],C_SCHEME_FALSE);}

/* rvalues in k2355 in k2352 in k2349 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2328 in k2185 in k2182 in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in ... */
static void C_ccall f_2358(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2358,6,t0,t1,t2,t3,t4,t5);}
t6=C_i_length(t5);
t7=C_eqp(t6,C_fix(1));
if(C_truep(t7)){
t8=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t9=C_a_i_cons(&a,2,t4,t5);
t10=t1;
t11=t10;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_a_i_record4(&a,4,lf[37],lf[39],t8,t9));}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}

/* k2355 in k2352 in k2349 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2328 in k2185 in k2182 in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in ... */
static void C_ccall f_2357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2357,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2358,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2389,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:506: rewrite */
t4=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[51],C_fix(8),t2);}

/* k3518 in k3515 in k3512 in k3509 in k3506 in k3503 in k3500 in k3497 in k3494 in k3491 in k3488 in k3485 in k3482 in k3479 in k3476 in k3473 in k3470 in k3467 in k3464 in k3461 in k3458 in k3455 in ... */
static void C_ccall f_3520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3520,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3523,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:893: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[320],C_fix(2),C_fix(2),lf[321],C_SCHEME_FALSE);}

/* k2696 in k2693 in k2690 in k2687 in k2684 in k2681 in k2678 in k2675 in k2672 in k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 in ... */
static void C_ccall f_2698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2698,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2701,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:570: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[825],C_fix(2),C_fix(1),lf[826],C_SCHEME_FALSE);}

/* k2693 in k2690 in k2687 in k2684 in k2681 in k2678 in k2675 in k2672 in k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 in k2630 in ... */
static void C_ccall f_2695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2695,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2698,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:569: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[827],C_fix(2),C_fix(1),lf[828],C_SCHEME_FALSE);}

/* k2340 in k2337 in k2334 in k2331 in k2328 in k2185 in k2182 in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 in ... */
static void C_ccall f_2342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2345,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:495: rewrite-c..r */
f_2189(t2,lf[833],lf[887],lf[888],C_fix(3));}

/* k2690 in k2687 in k2684 in k2681 in k2678 in k2675 in k2672 in k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 in k2630 in k2627 in ... */
static void C_ccall f_2692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2692,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2695,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:568: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[829],C_fix(2),C_fix(1),lf[830],C_SCHEME_FALSE);}

/* a5416 in k5443 in a5337 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_5417(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5417,4,t0,t1,t2,t3);}
t4=(C_truep(*((C_word*)lf[36]+1))?lf[926]:lf[927]);
t5=C_a_i_list2(&a,2,t2,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_record4(&a,4,lf[37],lf[38],t4,t5));}

/* k5413 in k5443 in a5337 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_5415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5415,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[37],lf[39],((C_word*)t0)[4],t2));}

/* k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in ... */
static void C_ccall f_3709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3709,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3712,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1008: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[175],C_fix(2),C_fix(3),lf[176],C_SCHEME_FALSE);}

/* k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in ... */
static void C_ccall f_3706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3706,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3709,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1007: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[177],C_fix(2),C_fix(3),lf[178],C_SCHEME_FALSE);}

/* k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in ... */
static void C_ccall f_3703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3703,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3706,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1006: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[179],C_fix(2),C_fix(3),lf[180],C_SCHEME_FALSE);}

/* k2343 in k2340 in k2337 in k2334 in k2331 in k2328 in k2185 in k2182 in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in ... */
static void C_ccall f_2345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2345,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2348,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:496: rewrite-c..r */
f_2189(t2,lf[884],lf[885],lf[886],C_fix(0));}

/* k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in ... */
static void C_ccall f_3700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3700,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3703,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1005: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[181],C_fix(2),C_fix(3),lf[182],C_SCHEME_FALSE);}

/* k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2328 in k2185 in k2182 in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in ... */
static void C_ccall f_2348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2351,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:497: rewrite-c..r */
f_2189(t2,lf[881],lf[882],lf[883],C_fix(1));}

/* k2687 in k2684 in k2681 in k2678 in k2675 in k2672 in k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 in k2630 in k2627 in k2624 in ... */
static void C_ccall f_2689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2689,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2692,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:567: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[831],C_fix(2),C_fix(1),lf[832],C_SCHEME_FALSE);}

/* k2681 in k2678 in k2675 in k2672 in k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 in k2630 in k2627 in k2624 in k2621 in k2618 in ... */
static void C_ccall f_2683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2683,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2686,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:565: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[835],C_fix(2),C_fix(1),lf[836],C_SCHEME_FALSE);}

/* k2684 in k2681 in k2678 in k2675 in k2672 in k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 in k2630 in k2627 in k2624 in k2621 in ... */
static void C_ccall f_2686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2686,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2689,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:566: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[833],C_fix(2),C_fix(1),lf[834],C_SCHEME_FALSE);}

/* k2328 in k2185 in k2182 in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_2330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2330,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2333,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:491: rewrite-c..r */
f_2189(t2,lf[897],lf[898],lf[899],C_fix(0));}

/* k2331 in k2328 in k2185 in k2182 in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_2333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2336,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:492: rewrite-c..r */
f_2189(t2,lf[894],lf[895],lf[896],C_fix(0));}

/* k2678 in k2675 in k2672 in k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 in k2630 in k2627 in k2624 in k2621 in k2618 in k2615 in ... */
static void C_ccall f_2680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2680,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2683,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:564: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[837],C_fix(2),C_fix(1),lf[838],C_SCHEME_FALSE);}

/* k2337 in k2334 in k2331 in k2328 in k2185 in k2182 in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_2339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2339,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2342,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:494: rewrite-c..r */
f_2189(t2,lf[854],lf[889],lf[890],C_fix(2));}

/* k2334 in k2331 in k2328 in k2185 in k2182 in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_2336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2339,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:493: rewrite-c..r */
f_2189(t2,lf[891],lf[892],lf[893],C_fix(1));}

/* k2675 in k2672 in k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 in k2630 in k2627 in k2624 in k2621 in k2618 in k2615 in k2612 in ... */
static void C_ccall f_2677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2677,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2680,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:563: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[839],C_fix(2),C_fix(1),lf[840],C_SCHEME_FALSE);}

/* k2672 in k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 in k2630 in k2627 in k2624 in k2621 in k2618 in k2615 in k2612 in k2609 in ... */
static void C_ccall f_2674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2674,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2677,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:562: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[841],C_fix(2),C_fix(1),lf[842],C_SCHEME_FALSE);}

/* k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in k2651 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 in k2630 in k2627 in k2624 in k2621 in k2618 in k2615 in k2612 in k2609 in k2390 in ... */
static void C_ccall f_2671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2671,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2674,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:561: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[843],C_fix(2),C_fix(1),lf[844],C_SCHEME_FALSE);}

/* k3761 in k3758 in k3755 in k3752 in k3749 in k3746 in k3743 in k3740 in k3737 in k3734 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in ... */
static void C_ccall f_3763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3763,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3766,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1029: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[138],C_fix(7),C_fix(1),lf[139],C_fix(1),C_SCHEME_FALSE);}

/* k3764 in k3761 in k3758 in k3755 in k3752 in k3749 in k3746 in k3743 in k3740 in k3737 in k3734 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in ... */
static void C_ccall f_3766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3769,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1030: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[136],C_fix(7),C_fix(1),lf[137],C_fix(1),C_SCHEME_FALSE);}

/* k3767 in k3764 in k3761 in k3758 in k3755 in k3752 in k3749 in k3746 in k3743 in k3740 in k3737 in k3734 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in ... */
static void C_ccall f_3769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3769,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3772,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1031: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[134],C_fix(7),C_fix(1),lf[135],C_fix(1),C_SCHEME_FALSE);}

/* k3758 in k3755 in k3752 in k3749 in k3746 in k3743 in k3740 in k3737 in k3734 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in ... */
static void C_ccall f_3760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3760,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3763,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1028: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[140],C_fix(7),C_fix(1),lf[141],C_fix(1),C_SCHEME_FALSE);}

/* rewrite-c-w-v in k2390 in k2387 in k2355 in k2352 in k2349 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2328 in k2185 in k2182 in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in ... */
static void C_ccall f_2394(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2394,6,t0,t1,t2,t3,t4,t5);}
t6=C_i_length(t5);
t7=C_eqp(C_fix(2),t6);
if(C_truep(t7)){
t8=C_i_car(t5);
t9=t8;
t10=C_i_cadr(t5);
t11=t10;
t12=C_slot(t9,C_fix(1));
t13=C_eqp(lf[44],t12);
if(C_truep(t13)){
t14=C_slot(t11,C_fix(1));
t15=C_eqp(lf[44],t14);
if(C_truep(t15)){
t16=C_slot(t11,C_fix(2));
t17=C_i_car(t16);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2428,a[2]=t11,a[3]=t4,a[4]=t9,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-platform.scm:519: get */
t19=*((C_word*)lf[60]+1);
((C_proc5)(void*)(*((C_word*)t19+1)))(5,t19,t18,t2,t17,lf[73]);}
else{
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,C_SCHEME_FALSE);}}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}

/* k3752 in k3749 in k3746 in k3743 in k3740 in k3737 in k3734 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in ... */
static void C_ccall f_3754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3754,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3757,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1026: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[144],C_fix(7),C_fix(1),lf[145],C_fix(1),C_SCHEME_FALSE);}

/* k3755 in k3752 in k3749 in k3746 in k3743 in k3740 in k3737 in k3734 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in ... */
static void C_ccall f_3757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3757,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3760,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1027: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[142],C_fix(7),C_fix(1),lf[143],C_fix(1),C_SCHEME_FALSE);}

/* k2390 in k2387 in k2355 in k2352 in k2349 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2328 in k2185 in k2182 in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in ... */
static void C_ccall f_2392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2394,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2611,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:538: rewrite */
t4=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[870],C_fix(8),t2);}

/* k3749 in k3746 in k3743 in k3740 in k3737 in k3734 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in ... */
static void C_ccall f_3751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3751,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3754,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1024: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[146],C_fix(17),C_fix(1),lf[147],lf[148]);}

/* k2387 in k2355 in k2352 in k2349 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2328 in k2185 in k2182 in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in ... */
static void C_ccall f_2389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2392,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:507: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[52],C_fix(8),((C_word*)t0)[3]);}

/* for-each-loop44 in k1627 in k1604 in k1601 in k1598 */
static void C_fcall f_5678(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5678,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5688,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_a_i_list(&a,1,C_SCHEME_TRUE);
if(C_truep(C_i_nullp(t5))){
/* tweaks.scm:54: ##sys#put! */
t6=*((C_word*)lf[932]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t3,t4,lf[933],C_SCHEME_TRUE);}
else{
t6=C_i_car(t5);
/* tweaks.scm:54: ##sys#put! */
t7=*((C_word*)lf[932]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t3,t4,lf[933],t6);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3743 in k3740 in k3737 in k3734 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in ... */
static void C_ccall f_3745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3745,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3748,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1022: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[151],C_fix(17),C_fix(1),lf[152]);}

/* k3740 in k3737 in k3734 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in ... */
static void C_ccall f_3742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3742,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3745,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1020: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[153],C_fix(2),C_fix(1),lf[154],C_SCHEME_FALSE);}

/* k3746 in k3743 in k3740 in k3737 in k3734 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in ... */
static void C_ccall f_3748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3748,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3751,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1023: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[149],C_fix(17),C_fix(1),lf[150]);}

/* k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 in k3671 in k3668 in ... */
static void C_ccall f_3733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3736,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1017: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[159],C_fix(2),C_fix(1),lf[160],C_SCHEME_FALSE);}

/* k3737 in k3734 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 in ... */
static void C_ccall f_3739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3739,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3742,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1019: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[155],C_fix(2),C_fix(1),lf[156],C_SCHEME_FALSE);}

/* k3734 in k3731 in k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 in k3671 in ... */
static void C_ccall f_3736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3736,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3739,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1018: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[157],C_fix(2),C_fix(1),lf[158],C_SCHEME_FALSE);}

/* k3728 in k3725 in k3722 in k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3701 in k3698 in k3695 in k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in k3674 in k3671 in k3668 in k3665 in ... */
static void C_ccall f_3730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3730,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3733,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:1016: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[161],C_fix(2),C_fix(1),lf[162],C_SCHEME_FALSE);}

/* k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_1651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1651,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1654,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:243: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[444],C_fix(19),C_fix(0),lf[930],lf[931],C_SCHEME_FALSE);}

/* k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_1958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1958,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1960,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2184,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:459: rewrite */
t4=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[904],C_fix(8),t2);}

/* k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_1955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1955,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1958,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4814,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:404: rewrite */
t4=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[907],C_fix(8),t3);}

/* k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_1952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1955,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:402: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[797],C_fix(8),((C_word*)t0)[3]);}

/* k2627 in k2624 in k2621 in k2618 in k2615 in k2612 in k2609 in k2390 in k2387 in k2355 in k2352 in k2349 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2328 in k2185 in k2182 in k1956 in ... */
static void C_ccall f_2629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2629,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2632,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:546: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[867],C_fix(13),lf[868],C_SCHEME_TRUE);}

/* k2624 in k2621 in k2618 in k2615 in k2612 in k2609 in k2390 in k2387 in k2355 in k2352 in k2349 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2328 in k2185 in k2182 in k1956 in k1953 in ... */
static void C_ccall f_2626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2626,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2629,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:545: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[867],C_fix(13),lf[869],C_SCHEME_FALSE);}

/* k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_1660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1660,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1663,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5175,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:313: rewrite */
t4=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[442],C_fix(8),t3);}

/* k2621 in k2618 in k2615 in k2612 in k2609 in k2390 in k2387 in k2355 in k2352 in k2349 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2328 in k2185 in k2182 in k1956 in k1953 in k1950 in ... */
static void C_ccall f_2623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2623,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2626,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:544: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[870],C_fix(13),lf[871],C_SCHEME_TRUE);}

/* a4418 in k4074 in k4071 in k3922 in k3919 in k3916 in k3913 in k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in k3755 in k3752 in k3749 in k3746 in k3743 in k3740 in k3737 in k3734 in ... */
static void C_ccall f_4419(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4419,6,t0,t1,t2,t3,t4,t5);}
t6=C_i_length(t5);
t7=C_eqp(C_fix(1),t6);
if(C_truep(t7)){
t8=C_i_car(t5);
t9=C_slot(t8,C_fix(1));
t10=C_eqp(lf[44],t9);
if(C_truep(t10)){
t11=C_slot(t8,C_fix(2));
t12=C_i_car(t11);
t13=t12;
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4449,a[2]=t13,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* tweaks.scm:51: ##sys#get */
t15=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,t13,lf[55]);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}

/* rewrite-apply in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_1960(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1960,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1970,a[2]=t5,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* c-platform.scm:437: last */
t7=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t5);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* a3961 in k3943 in rewrite-call/cc in k3922 in k3919 in k3916 in k3913 in k3776 in k3773 in k3770 in k3767 in k3764 in k3761 in k3758 in k3755 in k3752 in k3749 in k3746 in k3743 in k3740 in k3737 in k3734 in ... */
static void C_ccall f_3962(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3962,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_nequalp(t3,C_fix(2)))){
t5=(C_truep(t4)?t4:C_i_cadr(((C_word*)t0)[2]));
t6=t5;
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4022,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* c-platform.scm:1081: get */
t8=*((C_word*)lf[60]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,((C_word*)t0)[5],t6,lf[79]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k2618 in k2615 in k2612 in k2609 in k2390 in k2387 in k2355 in k2352 in k2349 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2328 in k2185 in k2182 in k1956 in k1953 in k1950 in k1749 in ... */
static void C_ccall f_2620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2620,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2623,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:543: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[870],C_fix(13),lf[872],C_SCHEME_FALSE);}

/* k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_1654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1654,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1657,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5493,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:245: rewrite */
t4=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[448],C_fix(8),t3);}

/* k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_1657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1660,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5338,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:275: rewrite */
t4=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[446],C_fix(8),t3);}

/* k2615 in k2612 in k2609 in k2390 in k2387 in k2355 in k2352 in k2349 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2328 in k2185 in k2182 in k1956 in k1953 in k1950 in k1749 in k1746 in ... */
static void C_ccall f_2617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2617,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2620,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:542: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[52],C_fix(13),lf[873],C_SCHEME_TRUE);}

/* k2612 in k2609 in k2390 in k2387 in k2355 in k2352 in k2349 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2328 in k2185 in k2182 in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in ... */
static void C_ccall f_2614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2614,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2617,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:541: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[51],C_fix(13),lf[874],C_SCHEME_TRUE);}

/* k1968 in rewrite-apply in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_1970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1970,2,t0,t1);}
t2=t1;
t3=((C_word*)t0)[2];
t4=C_u_i_car(t3);
t5=C_slot(t2,C_fix(1));
t6=C_eqp(lf[43],t5);
if(C_truep(t6)){
t7=C_a_i_list1(&a,1,C_SCHEME_FALSE);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1993,a[2]=((C_word*)t0)[3],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=((C_word*)t0)[2];
t11=C_u_i_car(t10);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1999,a[2]=t9,a[3]=t11,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2061,a[2]=t2,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
/* c-platform.scm:444: butlast */
t14=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t14+1)))(3,t14,t13,((C_word*)t0)[2]);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2064,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t8=C_slot(t4,C_fix(1));
t9=C_eqp(lf[44],t8);
if(C_truep(t9)){
t10=C_i_length(((C_word*)t0)[2]);
t11=C_eqp(C_fix(2),t10);
if(C_truep(t11)){
t12=C_slot(t4,C_fix(2));
t13=C_i_car(t12);
if(C_truep((C_truep(C_eqp(t13,lf[51]))?C_SCHEME_TRUE:(C_truep(C_eqp(t13,lf[52]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2120,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* tweaks.scm:51: ##sys#get */
t15=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,t13,lf[55]);}
else{
t14=t7;
f_2064(t14,C_SCHEME_FALSE);}}
else{
t12=t7;
f_2064(t12,C_SCHEME_FALSE);}}
else{
t10=t7;
f_2064(t10,C_SCHEME_FALSE);}}}

/* k2609 in k2390 in k2387 in k2355 in k2352 in k2349 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2328 in k2185 in k2182 in k1956 in k1953 in k1950 in k1749 in k1746 in k1664 in k1661 in ... */
static void C_ccall f_2611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2611,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2614,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:539: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[867],C_fix(8),((C_word*)t0)[3]);}

/* k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_1663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1663,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1666,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5050,tmp=(C_word)a,a+=2,tmp);
/* c-platform.scm:340: rewrite */
t4=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[919],C_fix(8),t3);}

/* op1 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_fcall f_1668(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1668,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1670,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp));}

/* k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_1666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1668,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1748,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5048,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:380: op1 */
f_1668(t4,lf[913],lf[914],lf[915]);}

/* k2534 in k2538 in k2459 in k2456 in k2453 in k2426 in rewrite-c-w-v in k2390 in k2387 in k2355 in k2352 in k2349 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2328 in k2185 in k2182 in k1956 in ... */
static void C_ccall f_2536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2536,2,t0,t1);}
t2=C_a_i_list3(&a,3,((C_word*)t0)[2],((C_word*)t0)[3],t1);
t3=C_a_i_record4(&a,4,lf[37],lf[39],((C_word*)t0)[4],t2);
t4=C_a_i_list1(&a,1,t3);
t5=C_a_i_record4(&a,4,lf[37],lf[64],((C_word*)t0)[5],t4);
t6=t5;
t7=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2507,a[2]=((C_word*)t0)[6],a[3]=t8,a[4]=t6,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* c-platform.scm:537: varnode */
t10=*((C_word*)lf[66]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,((C_word*)t0)[9]);}

/* k2795 in k2792 in k2789 in k2786 in k2783 in k2780 in k2777 in k2774 in k2771 in k2768 in k2765 in k2762 in k2759 in k2756 in k2753 in k2750 in k2747 in k2744 in k2741 in k2738 in k2735 in k2732 in ... */
static void C_ccall f_2797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2797,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2800,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:607: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[762],C_fix(2),C_fix(1),lf[763],C_SCHEME_TRUE);}

/* k2792 in k2789 in k2786 in k2783 in k2780 in k2777 in k2774 in k2771 in k2768 in k2765 in k2762 in k2759 in k2756 in k2753 in k2750 in k2747 in k2744 in k2741 in k2738 in k2735 in k2732 in k2729 in ... */
static void C_ccall f_2794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2794,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2797,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:606: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[764],C_fix(2),C_fix(1),lf[765],C_SCHEME_TRUE);}

/* k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in k3029 in k3026 in k3023 in k3020 in k3017 in k3014 in k3011 in k3008 in k3005 in k3002 in k2999 in k2996 in k2993 in k2990 in k2987 in ... */
static void C_ccall f_3052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3052,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3055,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:698: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[592],C_fix(16),C_fix(2),lf[593],C_SCHEME_FALSE,*((C_word*)lf[9]+1));}

/* k2789 in k2786 in k2783 in k2780 in k2777 in k2774 in k2771 in k2768 in k2765 in k2762 in k2759 in k2756 in k2753 in k2750 in k2747 in k2744 in k2741 in k2738 in k2735 in k2732 in k2729 in k2726 in ... */
static void C_ccall f_2791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2791,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2794,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:605: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[766],C_fix(2),C_fix(1),lf[767],C_SCHEME_TRUE);}

/* k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in k3029 in k3026 in k3023 in k3020 in k3017 in k3014 in k3011 in k3008 in k3005 in k3002 in k2999 in k2996 in k2993 in ... */
static void C_ccall f_3058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3058,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3061,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:700: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[588],C_fix(16),C_fix(2),lf[589],C_SCHEME_FALSE,*((C_word*)lf[9]+1));}

/* k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in k3029 in k3026 in k3023 in k3020 in k3017 in k3014 in k3011 in k3008 in k3005 in k3002 in k2999 in k2996 in k2993 in k2990 in ... */
static void C_ccall f_3055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3058,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:699: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[590],C_fix(16),C_fix(2),lf[591],C_SCHEME_FALSE,*((C_word*)lf[9]+1));}

/* k2786 in k2783 in k2780 in k2777 in k2774 in k2771 in k2768 in k2765 in k2762 in k2759 in k2756 in k2753 in k2750 in k2747 in k2744 in k2741 in k2738 in k2735 in k2732 in k2729 in k2726 in k2723 in ... */
static void C_ccall f_2788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2788,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2791,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:604: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[768],C_fix(2),C_fix(1),lf[769],C_SCHEME_TRUE);}

/* k2783 in k2780 in k2777 in k2774 in k2771 in k2768 in k2765 in k2762 in k2759 in k2756 in k2753 in k2750 in k2747 in k2744 in k2741 in k2738 in k2735 in k2732 in k2729 in k2726 in k2723 in k2720 in ... */
static void C_ccall f_2785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2785,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2788,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:603: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[770],C_fix(2),C_fix(1),lf[771],C_SCHEME_TRUE);}

/* k3062 in k3059 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in k3029 in k3026 in k3023 in k3020 in k3017 in k3014 in k3011 in k3008 in k3005 in k3002 in k2999 in ... */
static void C_ccall f_3064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3064,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3067,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:702: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[584],C_fix(16),C_fix(2),lf[585],C_SCHEME_FALSE,*((C_word*)lf[9]+1));}

/* k3059 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in k3029 in k3026 in k3023 in k3020 in k3017 in k3014 in k3011 in k3008 in k3005 in k3002 in k2999 in k2996 in ... */
static void C_ccall f_3061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3061,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3064,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:701: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[586],C_fix(16),C_fix(2),lf[587],C_SCHEME_FALSE,*((C_word*)lf[9]+1));}

/* k2780 in k2777 in k2774 in k2771 in k2768 in k2765 in k2762 in k2759 in k2756 in k2753 in k2750 in k2747 in k2744 in k2741 in k2738 in k2735 in k2732 in k2729 in k2726 in k2723 in k2720 in k2717 in ... */
static void C_ccall f_2782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2782,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2785,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:602: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[772],C_fix(2),C_fix(1),lf[773],C_SCHEME_TRUE);}

/* k3065 in k3062 in k3059 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in k3029 in k3026 in k3023 in k3020 in k3017 in k3014 in k3011 in k3008 in k3005 in k3002 in ... */
static void C_ccall f_3067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3067,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3070,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:703: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[582],C_fix(16),C_fix(1),lf[583],C_SCHEME_FALSE,*((C_word*)lf[9]+1));}

/* k2538 in k2459 in k2456 in k2453 in k2426 in rewrite-c-w-v in k2390 in k2387 in k2355 in k2352 in k2349 in k2346 in k2343 in k2340 in k2337 in k2334 in k2331 in k2328 in k2185 in k2182 in k1956 in k1953 in ... */
static void C_ccall f_2540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2540,2,t0,t1);}
t2=C_a_i_list1(&a,1,((C_word*)t0)[2]);
t3=C_a_i_list4(&a,4,t1,C_SCHEME_FALSE,t2,C_fix(0));
t4=t3;
t5=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2536,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-platform.scm:534: varnode */
t8=*((C_word*)lf[66]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t0)[2]);}

/* k2777 in k2774 in k2771 in k2768 in k2765 in k2762 in k2759 in k2756 in k2753 in k2750 in k2747 in k2744 in k2741 in k2738 in k2735 in k2732 in k2729 in k2726 in k2723 in k2720 in k2717 in k2714 in ... */
static void C_ccall f_2779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2779,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2782,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:601: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[774],C_fix(2),C_fix(1),lf[775],C_SCHEME_TRUE);}

/* k2771 in k2768 in k2765 in k2762 in k2759 in k2756 in k2753 in k2750 in k2747 in k2744 in k2741 in k2738 in k2735 in k2732 in k2729 in k2726 in k2723 in k2720 in k2717 in k2714 in k2711 in k2708 in ... */
static void C_ccall f_2773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2776,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:599: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[778],C_fix(2),C_fix(1),lf[779],C_SCHEME_TRUE);}

/* k2774 in k2771 in k2768 in k2765 in k2762 in k2759 in k2756 in k2753 in k2750 in k2747 in k2744 in k2741 in k2738 in k2735 in k2732 in k2729 in k2726 in k2723 in k2720 in k2717 in k2714 in k2711 in ... */
static void C_ccall f_2776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2776,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2779,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:600: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[776],C_fix(2),C_fix(1),lf[777],C_SCHEME_TRUE);}

/* k3071 in k3068 in k3065 in k3062 in k3059 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in k3029 in k3026 in k3023 in k3020 in k3017 in k3014 in k3011 in k3008 in ... */
static void C_ccall f_3073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3073,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3076,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:706: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[578],C_fix(16),C_fix(1),lf[579],C_SCHEME_TRUE,*((C_word*)lf[9]+1));}

/* k3068 in k3065 in k3062 in k3059 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in k3029 in k3026 in k3023 in k3020 in k3017 in k3014 in k3011 in k3008 in k3005 in ... */
static void C_ccall f_3070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3070,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3073,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:705: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[580],C_fix(16),C_fix(1),lf[581],C_SCHEME_TRUE,*((C_word*)lf[9]+1));}

/* k2768 in k2765 in k2762 in k2759 in k2756 in k2753 in k2750 in k2747 in k2744 in k2741 in k2738 in k2735 in k2732 in k2729 in k2726 in k2723 in k2720 in k2717 in k2714 in k2711 in k2708 in k2705 in ... */
static void C_ccall f_2770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2770,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2773,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:598: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[780],C_fix(2),C_fix(1),lf[781],C_SCHEME_TRUE);}

/* k3077 in k3074 in k3071 in k3068 in k3065 in k3062 in k3059 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in k3029 in k3026 in k3023 in k3020 in k3017 in k3014 in ... */
static void C_ccall f_3079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3079,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3082,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:708: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[574],C_fix(16),C_fix(1),lf[575],C_SCHEME_TRUE,*((C_word*)lf[9]+1));}

/* k3074 in k3071 in k3068 in k3065 in k3062 in k3059 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in k3029 in k3026 in k3023 in k3020 in k3017 in k3014 in k3011 in ... */
static void C_ccall f_3076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3076,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3079,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:707: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[576],C_fix(16),C_fix(1),lf[577],C_SCHEME_TRUE,*((C_word*)lf[9]+1));}

/* k2888 in k2885 in k2882 in k2879 in k2876 in k2873 in k2870 in k2867 in k2864 in k2861 in k2858 in k2855 in k2852 in k2849 in k2846 in k2843 in k2840 in k2837 in k2834 in k2831 in k2828 in k2825 in ... */
static void C_ccall f_2890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2893,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:638: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[707],C_fix(2),C_fix(2),lf[708],C_SCHEME_TRUE);}

/* k3080 in k3077 in k3074 in k3071 in k3068 in k3065 in k3062 in k3059 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in k3029 in k3026 in k3023 in k3020 in k3017 in ... */
static void C_ccall f_3082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3082,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3085,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:709: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[572],C_fix(16),C_fix(1),lf[573],C_SCHEME_TRUE,*((C_word*)lf[9]+1));}

/* k3083 in k3080 in k3077 in k3074 in k3071 in k3068 in k3065 in k3062 in k3059 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in k3029 in k3026 in k3023 in k3020 in ... */
static void C_ccall f_3085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3085,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3088,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:710: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[570],C_fix(16),C_fix(1),lf[571],C_SCHEME_TRUE,*((C_word*)lf[9]+1));}

/* k3086 in k3083 in k3080 in k3077 in k3074 in k3071 in k3068 in k3065 in k3062 in k3059 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in k3029 in k3026 in k3023 in ... */
static void C_ccall f_3088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3088,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3091,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:711: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[568],C_fix(16),C_fix(1),lf[569],C_SCHEME_TRUE,*((C_word*)lf[9]+1));}

/* k2879 in k2876 in k2873 in k2870 in k2867 in k2864 in k2861 in k2858 in k2855 in k2852 in k2849 in k2846 in k2843 in k2840 in k2837 in k2834 in k2831 in k2828 in k2825 in k2822 in k2819 in k2816 in ... */
static void C_ccall f_2881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2884,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:635: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[713],C_fix(2),C_fix(2),lf[714],C_SCHEME_TRUE);}

/* k3089 in k3086 in k3083 in k3080 in k3077 in k3074 in k3071 in k3068 in k3065 in k3062 in k3059 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in k3029 in k3026 in ... */
static void C_ccall f_3091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3091,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3094,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:712: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[563],C_fix(16),C_fix(1),lf[567],C_SCHEME_TRUE,*((C_word*)lf[9]+1));}

/* k3092 in k3089 in k3086 in k3083 in k3080 in k3077 in k3074 in k3071 in k3068 in k3065 in k3062 in k3059 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in k3029 in ... */
static void C_ccall f_3094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3094,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3097,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:713: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[565],C_fix(16),C_fix(1),lf[566],C_SCHEME_TRUE,*((C_word*)lf[9]+1));}

/* k2891 in k2888 in k2885 in k2882 in k2879 in k2876 in k2873 in k2870 in k2867 in k2864 in k2861 in k2858 in k2855 in k2852 in k2849 in k2846 in k2843 in k2840 in k2837 in k2834 in k2831 in k2828 in ... */
static void C_ccall f_2893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2896,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:639: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[705],C_fix(2),C_fix(2),lf[706],C_SCHEME_TRUE);}

/* k2894 in k2891 in k2888 in k2885 in k2882 in k2879 in k2876 in k2873 in k2870 in k2867 in k2864 in k2861 in k2858 in k2855 in k2852 in k2849 in k2846 in k2843 in k2840 in k2837 in k2834 in k2831 in ... */
static void C_ccall f_2896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2899,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:640: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[703],C_fix(2),C_fix(2),lf[704],C_SCHEME_TRUE);}

/* k2897 in k2894 in k2891 in k2888 in k2885 in k2882 in k2879 in k2876 in k2873 in k2870 in k2867 in k2864 in k2861 in k2858 in k2855 in k2852 in k2849 in k2846 in k2843 in k2840 in k2837 in k2834 in ... */
static void C_ccall f_2899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2902,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:641: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[701],C_fix(2),C_fix(1),lf[702],C_SCHEME_TRUE);}

/* k3095 in k3092 in k3089 in k3086 in k3083 in k3080 in k3077 in k3074 in k3071 in k3068 in k3065 in k3062 in k3059 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in ... */
static void C_ccall f_3097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3097,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3100,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:714: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[563],C_fix(16),C_fix(2),lf[564],C_SCHEME_TRUE,*((C_word*)lf[9]+1));}

/* k2882 in k2879 in k2876 in k2873 in k2870 in k2867 in k2864 in k2861 in k2858 in k2855 in k2852 in k2849 in k2846 in k2843 in k2840 in k2837 in k2834 in k2831 in k2828 in k2825 in k2822 in k2819 in ... */
static void C_ccall f_2884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2884,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2887,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:636: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[711],C_fix(2),C_fix(2),lf[712],C_SCHEME_TRUE);}

/* k2885 in k2882 in k2879 in k2876 in k2873 in k2870 in k2867 in k2864 in k2861 in k2858 in k2855 in k2852 in k2849 in k2846 in k2843 in k2840 in k2837 in k2834 in k2831 in k2828 in k2825 in k2822 in ... */
static void C_ccall f_2887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2887,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2890,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:637: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[709],C_fix(2),C_fix(2),lf[710],C_SCHEME_TRUE);}

/* k5157 in a5049 in k1661 in k1658 in k1655 in k1652 in k1649 in k1627 in k1604 in k1601 in k1598 */
static void C_ccall f_5159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5159,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record4(&a,4,lf[37],lf[39],((C_word*)t0)[3],t1));}

/* k2720 in k2717 in k2714 in k2711 in k2708 in k2705 in k2702 in k2699 in k2696 in k2693 in k2690 in k2687 in k2684 in k2681 in k2678 in k2675 in k2672 in k2669 in k2666 in k2663 in k2660 in k2657 in ... */
static void C_ccall f_2722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2722,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2725,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-platform.scm:579: rewrite */
t3=*((C_word*)lf[63]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[810],C_fix(2),C_fix(1),lf[811],C_SCHEME_TRUE);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[554] = {
{"f_2728:c_2dplatform_2escm",(void*)f_2728},
{"f_2725:c_2dplatform_2escm",(void*)f_2725},
{"f_2713:c_2dplatform_2escm",(void*)f_2713},
{"f_2710:c_2dplatform_2escm",(void*)f_2710},
{"f_4282:c_2dplatform_2escm",(void*)f_4282},
{"f_2719:c_2dplatform_2escm",(void*)f_2719},
{"f_2716:c_2dplatform_2escm",(void*)f_2716},
{"f_2701:c_2dplatform_2escm",(void*)f_2701},
{"f_2704:c_2dplatform_2escm",(void*)f_2704},
{"f_2707:c_2dplatform_2escm",(void*)f_2707},
{"f_3295:c_2dplatform_2escm",(void*)f_3295},
{"f_3292:c_2dplatform_2escm",(void*)f_3292},
{"f_3298:c_2dplatform_2escm",(void*)f_3298},
{"f_3262:c_2dplatform_2escm",(void*)f_3262},
{"f_3265:c_2dplatform_2escm",(void*)f_3265},
{"f_3268:c_2dplatform_2escm",(void*)f_3268},
{"f_4870:c_2dplatform_2escm",(void*)f_4870},
{"f_3280:c_2dplatform_2escm",(void*)f_3280},
{"f_5497:c_2dplatform_2escm",(void*)f_5497},
{"f_3283:c_2dplatform_2escm",(void*)f_3283},
{"f_5493:c_2dplatform_2escm",(void*)f_5493},
{"f_2083:c_2dplatform_2escm",(void*)f_2083},
{"f_3289:c_2dplatform_2escm",(void*)f_3289},
{"f_3286:c_2dplatform_2escm",(void*)f_3286},
{"f_2860:c_2dplatform_2escm",(void*)f_2860},
{"f_5226:c_2dplatform_2escm",(void*)f_5226},
{"f_1778:c_2dplatform_2escm",(void*)f_1778},
{"f_4504:c_2dplatform_2escm",(void*)f_4504},
{"f_1908:c_2dplatform_2escm",(void*)f_1908},
{"f_2875:c_2dplatform_2escm",(void*)f_2875},
{"f_2872:c_2dplatform_2escm",(void*)f_2872},
{"f_2878:c_2dplatform_2escm",(void*)f_2878},
{"f_2061:c_2dplatform_2escm",(void*)f_2061},
{"f_2064:c_2dplatform_2escm",(void*)f_2064},
{"f_1781:c_2dplatform_2escm",(void*)f_1781},
{"f_3628:c_2dplatform_2escm",(void*)f_3628},
{"f_3625:c_2dplatform_2escm",(void*)f_3625},
{"f_3622:c_2dplatform_2escm",(void*)f_3622},
{"f_2863:c_2dplatform_2escm",(void*)f_2863},
{"f_2869:c_2dplatform_2escm",(void*)f_2869},
{"f_2866:c_2dplatform_2escm",(void*)f_2866},
{"f_5242:c_2dplatform_2escm",(void*)f_5242},
{"f_3616:c_2dplatform_2escm",(void*)f_3616},
{"f_3613:c_2dplatform_2escm",(void*)f_3613},
{"f_3610:c_2dplatform_2escm",(void*)f_3610},
{"f_3379:c_2dplatform_2escm",(void*)f_3379},
{"f_3376:c_2dplatform_2escm",(void*)f_3376},
{"f_2044:c_2dplatform_2escm",(void*)f_2044},
{"f_3619:c_2dplatform_2escm",(void*)f_3619},
{"f_4534:c_2dplatform_2escm",(void*)f_4534},
{"f_3370:c_2dplatform_2escm",(void*)f_3370},
{"f_3373:c_2dplatform_2escm",(void*)f_3373},
{"f_2824:c_2dplatform_2escm",(void*)f_2824},
{"f_2821:c_2dplatform_2escm",(void*)f_2821},
{"f_2839:c_2dplatform_2escm",(void*)f_2839},
{"f_3634:c_2dplatform_2escm",(void*)f_3634},
{"f_3637:c_2dplatform_2escm",(void*)f_3637},
{"f_3631:c_2dplatform_2escm",(void*)f_3631},
{"f_3397:c_2dplatform_2escm",(void*)f_3397},
{"f_3664:c_2dplatform_2escm",(void*)f_3664},
{"f_2827:c_2dplatform_2escm",(void*)f_2827},
{"f_3391:c_2dplatform_2escm",(void*)f_3391},
{"f_3667:c_2dplatform_2escm",(void*)f_3667},
{"f_3394:c_2dplatform_2escm",(void*)f_3394},
{"f_3661:c_2dplatform_2escm",(void*)f_3661},
{"f_3367:c_2dplatform_2escm",(void*)f_3367},
{"f_3655:c_2dplatform_2escm",(void*)f_3655},
{"f_3652:c_2dplatform_2escm",(void*)f_3652},
{"f_3658:c_2dplatform_2escm",(void*)f_3658},
{"f_3361:c_2dplatform_2escm",(void*)f_3361},
{"f_3364:c_2dplatform_2escm",(void*)f_3364},
{"f_3607:c_2dplatform_2escm",(void*)f_3607},
{"f_3601:c_2dplatform_2escm",(void*)f_3601},
{"f_3604:c_2dplatform_2escm",(void*)f_3604},
{"f_4214:c_2dplatform_2escm",(void*)f_4214},
{"f_1600:c_2dplatform_2escm",(void*)f_1600},
{"f_1748:c_2dplatform_2escm",(void*)f_1748},
{"f_2507:c_2dplatform_2escm",(void*)f_2507},
{"f_1740:c_2dplatform_2escm",(void*)f_1740},
{"f_1753:c_2dplatform_2escm",(void*)f_1753},
{"f_2854:c_2dplatform_2escm",(void*)f_2854},
{"f_2851:c_2dplatform_2escm",(void*)f_2851},
{"f_1751:c_2dplatform_2escm",(void*)f_1751},
{"f_3271:c_2dplatform_2escm",(void*)f_3271},
{"f_3274:c_2dplatform_2escm",(void*)f_3274},
{"f_1606:c_2dplatform_2escm",(void*)f_1606},
{"f_3277:c_2dplatform_2escm",(void*)f_3277},
{"f_1603:c_2dplatform_2escm",(void*)f_1603},
{"f_1769:c_2dplatform_2escm",(void*)f_1769},
{"f_2845:c_2dplatform_2escm",(void*)f_2845},
{"f_2842:c_2dplatform_2escm",(void*)f_2842},
{"f_2857:c_2dplatform_2escm",(void*)f_2857},
{"f_2836:c_2dplatform_2escm",(void*)f_2836},
{"f_2833:c_2dplatform_2escm",(void*)f_2833},
{"f_2830:c_2dplatform_2escm",(void*)f_2830},
{"f_2848:c_2dplatform_2escm",(void*)f_2848},
{"f_3643:c_2dplatform_2escm",(void*)f_3643},
{"f_3646:c_2dplatform_2escm",(void*)f_3646},
{"f_3649:c_2dplatform_2escm",(void*)f_3649},
{"f_3640:c_2dplatform_2escm",(void*)f_3640},
{"f_4095:c_2dplatform_2escm",(void*)f_4095},
{"f_4092:c_2dplatform_2escm",(void*)f_4092},
{"f_4098:c_2dplatform_2escm",(void*)f_4098},
{"f_1629:c_2dplatform_2escm",(void*)f_1629},
{"f_3778:c_2dplatform_2escm",(void*)f_3778},
{"f_3775:c_2dplatform_2escm",(void*)f_3775},
{"f_3772:c_2dplatform_2escm",(void*)f_3772},
{"f_3388:c_2dplatform_2escm",(void*)f_3388},
{"f_3780:c_2dplatform_2escm",(void*)f_3780},
{"f_3382:c_2dplatform_2escm",(void*)f_3382},
{"f_3385:c_2dplatform_2escm",(void*)f_3385},
{"f_5107:c_2dplatform_2escm",(void*)f_5107},
{"f_4390:c_2dplatform_2escm",(void*)f_4390},
{"f_3800:c_2dplatform_2escm",(void*)f_3800},
{"f_2120:c_2dplatform_2escm",(void*)f_2120},
{"f_5044:c_2dplatform_2escm",(void*)f_5044},
{"f_5048:c_2dplatform_2escm",(void*)f_5048},
{"f_3310:c_2dplatform_2escm",(void*)f_3310},
{"f_3313:c_2dplatform_2escm",(void*)f_3313},
{"f_3316:c_2dplatform_2escm",(void*)f_3316},
{"f_3319:c_2dplatform_2escm",(void*)f_3319},
{"f_5217:c_2dplatform_2escm",(void*)f_5217},
{"f_5219:c_2dplatform_2escm",(void*)f_5219},
{"f_3340:c_2dplatform_2escm",(void*)f_3340},
{"f_3349:c_2dplatform_2escm",(void*)f_3349},
{"f_3343:c_2dplatform_2escm",(void*)f_3343},
{"f_3346:c_2dplatform_2escm",(void*)f_3346},
{"f_3815:c_2dplatform_2escm",(void*)f_3815},
{"f_4076:c_2dplatform_2escm",(void*)f_4076},
{"f_4073:c_2dplatform_2escm",(void*)f_4073},
{"f_4086:c_2dplatform_2escm",(void*)f_4086},
{"f_4083:c_2dplatform_2escm",(void*)f_4083},
{"f_4080:c_2dplatform_2escm",(void*)f_4080},
{"f_3322:c_2dplatform_2escm",(void*)f_3322},
{"f_3328:c_2dplatform_2escm",(void*)f_3328},
{"f_3325:c_2dplatform_2escm",(void*)f_3325},
{"f_4089:c_2dplatform_2escm",(void*)f_4089},
{"f_3352:c_2dplatform_2escm",(void*)f_3352},
{"f_3358:c_2dplatform_2escm",(void*)f_3358},
{"f_3355:c_2dplatform_2escm",(void*)f_3355},
{"f_3868:c_2dplatform_2escm",(void*)f_3868},
{"f_3331:c_2dplatform_2escm",(void*)f_3331},
{"f_3337:c_2dplatform_2escm",(void*)f_3337},
{"f_3334:c_2dplatform_2escm",(void*)f_3334},
{"f_4022:c_2dplatform_2escm",(void*)f_4022},
{"f_2812:c_2dplatform_2escm",(void*)f_2812},
{"f_2815:c_2dplatform_2escm",(void*)f_2815},
{"f_3583:c_2dplatform_2escm",(void*)f_3583},
{"f_3586:c_2dplatform_2escm",(void*)f_3586},
{"f_3580:c_2dplatform_2escm",(void*)f_3580},
{"f_3577:c_2dplatform_2escm",(void*)f_3577},
{"f_2800:c_2dplatform_2escm",(void*)f_2800},
{"f_5703:c_2dplatform_2escm",(void*)f_5703},
{"f_2803:c_2dplatform_2escm",(void*)f_2803},
{"f_2806:c_2dplatform_2escm",(void*)f_2806},
{"f_2818:c_2dplatform_2escm",(void*)f_2818},
{"f_4365:c_2dplatform_2escm",(void*)f_4365},
{"f_4362:c_2dplatform_2escm",(void*)f_4362},
{"f_3595:c_2dplatform_2escm",(void*)f_3595},
{"f_3592:c_2dplatform_2escm",(void*)f_3592},
{"f_3589:c_2dplatform_2escm",(void*)f_3589},
{"f_2809:c_2dplatform_2escm",(void*)f_2809},
{"f_3598:c_2dplatform_2escm",(void*)f_3598},
{"f_3301:c_2dplatform_2escm",(void*)f_3301},
{"f_3304:c_2dplatform_2escm",(void*)f_3304},
{"f_3307:c_2dplatform_2escm",(void*)f_3307},
{"f_4207:c_2dplatform_2escm",(void*)f_4207},
{"f_4332:c_2dplatform_2escm",(void*)f_4332},
{"f_2992:c_2dplatform_2escm",(void*)f_2992},
{"f_2995:c_2dplatform_2escm",(void*)f_2995},
{"f_2998:c_2dplatform_2escm",(void*)f_2998},
{"f_2983:c_2dplatform_2escm",(void*)f_2983},
{"f_2986:c_2dplatform_2escm",(void*)f_2986},
{"f_2989:c_2dplatform_2escm",(void*)f_2989},
{"f_2980:c_2dplatform_2escm",(void*)f_2980},
{"f_3574:c_2dplatform_2escm",(void*)f_3574},
{"f_3571:c_2dplatform_2escm",(void*)f_3571},
{"f_5644:c_2dplatform_2escm",(void*)f_5644},
{"f_2207:c_2dplatform_2escm",(void*)f_2207},
{"f_4867:c_2dplatform_2escm",(void*)f_4867},
{"f_4836:c_2dplatform_2escm",(void*)f_4836},
{"f_4830:c_2dplatform_2escm",(void*)f_4830},
{"f_2231:c_2dplatform_2escm",(void*)f_2231},
{"f_2234:c_2dplatform_2escm",(void*)f_2234},
{"f_2195:c_2dplatform_2escm",(void*)f_2195},
{"f_4814:c_2dplatform_2escm",(void*)f_4814},
{"f_5297:c_2dplatform_2escm",(void*)f_5297},
{"f_5295:c_2dplatform_2escm",(void*)f_5295},
{"f_2187:c_2dplatform_2escm",(void*)f_2187},
{"f_2184:c_2dplatform_2escm",(void*)f_2184},
{"f_2189:c_2dplatform_2escm",(void*)f_2189},
{"f_2974:c_2dplatform_2escm",(void*)f_2974},
{"f_2977:c_2dplatform_2escm",(void*)f_2977},
{"f_2971:c_2dplatform_2escm",(void*)f_2971},
{"f_3211:c_2dplatform_2escm",(void*)f_3211},
{"f_3217:c_2dplatform_2escm",(void*)f_3217},
{"f_3214:c_2dplatform_2escm",(void*)f_3214},
{"f_5175:c_2dplatform_2escm",(void*)f_5175},
{"f_2965:c_2dplatform_2escm",(void*)f_2965},
{"f_2461:c_2dplatform_2escm",(void*)f_2461},
{"f_2962:c_2dplatform_2escm",(void*)f_2962},
{"f_2968:c_2dplatform_2escm",(void*)f_2968},
{"f_3202:c_2dplatform_2escm",(void*)f_3202},
{"f_3205:c_2dplatform_2escm",(void*)f_3205},
{"f_3208:c_2dplatform_2escm",(void*)f_3208},
{"f_5523:c_2dplatform_2escm",(void*)f_5523},
{"f_2455:c_2dplatform_2escm",(void*)f_2455},
{"f_3232:c_2dplatform_2escm",(void*)f_3232},
{"f_3238:c_2dplatform_2escm",(void*)f_3238},
{"f_3235:c_2dplatform_2escm",(void*)f_3235},
{"f_2254:c_2dplatform_2escm",(void*)f_2254},
{"f_3460:c_2dplatform_2escm",(void*)f_3460},
{"f_3463:c_2dplatform_2escm",(void*)f_3463},
{"f_2458:c_2dplatform_2escm",(void*)f_2458},
{"f_3220:c_2dplatform_2escm",(void*)f_3220},
{"f_3229:c_2dplatform_2escm",(void*)f_3229},
{"f_3223:c_2dplatform_2escm",(void*)f_3223},
{"f_3226:c_2dplatform_2escm",(void*)f_3226},
{"f_3469:c_2dplatform_2escm",(void*)f_3469},
{"f_3466:c_2dplatform_2escm",(void*)f_3466},
{"f_2935:c_2dplatform_2escm",(void*)f_2935},
{"f_2932:c_2dplatform_2escm",(void*)f_2932},
{"f_2938:c_2dplatform_2escm",(void*)f_2938},
{"f_3475:c_2dplatform_2escm",(void*)f_3475},
{"f_3472:c_2dplatform_2escm",(void*)f_3472},
{"f_3250:c_2dplatform_2escm",(void*)f_3250},
{"f_3259:c_2dplatform_2escm",(void*)f_3259},
{"f_3256:c_2dplatform_2escm",(void*)f_3256},
{"f_3253:c_2dplatform_2escm",(void*)f_3253},
{"f_3478:c_2dplatform_2escm",(void*)f_3478},
{"f_2926:c_2dplatform_2escm",(void*)f_2926},
{"f_2923:c_2dplatform_2escm",(void*)f_2923},
{"f_2920:c_2dplatform_2escm",(void*)f_2920},
{"f_4134:c_2dplatform_2escm",(void*)f_4134},
{"f_2929:c_2dplatform_2escm",(void*)f_2929},
{"f_4131:c_2dplatform_2escm",(void*)f_4131},
{"f_3481:c_2dplatform_2escm",(void*)f_3481},
{"f_4137:c_2dplatform_2escm",(void*)f_4137},
{"f_4139:c_2dplatform_2escm",(void*)f_4139},
{"f_3484:c_2dplatform_2escm",(void*)f_3484},
{"f_3241:c_2dplatform_2escm",(void*)f_3241},
{"f_3247:c_2dplatform_2escm",(void*)f_3247},
{"f_3244:c_2dplatform_2escm",(void*)f_3244},
{"f_3487:c_2dplatform_2escm",(void*)f_3487},
{"f_4101:c_2dplatform_2escm",(void*)f_4101},
{"f_4107:c_2dplatform_2escm",(void*)f_4107},
{"f_4104:c_2dplatform_2escm",(void*)f_4104},
{"f_2428:c_2dplatform_2escm",(void*)f_2428},
{"f_4010:c_2dplatform_2escm",(void*)f_4010},
{"f_4014:c_2dplatform_2escm",(void*)f_4014},
{"f_4018:c_2dplatform_2escm",(void*)f_4018},
{"f_1670:c_2dplatform_2escm",(void*)f_1670},
{"f_4475:c_2dplatform_2escm",(void*)f_4475},
{"f_4125:c_2dplatform_2escm",(void*)f_4125},
{"f_4122:c_2dplatform_2escm",(void*)f_4122},
{"f_4128:c_2dplatform_2escm",(void*)f_4128},
{"toplevel:c_2dplatform_2escm",(void*)C_platform_toplevel},
{"f_4791:c_2dplatform_2escm",(void*)f_4791},
{"f_2953:c_2dplatform_2escm",(void*)f_2953},
{"f_2956:c_2dplatform_2escm",(void*)f_2956},
{"f_2950:c_2dplatform_2escm",(void*)f_2950},
{"f_2959:c_2dplatform_2escm",(void*)f_2959},
{"f_4149:c_2dplatform_2escm",(void*)f_4149},
{"f_2944:c_2dplatform_2escm",(void*)f_2944},
{"f_3001:c_2dplatform_2escm",(void*)f_3001},
{"f_2941:c_2dplatform_2escm",(void*)f_2941},
{"f_3007:c_2dplatform_2escm",(void*)f_3007},
{"f_2947:c_2dplatform_2escm",(void*)f_2947},
{"f_3004:c_2dplatform_2escm",(void*)f_3004},
{"f_5447:c_2dplatform_2escm",(void*)f_5447},
{"f_5445:c_2dplatform_2escm",(void*)f_5445},
{"f_3022:c_2dplatform_2escm",(void*)f_3022},
{"f_3025:c_2dplatform_2escm",(void*)f_3025},
{"f_3028:c_2dplatform_2escm",(void*)f_3028},
{"f_3181:c_2dplatform_2escm",(void*)f_3181},
{"f_3184:c_2dplatform_2escm",(void*)f_3184},
{"f_3013:c_2dplatform_2escm",(void*)f_3013},
{"f_3010:c_2dplatform_2escm",(void*)f_3010},
{"f_3016:c_2dplatform_2escm",(void*)f_3016},
{"f_3019:c_2dplatform_2escm",(void*)f_3019},
{"f_3178:c_2dplatform_2escm",(void*)f_3178},
{"f_3870:c_2dplatform_2escm",(void*)f_3870},
{"f_3490:c_2dplatform_2escm",(void*)f_3490},
{"f_3493:c_2dplatform_2escm",(void*)f_3493},
{"f_3496:c_2dplatform_2escm",(void*)f_3496},
{"f_3499:c_2dplatform_2escm",(void*)f_3499},
{"f_4940:c_2dplatform_2escm",(void*)f_4940},
{"f_3190:c_2dplatform_2escm",(void*)f_3190},
{"f_3193:c_2dplatform_2escm",(void*)f_3193},
{"f_3187:c_2dplatform_2escm",(void*)f_3187},
{"f_4999:c_2dplatform_2escm",(void*)f_4999},
{"f_3199:c_2dplatform_2escm",(void*)f_3199},
{"f_3196:c_2dplatform_2escm",(void*)f_3196},
{"f_4449:c_2dplatform_2escm",(void*)f_4449},
{"f_2668:c_2dplatform_2escm",(void*)f_2668},
{"f_4612:c_2dplatform_2escm",(void*)f_4612},
{"f_2665:c_2dplatform_2escm",(void*)f_2665},
{"f_2662:c_2dplatform_2escm",(void*)f_2662},
{"f_2659:c_2dplatform_2escm",(void*)f_2659},
{"f_2656:c_2dplatform_2escm",(void*)f_2656},
{"f_2650:c_2dplatform_2escm",(void*)f_2650},
{"f_2653:c_2dplatform_2escm",(void*)f_2653},
{"f_2647:c_2dplatform_2escm",(void*)f_2647},
{"f_3451:c_2dplatform_2escm",(void*)f_3451},
{"f_3457:c_2dplatform_2escm",(void*)f_3457},
{"f_3454:c_2dplatform_2escm",(void*)f_3454},
{"f_2641:c_2dplatform_2escm",(void*)f_2641},
{"f_2644:c_2dplatform_2escm",(void*)f_2644},
{"f_2638:c_2dplatform_2escm",(void*)f_2638},
{"f_3400:c_2dplatform_2escm",(void*)f_3400},
{"f_3403:c_2dplatform_2escm",(void*)f_3403},
{"f_3406:c_2dplatform_2escm",(void*)f_3406},
{"f_3409:c_2dplatform_2escm",(void*)f_3409},
{"f_4608:c_2dplatform_2escm",(void*)f_4608},
{"f_2632:c_2dplatform_2escm",(void*)f_2632},
{"f_2635:c_2dplatform_2escm",(void*)f_2635},
{"f_3421:c_2dplatform_2escm",(void*)f_3421},
{"f_3427:c_2dplatform_2escm",(void*)f_3427},
{"f_3424:c_2dplatform_2escm",(void*)f_3424},
{"f_4661:c_2dplatform_2escm",(void*)f_4661},
{"f_4636:c_2dplatform_2escm",(void*)f_4636},
{"f_4584:c_2dplatform_2escm",(void*)f_4584},
{"f_3442:c_2dplatform_2escm",(void*)f_3442},
{"f_3448:c_2dplatform_2escm",(void*)f_3448},
{"f_3445:c_2dplatform_2escm",(void*)f_3445},
{"f_3430:c_2dplatform_2escm",(void*)f_3430},
{"f_3439:c_2dplatform_2escm",(void*)f_3439},
{"f_3436:c_2dplatform_2escm",(void*)f_3436},
{"f_3433:c_2dplatform_2escm",(void*)f_3433},
{"f_5598:c_2dplatform_2escm",(void*)f_5598},
{"f_4907:c_2dplatform_2escm",(void*)f_4907},
{"f_5582:c_2dplatform_2escm",(void*)f_5582},
{"f_3553:c_2dplatform_2escm",(void*)f_3553},
{"f_3559:c_2dplatform_2escm",(void*)f_3559},
{"f_3556:c_2dplatform_2escm",(void*)f_3556},
{"f_3550:c_2dplatform_2escm",(void*)f_3550},
{"f_3160:c_2dplatform_2escm",(void*)f_3160},
{"f_3163:c_2dplatform_2escm",(void*)f_3163},
{"f_5575:c_2dplatform_2escm",(void*)f_5575},
{"f_5573:c_2dplatform_2escm",(void*)f_5573},
{"f_3544:c_2dplatform_2escm",(void*)f_3544},
{"f_3547:c_2dplatform_2escm",(void*)f_3547},
{"f_4741:c_2dplatform_2escm",(void*)f_4741},
{"f_3541:c_2dplatform_2escm",(void*)f_3541},
{"f_2761:c_2dplatform_2escm",(void*)f_2761},
{"f_2764:c_2dplatform_2escm",(void*)f_2764},
{"f_3172:c_2dplatform_2escm",(void*)f_3172},
{"f_3175:c_2dplatform_2escm",(void*)f_3175},
{"f_3166:c_2dplatform_2escm",(void*)f_3166},
{"f_2767:c_2dplatform_2escm",(void*)f_2767},
{"f_3169:c_2dplatform_2escm",(void*)f_3169},
{"f_3532:c_2dplatform_2escm",(void*)f_3532},
{"f_3535:c_2dplatform_2escm",(void*)f_3535},
{"f_3538:c_2dplatform_2escm",(void*)f_3538},
{"f_3673:c_2dplatform_2escm",(void*)f_3673},
{"f_3676:c_2dplatform_2escm",(void*)f_3676},
{"f_3670:c_2dplatform_2escm",(void*)f_3670},
{"f_2755:c_2dplatform_2escm",(void*)f_2755},
{"f_2752:c_2dplatform_2escm",(void*)f_2752},
{"f_3679:c_2dplatform_2escm",(void*)f_3679},
{"f_2911:c_2dplatform_2escm",(void*)f_2911},
{"f_2914:c_2dplatform_2escm",(void*)f_2914},
{"f_2917:c_2dplatform_2escm",(void*)f_2917},
{"f_2758:c_2dplatform_2escm",(void*)f_2758},
{"f_3685:c_2dplatform_2escm",(void*)f_3685},
{"f_3151:c_2dplatform_2escm",(void*)f_3151},
{"f_3682:c_2dplatform_2escm",(void*)f_3682},
{"f_2740:c_2dplatform_2escm",(void*)f_2740},
{"f_2743:c_2dplatform_2escm",(void*)f_2743},
{"f_3688:c_2dplatform_2escm",(void*)f_3688},
{"f_3157:c_2dplatform_2escm",(void*)f_3157},
{"f_2902:c_2dplatform_2escm",(void*)f_2902},
{"f_3040:c_2dplatform_2escm",(void*)f_3040},
{"f_3154:c_2dplatform_2escm",(void*)f_3154},
{"f_2905:c_2dplatform_2escm",(void*)f_2905},
{"f_3043:c_2dplatform_2escm",(void*)f_3043},
{"f_2908:c_2dplatform_2escm",(void*)f_2908},
{"f_3046:c_2dplatform_2escm",(void*)f_3046},
{"f_3049:c_2dplatform_2escm",(void*)f_3049},
{"f_2746:c_2dplatform_2escm",(void*)f_2746},
{"f_2749:c_2dplatform_2escm",(void*)f_2749},
{"f_3517:c_2dplatform_2escm",(void*)f_3517},
{"f_3514:c_2dplatform_2escm",(void*)f_3514},
{"f_3511:c_2dplatform_2escm",(void*)f_3511},
{"f_3694:c_2dplatform_2escm",(void*)f_3694},
{"f_3691:c_2dplatform_2escm",(void*)f_3691},
{"f_3142:c_2dplatform_2escm",(void*)f_3142},
{"f_3412:c_2dplatform_2escm",(void*)f_3412},
{"f_2731:c_2dplatform_2escm",(void*)f_2731},
{"f_3415:c_2dplatform_2escm",(void*)f_3415},
{"f_2734:c_2dplatform_2escm",(void*)f_2734},
{"f_3418:c_2dplatform_2escm",(void*)f_3418},
{"f_3697:c_2dplatform_2escm",(void*)f_3697},
{"f_3148:c_2dplatform_2escm",(void*)f_3148},
{"f_3145:c_2dplatform_2escm",(void*)f_3145},
{"f_3031:c_2dplatform_2escm",(void*)f_3031},
{"f_3034:c_2dplatform_2escm",(void*)f_3034},
{"f_3037:c_2dplatform_2escm",(void*)f_3037},
{"f_2737:c_2dplatform_2escm",(void*)f_2737},
{"f_3945:c_2dplatform_2escm",(void*)f_3945},
{"f_3505:c_2dplatform_2escm",(void*)f_3505},
{"f_3508:c_2dplatform_2escm",(void*)f_3508},
{"f_3502:c_2dplatform_2escm",(void*)f_3502},
{"f_4703:c_2dplatform_2escm",(void*)f_4703},
{"f_3130:c_2dplatform_2escm",(void*)f_3130},
{"f_5050:c_2dplatform_2escm",(void*)f_5050},
{"f_3139:c_2dplatform_2escm",(void*)f_3139},
{"f_3133:c_2dplatform_2escm",(void*)f_3133},
{"f_3136:c_2dplatform_2escm",(void*)f_3136},
{"f_1999:c_2dplatform_2escm",(void*)f_1999},
{"f_1993:c_2dplatform_2escm",(void*)f_1993},
{"f_5089:c_2dplatform_2escm",(void*)f_5089},
{"f_3121:c_2dplatform_2escm",(void*)f_3121},
{"f_3127:c_2dplatform_2escm",(void*)f_3127},
{"f_3124:c_2dplatform_2escm",(void*)f_3124},
{"f_3924:c_2dplatform_2escm",(void*)f_3924},
{"f_3926:c_2dplatform_2escm",(void*)f_3926},
{"f_3565:c_2dplatform_2escm",(void*)f_3565},
{"f_3921:c_2dplatform_2escm",(void*)f_3921},
{"f_3562:c_2dplatform_2escm",(void*)f_3562},
{"f_3568:c_2dplatform_2escm",(void*)f_3568},
{"f_5338:c_2dplatform_2escm",(void*)f_5338},
{"f_3112:c_2dplatform_2escm",(void*)f_3112},
{"f_3115:c_2dplatform_2escm",(void*)f_3115},
{"f_3118:c_2dplatform_2escm",(void*)f_3118},
{"f_2300:c_2dplatform_2escm",(void*)f_2300},
{"f_4113:c_2dplatform_2escm",(void*)f_4113},
{"f_4110:c_2dplatform_2escm",(void*)f_4110},
{"f_4116:c_2dplatform_2escm",(void*)f_4116},
{"f_3915:c_2dplatform_2escm",(void*)f_3915},
{"f_4119:c_2dplatform_2escm",(void*)f_4119},
{"f_3918:c_2dplatform_2escm",(void*)f_3918},
{"f_4738:c_2dplatform_2escm",(void*)f_4738},
{"f_3103:c_2dplatform_2escm",(void*)f_3103},
{"f_3100:c_2dplatform_2escm",(void*)f_3100},
{"f_3106:c_2dplatform_2escm",(void*)f_3106},
{"f_3109:c_2dplatform_2escm",(void*)f_3109},
{"f_3727:c_2dplatform_2escm",(void*)f_3727},
{"f_3721:c_2dplatform_2escm",(void*)f_3721},
{"f_3724:c_2dplatform_2escm",(void*)f_3724},
{"f_2015:c_2dplatform_2escm",(void*)f_2015},
{"f_2013:c_2dplatform_2escm",(void*)f_2013},
{"f_2351:c_2dplatform_2escm",(void*)f_2351},
{"f_2354:c_2dplatform_2escm",(void*)f_2354},
{"f_5688:c_2dplatform_2escm",(void*)f_5688},
{"f_3715:c_2dplatform_2escm",(void*)f_3715},
{"f_3718:c_2dplatform_2escm",(void*)f_3718},
{"f_3529:c_2dplatform_2escm",(void*)f_3529},
{"f_3712:c_2dplatform_2escm",(void*)f_3712},
{"f_3526:c_2dplatform_2escm",(void*)f_3526},
{"f_3523:c_2dplatform_2escm",(void*)f_3523},
{"f_2358:c_2dplatform_2escm",(void*)f_2358},
{"f_2357:c_2dplatform_2escm",(void*)f_2357},
{"f_3520:c_2dplatform_2escm",(void*)f_3520},
{"f_2698:c_2dplatform_2escm",(void*)f_2698},
{"f_2695:c_2dplatform_2escm",(void*)f_2695},
{"f_2342:c_2dplatform_2escm",(void*)f_2342},
{"f_2692:c_2dplatform_2escm",(void*)f_2692},
{"f_5417:c_2dplatform_2escm",(void*)f_5417},
{"f_5415:c_2dplatform_2escm",(void*)f_5415},
{"f_3709:c_2dplatform_2escm",(void*)f_3709},
{"f_3706:c_2dplatform_2escm",(void*)f_3706},
{"f_3703:c_2dplatform_2escm",(void*)f_3703},
{"f_2345:c_2dplatform_2escm",(void*)f_2345},
{"f_3700:c_2dplatform_2escm",(void*)f_3700},
{"f_2348:c_2dplatform_2escm",(void*)f_2348},
{"f_2689:c_2dplatform_2escm",(void*)f_2689},
{"f_2683:c_2dplatform_2escm",(void*)f_2683},
{"f_2686:c_2dplatform_2escm",(void*)f_2686},
{"f_2330:c_2dplatform_2escm",(void*)f_2330},
{"f_2333:c_2dplatform_2escm",(void*)f_2333},
{"f_2680:c_2dplatform_2escm",(void*)f_2680},
{"f_2339:c_2dplatform_2escm",(void*)f_2339},
{"f_2336:c_2dplatform_2escm",(void*)f_2336},
{"f_2677:c_2dplatform_2escm",(void*)f_2677},
{"f_2674:c_2dplatform_2escm",(void*)f_2674},
{"f_2671:c_2dplatform_2escm",(void*)f_2671},
{"f_3763:c_2dplatform_2escm",(void*)f_3763},
{"f_3766:c_2dplatform_2escm",(void*)f_3766},
{"f_3769:c_2dplatform_2escm",(void*)f_3769},
{"f_3760:c_2dplatform_2escm",(void*)f_3760},
{"f_2394:c_2dplatform_2escm",(void*)f_2394},
{"f_3754:c_2dplatform_2escm",(void*)f_3754},
{"f_3757:c_2dplatform_2escm",(void*)f_3757},
{"f_2392:c_2dplatform_2escm",(void*)f_2392},
{"f_3751:c_2dplatform_2escm",(void*)f_3751},
{"f_2389:c_2dplatform_2escm",(void*)f_2389},
{"f_5678:c_2dplatform_2escm",(void*)f_5678},
{"f_3745:c_2dplatform_2escm",(void*)f_3745},
{"f_3742:c_2dplatform_2escm",(void*)f_3742},
{"f_3748:c_2dplatform_2escm",(void*)f_3748},
{"f_3733:c_2dplatform_2escm",(void*)f_3733},
{"f_3739:c_2dplatform_2escm",(void*)f_3739},
{"f_3736:c_2dplatform_2escm",(void*)f_3736},
{"f_3730:c_2dplatform_2escm",(void*)f_3730},
{"f_1651:c_2dplatform_2escm",(void*)f_1651},
{"f_1958:c_2dplatform_2escm",(void*)f_1958},
{"f_1955:c_2dplatform_2escm",(void*)f_1955},
{"f_1952:c_2dplatform_2escm",(void*)f_1952},
{"f_2629:c_2dplatform_2escm",(void*)f_2629},
{"f_2626:c_2dplatform_2escm",(void*)f_2626},
{"f_1660:c_2dplatform_2escm",(void*)f_1660},
{"f_2623:c_2dplatform_2escm",(void*)f_2623},
{"f_4419:c_2dplatform_2escm",(void*)f_4419},
{"f_1960:c_2dplatform_2escm",(void*)f_1960},
{"f_3962:c_2dplatform_2escm",(void*)f_3962},
{"f_2620:c_2dplatform_2escm",(void*)f_2620},
{"f_1654:c_2dplatform_2escm",(void*)f_1654},
{"f_1657:c_2dplatform_2escm",(void*)f_1657},
{"f_2617:c_2dplatform_2escm",(void*)f_2617},
{"f_2614:c_2dplatform_2escm",(void*)f_2614},
{"f_1970:c_2dplatform_2escm",(void*)f_1970},
{"f_2611:c_2dplatform_2escm",(void*)f_2611},
{"f_1663:c_2dplatform_2escm",(void*)f_1663},
{"f_1668:c_2dplatform_2escm",(void*)f_1668},
{"f_1666:c_2dplatform_2escm",(void*)f_1666},
{"f_2536:c_2dplatform_2escm",(void*)f_2536},
{"f_2797:c_2dplatform_2escm",(void*)f_2797},
{"f_2794:c_2dplatform_2escm",(void*)f_2794},
{"f_3052:c_2dplatform_2escm",(void*)f_3052},
{"f_2791:c_2dplatform_2escm",(void*)f_2791},
{"f_3058:c_2dplatform_2escm",(void*)f_3058},
{"f_3055:c_2dplatform_2escm",(void*)f_3055},
{"f_2788:c_2dplatform_2escm",(void*)f_2788},
{"f_2785:c_2dplatform_2escm",(void*)f_2785},
{"f_3064:c_2dplatform_2escm",(void*)f_3064},
{"f_3061:c_2dplatform_2escm",(void*)f_3061},
{"f_2782:c_2dplatform_2escm",(void*)f_2782},
{"f_3067:c_2dplatform_2escm",(void*)f_3067},
{"f_2540:c_2dplatform_2escm",(void*)f_2540},
{"f_2779:c_2dplatform_2escm",(void*)f_2779},
{"f_2773:c_2dplatform_2escm",(void*)f_2773},
{"f_2776:c_2dplatform_2escm",(void*)f_2776},
{"f_3073:c_2dplatform_2escm",(void*)f_3073},
{"f_3070:c_2dplatform_2escm",(void*)f_3070},
{"f_2770:c_2dplatform_2escm",(void*)f_2770},
{"f_3079:c_2dplatform_2escm",(void*)f_3079},
{"f_3076:c_2dplatform_2escm",(void*)f_3076},
{"f_2890:c_2dplatform_2escm",(void*)f_2890},
{"f_3082:c_2dplatform_2escm",(void*)f_3082},
{"f_3085:c_2dplatform_2escm",(void*)f_3085},
{"f_3088:c_2dplatform_2escm",(void*)f_3088},
{"f_2881:c_2dplatform_2escm",(void*)f_2881},
{"f_3091:c_2dplatform_2escm",(void*)f_3091},
{"f_3094:c_2dplatform_2escm",(void*)f_3094},
{"f_2893:c_2dplatform_2escm",(void*)f_2893},
{"f_2896:c_2dplatform_2escm",(void*)f_2896},
{"f_2899:c_2dplatform_2escm",(void*)f_2899},
{"f_3097:c_2dplatform_2escm",(void*)f_3097},
{"f_2884:c_2dplatform_2escm",(void*)f_2884},
{"f_2887:c_2dplatform_2escm",(void*)f_2887},
{"f_5159:c_2dplatform_2escm",(void*)f_5159},
{"f_2722:c_2dplatform_2escm",(void*)f_2722},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  map		1
S|  for-each		1
o|eliminated procedure checks: 59 
o|specializations:
o|  2 (eqv? (not float) *)
o|  1 (memq * list)
o|  17 (= fixnum fixnum)
o|  3 (>= fixnum fixnum)
o|  3 (cdr pair)
o|  2 (car pair)
o|  6 (first pair)
o|  1 (##sys#check-list (or pair list) *)
o|safe globals: (##compiler#non-foldable-bindings ##compiler#internal-bindings ##compiler#default-extended-bindings ##compiler#default-standard-bindings ##compiler#valid-compiler-options-with-argument ##compiler#valid-compiler-options ##compiler#target-include-file ##compiler#membership-unfold-limit ##compiler#membership-test-operators ##compiler#eq-inline-operator ##compiler#unlikely-variables small-parameter-limit ##compiler#parameter-limit ##compiler#words-per-flonum ##compiler#units-used-by-default ##compiler#default-profiling-declarations ##compiler#default-debugging-declarations ##compiler#default-declarations ##compiler#default-optimization-passes) 
o|Removed `not' forms: 3 
o|inlining procedure: k1672 
o|contracted procedure: "(c-platform.scm:371) g260261" 
o|inlining procedure: k1695 
o|contracted procedure: "(c-platform.scm:376) g265266" 
o|inlining procedure: k1714 
o|inlining procedure: k1714 
o|inlining procedure: k1695 
o|contracted procedure: "(c-platform.scm:377) g270271" 
o|inlining procedure: k1672 
o|substituted constant variable: a1745 
o|inlining procedure: k1755 
o|inlining procedure: k1773 
o|contracted procedure: "(c-platform.scm:398) g326327" 
o|contracted procedure: "(c-platform.scm:400) g331332" 
o|inlining procedure: k1773 
o|inlining procedure: k1807 
o|contracted procedure: "(c-platform.scm:397) g323324" 
o|inlining procedure: k1807 
o|contracted procedure: "(c-platform.scm:396) g320321" 
o|contracted procedure: "(c-platform.scm:395) g316317" 
o|contracted procedure: "(c-platform.scm:394) g313314" 
o|inlining procedure: k1877 
o|contracted procedure: "(c-platform.scm:393) g303304" 
o|contracted procedure: "(c-platform.scm:392) g300301" 
o|contracted procedure: "(c-platform.scm:392) g297298" 
o|inlining procedure: k1877 
o|contracted procedure: "(c-platform.scm:391) g293294" 
o|contracted procedure: "(c-platform.scm:390) g289290" 
o|inlining procedure: k1755 
o|substituted constant variable: a1949 
o|inlining procedure: k1962 
o|contracted procedure: "(c-platform.scm:440) g428429" 
o|inlining procedure: k2017 
o|inlining procedure: k2017 
o|contracted procedure: "(c-platform.scm:444) g452453" 
o|inlining procedure: k2065 
o|inlining procedure: k2065 
o|contracted procedure: "(c-platform.scm:455) g489490" 
o|contracted procedure: "(c-platform.scm:457) g494495" 
o|inlining procedure: k2096 
o|substituted constant variable: a2109 
o|inlining procedure: k2110 
o|contracted procedure: "(c-platform.scm:450) g479480" 
o|contracted procedure: "(c-platform.scm:452) g484485" 
o|inlining procedure: k2110 
o|contracted procedure: "(c-platform.scm:449) g476477" 
o|contracted procedure: "(c-platform.scm:447) g471472" 
o|inlining procedure: k2096 
o|substituted constant variable: a2159 
o|contracted procedure: "(c-platform.scm:445) g466467" 
o|contracted procedure: "(c-platform.scm:439) g425426" 
o|inlining procedure: k1962 
o|inlining procedure: k2197 
o|contracted procedure: "(c-platform.scm:474) g513514" 
o|inlining procedure: k2229 
o|contracted procedure: "(c-platform.scm:480) g529530" 
o|inlining procedure: k2229 
o|contracted procedure: "(c-platform.scm:486) g535536" 
o|inlining procedure: k2273 
o|contracted procedure: "(c-platform.scm:487) g540541" 
o|inlining procedure: k2273 
o|contracted procedure: "(c-platform.scm:479) g526527" 
o|contracted procedure: "(c-platform.scm:478) g523524" 
o|inlining procedure: k2197 
o|substituted constant variable: a2327 
o|inlining procedure: k2360 
o|contracted procedure: "(c-platform.scm:505) g561562" 
o|inlining procedure: k2360 
o|substituted constant variable: a2386 
o|inlining procedure: k2396 
o|inlining procedure: k2414 
o|inlining procedure: k2429 
o|inlining procedure: k2441 
o|contracted procedure: "(c-platform.scm:527) g603604" 
o|contracted procedure: "(c-platform.scm:535) g618619" 
o|contracted procedure: "(c-platform.scm:529) g608609" 
o|contracted procedure: "(c-platform.scm:532) g613614" 
o|contracted procedure: "(c-platform.scm:526) g600601" 
o|substituted constant variable: a2554 
o|inlining procedure: k2441 
o|contracted procedure: "(c-platform.scm:521) g593594" 
o|contracted procedure: "(c-platform.scm:520) g589590" 
o|inlining procedure: k2429 
o|contracted procedure: "(c-platform.scm:518) g584585" 
o|inlining procedure: k2414 
o|contracted procedure: "(c-platform.scm:517) g580581" 
o|contracted procedure: "(c-platform.scm:516) g576577" 
o|inlining procedure: k2396 
o|substituted constant variable: a2604 
o|inlining procedure: k3785 
o|inlining procedure: k3804 
o|contracted procedure: "(c-platform.scm:1050) g740741" 
o|contracted procedure: "(c-platform.scm:1054) g745746" 
o|contracted procedure: "(c-platform.scm:1057) g750751" 
o|contracted procedure: "(c-platform.scm:1049) g735736" 
o|inlining procedure: k3804 
o|contracted procedure: "(c-platform.scm:1044) g729730" 
o|contracted procedure: "(c-platform.scm:1042) g724725" 
o|inlining procedure: k3785 
o|inlining procedure: k3928 
o|inlining procedure: k3946 
o|inlining procedure: k3964 
o|contracted procedure: k3976 
o|contracted procedure: k3982 
o|inlining procedure: k3979 
o|inlining procedure: k3979 
o|contracted procedure: k3988 
o|contracted procedure: "(c-platform.scm:1084) g791792" 
o|inlining procedure: k3964 
o|contracted procedure: "(c-platform.scm:1075) g777778" 
o|contracted procedure: "(c-platform.scm:1074) g773774" 
o|inlining procedure: k3946 
o|contracted procedure: "(c-platform.scm:1073) g770771" 
o|contracted procedure: "(c-platform.scm:1072) g766767" 
o|inlining procedure: k3928 
o|substituted constant variable: a4066 
o|inlining procedure: k4141 
o|contracted procedure: "(c-platform.scm:1197) g887888" 
o|contracted procedure: "(c-platform.scm:1201) g892893" 
o|contracted procedure: "(c-platform.scm:1204) g897898" 
o|inlining procedure: k4141 
o|substituted constant variable: a4208 
o|inlining procedure: k4216 
o|contracted procedure: "(c-platform.scm:1180) g866867" 
o|contracted procedure: "(c-platform.scm:1183) g871872" 
o|contracted procedure: "(c-platform.scm:1186) g876877" 
o|inlining procedure: k4216 
o|substituted constant variable: a4276 
o|inlining procedure: k4284 
o|contracted procedure: "(c-platform.scm:1157) g851852" 
o|contracted procedure: "(c-platform.scm:1160) g856857" 
o|inlining procedure: k4320 
o|inlining procedure: k4320 
o|inlining procedure: k4284 
o|substituted constant variable: a4326 
o|inlining procedure: k4334 
o|contracted procedure: "(c-platform.scm:1143) g829830" 
o|inlining procedure: k4360 
o|inlining procedure: k4360 
o|contracted procedure: "(c-platform.scm:1149) g841842" 
o|contracted procedure: "(c-platform.scm:1147) g838839" 
o|contracted procedure: "(c-platform.scm:1146) g835836" 
o|inlining procedure: k4334 
o|substituted constant variable: a4413 
o|inlining procedure: k4421 
o|inlining procedure: k4439 
o|contracted procedure: "(c-platform.scm:1127) g818819" 
o|substituted constant variable: setter-map 
o|inlining procedure: k4439 
o|contracted procedure: "(c-platform.scm:1125) g814815" 
o|contracted procedure: "(c-platform.scm:1124) g810811" 
o|contracted procedure: "(c-platform.scm:1123) g806807" 
o|inlining procedure: k4421 
o|substituted constant variable: a4498 
o|inlining procedure: k4506 
o|contracted procedure: "(c-platform.scm:941) g679680" 
o|inlining procedure: k4535 
o|inlining procedure: k4535 
o|contracted procedure: "(c-platform.scm:956) g705706" 
o|contracted procedure: "(c-platform.scm:957) g710711" 
o|inlining procedure: k4567 
o|inlining procedure: k4579 
o|contracted procedure: "(c-platform.scm:949) g695696" 
o|contracted procedure: "(c-platform.scm:952) g700701" 
o|inlining procedure: k4579 
o|contracted procedure: "(c-platform.scm:946) g691692" 
o|inlining procedure: k4567 
o|contracted procedure: "(c-platform.scm:944) g687688" 
o|inlining procedure: k4506 
o|substituted constant variable: a4655 
o|inlining procedure: k4663 
o|contracted procedure: "(c-platform.scm:909) g655656" 
o|contracted procedure: "(c-platform.scm:912) g660661" 
o|inlining procedure: k4701 
o|contracted procedure: "(c-platform.scm:916) g670671" 
o|inlining procedure: k4701 
o|contracted procedure: "(c-platform.scm:915) g667668" 
o|inlining procedure: k4663 
o|substituted constant variable: a4736 
o|contracted procedure: "(c-platform.scm:861) g638639" 
o|contracted procedure: "(c-platform.scm:864) g643644" 
o|inlining procedure: k4775 
o|inlining procedure: k4775 
o|substituted constant variable: a4810 
o|substituted constant variable: a4812 
o|inlining procedure: k4816 
o|inlining procedure: k4837 
o|inlining procedure: k4837 
o|contracted procedure: "(c-platform.scm:426) g407408" 
o|contracted procedure: "(c-platform.scm:428) g412413" 
o|contracted procedure: "(c-platform.scm:423) g397398" 
o|contracted procedure: "(c-platform.scm:425) g402403" 
o|inlining procedure: k4896 
o|contracted procedure: "(c-platform.scm:421) g391392" 
o|inlining procedure: k4896 
o|contracted procedure: "(c-platform.scm:420) g387388" 
o|inlining procedure: k4941 
o|inlining procedure: k4941 
o|contracted procedure: "(c-platform.scm:418) g380381" 
o|contracted procedure: "(c-platform.scm:417) g376377" 
o|inlining procedure: k4968 
o|contracted procedure: "(c-platform.scm:416) g363364" 
o|contracted procedure: "(c-platform.scm:415) g360361" 
o|contracted procedure: "(c-platform.scm:415) g357358" 
o|inlining procedure: k4968 
o|contracted procedure: "(c-platform.scm:414) g353354" 
o|contracted procedure: "(c-platform.scm:413) g349350" 
o|inlining procedure: k4816 
o|substituted constant variable: a5040 
o|inlining procedure: k5052 
o|contracted procedure: "(c-platform.scm:348) g218219" 
o|inlining procedure: k5084 
o|contracted procedure: "(c-platform.scm:354) g231232" 
o|inlining procedure: k5084 
o|contracted procedure: "(c-platform.scm:357) g236237" 
o|contracted procedure: "(c-platform.scm:353) g228229" 
o|contracted procedure: "(c-platform.scm:352) g225226" 
o|contracted procedure: "(c-platform.scm:358) g241242" 
o|contracted procedure: "(c-platform.scm:360) g246247" 
o|inlining procedure: k5052 
o|substituted constant variable: a5173 
o|inlining procedure: k5177 
o|inlining procedure: k5192 
o|contracted procedure: "(c-platform.scm:329) g189190" 
o|inlining procedure: k5221 
o|contracted procedure: "(c-platform.scm:336) g203204" 
o|inlining procedure: k5221 
o|contracted procedure: "(c-platform.scm:337) g208209" 
o|contracted procedure: "(c-platform.scm:335) g200201" 
o|contracted procedure: "(c-platform.scm:335) g197198" 
o|inlining procedure: k5192 
o|substituted constant variable: a5287 
o|inlining procedure: k5299 
o|contracted procedure: "(c-platform.scm:325) g184185" 
o|inlining procedure: k5299 
o|contracted procedure: "(c-platform.scm:324) g181182" 
o|inlining procedure: k5177 
o|substituted constant variable: a5336 
o|inlining procedure: k5340 
o|inlining procedure: k5340 
o|contracted procedure: "(c-platform.scm:286) g140141" 
o|contracted procedure: "(c-platform.scm:289) g145146" 
o|inlining procedure: k5384 
o|contracted procedure: "(c-platform.scm:302) g161162" 
o|contracted procedure: "(c-platform.scm:308) g168169" 
o|substituted constant variable: a5439 
o|inlining procedure: k5384 
o|inlining procedure: k5449 
o|contracted procedure: "(c-platform.scm:298) g156157" 
o|inlining procedure: k5449 
o|contracted procedure: "(c-platform.scm:297) g153154" 
o|inlining procedure: k5498 
o|contracted procedure: "(c-platform.scm:259) g9798" 
o|inlining procedure: k5498 
o|contracted procedure: "(c-platform.scm:261) g102103" 
o|inlining procedure: k5548 
o|contracted procedure: "(c-platform.scm:263) g107108" 
o|inlining procedure: k5577 
o|contracted procedure: "(c-platform.scm:270) g121122" 
o|inlining procedure: k5577 
o|contracted procedure: "(c-platform.scm:271) g126127" 
o|contracted procedure: "(c-platform.scm:269) g118119" 
o|contracted procedure: "(c-platform.scm:269) g115116" 
o|inlining procedure: k5548 
o|inlining procedure: k5646 
o|contracted procedure: "(c-platform.scm:257) g9091" 
o|inlining procedure: k5646 
o|contracted procedure: "(c-platform.scm:256) g8788" 
o|inlining procedure: k5680 
o|contracted procedure: "(c-platform.scm:229) g4552" 
o|contracted procedure: "(c-platform.scm:230) g6061" 
o|inlining procedure: k5680 
o|simplifications: ((if . 1)) 
o|replaced variables: 533 
o|removed binding forms: 611 
o|substituted constant variable: c262 
o|substituted constant variable: c267 
o|substituted constant variable: c272 
o|substituted constant variable: r16735713 
o|substituted constant variable: c328 
o|substituted constant variable: c333 
o|substituted constant variable: p334 
o|substituted constant variable: r17745716 
o|substituted constant variable: r18085718 
o|substituted constant variable: c305 
o|substituted constant variable: r18785720 
o|substituted constant variable: r17565721 
o|substituted constant variable: c430 
o|substituted constant variable: c491 
o|substituted constant variable: c496 
o|substituted constant variable: p497 
o|substituted constant variable: s498 
o|substituted constant variable: c481 
o|substituted constant variable: c486 
o|substituted constant variable: p487 
o|substituted constant variable: s488 
o|substituted constant variable: r21115729 
o|substituted constant variable: r20975731 
o|substituted constant variable: r19635732 
o|substituted constant variable: c515 
o|substituted constant variable: c531 
o|substituted constant variable: c537 
o|substituted constant variable: c542 
o|substituted constant variable: r21985740 
o|substituted constant variable: c563 
o|substituted constant variable: r23615742 
o|substituted constant variable: c605 
o|substituted constant variable: c620 
o|substituted constant variable: c610 
o|substituted constant variable: c615 
o|substituted constant variable: r24425747 
o|substituted constant variable: r24305748 
o|substituted constant variable: r24155749 
o|substituted constant variable: r23975750 
o|substituted constant variable: c742 
o|substituted constant variable: c747 
o|substituted constant variable: c752 
o|substituted constant variable: c737 
o|substituted constant variable: p738 
o|substituted constant variable: s739 
o|substituted constant variable: r38055753 
o|substituted constant variable: r37865754 
o|substituted constant variable: r39805758 
o|substituted constant variable: c793 
o|substituted constant variable: r39655760 
o|substituted constant variable: r39475761 
o|substituted constant variable: r39295762 
o|removed side-effect free assignment to unused variable: setter-map 
o|substituted constant variable: c889 
o|substituted constant variable: c894 
o|substituted constant variable: c899 
o|substituted constant variable: p900 
o|substituted constant variable: r41425764 
o|substituted constant variable: c868 
o|substituted constant variable: c873 
o|substituted constant variable: p874 
o|substituted constant variable: c878 
o|substituted constant variable: p879 
o|substituted constant variable: r42175766 
o|substituted constant variable: c853 
o|substituted constant variable: c858 
o|substituted constant variable: r43215768 
o|substituted constant variable: r43215768 
o|substituted constant variable: r43215770 
o|substituted constant variable: r43215770 
o|substituted constant variable: r42855772 
o|substituted constant variable: c831 
o|substituted constant variable: c843 
o|substituted constant variable: p844 
o|substituted constant variable: r43355778 
o|substituted constant variable: c820 
o|substituted constant variable: r44405781 
o|substituted constant variable: r44225782 
o|converted assignments to bindings: (rewrite-call/cc758) 
o|converted assignments to bindings: (rewrite-make-vector715) 
o|substituted constant variable: c681 
o|substituted constant variable: c707 
o|substituted constant variable: p708 
o|substituted constant variable: c712 
o|substituted constant variable: c697 
o|substituted constant variable: p698 
o|substituted constant variable: c702 
o|substituted constant variable: p703 
o|substituted constant variable: r45805790 
o|substituted constant variable: r45685791 
o|substituted constant variable: r45075792 
o|substituted constant variable: c657 
o|substituted constant variable: c662 
o|substituted constant variable: r47025795 
o|substituted constant variable: r46645796 
o|substituted constant variable: c640 
o|substituted constant variable: c645 
o|substituted constant variable: p646 
o|converted assignments to bindings: (build635) 
o|converted assignments to bindings: (rewrite-c-w-v567) 
o|converted assignments to bindings: (rewrite-c..r501) 
o|converted assignments to bindings: (rewrite-apply417) 
o|substituted constant variable: c409 
o|substituted constant variable: c414 
o|substituted constant variable: p415 
o|substituted constant variable: c399 
o|substituted constant variable: c404 
o|substituted constant variable: p405 
o|substituted constant variable: r48975803 
o|substituted constant variable: c365 
o|substituted constant variable: r49695807 
o|substituted constant variable: r48175808 
o|converted assignments to bindings: (eqv?-id277) 
o|converted assignments to bindings: (op1251) 
o|substituted constant variable: c220 
o|substituted constant variable: c233 
o|substituted constant variable: p234 
o|substituted constant variable: c238 
o|substituted constant variable: p239 
o|substituted constant variable: c243 
o|substituted constant variable: c248 
o|substituted constant variable: p249 
o|substituted constant variable: s250 
o|substituted constant variable: r50535814 
o|substituted constant variable: c191 
o|substituted constant variable: c205 
o|substituted constant variable: p206 
o|substituted constant variable: c210 
o|substituted constant variable: p211 
o|substituted constant variable: r51935819 
o|substituted constant variable: r53005821 
o|substituted constant variable: r51785822 
o|substituted constant variable: r53415823 
o|substituted constant variable: c142 
o|substituted constant variable: c147 
o|substituted constant variable: c163 
o|substituted constant variable: c170 
o|substituted constant variable: r53855826 
o|substituted constant variable: r54505828 
o|substituted constant variable: c99 
o|substituted constant variable: c104 
o|substituted constant variable: c109 
o|substituted constant variable: c123 
o|substituted constant variable: p124 
o|substituted constant variable: c128 
o|substituted constant variable: p129 
o|substituted constant variable: r55495834 
o|substituted constant variable: r56475836 
o|substituted constant variable: mark68 
o|substituted constant variable: g5153 
o|simplifications: ((let . 8)) 
o|replaced variables: 87 
o|removed binding forms: 536 
o|removed conditional forms: 1 
o|inlining procedure: k4698 
o|inlining procedure: k4698 
o|inlining procedure: k4698 
o|inlining procedure: k5378 
o|inlining procedure: k5378 
o|inlining procedure: k1634 
o|replaced variables: 155 
o|removed binding forms: 229 
o|substituted constant variable: r46995853 
o|substituted constant variable: r46995853 
o|substituted constant variable: r46995858 
o|substituted constant variable: r46995858 
o|substituted constant variable: r46995863 
o|substituted constant variable: r46995863 
o|substituted constant variable: r53795868 
o|substituted constant variable: r53795868 
o|substituted constant variable: r53795873 
o|substituted constant variable: r53795873 
o|substituted constant variable: r16355878 
o|replaced variables: 5 
o|removed binding forms: 158 
o|removed binding forms: 16 
o|simplifications: ((if . 8) (##core#call . 395)) 
o|  call simplifications:
o|    null?	5
o|    zero?
o|    fx>=	3
o|    symbol?	2
o|    negative?
o|    -
o|    assq
o|    =
o|    fixnum?	2
o|    <=
o|    add1
o|    third	4
o|    proper-list?
o|    cadr	2
o|    cdr	4
o|    ##sys#check-list
o|    pair?	5
o|    cons	4
o|    ##sys#setslot
o|    second	9
o|    equal?	2
o|    ##sys#slot	58
o|    first	24
o|    flonum?	2
o|    not	4
o|    length	22
o|    eq?	61
o|    car	10
o|    list	92
o|    ##sys#make-structure	70
o|contracted procedure: k1742 
o|contracted procedure: k1675 
o|contracted procedure: k1687 
o|contracted procedure: k1691 
o|contracted procedure: k1698 
o|inlining procedure: k1710 
o|inlining procedure: k1710 
o|contracted procedure: k1726 
o|contracted procedure: k1734 
o|contracted procedure: k1730 
o|contracted procedure: k1946 
o|contracted procedure: k1758 
o|contracted procedure: k1761 
o|contracted procedure: k1764 
o|contracted procedure: k1791 
o|contracted procedure: k1804 
o|contracted procedure: k1795 
o|contracted procedure: k1839 
o|contracted procedure: k1810 
o|contracted procedure: k1830 
o|contracted procedure: k1821 
o|contracted procedure: k1817 
o|contracted procedure: k1871 
o|contracted procedure: k1842 
o|contracted procedure: k1862 
o|contracted procedure: k1853 
o|contracted procedure: k1849 
o|contracted procedure: k1942 
o|contracted procedure: k1874 
o|contracted procedure: k1933 
o|contracted procedure: k1880 
o|contracted procedure: k1915 
o|contracted procedure: k1924 
o|contracted procedure: k1886 
o|contracted procedure: k1898 
o|contracted procedure: k1902 
o|contracted procedure: k1965 
o|contracted procedure: k2179 
o|contracted procedure: k1975 
o|contracted procedure: k1987 
o|contracted procedure: k2001 
o|contracted procedure: k2055 
o|contracted procedure: k2005 
o|contracted procedure: k2008 
o|contracted procedure: k2020 
o|contracted procedure: k2023 
o|contracted procedure: k2034 
o|contracted procedure: k2046 
o|contracted procedure: k2077 
o|contracted procedure: k2090 
o|contracted procedure: k2170 
o|contracted procedure: k2093 
o|contracted procedure: k2161 
o|contracted procedure: k2099 
o|contracted procedure: k2156 
o|contracted procedure: k2102 
o|contracted procedure: k2130 
o|contracted procedure: k2143 
o|contracted procedure: k2147 
o|contracted procedure: k2134 
o|contracted procedure: k2324 
o|contracted procedure: k2200 
o|contracted procedure: k2209 
o|contracted procedure: k2221 
o|contracted procedure: k2225 
o|contracted procedure: k2244 
o|contracted procedure: k2248 
o|contracted procedure: k2258 
o|contracted procedure: k2270 
o|contracted procedure: k2285 
o|contracted procedure: k2320 
o|contracted procedure: k2291 
o|contracted procedure: k2311 
o|contracted procedure: k2302 
o|contracted procedure: k2383 
o|contracted procedure: k2363 
o|contracted procedure: k2375 
o|contracted procedure: k2379 
o|contracted procedure: k2606 
o|contracted procedure: k2399 
o|contracted procedure: k2402 
o|contracted procedure: k2405 
o|contracted procedure: k2601 
o|contracted procedure: k2411 
o|contracted procedure: k2592 
o|contracted procedure: k2417 
o|contracted procedure: k2583 
o|contracted procedure: k2420 
o|contracted procedure: k2574 
o|contracted procedure: k2435 
o|contracted procedure: k2565 
o|contracted procedure: k2438 
o|contracted procedure: k2444 
o|contracted procedure: k2556 
o|contracted procedure: k2450 
o|contracted procedure: k2471 
o|contracted procedure: k2542 
o|contracted procedure: k2509 
o|contracted procedure: k2526 
o|contracted procedure: k2530 
o|contracted procedure: k2522 
o|contracted procedure: k2513 
o|contracted procedure: k2484 
o|contracted procedure: k2497 
o|contracted procedure: k2501 
o|contracted procedure: k2493 
o|contracted procedure: k2475 
o|contracted procedure: k2551 
o|contracted procedure: k3782 
o|contracted procedure: k3788 
o|contracted procedure: k3910 
o|contracted procedure: k3795 
o|contracted procedure: k3901 
o|contracted procedure: k3801 
o|contracted procedure: k3807 
o|contracted procedure: k3879 
o|contracted procedure: k3816 
o|contracted procedure: k3828 
o|contracted procedure: k3845 
o|contracted procedure: k3876 
o|contracted procedure: k3862 
o|contracted procedure: k3858 
o|contracted procedure: k3849 
o|contracted procedure: k3841 
o|contracted procedure: k3832 
o|contracted procedure: k4068 
o|contracted procedure: k3931 
o|contracted procedure: k3934 
o|contracted procedure: k4063 
o|contracted procedure: k3940 
o|contracted procedure: k4041 
o|contracted procedure: k3952 
o|contracted procedure: k4032 
o|contracted procedure: k3955 
o|contracted procedure: k3967 
o|contracted procedure: k3970 
o|contracted procedure: k4000 
o|contracted procedure: k4004 
o|contracted procedure: k4054 
o|contracted procedure: k4045 
o|contracted procedure: k4210 
o|contracted procedure: k4144 
o|contracted procedure: k4159 
o|contracted procedure: k4167 
o|contracted procedure: k4180 
o|contracted procedure: k4201 
o|contracted procedure: k4197 
o|contracted procedure: k4193 
o|contracted procedure: k4184 
o|contracted procedure: k4176 
o|contracted procedure: k4163 
o|contracted procedure: k4278 
o|contracted procedure: k4219 
o|contracted procedure: k4231 
o|contracted procedure: k4269 
o|contracted procedure: k4273 
o|contracted procedure: k4265 
o|contracted procedure: k4257 
o|contracted procedure: k4261 
o|contracted procedure: k4248 
o|contracted procedure: k4244 
o|contracted procedure: k4235 
o|contracted procedure: k4328 
o|contracted procedure: k4287 
o|contracted procedure: k4299 
o|contracted procedure: k4323 
o|contracted procedure: k4316 
o|contracted procedure: k4312 
o|contracted procedure: k4303 
o|contracted procedure: k4415 
o|contracted procedure: k4337 
o|contracted procedure: k4340 
o|contracted procedure: k4352 
o|contracted procedure: k4356 
o|contracted procedure: k4378 
o|contracted procedure: k4410 
o|contracted procedure: k4381 
o|contracted procedure: k4401 
o|contracted procedure: k4392 
o|contracted procedure: k4500 
o|contracted procedure: k4424 
o|contracted procedure: k4427 
o|contracted procedure: k4495 
o|contracted procedure: k4433 
o|contracted procedure: k4486 
o|contracted procedure: k4436 
o|contracted procedure: k4450 
o|contracted procedure: k4465 
o|contracted procedure: k4469 
o|contracted procedure: k4477 
o|contracted procedure: k4657 
o|contracted procedure: k4509 
o|contracted procedure: k4512 
o|contracted procedure: k4524 
o|inlining procedure: k4528 
o|inlining procedure: k4528 
o|contracted procedure: k4541 
o|contracted procedure: k4561 
o|contracted procedure: k4652 
o|contracted procedure: k4564 
o|contracted procedure: k4570 
o|contracted procedure: k4643 
o|contracted procedure: k4573 
o|contracted procedure: k4588 
o|contracted procedure: k4600 
o|contracted procedure: k4622 
o|contracted procedure: k4627 
o|contracted procedure: k4733 
o|contracted procedure: k4666 
o|contracted procedure: k4678 
o|contracted procedure: k4682 
o|contracted procedure: k4695 
o|contracted procedure: k4729 
o|contracted procedure: k4704 
o|contracted procedure: k4720 
o|contracted procedure: k4711 
o|contracted procedure: k4752 
o|contracted procedure: k4769 
o|contracted procedure: k4765 
o|contracted procedure: k4756 
o|contracted procedure: k4772 
o|contracted procedure: k4778 
o|contracted procedure: k4785 
o|contracted procedure: k4795 
o|contracted procedure: k4802 
o|contracted procedure: k4806 
o|contracted procedure: k5037 
o|contracted procedure: k4819 
o|contracted procedure: k4822 
o|contracted procedure: k4825 
o|contracted procedure: k4849 
o|contracted procedure: k4862 
o|contracted procedure: k4853 
o|contracted procedure: k4880 
o|contracted procedure: k4893 
o|contracted procedure: k4884 
o|contracted procedure: k4929 
o|contracted procedure: k4899 
o|contracted procedure: k4920 
o|contracted procedure: k4902 
o|contracted procedure: k4962 
o|contracted procedure: k4932 
o|contracted procedure: k4953 
o|contracted procedure: k4935 
o|contracted procedure: k5033 
o|contracted procedure: k4965 
o|contracted procedure: k5024 
o|contracted procedure: k4971 
o|contracted procedure: k5006 
o|contracted procedure: k5015 
o|contracted procedure: k4977 
o|contracted procedure: k4989 
o|contracted procedure: k4993 
o|contracted procedure: k5170 
o|contracted procedure: k5055 
o|contracted procedure: k5061 
o|contracted procedure: k5073 
o|contracted procedure: k5077 
o|contracted procedure: k5080 
o|contracted procedure: k5099 
o|contracted procedure: k5141 
o|contracted procedure: k5116 
o|contracted procedure: k5132 
o|contracted procedure: k5123 
o|contracted procedure: k5153 
o|contracted procedure: k5166 
o|contracted procedure: k5333 
o|contracted procedure: k5180 
o|contracted procedure: k5289 
o|contracted procedure: k5183 
o|contracted procedure: k5189 
o|contracted procedure: k5284 
o|contracted procedure: k5195 
o|contracted procedure: k5207 
o|contracted procedure: k5211 
o|contracted procedure: k5236 
o|contracted procedure: k5252 
o|contracted procedure: k5280 
o|contracted procedure: k5255 
o|contracted procedure: k5271 
o|contracted procedure: k5262 
o|contracted procedure: k5327 
o|contracted procedure: k5302 
o|contracted procedure: k5318 
o|contracted procedure: k5309 
o|contracted procedure: k5343 
o|contracted procedure: k5489 
o|contracted procedure: k5482 
o|contracted procedure: k5349 
o|contracted procedure: k5361 
o|contracted procedure: k5365 
o|contracted procedure: k5381 
o|contracted procedure: k5387 
o|contracted procedure: k5436 
o|contracted procedure: k5393 
o|contracted procedure: k5405 
o|contracted procedure: k5409 
o|contracted procedure: k5428 
o|contracted procedure: k5432 
o|contracted procedure: k5477 
o|contracted procedure: k5452 
o|contracted procedure: k5468 
o|contracted procedure: k5459 
o|contracted procedure: k5501 
o|contracted procedure: k5513 
o|contracted procedure: k5517 
o|contracted procedure: k5640 
o|contracted procedure: k5527 
o|contracted procedure: k5539 
o|contracted procedure: k5543 
o|contracted procedure: k5551 
o|contracted procedure: k5563 
o|contracted procedure: k5567 
o|contracted procedure: k5592 
o|contracted procedure: k5608 
o|contracted procedure: k5636 
o|contracted procedure: k5611 
o|contracted procedure: k5627 
o|contracted procedure: k5618 
o|contracted procedure: k5674 
o|contracted procedure: k5649 
o|contracted procedure: k5665 
o|contracted procedure: k5656 
o|contracted procedure: k5683 
o|contracted procedure: k5693 
o|contracted procedure: k5697 
o|contracted procedure: k1640 
o|contracted procedure: k1634 
o|simplifications: ((let . 19)) 
o|removed binding forms: 324 
o|inlining procedure: k1695 
o|inlining procedure: k1695 
o|inlining procedure: k1695 
o|inlining procedure: k2026 
o|inlining procedure: k2026 
o|inlining procedure: k2229 
o|inlining procedure: k2229 
o|inlining procedure: k2229 
o|inlining procedure: k4360 
o|inlining procedure: k4535 
o|inlining procedure: k4535 
o|inlining procedure: k4691 
o|inlining procedure: k4691 
o|inlining procedure: k4691 
o|inlining procedure: k5084 
o|inlining procedure: k5084 
o|inlining procedure: k5374 
o|inlining procedure: k5374 
o|replaced variables: 56 
o|removed binding forms: 2 
o|removed binding forms: 44 
o|replaced variables: 6 
o|removed binding forms: 2 
o|direct leaf routine/allocation: build635 25 
o|customizable procedures: (for-each-loop4475 k5580 k5224 k5087 op1251 k4828 k4865 k4868 k4834 rewrite-c..r501 k4582 k4532 k4363 k2232 k2062 map-loop435455 k1767 k1776 k1779) 
o|calls to known targets: 61 
o|fast box initializations: 2 
o|dropping unused closure argument: f_2189 
o|dropping unused closure argument: f_1668 
*/
/* end of file */
