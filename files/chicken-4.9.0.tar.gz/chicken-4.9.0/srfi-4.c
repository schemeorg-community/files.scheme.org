/* Generated from srfi-4.scm by the CHICKEN compiler
   http://www.call-cc.org
   2014-06-02 16:37
   Version 4.9.0 (rev 3f195ba)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2014-06-02 on yves (Linux)
   command line: srfi-4.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -explicit-use -no-trace -output-file srfi-4.c
   unit: srfi_2d4
*/

#include "chicken.h"

#define C_copy_subvector(to, from, start_to, start_from, bytes)   \
  (C_memcpy((C_char *)C_data_pointer(to) + C_unfix(start_to), (C_char *)C_data_pointer(from) + C_unfix(start_from), C_unfix(bytes)), \
    C_SCHEME_UNDEFINED)

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[167];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,50),40,35,35,115,121,115,35,99,104,101,99,107,45,101,120,97,99,116,45,105,110,116,101,114,118,97,108,32,110,54,52,32,102,114,111,109,54,53,32,116,111,54,54,32,108,111,99,54,55,41,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,21),40,117,56,118,101,99,116,111,114,45,108,101,110,103,116,104,32,120,55,51,41,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,21),40,115,56,118,101,99,116,111,114,45,108,101,110,103,116,104,32,120,55,54,41,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,22),40,117,49,54,118,101,99,116,111,114,45,108,101,110,103,116,104,32,120,55,57,41,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,22),40,115,49,54,118,101,99,116,111,114,45,108,101,110,103,116,104,32,120,56,50,41,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,22),40,117,51,50,118,101,99,116,111,114,45,108,101,110,103,116,104,32,120,56,53,41,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,22),40,115,51,50,118,101,99,116,111,114,45,108,101,110,103,116,104,32,120,56,56,41,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,22),40,102,51,50,118,101,99,116,111,114,45,108,101,110,103,116,104,32,120,57,49,41,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,22),40,102,54,52,118,101,99,116,111,114,45,108,101,110,103,116,104,32,120,57,52,41,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,27),40,117,56,118,101,99,116,111,114,45,115,101,116,33,32,120,57,55,32,105,57,56,32,121,57,57,41,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,30),40,115,56,118,101,99,116,111,114,45,115,101,116,33,32,120,49,49,53,32,105,49,49,54,32,121,49,49,55,41,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,31),40,117,49,54,118,101,99,116,111,114,45,115,101,116,33,32,120,49,51,50,32,105,49,51,51,32,121,49,51,52,41,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,31),40,115,49,54,118,101,99,116,111,114,45,115,101,116,33,32,120,49,53,48,32,105,49,53,49,32,121,49,53,50,41,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,31),40,117,51,50,118,101,99,116,111,114,45,115,101,116,33,32,120,49,54,55,32,105,49,54,56,32,121,49,54,57,41,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,31),40,115,51,50,118,101,99,116,111,114,45,115,101,116,33,32,120,49,56,57,32,105,49,57,48,32,121,49,57,49,41,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,31),40,102,51,50,118,101,99,116,111,114,45,115,101,116,33,32,120,50,48,55,32,105,50,48,56,32,121,50,48,57,41,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,31),40,102,54,52,118,101,99,116,111,114,45,115,101,116,33,32,120,50,50,52,32,105,50,50,53,32,121,50,50,54,41,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,19),40,101,120,116,45,102,114,101,101,32,98,118,51,54,54,51,54,57,41,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,29),40,97,108,108,111,99,32,108,111,99,51,55,49,32,108,101,110,51,55,50,32,101,120,116,63,51,55,51,41,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,28),40,114,101,108,101,97,115,101,45,110,117,109,98,101,114,45,118,101,99,116,111,114,32,118,51,56,48,41,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,52,48,50,41,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,34),40,109,97,107,101,45,117,56,118,101,99,116,111,114,32,108,101,110,51,56,54,32,46,32,116,109,112,51,56,53,51,56,55,41,0,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,52,51,49,41,0,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,34),40,109,97,107,101,45,115,56,118,101,99,116,111,114,32,108,101,110,52,49,53,32,46,32,116,109,112,52,49,52,52,49,54,41,0,0,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,52,54,48,41,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,35),40,109,97,107,101,45,117,49,54,118,101,99,116,111,114,32,108,101,110,52,52,52,32,46,32,116,109,112,52,52,51,52,52,53,41,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,52,56,57,41,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,35),40,109,97,107,101,45,115,49,54,118,101,99,116,111,114,32,108,101,110,52,55,51,32,46,32,116,109,112,52,55,50,52,55,52,41,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,53,49,56,41,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,35),40,109,97,107,101,45,117,51,50,118,101,99,116,111,114,32,108,101,110,53,48,50,32,46,32,116,109,112,53,48,49,53,48,51,41,0,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,53,52,55,41,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,35),40,109,97,107,101,45,115,51,50,118,101,99,116,111,114,32,108,101,110,53,51,49,32,46,32,116,109,112,53,51,48,53,51,50,41,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,53,55,54,41,0,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,35),40,109,97,107,101,45,102,51,50,118,101,99,116,111,114,32,108,101,110,53,54,48,32,46,32,116,109,112,53,53,57,53,54,49,41,0,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,54,48,54,41,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,35),40,109,97,107,101,45,102,54,52,118,101,99,116,111,114,32,108,101,110,53,57,48,32,46,32,116,109,112,53,56,57,53,57,49,41,0,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,21),40,100,111,108,111,111,112,54,52,48,32,112,54,52,50,32,105,54,52,51,41,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,23),40,108,105,115,116,45,62,117,56,118,101,99,116,111,114,32,108,115,116,54,51,55,41,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,21),40,100,111,108,111,111,112,54,53,51,32,112,54,53,53,32,105,54,53,54,41,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,23),40,108,105,115,116,45,62,115,56,118,101,99,116,111,114,32,108,115,116,54,53,48,41,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,21),40,100,111,108,111,111,112,54,54,54,32,112,54,54,56,32,105,54,54,57,41,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,24),40,108,105,115,116,45,62,117,49,54,118,101,99,116,111,114,32,108,115,116,54,54,51,41};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,21),40,100,111,108,111,111,112,54,55,57,32,112,54,56,49,32,105,54,56,50,41,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,24),40,108,105,115,116,45,62,115,49,54,118,101,99,116,111,114,32,108,115,116,54,55,54,41};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,21),40,100,111,108,111,111,112,54,57,50,32,112,54,57,52,32,105,54,57,53,41,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,24),40,108,105,115,116,45,62,117,51,50,118,101,99,116,111,114,32,108,115,116,54,56,57,41};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,21),40,100,111,108,111,111,112,55,48,53,32,112,55,48,55,32,105,55,48,56,41,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,24),40,108,105,115,116,45,62,115,51,50,118,101,99,116,111,114,32,108,115,116,55,48,50,41};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,21),40,100,111,108,111,111,112,55,49,56,32,112,55,50,48,32,105,55,50,49,41,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,24),40,108,105,115,116,45,62,102,51,50,118,101,99,116,111,114,32,108,115,116,55,49,53,41};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,21),40,100,111,108,111,111,112,55,51,49,32,112,55,51,51,32,105,55,51,52,41,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,24),40,108,105,115,116,45,62,102,54,52,118,101,99,116,111,114,32,108,115,116,55,50,56,41};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,18),40,117,56,118,101,99,116,111,114,32,46,32,120,115,55,52,48,41,0,0,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,18),40,115,56,118,101,99,116,111,114,32,46,32,120,115,55,52,50,41,0,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,19),40,117,49,54,118,101,99,116,111,114,32,46,32,120,115,55,52,52,41,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,19),40,115,49,54,118,101,99,116,111,114,32,46,32,120,115,55,52,54,41,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,19),40,117,51,50,118,101,99,116,111,114,32,46,32,120,115,55,52,56,41,0,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,19),40,115,51,50,118,101,99,116,111,114,32,46,32,120,115,55,53,48,41,0,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,19),40,102,51,50,118,101,99,116,111,114,32,46,32,120,115,55,53,50,41,0,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,19),40,102,54,52,118,101,99,116,111,114,32,46,32,120,115,55,53,52,41,0,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,55,55,53,41,0,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,21),40,117,56,118,101,99,116,111,114,45,62,108,105,115,116,32,118,55,55,50,41,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,55,56,50,41,0,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,21),40,115,56,118,101,99,116,111,114,45,62,108,105,115,116,32,118,55,55,57,41,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,55,56,57,41,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,22),40,117,49,54,118,101,99,116,111,114,45,62,108,105,115,116,32,118,55,56,54,41,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,55,57,54,41,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,22),40,115,49,54,118,101,99,116,111,114,45,62,108,105,115,116,32,118,55,57,51,41,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,56,48,51,41,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,22),40,117,51,50,118,101,99,116,111,114,45,62,108,105,115,116,32,118,56,48,48,41,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,56,49,48,41,0,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,22),40,115,51,50,118,101,99,116,111,114,45,62,108,105,115,116,32,118,56,48,55,41,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,56,49,55,41,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,22),40,102,51,50,118,101,99,116,111,114,45,62,108,105,115,116,32,118,56,49,52,41,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,56,50,52,41,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,22),40,102,54,52,118,101,99,116,111,114,45,62,108,105,115,116,32,118,56,50,49,41,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,16),40,117,56,118,101,99,116,111,114,63,32,120,56,50,56,41};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,16),40,115,56,118,101,99,116,111,114,63,32,120,56,51,48,41};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,17),40,117,49,54,118,101,99,116,111,114,63,32,120,56,51,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,17),40,115,49,54,118,101,99,116,111,114,63,32,120,56,51,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,17),40,117,51,50,118,101,99,116,111,114,63,32,120,56,51,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,17),40,115,51,50,118,101,99,116,111,114,63,32,120,56,51,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,17),40,102,51,50,118,101,99,116,111,114,63,32,120,56,52,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,17),40,102,54,52,118,101,99,116,111,114,63,32,120,56,52,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,13),40,102,95,51,51,54,49,32,118,56,53,50,41,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,25),40,112,97,99,107,45,99,111,112,121,32,116,97,103,56,53,48,32,108,111,99,56,53,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,15),40,102,95,51,51,55,57,32,115,116,114,56,54,48,41,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,28),40,117,110,112,97,99,107,32,116,97,103,56,53,55,32,115,122,56,53,56,32,108,111,99,56,53,57,41,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,15),40,102,95,51,52,48,57,32,115,116,114,56,55,48,41,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,33),40,117,110,112,97,99,107,45,99,111,112,121,32,116,97,103,56,54,55,32,115,122,56,54,56,32,108,111,99,56,54,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,16),40,102,53,48,51,49,32,118,56,52,55,53,48,51,48,41};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,16),40,102,53,48,50,52,32,118,56,52,55,53,48,50,51,41};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,16),40,102,53,48,49,55,32,118,56,52,55,53,48,49,54,41};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,16),40,102,53,48,49,48,32,118,56,52,55,53,48,48,57,41};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,16),40,102,53,48,48,51,32,118,56,52,55,53,48,48,50,41};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,16),40,102,52,57,57,54,32,118,56,52,55,52,57,57,53,41};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,16),40,102,52,57,56,57,32,118,56,52,55,52,57,56,56,41};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,16),40,102,52,57,56,50,32,118,56,52,55,52,57,56,49,41};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,11),40,103,57,50,54,32,99,57,50,56,41,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,38),40,35,35,115,121,115,35,117,115,101,114,45,114,101,97,100,45,104,111,111,107,32,99,104,97,114,57,49,50,32,112,111,114,116,57,49,51,41,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,48),40,35,35,115,121,115,35,117,115,101,114,45,112,114,105,110,116,45,104,111,111,107,32,120,57,51,50,32,114,101,97,100,97,98,108,101,57,51,51,32,112,111,114,116,57,51,52,41};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,49),40,115,117,98,110,118,101,99,116,111,114,32,118,57,52,55,32,116,57,52,56,32,101,115,57,52,57,32,102,114,111,109,57,53,48,32,116,111,57,53,49,32,108,111,99,57,53,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,32),40,115,117,98,117,56,118,101,99,116,111,114,32,118,57,56,51,32,102,114,111,109,57,56,52,32,116,111,57,56,53,41};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,33),40,115,117,98,117,49,54,118,101,99,116,111,114,32,118,57,56,55,32,102,114,111,109,57,56,56,32,116,111,57,56,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,33),40,115,117,98,117,51,50,118,101,99,116,111,114,32,118,57,57,49,32,102,114,111,109,57,57,50,32,116,111,57,57,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,32),40,115,117,98,115,56,118,101,99,116,111,114,32,118,57,57,53,32,102,114,111,109,57,57,54,32,116,111,57,57,55,41};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,35),40,115,117,98,115,49,54,118,101,99,116,111,114,32,118,57,57,57,32,102,114,111,109,49,48,48,48,32,116,111,49,48,48,49,41,0,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,36),40,115,117,98,115,51,50,118,101,99,116,111,114,32,118,49,48,48,51,32,102,114,111,109,49,48,48,52,32,116,111,49,48,48,53,41,0,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,36),40,115,117,98,102,51,50,118,101,99,116,111,114,32,118,49,48,48,55,32,102,114,111,109,49,48,48,56,32,116,111,49,48,48,57,41,0,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,36),40,115,117,98,102,54,52,118,101,99,116,111,114,32,118,49,48,49,49,32,102,114,111,109,49,48,49,50,32,116,111,49,48,49,51,41,0,0,0,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,48,51,52,32,105,49,48,51,54,41,0,0,0,0,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,36),40,119,114,105,116,101,45,117,56,118,101,99,116,111,114,32,118,49,48,50,48,32,46,32,116,109,112,49,48,49,57,49,48,50,49,41,0,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,45),40,114,101,97,100,45,117,56,118,101,99,116,111,114,33,32,110,49,48,52,55,32,100,101,115,116,49,48,52,56,32,46,32,116,109,112,49,48,52,54,49,48,52,57,41,0,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,20),40,119,114,97,112,32,115,116,114,49,48,55,48,32,110,49,48,55,49,41,0,0,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,29),40,114,101,97,100,45,117,56,118,101,99,116,111,114,32,46,32,116,109,112,49,48,55,57,49,48,56,48,41,0,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,17),40,97,52,49,49,53,32,120,51,52,54,32,105,51,52,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,17),40,97,52,49,52,53,32,120,51,51,49,32,105,51,51,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,17),40,97,52,49,55,53,32,120,51,49,54,32,105,51,49,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,17),40,97,52,50,48,53,32,120,51,48,49,32,105,51,48,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,17),40,97,52,50,51,53,32,120,50,56,54,32,105,50,56,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,17),40,97,52,50,54,53,32,120,50,55,49,32,105,50,55,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,17),40,97,52,50,57,53,32,120,50,53,54,32,105,50,53,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,17),40,97,52,51,50,53,32,120,50,52,49,32,105,50,52,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub367(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub367(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word bv=(C_word )(C_a0);
C_free((void *)C_block_item(bv, 1));
C_ret:
#undef return

return C_r;}

#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub362(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub362(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int bytes=(int )C_unfix(C_a0);
C_word *buf = (C_word *)C_malloc(bytes + sizeof(C_header));if(buf == NULL) C_return(C_SCHEME_FALSE);C_block_header_init(buf, C_make_header(C_BYTEVECTOR_TYPE, bytes));C_return(buf);
C_ret:
#undef return

return C_r;}

C_noret_decl(C_srfi_2d4_toplevel)
C_externexport void C_ccall C_srfi_2d4_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3212)
static void C_ccall f_3212(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1546)
static void C_ccall f_1546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f4996)
static void C_ccall f4996(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1611)
static void C_ccall f_1611(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3789)
static void C_ccall f_3789(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3783)
static void C_ccall f_3783(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2167)
static C_word C_fcall f_2167(C_word t0,C_word t1);
C_noret_decl(f_2549)
static void C_ccall f_2549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2162)
static void C_ccall f_2162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1609)
static void C_ccall f_1609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3795)
static void C_ccall f_3795(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3311)
static void C_ccall f_3311(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3317)
static void C_ccall f_3317(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3221)
static void C_fcall f_3221(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3698)
static void C_fcall f_3698(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1621)
static void C_ccall f_1621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5031)
static void C_ccall f5031(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3235)
static void C_ccall f_3235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2153)
static void C_ccall f_2153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5024)
static void C_ccall f5024(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f5010)
static void C_ccall f5010(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1966)
static void C_ccall f_1966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5017)
static void C_ccall f5017(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3305)
static void C_ccall f_3305(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3359)
static void C_fcall f_3359(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2185)
static void C_ccall f_2185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5003)
static void C_ccall f5003(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1957)
static void C_ccall f_1957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3329)
static void C_ccall f_3329(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3964)
static void C_fcall f_3964(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3323)
static void C_ccall f_3323(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2890)
static void C_ccall f_2890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3162)
static void C_fcall f_3162(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2125)
static void C_ccall f_2125(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2125)
static void C_ccall f_2125r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3177)
static void C_ccall f_3177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3341)
static void C_ccall f_3341(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3183)
static void C_ccall f_3183(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3192)
static void C_fcall f_3192(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4146)
static void C_ccall f_4146(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4144)
static void C_ccall f_4144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1653)
static void C_ccall f_1653(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3335)
static void C_ccall f_3335(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1645)
static void C_ccall f_1645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2835)
static void C_ccall f_2835(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3756)
static void C_ccall f_3756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1693)
static void C_ccall f_1693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1696)
static void C_ccall f_1696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3093)
static void C_ccall f_3093(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2847)
static void C_fcall f_2847(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3762)
static void C_ccall f_3762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2842)
static void C_ccall f_2842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1684)
static void C_ccall f_1684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1686)
static void C_ccall f_1686(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3063)
static void C_ccall f_3063(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1989)
static void C_ccall f_1989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3072)
static void C_fcall f_3072(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1971)
static C_word C_fcall f_1971(C_word t0,C_word t1);
C_noret_decl(f_3015)
static void C_ccall f_3015(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3015)
static void C_ccall f_3015r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2878)
static void C_ccall f_2878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2871)
static void C_ccall f_2871(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2351)
static void C_ccall f_2351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4236)
static void C_ccall f_4236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4234)
static void C_ccall f_4234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2883)
static void C_fcall f_2883(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2854)
static void C_ccall f_2854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3644)
static void C_ccall f_3644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3647)
static void C_ccall f_3647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3051)
static void C_ccall f_3051(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3051)
static void C_ccall f_3051r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3057)
static void C_ccall f_3057(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3057)
static void C_ccall f_3057r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3087)
static void C_ccall f_3087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3021)
static void C_ccall f_3021(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3021)
static void C_ccall f_3021r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3027)
static void C_ccall f_3027(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3027)
static void C_ccall f_3027r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2799)
static void C_ccall f_2799(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3033)
static void C_ccall f_3033(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3033)
static void C_ccall f_3033r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2770)
static void C_ccall f_2770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3039)
static void C_ccall f_3039(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3039)
static void C_ccall f_3039r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3632)
static void C_ccall f_3632(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3657)
static void C_ccall f_3657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3600)
static void C_fcall f_3600(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3611)
static void C_ccall f_3611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4116)
static void C_ccall f_4116(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4114)
static void C_ccall f_4114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1494)
static void C_ccall f_1494(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4057)
static void C_ccall f_4057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1488)
static void C_ccall f_1488(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4204)
static void C_ccall f_4204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4206)
static void C_ccall f_4206(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3045)
static void C_ccall f_3045(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3045)
static void C_ccall f_3045r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4039)
static void C_ccall f_4039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2739)
static void C_fcall f_2739(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2734)
static void C_ccall f_2734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3732)
static void C_ccall f_3732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2746)
static void C_ccall f_2746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4042)
static void C_ccall f_4042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3559)
static void C_ccall f_3559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3555)
static void C_ccall f_3555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3551)
static void C_ccall f_3551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2782)
static void C_ccall f_2782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1473)
static void C_fcall f_1473(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2775)
static void C_fcall f_2775(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2482)
static void C_ccall f_2482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3567)
static void C_ccall f_3567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3563)
static void C_ccall f_3563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2323)
static void C_ccall f_2323(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2323)
static void C_ccall f_2323r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2818)
static void C_ccall f_2818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3102)
static void C_fcall f_3102(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2811)
static void C_fcall f_2811(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2464)
static C_word C_fcall f_2464(C_word t0,C_word t1);
C_noret_decl(f_2919)
static void C_fcall f_2919(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2806)
static void C_ccall f_2806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3117)
static void C_ccall f_3117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2914)
static void C_ccall f_2914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2763)
static void C_ccall f_2763(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2907)
static void C_ccall f_2907(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3123)
static void C_ccall f_3123(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3132)
static void C_fcall f_3132(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3495)
static void C_ccall f_3495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3499)
static void C_ccall f_3499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3491)
static void C_ccall f_3491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2926)
static void C_ccall f_2926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4014)
static void C_ccall f_4014(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4014)
static void C_ccall f_4014r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4013)
static void C_ccall f_4013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3153)
static void C_ccall f_3153(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3147)
static void C_ccall f_3147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4005)
static void C_fcall f_4005(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3572)
static void C_ccall f_3572(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4176)
static void C_ccall f_4176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4174)
static void C_ccall f_4174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3581)
static void C_ccall f_3581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3419)
static void C_ccall f_3419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2688)
static void C_ccall f_2688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2962)
static void C_ccall f_2962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2450)
static void C_ccall f_2450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2383)
static void C_ccall f_2383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3428)
static void C_fcall f_3428(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4326)
static void C_ccall f_4326(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4324)
static void C_ccall f_4324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1578)
static void C_ccall f_1578(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1570)
static void C_ccall f_1570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2664)
static void C_fcall f_2664(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2943)
static void C_ccall f_2943(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2669)
static C_word C_fcall f_2669(C_word t0,C_word t1);
C_noret_decl(f_2365)
static C_word C_fcall f_2365(C_word t0,C_word t1);
C_noret_decl(f_2955)
static void C_fcall f_2955(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1720)
static void C_ccall f_1720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2950)
static void C_ccall f_2950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2422)
static void C_ccall f_2422(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2422)
static void C_ccall f_2422r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3479)
static void C_ccall f_3479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3475)
static void C_ccall f_3475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3487)
static void C_ccall f_3487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3483)
static void C_ccall f_3483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3819)
static void C_ccall f_3819(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3813)
static void C_ccall f_3813(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1741)
static void C_ccall f_1741(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1748)
static void C_ccall f_1748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4296)
static void C_ccall f_4296(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4294)
static void C_ccall f_4294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4266)
static void C_ccall f_4266(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4264)
static void C_ccall f_4264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2979)
static void C_ccall f_2979(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2624)
static void C_ccall f_2624(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2624)
static void C_ccall f_2624r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1751)
static void C_ccall f_1751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1783)
static void C_ccall f_1783(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3543)
static void C_ccall f_3543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3409)
static void C_ccall f_3409(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3547)
static void C_ccall f_3547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3407)
static void C_fcall f_3407(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3539)
static void C_ccall f_3539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1775)
static void C_ccall f_1775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1929)
static void C_ccall f_1929(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1929)
static void C_ccall f_1929r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1921)
static void C_ccall f_1921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4354)
static void C_ccall f_4354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1896)
static void C_fcall f_1896(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3395)
static void C_fcall f_3395(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1914)
static void C_ccall f_1914(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1912)
static void C_ccall f_1912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3361)
static void C_ccall f_3361(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2986)
static void C_ccall f_2986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4066)
static void C_ccall f_4066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4062)
static void C_fcall f_4062(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2998)
static void C_ccall f_2998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2991)
static void C_fcall f_2991(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2585)
static void C_ccall f_2585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3511)
static void C_ccall f_3511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3515)
static void C_ccall f_3515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2566)
static C_word C_fcall f_2566(C_word t0,C_word t1);
C_noret_decl(f_3523)
static void C_ccall f_3523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3527)
static void C_ccall f_3527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3519)
static void C_ccall f_3519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2561)
static void C_fcall f_2561(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3531)
static void C_ccall f_3531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3535)
static void C_ccall f_3535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3379)
static void C_ccall f_3379(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3377)
static void C_fcall f_3377(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3371)
static void C_ccall f_3371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1820)
static void C_ccall f_1820(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1814)
static void C_ccall f_1814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4075)
static void C_ccall f_4075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3264)
static void C_ccall f_3264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4084)
static void C_ccall f_4084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2284)
static void C_ccall f_2284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3279)
static void C_fcall f_3279(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3270)
static void C_ccall f_3270(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1500)
static void C_ccall f_1500(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1506)
static void C_ccall f_1506(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2652)
static void C_ccall f_2652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2252)
static void C_ccall f_2252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1536)
static void C_ccall f_1536(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1530)
static void C_ccall f_1530(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f4982)
static void C_ccall f4982(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3924)
static void C_ccall f_3924(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3924)
static void C_ccall f_3924r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2261)
static void C_ccall f_2261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3503)
static void C_ccall f_3503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2727)
static void C_ccall f_2727(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1863)
static void C_ccall f_1863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2266)
static C_word C_fcall f_2266(C_word t0,C_word t1);
C_noret_decl(f_1867)
static void C_ccall f_1867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1524)
static void C_ccall f_1524(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f4989)
static void C_ccall f4989(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3507)
static void C_ccall f_3507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1851)
static void C_ccall f_1851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1859)
static void C_ccall f_1859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1883)
static void C_ccall f_1883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1887)
static void C_ccall f_1887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2521)
static void C_ccall f_2521(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2521)
static void C_ccall f_2521r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1871)
static void C_ccall f_1871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2027)
static void C_ccall f_2027(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2027)
static void C_ccall f_2027r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1875)
static void C_ccall f_1875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3825)
static void C_ccall f_3825(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1879)
static void C_ccall f_1879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3293)
static void C_ccall f_3293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3299)
static void C_ccall f_3299(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3831)
static void C_ccall f_3831(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3831)
static void C_ccall f_3831r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3861)
static void C_fcall f_3861(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3241)
static void C_ccall f_3241(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3807)
static void C_ccall f_3807(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3801)
static void C_ccall f_3801(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2087)
static void C_ccall f_2087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1512)
static void C_ccall f_1512(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1518)
static void C_ccall f_1518(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2224)
static void C_ccall f_2224(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2224)
static void C_ccall f_2224r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3250)
static void C_fcall f_3250(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3871)
static void C_ccall f_3871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2055)
static void C_ccall f_2055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2064)
static void C_ccall f_2064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3847)
static void C_ccall f_3847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2069)
static C_word C_fcall f_2069(C_word t0,C_word t1);
C_noret_decl(f_3206)
static void C_ccall f_3206(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_3221)
static void C_fcall trf_3221(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3221(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3221(t0,t1,t2);}

C_noret_decl(trf_3698)
static void C_fcall trf_3698(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3698(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3698(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3359)
static void C_fcall trf_3359(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3359(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3359(t0,t1,t2);}

C_noret_decl(trf_3964)
static void C_fcall trf_3964(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3964(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3964(t0,t1);}

C_noret_decl(trf_3162)
static void C_fcall trf_3162(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3162(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3162(t0,t1,t2);}

C_noret_decl(trf_3192)
static void C_fcall trf_3192(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3192(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3192(t0,t1,t2);}

C_noret_decl(trf_2847)
static void C_fcall trf_2847(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2847(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2847(t0,t1,t2,t3);}

C_noret_decl(trf_3072)
static void C_fcall trf_3072(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3072(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3072(t0,t1,t2);}

C_noret_decl(trf_2883)
static void C_fcall trf_2883(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2883(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2883(t0,t1,t2,t3);}

C_noret_decl(trf_3600)
static void C_fcall trf_3600(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3600(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3600(t0,t1,t2);}

C_noret_decl(trf_2739)
static void C_fcall trf_2739(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2739(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2739(t0,t1,t2,t3);}

C_noret_decl(trf_1473)
static void C_fcall trf_1473(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1473(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1473(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2775)
static void C_fcall trf_2775(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2775(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2775(t0,t1,t2,t3);}

C_noret_decl(trf_3102)
static void C_fcall trf_3102(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3102(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3102(t0,t1,t2);}

C_noret_decl(trf_2811)
static void C_fcall trf_2811(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2811(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2811(t0,t1,t2,t3);}

C_noret_decl(trf_2919)
static void C_fcall trf_2919(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2919(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2919(t0,t1,t2,t3);}

C_noret_decl(trf_3132)
static void C_fcall trf_3132(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3132(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3132(t0,t1,t2);}

C_noret_decl(trf_4005)
static void C_fcall trf_4005(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4005(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4005(t0,t1,t2);}

C_noret_decl(trf_3428)
static void C_fcall trf_3428(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3428(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3428(t0,t1);}

C_noret_decl(trf_2664)
static void C_fcall trf_2664(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2664(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2664(t0,t1);}

C_noret_decl(trf_2955)
static void C_fcall trf_2955(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2955(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2955(t0,t1,t2,t3);}

C_noret_decl(trf_3407)
static void C_fcall trf_3407(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3407(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3407(t0,t1,t2,t3);}

C_noret_decl(trf_1896)
static void C_fcall trf_1896(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1896(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1896(t0,t1,t2,t3);}

C_noret_decl(trf_3395)
static void C_fcall trf_3395(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3395(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3395(t0,t1);}

C_noret_decl(trf_4062)
static void C_fcall trf_4062(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4062(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4062(t0,t1);}

C_noret_decl(trf_2991)
static void C_fcall trf_2991(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2991(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2991(t0,t1,t2,t3);}

C_noret_decl(trf_2561)
static void C_fcall trf_2561(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2561(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2561(t0,t1);}

C_noret_decl(trf_3377)
static void C_fcall trf_3377(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3377(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3377(t0,t1,t2,t3);}

C_noret_decl(trf_3279)
static void C_fcall trf_3279(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3279(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3279(t0,t1,t2);}

C_noret_decl(trf_3861)
static void C_fcall trf_3861(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3861(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3861(t0,t1,t2);}

C_noret_decl(trf_3250)
static void C_fcall trf_3250(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3250(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3250(t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_2d4_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_2d4_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_2d4_toplevel"));
C_check_nursery_minimum(57);
if(!C_demand(57)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1430)){
C_save(t1);
C_rereclaim2(1430*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(57);
C_initialize_lf(lf,167);
lf[1]=C_h_intern(&lf[1],9,"\003syserror");
lf[2]=C_decode_literal(C_heaptop,"\376B\000\000&numeric value is not in expected range");
lf[3]=C_h_intern(&lf[3],15,"u8vector-length");
lf[4]=C_h_intern(&lf[4],8,"u8vector");
lf[5]=C_h_intern(&lf[5],15,"s8vector-length");
lf[6]=C_h_intern(&lf[6],8,"s8vector");
lf[7]=C_h_intern(&lf[7],16,"u16vector-length");
lf[8]=C_h_intern(&lf[8],9,"u16vector");
lf[9]=C_h_intern(&lf[9],16,"s16vector-length");
lf[10]=C_h_intern(&lf[10],9,"s16vector");
lf[11]=C_h_intern(&lf[11],16,"u32vector-length");
lf[12]=C_h_intern(&lf[12],9,"u32vector");
lf[13]=C_h_intern(&lf[13],16,"s32vector-length");
lf[14]=C_h_intern(&lf[14],9,"s32vector");
lf[15]=C_h_intern(&lf[15],16,"f32vector-length");
lf[16]=C_h_intern(&lf[16],9,"f32vector");
lf[17]=C_h_intern(&lf[17],16,"f64vector-length");
lf[18]=C_h_intern(&lf[18],9,"f64vector");
lf[19]=C_h_intern(&lf[19],13,"u8vector-set!");
lf[20]=C_h_intern(&lf[20],14,"\003syserror-hook");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\034argument may not be negative");
lf[22]=C_h_intern(&lf[22],13,"s8vector-set!");
lf[23]=C_h_intern(&lf[23],14,"u16vector-set!");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000\034argument may not be negative");
lf[25]=C_h_intern(&lf[25],14,"s16vector-set!");
lf[26]=C_h_intern(&lf[26],14,"u32vector-set!");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000\034argument may not be negative");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\036argument exceeds integer range");
lf[29]=C_h_intern(&lf[29],17,"\003syscheck-integer");
lf[30]=C_h_intern(&lf[30],14,"s32vector-set!");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\036argument exceeds integer range");
lf[32]=C_h_intern(&lf[32],14,"f32vector-set!");
lf[33]=C_h_intern(&lf[33],14,"f64vector-set!");
lf[34]=C_h_intern(&lf[34],12,"u8vector-ref");
lf[35]=C_h_intern(&lf[35],12,"s8vector-ref");
lf[36]=C_h_intern(&lf[36],13,"u16vector-ref");
lf[37]=C_h_intern(&lf[37],13,"s16vector-ref");
lf[38]=C_h_intern(&lf[38],13,"u32vector-ref");
lf[39]=C_h_intern(&lf[39],13,"s32vector-ref");
lf[40]=C_h_intern(&lf[40],13,"f32vector-ref");
lf[41]=C_h_intern(&lf[41],13,"f64vector-ref");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000:not enough memory - cannot allocate external number vector");
lf[43]=C_h_intern(&lf[43],19,"\003sysallocate-vector");
lf[44]=C_h_intern(&lf[44],21,"release-number-vector");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\047bad argument type - not a number vector");
lf[46]=C_h_intern(&lf[46],14,"number-vector\077");
lf[47]=C_h_intern(&lf[47],13,"make-u8vector");
lf[48]=C_h_intern(&lf[48],14,"set-finalizer!");
lf[49]=C_h_intern(&lf[49],13,"make-s8vector");
lf[50]=C_h_intern(&lf[50],14,"make-u16vector");
lf[51]=C_h_intern(&lf[51],14,"make-s16vector");
lf[52]=C_h_intern(&lf[52],14,"make-u32vector");
lf[53]=C_h_intern(&lf[53],14,"make-s32vector");
lf[54]=C_h_intern(&lf[54],14,"make-f32vector");
lf[55]=C_h_intern(&lf[55],14,"make-f64vector");
lf[56]=C_h_intern(&lf[56],14,"list->u8vector");
lf[57]=C_h_intern(&lf[57],27,"\003syserror-not-a-proper-list");
lf[58]=C_h_intern(&lf[58],14,"list->s8vector");
lf[59]=C_h_intern(&lf[59],15,"list->u16vector");
lf[60]=C_h_intern(&lf[60],15,"list->s16vector");
lf[61]=C_h_intern(&lf[61],15,"list->u32vector");
lf[62]=C_h_intern(&lf[62],15,"list->s32vector");
lf[63]=C_h_intern(&lf[63],15,"list->f32vector");
lf[64]=C_h_intern(&lf[64],15,"list->f64vector");
lf[65]=C_h_intern(&lf[65],14,"u8vector->list");
lf[66]=C_h_intern(&lf[66],14,"s8vector->list");
lf[67]=C_h_intern(&lf[67],15,"u16vector->list");
lf[68]=C_h_intern(&lf[68],15,"s16vector->list");
lf[69]=C_h_intern(&lf[69],15,"u32vector->list");
lf[70]=C_h_intern(&lf[70],15,"s32vector->list");
lf[71]=C_h_intern(&lf[71],15,"f32vector->list");
lf[72]=C_h_intern(&lf[72],15,"f64vector->list");
lf[73]=C_h_intern(&lf[73],9,"u8vector\077");
lf[74]=C_h_intern(&lf[74],9,"s8vector\077");
lf[75]=C_h_intern(&lf[75],10,"u16vector\077");
lf[76]=C_h_intern(&lf[76],10,"s16vector\077");
lf[77]=C_h_intern(&lf[77],10,"u32vector\077");
lf[78]=C_h_intern(&lf[78],10,"s32vector\077");
lf[79]=C_h_intern(&lf[79],10,"f32vector\077");
lf[80]=C_h_intern(&lf[80],10,"f64vector\077");
lf[81]=C_h_intern(&lf[81],18,"\003syssrfi-4-vector\077");
lf[83]=C_h_intern(&lf[83],13,"\003sysmake-blob");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000+blob does not have correct size for packing");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000+blob does not have correct size for packing");
lf[88]=C_h_intern(&lf[88],21,"u8vector->blob/shared");
lf[89]=C_h_intern(&lf[89],21,"s8vector->blob/shared");
lf[90]=C_h_intern(&lf[90],22,"u16vector->blob/shared");
lf[91]=C_h_intern(&lf[91],22,"s16vector->blob/shared");
lf[92]=C_h_intern(&lf[92],22,"u32vector->blob/shared");
lf[93]=C_h_intern(&lf[93],22,"s32vector->blob/shared");
lf[94]=C_h_intern(&lf[94],22,"f32vector->blob/shared");
lf[95]=C_h_intern(&lf[95],22,"f64vector->blob/shared");
lf[96]=C_h_intern(&lf[96],14,"u8vector->blob");
lf[97]=C_h_intern(&lf[97],14,"s8vector->blob");
lf[98]=C_h_intern(&lf[98],15,"u16vector->blob");
lf[99]=C_h_intern(&lf[99],15,"s16vector->blob");
lf[100]=C_h_intern(&lf[100],15,"u32vector->blob");
lf[101]=C_h_intern(&lf[101],15,"s32vector->blob");
lf[102]=C_h_intern(&lf[102],15,"f32vector->blob");
lf[103]=C_h_intern(&lf[103],15,"f64vector->blob");
lf[104]=C_h_intern(&lf[104],21,"blob->u8vector/shared");
lf[105]=C_h_intern(&lf[105],21,"blob->s8vector/shared");
lf[106]=C_h_intern(&lf[106],22,"blob->u16vector/shared");
lf[107]=C_h_intern(&lf[107],22,"blob->s16vector/shared");
lf[108]=C_h_intern(&lf[108],22,"blob->u32vector/shared");
lf[109]=C_h_intern(&lf[109],22,"blob->s32vector/shared");
lf[110]=C_h_intern(&lf[110],22,"blob->f32vector/shared");
lf[111]=C_h_intern(&lf[111],22,"blob->f64vector/shared");
lf[112]=C_h_intern(&lf[112],14,"blob->u8vector");
lf[113]=C_h_intern(&lf[113],14,"blob->s8vector");
lf[114]=C_h_intern(&lf[114],15,"blob->u16vector");
lf[115]=C_h_intern(&lf[115],15,"blob->s16vector");
lf[116]=C_h_intern(&lf[116],15,"blob->u32vector");
lf[117]=C_h_intern(&lf[117],15,"blob->s32vector");
lf[118]=C_h_intern(&lf[118],15,"blob->f32vector");
lf[119]=C_h_intern(&lf[119],15,"blob->f64vector");
lf[120]=C_h_intern(&lf[120],18,"\003sysuser-read-hook");
lf[121]=C_h_intern(&lf[121],2,"u8");
lf[122]=C_h_intern(&lf[122],2,"s8");
lf[123]=C_h_intern(&lf[123],3,"u16");
lf[124]=C_h_intern(&lf[124],3,"s16");
lf[125]=C_h_intern(&lf[125],3,"u32");
lf[126]=C_h_intern(&lf[126],3,"s32");
lf[127]=C_h_intern(&lf[127],3,"f32");
lf[128]=C_h_intern(&lf[128],3,"f64");
lf[129]=C_h_intern(&lf[129],1,"f");
lf[130]=C_h_intern(&lf[130],1,"F");
lf[131]=C_h_intern(&lf[131],4,"read");
lf[132]=C_h_intern(&lf[132],14,"\003sysread-error");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal bytevector syntax");
lf[134]=C_h_intern(&lf[134],19,"\003sysuser-print-hook");
lf[135]=C_h_intern(&lf[135],9,"\003sysprint");
lf[137]=C_h_intern(&lf[137],11,"subu8vector");
lf[138]=C_h_intern(&lf[138],12,"subu16vector");
lf[139]=C_h_intern(&lf[139],12,"subu32vector");
lf[140]=C_h_intern(&lf[140],11,"subs8vector");
lf[141]=C_h_intern(&lf[141],12,"subs16vector");
lf[142]=C_h_intern(&lf[142],12,"subs32vector");
lf[143]=C_h_intern(&lf[143],12,"subf32vector");
lf[144]=C_h_intern(&lf[144],12,"subf64vector");
lf[145]=C_h_intern(&lf[145],14,"write-u8vector");
lf[146]=C_h_intern(&lf[146],19,"\003sysstandard-output");
lf[147]=C_h_intern(&lf[147],16,"\003syswrite-char-0");
lf[148]=C_h_intern(&lf[148],14,"read-u8vector!");
lf[149]=C_h_intern(&lf[149],18,"\003sysstandard-input");
lf[150]=C_h_intern(&lf[150],16,"\003sysread-string!");
lf[151]=C_h_intern(&lf[151],13,"read-u8vector");
lf[152]=C_h_intern(&lf[152],17,"get-output-string");
lf[153]=C_h_intern(&lf[153],19,"\003syswrite-char/port");
lf[154]=C_h_intern(&lf[154],15,"\003sysread-char-0");
lf[155]=C_h_intern(&lf[155],18,"open-output-string");
lf[156]=C_h_intern(&lf[156],17,"register-feature!");
lf[157]=C_h_intern(&lf[157],6,"srfi-4");
lf[158]=C_h_intern(&lf[158],18,"getter-with-setter");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\023(f64vector-ref v i)");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\023(f32vector-ref v i)");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\023(s32vector-ref v i)");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\023(u32vector-ref v i)");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\023(s16vector-ref v i)");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\023(u16vector-ref v i)");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\022(s8vector-ref v i)");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\022(u8vector-ref v i)");
C_register_lf2(lf,167,create_ptable());
t2=C_mutate2(&lf[0] /* (set! ##sys#check-exact-interval ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1473,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate2((C_word*)lf[3]+1 /* (set! u8vector-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1488,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate2((C_word*)lf[5]+1 /* (set! s8vector-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1494,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate2((C_word*)lf[7]+1 /* (set! u16vector-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1500,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate2((C_word*)lf[9]+1 /* (set! s16vector-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1506,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate2((C_word*)lf[11]+1 /* (set! u32vector-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1512,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate2((C_word*)lf[13]+1 /* (set! s32vector-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1518,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate2((C_word*)lf[15]+1 /* (set! f32vector-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1524,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate2((C_word*)lf[17]+1 /* (set! f64vector-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1530,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate2((C_word*)lf[19]+1 /* (set! u8vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1536,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate2((C_word*)lf[22]+1 /* (set! s8vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1578,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate2((C_word*)lf[23]+1 /* (set! u16vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1611,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate2((C_word*)lf[25]+1 /* (set! s16vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1653,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate2((C_word*)lf[26]+1 /* (set! u32vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1686,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate2((C_word*)lf[30]+1 /* (set! s32vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1741,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate2((C_word*)lf[32]+1 /* (set! f32vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1783,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate2((C_word*)lf[33]+1 /* (set! f64vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1820,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1859,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4326,a[2]=((C_word)li123),tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:175: getter-with-setter */
t21=*((C_word*)lf[158]+1);
((C_proc5)(void*)(*((C_word*)t21+1)))(5,t21,t19,t20,*((C_word*)lf[19]+1),lf[166]);}

/* s32vector->list in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3212(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3212,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[14],lf[70]);
t4=C_u_i_s32vector_length(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3221,a[2]=t4,a[3]=t2,a[4]=t6,a[5]=((C_word)li70),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3221(t8,t1,C_fix(0));}

/* k1544 in u8vector-set! */
static void C_ccall f_1546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1546,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1570,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[4];
t4=C_i_check_exact_2(t3,lf[19]);
t5=C_fixnum_less_or_equal_p(C_fix(0),t3);
t6=(C_truep(t5)?C_fixnum_lessp(t3,((C_word*)t0)[6]):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_u_i_u8vector_set(((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]));}
else{
t7=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:56: ##sys#error-hook */
((C_proc7)C_fast_retrieve_proc(*((C_word*)lf[20]+1)))(7,*((C_word*)lf[20]+1),t2,t7,lf[19],t3,C_fix(0),((C_word*)t0)[6]);}}

/* f4996 in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f4996(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f4996,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[14],lf[93]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(1)));}

/* u16vector-set! */
static void C_ccall f_1611(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1611,5,t0,t1,t2,t3,t4);}
t5=C_i_check_structure_2(t2,lf[8],lf[23]);
t6=C_u_i_16vector_length(t2);
t7=C_i_check_exact_2(t4,lf[23]);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1621,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_fixnum_lessp(t4,C_fix(0)))){
/* srfi-4.scm:119: ##sys#error */
t9=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[23],lf[24],t4);}
else{
t9=t8;
f_1621(2,t9,C_SCHEME_UNDEFINED);}}

/* subu16vector in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in k3485 in ... */
static void C_ccall f_3789(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3789,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm:634: subnvector */
f_3698(t1,t2,lf[8],C_fix(2),t3,t4,lf[138]);}

/* subu8vector in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in k3485 in ... */
static void C_ccall f_3783(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3783,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm:633: subnvector */
f_3698(t1,t2,lf[4],C_fix(1),t3,t4,lf[137]);}

/* doloop460 in k2160 in k2151 in k2183 in make-u16vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static C_word C_fcall f_2167(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_stack_overflow_check;
loop:
if(C_truep(C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[2]))){
return(((C_word*)t0)[3]);}
else{
t2=C_u_i_u16vector_set(((C_word*)t0)[3],t1,((C_word*)t0)[4]);
t3=C_fixnum_plus(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}

/* k2547 in k2583 in make-f32vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2549,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[2])[1];
if(C_truep(t2)){
t3=C_i_check_number_2(((C_word*)((C_word*)t0)[2])[1],lf[54]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2561,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_blockp(((C_word*)((C_word*)t0)[2])[1]))){
t5=t4;
f_2561(t5,C_SCHEME_UNDEFINED);}
else{
t5=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_a_i_fix_to_flo(&a,1,((C_word*)((C_word*)t0)[2])[1]));
t6=t4;
f_2561(t6,t5);}}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}}

/* k2160 in k2151 in k2183 in make-u16vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2162,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2167,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li24),tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2167(t2,C_fix(0)));}

/* k1607 in s8vector-set! */
static void C_ccall f_1609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_u_i_s8vector_set(((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]));}

/* subu32vector in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in k3485 in ... */
static void C_ccall f_3795(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3795,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm:635: subnvector */
f_3698(t1,t2,lf[12],C_fix(4),t3,t4,lf[139]);}

/* u16vector? in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3311(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3311,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_structurep(t2,lf[8]));}

/* s16vector? in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3317(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3317,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_structurep(t2,lf[10]));}

/* loop in s32vector->list in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_fcall f_3221(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3221,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3235,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_fixnum_plus(t2,C_fix(1));
/* srfi-4.scm:478: loop */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* subnvector in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in k3485 in ... */
static void C_fcall f_3698(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3698,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=C_i_check_structure_2(t2,t3,t7);
t9=C_slot(t2,C_fix(1));
t10=t9;
t11=C_block_size(t10);
t12=C_u_fixnum_divide(t11,t4);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3732,a[2]=t6,a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t10,a[7]=t1,a[8]=t12,a[9]=t7,tmp=(C_word)a,a+=10,tmp);
t14=C_fixnum_plus(t12,C_fix(1));
t15=t5;
t16=t7;
t17=C_i_check_exact_2(t15,t16);
t18=C_fixnum_less_or_equal_p(C_fix(0),t15);
t19=(C_truep(t18)?C_fixnum_lessp(t15,t14):C_SCHEME_FALSE);
if(C_truep(t19)){
t20=C_SCHEME_UNDEFINED;
t21=t13;
f_3732(2,t21,t20);}
else{
t20=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:56: ##sys#error-hook */
((C_proc7)C_fast_retrieve_proc(*((C_word*)lf[20]+1)))(7,*((C_word*)lf[20]+1),t13,t20,t16,t15,C_fix(0),t14);}}

/* k1619 in u16vector-set! */
static void C_ccall f_1621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1645,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[4];
t4=C_i_check_exact_2(t3,lf[23]);
t5=C_fixnum_less_or_equal_p(C_fix(0),t3);
t6=(C_truep(t5)?C_fixnum_lessp(t3,((C_word*)t0)[6]):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_u_i_u16vector_set(((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]));}
else{
t7=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:56: ##sys#error-hook */
((C_proc7)C_fast_retrieve_proc(*((C_word*)lf[20]+1)))(7,*((C_word*)lf[20]+1),t2,t7,lf[23],t3,C_fix(0),((C_word*)t0)[6]);}}

/* f5031 in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f5031(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f5031,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[4],lf[88]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(1)));}

/* k3233 in loop in s32vector->list in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3235,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,C_a_u_i_s32vector_ref(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]),t1));}

/* k2151 in k2183 in make-u16vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2153,2,t0,t1);}
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2162,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm:316: ##sys#check-exact-interval */
f_1473(t2,((C_word*)t0)[2],C_fix(0),C_fix(65535),lf[50]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* f5024 in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f5024(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f5024,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[6],lf[89]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(1)));}

/* f5010 in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f5010(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f5010,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[10],lf[91]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(1)));}

/* k1964 in k1955 in k1987 in make-u8vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_1966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1971,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li20),tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1971(t2,C_fix(0)));}

/* f5017 in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f5017(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f5017,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[8],lf[90]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(1)));}

/* s8vector? in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3305(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3305,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_structurep(t2,lf[6]));}

/* pack-copy in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_fcall f_3359(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3359,NULL,3,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3361,a[2]=t2,a[3]=t3,a[4]=((C_word)li84),tmp=(C_word)a,a+=5,tmp));}

/* k2183 in make-u16vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2185,2,t0,t1);}
t2=C_a_i_record2(&a,2,lf[8],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2153,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[5])){
if(C_truep(((C_word*)t0)[6])){
/* srfi-4.scm:312: set-finalizer! */
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,((C_word*)t0)[7]);}
else{
t5=t4;
f_2153(2,t5,C_SCHEME_UNDEFINED);}}
else{
t5=t4;
f_2153(2,t5,C_SCHEME_UNDEFINED);}}

/* f5003 in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f5003(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f5003,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[12],lf[92]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(1)));}

/* k1955 in k1987 in make-u8vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_1957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1957,2,t0,t1);}
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1966,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm:290: ##sys#check-exact-interval */
f_1473(t2,((C_word*)t0)[2],C_fix(0),C_fix(255),lf[47]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* s32vector? in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3329(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3329,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_structurep(t2,lf[14]));}

/* k3962 in read-u8vector! in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in ... */
static void C_fcall f_3964(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
/* srfi-4.scm:661: ##sys#read-string! */
((C_proc6)C_fast_retrieve_proc(*((C_word*)lf[150]+1)))(6,*((C_word*)lf[150]+1),((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6]);}
else{
t2=C_fixnum_difference(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t2);
/* srfi-4.scm:661: ##sys#read-string! */
((C_proc6)C_fast_retrieve_proc(*((C_word*)lf[150]+1)))(6,*((C_word*)lf[150]+1),((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6]);}}

/* u32vector? in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3323(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3323,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_structurep(t2,lf[12]));}

/* k2888 in doloop692 in k2876 in list->u32vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_2883(t4,((C_word*)t0)[5],t2,t3);}

/* loop in s16vector->list in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_fcall f_3162(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3162,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=C_u_i_s16vector_ref(((C_word*)t0)[3],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3177,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_fixnum_plus(t2,C_fix(1));
/* srfi-4.scm:476: loop */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* make-u16vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2125(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_2125r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2125r(t0,t1,t2,t3);}}

static void C_ccall f_2125r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a=C_alloc(8);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=t5;
t7=C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_FALSE:C_i_car(t8));
t11=t10;
t12=C_i_nullp(t8);
t13=(C_truep(t12)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t14=C_i_nullp(t13);
t15=(C_truep(t14)?C_SCHEME_TRUE:C_i_car(t13));
t16=t15;
t17=C_i_nullp(t13);
t18=(C_truep(t17)?C_SCHEME_END_OF_LIST:C_i_cdr(t13));
t19=C_i_check_exact_2(t2,lf[50]);
t20=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2185,a[2]=t6,a[3]=t2,a[4]=t1,a[5]=t11,a[6]=t16,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t21=C_fixnum_shift_left(t2,C_fix(1));
/* srfi-4.scm:311: alloc */
f_1896(t20,lf[50],t21,t11);}

/* k3175 in loop in s16vector->list in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3177,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* f64vector? in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3341(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3341,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_structurep(t2,lf[18]));}

/* u32vector->list in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3183(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3183,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[12],lf[69]);
t4=C_u_i_u32vector_length(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3192,a[2]=t4,a[3]=t2,a[4]=t6,a[5]=((C_word)li68),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3192(t8,t1,C_fix(0));}

/* loop in u32vector->list in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_fcall f_3192(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3192,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3206,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_fixnum_plus(t2,C_fix(1));
/* srfi-4.scm:477: loop */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* a4145 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_4146(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4146,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[16],lf[40]);
t5=C_u_i_f32vector_length(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4174,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=t3;
t8=C_i_check_exact_2(t7,lf[40]);
t9=C_fixnum_less_or_equal_p(C_fix(0),t7);
t10=(C_truep(t9)?C_fixnum_lessp(t7,t5):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_a_u_i_f32vector_ref(&a,2,t2,t3));}
else{
t11=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:56: ##sys#error-hook */
((C_proc7)C_fast_retrieve_proc(*((C_word*)lf[20]+1)))(7,*((C_word*)lf[20]+1),t6,t11,lf[40],t7,C_fix(0),t5);}}

/* k4142 in a4115 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_4144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4144,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_u_i_f64vector_ref(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]));}

/* s16vector-set! */
static void C_ccall f_1653(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1653,5,t0,t1,t2,t3,t4);}
t5=C_i_check_structure_2(t2,lf[10],lf[25]);
t6=C_u_i_16vector_length(t2);
t7=C_i_check_exact_2(t4,lf[25]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1684,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t9=t3;
t10=C_i_check_exact_2(t9,lf[25]);
t11=C_fixnum_less_or_equal_p(C_fix(0),t9);
t12=(C_truep(t11)?C_fixnum_lessp(t9,t6):C_SCHEME_FALSE);
if(C_truep(t12)){
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_u_i_s16vector_set(t2,t3,t4));}
else{
t13=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:56: ##sys#error-hook */
((C_proc7)C_fast_retrieve_proc(*((C_word*)lf[20]+1)))(7,*((C_word*)lf[20]+1),t8,t13,lf[25],t9,C_fix(0),t6);}}

/* f32vector? in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3335(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3335,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_structurep(t2,lf[16]));}

/* k1643 in k1619 in u16vector-set! */
static void C_ccall f_1645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_u_i_u16vector_set(((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]));}

/* list->s16vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2835(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2835,3,t0,t1,t2);}
t3=C_i_check_list_2(t2,lf[10]);
t4=C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2842,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm:419: make-s16vector */
t6=((C_word*)t0)[2];
((C_proc3)C_fast_retrieve_proc(t6))(3,t6,t5,t4);}

/* k3754 in k3730 in subnvector in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in ... */
static void C_ccall f_3756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3756,2,t0,t1);}
t2=C_fixnum_difference(((C_word*)t0)[2],((C_word*)t0)[3]);
t3=C_fixnum_times(((C_word*)t0)[4],t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3762,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm:627: ##sys#allocate-vector */
t6=*((C_word*)lf[43]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,t4,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k1691 in u32vector-set! */
static void C_ccall f_1693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1693,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1696,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_negativep(((C_word*)t0)[5]))){
/* srfi-4.scm:135: ##sys#error */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[26],lf[27],((C_word*)t0)[5]);}
else{
if(C_truep(C_fits_in_unsigned_int_p(((C_word*)t0)[5]))){
t3=C_SCHEME_UNDEFINED;
t4=t2;
f_1696(2,t4,t3);}
else{
/* srfi-4.scm:137: ##sys#error */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[26],lf[28],((C_word*)t0)[5]);}}}

/* k1694 in k1691 in u32vector-set! */
static void C_ccall f_1696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1696,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1720,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[4];
t4=C_i_check_exact_2(t3,lf[26]);
t5=C_fixnum_less_or_equal_p(C_fix(0),t3);
t6=(C_truep(t5)?C_fixnum_lessp(t3,((C_word*)t0)[6]):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_u_i_u32vector_set(((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]));}
else{
t7=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:56: ##sys#error-hook */
((C_proc7)C_fast_retrieve_proc(*((C_word*)lf[20]+1)))(7,*((C_word*)lf[20]+1),t2,t7,lf[26],t3,C_fix(0),((C_word*)t0)[6]);}}

/* s8vector->list in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3093(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3093,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[6],lf[66]);
t4=C_u_i_s8vector_length(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3102,a[2]=t4,a[3]=t2,a[4]=t6,a[5]=((C_word)li62),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3102(t8,t1,C_fix(0));}

/* doloop679 in k2840 in list->s16vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_fcall f_2847(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2847,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2854,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_truep(C_blockp(t2))?C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
/* srfi-4.scm:419: s16vector-set! */
t7=*((C_word*)lf[25]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t4,((C_word*)t0)[2],t3,t6);}
else{
/* srfi-4.scm:419: ##sys#error-not-a-proper-list */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[57]+1)))(3,*((C_word*)lf[57]+1),t4,((C_word*)t0)[4]);}}}

/* k3760 in k3754 in k3730 in subnvector in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in ... */
static void C_ccall f_3762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3762,2,t0,t1);}
t2=C_string_to_bytevector(t1);
t3=C_a_i_record2(&a,2,((C_word*)t0)[2],t1);
t4=C_fixnum_times(((C_word*)t0)[3],((C_word*)t0)[4]);
t5=C_copy_subvector(t1,((C_word*)t0)[5],C_fix(0),t4,((C_word*)t0)[6]);
t6=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}

/* k2840 in list->s16vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2842,2,t0,t1);}
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2847,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word)li42),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2847(t6,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* k1682 in s16vector-set! */
static void C_ccall f_1684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_u_i_s16vector_set(((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]));}

/* u32vector-set! */
static void C_ccall f_1686(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1686,5,t0,t1,t2,t3,t4);}
t5=C_i_check_structure_2(t2,lf[12],lf[26]);
t6=C_u_i_32vector_length(t2);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1693,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm:133: ##sys#check-integer */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[29]+1)))(4,*((C_word*)lf[29]+1),t7,t4,lf[26]);}

/* u8vector->list in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3063(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3063,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[4],lf[65]);
t4=C_u_i_u8vector_length(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3072,a[2]=t4,a[3]=t2,a[4]=t6,a[5]=((C_word)li60),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3072(t8,t1,C_fix(0));}

/* k1987 in make-u8vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_1989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1989,2,t0,t1);}
t2=C_a_i_record2(&a,2,lf[4],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1957,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[5])){
if(C_truep(((C_word*)t0)[6])){
/* srfi-4.scm:286: set-finalizer! */
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,((C_word*)t0)[7]);}
else{
t5=t4;
f_1957(2,t5,C_SCHEME_UNDEFINED);}}
else{
t5=t4;
f_1957(2,t5,C_SCHEME_UNDEFINED);}}

/* loop in u8vector->list in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_fcall f_3072(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3072,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=C_u_i_u8vector_ref(((C_word*)t0)[3],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3087,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_fixnum_plus(t2,C_fix(1));
/* srfi-4.scm:473: loop */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* doloop402 in k1964 in k1955 in k1987 in make-u8vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static C_word C_fcall f_1971(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_stack_overflow_check;
loop:
if(C_truep(C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[2]))){
return(((C_word*)t0)[3]);}
else{
t2=C_u_i_u8vector_set(((C_word*)t0)[3],t1,((C_word*)t0)[4]);
t3=C_fixnum_plus(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}

/* u8vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3015(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_3015r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3015r(t0,t1,t2);}}

static void C_ccall f_3015r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm:429: list->u8vector */
t3=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* k2876 in list->u32vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2878,2,t0,t1);}
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2883,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word)li44),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2883(t6,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* list->u32vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2871(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2871,3,t0,t1,t2);}
t3=C_i_check_list_2(t2,lf[12]);
t4=C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2878,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm:420: make-u32vector */
t6=((C_word*)t0)[2];
((C_proc3)C_fast_retrieve_proc(t6))(3,t6,t5,t4);}

/* k2349 in k2381 in make-u32vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2351,2,t0,t1);}
if(C_truep(((C_word*)t0)[2])){
t2=C_i_check_exact_2(((C_word*)t0)[2],lf[52]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2365,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word)li28),tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_2365(t3,C_fix(0)));}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* a4235 in k1865 in k1861 in k1857 */
static void C_ccall f_4236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4236,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[10],lf[37]);
t5=C_u_i_s16vector_length(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4264,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=t3;
t8=C_i_check_exact_2(t7,lf[37]);
t9=C_fixnum_less_or_equal_p(C_fix(0),t7);
t10=(C_truep(t9)?C_fixnum_lessp(t7,t5):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_u_i_s16vector_ref(t2,t3));}
else{
t11=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:56: ##sys#error-hook */
((C_proc7)C_fast_retrieve_proc(*((C_word*)lf[20]+1)))(7,*((C_word*)lf[20]+1),t6,t11,lf[37],t7,C_fix(0),t5);}}

/* k4232 in a4205 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_4234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4234,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_u_i_u32vector_ref(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]));}

/* doloop692 in k2876 in list->u32vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_fcall f_2883(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2883,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2890,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_truep(C_blockp(t2))?C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
/* srfi-4.scm:420: u32vector-set! */
t7=*((C_word*)lf[26]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t4,((C_word*)t0)[2],t3,t6);}
else{
/* srfi-4.scm:420: ##sys#error-not-a-proper-list */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[57]+1)))(3,*((C_word*)lf[57]+1),t4,((C_word*)t0)[4]);}}}

/* k2852 in doloop679 in k2840 in list->s16vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_2847(t4,((C_word*)t0)[5],t2,t3);}

/* k3642 in user-print-hook in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in ... */
static void C_ccall f_3644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3644,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3647,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* srfi-4.scm:610: ##sys#print */
t4=*((C_word*)lf[135]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k3645 in k3642 in user-print-hook in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in ... */
static void C_ccall f_3647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3647,2,t0,t1);}
t2=C_i_caddr(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3657,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm:611: g942 */
t4=t2;
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[5]);}

/* f32vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3051(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_3051r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3051r(t0,t1,t2);}}

static void C_ccall f_3051r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm:447: list->f32vector */
t3=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* f64vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3057(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_3057r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3057r(t0,t1,t2);}}

static void C_ccall f_3057r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm:450: list->f64vector */
t3=*((C_word*)lf[64]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* k3085 in loop in u8vector->list in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3087,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* s8vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3021(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_3021r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3021r(t0,t1,t2);}}

static void C_ccall f_3021r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm:432: list->s8vector */
t3=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* u16vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3027(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_3027r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3027r(t0,t1,t2);}}

static void C_ccall f_3027r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm:435: list->u16vector */
t3=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* list->u16vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2799(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2799,3,t0,t1,t2);}
t3=C_i_check_list_2(t2,lf[8]);
t4=C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2806,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm:418: make-u16vector */
t6=((C_word*)t0)[2];
((C_proc3)C_fast_retrieve_proc(t6))(3,t6,t5,t4);}

/* s16vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3033(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_3033r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3033r(t0,t1,t2);}}

static void C_ccall f_3033r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm:438: list->s16vector */
t3=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* k2768 in list->s8vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2770,2,t0,t1);}
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2775,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word)li38),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2775(t6,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* u32vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3039(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_3039r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3039r(t0,t1,t2);}}

static void C_ccall f_3039r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm:441: list->u32vector */
t3=*((C_word*)lf[61]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* ##sys#user-print-hook in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in k3485 in ... */
static void C_ccall f_3632(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[102],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3632,5,t0,t1,t2,t3,t4);}
t5=C_slot(t2,C_fix(0));
t6=C_a_i_list(&a,3,lf[4],lf[121],*((C_word*)lf[65]+1));
t7=C_a_i_list(&a,3,lf[6],lf[122],*((C_word*)lf[66]+1));
t8=C_a_i_list(&a,3,lf[8],lf[123],*((C_word*)lf[67]+1));
t9=C_a_i_list(&a,3,lf[10],lf[124],*((C_word*)lf[68]+1));
t10=C_a_i_list(&a,3,lf[12],lf[125],*((C_word*)lf[69]+1));
t11=C_a_i_list(&a,3,lf[14],lf[126],*((C_word*)lf[70]+1));
t12=C_a_i_list(&a,3,lf[16],lf[127],*((C_word*)lf[71]+1));
t13=C_a_i_list(&a,3,lf[18],lf[128],*((C_word*)lf[72]+1));
t14=C_a_i_list(&a,8,t6,t7,t8,t9,t10,t11,t12,t13);
t15=C_u_i_assq(t5,t14);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3644,a[2]=t15,a[3]=t1,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm:609: ##sys#print */
t17=*((C_word*)lf[135]+1);
((C_proc5)(void*)(*((C_word*)t17+1)))(5,t17,t16,C_make_character(35),C_SCHEME_FALSE,t4);}
else{
/* srfi-4.scm:612: old-hook */
t16=((C_word*)t0)[2];
((C_proc5)C_fast_retrieve_proc(t16))(5,t16,t1,t2,t3,t4);}}

/* k3655 in k3645 in k3642 in user-print-hook in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in ... */
static void C_ccall f_3657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm:611: ##sys#print */
t2=*((C_word*)lf[135]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_TRUE,((C_word*)t0)[3]);}

/* g926 in k3579 in user-read-hook in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in ... */
static void C_fcall f_3600(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3600,NULL,3,t0,t1,t2);}
t3=C_slot(t2,C_fix(1));
t4=C_slot(t3,C_fix(0));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3611,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm:589: read */
t7=*((C_word*)lf[131]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[2]);}

/* k3609 in g926 in k3579 in user-read-hook in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in ... */
static void C_ccall f_3611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm:589: g929 */
t2=((C_word*)t0)[2];
((C_proc3)C_fast_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],t1);}

/* a4115 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_4116(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4116,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[18],lf[41]);
t5=C_u_i_f64vector_length(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4144,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=t3;
t8=C_i_check_exact_2(t7,lf[41]);
t9=C_fixnum_less_or_equal_p(C_fix(0),t7);
t10=(C_truep(t9)?C_fixnum_lessp(t7,t5):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_a_u_i_f64vector_ref(&a,2,t2,t3));}
else{
t11=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:56: ##sys#error-hook */
((C_proc7)C_fast_retrieve_proc(*((C_word*)lf[20]+1)))(7,*((C_word*)lf[20]+1),t6,t11,lf[41],t7,C_fix(0),t5);}}

/* k4112 in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in k3485 in ... */
static void C_ccall f_4114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* s8vector-length */
static void C_ccall f_1494(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1494,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[6],lf[5]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_u_i_8vector_length(t2));}

/* k4055 in read-u8vector in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in ... */
static void C_ccall f_4057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4057,2,t0,t1);}
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4062,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word)li114),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_4062(t6,((C_word*)t0)[4]);}

/* u8vector-length */
static void C_ccall f_1488(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1488,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[4],lf[3]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_u_i_8vector_length(t2));}

/* k4202 in a4175 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_4204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4204,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_u_i_s32vector_ref(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]));}

/* a4205 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_4206(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4206,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[12],lf[38]);
t5=C_u_i_u32vector_length(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4234,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=t3;
t8=C_i_check_exact_2(t7,lf[38]);
t9=C_fixnum_less_or_equal_p(C_fix(0),t7);
t10=(C_truep(t9)?C_fixnum_lessp(t7,t5):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_a_u_i_u32vector_ref(&a,2,t2,t3));}
else{
t11=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:56: ##sys#error-hook */
((C_proc7)C_fast_retrieve_proc(*((C_word*)lf[20]+1)))(7,*((C_word*)lf[20]+1),t6,t11,lf[38],t7,C_fix(0),t5);}}

/* s32vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3045(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_3045r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3045r(t0,t1,t2);}}

static void C_ccall f_3045r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm:444: list->s32vector */
t3=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* k4037 in read-u8vector in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in ... */
static void C_ccall f_4039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4039,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4042,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm:676: ##sys#read-string! */
((C_proc6)C_fast_retrieve_proc(*((C_word*)lf[150]+1)))(6,*((C_word*)lf[150]+1),t3,((C_word*)t0)[2],t2,((C_word*)t0)[5],C_fix(0));}

/* doloop640 in k2732 in list->u8vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_fcall f_2739(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2739,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2746,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_truep(C_blockp(t2))?C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
/* srfi-4.scm:416: u8vector-set! */
t7=*((C_word*)lf[19]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t4,((C_word*)t0)[2],t3,t6);}
else{
/* srfi-4.scm:416: ##sys#error-not-a-proper-list */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[57]+1)))(3,*((C_word*)lf[57]+1),t4,((C_word*)t0)[4]);}}}

/* k2732 in list->u8vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2734,2,t0,t1);}
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2739,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word)li36),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2739(t6,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* k3730 in subnvector in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in ... */
static void C_ccall f_3732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3732,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3756,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_fixnum_plus(((C_word*)t0)[8],C_fix(1));
t4=((C_word*)t0)[2];
t5=((C_word*)t0)[9];
t6=C_i_check_exact_2(t4,t5);
t7=C_fixnum_less_or_equal_p(C_fix(0),t4);
t8=(C_truep(t7)?C_fixnum_lessp(t4,t3):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=C_SCHEME_UNDEFINED;
t10=t2;
f_3756(2,t10,t9);}
else{
t9=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:56: ##sys#error-hook */
((C_proc7)C_fast_retrieve_proc(*((C_word*)lf[20]+1)))(7,*((C_word*)lf[20]+1),t2,t9,t5,t4,C_fix(0),t3);}}

/* k2744 in doloop640 in k2732 in list->u8vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_2739(t4,((C_word*)t0)[5],t2,t3);}

/* k4040 in k4037 in read-u8vector in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in ... */
static void C_ccall f_4042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4042,2,t0,t1);}
t2=C_string_to_bytevector(((C_word*)t0)[2]);
t3=C_eqp(((C_word*)t0)[3],t1);
if(C_truep(t3)){
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record2(&a,2,lf[4],((C_word*)t0)[2]));}
else{
/* srfi-4.scm:680: wrap */
f_4005(((C_word*)t0)[4],((C_word*)t0)[2],t1);}}

/* k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in k3485 in k3481 in k3477 in k3473 in ... */
static void C_ccall f_3559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3559,2,t0,t1);}
t2=C_mutate2((C_word*)lf[117]+1 /* (set! blob->s32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3563,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:567: unpack-copy */
f_3407(t3,lf[16],C_fix(4),lf[118]);}

/* k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in k3485 in k3481 in k3477 in k3473 in k1885 in ... */
static void C_ccall f_3555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3555,2,t0,t1);}
t2=C_mutate2((C_word*)lf[116]+1 /* (set! blob->u32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3559,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:566: unpack-copy */
f_3407(t3,lf[14],C_fix(4),lf[117]);}

/* k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in k3485 in k3481 in k3477 in k3473 in k1885 in k1881 in ... */
static void C_ccall f_3551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3551,2,t0,t1);}
t2=C_mutate2((C_word*)lf[115]+1 /* (set! blob->s16vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3555,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:565: unpack-copy */
f_3407(t3,lf[12],C_fix(4),lf[116]);}

/* k2780 in doloop653 in k2768 in list->s8vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_2775(t4,((C_word*)t0)[5],t2,t3);}

/* ##sys#check-exact-interval */
static void C_fcall f_1473(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1473,NULL,5,t1,t2,t3,t4,t5);}
t6=C_i_check_exact_2(t2,t5);
t7=C_fixnum_lessp(t2,t3);
t8=(C_truep(t7)?t7:C_fixnum_greaterp(t2,t4));
if(C_truep(t8)){
/* srfi-4.scm:51: ##sys#error */
t9=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t9+1)))(7,t9,t1,t5,lf[2],t2,t3,t4);}
else{
t9=C_SCHEME_UNDEFINED;
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}}

/* doloop653 in k2768 in list->s8vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_fcall f_2775(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2775,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2782,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_truep(C_blockp(t2))?C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
/* srfi-4.scm:417: s8vector-set! */
t7=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t4,((C_word*)t0)[2],t3,t6);}
else{
/* srfi-4.scm:417: ##sys#error-not-a-proper-list */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[57]+1)))(3,*((C_word*)lf[57]+1),t4,((C_word*)t0)[4]);}}}

/* k2480 in make-s32vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2482,2,t0,t1);}
t2=C_a_i_record2(&a,2,lf[14],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2450,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[5])){
if(C_truep(((C_word*)t0)[6])){
/* srfi-4.scm:351: set-finalizer! */
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,((C_word*)t0)[7]);}
else{
t5=t4;
f_2450(2,t5,C_SCHEME_UNDEFINED);}}
else{
t5=t4;
f_2450(2,t5,C_SCHEME_UNDEFINED);}}

/* k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in k3485 in k3481 in ... */
static void C_ccall f_3567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[100],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3567,2,t0,t1);}
t2=C_mutate2((C_word*)lf[119]+1 /* (set! blob->f64vector ...) */,t1);
t3=*((C_word*)lf[120]+1);
t4=C_a_i_list(&a,16,lf[121],*((C_word*)lf[56]+1),lf[122],*((C_word*)lf[58]+1),lf[123],*((C_word*)lf[59]+1),lf[124],*((C_word*)lf[60]+1),lf[125],*((C_word*)lf[61]+1),lf[126],*((C_word*)lf[62]+1),lf[127],*((C_word*)lf[63]+1),lf[128],*((C_word*)lf[64]+1));
t5=t4;
t6=C_mutate2((C_word*)lf[120]+1 /* (set! ##sys#user-read-hook ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3572,a[2]=t5,a[3]=t3,a[4]=((C_word)li99),tmp=(C_word)a,a+=5,tmp));
t7=*((C_word*)lf[134]+1);
t8=C_mutate2((C_word*)lf[134]+1 /* (set! ##sys#user-print-hook ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3632,a[2]=t7,a[3]=((C_word)li100),tmp=(C_word)a,a+=4,tmp));
t9=C_mutate2(&lf[136] /* (set! subnvector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3698,a[2]=((C_word)li101),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate2((C_word*)lf[137]+1 /* (set! subu8vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3783,a[2]=((C_word)li102),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate2((C_word*)lf[138]+1 /* (set! subu16vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3789,a[2]=((C_word)li103),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate2((C_word*)lf[139]+1 /* (set! subu32vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3795,a[2]=((C_word)li104),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate2((C_word*)lf[140]+1 /* (set! subs8vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3801,a[2]=((C_word)li105),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate2((C_word*)lf[141]+1 /* (set! subs16vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3807,a[2]=((C_word)li106),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate2((C_word*)lf[142]+1 /* (set! subs32vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3813,a[2]=((C_word)li107),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate2((C_word*)lf[143]+1 /* (set! subf32vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3819,a[2]=((C_word)li108),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate2((C_word*)lf[144]+1 /* (set! subf64vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3825,a[2]=((C_word)li109),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate2((C_word*)lf[145]+1 /* (set! write-u8vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3831,a[2]=((C_word)li111),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate2((C_word*)lf[148]+1 /* (set! read-u8vector! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3924,a[2]=((C_word)li112),tmp=(C_word)a,a+=3,tmp));
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4005,a[2]=((C_word)li113),tmp=(C_word)a,a+=3,tmp);
t21=C_mutate2((C_word*)lf[151]+1 /* (set! read-u8vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4014,a[2]=t20,a[3]=((C_word)li115),tmp=(C_word)a,a+=4,tmp));
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4114,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:693: register-feature! */
t23=*((C_word*)lf[156]+1);
((C_proc3)(void*)(*((C_word*)t23+1)))(3,t23,t22,lf[157]);}

/* k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in k3485 in k3481 in k3477 in ... */
static void C_ccall f_3563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3563,2,t0,t1);}
t2=C_mutate2((C_word*)lf[118]+1 /* (set! blob->f32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3567,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:568: unpack-copy */
f_3407(t3,lf[18],C_fix(8),lf[119]);}

/* make-u32vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2323(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_2323r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2323r(t0,t1,t2,t3);}}

static void C_ccall f_2323r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a=C_alloc(8);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=t5;
t7=C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_FALSE:C_i_car(t8));
t11=t10;
t12=C_i_nullp(t8);
t13=(C_truep(t12)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t14=C_i_nullp(t13);
t15=(C_truep(t14)?C_SCHEME_TRUE:C_i_car(t13));
t16=t15;
t17=C_i_nullp(t13);
t18=(C_truep(t17)?C_SCHEME_END_OF_LIST:C_i_cdr(t13));
t19=C_i_check_exact_2(t2,lf[52]);
t20=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2383,a[2]=t6,a[3]=t2,a[4]=t1,a[5]=t11,a[6]=t16,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t21=C_fixnum_shift_left(t2,C_fix(2));
/* srfi-4.scm:337: alloc */
f_1896(t20,lf[52],t21,t11);}

/* k2816 in doloop666 in k2804 in list->u16vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_2811(t4,((C_word*)t0)[5],t2,t3);}

/* loop in s8vector->list in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_fcall f_3102(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3102,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=C_u_i_s8vector_ref(((C_word*)t0)[3],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3117,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_fixnum_plus(t2,C_fix(1));
/* srfi-4.scm:474: loop */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* doloop666 in k2804 in list->u16vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_fcall f_2811(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2811,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2818,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_truep(C_blockp(t2))?C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
/* srfi-4.scm:418: u16vector-set! */
t7=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t4,((C_word*)t0)[2],t3,t6);}
else{
/* srfi-4.scm:418: ##sys#error-not-a-proper-list */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[57]+1)))(3,*((C_word*)lf[57]+1),t4,((C_word*)t0)[4]);}}}

/* doloop547 in k2448 in k2480 in make-s32vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static C_word C_fcall f_2464(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_stack_overflow_check;
loop:
if(C_truep(C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[2]))){
return(((C_word*)t0)[3]);}
else{
t2=C_u_i_s32vector_set(((C_word*)t0)[3],t1,((C_word*)t0)[4]);
t3=C_fixnum_plus(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}

/* doloop705 in k2912 in list->s32vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_fcall f_2919(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2919,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2926,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_truep(C_blockp(t2))?C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
/* srfi-4.scm:421: s32vector-set! */
t7=*((C_word*)lf[30]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t4,((C_word*)t0)[2],t3,t6);}
else{
/* srfi-4.scm:421: ##sys#error-not-a-proper-list */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[57]+1)))(3,*((C_word*)lf[57]+1),t4,((C_word*)t0)[4]);}}}

/* k2804 in list->u16vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2806,2,t0,t1);}
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2811,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word)li40),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2811(t6,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* k3115 in loop in s8vector->list in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3117,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k2912 in list->s32vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2914,2,t0,t1);}
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2919,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word)li46),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2919(t6,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* list->s8vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2763(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2763,3,t0,t1,t2);}
t3=C_i_check_list_2(t2,lf[6]);
t4=C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2770,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm:417: make-s8vector */
t6=((C_word*)t0)[2];
((C_proc3)C_fast_retrieve_proc(t6))(3,t6,t5,t4);}

/* list->s32vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2907(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2907,3,t0,t1,t2);}
t3=C_i_check_list_2(t2,lf[14]);
t4=C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2914,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm:421: make-s32vector */
t6=((C_word*)t0)[2];
((C_proc3)C_fast_retrieve_proc(t6))(3,t6,t5,t4);}

/* u16vector->list in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3123(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3123,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[8],lf[67]);
t4=C_u_i_u16vector_length(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3132,a[2]=t4,a[3]=t2,a[4]=t6,a[5]=((C_word)li64),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3132(t8,t1,C_fix(0));}

/* loop in u16vector->list in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_fcall f_3132(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3132,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=C_u_i_u16vector_ref(((C_word*)t0)[3],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3147,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_fixnum_plus(t2,C_fix(1));
/* srfi-4.scm:475: loop */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* k3493 in k3489 in k3485 in k3481 in k3477 in k3473 in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3495,2,t0,t1);}
t2=C_mutate2((C_word*)lf[101]+1 /* (set! s32vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3499,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:549: pack-copy */
f_3359(t3,lf[16],lf[102]);}

/* k3497 in k3493 in k3489 in k3485 in k3481 in k3477 in k3473 in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3499,2,t0,t1);}
t2=C_mutate2((C_word*)lf[102]+1 /* (set! f32vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3503,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:550: pack-copy */
f_3359(t3,lf[18],lf[103]);}

/* k3489 in k3485 in k3481 in k3477 in k3473 in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3491,2,t0,t1);}
t2=C_mutate2((C_word*)lf[100]+1 /* (set! u32vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3495,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:548: pack-copy */
f_3359(t3,lf[14],lf[101]);}

/* k2924 in doloop705 in k2912 in list->s32vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_2919(t4,((C_word*)t0)[5],t2,t3);}

/* read-u8vector in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in k3485 in ... */
static void C_ccall f_4014(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_4014r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4014r(t0,t1,t2);}}

static void C_ccall f_4014r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a=C_alloc(6);
t3=C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:C_i_car(t2));
t5=t4;
t6=C_i_nullp(t2);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:C_i_cdr(t2));
t8=C_i_nullp(t7);
t9=(C_truep(t8)?*((C_word*)lf[149]+1):C_i_car(t7));
t10=t9;
t11=C_i_nullp(t7);
t12=(C_truep(t11)?C_SCHEME_END_OF_LIST:C_i_cdr(t7));
t13=C_i_check_port_2(t10,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[151]);
if(C_truep(t5)){
t14=C_i_check_exact_2(t5,lf[151]);
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4039,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t10,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm:675: ##sys#allocate-vector */
t16=*((C_word*)lf[43]+1);
((C_proc6)(void*)(*((C_word*)t16+1)))(6,t16,t15,t5,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}
else{
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4057,a[2]=((C_word*)t0)[2],a[3]=t10,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm:682: open-output-string */
t15=*((C_word*)lf[155]+1);
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,t14);}}

/* k4011 in wrap in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in ... */
static void C_ccall f_4013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4013,2,t0,t1);}
t2=C_string_to_bytevector(t1);
t3=C_substring_copy(((C_word*)t0)[2],t1,C_fix(0),((C_word*)t0)[3],C_fix(0));
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record2(&a,2,lf[4],t1));}

/* s16vector->list in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3153(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3153,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[10],lf[68]);
t4=C_u_i_s16vector_length(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3162,a[2]=t4,a[3]=t2,a[4]=t6,a[5]=((C_word)li66),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3162(t8,t1,C_fix(0));}

/* k3145 in loop in u16vector->list in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3147,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* wrap in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in k3485 in ... */
static void C_fcall f_4005(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4005,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4013,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm:668: ##sys#allocate-vector */
t5=*((C_word*)lf[43]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,t3,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* ##sys#user-read-hook in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in k3485 in ... */
static void C_ccall f_3572(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3572,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_truep(C_eqp(t4,C_make_character(117)))?C_SCHEME_TRUE:(C_truep(C_eqp(t4,C_make_character(115)))?C_SCHEME_TRUE:(C_truep(C_eqp(t4,C_make_character(102)))?C_SCHEME_TRUE:(C_truep(C_eqp(t4,C_make_character(85)))?C_SCHEME_TRUE:(C_truep(C_eqp(t4,C_make_character(83)))?C_SCHEME_TRUE:(C_truep(C_eqp(t4,C_make_character(70)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3581,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm:586: read */
t6=*((C_word*)lf[131]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
/* srfi-4.scm:591: old-hook */
t5=((C_word*)t0)[3];
((C_proc4)C_fast_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* a4175 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_4176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4176,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[14],lf[39]);
t5=C_u_i_s32vector_length(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4204,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=t3;
t8=C_i_check_exact_2(t7,lf[39]);
t9=C_fixnum_less_or_equal_p(C_fix(0),t7);
t10=(C_truep(t9)?C_fixnum_lessp(t7,t5):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_a_u_i_s32vector_ref(&a,2,t2,t3));}
else{
t11=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:56: ##sys#error-hook */
((C_proc7)C_fast_retrieve_proc(*((C_word*)lf[20]+1)))(7,*((C_word*)lf[20]+1),t6,t11,lf[39],t7,C_fix(0),t5);}}

/* k4172 in a4145 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_4174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4174,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_u_i_f32vector_ref(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]));}

/* k3579 in user-read-hook in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in ... */
static void C_ccall f_3581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3581,2,t0,t1);}
t2=C_i_symbolp(t1);
t3=(C_truep(t2)?t1:C_SCHEME_FALSE);
t4=C_eqp(t3,lf[129]);
t5=(C_truep(t4)?t4:C_eqp(t3,lf[130]));
if(C_truep(t5)){
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=C_i_memq(t3,((C_word*)t0)[3]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3600,a[2]=((C_word*)t0)[4],a[3]=((C_word)li98),tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm:586: g926 */
t8=t7;
f_3600(t8,((C_word*)t0)[2],t6);}
else{
/* srfi-4.scm:590: ##sys#read-error */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[132]+1)))(5,*((C_word*)lf[132]+1),((C_word*)t0)[2],((C_word*)t0)[4],lf[133],t3);}}}

/* k3417 */
static void C_ccall f_3419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3419,2,t0,t1);}
t2=t1;
t3=C_eqp(C_SCHEME_TRUE,((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3428,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t5=t4;
f_3428(t5,t3);}
else{
t5=C_fixnum_modulo(((C_word*)t0)[7],((C_word*)t0)[2]);
t6=t4;
f_3428(t6,C_eqp(C_fix(0),t5));}}

/* k2686 in make-f64vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2688,2,t0,t1);}
t2=C_a_i_record2(&a,2,lf[18],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2652,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[5])){
if(C_truep(((C_word*)t0)[6])){
/* srfi-4.scm:381: set-finalizer! */
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,((C_word*)t0)[7]);}
else{
t5=t4;
f_2652(2,t5,C_SCHEME_UNDEFINED);}}
else{
t5=t4;
f_2652(2,t5,C_SCHEME_UNDEFINED);}}

/* k2960 in doloop718 in k2948 in list->f32vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_2955(t4,((C_word*)t0)[5],t2,t3);}

/* k2448 in k2480 in make-s32vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2450,2,t0,t1);}
if(C_truep(((C_word*)t0)[2])){
t2=C_i_check_exact_2(((C_word*)t0)[2],lf[53]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2464,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word)li30),tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_2464(t3,C_fix(0)));}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* k2381 in make-u32vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2383,2,t0,t1);}
t2=C_a_i_record2(&a,2,lf[12],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2351,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[5])){
if(C_truep(((C_word*)t0)[6])){
/* srfi-4.scm:338: set-finalizer! */
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,((C_word*)t0)[7]);}
else{
t5=t4;
f_2351(2,t5,C_SCHEME_UNDEFINED);}}
else{
t5=t4;
f_2351(2,t5,C_SCHEME_UNDEFINED);}}

/* k3426 in k3417 */
static void C_fcall f_3428(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3428,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_copy_block(((C_word*)t0)[2],((C_word*)t0)[3]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record2(&a,2,((C_word*)t0)[5],t2));}
else{
/* srfi-4.scm:532: ##sys#error */
t2=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],((C_word*)t0)[6],lf[87],((C_word*)t0)[5],((C_word*)t0)[7],((C_word*)t0)[8]);}}

/* a4325 */
static void C_ccall f_4326(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4326,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[4],lf[34]);
t5=C_u_i_s8vector_length(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4354,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=t3;
t8=C_i_check_exact_2(t7,lf[34]);
t9=C_fixnum_less_or_equal_p(C_fix(0),t7);
t10=(C_truep(t9)?C_fixnum_lessp(t7,t5):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_u_i_u8vector_ref(t2,t3));}
else{
t11=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:56: ##sys#error-hook */
((C_proc7)C_fast_retrieve_proc(*((C_word*)lf[20]+1)))(7,*((C_word*)lf[20]+1),t6,t11,lf[34],t7,C_fix(0),t5);}}

/* k4322 in a4295 in k1857 */
static void C_ccall f_4324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_u_i_s8vector_ref(((C_word*)t0)[3],((C_word*)t0)[4]));}

/* s8vector-set! */
static void C_ccall f_1578(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1578,5,t0,t1,t2,t3,t4);}
t5=C_i_check_structure_2(t2,lf[6],lf[22]);
t6=C_u_i_8vector_length(t2);
t7=C_i_check_exact_2(t4,lf[22]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1609,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t9=t3;
t10=C_i_check_exact_2(t9,lf[22]);
t11=C_fixnum_less_or_equal_p(C_fix(0),t9);
t12=(C_truep(t11)?C_fixnum_lessp(t9,t6):C_SCHEME_FALSE);
if(C_truep(t12)){
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_u_i_s8vector_set(t2,t3,t4));}
else{
t13=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:56: ##sys#error-hook */
((C_proc7)C_fast_retrieve_proc(*((C_word*)lf[20]+1)))(7,*((C_word*)lf[20]+1),t8,t13,lf[22],t9,C_fix(0),t6);}}

/* k1568 in k1544 in u8vector-set! */
static void C_ccall f_1570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_u_i_u8vector_set(((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]));}

/* k2662 in k2650 in k2686 in make-f64vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_fcall f_2664(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2664,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2669,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li34),tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2669(t2,C_fix(0)));}

/* list->f32vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2943(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2943,3,t0,t1,t2);}
t3=C_i_check_list_2(t2,lf[16]);
t4=C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2950,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm:422: make-f32vector */
t6=((C_word*)t0)[2];
((C_proc3)C_fast_retrieve_proc(t6))(3,t6,t5,t4);}

/* doloop606 in k2662 in k2650 in k2686 in make-f64vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static C_word C_fcall f_2669(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_stack_overflow_check;
loop:
if(C_truep(C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[2]))){
return(((C_word*)t0)[3]);}
else{
t2=C_u_i_f64vector_set(((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[4])[1]);
t3=C_fixnum_plus(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}

/* doloop518 in k2349 in k2381 in make-u32vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static C_word C_fcall f_2365(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_stack_overflow_check;
loop:
if(C_truep(C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[2]))){
return(((C_word*)t0)[3]);}
else{
t2=C_u_i_u32vector_set(((C_word*)t0)[3],t1,((C_word*)t0)[4]);
t3=C_fixnum_plus(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}

/* doloop718 in k2948 in list->f32vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_fcall f_2955(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2955,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2962,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_truep(C_blockp(t2))?C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
/* srfi-4.scm:422: f32vector-set! */
t7=*((C_word*)lf[32]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t4,((C_word*)t0)[2],t3,t6);}
else{
/* srfi-4.scm:422: ##sys#error-not-a-proper-list */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[57]+1)))(3,*((C_word*)lf[57]+1),t4,((C_word*)t0)[4]);}}}

/* k1718 in k1694 in k1691 in u32vector-set! */
static void C_ccall f_1720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_u_i_u32vector_set(((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]));}

/* k2948 in list->f32vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2950,2,t0,t1);}
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2955,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word)li48),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2955(t6,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* make-s32vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2422(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_2422r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2422r(t0,t1,t2,t3);}}

static void C_ccall f_2422r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a=C_alloc(8);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=t5;
t7=C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_FALSE:C_i_car(t8));
t11=t10;
t12=C_i_nullp(t8);
t13=(C_truep(t12)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t14=C_i_nullp(t13);
t15=(C_truep(t14)?C_SCHEME_TRUE:C_i_car(t13));
t16=t15;
t17=C_i_nullp(t13);
t18=(C_truep(t17)?C_SCHEME_END_OF_LIST:C_i_cdr(t13));
t19=C_i_check_exact_2(t2,lf[53]);
t20=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2482,a[2]=t6,a[3]=t2,a[4]=t1,a[5]=t11,a[6]=t16,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t21=C_fixnum_shift_left(t2,C_fix(2));
/* srfi-4.scm:350: alloc */
f_1896(t20,lf[53],t21,t11);}

/* k3477 in k3473 in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3479,2,t0,t1);}
t2=C_mutate2((C_word*)lf[97]+1 /* (set! s8vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3483,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:545: pack-copy */
f_3359(t3,lf[8],lf[98]);}

/* k3473 in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3475,2,t0,t1);}
t2=C_mutate2((C_word*)lf[96]+1 /* (set! u8vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3479,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:544: pack-copy */
f_3359(t3,lf[6],lf[97]);}

/* k3485 in k3481 in k3477 in k3473 in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3487,2,t0,t1);}
t2=C_mutate2((C_word*)lf[99]+1 /* (set! s16vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3491,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:547: pack-copy */
f_3359(t3,lf[12],lf[100]);}

/* k3481 in k3477 in k3473 in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3483,2,t0,t1);}
t2=C_mutate2((C_word*)lf[98]+1 /* (set! u16vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3487,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:546: pack-copy */
f_3359(t3,lf[10],lf[99]);}

/* subf32vector in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in k3485 in ... */
static void C_ccall f_3819(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3819,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm:639: subnvector */
f_3698(t1,t2,lf[16],C_fix(4),t3,t4,lf[143]);}

/* subs32vector in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in k3485 in ... */
static void C_ccall f_3813(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3813,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm:638: subnvector */
f_3698(t1,t2,lf[14],C_fix(4),t3,t4,lf[142]);}

/* s32vector-set! */
static void C_ccall f_1741(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1741,5,t0,t1,t2,t3,t4);}
t5=C_i_check_structure_2(t2,lf[14],lf[30]);
t6=C_u_i_32vector_length(t2);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1748,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm:144: ##sys#check-integer */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[29]+1)))(4,*((C_word*)lf[29]+1),t7,t4,lf[30]);}

/* k1746 in s32vector-set! */
static void C_ccall f_1748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1748,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1751,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_fits_in_int_p(((C_word*)t0)[5]))){
t3=t2;
f_1751(2,t3,C_SCHEME_UNDEFINED);}
else{
/* srfi-4.scm:146: ##sys#error */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[30],lf[31],((C_word*)t0)[5]);}}

/* a4295 in k1857 */
static void C_ccall f_4296(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4296,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[6],lf[35]);
t5=C_u_i_s8vector_length(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4324,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=t3;
t8=C_i_check_exact_2(t7,lf[35]);
t9=C_fixnum_less_or_equal_p(C_fix(0),t7);
t10=(C_truep(t9)?C_fixnum_lessp(t7,t5):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_u_i_s8vector_ref(t2,t3));}
else{
t11=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:56: ##sys#error-hook */
((C_proc7)C_fast_retrieve_proc(*((C_word*)lf[20]+1)))(7,*((C_word*)lf[20]+1),t6,t11,lf[35],t7,C_fix(0),t5);}}

/* k4292 in a4265 in k1861 in k1857 */
static void C_ccall f_4294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_u_i_u16vector_ref(((C_word*)t0)[3],((C_word*)t0)[4]));}

/* a4265 in k1861 in k1857 */
static void C_ccall f_4266(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4266,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[8],lf[36]);
t5=C_u_i_s16vector_length(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4294,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=t3;
t8=C_i_check_exact_2(t7,lf[36]);
t9=C_fixnum_less_or_equal_p(C_fix(0),t7);
t10=(C_truep(t9)?C_fixnum_lessp(t7,t5):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_u_i_u16vector_ref(t2,t3));}
else{
t11=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:56: ##sys#error-hook */
((C_proc7)C_fast_retrieve_proc(*((C_word*)lf[20]+1)))(7,*((C_word*)lf[20]+1),t6,t11,lf[36],t7,C_fix(0),t5);}}

/* k4262 in a4235 in k1865 in k1861 in k1857 */
static void C_ccall f_4264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_u_i_s16vector_ref(((C_word*)t0)[3],((C_word*)t0)[4]));}

/* list->f64vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2979(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2979,3,t0,t1,t2);}
t3=C_i_check_list_2(t2,lf[18]);
t4=C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2986,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm:423: make-f64vector */
t6=((C_word*)t0)[2];
((C_proc3)C_fast_retrieve_proc(t6))(3,t6,t5,t4);}

/* make-f64vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2624(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_2624r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2624r(t0,t1,t2,t3);}}

static void C_ccall f_2624r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a=C_alloc(10);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_i_nullp(t3);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t10=C_i_nullp(t9);
t11=(C_truep(t10)?C_SCHEME_FALSE:C_i_car(t9));
t12=t11;
t13=C_i_nullp(t9);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:C_i_cdr(t9));
t15=C_i_nullp(t14);
t16=(C_truep(t15)?C_SCHEME_TRUE:C_i_car(t14));
t17=t16;
t18=C_i_nullp(t14);
t19=(C_truep(t18)?C_SCHEME_END_OF_LIST:C_i_cdr(t14));
t20=C_i_check_exact_2(t2,lf[55]);
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2688,a[2]=t7,a[3]=t2,a[4]=t1,a[5]=t12,a[6]=t17,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t22=C_fixnum_shift_left(t2,C_fix(3));
/* srfi-4.scm:380: alloc */
f_1896(t21,lf[55],t22,t12);}

/* k1749 in k1746 in s32vector-set! */
static void C_ccall f_1751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1751,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1775,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[4];
t4=C_i_check_exact_2(t3,lf[30]);
t5=C_fixnum_less_or_equal_p(C_fix(0),t3);
t6=(C_truep(t5)?C_fixnum_lessp(t3,((C_word*)t0)[6]):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_u_i_s32vector_set(((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]));}
else{
t7=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:56: ##sys#error-hook */
((C_proc7)C_fast_retrieve_proc(*((C_word*)lf[20]+1)))(7,*((C_word*)lf[20]+1),t2,t7,lf[30],t3,C_fix(0),((C_word*)t0)[6]);}}

/* f32vector-set! */
static void C_ccall f_1783(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1783,5,t0,t1,t2,t3,t4);}
t5=C_i_check_structure_2(t2,lf[16],lf[32]);
t6=C_u_i_32vector_length(t2);
t7=C_i_check_number_2(t4,lf[32]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1814,a[2]=t4,a[3]=t1,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t9=t3;
t10=C_i_check_exact_2(t9,lf[32]);
t11=C_fixnum_less_or_equal_p(C_fix(0),t9);
t12=(C_truep(t11)?C_fixnum_lessp(t9,t6):C_SCHEME_FALSE);
if(C_truep(t12)){
t13=C_SCHEME_UNDEFINED;
t14=t8;
f_1814(2,t14,t13);}
else{
t13=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:56: ##sys#error-hook */
((C_proc7)C_fast_retrieve_proc(*((C_word*)lf[20]+1)))(7,*((C_word*)lf[20]+1),t8,t13,lf[32],t9,C_fix(0),t6);}}

/* k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in k3485 in k3481 in k3477 in k3473 in k1885 in k1881 in k1877 in k1873 in ... */
static void C_ccall f_3543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3543,2,t0,t1);}
t2=C_mutate2((C_word*)lf[113]+1 /* (set! blob->s8vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3547,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:563: unpack-copy */
f_3407(t3,lf[8],C_fix(2),lf[114]);}

/* f_3409 in unpack-copy in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3409(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3409,3,t0,t1,t2);}
t3=C_i_check_bytevector_2(t2,((C_word*)t0)[2]);
t4=C_block_size(t2);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3419,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[2],a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm:526: ##sys#make-blob */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[83]+1)))(3,*((C_word*)lf[83]+1),t6,t5);}

/* k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in k3485 in k3481 in k3477 in k3473 in k1885 in k1881 in k1877 in ... */
static void C_ccall f_3547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3547,2,t0,t1);}
t2=C_mutate2((C_word*)lf[114]+1 /* (set! blob->u16vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3551,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:564: unpack-copy */
f_3407(t3,lf[10],C_fix(2),lf[115]);}

/* unpack-copy in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_fcall f_3407(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3407,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3409,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=((C_word)li88),tmp=(C_word)a,a+=6,tmp));}

/* k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in k3485 in k3481 in k3477 in k3473 in k1885 in k1881 in k1877 in k1873 in k1869 in ... */
static void C_ccall f_3539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3539,2,t0,t1);}
t2=C_mutate2((C_word*)lf[112]+1 /* (set! blob->u8vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3543,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:562: unpack-copy */
f_3407(t3,lf[6],C_SCHEME_TRUE,lf[113]);}

/* k1773 in k1749 in k1746 in s32vector-set! */
static void C_ccall f_1775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_u_i_s32vector_set(((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]));}

/* make-u8vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_1929(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_1929r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1929r(t0,t1,t2,t3);}}

static void C_ccall f_1929r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a=C_alloc(8);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=t5;
t7=C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_FALSE:C_i_car(t8));
t11=t10;
t12=C_i_nullp(t8);
t13=(C_truep(t12)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t14=C_i_nullp(t13);
t15=(C_truep(t14)?C_SCHEME_TRUE:C_i_car(t13));
t16=t15;
t17=C_i_nullp(t13);
t18=(C_truep(t17)?C_SCHEME_END_OF_LIST:C_i_cdr(t13));
t19=C_i_check_exact_2(t2,lf[47]);
t20=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1989,a[2]=t6,a[3]=t2,a[4]=t1,a[5]=t11,a[6]=t16,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm:285: alloc */
f_1896(t20,lf[47],t2,t11);}

/* k1919 in release-number-vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_1921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub367(C_SCHEME_UNDEFINED,t3));}
else{
/* srfi-4.scm:280: ##sys#error */
t2=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[44],lf[45],((C_word*)t0)[3]);}}

/* k4352 in a4325 */
static void C_ccall f_4354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_u_i_u8vector_ref(((C_word*)t0)[3],((C_word*)t0)[4]));}

/* ext-free in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_1894(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1894,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,stub367(C_SCHEME_UNDEFINED,t2));}

/* alloc in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_fcall f_1896(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1896,NULL,4,t1,t2,t3,t4);}
if(C_truep(t4)){
t5=t3;
t6=C_i_foreign_fixnum_argumentp(t5);
t7=stub362(C_SCHEME_UNDEFINED,t6);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
/* srfi-4.scm:271: ##sys#error */
t8=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,t2,lf[42],t3);}}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1912,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:272: ##sys#allocate-vector */
t6=*((C_word*)lf[43]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,t3,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}}

/* k3393 */
static void C_fcall f_3395(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3395,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_record2(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]));}
else{
/* srfi-4.scm:520: ##sys#error */
t2=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[2],((C_word*)t0)[5],lf[85],((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[7]);}}

/* release-number-vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_1914(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1914,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1921,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm:278: number-vector? */
t4=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k1910 in alloc in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_1912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_string_to_bytevector(t1);
t3=t1;
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* f_3361 in pack-copy in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3361(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3361,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,((C_word*)t0)[2],((C_word*)t0)[3]);
t4=C_slot(t2,C_fix(1));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3371,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_block_size(t5);
/* srfi-4.scm:510: ##sys#make-blob */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[83]+1)))(3,*((C_word*)lf[83]+1),t6,t7);}

/* k2984 in list->f64vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2986,2,t0,t1);}
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2991,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word)li50),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2991(t6,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* k4064 in loop in k4055 in read-u8vector in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in ... */
static void C_ccall f_4066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4066,2,t0,t1);}
if(C_truep(C_eofp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4075,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm:686: get-output-string */
t3=*((C_word*)lf[152]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4084,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm:690: ##sys#write-char/port */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[153]+1)))(4,*((C_word*)lf[153]+1),t2,t1,((C_word*)t0)[4]);}}

/* loop in k4055 in read-u8vector in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in ... */
static void C_fcall f_4062(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4062,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4066,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm:684: ##sys#read-char-0 */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[154]+1)))(3,*((C_word*)lf[154]+1),t2,((C_word*)t0)[5]);}

/* k2996 in doloop731 in k2984 in list->f64vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_2991(t4,((C_word*)t0)[5],t2,t3);}

/* doloop731 in k2984 in list->f64vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_fcall f_2991(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2991,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2998,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_truep(C_blockp(t2))?C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
/* srfi-4.scm:423: f64vector-set! */
t7=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t4,((C_word*)t0)[2],t3,t6);}
else{
/* srfi-4.scm:423: ##sys#error-not-a-proper-list */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[57]+1)))(3,*((C_word*)lf[57]+1),t4,((C_word*)t0)[4]);}}}

/* k2583 in make-f32vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2585,2,t0,t1);}
t2=C_a_i_record2(&a,2,lf[16],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2549,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[5])){
if(C_truep(((C_word*)t0)[6])){
/* srfi-4.scm:364: set-finalizer! */
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,((C_word*)t0)[7]);}
else{
t5=t4;
f_2549(2,t5,C_SCHEME_UNDEFINED);}}
else{
t5=t4;
f_2549(2,t5,C_SCHEME_UNDEFINED);}}

/* k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in k3485 in k3481 in k3477 in k3473 in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3511,2,t0,t1);}
t2=C_mutate2((C_word*)lf[105]+1 /* (set! blob->s8vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3515,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:554: unpack */
f_3377(t3,lf[8],C_fix(2),lf[106]);}

/* k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in k3485 in k3481 in k3477 in k3473 in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3515,2,t0,t1);}
t2=C_mutate2((C_word*)lf[106]+1 /* (set! blob->u16vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3519,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:555: unpack */
f_3377(t3,lf[10],C_fix(2),lf[107]);}

/* doloop576 in k2559 in k2547 in k2583 in make-f32vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static C_word C_fcall f_2566(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_stack_overflow_check;
loop:
if(C_truep(C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[2]))){
return(((C_word*)t0)[3]);}
else{
t2=C_u_i_f32vector_set(((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[4])[1]);
t3=C_fixnum_plus(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}

/* k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in k3485 in k3481 in k3477 in k3473 in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3523,2,t0,t1);}
t2=C_mutate2((C_word*)lf[108]+1 /* (set! blob->u32vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3527,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:557: unpack */
f_3377(t3,lf[14],C_fix(4),lf[109]);}

/* k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in k3485 in k3481 in k3477 in k3473 in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 in ... */
static void C_ccall f_3527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3527,2,t0,t1);}
t2=C_mutate2((C_word*)lf[109]+1 /* (set! blob->s32vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3531,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:558: unpack */
f_3377(t3,lf[16],C_fix(4),lf[110]);}

/* k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in k3485 in k3481 in k3477 in k3473 in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3519,2,t0,t1);}
t2=C_mutate2((C_word*)lf[107]+1 /* (set! blob->s16vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3523,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:556: unpack */
f_3377(t3,lf[12],C_fix(4),lf[108]);}

/* k2559 in k2547 in k2583 in make-f32vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_fcall f_2561(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2561,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2566,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li32),tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2566(t2,C_fix(0)));}

/* k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in k3485 in k3481 in k3477 in k3473 in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in ... */
static void C_ccall f_3531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3531,2,t0,t1);}
t2=C_mutate2((C_word*)lf[110]+1 /* (set! blob->f32vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3535,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:559: unpack */
f_3377(t3,lf[18],C_fix(8),lf[111]);}

/* k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in k3485 in k3481 in k3477 in k3473 in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in ... */
static void C_ccall f_3535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3535,2,t0,t1);}
t2=C_mutate2((C_word*)lf[111]+1 /* (set! blob->f64vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3539,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:561: unpack-copy */
f_3407(t3,lf[4],C_SCHEME_TRUE,lf[112]);}

/* f_3379 in unpack in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3379(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3379,3,t0,t1,t2);}
t3=C_i_check_bytevector_2(t2,((C_word*)t0)[2]);
t4=C_block_size(t2);
t5=t4;
t6=C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3395,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t5,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_3395(t8,t6);}
else{
t8=C_fixnum_modulo(t5,((C_word*)t0)[3]);
t9=t7;
f_3395(t9,C_eqp(C_fix(0),t8));}}

/* unpack in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_fcall f_3377(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3377,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3379,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=((C_word)li86),tmp=(C_word)a,a+=6,tmp));}

/* k3369 */
static void C_ccall f_3371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_copy_block(((C_word*)t0)[3],t1));}

/* f64vector-set! */
static void C_ccall f_1820(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1820,5,t0,t1,t2,t3,t4);}
t5=C_i_check_structure_2(t2,lf[18],lf[33]);
t6=C_u_i_64vector_length(t2);
t7=C_i_check_number_2(t4,lf[33]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1851,a[2]=t4,a[3]=t1,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t9=t3;
t10=C_i_check_exact_2(t9,lf[33]);
t11=C_fixnum_less_or_equal_p(C_fix(0),t9);
t12=(C_truep(t11)?C_fixnum_lessp(t9,t6):C_SCHEME_FALSE);
if(C_truep(t12)){
t13=C_SCHEME_UNDEFINED;
t14=t8;
f_1851(2,t14,t13);}
else{
t13=C_fix((C_word)C_OUT_OF_RANGE_ERROR);
/* srfi-4.scm:56: ##sys#error-hook */
((C_proc7)C_fast_retrieve_proc(*((C_word*)lf[20]+1)))(7,*((C_word*)lf[20]+1),t8,t13,lf[33],t9,C_fix(0),t6);}}

/* k1812 in f32vector-set! */
static void C_ccall f_1814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1814,2,t0,t1);}
if(C_truep(C_blockp(((C_word*)t0)[2]))){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_u_i_f32vector_set(((C_word*)t0)[4],((C_word*)t0)[5],t2));}
else{
t2=C_a_i_fix_to_flo(&a,1,((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_u_i_f32vector_set(((C_word*)t0)[4],((C_word*)t0)[5],t2));}}

/* k4073 in k4064 in loop in k4055 in read-u8vector in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in ... */
static void C_ccall f_4075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_block_size(t1);
/* srfi-4.scm:688: wrap */
f_4005(((C_word*)t0)[3],t1,t2);}

/* k3262 in loop in f32vector->list in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3264,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,C_a_u_i_f32vector_ref(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]),t1));}

/* k4082 in k4064 in loop in k4055 in read-u8vector in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in ... */
static void C_ccall f_4084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm:691: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4062(t2,((C_word*)t0)[3]);}

/* k2282 in make-s16vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2284,2,t0,t1);}
t2=C_a_i_record2(&a,2,lf[10],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2252,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[5])){
if(C_truep(((C_word*)t0)[6])){
/* srfi-4.scm:325: set-finalizer! */
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,((C_word*)t0)[7]);}
else{
t5=t4;
f_2252(2,t5,C_SCHEME_UNDEFINED);}}
else{
t5=t4;
f_2252(2,t5,C_SCHEME_UNDEFINED);}}

/* loop in f64vector->list in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_fcall f_3279(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3279,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3293,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_fixnum_plus(t2,C_fix(1));
/* srfi-4.scm:480: loop */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* f64vector->list in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3270(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3270,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[18],lf[72]);
t4=C_u_i_f64vector_length(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3279,a[2]=t4,a[3]=t2,a[4]=t6,a[5]=((C_word)li74),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3279(t8,t1,C_fix(0));}

/* u16vector-length */
static void C_ccall f_1500(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1500,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[8],lf[7]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_u_i_16vector_length(t2));}

/* s16vector-length */
static void C_ccall f_1506(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1506,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[10],lf[9]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_u_i_16vector_length(t2));}

/* k2650 in k2686 in make-f64vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2652,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[2])[1];
if(C_truep(t2)){
t3=C_i_check_number_2(((C_word*)((C_word*)t0)[2])[1],lf[55]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2664,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_blockp(((C_word*)((C_word*)t0)[2])[1]))){
t5=t4;
f_2664(t5,C_SCHEME_UNDEFINED);}
else{
t5=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_a_i_fix_to_flo(&a,1,((C_word*)((C_word*)t0)[2])[1]));
t6=t4;
f_2664(t6,t5);}}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}}

/* k2250 in k2282 in make-s16vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2252,2,t0,t1);}
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2261,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm:329: ##sys#check-exact-interval */
f_1473(t2,((C_word*)t0)[2],C_fix(-32768),C_fix(32767),lf[51]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* u8vector-set! */
static void C_ccall f_1536(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1536,5,t0,t1,t2,t3,t4);}
t5=C_i_check_structure_2(t2,lf[4],lf[19]);
t6=C_u_i_8vector_length(t2);
t7=C_i_check_exact_2(t4,lf[19]);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1546,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_fixnum_lessp(t4,C_fix(0)))){
/* srfi-4.scm:103: ##sys#error */
t9=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[19],lf[21],t4);}
else{
t9=t8;
f_1546(2,t9,C_SCHEME_UNDEFINED);}}

/* f64vector-length */
static void C_ccall f_1530(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1530,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[18],lf[17]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_u_i_64vector_length(t2));}

/* f4982 in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f4982(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f4982,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[18],lf[95]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(1)));}

/* read-u8vector! in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in k3485 in ... */
static void C_ccall f_3924(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_3924r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3924r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3924r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word *a=C_alloc(10);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t6=C_i_nullp(t4);
t7=(C_truep(t6)?*((C_word*)lf[149]+1):C_i_car(t4));
t8=t7;
t9=C_i_nullp(t4);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:C_i_cdr(t4));
t11=C_i_nullp(t10);
t12=(C_truep(t11)?C_fix(0):C_i_car(t10));
t13=t12;
t14=C_i_nullp(t10);
t15=(C_truep(t14)?C_SCHEME_END_OF_LIST:C_i_cdr(t10));
t16=C_i_check_port_2(t8,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[148]);
t17=C_i_check_exact_2(t13,lf[148]);
t18=C_i_check_structure_2(t3,lf[4],lf[148]);
t19=(C_truep(((C_word*)t5)[1])?C_i_check_exact_2(((C_word*)t5)[1],lf[148]):C_SCHEME_UNDEFINED);
t20=C_slot(t3,C_fix(1));
t21=t20;
t22=C_block_size(t21);
t23=t22;
t24=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3964,a[2]=t1,a[3]=t5,a[4]=t21,a[5]=t8,a[6]=t13,a[7]=t23,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t5)[1])){
t25=C_fixnum_plus(t13,((C_word*)t5)[1]);
t26=t24;
f_3964(t26,C_fixnum_less_or_equal_p(t25,t23));}
else{
t25=t24;
f_3964(t25,C_SCHEME_FALSE);}}

/* k2259 in k2250 in k2282 in make-s16vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2266,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li26),tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2266(t2,C_fix(0)));}

/* k3501 in k3497 in k3493 in k3489 in k3485 in k3481 in k3477 in k3473 in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3503,2,t0,t1);}
t2=C_mutate2((C_word*)lf[103]+1 /* (set! f64vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3507,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:552: unpack */
f_3377(t3,lf[4],C_SCHEME_TRUE,lf[104]);}

/* list->u8vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2727(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2727,3,t0,t1,t2);}
t3=C_i_check_list_2(t2,lf[4]);
t4=C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2734,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm:416: make-u8vector */
t6=((C_word*)t0)[2];
((C_proc3)C_fast_retrieve_proc(t6))(3,t6,t5,t4);}

/* k1861 in k1857 */
static void C_ccall f_1863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1863,2,t0,t1);}
t2=C_mutate2((C_word*)lf[35]+1 /* (set! s8vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1867,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4266,a[2]=((C_word)li121),tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:195: getter-with-setter */
t5=*((C_word*)lf[158]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,*((C_word*)lf[23]+1),lf[164]);}

/* doloop489 in k2259 in k2250 in k2282 in make-s16vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static C_word C_fcall f_2266(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_stack_overflow_check;
loop:
if(C_truep(C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[2]))){
return(((C_word*)t0)[3]);}
else{
t2=C_u_i_s16vector_set(((C_word*)t0)[3],t1,((C_word*)t0)[4]);
t3=C_fixnum_plus(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}

/* k1865 in k1861 in k1857 */
static void C_ccall f_1867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1867,2,t0,t1);}
t2=C_mutate2((C_word*)lf[36]+1 /* (set! u16vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1871,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4236,a[2]=((C_word)li120),tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:205: getter-with-setter */
t5=*((C_word*)lf[158]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,*((C_word*)lf[25]+1),lf[163]);}

/* f32vector-length */
static void C_ccall f_1524(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1524,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[16],lf[15]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_u_i_32vector_length(t2));}

/* f4989 in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f4989(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f4989,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[16],lf[94]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(1)));}

/* k3505 in k3501 in k3497 in k3493 in k3489 in k3485 in k3481 in k3477 in k3473 in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3507,2,t0,t1);}
t2=C_mutate2((C_word*)lf[104]+1 /* (set! blob->u8vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3511,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:553: unpack */
f_3377(t3,lf[6],C_SCHEME_TRUE,lf[105]);}

/* k1849 in f64vector-set! */
static void C_ccall f_1851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1851,2,t0,t1);}
if(C_truep(C_blockp(((C_word*)t0)[2]))){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_u_i_f64vector_set(((C_word*)t0)[4],((C_word*)t0)[5],t2));}
else{
t2=C_a_i_fix_to_flo(&a,1,((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_u_i_f64vector_set(((C_word*)t0)[4],((C_word*)t0)[5],t2));}}

/* k1857 */
static void C_ccall f_1859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1859,2,t0,t1);}
t2=C_mutate2((C_word*)lf[34]+1 /* (set! u8vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1863,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4296,a[2]=((C_word)li122),tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:185: getter-with-setter */
t5=*((C_word*)lf[158]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,*((C_word*)lf[19]+1),lf[165]);}

/* k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_1883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1883,2,t0,t1);}
t2=C_mutate2((C_word*)lf[40]+1 /* (set! f32vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1887,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4116,a[2]=((C_word)li116),tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:245: getter-with-setter */
t5=*((C_word*)lf[158]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,*((C_word*)lf[33]+1),lf[159]);}

/* k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_1887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word ab[189],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1887,2,t0,t1);}
t2=C_mutate2((C_word*)lf[41]+1 /* (set! f64vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1894,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1896,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp);
t5=C_mutate2((C_word*)lf[44]+1 /* (set! release-number-vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1914,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate2((C_word*)lf[47]+1 /* (set! make-u8vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1929,a[2]=t3,a[3]=t4,a[4]=((C_word)li21),tmp=(C_word)a,a+=5,tmp));
t7=C_mutate2((C_word*)lf[49]+1 /* (set! make-s8vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2027,a[2]=t3,a[3]=t4,a[4]=((C_word)li23),tmp=(C_word)a,a+=5,tmp));
t8=C_mutate2((C_word*)lf[50]+1 /* (set! make-u16vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2125,a[2]=t3,a[3]=t4,a[4]=((C_word)li25),tmp=(C_word)a,a+=5,tmp));
t9=C_mutate2((C_word*)lf[51]+1 /* (set! make-s16vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2224,a[2]=t3,a[3]=t4,a[4]=((C_word)li27),tmp=(C_word)a,a+=5,tmp));
t10=C_mutate2((C_word*)lf[52]+1 /* (set! make-u32vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2323,a[2]=t3,a[3]=t4,a[4]=((C_word)li29),tmp=(C_word)a,a+=5,tmp));
t11=C_mutate2((C_word*)lf[53]+1 /* (set! make-s32vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2422,a[2]=t3,a[3]=t4,a[4]=((C_word)li31),tmp=(C_word)a,a+=5,tmp));
t12=C_mutate2((C_word*)lf[54]+1 /* (set! make-f32vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2521,a[2]=t3,a[3]=t4,a[4]=((C_word)li33),tmp=(C_word)a,a+=5,tmp));
t13=C_mutate2((C_word*)lf[55]+1 /* (set! make-f64vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2624,a[2]=t3,a[3]=t4,a[4]=((C_word)li35),tmp=(C_word)a,a+=5,tmp));
t14=*((C_word*)lf[47]+1);
t15=C_mutate2((C_word*)lf[56]+1 /* (set! list->u8vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2727,a[2]=t14,a[3]=((C_word)li37),tmp=(C_word)a,a+=4,tmp));
t16=*((C_word*)lf[49]+1);
t17=C_mutate2((C_word*)lf[58]+1 /* (set! list->s8vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2763,a[2]=t16,a[3]=((C_word)li39),tmp=(C_word)a,a+=4,tmp));
t18=*((C_word*)lf[50]+1);
t19=C_mutate2((C_word*)lf[59]+1 /* (set! list->u16vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2799,a[2]=t18,a[3]=((C_word)li41),tmp=(C_word)a,a+=4,tmp));
t20=*((C_word*)lf[51]+1);
t21=C_mutate2((C_word*)lf[60]+1 /* (set! list->s16vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2835,a[2]=t20,a[3]=((C_word)li43),tmp=(C_word)a,a+=4,tmp));
t22=*((C_word*)lf[52]+1);
t23=C_mutate2((C_word*)lf[61]+1 /* (set! list->u32vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2871,a[2]=t22,a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp));
t24=*((C_word*)lf[53]+1);
t25=C_mutate2((C_word*)lf[62]+1 /* (set! list->s32vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2907,a[2]=t24,a[3]=((C_word)li47),tmp=(C_word)a,a+=4,tmp));
t26=*((C_word*)lf[54]+1);
t27=C_mutate2((C_word*)lf[63]+1 /* (set! list->f32vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2943,a[2]=t26,a[3]=((C_word)li49),tmp=(C_word)a,a+=4,tmp));
t28=*((C_word*)lf[55]+1);
t29=C_mutate2((C_word*)lf[64]+1 /* (set! list->f64vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2979,a[2]=t28,a[3]=((C_word)li51),tmp=(C_word)a,a+=4,tmp));
t30=C_mutate2((C_word*)lf[4]+1 /* (set! u8vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3015,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp));
t31=C_mutate2((C_word*)lf[6]+1 /* (set! s8vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3021,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate2((C_word*)lf[8]+1 /* (set! u16vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3027,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate2((C_word*)lf[10]+1 /* (set! s16vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3033,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp));
t34=C_mutate2((C_word*)lf[12]+1 /* (set! u32vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3039,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp));
t35=C_mutate2((C_word*)lf[14]+1 /* (set! s32vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3045,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp));
t36=C_mutate2((C_word*)lf[16]+1 /* (set! f32vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3051,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp));
t37=C_mutate2((C_word*)lf[18]+1 /* (set! f64vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3057,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp));
t38=C_mutate2((C_word*)lf[65]+1 /* (set! u8vector->list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3063,a[2]=((C_word)li61),tmp=(C_word)a,a+=3,tmp));
t39=C_mutate2((C_word*)lf[66]+1 /* (set! s8vector->list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3093,a[2]=((C_word)li63),tmp=(C_word)a,a+=3,tmp));
t40=C_mutate2((C_word*)lf[67]+1 /* (set! u16vector->list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3123,a[2]=((C_word)li65),tmp=(C_word)a,a+=3,tmp));
t41=C_mutate2((C_word*)lf[68]+1 /* (set! s16vector->list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3153,a[2]=((C_word)li67),tmp=(C_word)a,a+=3,tmp));
t42=C_mutate2((C_word*)lf[69]+1 /* (set! u32vector->list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3183,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp));
t43=C_mutate2((C_word*)lf[70]+1 /* (set! s32vector->list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3212,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp));
t44=C_mutate2((C_word*)lf[71]+1 /* (set! f32vector->list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3241,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp));
t45=C_mutate2((C_word*)lf[72]+1 /* (set! f64vector->list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3270,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp));
t46=C_mutate2((C_word*)lf[73]+1 /* (set! u8vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3299,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp));
t47=C_mutate2((C_word*)lf[74]+1 /* (set! s8vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3305,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp));
t48=C_mutate2((C_word*)lf[75]+1 /* (set! u16vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3311,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t49=C_mutate2((C_word*)lf[76]+1 /* (set! s16vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3317,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp));
t50=C_mutate2((C_word*)lf[77]+1 /* (set! u32vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3323,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate2((C_word*)lf[78]+1 /* (set! s32vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3329,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp));
t52=C_mutate2((C_word*)lf[79]+1 /* (set! f32vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3335,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp));
t53=C_mutate2((C_word*)lf[80]+1 /* (set! f64vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3341,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp));
t54=C_mutate2((C_word*)lf[46]+1 /* (set! number-vector? ...) */,*((C_word*)lf[81]+1));
t55=C_mutate2(&lf[82] /* (set! pack-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3359,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp));
t56=C_mutate2(&lf[84] /* (set! unpack ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3377,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t57=C_mutate2(&lf[86] /* (set! unpack-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3407,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp));
t58=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5031,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp);
t59=C_mutate2((C_word*)lf[88]+1 /* (set! u8vector->blob/shared ...) */,t58);
t60=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5024,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp);
t61=C_mutate2((C_word*)lf[89]+1 /* (set! s8vector->blob/shared ...) */,t60);
t62=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5017,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp);
t63=C_mutate2((C_word*)lf[90]+1 /* (set! u16vector->blob/shared ...) */,t62);
t64=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5010,a[2]=((C_word)li93),tmp=(C_word)a,a+=3,tmp);
t65=C_mutate2((C_word*)lf[91]+1 /* (set! s16vector->blob/shared ...) */,t64);
t66=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5003,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp);
t67=C_mutate2((C_word*)lf[92]+1 /* (set! u32vector->blob/shared ...) */,t66);
t68=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f4996,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp);
t69=C_mutate2((C_word*)lf[93]+1 /* (set! s32vector->blob/shared ...) */,t68);
t70=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f4989,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp);
t71=C_mutate2((C_word*)lf[94]+1 /* (set! f32vector->blob/shared ...) */,t70);
t72=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f4982,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp);
t73=C_mutate2((C_word*)lf[95]+1 /* (set! f64vector->blob/shared ...) */,t72);
t74=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3475,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:543: pack-copy */
f_3359(t74,lf[4],lf[96]);}

/* make-f32vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2521(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_2521r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2521r(t0,t1,t2,t3);}}

static void C_ccall f_2521r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a=C_alloc(10);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_i_nullp(t3);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t10=C_i_nullp(t9);
t11=(C_truep(t10)?C_SCHEME_FALSE:C_i_car(t9));
t12=t11;
t13=C_i_nullp(t9);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:C_i_cdr(t9));
t15=C_i_nullp(t14);
t16=(C_truep(t15)?C_SCHEME_TRUE:C_i_car(t14));
t17=t16;
t18=C_i_nullp(t14);
t19=(C_truep(t18)?C_SCHEME_END_OF_LIST:C_i_cdr(t14));
t20=C_i_check_exact_2(t2,lf[54]);
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2585,a[2]=t7,a[3]=t2,a[4]=t1,a[5]=t12,a[6]=t17,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t22=C_fixnum_shift_left(t2,C_fix(2));
/* srfi-4.scm:363: alloc */
f_1896(t21,lf[54],t22,t12);}

/* k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_1871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1871,2,t0,t1);}
t2=C_mutate2((C_word*)lf[37]+1 /* (set! s16vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1875,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4206,a[2]=((C_word)li119),tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:215: getter-with-setter */
t5=*((C_word*)lf[158]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,*((C_word*)lf[26]+1),lf[162]);}

/* make-s8vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2027(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_2027r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2027r(t0,t1,t2,t3);}}

static void C_ccall f_2027r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a=C_alloc(8);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=t5;
t7=C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_FALSE:C_i_car(t8));
t11=t10;
t12=C_i_nullp(t8);
t13=(C_truep(t12)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t14=C_i_nullp(t13);
t15=(C_truep(t14)?C_SCHEME_TRUE:C_i_car(t13));
t16=t15;
t17=C_i_nullp(t13);
t18=(C_truep(t17)?C_SCHEME_END_OF_LIST:C_i_cdr(t13));
t19=C_i_check_exact_2(t2,lf[49]);
t20=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2087,a[2]=t6,a[3]=t2,a[4]=t1,a[5]=t11,a[6]=t16,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm:298: alloc */
f_1896(t20,lf[49],t2,t11);}

/* k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_1875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1875,2,t0,t1);}
t2=C_mutate2((C_word*)lf[38]+1 /* (set! u32vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1879,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4176,a[2]=((C_word)li118),tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:225: getter-with-setter */
t5=*((C_word*)lf[158]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,*((C_word*)lf[30]+1),lf[161]);}

/* subf64vector in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in k3485 in ... */
static void C_ccall f_3825(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3825,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm:640: subnvector */
f_3698(t1,t2,lf[18],C_fix(8),t3,t4,lf[144]);}

/* k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_1879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1879,2,t0,t1);}
t2=C_mutate2((C_word*)lf[39]+1 /* (set! s32vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1883,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4146,a[2]=((C_word)li117),tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:235: getter-with-setter */
t5=*((C_word*)lf[158]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,*((C_word*)lf[32]+1),lf[160]);}

/* k3291 in loop in f64vector->list in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3293,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,C_a_u_i_f64vector_ref(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]),t1));}

/* u8vector? in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3299(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3299,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_structurep(t2,lf[4]));}

/* write-u8vector in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in k3485 in ... */
static void C_ccall f_3831(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_3831r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3831r(t0,t1,t2,t3);}}

static void C_ccall f_3831r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(7);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?*((C_word*)lf[146]+1):C_i_car(t3));
t6=t5;
t7=C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?C_fix(0):C_i_car(t8));
t11=t10;
t12=C_i_nullp(t8);
t13=(C_truep(t12)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t14=t13;
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3847,a[2]=t14,a[3]=t2,a[4]=t6,a[5]=t1,a[6]=t11,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_nullp(t14))){
/* srfi-4.scm:643: u8vector-length */
t16=*((C_word*)lf[3]+1);
((C_proc3)(void*)(*((C_word*)t16+1)))(3,t16,t15,t2);}
else{
t16=t15;
f_3847(2,t16,C_i_car(t14));}}

/* doloop1034 in k3845 in write-u8vector in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in ... */
static void C_fcall f_3861(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3861,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3871,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_u_i_u8vector_ref(((C_word*)t0)[4],t2);
t5=C_make_character(C_unfix(t4));
/* srfi-4.scm:648: ##sys#write-char-0 */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[147]+1)))(4,*((C_word*)lf[147]+1),t3,t5,((C_word*)t0)[5]);}}

/* f32vector->list in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3241(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3241,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[16],lf[71]);
t4=C_u_i_f32vector_length(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3250,a[2]=t4,a[3]=t2,a[4]=t6,a[5]=((C_word)li72),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3250(t8,t1,C_fix(0));}

/* subs16vector in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in k3485 in ... */
static void C_ccall f_3807(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3807,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm:637: subnvector */
f_3698(t1,t2,lf[10],C_fix(2),t3,t4,lf[141]);}

/* subs8vector in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in k3485 in ... */
static void C_ccall f_3801(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3801,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm:636: subnvector */
f_3698(t1,t2,lf[6],C_fix(1),t3,t4,lf[140]);}

/* k2085 in make-s8vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2087,2,t0,t1);}
t2=C_a_i_record2(&a,2,lf[6],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2055,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[5])){
if(C_truep(((C_word*)t0)[6])){
/* srfi-4.scm:299: set-finalizer! */
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,((C_word*)t0)[7]);}
else{
t5=t4;
f_2055(2,t5,C_SCHEME_UNDEFINED);}}
else{
t5=t4;
f_2055(2,t5,C_SCHEME_UNDEFINED);}}

/* u32vector-length */
static void C_ccall f_1512(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1512,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[12],lf[11]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_u_i_32vector_length(t2));}

/* s32vector-length */
static void C_ccall f_1518(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1518,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[14],lf[13]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_u_i_32vector_length(t2));}

/* make-s16vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2224(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_2224r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2224r(t0,t1,t2,t3);}}

static void C_ccall f_2224r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a=C_alloc(8);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=t5;
t7=C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_FALSE:C_i_car(t8));
t11=t10;
t12=C_i_nullp(t8);
t13=(C_truep(t12)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t14=C_i_nullp(t13);
t15=(C_truep(t14)?C_SCHEME_TRUE:C_i_car(t13));
t16=t15;
t17=C_i_nullp(t13);
t18=(C_truep(t17)?C_SCHEME_END_OF_LIST:C_i_cdr(t13));
t19=C_i_check_exact_2(t2,lf[51]);
t20=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2284,a[2]=t6,a[3]=t2,a[4]=t1,a[5]=t11,a[6]=t16,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t21=C_fixnum_shift_left(t2,C_fix(1));
/* srfi-4.scm:324: alloc */
f_1896(t20,lf[51],t21,t11);}

/* loop in f32vector->list in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_fcall f_3250(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3250,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3264,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_fixnum_plus(t2,C_fix(1));
/* srfi-4.scm:479: loop */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* k3869 in doloop1034 in k3845 in write-u8vector in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in ... */
static void C_ccall f_3871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3861(t3,((C_word*)t0)[4],t2);}

/* k2053 in k2085 in make-s8vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2055,2,t0,t1);}
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2064,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm:303: ##sys#check-exact-interval */
f_1473(t2,((C_word*)t0)[2],C_fix(-128),C_fix(127),lf[49]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* k2062 in k2053 in k2085 in make-s8vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_2064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2064,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2069,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li22),tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2069(t2,C_fix(0)));}

/* k3845 in write-u8vector in k3565 in k3561 in k3557 in k3553 in k3549 in k3545 in k3541 in k3537 in k3533 in k3529 in k3525 in k3521 in k3517 in k3513 in k3509 in k3505 in k3501 in k3497 in k3493 in k3489 in ... */
static void C_ccall f_3847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3847,2,t0,t1);}
t2=t1;
t3=C_i_nullp(((C_word*)t0)[2]);
t4=(C_truep(t3)?C_SCHEME_END_OF_LIST:C_i_cdr(((C_word*)t0)[2]));
t5=C_i_check_structure_2(((C_word*)t0)[3],lf[4],lf[145]);
t6=C_i_check_port_2(((C_word*)t0)[4],C_SCHEME_FALSE,C_SCHEME_TRUE,lf[145]);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3861,a[2]=t2,a[3]=t8,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word)li110),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_3861(t10,((C_word*)t0)[5],((C_word*)t0)[6]);}

/* doloop431 in k2062 in k2053 in k2085 in make-s8vector in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static C_word C_fcall f_2069(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_stack_overflow_check;
loop:
if(C_truep(C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[2]))){
return(((C_word*)t0)[3]);}
else{
t2=C_u_i_s8vector_set(((C_word*)t0)[3],t1,((C_word*)t0)[4]);
t3=C_fixnum_plus(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}

/* k3204 in loop in u32vector->list in k1885 in k1881 in k1877 in k1873 in k1869 in k1865 in k1861 in k1857 */
static void C_ccall f_3206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3206,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,C_a_u_i_u32vector_ref(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]),t1));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[251] = {
{"toplevel:srfi_2d4_2escm",(void*)C_srfi_2d4_toplevel},
{"f_3212:srfi_2d4_2escm",(void*)f_3212},
{"f_1546:srfi_2d4_2escm",(void*)f_1546},
{"f4996:srfi_2d4_2escm",(void*)f4996},
{"f_1611:srfi_2d4_2escm",(void*)f_1611},
{"f_3789:srfi_2d4_2escm",(void*)f_3789},
{"f_3783:srfi_2d4_2escm",(void*)f_3783},
{"f_2167:srfi_2d4_2escm",(void*)f_2167},
{"f_2549:srfi_2d4_2escm",(void*)f_2549},
{"f_2162:srfi_2d4_2escm",(void*)f_2162},
{"f_1609:srfi_2d4_2escm",(void*)f_1609},
{"f_3795:srfi_2d4_2escm",(void*)f_3795},
{"f_3311:srfi_2d4_2escm",(void*)f_3311},
{"f_3317:srfi_2d4_2escm",(void*)f_3317},
{"f_3221:srfi_2d4_2escm",(void*)f_3221},
{"f_3698:srfi_2d4_2escm",(void*)f_3698},
{"f_1621:srfi_2d4_2escm",(void*)f_1621},
{"f5031:srfi_2d4_2escm",(void*)f5031},
{"f_3235:srfi_2d4_2escm",(void*)f_3235},
{"f_2153:srfi_2d4_2escm",(void*)f_2153},
{"f5024:srfi_2d4_2escm",(void*)f5024},
{"f5010:srfi_2d4_2escm",(void*)f5010},
{"f_1966:srfi_2d4_2escm",(void*)f_1966},
{"f5017:srfi_2d4_2escm",(void*)f5017},
{"f_3305:srfi_2d4_2escm",(void*)f_3305},
{"f_3359:srfi_2d4_2escm",(void*)f_3359},
{"f_2185:srfi_2d4_2escm",(void*)f_2185},
{"f5003:srfi_2d4_2escm",(void*)f5003},
{"f_1957:srfi_2d4_2escm",(void*)f_1957},
{"f_3329:srfi_2d4_2escm",(void*)f_3329},
{"f_3964:srfi_2d4_2escm",(void*)f_3964},
{"f_3323:srfi_2d4_2escm",(void*)f_3323},
{"f_2890:srfi_2d4_2escm",(void*)f_2890},
{"f_3162:srfi_2d4_2escm",(void*)f_3162},
{"f_2125:srfi_2d4_2escm",(void*)f_2125},
{"f_3177:srfi_2d4_2escm",(void*)f_3177},
{"f_3341:srfi_2d4_2escm",(void*)f_3341},
{"f_3183:srfi_2d4_2escm",(void*)f_3183},
{"f_3192:srfi_2d4_2escm",(void*)f_3192},
{"f_4146:srfi_2d4_2escm",(void*)f_4146},
{"f_4144:srfi_2d4_2escm",(void*)f_4144},
{"f_1653:srfi_2d4_2escm",(void*)f_1653},
{"f_3335:srfi_2d4_2escm",(void*)f_3335},
{"f_1645:srfi_2d4_2escm",(void*)f_1645},
{"f_2835:srfi_2d4_2escm",(void*)f_2835},
{"f_3756:srfi_2d4_2escm",(void*)f_3756},
{"f_1693:srfi_2d4_2escm",(void*)f_1693},
{"f_1696:srfi_2d4_2escm",(void*)f_1696},
{"f_3093:srfi_2d4_2escm",(void*)f_3093},
{"f_2847:srfi_2d4_2escm",(void*)f_2847},
{"f_3762:srfi_2d4_2escm",(void*)f_3762},
{"f_2842:srfi_2d4_2escm",(void*)f_2842},
{"f_1684:srfi_2d4_2escm",(void*)f_1684},
{"f_1686:srfi_2d4_2escm",(void*)f_1686},
{"f_3063:srfi_2d4_2escm",(void*)f_3063},
{"f_1989:srfi_2d4_2escm",(void*)f_1989},
{"f_3072:srfi_2d4_2escm",(void*)f_3072},
{"f_1971:srfi_2d4_2escm",(void*)f_1971},
{"f_3015:srfi_2d4_2escm",(void*)f_3015},
{"f_2878:srfi_2d4_2escm",(void*)f_2878},
{"f_2871:srfi_2d4_2escm",(void*)f_2871},
{"f_2351:srfi_2d4_2escm",(void*)f_2351},
{"f_4236:srfi_2d4_2escm",(void*)f_4236},
{"f_4234:srfi_2d4_2escm",(void*)f_4234},
{"f_2883:srfi_2d4_2escm",(void*)f_2883},
{"f_2854:srfi_2d4_2escm",(void*)f_2854},
{"f_3644:srfi_2d4_2escm",(void*)f_3644},
{"f_3647:srfi_2d4_2escm",(void*)f_3647},
{"f_3051:srfi_2d4_2escm",(void*)f_3051},
{"f_3057:srfi_2d4_2escm",(void*)f_3057},
{"f_3087:srfi_2d4_2escm",(void*)f_3087},
{"f_3021:srfi_2d4_2escm",(void*)f_3021},
{"f_3027:srfi_2d4_2escm",(void*)f_3027},
{"f_2799:srfi_2d4_2escm",(void*)f_2799},
{"f_3033:srfi_2d4_2escm",(void*)f_3033},
{"f_2770:srfi_2d4_2escm",(void*)f_2770},
{"f_3039:srfi_2d4_2escm",(void*)f_3039},
{"f_3632:srfi_2d4_2escm",(void*)f_3632},
{"f_3657:srfi_2d4_2escm",(void*)f_3657},
{"f_3600:srfi_2d4_2escm",(void*)f_3600},
{"f_3611:srfi_2d4_2escm",(void*)f_3611},
{"f_4116:srfi_2d4_2escm",(void*)f_4116},
{"f_4114:srfi_2d4_2escm",(void*)f_4114},
{"f_1494:srfi_2d4_2escm",(void*)f_1494},
{"f_4057:srfi_2d4_2escm",(void*)f_4057},
{"f_1488:srfi_2d4_2escm",(void*)f_1488},
{"f_4204:srfi_2d4_2escm",(void*)f_4204},
{"f_4206:srfi_2d4_2escm",(void*)f_4206},
{"f_3045:srfi_2d4_2escm",(void*)f_3045},
{"f_4039:srfi_2d4_2escm",(void*)f_4039},
{"f_2739:srfi_2d4_2escm",(void*)f_2739},
{"f_2734:srfi_2d4_2escm",(void*)f_2734},
{"f_3732:srfi_2d4_2escm",(void*)f_3732},
{"f_2746:srfi_2d4_2escm",(void*)f_2746},
{"f_4042:srfi_2d4_2escm",(void*)f_4042},
{"f_3559:srfi_2d4_2escm",(void*)f_3559},
{"f_3555:srfi_2d4_2escm",(void*)f_3555},
{"f_3551:srfi_2d4_2escm",(void*)f_3551},
{"f_2782:srfi_2d4_2escm",(void*)f_2782},
{"f_1473:srfi_2d4_2escm",(void*)f_1473},
{"f_2775:srfi_2d4_2escm",(void*)f_2775},
{"f_2482:srfi_2d4_2escm",(void*)f_2482},
{"f_3567:srfi_2d4_2escm",(void*)f_3567},
{"f_3563:srfi_2d4_2escm",(void*)f_3563},
{"f_2323:srfi_2d4_2escm",(void*)f_2323},
{"f_2818:srfi_2d4_2escm",(void*)f_2818},
{"f_3102:srfi_2d4_2escm",(void*)f_3102},
{"f_2811:srfi_2d4_2escm",(void*)f_2811},
{"f_2464:srfi_2d4_2escm",(void*)f_2464},
{"f_2919:srfi_2d4_2escm",(void*)f_2919},
{"f_2806:srfi_2d4_2escm",(void*)f_2806},
{"f_3117:srfi_2d4_2escm",(void*)f_3117},
{"f_2914:srfi_2d4_2escm",(void*)f_2914},
{"f_2763:srfi_2d4_2escm",(void*)f_2763},
{"f_2907:srfi_2d4_2escm",(void*)f_2907},
{"f_3123:srfi_2d4_2escm",(void*)f_3123},
{"f_3132:srfi_2d4_2escm",(void*)f_3132},
{"f_3495:srfi_2d4_2escm",(void*)f_3495},
{"f_3499:srfi_2d4_2escm",(void*)f_3499},
{"f_3491:srfi_2d4_2escm",(void*)f_3491},
{"f_2926:srfi_2d4_2escm",(void*)f_2926},
{"f_4014:srfi_2d4_2escm",(void*)f_4014},
{"f_4013:srfi_2d4_2escm",(void*)f_4013},
{"f_3153:srfi_2d4_2escm",(void*)f_3153},
{"f_3147:srfi_2d4_2escm",(void*)f_3147},
{"f_4005:srfi_2d4_2escm",(void*)f_4005},
{"f_3572:srfi_2d4_2escm",(void*)f_3572},
{"f_4176:srfi_2d4_2escm",(void*)f_4176},
{"f_4174:srfi_2d4_2escm",(void*)f_4174},
{"f_3581:srfi_2d4_2escm",(void*)f_3581},
{"f_3419:srfi_2d4_2escm",(void*)f_3419},
{"f_2688:srfi_2d4_2escm",(void*)f_2688},
{"f_2962:srfi_2d4_2escm",(void*)f_2962},
{"f_2450:srfi_2d4_2escm",(void*)f_2450},
{"f_2383:srfi_2d4_2escm",(void*)f_2383},
{"f_3428:srfi_2d4_2escm",(void*)f_3428},
{"f_4326:srfi_2d4_2escm",(void*)f_4326},
{"f_4324:srfi_2d4_2escm",(void*)f_4324},
{"f_1578:srfi_2d4_2escm",(void*)f_1578},
{"f_1570:srfi_2d4_2escm",(void*)f_1570},
{"f_2664:srfi_2d4_2escm",(void*)f_2664},
{"f_2943:srfi_2d4_2escm",(void*)f_2943},
{"f_2669:srfi_2d4_2escm",(void*)f_2669},
{"f_2365:srfi_2d4_2escm",(void*)f_2365},
{"f_2955:srfi_2d4_2escm",(void*)f_2955},
{"f_1720:srfi_2d4_2escm",(void*)f_1720},
{"f_2950:srfi_2d4_2escm",(void*)f_2950},
{"f_2422:srfi_2d4_2escm",(void*)f_2422},
{"f_3479:srfi_2d4_2escm",(void*)f_3479},
{"f_3475:srfi_2d4_2escm",(void*)f_3475},
{"f_3487:srfi_2d4_2escm",(void*)f_3487},
{"f_3483:srfi_2d4_2escm",(void*)f_3483},
{"f_3819:srfi_2d4_2escm",(void*)f_3819},
{"f_3813:srfi_2d4_2escm",(void*)f_3813},
{"f_1741:srfi_2d4_2escm",(void*)f_1741},
{"f_1748:srfi_2d4_2escm",(void*)f_1748},
{"f_4296:srfi_2d4_2escm",(void*)f_4296},
{"f_4294:srfi_2d4_2escm",(void*)f_4294},
{"f_4266:srfi_2d4_2escm",(void*)f_4266},
{"f_4264:srfi_2d4_2escm",(void*)f_4264},
{"f_2979:srfi_2d4_2escm",(void*)f_2979},
{"f_2624:srfi_2d4_2escm",(void*)f_2624},
{"f_1751:srfi_2d4_2escm",(void*)f_1751},
{"f_1783:srfi_2d4_2escm",(void*)f_1783},
{"f_3543:srfi_2d4_2escm",(void*)f_3543},
{"f_3409:srfi_2d4_2escm",(void*)f_3409},
{"f_3547:srfi_2d4_2escm",(void*)f_3547},
{"f_3407:srfi_2d4_2escm",(void*)f_3407},
{"f_3539:srfi_2d4_2escm",(void*)f_3539},
{"f_1775:srfi_2d4_2escm",(void*)f_1775},
{"f_1929:srfi_2d4_2escm",(void*)f_1929},
{"f_1921:srfi_2d4_2escm",(void*)f_1921},
{"f_4354:srfi_2d4_2escm",(void*)f_4354},
{"f_1894:srfi_2d4_2escm",(void*)f_1894},
{"f_1896:srfi_2d4_2escm",(void*)f_1896},
{"f_3395:srfi_2d4_2escm",(void*)f_3395},
{"f_1914:srfi_2d4_2escm",(void*)f_1914},
{"f_1912:srfi_2d4_2escm",(void*)f_1912},
{"f_3361:srfi_2d4_2escm",(void*)f_3361},
{"f_2986:srfi_2d4_2escm",(void*)f_2986},
{"f_4066:srfi_2d4_2escm",(void*)f_4066},
{"f_4062:srfi_2d4_2escm",(void*)f_4062},
{"f_2998:srfi_2d4_2escm",(void*)f_2998},
{"f_2991:srfi_2d4_2escm",(void*)f_2991},
{"f_2585:srfi_2d4_2escm",(void*)f_2585},
{"f_3511:srfi_2d4_2escm",(void*)f_3511},
{"f_3515:srfi_2d4_2escm",(void*)f_3515},
{"f_2566:srfi_2d4_2escm",(void*)f_2566},
{"f_3523:srfi_2d4_2escm",(void*)f_3523},
{"f_3527:srfi_2d4_2escm",(void*)f_3527},
{"f_3519:srfi_2d4_2escm",(void*)f_3519},
{"f_2561:srfi_2d4_2escm",(void*)f_2561},
{"f_3531:srfi_2d4_2escm",(void*)f_3531},
{"f_3535:srfi_2d4_2escm",(void*)f_3535},
{"f_3379:srfi_2d4_2escm",(void*)f_3379},
{"f_3377:srfi_2d4_2escm",(void*)f_3377},
{"f_3371:srfi_2d4_2escm",(void*)f_3371},
{"f_1820:srfi_2d4_2escm",(void*)f_1820},
{"f_1814:srfi_2d4_2escm",(void*)f_1814},
{"f_4075:srfi_2d4_2escm",(void*)f_4075},
{"f_3264:srfi_2d4_2escm",(void*)f_3264},
{"f_4084:srfi_2d4_2escm",(void*)f_4084},
{"f_2284:srfi_2d4_2escm",(void*)f_2284},
{"f_3279:srfi_2d4_2escm",(void*)f_3279},
{"f_3270:srfi_2d4_2escm",(void*)f_3270},
{"f_1500:srfi_2d4_2escm",(void*)f_1500},
{"f_1506:srfi_2d4_2escm",(void*)f_1506},
{"f_2652:srfi_2d4_2escm",(void*)f_2652},
{"f_2252:srfi_2d4_2escm",(void*)f_2252},
{"f_1536:srfi_2d4_2escm",(void*)f_1536},
{"f_1530:srfi_2d4_2escm",(void*)f_1530},
{"f4982:srfi_2d4_2escm",(void*)f4982},
{"f_3924:srfi_2d4_2escm",(void*)f_3924},
{"f_2261:srfi_2d4_2escm",(void*)f_2261},
{"f_3503:srfi_2d4_2escm",(void*)f_3503},
{"f_2727:srfi_2d4_2escm",(void*)f_2727},
{"f_1863:srfi_2d4_2escm",(void*)f_1863},
{"f_2266:srfi_2d4_2escm",(void*)f_2266},
{"f_1867:srfi_2d4_2escm",(void*)f_1867},
{"f_1524:srfi_2d4_2escm",(void*)f_1524},
{"f4989:srfi_2d4_2escm",(void*)f4989},
{"f_3507:srfi_2d4_2escm",(void*)f_3507},
{"f_1851:srfi_2d4_2escm",(void*)f_1851},
{"f_1859:srfi_2d4_2escm",(void*)f_1859},
{"f_1883:srfi_2d4_2escm",(void*)f_1883},
{"f_1887:srfi_2d4_2escm",(void*)f_1887},
{"f_2521:srfi_2d4_2escm",(void*)f_2521},
{"f_1871:srfi_2d4_2escm",(void*)f_1871},
{"f_2027:srfi_2d4_2escm",(void*)f_2027},
{"f_1875:srfi_2d4_2escm",(void*)f_1875},
{"f_3825:srfi_2d4_2escm",(void*)f_3825},
{"f_1879:srfi_2d4_2escm",(void*)f_1879},
{"f_3293:srfi_2d4_2escm",(void*)f_3293},
{"f_3299:srfi_2d4_2escm",(void*)f_3299},
{"f_3831:srfi_2d4_2escm",(void*)f_3831},
{"f_3861:srfi_2d4_2escm",(void*)f_3861},
{"f_3241:srfi_2d4_2escm",(void*)f_3241},
{"f_3807:srfi_2d4_2escm",(void*)f_3807},
{"f_3801:srfi_2d4_2escm",(void*)f_3801},
{"f_2087:srfi_2d4_2escm",(void*)f_2087},
{"f_1512:srfi_2d4_2escm",(void*)f_1512},
{"f_1518:srfi_2d4_2escm",(void*)f_1518},
{"f_2224:srfi_2d4_2escm",(void*)f_2224},
{"f_3250:srfi_2d4_2escm",(void*)f_3250},
{"f_3871:srfi_2d4_2escm",(void*)f_3871},
{"f_2055:srfi_2d4_2escm",(void*)f_2055},
{"f_2064:srfi_2d4_2escm",(void*)f_2064},
{"f_3847:srfi_2d4_2escm",(void*)f_3847},
{"f_2069:srfi_2d4_2escm",(void*)f_2069},
{"f_3206:srfi_2d4_2escm",(void*)f_3206},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
o|eliminated procedure checks: 103 
o|specializations:
o|  2 (##sys#check-input-port * * *)
o|  1 (##sys#check-output-port * * *)
o|  1 (assq * (list-of pair))
o|  1 (memq * list)
o|safe globals: (f64vector-set! f32vector-set! s32vector-set! u32vector-set! s16vector-set! u16vector-set! s8vector-set! u8vector-set! f64vector-length f32vector-length s32vector-length u32vector-length s16vector-length u16vector-length s8vector-length u8vector-length ##sys#check-exact-interval) 
o|Removed `not' forms: 9 
o|inlining procedure: k1478 
o|inlining procedure: k1478 
o|contracted procedure: "(srfi-4.scm:104) g101102" 
o|inlining procedure: k1552 
o|inlining procedure: k1552 
o|contracted procedure: "(srfi-4.scm:111) g119120" 
o|inlining procedure: k1591 
o|inlining procedure: k1591 
o|contracted procedure: "(srfi-4.scm:120) g136137" 
o|inlining procedure: k1627 
o|inlining procedure: k1627 
o|contracted procedure: "(srfi-4.scm:127) g154155" 
o|inlining procedure: k1666 
o|inlining procedure: k1666 
o|contracted procedure: "(srfi-4.scm:138) g175176" 
o|inlining procedure: k1702 
o|inlining procedure: k1702 
o|contracted procedure: k1730 
o|inlining procedure: k1727 
o|inlining procedure: k1727 
o|contracted procedure: "(srfi-4.scm:147) g193194" 
o|inlining procedure: k1757 
o|inlining procedure: k1757 
o|inlining procedure: k1816 
o|inlining procedure: k1816 
o|contracted procedure: "(srfi-4.scm:154) g211212" 
o|inlining procedure: k1796 
o|inlining procedure: k1796 
o|inlining procedure: k1853 
o|inlining procedure: k1853 
o|contracted procedure: "(srfi-4.scm:166) g228229" 
o|inlining procedure: k1833 
o|inlining procedure: k1833 
o|inlining procedure: k1898 
o|contracted procedure: "(srfi-4.scm:269) ext-alloc360" 
o|inlining procedure: k1898 
o|inlining procedure: k1916 
o|inlining procedure: "(srfi-4.scm:279) ext-free365" 
o|inlining procedure: k1916 
o|contracted procedure: k1961 
o|inlining procedure: k1958 
o|inlining procedure: k1973 
o|inlining procedure: k1973 
o|inlining procedure: k1958 
o|contracted procedure: k2059 
o|inlining procedure: k2056 
o|inlining procedure: k2071 
o|inlining procedure: k2071 
o|inlining procedure: k2056 
o|contracted procedure: k2157 
o|inlining procedure: k2154 
o|inlining procedure: k2169 
o|inlining procedure: k2169 
o|inlining procedure: k2154 
o|contracted procedure: k2256 
o|inlining procedure: k2253 
o|inlining procedure: k2268 
o|inlining procedure: k2268 
o|inlining procedure: k2253 
o|contracted procedure: k2355 
o|inlining procedure: k2352 
o|inlining procedure: k2367 
o|inlining procedure: k2367 
o|inlining procedure: k2352 
o|contracted procedure: k2454 
o|inlining procedure: k2451 
o|inlining procedure: k2466 
o|inlining procedure: k2466 
o|inlining procedure: k2451 
o|contracted procedure: k2553 
o|inlining procedure: k2550 
o|inlining procedure: k2568 
o|inlining procedure: k2568 
o|inlining procedure: k2550 
o|contracted procedure: k2656 
o|inlining procedure: k2653 
o|inlining procedure: k2671 
o|inlining procedure: k2671 
o|inlining procedure: k2653 
o|inlining procedure: k2741 
o|inlining procedure: k2741 
o|inlining procedure: k2777 
o|inlining procedure: k2777 
o|inlining procedure: k2813 
o|inlining procedure: k2813 
o|inlining procedure: k2849 
o|inlining procedure: k2849 
o|inlining procedure: k2885 
o|inlining procedure: k2885 
o|inlining procedure: k2921 
o|inlining procedure: k2921 
o|inlining procedure: k2957 
o|inlining procedure: k2957 
o|inlining procedure: k2993 
o|inlining procedure: k2993 
o|inlining procedure: k3074 
o|inlining procedure: k3074 
o|inlining procedure: k3104 
o|inlining procedure: k3104 
o|inlining procedure: k3134 
o|inlining procedure: k3134 
o|inlining procedure: k3164 
o|inlining procedure: k3164 
o|inlining procedure: k3194 
o|inlining procedure: k3194 
o|inlining procedure: k3223 
o|inlining procedure: k3223 
o|inlining procedure: k3252 
o|inlining procedure: k3252 
o|inlining procedure: k3281 
o|inlining procedure: k3281 
o|inlining procedure: k3387 
o|inlining procedure: k3387 
o|inlining procedure: k3420 
o|inlining procedure: k3420 
o|substituted constant variable: a3578 
o|inlining procedure: k3574 
o|inlining procedure: k3597 
o|inlining procedure: k3597 
o|inlining procedure: k3574 
o|inlining procedure: k3639 
o|inlining procedure: k3639 
o|contracted procedure: "(srfi-4.scm:625) g965966" 
o|inlining procedure: k3738 
o|inlining procedure: k3738 
o|contracted procedure: "(srfi-4.scm:624) g956957" 
o|inlining procedure: k3714 
o|inlining procedure: k3714 
o|substituted constant variable: a3855 
o|substituted constant variable: a3856 
o|inlining procedure: k3863 
o|inlining procedure: k3863 
o|substituted constant variable: a3939 
o|substituted constant variable: a3940 
o|substituted constant variable: a4029 
o|substituted constant variable: a4030 
o|inlining procedure: k4031 
o|inlining procedure: k4031 
o|inlining procedure: k4067 
o|inlining procedure: k4067 
o|contracted procedure: "(srfi-4.scm:249) g349350" 
o|inlining procedure: k4126 
o|inlining procedure: k4126 
o|contracted procedure: "(srfi-4.scm:239) g334335" 
o|inlining procedure: k4156 
o|inlining procedure: k4156 
o|contracted procedure: "(srfi-4.scm:229) g319320" 
o|inlining procedure: k4186 
o|inlining procedure: k4186 
o|contracted procedure: "(srfi-4.scm:219) g304305" 
o|inlining procedure: k4216 
o|inlining procedure: k4216 
o|contracted procedure: "(srfi-4.scm:209) g289290" 
o|inlining procedure: k4246 
o|inlining procedure: k4246 
o|contracted procedure: "(srfi-4.scm:199) g274275" 
o|inlining procedure: k4276 
o|inlining procedure: k4276 
o|contracted procedure: "(srfi-4.scm:189) g259260" 
o|inlining procedure: k4306 
o|inlining procedure: k4306 
o|contracted procedure: "(srfi-4.scm:179) g244245" 
o|inlining procedure: k4336 
o|inlining procedure: k4336 
o|simplifications: ((if . 1)) 
o|replaced variables: 303 
o|removed binding forms: 322 
o|substituted constant variable: loc106 
o|substituted constant variable: from104 
o|substituted constant variable: from104 
o|substituted constant variable: loc106 
o|substituted constant variable: loc124 
o|substituted constant variable: from122 
o|substituted constant variable: from122 
o|substituted constant variable: loc124 
o|substituted constant variable: loc141 
o|substituted constant variable: from139 
o|substituted constant variable: from139 
o|substituted constant variable: loc141 
o|substituted constant variable: loc159 
o|substituted constant variable: from157 
o|substituted constant variable: from157 
o|substituted constant variable: loc159 
o|substituted constant variable: loc180 
o|substituted constant variable: from178 
o|substituted constant variable: from178 
o|substituted constant variable: loc180 
o|substituted constant variable: loc198 
o|substituted constant variable: from196 
o|substituted constant variable: from196 
o|substituted constant variable: loc198 
o|substituted constant variable: loc216 
o|substituted constant variable: from214 
o|substituted constant variable: from214 
o|substituted constant variable: loc216 
o|substituted constant variable: loc233 
o|substituted constant variable: from231 
o|substituted constant variable: from231 
o|substituted constant variable: loc233 
o|substituted constant variable: r30754437 
o|substituted constant variable: r31054439 
o|substituted constant variable: r31354441 
o|substituted constant variable: r31654443 
o|substituted constant variable: r31954445 
o|substituted constant variable: r32244447 
o|substituted constant variable: r32534449 
o|substituted constant variable: r32824451 
o|substituted constant variable: from968 
o|substituted constant variable: from968 
o|substituted constant variable: from959 
o|substituted constant variable: from959 
o|converted assignments to bindings: (wrap1069) 
o|substituted constant variable: loc354 
o|substituted constant variable: from352 
o|substituted constant variable: from352 
o|substituted constant variable: loc354 
o|substituted constant variable: loc339 
o|substituted constant variable: from337 
o|substituted constant variable: from337 
o|substituted constant variable: loc339 
o|substituted constant variable: loc324 
o|substituted constant variable: from322 
o|substituted constant variable: from322 
o|substituted constant variable: loc324 
o|substituted constant variable: loc309 
o|substituted constant variable: from307 
o|substituted constant variable: from307 
o|substituted constant variable: loc309 
o|substituted constant variable: loc294 
o|substituted constant variable: from292 
o|substituted constant variable: from292 
o|substituted constant variable: loc294 
o|substituted constant variable: loc279 
o|substituted constant variable: from277 
o|substituted constant variable: from277 
o|substituted constant variable: loc279 
o|substituted constant variable: loc264 
o|substituted constant variable: from262 
o|substituted constant variable: from262 
o|substituted constant variable: loc264 
o|substituted constant variable: loc249 
o|substituted constant variable: from247 
o|substituted constant variable: from247 
o|substituted constant variable: loc249 
o|simplifications: ((let . 1)) 
o|replaced variables: 40 
o|removed binding forms: 360 
o|inlining procedure: k1980 
o|inlining procedure: k1980 
o|inlining procedure: k2078 
o|inlining procedure: k2078 
o|inlining procedure: k2176 
o|inlining procedure: k2176 
o|inlining procedure: k2275 
o|inlining procedure: k2275 
o|inlining procedure: k2374 
o|inlining procedure: k2374 
o|inlining procedure: k2473 
o|inlining procedure: k2473 
o|inlining procedure: k2576 
o|inlining procedure: k2576 
o|inlining procedure: k2679 
o|inlining procedure: k2679 
o|inlining procedure: k3956 
o|inlining procedure: k3956 
o|replaced variables: 1 
o|removed binding forms: 77 
o|substituted constant variable: r19814598 
o|substituted constant variable: r20794602 
o|substituted constant variable: r21774606 
o|substituted constant variable: r22764610 
o|substituted constant variable: r23754614 
o|substituted constant variable: r24744618 
o|substituted constant variable: r25774622 
o|substituted constant variable: r26804626 
o|replaced variables: 8 
o|removed binding forms: 12 
o|removed conditional forms: 8 
o|removed binding forms: 16 
o|simplifications: ((##core#call . 343) (if . 91)) 
o|  call simplifications:
o|    list
o|    eof-object?
o|    integer->char
o|    fx-	2
o|    fx*	2
o|    ##sys#list	9
o|    cadr
o|    caddr
o|    symbol?
o|    memq
o|    ##sys#check-byte-vector	2
o|    eq?	7
o|    ##sys#size	6
o|    ##sys#slot	6
o|    ##sys#structure?	8
o|    fx>=	9
o|    fx+	12
o|    cons	8
o|    ##sys#check-list	8
o|    car	31
o|    null?	62
o|    cdr	31
o|    ##sys#make-structure	13
o|    ##sys#foreign-fixnum-argument
o|    ##sys#check-number	4
o|    ##sys#fits-in-int?
o|    negative?
o|    ##sys#fits-in-unsigned-int?
o|    fx<=	19
o|    fx<	20
o|    ##sys#check-structure	37
o|    ##sys#check-exact	36
o|contracted procedure: k1475 
o|contracted procedure: k1481 
o|contracted procedure: k1490 
o|contracted procedure: k1496 
o|contracted procedure: k1502 
o|contracted procedure: k1508 
o|contracted procedure: k1514 
o|contracted procedure: k1520 
o|contracted procedure: k1526 
o|contracted procedure: k1532 
o|contracted procedure: k1538 
o|contracted procedure: k1541 
o|contracted procedure: k1549 
o|contracted procedure: k1562 
o|contracted procedure: k1555 
o|contracted procedure: k1571 
o|contracted procedure: k1580 
o|contracted procedure: k1583 
o|contracted procedure: k1588 
o|contracted procedure: k1601 
o|contracted procedure: k1594 
o|contracted procedure: k1613 
o|contracted procedure: k1616 
o|contracted procedure: k1624 
o|contracted procedure: k1637 
o|contracted procedure: k1630 
o|contracted procedure: k1646 
o|contracted procedure: k1655 
o|contracted procedure: k1658 
o|contracted procedure: k1663 
o|contracted procedure: k1676 
o|contracted procedure: k1669 
o|contracted procedure: k1688 
o|contracted procedure: k1699 
o|contracted procedure: k1712 
o|contracted procedure: k1705 
o|contracted procedure: k1721 
o|contracted procedure: k1737 
o|contracted procedure: k1743 
o|contracted procedure: k1754 
o|contracted procedure: k1767 
o|contracted procedure: k1760 
o|contracted procedure: k1776 
o|contracted procedure: k1785 
o|contracted procedure: k1788 
o|contracted procedure: k1793 
o|contracted procedure: k1806 
o|contracted procedure: k1799 
o|contracted procedure: k1822 
o|contracted procedure: k1825 
o|contracted procedure: k1830 
o|contracted procedure: k1843 
o|contracted procedure: k1836 
o|contracted procedure: k1891 
o|contracted procedure: k2020 
o|contracted procedure: k1931 
o|contracted procedure: k2014 
o|contracted procedure: k1934 
o|contracted procedure: k2008 
o|contracted procedure: k1937 
o|contracted procedure: k2002 
o|contracted procedure: k1940 
o|contracted procedure: k1996 
o|contracted procedure: k1943 
o|contracted procedure: k1990 
o|contracted procedure: k1946 
o|contracted procedure: k1949 
o|contracted procedure: k1952 
o|contracted procedure: k2118 
o|contracted procedure: k2029 
o|contracted procedure: k2112 
o|contracted procedure: k2032 
o|contracted procedure: k2106 
o|contracted procedure: k2035 
o|contracted procedure: k2100 
o|contracted procedure: k2038 
o|contracted procedure: k2094 
o|contracted procedure: k2041 
o|contracted procedure: k2088 
o|contracted procedure: k2044 
o|contracted procedure: k2047 
o|contracted procedure: k2050 
o|contracted procedure: k2217 
o|contracted procedure: k2127 
o|contracted procedure: k2211 
o|contracted procedure: k2130 
o|contracted procedure: k2205 
o|contracted procedure: k2133 
o|contracted procedure: k2199 
o|contracted procedure: k2136 
o|contracted procedure: k2193 
o|contracted procedure: k2139 
o|contracted procedure: k2187 
o|contracted procedure: k2142 
o|contracted procedure: k2145 
o|contracted procedure: k2148 
o|contracted procedure: k2316 
o|contracted procedure: k2226 
o|contracted procedure: k2310 
o|contracted procedure: k2229 
o|contracted procedure: k2304 
o|contracted procedure: k2232 
o|contracted procedure: k2298 
o|contracted procedure: k2235 
o|contracted procedure: k2292 
o|contracted procedure: k2238 
o|contracted procedure: k2286 
o|contracted procedure: k2241 
o|contracted procedure: k2244 
o|contracted procedure: k2247 
o|contracted procedure: k2415 
o|contracted procedure: k2325 
o|contracted procedure: k2409 
o|contracted procedure: k2328 
o|contracted procedure: k2403 
o|contracted procedure: k2331 
o|contracted procedure: k2397 
o|contracted procedure: k2334 
o|contracted procedure: k2391 
o|contracted procedure: k2337 
o|contracted procedure: k2385 
o|contracted procedure: k2340 
o|contracted procedure: k2343 
o|contracted procedure: k2346 
o|contracted procedure: k2358 
o|contracted procedure: k2514 
o|contracted procedure: k2424 
o|contracted procedure: k2508 
o|contracted procedure: k2427 
o|contracted procedure: k2502 
o|contracted procedure: k2430 
o|contracted procedure: k2496 
o|contracted procedure: k2433 
o|contracted procedure: k2490 
o|contracted procedure: k2436 
o|contracted procedure: k2484 
o|contracted procedure: k2439 
o|contracted procedure: k2442 
o|contracted procedure: k2445 
o|contracted procedure: k2457 
o|contracted procedure: k2617 
o|contracted procedure: k2523 
o|contracted procedure: k2611 
o|contracted procedure: k2526 
o|contracted procedure: k2605 
o|contracted procedure: k2529 
o|contracted procedure: k2599 
o|contracted procedure: k2532 
o|contracted procedure: k2593 
o|contracted procedure: k2535 
o|contracted procedure: k2587 
o|contracted procedure: k2538 
o|contracted procedure: k2541 
o|contracted procedure: k2544 
o|contracted procedure: k2556 
o|contracted procedure: k2720 
o|contracted procedure: k2626 
o|contracted procedure: k2714 
o|contracted procedure: k2629 
o|contracted procedure: k2708 
o|contracted procedure: k2632 
o|contracted procedure: k2702 
o|contracted procedure: k2635 
o|contracted procedure: k2696 
o|contracted procedure: k2638 
o|contracted procedure: k2690 
o|contracted procedure: k2641 
o|contracted procedure: k2644 
o|contracted procedure: k2647 
o|contracted procedure: k2659 
o|contracted procedure: k2729 
o|contracted procedure: k2752 
o|contracted procedure: k2765 
o|contracted procedure: k2788 
o|contracted procedure: k2801 
o|contracted procedure: k2824 
o|contracted procedure: k2837 
o|contracted procedure: k2860 
o|contracted procedure: k2873 
o|contracted procedure: k2896 
o|contracted procedure: k2909 
o|contracted procedure: k2932 
o|contracted procedure: k2945 
o|contracted procedure: k2968 
o|contracted procedure: k2981 
o|contracted procedure: k3004 
o|contracted procedure: k3065 
o|contracted procedure: k3077 
o|contracted procedure: k3089 
o|contracted procedure: k3095 
o|contracted procedure: k3107 
o|contracted procedure: k3119 
o|contracted procedure: k3125 
o|contracted procedure: k3137 
o|contracted procedure: k3149 
o|contracted procedure: k3155 
o|contracted procedure: k3167 
o|contracted procedure: k3179 
o|contracted procedure: k3185 
o|contracted procedure: k3197 
o|contracted procedure: k3208 
o|contracted procedure: k3214 
o|contracted procedure: k3226 
o|contracted procedure: k3237 
o|contracted procedure: k3243 
o|contracted procedure: k3255 
o|contracted procedure: k3266 
o|contracted procedure: k3272 
o|contracted procedure: k3284 
o|contracted procedure: k3295 
o|contracted procedure: k3352 
o|contracted procedure: k3363 
o|contracted procedure: k3366 
o|contracted procedure: k3373 
o|contracted procedure: k3381 
o|contracted procedure: k3384 
o|contracted procedure: k3390 
o|contracted procedure: k3411 
o|contracted procedure: k3414 
o|contracted procedure: k3423 
o|contracted procedure: k3569 
o|contracted procedure: k3625 
o|contracted procedure: k3582 
o|contracted procedure: k3588 
o|contracted procedure: k3591 
o|contracted procedure: k3594 
o|contracted procedure: k3613 
o|contracted procedure: k3602 
o|contracted procedure: k3666 
o|contracted procedure: k3670 
o|contracted procedure: k3674 
o|contracted procedure: k3678 
o|contracted procedure: k3682 
o|contracted procedure: k3686 
o|contracted procedure: k3690 
o|contracted procedure: k3694 
o|contracted procedure: k3636 
o|contracted procedure: k3652 
o|contracted procedure: k3659 
o|contracted procedure: k3700 
o|contracted procedure: k3703 
o|contracted procedure: k3706 
o|contracted procedure: k3771 
o|contracted procedure: k3757 
o|contracted procedure: k3763 
o|contracted procedure: k3767 
o|contracted procedure: k3775 
o|contracted procedure: k3735 
o|contracted procedure: k3748 
o|contracted procedure: k3741 
o|contracted procedure: k3779 
o|contracted procedure: k3711 
o|contracted procedure: k3724 
o|contracted procedure: k3717 
o|contracted procedure: k3917 
o|contracted procedure: k3833 
o|contracted procedure: k3911 
o|contracted procedure: k3836 
o|contracted procedure: k3905 
o|contracted procedure: k3839 
o|contracted procedure: k3899 
o|contracted procedure: k3842 
o|contracted procedure: k3884 
o|contracted procedure: k3848 
o|contracted procedure: k3851 
o|contracted procedure: k3866 
o|contracted procedure: k3876 
o|contracted procedure: k3880 
o|contracted procedure: k3890 
o|contracted procedure: k3997 
o|contracted procedure: k3926 
o|contracted procedure: k3991 
o|contracted procedure: k3929 
o|contracted procedure: k3985 
o|contracted procedure: k3932 
o|contracted procedure: k3979 
o|contracted procedure: k3935 
o|contracted procedure: k3941 
o|contracted procedure: k3944 
o|contracted procedure: k3947 
o|contracted procedure: k3950 
o|contracted procedure: k3953 
o|contracted procedure: k3966 
o|contracted procedure: k3973 
o|contracted procedure: k4106 
o|contracted procedure: k4016 
o|contracted procedure: k4100 
o|contracted procedure: k4019 
o|contracted procedure: k4094 
o|contracted procedure: k4022 
o|contracted procedure: k4088 
o|contracted procedure: k4025 
o|contracted procedure: k4034 
o|contracted procedure: k4046 
o|contracted procedure: k4070 
o|contracted procedure: k4076 
o|contracted procedure: k4118 
o|contracted procedure: k4123 
o|contracted procedure: k4136 
o|contracted procedure: k4129 
o|contracted procedure: k4148 
o|contracted procedure: k4153 
o|contracted procedure: k4166 
o|contracted procedure: k4159 
o|contracted procedure: k4178 
o|contracted procedure: k4183 
o|contracted procedure: k4196 
o|contracted procedure: k4189 
o|contracted procedure: k4208 
o|contracted procedure: k4213 
o|contracted procedure: k4226 
o|contracted procedure: k4219 
o|contracted procedure: k4238 
o|contracted procedure: k4243 
o|contracted procedure: k4256 
o|contracted procedure: k4249 
o|contracted procedure: k4268 
o|contracted procedure: k4273 
o|contracted procedure: k4286 
o|contracted procedure: k4279 
o|contracted procedure: k4298 
o|contracted procedure: k4303 
o|contracted procedure: k4316 
o|contracted procedure: k4309 
o|contracted procedure: k4328 
o|contracted procedure: k4333 
o|contracted procedure: k4346 
o|contracted procedure: k4339 
o|simplifications: ((let . 16)) 
o|removed binding forms: 328 
o|inlining procedure: "(srfi-4.scm:541) pack" 
o|inlining procedure: "(srfi-4.scm:540) pack" 
o|inlining procedure: "(srfi-4.scm:539) pack" 
o|inlining procedure: "(srfi-4.scm:538) pack" 
o|inlining procedure: "(srfi-4.scm:537) pack" 
o|inlining procedure: "(srfi-4.scm:536) pack" 
o|inlining procedure: "(srfi-4.scm:535) pack" 
o|inlining procedure: "(srfi-4.scm:534) pack" 
o|replaced variables: 216 
o|inlining procedure: k1568 
o|inlining procedure: k1607 
o|inlining procedure: k1643 
o|inlining procedure: k1682 
o|inlining procedure: k1718 
o|inlining procedure: k1773 
o|inlining procedure: k1901 
o|removed side-effect free assignment to unused variable: pack 
o|substituted constant variable: tag8454978 
o|substituted constant variable: loc8464979 
o|substituted constant variable: tag8454985 
o|substituted constant variable: loc8464986 
o|substituted constant variable: tag8454992 
o|substituted constant variable: loc8464993 
o|substituted constant variable: tag8454999 
o|substituted constant variable: loc8465000 
o|substituted constant variable: tag8455006 
o|substituted constant variable: loc8465007 
o|substituted constant variable: tag8455013 
o|substituted constant variable: loc8465014 
o|substituted constant variable: tag8455020 
o|substituted constant variable: loc8465021 
o|substituted constant variable: tag8455027 
o|substituted constant variable: loc8465028 
o|inlining procedure: k4142 
o|inlining procedure: k4172 
o|inlining procedure: k4202 
o|inlining procedure: k4232 
o|inlining procedure: k4262 
o|inlining procedure: k4292 
o|inlining procedure: k4322 
o|inlining procedure: k4352 
o|replaced variables: 8 
o|removed binding forms: 81 
o|removed binding forms: 40 
o|contracted procedure: k3441 
o|contracted procedure: k3445 
o|contracted procedure: k3449 
o|contracted procedure: k3453 
o|contracted procedure: k3457 
o|contracted procedure: k3461 
o|contracted procedure: k3465 
o|contracted procedure: k3469 
o|removed binding forms: 22 
o|direct leaf routine/allocation: doloop402403 0 
o|direct leaf routine/allocation: doloop431432 0 
o|direct leaf routine/allocation: doloop460461 0 
o|direct leaf routine/allocation: doloop489490 0 
o|direct leaf routine/allocation: doloop518519 0 
o|direct leaf routine/allocation: doloop547548 0 
o|direct leaf routine/allocation: doloop576577 0 
o|direct leaf routine/allocation: doloop606607 0 
o|converted assignments to bindings: (doloop402403) 
o|converted assignments to bindings: (doloop431432) 
o|converted assignments to bindings: (doloop460461) 
o|converted assignments to bindings: (doloop489490) 
o|converted assignments to bindings: (doloop518519) 
o|converted assignments to bindings: (doloop547548) 
o|converted assignments to bindings: (doloop576577) 
o|converted assignments to bindings: (doloop606607) 
o|simplifications: ((let . 8)) 
o|customizable procedures: (pack-copy unpack unpack-copy loop1099 wrap1069 k3962 doloop10341035 subnvector g926927 k3426 k3393 loop823 loop816 loop809 loop802 loop795 loop788 loop781 loop774 doloop731732 doloop718719 doloop705706 doloop692693 doloop679680 doloop666667 doloop653654 doloop640641 k2662 k2559 alloc370 ##sys#check-exact-interval) 
o|calls to known targets: 118 
o|identified direct recursive calls: f_1971 1 
o|identified direct recursive calls: f_2069 1 
o|identified direct recursive calls: f_2167 1 
o|identified direct recursive calls: f_2266 1 
o|identified direct recursive calls: f_2365 1 
o|identified direct recursive calls: f_2464 1 
o|identified direct recursive calls: f_2566 1 
o|identified direct recursive calls: f_2669 1 
o|identified direct recursive calls: f_3072 1 
o|identified direct recursive calls: f_3102 1 
o|identified direct recursive calls: f_3132 1 
o|identified direct recursive calls: f_3162 1 
o|identified direct recursive calls: f_3192 1 
o|identified direct recursive calls: f_3221 1 
o|identified direct recursive calls: f_3250 1 
o|identified direct recursive calls: f_3279 1 
o|fast box initializations: 18 
o|fast global references: 36 
o|fast global assignments: 5 
o|dropping unused closure argument: f_3698 
o|dropping unused closure argument: f_3359 
o|dropping unused closure argument: f_1473 
o|dropping unused closure argument: f_4005 
o|dropping unused closure argument: f_3407 
o|dropping unused closure argument: f_1896 
o|dropping unused closure argument: f_3377 
*/
/* end of file */
