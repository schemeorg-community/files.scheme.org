/* Generated from chicken-syntax.scm by the CHICKEN compiler
   http://www.call-cc.org
   2014-06-02 16:38
   Version 4.9.0 (rev 3f195ba)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2014-06-02 on yves (Linux)
   command line: chicken-syntax.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -explicit-use -no-trace -output-file chicken-syntax.c
   unit: chicken_2dsyntax
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[292];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,25),40,97,51,53,52,50,32,120,50,53,48,57,32,114,50,53,49,48,32,99,50,53,49,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,18),40,103,50,52,56,53,32,99,108,97,117,115,101,50,52,57,54,41,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,50,52,55,57,32,103,50,52,57,49,50,53,48,50,41};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,25),40,97,51,54,48,50,32,120,50,52,54,56,32,114,50,52,54,57,32,99,50,52,55,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,34),40,109,97,112,45,108,111,111,112,50,52,50,52,32,103,50,52,51,54,50,52,52,57,32,103,50,52,51,55,50,52,53,48,41,0,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,50,51,56,52,32,103,50,51,57,54,50,52,49,48,41};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,24),40,108,111,111,112,50,32,97,110,97,109,101,115,50,51,55,56,32,105,50,51,55,57,41};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,37),40,108,111,111,112,32,97,114,103,115,50,51,54,52,32,97,110,97,109,101,115,50,51,54,53,32,97,116,121,112,101,115,50,51,54,54,41,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,25),40,97,51,55,50,51,32,120,50,51,52,54,32,114,50,51,52,55,32,99,50,51,52,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,24),40,97,52,49,53,49,32,116,121,112,101,50,51,52,52,32,118,97,114,50,51,52,53,41};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,50,51,49,56,32,103,50,51,51,48,50,51,51,55,41};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,50,50,57,48,32,103,50,51,48,50,50,51,48,57,41};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,32),40,108,111,111,112,50,50,52,50,32,108,50,50,51,55,50,50,56,48,32,108,101,110,50,50,51,56,50,50,56,49,41};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,32),40,108,111,111,112,50,50,52,50,32,108,50,50,51,55,50,50,54,52,32,108,101,110,50,50,51,56,50,50,54,53,41};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,52),40,97,52,48,56,57,32,105,110,112,117,116,50,50,51,54,50,50,52,57,32,114,101,110,97,109,101,50,50,52,53,50,50,53,48,32,99,111,109,112,97,114,101,50,50,51,51,50,50,53,49,41,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,25),40,97,52,51,57,52,32,120,50,50,50,53,32,114,50,50,50,54,32,99,50,50,50,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,7),40,97,52,52,53,51,41,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,58),40,97,52,52,54,51,32,116,121,112,101,50,49,57,57,50,50,48,48,50,50,48,53,32,112,114,101,100,50,50,48,49,50,50,48,50,50,50,48,54,32,112,117,114,101,50,50,48,51,50,50,48,52,50,50,48,55,41,0,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,25),40,97,52,52,51,50,32,120,50,49,57,52,32,114,50,49,57,53,32,99,50,49,57,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,50,49,54,51,32,103,50,49,55,53,50,49,56,52,41};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,25),40,97,52,53,52,48,32,120,50,49,52,57,32,114,50,49,53,48,32,99,50,49,53,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,25),40,97,52,54,53,55,32,120,50,49,51,49,32,114,50,49,51,50,32,99,50,49,51,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,32),40,108,111,111,112,50,48,56,57,32,108,50,48,56,52,50,49,50,50,32,108,101,110,50,48,56,53,50,49,50,51,41};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,32),40,108,111,111,112,50,48,56,57,32,108,50,48,56,52,50,49,49,49,32,108,101,110,50,48,56,53,50,49,49,50,41};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,52),40,97,52,55,52,52,32,105,110,112,117,116,50,48,56,51,50,48,57,54,32,114,101,110,97,109,101,50,48,57,50,50,48,57,55,32,99,111,109,112,97,114,101,50,48,56,48,50,48,57,56,41,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,52),40,97,52,56,57,50,32,105,110,112,117,116,50,48,52,57,50,48,54,50,32,114,101,110,97,109,101,50,48,53,56,50,48,54,51,32,99,111,109,112,97,114,101,50,48,52,54,50,48,54,52,41,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,25),40,97,52,57,56,57,32,120,50,48,51,56,32,114,50,48,51,57,32,99,50,48,52,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,25),40,97,53,48,49,48,32,120,50,48,51,49,32,114,50,48,51,50,32,99,50,48,51,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,28),40,97,53,48,50,55,32,102,111,114,109,50,48,50,52,32,114,50,48,50,53,32,99,50,48,50,54,41,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,28),40,97,53,48,53,54,32,102,111,114,109,50,48,49,51,32,114,50,48,49,52,32,99,50,48,49,53,41,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,47),40,108,111,111,112,32,120,115,49,57,57,49,32,118,97,114,115,49,57,57,50,32,98,115,49,57,57,51,32,118,97,108,115,49,57,57,52,32,114,101,115,116,49,57,57,53,41,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,28),40,97,53,49,50,49,32,102,111,114,109,49,57,56,52,32,114,49,57,56,53,32,99,49,57,56,54,41,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,40),40,108,111,111,112,32,120,115,49,57,54,49,32,118,97,114,115,49,57,54,50,32,118,97,108,115,49,57,54,51,32,114,101,115,116,49,57,54,52,41};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,28),40,97,53,51,50,48,32,102,111,114,109,49,57,53,52,32,114,49,57,53,53,32,99,49,57,53,54,41,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,7),40,103,49,56,57,55,41,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,115,108,111,116,115,49,57,49,55,32,105,49,57,49,56,41,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,56,57,49,32,103,49,57,48,51,49,57,49,48,41};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,56,54,50,32,103,49,56,55,52,49,56,56,48,41};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,28),40,97,53,53,48,48,32,102,111,114,109,49,56,52,55,32,114,49,56,52,56,32,99,49,56,52,57,41,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,7),40,103,49,55,56,52,41,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,55,55,56,32,103,49,55,57,48,49,56,48,48,41};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,20),40,112,97,114,115,101,45,99,108,97,117,115,101,32,99,49,55,53,57,41,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,56,48,57,32,103,49,56,50,49,49,56,50,55,41};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,28),40,97,53,56,55,55,32,102,111,114,109,49,55,52,55,32,114,49,55,52,56,32,99,49,55,52,57,41,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,28),40,97,54,49,53,56,32,102,111,114,109,49,55,51,53,32,114,49,55,51,54,32,99,49,55,51,55,41,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,28),40,97,54,50,55,55,32,102,111,114,109,49,55,49,52,32,114,49,55,49,53,32,99,49,55,49,54,41,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,105,49,53,57,54,41,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,15),40,103,101,110,118,97,114,115,32,110,49,53,57,52,41,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,7),40,97,54,52,54,57,41,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,34),40,109,97,112,45,108,111,111,112,49,54,56,49,32,103,49,54,57,51,49,55,48,49,32,103,49,54,57,52,49,55,48,50,41,0,0,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,27),40,98,117,105,108,100,32,118,97,114,115,50,49,54,53,57,32,118,114,101,115,116,49,54,54,48,41,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,27),40,97,54,52,55,57,32,118,97,114,115,49,49,54,53,53,32,118,97,114,115,50,49,54,53,54,41,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,34),40,97,54,52,52,57,32,118,97,114,115,49,54,52,50,32,97,114,103,99,49,54,52,51,32,114,101,115,116,49,54,52,52,41,0,0,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,22),40,97,54,52,51,57,32,99,49,54,52,48,32,98,111,100,121,49,54,52,49,41,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,34),40,97,54,54,57,51,32,118,97,114,115,49,54,49,57,32,97,114,103,99,49,54,50,48,32,114,101,115,116,49,54,50,49,41,0,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,54,48,49,32,103,49,54,49,51,49,54,50,51,41};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,28),40,97,54,51,53,48,32,102,111,114,109,49,53,57,48,32,114,49,53,57,49,32,99,49,53,57,50,41,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,27),40,108,111,111,112,32,97,114,103,115,49,53,55,50,32,118,97,114,100,101,102,115,49,53,55,51,41,0,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,28),40,97,54,55,56,56,32,102,111,114,109,49,53,53,56,32,114,49,53,53,57,32,99,49,53,54,48,41,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,28),40,97,54,57,52,52,32,102,111,114,109,49,53,52,51,32,114,49,53,52,52,32,99,49,53,52,53,41,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,48),40,114,101,99,117,114,32,118,97,114,115,49,52,48,52,32,100,101,102,97,117,108,116,101,114,115,49,52,48,53,32,110,111,110,45,100,101,102,97,117,108,116,115,49,52,48,54,41};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,61),40,109,97,107,101,45,105,102,45,116,114,101,101,32,118,97,114,115,49,51,57,56,32,100,101,102,97,117,108,116,101,114,115,49,51,57,57,32,98,111,100,121,45,112,114,111,99,49,52,48,48,32,114,101,115,116,49,52,48,49,41,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,31),40,112,114,101,102,105,120,45,115,121,109,32,112,114,101,102,105,120,49,52,52,51,32,115,121,109,49,52,52,52,41,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,13),40,103,49,52,53,52,32,118,49,52,54,53,41,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,15),40,103,49,53,49,49,32,118,97,114,49,53,50,50,41,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,58),40,114,101,99,117,114,32,118,97,114,115,49,51,56,57,32,100,101,102,97,117,108,116,101,114,45,110,97,109,101,115,49,51,57,48,32,100,101,102,115,49,51,57,49,32,110,101,120,116,45,103,117,121,49,51,57,50,41,0,0,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,53,48,53,32,103,49,53,49,55,49,53,50,52,41};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,52,55,54,32,103,49,52,56,56,49,52,57,52,41};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,52,52,56,32,103,49,52,54,48,49,52,54,55,41};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,52,49,56,32,103,49,52,51,48,49,52,51,54,41};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,28),40,97,55,48,51,51,32,102,111,114,109,49,51,55,53,32,114,49,51,55,54,32,99,49,51,55,55,41,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,7),40,103,49,51,52,55,41,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,51,52,49,32,103,49,51,53,51,49,51,54,51,41};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,30),40,101,120,112,97,110,100,32,99,108,97,117,115,101,115,49,51,49,56,32,101,108,115,101,63,49,51,49,57,41,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,28),40,97,55,52,55,51,32,102,111,114,109,49,51,48,54,32,114,49,51,48,55,32,99,49,51,48,56,41,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,13),40,102,111,108,100,32,98,115,49,50,56,51,41,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,28),40,97,55,54,51,57,32,102,111,114,109,49,50,55,55,32,114,49,50,55,56,32,99,49,50,55,57,41,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,32),40,113,117,111,116,105,102,121,45,112,114,111,99,49,50,53,54,32,120,115,49,50,53,57,32,105,100,49,50,54,48,41};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,28),40,97,55,55,51,54,32,102,111,114,109,49,50,53,51,32,114,49,50,53,52,32,99,49,50,53,53,41,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,28),40,97,55,56,52,48,32,102,111,114,109,49,50,52,53,32,114,49,50,52,54,32,99,49,50,52,55,41,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,13),40,103,49,49,48,52,32,118,49,49,49,53,41,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,14),40,108,111,111,107,117,112,32,118,49,49,50,52,41,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,13),40,103,49,50,49,50,32,118,49,50,50,51,41,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,50,48,54,32,103,49,50,49,56,49,50,50,56,41};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,49,56,48,32,103,49,49,57,50,49,49,57,56,41};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,14),40,103,49,49,54,51,32,118,98,49,49,55,52,41,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,49,53,55,32,103,49,49,54,57,49,50,51,53,41};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,49,51,48,32,103,49,49,52,50,49,49,52,57,41};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,48,57,56,32,103,49,49,49,48,49,49,49,55,41};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,48,55,48,32,103,49,48,56,50,49,48,56,57,41};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,28),40,97,55,56,56,56,32,102,111,114,109,49,48,54,50,32,114,49,48,54,51,32,99,49,48,54,52,41,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,20),40,102,111,108,100,32,118,98,105,110,100,105,110,103,115,49,48,53,51,41,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,28),40,97,56,50,50,54,32,102,111,114,109,49,48,52,54,32,114,49,48,52,55,32,99,49,48,52,56,41,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,23),40,97,112,112,101,110,100,42,56,55,55,32,105,108,56,56,51,32,108,56,56,52,41,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,22),40,109,97,112,42,56,55,56,32,112,114,111,99,56,56,53,32,108,56,56,54,41,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,11),40,103,57,51,56,32,118,57,52,57,41,0,0,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,13),40,108,111,111,107,117,112,32,118,57,53,56,41,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,12),40,103,57,56,57,32,118,49,48,48,48,41,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,22),40,109,97,112,45,108,111,111,112,57,56,51,32,103,57,57,53,49,48,48,50,41,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,35),40,102,111,108,100,32,108,108,105,115,116,115,57,55,49,32,101,120,112,115,57,55,50,32,108,108,105,115,116,115,50,57,55,51,41,0,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,48,49,56,32,103,49,48,51,48,49,48,51,55,41};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,108,108,105,115,116,115,57,54,49,32,97,99,99,57,54,50,41,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,57,51,50,32,103,57,52,52,57,53,49,41,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,108,108,105,115,116,115,57,50,48,32,97,99,99,57,50,49,41,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,56,57,52,32,103,57,48,54,57,49,50,41,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,25),40,97,56,50,56,48,32,102,111,114,109,56,55,50,32,114,56,55,51,32,99,56,55,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,26),40,102,111,114,45,101,97,99,104,45,108,111,111,112,56,53,48,32,103,56,53,55,56,54,51,41,0,0,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,25),40,97,56,55,52,57,32,102,111,114,109,56,52,53,32,114,56,52,54,32,99,56,52,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,29),40,109,97,112,45,108,111,111,112,56,49,48,32,103,56,50,50,56,51,53,32,103,56,50,51,56,51,54,41,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,55,56,49,32,103,55,57,51,55,57,57,41,0,0,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,25),40,97,56,56,49,50,32,102,111,114,109,55,54,51,32,114,55,54,52,32,99,55,54,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,25),40,97,56,57,55,56,32,102,111,114,109,55,53,54,32,114,55,53,55,32,99,55,53,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,25),40,97,57,48,48,54,32,102,111,114,109,55,52,57,32,114,55,53,48,32,99,55,53,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,11),40,103,53,57,57,32,122,54,49,48,41,0,0,0,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,6),40,103,54,50,55,41,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,12),40,103,55,49,57,32,97,50,55,51,51,41,0,0,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,29),40,109,97,112,45,108,111,111,112,55,49,51,32,103,55,50,53,55,51,56,32,103,55,50,54,55,51,57,41,0,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,29),40,109,97,112,45,108,111,111,112,54,56,50,32,103,54,57,52,55,48,50,32,103,54,57,53,55,48,51,41,0,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,29),40,109,97,112,45,108,111,111,112,54,53,49,32,103,54,54,51,54,55,49,32,103,54,54,52,54,55,50,41,0,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,54,50,49,32,103,54,51,51,54,52,48,41,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,53,57,51,32,103,54,48,53,54,49,50,41,0,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,53,54,54,32,103,53,55,56,53,56,52,41,0,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,53,51,57,32,103,53,53,49,53,53,55,41,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,25),40,97,57,48,51,48,32,102,111,114,109,53,50,55,32,114,53,50,56,32,99,53,50,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,115,115,53,48,54,41,0,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,25),40,97,57,52,57,56,32,102,111,114,109,52,57,49,32,114,52,57,50,32,99,52,57,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,6),40,103,50,48,53,41,0,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,6),40,103,50,51,51,41,0,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,29),40,109,97,112,45,108,111,111,112,52,53,54,32,103,52,54,56,52,56,49,32,103,52,54,57,52,56,50,41,0,0,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,29),40,109,97,112,45,108,111,111,112,52,50,48,32,103,52,51,50,52,52,53,32,103,52,51,51,52,52,54,41,0,0,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,29),40,109,97,112,45,108,111,111,112,51,56,52,32,103,51,57,54,52,48,57,32,103,51,57,55,52,49,48,41,0,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,29),40,109,97,112,45,108,111,111,112,51,52,56,32,103,51,54,48,51,55,51,32,103,51,54,49,51,55,52,41,0,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,29),40,109,97,112,45,108,111,111,112,51,49,52,32,103,51,50,54,51,51,55,32,103,51,50,55,51,51,56,41,0,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,110,51,51,52,41,0,0,0,0,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,29),40,109,97,112,45,108,111,111,112,50,53,55,32,103,50,54,57,51,48,51,32,103,50,55,48,51,48,52,41,0,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,50,55,56,32,103,50,57,48,50,57,54,41,0,0,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,50,50,55,32,103,50,51,57,50,52,54,41,0,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,49,57,57,32,103,50,49,49,50,49,56,41,0,0,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,49,55,50,32,103,49,56,52,49,57,48,41,0,0,0};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,25),40,97,57,53,57,57,32,102,111,114,109,49,54,52,32,114,49,54,53,32,99,49,54,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,26),40,97,49,48,50,51,50,32,102,111,114,109,49,53,48,32,114,49,53,49,32,99,49,53,50,41,0,0,0,0,0,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,26),40,97,49,48,51,48,55,32,102,111,114,109,49,51,48,32,114,49,51,49,32,99,49,51,50,41,0,0,0,0,0,0};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,26),40,97,49,48,51,57,54,32,102,111,114,109,49,50,50,32,114,49,50,51,32,99,49,50,52,41,0,0,0,0,0,0};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,26),40,97,49,48,52,49,51,32,102,111,114,109,49,49,54,32,114,49,49,55,32,99,49,49,56,41,0,0,0,0,0,0};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,26),40,97,49,48,52,50,55,32,102,111,114,109,49,48,57,32,114,49,49,48,32,99,49,49,49,41,0,0,0,0,0,0};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,23),40,97,49,48,52,55,54,32,102,111,114,109,56,55,32,114,56,56,32,99,56,57,41,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,12),40,103,51,49,32,115,108,111,116,52,50,41,0,0,0,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,22),40,109,97,112,115,108,111,116,115,32,115,108,111,116,115,54,50,32,105,54,51,41,0,0};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,18),40,109,97,112,45,108,111,111,112,50,53,32,103,51,55,53,50,41,0,0,0,0,0,0};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,20),40,97,49,48,53,54,57,32,120,49,51,32,114,49,52,32,99,49,53,41,0,0,0,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,20),40,97,49,48,57,50,57,32,102,111,114,109,54,32,114,55,32,99,56,41,0,0,0,0};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(f_9425)
static void C_fcall f_9425(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8796)
static void C_ccall f_8796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4150)
static void C_ccall f_4150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4152)
static void C_ccall f_4152(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9384)
static void C_ccall f_9384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9419)
static void C_ccall f_9419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9306)
static void C_fcall f_9306(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6789)
static void C_ccall f_6789(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6787)
static void C_ccall f_6787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5032)
static void C_ccall f_5032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5039)
static void C_ccall f_5039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9702)
static void C_fcall f_9702(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5028)
static void C_ccall f_5028(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5026)
static void C_ccall f_5026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9715)
static void C_fcall f_9715(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5011)
static void C_ccall f_5011(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6992)
static void C_ccall f_6992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7557)
static void C_ccall f_7557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7553)
static void C_ccall f_7553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5015)
static void C_ccall f_5015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7550)
static void C_ccall f_7550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9319)
static void C_fcall f_9319(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5321)
static void C_ccall f_5321(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5325)
static void C_ccall f_5325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5328)
static void C_ccall f_5328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6982)
static void C_ccall f_6982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5221)
static void C_ccall f_5221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8559)
static void C_fcall f_8559(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5224)
static void C_ccall f_5224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5311)
static void C_ccall f_5311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9007)
static void C_ccall f_9007(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5319)
static void C_ccall f_5319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9005)
static void C_ccall f_9005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7539)
static void C_ccall f_7539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7536)
static void C_ccall f_7536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7530)
static void C_ccall f_7530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9011)
static void C_ccall f_9011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4213)
static void C_fcall f_4213(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8531)
static void C_ccall f_8531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(C_chicken_2dsyntax_toplevel)
C_externexport void C_ccall C_chicken_2dsyntax_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9029)
static void C_ccall f_9029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10233)
static void C_ccall f_10233(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9031)
static void C_ccall f_9031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10231)
static void C_ccall f_10231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8766)
static void C_ccall f_8766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5047)
static void C_ccall f_5047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8594)
static void C_fcall f_8594(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8775)
static void C_ccall f_8775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10237)
static void C_ccall f_10237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5341)
static void C_fcall f_5341(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9058)
static void C_ccall f_9058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9050)
static void C_ccall f_9050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7587)
static void C_ccall f_7587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7589)
static void C_fcall f_7589(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8748)
static void C_ccall f_8748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5247)
static void C_ccall f_5247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5241)
static void C_ccall f_5241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5331)
static void C_ccall f_5331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5334)
static void C_ccall f_5334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8750)
static void C_ccall f_8750(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8754)
static void C_ccall f_8754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8759)
static void C_ccall f_8759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10272)
static void C_fcall f_10272(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5001)
static void C_ccall f_5001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10249)
static void C_ccall f_10249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5009)
static void C_ccall f_5009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4273)
static void C_ccall f_4273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5393)
static void C_ccall f_5393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6401)
static void C_ccall f_6401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6407)
static void C_ccall f_6407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6404)
static void C_ccall f_6404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5383)
static void C_ccall f_5383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5061)
static void C_ccall f_5061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5287)
static void C_ccall f_5287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5055)
static void C_ccall f_5055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5057)
static void C_ccall f_5057(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4267)
static void C_ccall f_4267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4264)
static void C_ccall f_4264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6426)
static void C_ccall f_6426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6410)
static void C_ccall f_6410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6413)
static void C_ccall f_6413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6416)
static void C_ccall f_6416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6419)
static void C_ccall f_6419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7576)
static C_word C_fcall f_7576(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_4289)
static void C_ccall f_4289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4282)
static void C_fcall f_4282(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7572)
static void C_ccall f_7572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4258)
static void C_ccall f_4258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6464)
static void C_fcall f_6464(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10089)
static void C_fcall f_10089(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6468)
static void C_ccall f_6468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6454)
static void C_ccall f_6454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6450)
static void C_ccall f_6450(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3706)
static void C_ccall f_3706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6480)
static void C_ccall f_6480(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6484)
static void C_ccall f_6484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9217)
static void C_fcall f_9217(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6470)
static void C_ccall f_6470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6478)
static void C_ccall f_6478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6853)
static void C_ccall f_6853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8312)
static void C_ccall f_8312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8319)
static void C_ccall f_8319(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5367)
static void C_ccall f_5367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5360)
static void C_ccall f_5360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5264)
static void C_ccall f_5264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3747)
static void C_ccall f_3747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3743)
static void C_ccall f_3743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5354)
static void C_ccall f_5354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5351)
static void C_ccall f_5351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9204)
static void C_fcall f_9204(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3750)
static void C_ccall f_3750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3753)
static void C_ccall f_3753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3756)
static void C_ccall f_3756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9257)
static void C_fcall f_9257(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6825)
static void C_ccall f_6825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6827)
static void C_fcall f_6827(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3722)
static void C_ccall f_3722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3724)
static void C_ccall f_3724(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6763)
static void C_ccall f_6763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6767)
static void C_ccall f_6767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6811)
static void C_ccall f_6811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6814)
static void C_ccall f_6814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3734)
static void C_ccall f_3734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6793)
static void C_ccall f_6793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6805)
static void C_ccall f_6805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6808)
static void C_ccall f_6808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3830)
static void C_fcall f_3830(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6775)
static void C_ccall f_6775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6779)
static void C_ccall f_6779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6771)
static void C_ccall f_6771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8279)
static void C_ccall f_8279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7174)
static void C_ccall f_7174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3817)
static void C_fcall f_3817(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3815)
static void C_ccall f_3815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8269)
static void C_ccall f_8269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8291)
static void C_ccall f_8291(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7198)
static void C_ccall f_7198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8281)
static void C_ccall f_8281(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8285)
static void C_ccall f_8285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6440)
static void C_ccall f_6440(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6607)
static void C_ccall f_6607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6438)
static void C_ccall f_6438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6943)
static void C_ccall f_6943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6945)
static void C_ccall f_6945(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6935)
static void C_ccall f_6935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3392)
static void C_ccall f_3392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3395)
static void C_ccall f_3395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3398)
static void C_ccall f_3398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6949)
static void C_ccall f_6949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10930)
static void C_ccall f_10930(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10934)
static void C_ccall f_10934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10920)
static void C_ccall f_10920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10928)
static void C_ccall f_10928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7016)
static void C_ccall f_7016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3388)
static void C_ccall f_3388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6618)
static void C_ccall f_6618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6952)
static void C_ccall f_6952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6706)
static void C_fcall f_6706(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6704)
static void C_ccall f_6704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6735)
static void C_ccall f_6735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7024)
static void C_ccall f_7024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7020)
static void C_ccall f_7020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7057)
static void C_ccall f_7057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7034)
static void C_ccall f_7034(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7032)
static void C_ccall f_7032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6655)
static void C_ccall f_6655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7038)
static void C_ccall f_7038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8817)
static void C_ccall f_8817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8813)
static void C_ccall f_8813(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8811)
static void C_ccall f_8811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4088)
static void C_ccall f_4088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4090)
static void C_ccall f_4090(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3774)
static void C_ccall f_3774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3777)
static void C_ccall f_3777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4913)
static void C_ccall f_4913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4903)
static void C_fcall f_4903(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4927)
static void C_fcall f_4927(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9646)
static void C_ccall f_9646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8483)
static void C_fcall f_8483(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9639)
static void C_ccall f_9639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9636)
static void C_ccall f_9636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4940)
static void C_ccall f_4940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8494)
static void C_ccall f_8494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7492)
static void C_ccall f_7492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9692)
static void C_ccall f_9692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9683)
static void C_ccall f_9683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4014)
static void C_fcall f_4014(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7472)
static void C_ccall f_7472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9061)
static void C_ccall f_9061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9067)
static void C_ccall f_9067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8444)
static void C_fcall f_8444(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8442)
static void C_ccall f_8442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5931)
static C_word C_fcall f_5931(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_9670)
static void C_ccall f_9670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9679)
static void C_ccall f_9679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9071)
static void C_fcall f_9071(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9070)
static void C_ccall f_9070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5947)
static void C_fcall f_5947(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9079)
static void C_ccall f_9079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5945)
static void C_ccall f_5945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4031)
static void C_ccall f_4031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9086)
static void C_fcall f_9086(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9085)
static void C_ccall f_9085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9097)
static void C_ccall f_9097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9094)
static void C_ccall f_9094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8473)
static void C_ccall f_8473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5416)
static void C_ccall f_5416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5419)
static void C_ccall f_5419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5906)
static void C_fcall f_5906(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5909)
static void C_fcall f_5909(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5903)
static void C_fcall f_5903(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9624)
static void C_ccall f_9624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9627)
static void C_ccall f_9627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9628)
static void C_fcall f_9628(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9615)
static void C_ccall f_9615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9616)
static void C_fcall f_9616(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8436)
static void C_ccall f_8436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9600)
static void C_ccall f_9600(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9604)
static void C_ccall f_9604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4303)
static void C_ccall f_4303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7889)
static void C_ccall f_7889(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7887)
static void C_ccall f_7887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7883)
static void C_ccall f_7883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8632)
static void C_ccall f_8632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8638)
static void C_fcall f_8638(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7474)
static void C_ccall f_7474(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7478)
static void C_ccall f_7478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5132)
static void C_ccall f_5132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4314)
static void C_ccall f_4314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4317)
static void C_ccall f_4317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5135)
static void C_ccall f_5135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7893)
static void C_ccall f_7893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7486)
static void C_ccall f_7486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7489)
static void C_ccall f_7489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5120)
static void C_ccall f_5120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4323)
static void C_ccall f_4323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5122)
static void C_ccall f_5122(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5129)
static void C_ccall f_5129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5126)
static void C_ccall f_5126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8667)
static void C_ccall f_8667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7468)
static void C_ccall f_7468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7464)
static void C_ccall f_7464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5499)
static void C_ccall f_5499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5491)
static void C_ccall f_5491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8673)
static void C_fcall f_8673(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8686)
static void C_ccall f_8686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5155)
static void C_ccall f_5155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5152)
static void C_ccall f_5152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8977)
static void C_ccall f_8977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8979)
static void C_ccall f_8979(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5142)
static void C_fcall f_5142(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5637)
static void C_ccall f_5637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8983)
static void C_ccall f_8983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4399)
static void C_ccall f_4399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5607)
static void C_ccall f_5607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4393)
static void C_ccall f_4393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4395)
static void C_ccall f_4395(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5442)
static void C_ccall f_5442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5603)
static void C_fcall f_5603(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3876)
static void C_ccall f_3876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3783)
static void C_ccall f_3783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5658)
static void C_ccall f_5658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5436)
static void C_ccall f_5436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7867)
static void C_ccall f_7867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4594)
static void C_ccall f_4594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8965)
static void C_ccall f_8965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3895)
static void C_fcall f_3895(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7841)
static void C_ccall f_7841(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4893)
static void C_ccall f_4893(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3884)
static void C_ccall f_3884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4891)
static void C_ccall f_4891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3764)
static void C_fcall f_3764(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4539)
static void C_ccall f_4539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7845)
static void C_ccall f_7845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7848)
static void C_ccall f_7848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5172)
static void C_ccall f_5172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4351)
static void C_fcall f_4351(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4545)
static void C_ccall f_4545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4548)
static void C_ccall f_4548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4541)
static void C_ccall f_4541(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4362)
static void C_ccall f_4362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5161)
static void C_ccall f_5161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10518)
static void C_fcall f_10518(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10582)
static void C_ccall f_10582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10585)
static void C_ccall f_10585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10588)
static void C_ccall f_10588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6145)
static void C_ccall f_6145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9270)
static void C_fcall f_9270(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6159)
static void C_ccall f_6159(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6157)
static void C_ccall f_6157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3613)
static void C_ccall f_3613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3616)
static void C_ccall f_3616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10570)
static void C_ccall f_10570(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10574)
static void C_ccall f_10574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10481)
static void C_ccall f_10481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6149)
static void C_ccall f_6149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10568)
static void C_ccall f_10568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10475)
static void C_ccall f_10475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10477)
static void C_ccall f_10477(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10397)
static void C_ccall f_10397(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10395)
static void C_ccall f_10395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5198)
static void C_ccall f_5198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4339)
static void C_ccall f_4339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4332)
static void C_fcall f_4332(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3601)
static void C_ccall f_3601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3603)
static void C_ccall f_3603(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3607)
static void C_ccall f_3607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7739)
static void C_fcall f_7739(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7735)
static void C_ccall f_7735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5188)
static void C_ccall f_5188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10385)
static void C_ccall f_10385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7737)
static void C_ccall f_7737(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10378)
static void C_ccall f_10378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6109)
static void C_ccall f_6109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6163)
static void C_ccall f_6163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3637)
static void C_fcall f_3637(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6166)
static void C_ccall f_6166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6169)
static void C_ccall f_6169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3641)
static void C_ccall f_3641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10699)
static void C_ccall f_10699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3648)
static void C_ccall f_3648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10696)
static void C_ccall f_10696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10693)
static void C_ccall f_10693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9107)
static void C_ccall f_9107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3525)
static void C_ccall f_3525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3528)
static void C_ccall f_3528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3522)
static void C_ccall f_3522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10401)
static void C_ccall f_10401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3516)
static void C_ccall f_3516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3519)
static void C_ccall f_3519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3513)
static void C_ccall f_3513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3510)
static void C_ccall f_3510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10326)
static void C_fcall f_10326(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10323)
static void C_ccall f_10323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10428)
static void C_ccall f_10428(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10426)
static void C_ccall f_10426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10312)
static void C_ccall f_10312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10414)
static void C_ccall f_10414(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10412)
static void C_ccall f_10412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7088)
static void C_ccall f_7088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6180)
static void C_ccall f_6180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10306)
static void C_ccall f_10306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10308)
static void C_ccall f_10308(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6196)
static void C_ccall f_6196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7061)
static void C_ccall f_7061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7067)
static void C_fcall f_7067(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7065)
static void C_ccall f_7065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10432)
static void C_ccall f_10432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9121)
static void C_ccall f_9121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3504)
static void C_ccall f_3504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3507)
static void C_ccall f_3507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10368)
static void C_ccall f_10368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3501)
static void C_ccall f_3501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10349)
static void C_fcall f_10349(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4768)
static void C_ccall f_4768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4793)
static void C_ccall f_4793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4799)
static void C_ccall f_4799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4790)
static void C_ccall f_4790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3547)
static void C_ccall f_3547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3541)
static void C_ccall f_3541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3543)
static void C_ccall f_3543(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5868)
static void C_ccall f_5868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4784)
static void C_ccall f_4784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3537)
static void C_ccall f_3537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3531)
static void C_ccall f_3531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3534)
static void C_ccall f_3534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5878)
static void C_ccall f_5878(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5876)
static void C_ccall f_5876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5888)
static void C_ccall f_5888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8711)
static void C_fcall f_8711(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5882)
static void C_ccall f_5882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5885)
static void C_ccall f_5885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7206)
static void C_ccall f_7206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5897)
static void C_ccall f_5897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5899)
static void C_ccall f_5899(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5891)
static void C_ccall f_5891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5894)
static void C_ccall f_5894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7715)
static void C_ccall f_7715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9598)
static void C_ccall f_9598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3585)
static void C_ccall f_3585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4865)
static void C_ccall f_4865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9585)
static void C_ccall f_9585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8058)
static void C_ccall f_8058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7239)
static void C_ccall f_7239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7235)
static void C_ccall f_7235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7248)
static void C_ccall f_7248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4879)
static void C_ccall f_4879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7240)
static void C_fcall f_7240(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8106)
static void C_fcall f_8106(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8100)
static void C_ccall f_8100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7217)
static void C_ccall f_7217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9550)
static void C_fcall f_9550(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7214)
static void C_ccall f_7214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7226)
static void C_ccall f_7226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7227)
static void C_fcall f_7227(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7220)
static void C_ccall f_7220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9571)
static void C_ccall f_9571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9578)
static void C_ccall f_9578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3562)
static void C_ccall f_3562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9561)
static void C_ccall f_9561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3559)
static void C_ccall f_3559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3556)
static void C_ccall f_3556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7921)
static void C_ccall f_7921(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7920)
static void C_ccall f_7920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7314)
static void C_fcall f_7314(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8141)
static void C_fcall f_8141(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7257)
static void C_ccall f_7257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7914)
static void C_ccall f_7914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7910)
static void C_ccall f_7910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7254)
static void C_ccall f_7254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7902)
static void C_fcall f_7902(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7901)
static void C_ccall f_7901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7839)
static void C_ccall f_7839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7827)
static void C_ccall f_7827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9982)
static void C_fcall f_9982(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9894)
static void C_fcall f_9894(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9954)
static void C_ccall f_9954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9958)
static void C_ccall f_9958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9945)
static void C_ccall f_9945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4656)
static void C_ccall f_4656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5827)
static void C_fcall f_5827(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6056)
static void C_ccall f_6056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4658)
static void C_ccall f_4658(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8023)
static void C_ccall f_8023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9845)
static void C_fcall f_9845(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6049)
static void C_ccall f_6049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4648)
static void C_ccall f_4648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8029)
static void C_fcall f_8029(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9967)
static void C_ccall f_9967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9969)
static void C_fcall f_9969(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4617)
static void C_ccall f_4617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4619)
static void C_fcall f_4619(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5777)
static C_word C_fcall f_5777(C_word t0,C_word t1);
C_noret_decl(f_6080)
static void C_fcall f_6080(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4603)
static void C_ccall f_4603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5790)
static void C_ccall f_5790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5792)
static void C_fcall f_5792(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6027)
static void C_ccall f_6027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7349)
static void C_fcall f_7349(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7343)
static void C_ccall f_7343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9858)
static void C_fcall f_9858(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6694)
static void C_ccall f_6694(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5520)
static void C_ccall f_5520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5523)
static void C_ccall f_5523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6060)
static void C_ccall f_6060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5529)
static void C_ccall f_5529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8364)
static void C_ccall f_8364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8368)
static void C_fcall f_8368(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8367)
static void C_ccall f_8367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7384)
static void C_fcall f_7384(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7784)
static void C_ccall f_7784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7644)
static void C_ccall f_7644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8885)
static void C_ccall f_8885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7780)
static void C_ccall f_7780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7640)
static void C_ccall f_7640(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8887)
static void C_fcall f_8887(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5501)
static void C_ccall f_5501(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3978)
static void C_ccall f_3978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5505)
static void C_ccall f_5505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10020)
static void C_fcall f_10020(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8346)
static void C_ccall f_8346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8342)
static void C_ccall f_8342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7654)
static void C_fcall f_7654(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3960)
static void C_fcall f_3960(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6864)
static void C_ccall f_6864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10194)
static void C_fcall f_10194(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5595)
static void C_fcall f_5595(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5599)
static void C_ccall f_5599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10034)
static void C_ccall f_10034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10188)
static void C_ccall f_10188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8376)
static void C_ccall f_8376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8380)
static void C_ccall f_8380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8387)
static void C_ccall f_8387(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8386)
static void C_ccall f_8386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4415)
static void C_ccall f_4415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7985)
static void C_ccall f_7985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8858)
static void C_ccall f_8858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5737)
static void C_ccall f_5737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10053)
static void C_fcall f_10053(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7994)
static void C_fcall f_7994(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7992)
static void C_ccall f_7992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10153)
static void C_ccall f_10153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6503)
static void C_ccall f_6503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6505)
static void C_fcall f_6505(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6518)
static void C_fcall f_6518(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10159)
static void C_fcall f_10159(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4437)
static void C_ccall f_4437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4431)
static void C_ccall f_4431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4433)
static void C_ccall f_4433(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9167)
static C_word C_fcall f_9167(C_word *a,C_word t0,C_word t1,C_word t2);
C_noret_decl(f_9165)
static void C_ccall f_9165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7977)
static void C_fcall f_7977(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4446)
static void C_ccall f_4446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7975)
static void C_ccall f_7975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5582)
static void C_fcall f_5582(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5588)
static void C_fcall f_5588(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3677)
static void C_fcall f_3677(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7755)
static void C_ccall f_7755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7945)
static void C_ccall f_7945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7949)
static void C_ccall f_7949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4454)
static void C_ccall f_4454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3675)
static void C_ccall f_3675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7752)
static void C_fcall f_7752(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5538)
static void C_ccall f_5538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5532)
static void C_ccall f_5532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10124)
static void C_fcall f_10124(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6326)
static void C_ccall f_6326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7764)
static void C_fcall f_7764(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10713)
static void C_ccall f_10713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8398)
static void C_ccall f_8398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5561)
static void C_ccall f_5561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7951)
static void C_fcall f_7951(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5563)
static void C_fcall f_5563(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10040)
static void C_fcall f_10040(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7638)
static void C_ccall f_7638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4489)
static void C_ccall f_4489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7743)
static void C_ccall f_7743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7681)
static void C_ccall f_7681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7696)
static void C_ccall f_7696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7699)
static void C_ccall f_7699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4493)
static void C_fcall f_4493(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10822)
static void C_ccall f_10822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10826)
static void C_ccall f_10826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7503)
static void C_ccall f_7503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7505)
static void C_fcall f_7505(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7419)
static void C_fcall f_7419(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10891)
static void C_fcall f_10891(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7413)
static void C_ccall f_7413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10725)
static void C_ccall f_10725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10729)
static void C_fcall f_10729(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9194)
static void C_ccall f_9194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8625)
static void C_ccall f_8625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6349)
static void C_ccall f_6349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10841)
static void C_ccall f_10841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8900)
static void C_fcall f_8900(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6296)
static void C_ccall f_6296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10867)
static void C_ccall f_10867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10861)
static void C_ccall f_10861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6554)
static void C_fcall f_6554(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10652)
static void C_ccall f_10652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6398)
static void C_ccall f_6398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4464)
static void C_ccall f_4464(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4462)
static void C_ccall f_4462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10887)
static void C_ccall f_10887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6395)
static void C_ccall f_6395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6392)
static void C_ccall f_6392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6389)
static void C_ccall f_6389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10503)
static void C_ccall f_10503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6381)
static void C_ccall f_6381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6377)
static void C_ccall f_6377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6282)
static void C_ccall f_6282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10591)
static void C_ccall f_10591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10592)
static void C_fcall f_10592(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6272)
static void C_ccall f_6272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3944)
static void C_ccall f_3944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9835)
static void C_ccall f_9835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6276)
static void C_ccall f_6276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6278)
static void C_ccall f_6278(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3413)
static void C_ccall f_3413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3410)
static void C_ccall f_3410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9822)
static void C_ccall f_9822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3958)
static void C_ccall f_3958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3425)
static void C_ccall f_3425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3428)
static void C_ccall f_3428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9826)
static void C_ccall f_9826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9810)
static void C_ccall f_9810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3416)
static void C_ccall f_3416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3419)
static void C_ccall f_3419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9907)
static void C_fcall f_9907(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7278)
static void C_ccall f_7278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3913)
static void C_ccall f_3913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3915)
static void C_fcall f_3915(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6268)
static void C_ccall f_6268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7272)
static void C_ccall f_7272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7275)
static void C_ccall f_7275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3401)
static void C_ccall f_3401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7288)
static void C_ccall f_7288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7281)
static void C_ccall f_7281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10677)
static void C_fcall f_10677(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10675)
static void C_ccall f_10675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4671)
static void C_ccall f_4671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9518)
static void C_ccall f_9518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3404)
static void C_ccall f_3404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3407)
static void C_ccall f_3407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4665)
static void C_ccall f_4665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4662)
static void C_ccall f_4662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4668)
static void C_ccall f_4668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3422)
static void C_ccall f_3422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10620)
static void C_ccall f_10620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9512)
static void C_ccall f_9512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9515)
static void C_ccall f_9515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7260)
static void C_ccall f_7260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4694)
static void C_ccall f_4694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7263)
static void C_ccall f_7263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4697)
static void C_ccall f_4697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7264)
static void C_fcall f_7264(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9503)
static void C_ccall f_9503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6363)
static void C_fcall f_6363(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6357)
static void C_fcall f_6357(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6355)
static void C_ccall f_6355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6351)
static void C_ccall f_6351(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3495)
static void C_ccall f_3495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3492)
static void C_ccall f_3492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3498)
static void C_ccall f_3498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8071)
static void C_fcall f_8071(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8186)
static void C_ccall f_8186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8188)
static void C_fcall f_8188(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9521)
static void C_ccall f_9521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3447)
static void C_ccall f_3447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3441)
static void C_ccall f_3441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3444)
static void C_ccall f_3444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8170)
static void C_ccall f_8170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8069)
static void C_ccall f_8069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3438)
static void C_ccall f_3438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3431)
static void C_ccall f_3431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3434)
static void C_ccall f_3434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8936)
static void C_fcall f_8936(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3480)
static void C_ccall f_3480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3471)
static void C_ccall f_3471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7114)
static void C_ccall f_7114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3483)
static void C_ccall f_3483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3486)
static void C_ccall f_3486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3489)
static void C_ccall f_3489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7118)
static void C_ccall f_7118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3474)
static void C_ccall f_3474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3477)
static void C_ccall f_3477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8231)
static void C_ccall f_8231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7134)
static void C_fcall f_7134(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4994)
static void C_ccall f_4994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8239)
static void C_ccall f_8239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4990)
static void C_ccall f_4990(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8225)
static void C_ccall f_8225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8227)
static void C_ccall f_8227(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4988)
static void C_ccall f_4988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7106)
static void C_ccall f_7106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8244)
static void C_fcall f_8244(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3450)
static void C_ccall f_3450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7128)
static void C_fcall f_7128(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3468)
static void C_ccall f_3468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3465)
static void C_ccall f_3465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3462)
static void C_ccall f_3462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3459)
static void C_ccall f_3459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3456)
static void C_ccall f_3456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3453)
static void C_ccall f_3453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7148)
static void C_ccall f_7148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8412)
static void C_fcall f_8412(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8410)
static void C_ccall f_8410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4178)
static void C_fcall f_4178(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8428)
static void C_fcall f_8428(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4808)
static void C_fcall f_4808(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4142)
static void C_ccall f_4142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9460)
static void C_fcall f_9460(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4168)
static void C_ccall f_4168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4829)
static void C_ccall f_4829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9751)
static void C_fcall f_9751(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4815)
static void C_ccall f_4815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4843)
static void C_ccall f_4843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4840)
static void C_ccall f_4840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4849)
static void C_ccall f_4849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9355)
static void C_fcall f_9355(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4755)
static void C_ccall f_4755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9764)
static void C_fcall f_9764(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9497)
static void C_ccall f_9497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9499)
static void C_ccall f_9499(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4743)
static void C_ccall f_4743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4745)
static void C_ccall f_4745(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4858)
static void C_fcall f_4858(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9390)
static void C_fcall f_9390(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4114)
static void C_ccall f_4114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4132)
static void C_ccall f_4132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8786)
static void C_fcall f_8786(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8782)
static void C_ccall f_8782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4100)
static void C_ccall f_4100(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_9425)
static void C_fcall trf_9425(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9425(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9425(t0,t1,t2);}

C_noret_decl(trf_9306)
static void C_fcall trf_9306(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9306(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9306(t0,t1,t2,t3);}

C_noret_decl(trf_9702)
static void C_fcall trf_9702(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9702(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9702(t0,t1,t2,t3);}

C_noret_decl(trf_9715)
static void C_fcall trf_9715(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9715(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9715(t0,t1);}

C_noret_decl(trf_9319)
static void C_fcall trf_9319(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9319(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9319(t0,t1);}

C_noret_decl(trf_8559)
static void C_fcall trf_8559(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8559(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8559(t0,t1,t2);}

C_noret_decl(trf_4213)
static void C_fcall trf_4213(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4213(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4213(t0,t1,t2);}

C_noret_decl(trf_8594)
static void C_fcall trf_8594(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8594(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8594(t0,t1,t2,t3);}

C_noret_decl(trf_5341)
static void C_fcall trf_5341(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5341(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5341(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7589)
static void C_fcall trf_7589(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7589(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7589(t0,t1,t2);}

C_noret_decl(trf_10272)
static void C_fcall trf_10272(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10272(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10272(t0,t1);}

C_noret_decl(trf_4282)
static void C_fcall trf_4282(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4282(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4282(t0,t1,t2,t3);}

C_noret_decl(trf_6464)
static void C_fcall trf_6464(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6464(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6464(t0,t1);}

C_noret_decl(trf_10089)
static void C_fcall trf_10089(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10089(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10089(t0,t1,t2);}

C_noret_decl(trf_9217)
static void C_fcall trf_9217(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9217(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9217(t0,t1);}

C_noret_decl(trf_9204)
static void C_fcall trf_9204(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9204(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9204(t0,t1,t2,t3);}

C_noret_decl(trf_9257)
static void C_fcall trf_9257(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9257(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9257(t0,t1,t2,t3);}

C_noret_decl(trf_6827)
static void C_fcall trf_6827(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6827(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6827(t0,t1,t2,t3);}

C_noret_decl(trf_3830)
static void C_fcall trf_3830(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3830(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3830(t0,t1);}

C_noret_decl(trf_3817)
static void C_fcall trf_3817(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3817(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3817(t0,t1,t2,t3);}

C_noret_decl(trf_6706)
static void C_fcall trf_6706(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6706(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6706(t0,t1,t2);}

C_noret_decl(trf_4903)
static void C_fcall trf_4903(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4903(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4903(t0,t1);}

C_noret_decl(trf_4927)
static void C_fcall trf_4927(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4927(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4927(t0,t1);}

C_noret_decl(trf_8483)
static void C_fcall trf_8483(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8483(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8483(t0,t1);}

C_noret_decl(trf_4014)
static void C_fcall trf_4014(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4014(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4014(t0,t1);}

C_noret_decl(trf_8444)
static void C_fcall trf_8444(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8444(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8444(t0,t1,t2);}

C_noret_decl(trf_9071)
static void C_fcall trf_9071(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9071(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9071(t0,t1,t2);}

C_noret_decl(trf_5947)
static void C_fcall trf_5947(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5947(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5947(t0,t1,t2);}

C_noret_decl(trf_9086)
static void C_fcall trf_9086(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9086(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9086(t0,t1);}

C_noret_decl(trf_5906)
static void C_fcall trf_5906(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5906(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5906(t0,t1);}

C_noret_decl(trf_5909)
static void C_fcall trf_5909(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5909(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5909(t0,t1);}

C_noret_decl(trf_5903)
static void C_fcall trf_5903(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5903(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5903(t0,t1);}

C_noret_decl(trf_9628)
static void C_fcall trf_9628(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9628(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9628(t0,t1);}

C_noret_decl(trf_9616)
static void C_fcall trf_9616(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9616(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9616(t0,t1);}

C_noret_decl(trf_8638)
static void C_fcall trf_8638(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8638(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8638(t0,t1,t2);}

C_noret_decl(trf_8673)
static void C_fcall trf_8673(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8673(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8673(t0,t1,t2,t3);}

C_noret_decl(trf_5142)
static void C_fcall trf_5142(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5142(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5142(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5603)
static void C_fcall trf_5603(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5603(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5603(t0,t1);}

C_noret_decl(trf_3895)
static void C_fcall trf_3895(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3895(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3895(t0,t1);}

C_noret_decl(trf_3764)
static void C_fcall trf_3764(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3764(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3764(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4351)
static void C_fcall trf_4351(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4351(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4351(t0,t1);}

C_noret_decl(trf_10518)
static void C_fcall trf_10518(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10518(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10518(t0,t1);}

C_noret_decl(trf_9270)
static void C_fcall trf_9270(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9270(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9270(t0,t1);}

C_noret_decl(trf_4332)
static void C_fcall trf_4332(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4332(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4332(t0,t1,t2,t3);}

C_noret_decl(trf_7739)
static void C_fcall trf_7739(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7739(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7739(t0,t1,t2,t3);}

C_noret_decl(trf_3637)
static void C_fcall trf_3637(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3637(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3637(t0,t1,t2);}

C_noret_decl(trf_10326)
static void C_fcall trf_10326(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10326(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10326(t0,t1);}

C_noret_decl(trf_7067)
static void C_fcall trf_7067(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7067(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7067(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_10349)
static void C_fcall trf_10349(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10349(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10349(t0,t1);}

C_noret_decl(trf_8711)
static void C_fcall trf_8711(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8711(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8711(t0,t1,t2);}

C_noret_decl(trf_7240)
static void C_fcall trf_7240(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7240(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7240(t0,t1,t2);}

C_noret_decl(trf_8106)
static void C_fcall trf_8106(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8106(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8106(t0,t1,t2);}

C_noret_decl(trf_9550)
static void C_fcall trf_9550(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9550(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9550(t0,t1,t2);}

C_noret_decl(trf_7227)
static void C_fcall trf_7227(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7227(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7227(t0,t1,t2);}

C_noret_decl(trf_7314)
static void C_fcall trf_7314(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7314(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7314(t0,t1,t2);}

C_noret_decl(trf_8141)
static void C_fcall trf_8141(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8141(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8141(t0,t1,t2);}

C_noret_decl(trf_7902)
static void C_fcall trf_7902(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7902(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7902(t0,t1,t2);}

C_noret_decl(trf_9982)
static void C_fcall trf_9982(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9982(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9982(t0,t1);}

C_noret_decl(trf_9894)
static void C_fcall trf_9894(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9894(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9894(t0,t1,t2,t3);}

C_noret_decl(trf_5827)
static void C_fcall trf_5827(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5827(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5827(t0,t1,t2);}

C_noret_decl(trf_9845)
static void C_fcall trf_9845(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9845(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9845(t0,t1,t2,t3);}

C_noret_decl(trf_8029)
static void C_fcall trf_8029(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8029(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8029(t0,t1,t2);}

C_noret_decl(trf_9969)
static void C_fcall trf_9969(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9969(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9969(t0,t1,t2,t3);}

C_noret_decl(trf_4619)
static void C_fcall trf_4619(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4619(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4619(t0,t1,t2);}

C_noret_decl(trf_6080)
static void C_fcall trf_6080(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6080(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6080(t0,t1,t2);}

C_noret_decl(trf_5792)
static void C_fcall trf_5792(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5792(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5792(t0,t1,t2);}

C_noret_decl(trf_7349)
static void C_fcall trf_7349(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7349(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7349(t0,t1,t2);}

C_noret_decl(trf_9858)
static void C_fcall trf_9858(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9858(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9858(t0,t1);}

C_noret_decl(trf_8368)
static void C_fcall trf_8368(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8368(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8368(t0,t1,t2);}

C_noret_decl(trf_7384)
static void C_fcall trf_7384(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7384(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7384(t0,t1,t2);}

C_noret_decl(trf_8887)
static void C_fcall trf_8887(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8887(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8887(t0,t1,t2,t3);}

C_noret_decl(trf_10020)
static void C_fcall trf_10020(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10020(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10020(t0,t1,t2);}

C_noret_decl(trf_7654)
static void C_fcall trf_7654(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7654(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7654(t0,t1,t2);}

C_noret_decl(trf_3960)
static void C_fcall trf_3960(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3960(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3960(t0,t1,t2,t3);}

C_noret_decl(trf_10194)
static void C_fcall trf_10194(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10194(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10194(t0,t1,t2);}

C_noret_decl(trf_5595)
static void C_fcall trf_5595(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5595(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5595(t0,t1);}

C_noret_decl(trf_10053)
static void C_fcall trf_10053(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10053(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10053(t0,t1);}

C_noret_decl(trf_7994)
static void C_fcall trf_7994(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7994(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7994(t0,t1,t2);}

C_noret_decl(trf_6505)
static void C_fcall trf_6505(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6505(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6505(t0,t1,t2,t3);}

C_noret_decl(trf_6518)
static void C_fcall trf_6518(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6518(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6518(t0,t1);}

C_noret_decl(trf_10159)
static void C_fcall trf_10159(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10159(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10159(t0,t1,t2);}

C_noret_decl(trf_7977)
static void C_fcall trf_7977(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7977(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7977(t0,t1,t2);}

C_noret_decl(trf_5582)
static void C_fcall trf_5582(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5582(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5582(t0,t1);}

C_noret_decl(trf_5588)
static void C_fcall trf_5588(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5588(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5588(t0,t1);}

C_noret_decl(trf_3677)
static void C_fcall trf_3677(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3677(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3677(t0,t1,t2);}

C_noret_decl(trf_7752)
static void C_fcall trf_7752(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7752(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7752(t0,t1);}

C_noret_decl(trf_10124)
static void C_fcall trf_10124(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10124(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10124(t0,t1,t2);}

C_noret_decl(trf_7764)
static void C_fcall trf_7764(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7764(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7764(t0,t1);}

C_noret_decl(trf_7951)
static void C_fcall trf_7951(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7951(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7951(t0,t1,t2);}

C_noret_decl(trf_5563)
static void C_fcall trf_5563(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5563(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5563(t0,t1,t2,t3);}

C_noret_decl(trf_10040)
static void C_fcall trf_10040(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10040(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10040(t0,t1,t2,t3);}

C_noret_decl(trf_4493)
static void C_fcall trf_4493(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4493(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4493(t0,t1);}

C_noret_decl(trf_7505)
static void C_fcall trf_7505(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7505(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7505(t0,t1,t2,t3);}

C_noret_decl(trf_7419)
static void C_fcall trf_7419(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7419(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7419(t0,t1,t2);}

C_noret_decl(trf_10891)
static void C_fcall trf_10891(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10891(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10891(t0,t1,t2);}

C_noret_decl(trf_10729)
static void C_fcall trf_10729(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10729(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10729(t0,t1);}

C_noret_decl(trf_8900)
static void C_fcall trf_8900(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8900(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8900(t0,t1);}

C_noret_decl(trf_6554)
static void C_fcall trf_6554(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6554(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6554(t0,t1,t2,t3);}

C_noret_decl(trf_10592)
static void C_fcall trf_10592(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10592(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10592(t0,t1,t2);}

C_noret_decl(trf_9907)
static void C_fcall trf_9907(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9907(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9907(t0,t1);}

C_noret_decl(trf_3915)
static void C_fcall trf_3915(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3915(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3915(t0,t1,t2);}

C_noret_decl(trf_10677)
static void C_fcall trf_10677(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10677(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10677(t0,t1,t2,t3);}

C_noret_decl(trf_7264)
static void C_fcall trf_7264(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7264(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7264(t0,t1,t2);}

C_noret_decl(trf_6363)
static void C_fcall trf_6363(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6363(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6363(t0,t1,t2);}

C_noret_decl(trf_6357)
static void C_fcall trf_6357(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6357(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6357(t0,t1,t2);}

C_noret_decl(trf_8071)
static void C_fcall trf_8071(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8071(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8071(t0,t1,t2);}

C_noret_decl(trf_8188)
static void C_fcall trf_8188(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8188(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8188(t0,t1,t2);}

C_noret_decl(trf_8936)
static void C_fcall trf_8936(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8936(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8936(t0,t1,t2);}

C_noret_decl(trf_7134)
static void C_fcall trf_7134(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7134(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7134(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8244)
static void C_fcall trf_8244(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8244(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8244(t0,t1,t2);}

C_noret_decl(trf_7128)
static void C_fcall trf_7128(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7128(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7128(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_8412)
static void C_fcall trf_8412(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8412(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8412(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4178)
static void C_fcall trf_4178(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4178(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4178(t0,t1,t2);}

C_noret_decl(trf_8428)
static void C_fcall trf_8428(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8428(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8428(t0,t1,t2);}

C_noret_decl(trf_4808)
static void C_fcall trf_4808(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4808(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4808(t0,t1,t2,t3);}

C_noret_decl(trf_9460)
static void C_fcall trf_9460(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9460(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9460(t0,t1,t2);}

C_noret_decl(trf_9751)
static void C_fcall trf_9751(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9751(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9751(t0,t1,t2,t3);}

C_noret_decl(trf_9355)
static void C_fcall trf_9355(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9355(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9355(t0,t1,t2);}

C_noret_decl(trf_9764)
static void C_fcall trf_9764(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9764(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9764(t0,t1);}

C_noret_decl(trf_4858)
static void C_fcall trf_4858(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4858(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4858(t0,t1,t2,t3);}

C_noret_decl(trf_9390)
static void C_fcall trf_9390(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9390(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9390(t0,t1,t2);}

C_noret_decl(trf_8786)
static void C_fcall trf_8786(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8786(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8786(t0,t1,t2);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

/* map-loop566 in k9065 in k9059 in k9056 in k9048 in a9030 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_9425(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9425,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cadr(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8794 in for-each-loop850 in k8752 in a8749 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_8796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8786(t3,((C_word*)t0)[4],t2);}

/* k4148 in k4140 in k4130 in k4112 in k4098 in a4089 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in ... */
static void C_ccall f_4150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4150,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,((C_word*)t0)[4],t2));}

/* a4151 in k4140 in k4130 in k4112 in k4098 in a4089 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in ... */
static void C_ccall f_4152(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4152,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4168,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1208: rename2245 */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[52]);}

/* k9382 in map-loop621 in k9083 in k9068 in k9065 in k9059 in k9056 in k9048 in a9030 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9384,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9355(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9355(t6,((C_word*)t0)[5],t5);}}

/* k9417 in map-loop593 in k9068 in k9065 in k9059 in k9056 in k9048 in a9030 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9419,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9390(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9390(t6,((C_word*)t0)[5],t5);}}

/* map-loop651 in k9095 in k9083 in k9068 in k9065 in k9059 in k9056 in k9048 in a9030 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_9306(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9306,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=t9;
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9319,a[2]=((C_word*)t0)[2],a[3]=t10,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t12=t11;
f_9319(t12,C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t10));}
else{
t12=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t10);
t13=t11;
f_9319(t13,t12);}}
else{
t6=((C_word*)((C_word*)t0)[4])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* a6788 in k6933 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in ... */
static void C_ccall f_6789(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6789,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6793,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:734: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[172],t2,lf[175]);}

/* k6785 in k6933 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in ... */
static void C_ccall f_6787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:729: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[172],((C_word*)t0)[3],t1);}

/* k5030 in a5027 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in ... */
static void C_ccall f_5032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5032,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5039,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1079: r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[75]);}

/* k5037 in k5030 in a5027 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in ... */
static void C_ccall f_5039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5039,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5047,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1080: r */
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[47]);}

/* map-loop456 in k9677 in k9808 in k9644 in k9637 in k9625 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_9702(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9702,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list(&a,3,lf[212],t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=t9;
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9715,a[2]=((C_word*)t0)[2],a[3]=t10,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t12=t11;
f_9715(t12,C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t10));}
else{
t12=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t10);
t13=t11;
f_9715(t13,t12);}}
else{
t6=((C_word*)((C_word*)t0)[4])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* a5027 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in ... */
static void C_ccall f_5028(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5028,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5032,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1078: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[96],t2,lf[97]);}

/* k5024 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in ... */
static void C_ccall f_5026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1074: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[96],C_SCHEME_END_OF_LIST,t1);}

/* k9713 in map-loop456 in k9677 in k9808 in k9644 in k9637 in k9625 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_9715(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[6])[1];
f_9702(t5,((C_word*)t0)[7],t3,t4);}

/* a5010 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in ... */
static void C_ccall f_5011(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5011,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5015,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1089: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[93],t2,lf[95]);}

/* k6990 in k6950 in k6947 in a6944 in k7014 in k7018 in k7022 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in ... */
static void C_ccall f_6992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6992,2,t0,t1);}
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=t2;
t4=C_i_cddr(((C_word*)t0)[3]);
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_car(t4));
t7=t6;
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6982,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t7,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:713: r */
t9=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,lf[152]);}

/* k7555 in k7534 in k7528 in expand in k7490 in k7487 in k7484 in k7476 in a7473 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in ... */
static void C_ccall f_7557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:525: ##sys#notice */
t2=*((C_word*)lf[193]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[194],t1);}

/* k7551 in k7548 in k7534 in k7528 in expand in k7490 in k7487 in k7484 in k7476 in a7473 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in ... */
static void C_ccall f_7553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[192]);}

/* k5013 in a5010 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in ... */
static void C_ccall f_5015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5015,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,3,lf[94],t2,C_SCHEME_TRUE));}

/* k7548 in k7534 in k7528 in expand in k7490 in k7487 in k7484 in k7476 in a7473 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in ... */
static void C_ccall f_7550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7553,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:528: expand */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7505(t3,t2,((C_word*)t0)[4],C_SCHEME_TRUE);}

/* k9317 in map-loop651 in k9095 in k9083 in k9068 in k9065 in k9059 in k9056 in k9048 in a9030 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 in ... */
static void C_fcall f_9319(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[6])[1];
f_9306(t5,((C_word*)t0)[7],t3,t4);}

/* a5320 in k5489 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in ... */
static void C_ccall f_5321(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5321,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5325,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:990: r */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[107]);}

/* k5323 in a5320 in k5489 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in ... */
static void C_ccall f_5325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5325,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5328,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:991: r */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[106]);}

/* k5326 in k5323 in a5320 in k5489 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in ... */
static void C_ccall f_5328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5328,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5331,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:992: r */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[102]);}

/* k6980 in k6990 in k6950 in k6947 in a6944 in k7014 in k7018 in k7022 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in ... */
static void C_ccall f_6982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6982,2,t0,t1);}
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,4,lf[157],((C_word*)t0)[3],((C_word*)t0)[4],t2);
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,3,lf[30],((C_word*)t0)[6],t3));}

/* k5219 in loop in k5133 in k5130 in k5127 in k5124 in a5121 in k5309 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in ... */
static void C_ccall f_5221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5221,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5224,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5241,a[2]=((C_word*)t0)[8],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1040: gensym */
t4=*((C_word*)lf[32]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5247,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=((C_word*)t0)[2];
t4=C_u_i_car(t3);
/* chicken-syntax.scm:1042: c */
t5=((C_word*)t0)[10];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,((C_word*)t0)[11],t4);}}

/* map-loop1018 in k8396 in k8384 in k8365 in k8362 in k8283 in a8280 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in ... */
static void C_fcall f_8559(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8559,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cadr(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5222 in k5219 in loop in k5133 in k5130 in k5127 in k5124 in a5121 in k5309 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in ... */
static void C_ccall f_5224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5224,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
t5=C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* chicken-syntax.scm:1041: loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_5142(t6,((C_word*)t0)[6],t3,t4,((C_word*)t0)[7],t5,C_SCHEME_FALSE);}

/* k5309 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in ... */
static void C_ccall f_5311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5311,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[102],t1);
t3=C_a_i_list(&a,1,t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5120,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5122,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1020: ##sys#er-transformer */
t7=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* a9006 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9007(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9007,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9011,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:311: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[231],t2,lf[232]);}

/* k5317 in k5489 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in ... */
static void C_ccall f_5319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:985: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[109],((C_word*)t0)[3],t1);}

/* k9003 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:307: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[231],C_SCHEME_END_OF_LIST,t1);}

/* k7537 in k7534 in k7528 in expand in k7490 in k7487 in k7484 in k7476 in a7473 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in ... */
static void C_ccall f_7539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7539,2,t0,t1);}
t2=C_u_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[26],t2));}

/* k7534 in k7528 in expand in k7490 in k7487 in k7484 in k7476 in a7473 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in ... */
static void C_ccall f_7536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7536,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7539,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:522: expand */
t3=((C_word*)((C_word*)t0)[4])[1];
f_7505(t3,t2,((C_word*)t0)[5],C_SCHEME_TRUE);}
else{
if(C_truep(((C_word*)t0)[6])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7550,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7557,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:527: ##sys#strip-syntax */
t4=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7576,a[2]=((C_word*)t0)[7],a[3]=((C_word)li71),tmp=(C_word)a,a+=4,tmp);
t7=C_u_i_car(((C_word*)t0)[2]);
t8=C_i_check_list_2(t7,lf[28]);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7587,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7589,a[2]=t6,a[3]=t5,a[4]=t11,a[5]=t3,a[6]=((C_word)li72),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_7589(t13,t9,t7);}}}

/* k7528 in expand in k7490 in k7487 in k7484 in k7476 in a7473 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in ... */
static void C_ccall f_7530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7536,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_i_car(((C_word*)t0)[2]);
/* chicken-syntax.scm:521: c */
t4=((C_word*)t0)[9];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[10],t3);}

/* k9009 in a9006 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9011,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
t5=C_u_i_cdr(t4);
t6=C_a_i_cons(&a,2,lf[26],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_list(&a,3,lf[157],t2,t6));}

/* map-loop2290 in k4098 in a4089 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in ... */
static void C_fcall f_4213(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4213,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8529 in k8481 in fold in k8408 in k8396 in k8384 in k8365 in k8362 in k8283 in a8280 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in ... */
static void C_ccall f_8531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8531,2,t0,t1);}
t2=C_a_i_list(&a,3,lf[99],((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,3,lf[142],((C_word*)t0)[4],t2));}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_chicken_2dsyntax_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_chicken_2dsyntax_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("chicken_2dsyntax_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3926)){
C_save(t1);
C_rereclaim2(3926*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,292);
lf[0]=C_h_intern(&lf[0],28,"\003sysdefine-values-definition");
lf[1]=C_h_intern(&lf[1],29,"\003syschicken-macro-environment");
lf[2]=C_h_intern(&lf[2],17,"register-feature!");
lf[3]=C_h_intern(&lf[3],6,"srfi-8");
lf[4]=C_h_intern(&lf[4],7,"srfi-11");
lf[5]=C_h_intern(&lf[5],7,"srfi-15");
lf[6]=C_h_intern(&lf[6],7,"srfi-16");
lf[7]=C_h_intern(&lf[7],7,"srfi-26");
lf[8]=C_h_intern(&lf[8],7,"srfi-31");
lf[9]=C_h_intern(&lf[9],16,"\003sysmacro-subset");
lf[10]=C_h_intern(&lf[10],29,"\003sysdefault-macro-environment");
lf[11]=C_h_intern(&lf[11],28,"\003sysextend-macro-environment");
lf[12]=C_h_intern(&lf[12],11,"define-type");
lf[13]=C_h_intern(&lf[13],10,"\000compiling");
lf[14]=C_h_intern(&lf[14],12,"\003sysfeatures");
lf[15]=C_h_intern(&lf[15],26,"\010compilertype-abbreviation");
lf[16]=C_h_intern(&lf[16],16,"\003sysput/restore!");
lf[17]=C_h_intern(&lf[17],24,"\004coreelaborationtimeonly");
lf[18]=C_h_intern(&lf[18],32,"\010compilercheck-and-validate-type");
lf[19]=C_h_intern(&lf[19],16,"\003sysstrip-syntax");
lf[20]=C_h_intern(&lf[20],5,"quote");
lf[21]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[22]=C_h_intern(&lf[22],16,"\003syscheck-syntax");
lf[23]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[24]=C_h_intern(&lf[24],18,"\003syser-transformer");
lf[25]=C_h_intern(&lf[25],17,"compiler-typecase");
lf[26]=C_h_intern(&lf[26],10,"\004corebegin");
lf[27]=C_h_intern(&lf[27],4,"else");
lf[28]=C_h_intern(&lf[28],3,"map");
lf[29]=C_h_intern(&lf[29],13,"\004coretypecase");
lf[30]=C_h_intern(&lf[30],8,"\004corelet");
lf[31]=C_h_intern(&lf[31],15,"get-line-number");
lf[32]=C_h_intern(&lf[32],6,"gensym");
lf[33]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001\376\377\001\000\000\000\001");
lf[34]=C_h_intern(&lf[34],21,"define-specialization");
lf[35]=C_h_intern(&lf[35],6,"inline");
lf[36]=C_h_intern(&lf[36],4,"hide");
lf[37]=C_h_intern(&lf[37],12,"\004coredeclare");
lf[38]=C_h_intern(&lf[38],8,"\004corethe");
lf[39]=C_h_intern(&lf[39],8,"\003sysput!");
lf[40]=C_h_intern(&lf[40],30,"\010compilerlocal-specializations");
lf[41]=C_h_intern(&lf[41],10,"\003sysappend");
lf[42]=C_h_intern(&lf[42],22,"\010compilervariable-mark");
lf[43]=C_h_intern(&lf[43],7,"reverse");
lf[44]=C_h_intern(&lf[44],1,"\052");
lf[45]=C_h_intern(&lf[45],12,"syntax-error");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\027invalid argument syntax");
lf[47]=C_h_intern(&lf[47],6,"define");
lf[48]=C_h_intern(&lf[48],13,"\003sysglobalize");
lf[49]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000"
"\000\376\377\001\000\000\000\001");
lf[50]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[51]=C_h_intern(&lf[51],6,"assume");
lf[52]=C_h_intern(&lf[52],3,"the");
lf[53]=C_h_intern(&lf[53],9,"\003sysmap-n");
lf[54]=C_h_intern(&lf[54],3,"let");
lf[55]=C_h_intern(&lf[55],25,"\003syssyntax-rules-mismatch");
lf[56]=C_h_intern(&lf[56],5,"\003sys+");
lf[57]=C_h_intern(&lf[57],5,"\003sys=");
lf[58]=C_h_intern(&lf[58],6,"\003sys>=");
lf[59]=C_h_intern(&lf[59],10,"\003syslength");
lf[60]=C_h_intern(&lf[60],9,"\003syslist\077");
lf[61]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[62]=C_h_intern(&lf[62],1,":");
lf[63]=C_h_intern(&lf[63],22,"\010compilervalidate-type");
lf[64]=C_h_intern(&lf[64],4,"type");
lf[65]=C_h_intern(&lf[65],9,"predicate");
lf[66]=C_h_intern(&lf[66],4,"pure");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid type syntax");
lf[68]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[69]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[70]=C_h_intern(&lf[70],7,"functor");
lf[71]=C_h_intern(&lf[71],20,"\003sysregister-functor");
lf[72]=C_h_intern(&lf[72],6,"import");
lf[73]=C_h_intern(&lf[73],6,"scheme");
lf[74]=C_h_intern(&lf[74],7,"chicken");
lf[75]=C_h_intern(&lf[75],16,"begin-for-syntax");
lf[76]=C_h_intern(&lf[76],11,"\004coremodule");
lf[77]=C_h_intern(&lf[77],20,"\003sysvalidate-exports");
lf[78]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\003\000\000\002\376"
"\001\000\000\001_\376\001\000\000\001_");
lf[79]=C_h_intern(&lf[79],16,"define-interface");
lf[80]=C_h_intern(&lf[80],14,"\004coreinterface");
lf[81]=C_h_intern(&lf[81],10,"\000interface");
lf[82]=C_h_intern(&lf[82],17,"syntax-error-hook");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\017invalid exports");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000-`\052\047 is not allowed as a name for an interface");
lf[85]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[86]=C_h_intern(&lf[86],19,"let-compiler-syntax");
lf[87]=C_h_intern(&lf[87],24,"\004corelet-compiler-syntax");
lf[88]=C_h_intern(&lf[88],22,"define-compiler-syntax");
lf[89]=C_h_intern(&lf[89],27,"\004coredefine-compiler-syntax");
lf[90]=C_h_intern(&lf[90],14,"use-for-syntax");
lf[91]=C_h_intern(&lf[91],28,"require-extension-for-syntax");
lf[92]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[93]=C_h_intern(&lf[93],3,"use");
lf[94]=C_h_intern(&lf[94],22,"\004corerequire-extension");
lf[95]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[96]=C_h_intern(&lf[96],17,"define-for-syntax");
lf[97]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[98]=C_h_intern(&lf[98],3,"rec");
lf[99]=C_h_intern(&lf[99],11,"\004corelambda");
lf[100]=C_h_intern(&lf[100],12,"\004coreletrec\052");
lf[101]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[102]=C_h_intern(&lf[102],5,"apply");
lf[103]=C_h_intern(&lf[103],4,"cute");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000+tail patterns after <...> are not supported");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\047you need to supply at least a procedure");
lf[106]=C_h_intern(&lf[106],5,"<...>");
lf[107]=C_h_intern(&lf[107],2,"<>");
lf[108]=C_h_intern(&lf[108],19,"\003sysprimitive-alias");
lf[109]=C_h_intern(&lf[109],3,"cut");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000+tail patterns after <...> are not supported");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\047you need to supply at least a procedure");
lf[112]=C_h_intern(&lf[112],18,"getter-with-setter");
lf[113]=C_h_intern(&lf[113],18,"define-record-type");
lf[114]=C_h_intern(&lf[114],10,"\004corequote");
lf[115]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[116]=C_h_intern(&lf[116],18,"\003sysmake-structure");
lf[117]=C_h_intern(&lf[117],14,"\003sysstructure\077");
lf[118]=C_h_intern(&lf[118],19,"\003syscheck-structure");
lf[119]=C_h_intern(&lf[119],10,"\004corecheck");
lf[120]=C_h_intern(&lf[120],13,"\003sysblock-ref");
lf[121]=C_h_intern(&lf[121],10,"\003syssetter");
lf[122]=C_h_intern(&lf[122],14,"\003sysblock-set!");
lf[123]=C_h_intern(&lf[123],6,"setter");
lf[124]=C_h_intern(&lf[124],1,"y");
lf[125]=C_h_intern(&lf[125],1,"x");
lf[126]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\000\000\000\002\376\001\000\000\010variable\376\377\001\000\000\000\001\376\003\000\000\002\376\001\000\000\010variable\376\001\000"
"\000\001_");
lf[127]=C_h_intern(&lf[127],4,"memv");
lf[128]=C_h_intern(&lf[128],14,"condition-case");
lf[129]=C_h_intern(&lf[129],9,"condition");
lf[130]=C_h_intern(&lf[130],8,"\003sysslot");
lf[131]=C_h_intern(&lf[131],10,"\003syssignal");
lf[132]=C_h_intern(&lf[132],4,"cond");
lf[133]=C_h_intern(&lf[133],17,"handle-exceptions");
lf[134]=C_h_intern(&lf[134],3,"and");
lf[135]=C_h_intern(&lf[135],4,"kvar");
lf[136]=C_h_intern(&lf[136],5,"exvar");
lf[137]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[138]=C_h_intern(&lf[138],30,"call-with-current-continuation");
lf[139]=C_h_intern(&lf[139],22,"with-exception-handler");
lf[140]=C_h_intern(&lf[140],9,"\003sysapply");
lf[141]=C_h_intern(&lf[141],10,"\003sysvalues");
lf[142]=C_h_intern(&lf[142],20,"\003syscall-with-values");
lf[143]=C_h_intern(&lf[143],4,"args");
lf[144]=C_h_intern(&lf[144],1,"k");
lf[145]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[146]=C_h_intern(&lf[146],21,"define-record-printer");
lf[147]=C_h_intern(&lf[147],27,"\003sysregister-record-printer");
lf[148]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[149]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[150]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[151]=C_h_intern(&lf[151],2,">=");
lf[152]=C_h_intern(&lf[152],3,"car");
lf[153]=C_h_intern(&lf[153],3,"cdr");
lf[154]=C_h_intern(&lf[154],3,"eq\077");
lf[155]=C_h_intern(&lf[155],6,"length");
lf[156]=C_h_intern(&lf[156],11,"case-lambda");
lf[157]=C_h_intern(&lf[157],7,"\004coreif");
lf[158]=C_h_intern(&lf[158],9,"split-at!");
lf[159]=C_h_intern(&lf[159],4,"take");
lf[160]=C_h_intern(&lf[160],11,"lambda-list");
lf[161]=C_h_intern(&lf[161],25,"\003sysdecompose-lambda-list");
lf[162]=C_h_intern(&lf[162],10,"fold-right");
lf[163]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\004corecheck\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\003syserror\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreimmutable\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\012\004corequote\376\003\000\000\002\376B\000\0000no matching clause in call to \047case-lambda\047 form\376\377\016\376"
"\377\016\376\377\016\376\377\016");
lf[164]=C_h_intern(&lf[164],6,"append");
lf[165]=C_h_intern(&lf[165],4,"lvar");
lf[166]=C_h_intern(&lf[166],4,"rvar");
lf[167]=C_h_intern(&lf[167],3,"min");
lf[168]=C_h_intern(&lf[168],7,"require");
lf[169]=C_h_intern(&lf[169],6,"srfi-1");
lf[170]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[171]=C_h_intern(&lf[171],5,"null\077");
lf[172]=C_h_intern(&lf[172],14,"let-optionals\052");
lf[173]=C_h_intern(&lf[173],4,"tmp2");
lf[174]=C_h_intern(&lf[174],3,"tmp");
lf[175]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[176]=C_h_intern(&lf[176],8,"optional");
lf[177]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[178]=C_h_intern(&lf[178],13,"let-optionals");
lf[179]=C_h_intern(&lf[179],14,"string->symbol");
lf[180]=C_h_intern(&lf[180],13,"string-append");
lf[181]=C_h_intern(&lf[181],14,"symbol->string");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\001%");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\004def-");
lf[184]=C_h_intern(&lf[184],4,"let\052");
lf[185]=C_h_intern(&lf[185],6,"_%rest");
lf[186]=C_h_intern(&lf[186],4,"body");
lf[187]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[188]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[189]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[190]=C_h_intern(&lf[190],6,"select");
lf[191]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[192]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\004corebegin\376\377\016");
lf[193]=C_h_intern(&lf[193],10,"\003sysnotice");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\0005non-`else\047 clause following `else\047 clause in `select\047");
lf[195]=C_h_intern(&lf[195],8,"\003syseqv\077");
lf[196]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid syntax");
lf[198]=C_h_intern(&lf[198],2,"or");
lf[199]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[200]=C_h_intern(&lf[200],8,"and-let\052");
lf[201]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[202]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\001\000\000\001_");
lf[203]=C_h_intern(&lf[203],13,"define-inline");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\052invalid substitution form - must be lambda");
lf[205]=C_h_intern(&lf[205],6,"lambda");
lf[206]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[207]=C_h_intern(&lf[207],18,"\004coredefine-inline");
lf[208]=C_h_intern(&lf[208],8,"list-ref");
lf[209]=C_h_intern(&lf[209],9,"nth-value");
lf[210]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[211]=C_h_intern(&lf[211],13,"letrec-values");
lf[212]=C_h_intern(&lf[212],9,"\004coreset!");
lf[213]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[214]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[215]=C_h_intern(&lf[215],11,"let\052-values");
lf[216]=C_h_intern(&lf[216],10,"let-values");
lf[217]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[218]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[219]=C_h_intern(&lf[219],13,"define-values");
lf[220]=C_h_intern(&lf[220],8,"for-each");
lf[221]=C_h_intern(&lf[221],11,"set!-values");
lf[222]=C_h_intern(&lf[222],19,"\003sysregister-export");
lf[223]=C_h_intern(&lf[223],18,"\003syscurrent-module");
lf[224]=C_h_intern(&lf[224],7,"\003sysget");
lf[225]=C_h_intern(&lf[225],16,"\004coremacro-alias");
lf[226]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\001\000\000\010variable\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[227]=C_h_intern(&lf[227],14,"\004coreundefined");
lf[228]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\001\000\000\010variable\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[229]=C_h_intern(&lf[229],6,"unless");
lf[230]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[231]=C_h_intern(&lf[231],4,"when");
lf[232]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[233]=C_h_intern(&lf[233],12,"parameterize");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\011parameter");
lf[235]=C_h_intern(&lf[235],16,"\003sysdynamic-wind");
lf[236]=C_h_intern(&lf[236],1,"t");
lf[237]=C_h_intern(&lf[237],4,"mode");
lf[238]=C_h_intern(&lf[238],4,"swap");
lf[239]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[240]=C_h_intern(&lf[240],9,"eval-when");
lf[241]=C_h_intern(&lf[241],19,"\004corecompiletimetoo");
lf[242]=C_h_intern(&lf[242],20,"\004corecompiletimeonly");
lf[243]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[244]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[245]=C_h_intern(&lf[245],9,"\003syserror");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid situation specifier");
lf[247]=C_h_intern(&lf[247],4,"load");
lf[248]=C_h_intern(&lf[248],7,"compile");
lf[249]=C_h_intern(&lf[249],4,"eval");
lf[250]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[251]=C_h_intern(&lf[251],9,"fluid-let");
lf[252]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\001\000\000\001_");
lf[253]=C_h_intern(&lf[253],6,"ensure");
lf[254]=C_h_intern(&lf[254],15,"\003syssignal-hook");
lf[255]=C_h_intern(&lf[255],11,"\000type-error");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\033argument has incorrect type");
lf[257]=C_h_intern(&lf[257],14,"\004coreimmutable");
lf[258]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\003");
lf[259]=C_h_intern(&lf[259],6,"assert");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\020assertion failed");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\002) ");
lf[263]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[264]=C_h_intern(&lf[264],7,"include");
lf[265]=C_h_intern(&lf[265],12,"\004coreinclude");
lf[266]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006string\376\377\016");
lf[267]=C_h_intern(&lf[267],7,"declare");
lf[268]=C_h_intern(&lf[268],4,"time");
lf[269]=C_h_intern(&lf[269],15,"\003sysstart-timer");
lf[270]=C_h_intern(&lf[270],14,"\003sysstop-timer");
lf[271]=C_h_intern(&lf[271],17,"\003sysdisplay-times");
lf[272]=C_h_intern(&lf[272],7,"receive");
lf[273]=C_h_intern(&lf[273],8,"\003syslist");
lf[274]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\013lambda-list\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[275]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[276]=C_h_intern(&lf[276],13,"define-record");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid slot specification");
lf[278]=C_h_intern(&lf[278],3,"val");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\005-set!");
lf[282]=C_h_intern(&lf[282],17,"\003sysstring-append");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\001\077");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\005make-");
lf[285]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\001\000\000\001_");
lf[286]=C_h_intern(&lf[286],15,"define-constant");
lf[287]=C_h_intern(&lf[287],20,"\004coredefine-constant");
lf[288]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[289]=C_h_intern(&lf[289],21,"\003sysmacro-environment");
lf[290]=C_h_intern(&lf[290],11,"\003sysprovide");
lf[291]=C_h_intern(&lf[291],14,"chicken-syntax");
C_register_lf2(lf,292,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3388,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:38: ##sys#provide */
t3=*((C_word*)lf[290]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[291]);}

/* k9027 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:271: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[233],C_SCHEME_END_OF_LIST,t1);}

/* a10232 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_10233(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10233,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10237,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:193: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[253],t2,lf[258]);}

/* a9030 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9031,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9050,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:279: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[233],t2,lf[239]);}

/* k10229 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_10231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:188: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[253],C_SCHEME_END_OF_LIST,t1);}

/* k8764 in k8757 in for-each-loop850 in k8752 in a8749 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_8766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:355: ##sys#register-export */
t2=*((C_word*)lf[222]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k5045 in k5037 in k5030 in a5027 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in ... */
static void C_ccall f_5047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5047,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,2,((C_word*)t0)[4],t3));}

/* loop in k8384 in k8365 in k8362 in k8283 in a8280 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in ... */
static void C_fcall f_8594(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8594,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
/* chicken-syntax.scm:389: reverse */
t4=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=C_i_car(t2);
if(C_truep(C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8632,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:393: map* */
t6=((C_word*)((C_word*)t0)[3])[1];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[4],t4);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8625,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:392: lookup */
t6=((C_word*)t0)[4];
f_8387(3,t6,t5,t4);}}}

/* k8773 in k8752 in a8749 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_8775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8775,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8782,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:357: r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[221]);}

/* k10235 in a10232 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_10237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10237,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=C_i_caddr(((C_word*)t0)[2]);
t5=t4;
t6=((C_word*)t0)[2];
t7=C_u_i_cdr(t6);
t8=C_u_i_cdr(t7);
t9=C_u_i_cdr(t8);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10249,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t9,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:197: r */
t11=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,lf[174]);}

/* loop in k5332 in k5329 in k5326 in k5323 in a5320 in k5489 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in ... */
static void C_fcall f_5341(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5341,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(C_i_nullp(t2))){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5351,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:997: reverse */
t7=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}
else{
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5416,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t7=C_i_car(t2);
/* chicken-syntax.scm:1006: c */
t8=((C_word*)t0)[6];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,((C_word*)t0)[8],t7);}}

/* k9056 in k9048 in a9030 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9058,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9061,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:283: r */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[237]);}

/* k9048 in a9030 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9050,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9058,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:282: r */
t8=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,lf[238]);}

/* k7585 in k7534 in k7528 in expand in k7490 in k7487 in k7484 in k7476 in a7473 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in ... */
static void C_ccall f_7587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7587,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=C_u_i_cdr(((C_word*)t0)[3]);
t5=C_a_i_cons(&a,2,lf[26],t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7572,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:535: expand */
t8=((C_word*)((C_word*)t0)[5])[1];
f_7505(t8,t7,((C_word*)t0)[6],C_SCHEME_FALSE);}

/* map-loop1341 in k7534 in k7528 in expand in k7490 in k7487 in k7484 in k7476 in a7473 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in ... */
static void C_fcall f_7589(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7589,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=f_7576(C_a_i(&a,9),((C_word*)t0)[2],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate2(((C_word *)((C_word*)t0)[5])+1,t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[5])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8746 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_8748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:348: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[219],C_SCHEME_END_OF_LIST,t1);}

/* k5245 in k5219 in loop in k5133 in k5130 in k5127 in k5124 in a5121 in k5309 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in ... */
static void C_ccall f_5247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5247,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
if(C_truep(C_i_nullp(t3))){
/* chicken-syntax.scm:1044: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5142(t4,((C_word*)t0)[4],C_SCHEME_END_OF_LIST,((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],C_SCHEME_TRUE);}
else{
/* chicken-syntax.scm:1045: syntax-error */
t4=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[4],lf[103],lf[104],((C_word*)t0)[8]);}}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5264,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5287,a[2]=((C_word*)t0)[9],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1049: gensym */
t4=*((C_word*)lf[32]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5239 in k5219 in loop in k5133 in k5130 in k5127 in k5124 in a5121 in k5309 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in ... */
static void C_ccall f_5241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1040: r */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* k5329 in k5326 in k5323 in a5320 in k5489 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in ... */
static void C_ccall f_5331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5331,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5334,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=C_i_cdr(((C_word*)t0)[2]);
if(C_truep(C_i_nullp(t4))){
/* chicken-syntax.scm:994: syntax-error */
t5=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,lf[109],lf[111],((C_word*)t0)[2]);}
else{
t5=t3;
f_5334(2,t5,C_SCHEME_UNDEFINED);}}

/* k5332 in k5329 in k5326 in k5323 in a5320 in k5489 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in ... */
static void C_ccall f_5334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5334,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5341,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word)li32),tmp=(C_word)a,a+=10,tmp));
t7=((C_word*)t5)[1];
f_5341(t7,((C_word*)t0)[8],t3,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* a8749 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_8750(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8750,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8754,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:352: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[219],t2,lf[226]);}

/* k8752 in a8749 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_8754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8754,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_i_check_list_2(t2,lf[220]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8775,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8786,a[2]=t6,a[3]=((C_word)li106),tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_8786(t8,t4,t2);}

/* k8757 in for-each-loop850 in k8752 in a8749 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_8759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8759,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8766,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:355: ##sys#current-module */
t4=*((C_word*)lf[223]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k10270 in k10247 in k10235 in a10232 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_10272(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10272,NULL,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[254],t1);
t3=C_a_i_list(&a,4,lf[157],((C_word*)t0)[2],((C_word*)t0)[3],t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,3,lf[30],((C_word*)t0)[5],t3));}

/* k4999 in k4992 in a4989 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in ... */
static void C_ccall f_5001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5001,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,t1,t2));}

/* k10247 in k10235 in a10232 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_10249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10249,2,t0,t1);}
t2=t1;
t3=C_a_i_list(&a,2,t2,((C_word*)t0)[2]);
t4=C_a_i_list(&a,1,t3);
t5=t4;
t6=C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t7=C_a_i_list(&a,2,lf[119],t6);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10272,a[2]=t8,a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[5]))){
t10=t9;
f_10272(t10,C_a_i_cons(&a,2,lf[255],((C_word*)t0)[5]));}
else{
t10=C_a_i_list(&a,2,lf[114],lf[256]);
t11=C_a_i_list(&a,2,lf[257],t10);
t12=C_a_i_list(&a,2,lf[114],((C_word*)t0)[3]);
t13=C_a_i_list(&a,3,t11,t2,t12);
t14=t9;
f_10272(t14,C_a_i_cons(&a,2,lf[255],t13));}}

/* k5007 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in ... */
static void C_ccall f_5009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1085: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[93],C_SCHEME_END_OF_LIST,t1);}

/* k4271 in k4265 in k4262 in k4256 in a4089 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in ... */
static void C_ccall f_4273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4273,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[2]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4282,a[2]=t4,a[3]=((C_word)li12),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4282(t6,((C_word*)t0)[3],t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_4100(2,t2,C_SCHEME_FALSE);}}

/* k5391 in k5352 in k5349 in loop in k5332 in k5329 in k5326 in k5323 in a5320 in k5489 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in ... */
static void C_ccall f_5393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1000: r */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* k6399 in k6396 in k6393 in k6390 in k6353 in a6350 in k6761 in k6765 in k6769 in k6773 in k6777 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in ... */
static void C_ccall f_6401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6401,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6404,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:785: r */
t4=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[165]);}

/* k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6353 in a6350 in k6761 in k6765 in k6769 in k6773 in k6777 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in ... */
static void C_ccall f_6407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6407,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6410,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm:787: r */
t4=((C_word*)t0)[7];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[154]);}

/* k6402 in k6399 in k6396 in k6393 in k6390 in k6353 in a6350 in k6761 in k6765 in k6769 in k6773 in k6777 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in ... */
static void C_ccall f_6404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6404,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6407,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm:786: r */
t4=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[151]);}

/* k5381 in k5365 in k5358 in k5352 in k5349 in loop in k5332 in k5329 in k5326 in k5323 in a5320 in k5489 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in ... */
static void C_ccall f_5383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5383,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,3,lf[99],((C_word*)t0)[5],t3));}

/* k5059 in a5056 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in ... */
static void C_ccall f_5061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5061,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
if(C_truep(C_i_pairp(t2))){
t3=C_u_i_car(t2);
t4=C_u_i_cdr(t2);
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
t7=C_u_i_cdr(t6);
t8=C_a_i_cons(&a,2,t4,t7);
t9=C_a_i_cons(&a,2,lf[99],t8);
t10=C_a_i_list(&a,2,t3,t9);
t11=C_a_i_list(&a,1,t10);
t12=C_u_i_car(t2);
t13=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_a_i_list(&a,3,lf[100],t11,t12));}
else{
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
t5=C_u_i_cdr(t4);
t6=C_a_i_cons(&a,2,t2,t5);
t7=C_a_i_list(&a,1,t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_list(&a,3,lf[100],t7,t2));}}

/* k5285 in k5245 in k5219 in loop in k5133 in k5130 in k5127 in k5124 in a5121 in k5309 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in ... */
static void C_ccall f_5287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1049: r */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* k5053 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in ... */
static void C_ccall f_5055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1058: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[98],C_SCHEME_END_OF_LIST,t1);}

/* a5056 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in ... */
static void C_ccall f_5057(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5057,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5061,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1062: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[98],t2,lf[101]);}

/* k4265 in k4262 in k4256 in a4089 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in ... */
static void C_ccall f_4267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4267,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4273,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1208: ##sys#>= */
t4=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,C_fix(0));}

/* k4262 in k4256 in a4089 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in ... */
static void C_ccall f_4264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4264,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4267,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
/* chicken-syntax.scm:1208: ##sys#length */
t4=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[3];
f_4100(2,t2,C_SCHEME_FALSE);}}

/* k6424 in k6417 in k6414 in k6411 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6353 in a6350 in k6761 in k6765 in k6769 in k6773 in k6777 in k3466 in k3463 in k3460 in k3457 in ... */
static void C_ccall f_6426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6426,2,t0,t1);}
t2=t1;
t3=C_a_i_list(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t4=C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=C_a_i_list(&a,1,t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6438,a[2]=t6,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6440,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[12],a[11]=((C_word)li53),tmp=(C_word)a,a+=12,tmp);
t9=((C_word*)t0)[13];
t10=C_u_i_cdr(t9);
/* chicken-syntax.scm:795: fold-right */
t11=*((C_word*)lf[162]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,lf[163],t10);}

/* k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6353 in a6350 in k6761 in k6765 in k6769 in k6773 in k6777 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in ... */
static void C_ccall f_6410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6410,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6413,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm:788: r */
t4=((C_word*)t0)[7];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[152]);}

/* k6411 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6353 in a6350 in k6761 in k6765 in k6769 in k6773 in k6777 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in ... */
static void C_ccall f_6413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6413,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6416,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm:789: r */
t4=((C_word*)t0)[7];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[153]);}

/* k6414 in k6411 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6353 in a6350 in k6761 in k6765 in k6769 in k6773 in k6777 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in ... */
static void C_ccall f_6416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6416,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6419,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* chicken-syntax.scm:790: r */
t4=((C_word*)t0)[8];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[155]);}

/* k6417 in k6414 in k6411 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6353 in a6350 in k6761 in k6765 in k6769 in k6773 in k6777 in k3466 in k3463 in k3460 in k3457 in k3454 in ... */
static void C_ccall f_6419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6419,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6426,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* chicken-syntax.scm:792: append */
t4=*((C_word*)lf[164]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[6],((C_word*)t0)[2]);}

/* g1347 in k7534 in k7528 in expand in k7490 in k7487 in k7484 in k7476 in a7473 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in ... */
static C_word C_fcall f_7576(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_stack_overflow_check;
return(C_a_i_list(&a,3,lf[195],((C_word*)t0)[2],t1));}

/* k4287 in loop2242 in k4271 in k4265 in k4262 in k4256 in a4089 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in ... */
static void C_ccall f_4289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4289,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_eqp(((C_word*)t0)[3],C_SCHEME_END_OF_LIST));}
else{
t2=C_i_cdr(((C_word*)t0)[3]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4303,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1208: ##sys#+ */
t5=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[5],C_fix(-1));}}

/* loop2242 in k4271 in k4265 in k4262 in k4256 in a4089 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in ... */
static void C_fcall f_4282(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4282,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4289,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:1208: ##sys#= */
t5=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,C_fix(0));}

/* k7570 in k7585 in k7534 in k7528 in expand in k7490 in k7487 in k7484 in k7476 in a7473 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in ... */
static void C_ccall f_7572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7572,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,4,lf[157],((C_word*)t0)[3],((C_word*)t0)[4],t1));}

/* k4256 in a4089 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in ... */
static void C_ccall f_4258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4258,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4264,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
/* chicken-syntax.scm:1208: ##sys#list? */
t4=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[3];
f_4100(2,t2,C_SCHEME_FALSE);}}

/* k6462 in k6452 in a6449 in a6439 in k6424 in k6417 in k6414 in k6411 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6353 in a6350 in k6761 in k6765 in k6769 in k6773 in k6777 in ... */
static void C_fcall f_6464(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6464,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6468,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6470,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word)li48),tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6480,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],a[9]=((C_word)li51),tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm:807: ##sys#call-with-values */
C_call_with_values(4,0,t3,t4,t5);}

/* map-loop278 in k9637 in k9625 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_10089(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10089,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cadr(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6466 in k6462 in k6452 in a6449 in a6439 in k6424 in k6417 in k6414 in k6411 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6353 in a6350 in k6761 in k6765 in k6769 in k6773 in ... */
static void C_ccall f_6468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6468,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,4,lf[157],((C_word*)t0)[3],t1,((C_word*)t0)[4]));}

/* k6452 in a6449 in a6439 in k6424 in k6417 in k6414 in k6411 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6353 in a6350 in k6761 in k6765 in k6769 in k6773 in k6777 in k3466 in ... */
static void C_ccall f_6454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6454,2,t0,t1);}
t2=C_fixnum_difference(((C_word*)t0)[2],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6464,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[8])){
t4=C_eqp(t2,C_fix(0));
t5=t3;
f_6464(t5,(C_truep(t4)?C_SCHEME_TRUE:C_a_i_list(&a,3,((C_word*)t0)[14],((C_word*)t0)[15],t2)));}
else{
t4=t3;
f_6464(t4,C_a_i_list(&a,3,((C_word*)t0)[16],((C_word*)t0)[15],t2));}}

/* a6449 in a6439 in k6424 in k6417 in k6414 in k6411 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6353 in a6350 in k6761 in k6765 in k6769 in k6773 in k6777 in k3466 in k3463 in ... */
static void C_ccall f_6450(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6450,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_6454,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=((C_word*)t0)[4],a[8]=t4,a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[8],a[13]=((C_word*)t0)[9],a[14]=((C_word*)t0)[10],a[15]=((C_word*)t0)[11],a[16]=((C_word*)t0)[12],tmp=(C_word)a,a+=17,tmp);
t6=C_i_car(((C_word*)t0)[5]);
/* chicken-syntax.scm:800: ##sys#check-syntax */
t7=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,lf[156],t6,lf[160]);}

/* k3704 in map-loop2479 in k3614 in k3611 in k3605 in a3602 in k3523 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in ... */
static void C_ccall f_3706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3706,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3677(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3677(t6,((C_word*)t0)[5],t5);}}

/* a6479 in k6462 in k6452 in a6449 in a6439 in k6424 in k6417 in k6414 in k6411 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6353 in a6350 in k6761 in k6765 in k6769 in k6773 in ... */
static void C_ccall f_6480(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6480,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6484,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6554,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t6,a[7]=((C_word*)t0)[7],a[8]=((C_word)li50),tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_6554(t8,t4,t3,((C_word*)t0)[8]);}

/* k6482 in a6479 in k6462 in k6452 in a6449 in a6439 in k6424 in k6417 in k6414 in k6411 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6353 in a6350 in k6761 in k6765 in k6769 in ... */
static void C_ccall f_6484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6484,2,t0,t1);}
t2=t1;
if(C_truep(C_i_nullp(((C_word*)t0)[2]))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t0)[2];
t8=C_i_check_list_2(t7,lf[28]);
t9=C_i_check_list_2(((C_word*)t0)[4],lf[28]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6503,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6505,a[2]=t6,a[3]=t12,a[4]=t4,a[5]=((C_word)li49),tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_6505(t14,t10,t7,((C_word*)t0)[4]);}}

/* k9215 in map-loop713 in k9119 in k9105 in k9095 in k9083 in k9068 in k9065 in k9059 in k9056 in k9048 in a9030 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in ... */
static void C_fcall f_9217(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[6])[1];
f_9204(t5,((C_word*)t0)[7],t3,t4);}

/* a6469 in k6462 in k6452 in a6449 in a6439 in k6424 in k6417 in k6414 in k6411 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6353 in a6350 in k6761 in k6765 in k6769 in k6773 in ... */
static void C_ccall f_6470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6470,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6478,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:808: take */
t3=*((C_word*)lf[159]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k6476 in a6469 in k6462 in k6452 in a6449 in a6439 in k6424 in k6417 in k6414 in k6411 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6353 in a6350 in k6761 in k6765 in k6769 in ... */
static void C_ccall f_6478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:808: split-at! */
t2=*((C_word*)lf[158]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* k6851 in loop in k6812 in k6809 in k6806 in k6803 in k6791 in a6788 in k6933 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in ... */
static void C_ccall f_6853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[76],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6853,2,t0,t1);}
t2=C_u_i_car(((C_word*)t0)[2]);
t3=C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
t4=C_i_cadr(((C_word*)t0)[2]);
t5=C_a_i_list(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t6=C_a_i_list(&a,4,lf[157],t3,t4,t5);
t7=C_a_i_list(&a,2,t2,t6);
t8=C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
t9=C_a_i_list(&a,2,lf[20],C_SCHEME_END_OF_LIST);
t10=C_a_i_list(&a,2,((C_word*)t0)[6],((C_word*)t0)[4]);
t11=C_a_i_list(&a,4,lf[157],t8,t9,t10);
t12=C_a_i_list(&a,2,t1,t11);
t13=C_a_i_list(&a,2,t7,t12);
t14=t13;
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6864,a[2]=((C_word*)t0)[7],a[3]=t14,tmp=(C_word)a,a+=4,tmp);
t16=((C_word*)t0)[8];
t17=C_u_i_cdr(t16);
/* chicken-syntax.scm:756: loop */
t18=((C_word*)((C_word*)t0)[9])[1];
f_6827(t18,t15,t1,t17);}

/* k8310 in append*877 in k8283 in a8280 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_8312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8312,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* map*878 in k8283 in a8280 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_8319(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8319,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep(C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8342,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=C_i_car(t3);
/* chicken-syntax.scm:374: proc */
t6=t2;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
/* chicken-syntax.scm:373: proc */
t4=t2;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}}}

/* k5365 in k5358 in k5352 in k5349 in loop in k5332 in k5329 in k5326 in k5323 in a5320 in k5489 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in ... */
static void C_ccall f_5367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5367,2,t0,t1);}
t2=t1;
t3=C_i_car(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5383,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=C_u_i_cdr(((C_word*)t0)[2]);
t7=C_a_i_list(&a,1,((C_word*)t0)[5]);
/* chicken-syntax.scm:1000: ##sys#append */
t8=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,t6,t7);}

/* k5358 in k5352 in k5349 in loop in k5332 in k5329 in k5326 in k5323 in a5320 in k5489 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in ... */
static void C_ccall f_5360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5360,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5367,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:1000: ##sys#append */
t4=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[5],t2);}

/* k5262 in k5245 in k5219 in loop in k5133 in k5130 in k5127 in k5124 in a5121 in k5309 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in ... */
static void C_ccall f_5264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5264,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[2];
t5=C_u_i_car(t4);
t6=C_a_i_list2(&a,2,t1,t5);
t7=C_a_i_cons(&a,2,t6,((C_word*)t0)[3]);
t8=C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* chicken-syntax.scm:1050: loop */
t9=((C_word*)((C_word*)t0)[5])[1];
f_5142(t9,((C_word*)t0)[6],t3,((C_word*)t0)[7],t7,t8,C_SCHEME_FALSE);}

/* k3745 in k3741 in k3732 in a3723 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in ... */
static void C_ccall f_3747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3747,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3750,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm:1224: ##sys#globalize */
t4=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,C_SCHEME_END_OF_LIST);}

/* k3741 in k3732 in a3723 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in ... */
static void C_ccall f_3743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3743,2,t0,t1);}
t2=t1;
t3=C_u_i_cdr(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3747,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:1223: gensym */
t5=*((C_word*)lf[32]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[6]);}

/* k5352 in k5349 in loop in k5332 in k5329 in k5326 in k5323 in a5320 in k5489 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in ... */
static void C_ccall f_5354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5354,2,t0,t1);}
t2=t1;
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5360,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5393,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1000: gensym */
t5=*((C_word*)lf[32]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t3=C_i_car(t2);
t4=C_a_i_list(&a,2,lf[26],t3);
t5=C_u_i_cdr(t2);
t6=C_a_i_cons(&a,2,t4,t5);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_list(&a,3,lf[99],((C_word*)t0)[5],t6));}}

/* k5349 in loop in k5332 in k5329 in k5326 in k5323 in a5320 in k5489 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in ... */
static void C_ccall f_5351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5351,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5354,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:998: reverse */
t4=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[6]);}

/* map-loop713 in k9119 in k9105 in k9095 in k9083 in k9068 in k9065 in k9059 in k9056 in k9048 in a9030 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in ... */
static void C_fcall f_9204(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9204,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=f_9167(C_a_i(&a,42),((C_word*)t0)[2],t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=t9;
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9217,a[2]=((C_word*)t0)[3],a[3]=t10,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t12=t11;
f_9217(t12,C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(1),t10));}
else{
t12=C_mutate2(((C_word *)((C_word*)t0)[5])+1,t10);
t13=t11;
f_9217(t13,t12);}}
else{
t6=((C_word*)((C_word*)t0)[5])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k3748 in k3745 in k3741 in k3732 in a3723 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in ... */
static void C_ccall f_3750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3750,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3753,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t4=C_i_cdddr(((C_word*)t0)[2]);
if(C_truep(C_i_pairp(t4))){
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
t7=C_u_i_cdr(t6);
t8=C_u_i_car(t7);
/* chicken-syntax.scm:1225: ##sys#strip-syntax */
t9=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t3,t8);}
else{
t5=t3;
f_3753(2,t5,C_SCHEME_FALSE);}}

/* k3751 in k3748 in k3745 in k3741 in k3732 in a3723 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in ... */
static void C_ccall f_3753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3753,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3756,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm:1226: r */
t4=((C_word*)t0)[9];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[47]);}

/* k3754 in k3751 in k3748 in k3745 in k3741 in k3732 in a3723 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in ... */
static void C_ccall f_3756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3756,2,t0,t1);}
t2=t1;
t3=(C_truep(((C_word*)t0)[2])?C_i_cadddr(((C_word*)t0)[3]):C_i_caddr(((C_word*)t0)[3]));
t4=t3;
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3764,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[2],a[8]=t6,a[9]=((C_word*)t0)[7],a[10]=((C_word)li7),tmp=(C_word)a,a+=11,tmp));
t8=((C_word*)t6)[1];
f_3764(t8,((C_word*)t0)[8],((C_word*)t0)[9],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* map-loop682 in k9105 in k9095 in k9083 in k9068 in k9065 in k9059 in k9056 in k9048 in a9030 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 in ... */
static void C_fcall f_9257(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9257,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=t9;
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9270,a[2]=((C_word*)t0)[2],a[3]=t10,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t12=t11;
f_9270(t12,C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t10));}
else{
t12=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t10);
t13=t11;
f_9270(t13,t12);}}
else{
t6=((C_word*)((C_word*)t0)[4])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k6823 in k6812 in k6809 in k6806 in k6803 in k6791 in a6788 in k6933 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in ... */
static void C_ccall f_6825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6825,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,3,lf[30],((C_word*)t0)[3],t1));}

/* loop in k6812 in k6809 in k6806 in k6803 in k6791 in a6788 in k6933 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in ... */
static void C_fcall f_6827(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6827,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t3))){
t4=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_cons(&a,2,lf[30],t4));}
else{
t4=C_i_car(t3);
t5=t4;
if(C_truep(C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6853,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=t3,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm:749: r */
t7=((C_word*)t0)[7];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[173]);}
else{
t6=C_a_i_list(&a,2,t5,t2);
t7=C_a_i_list(&a,1,t6);
t8=C_a_i_cons(&a,2,t7,((C_word*)t0)[2]);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_a_i_cons(&a,2,lf[30],t8));}}}

/* k3720 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in ... */
static void C_ccall f_3722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1212: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[34],C_SCHEME_END_OF_LIST,t1);}

/* a3723 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in ... */
static void C_ccall f_3724(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3724,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_memq(lf[13],*((C_word*)lf[14]+1)))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3734,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1218: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[34],t2,lf[49]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[50]);}}

/* k6761 in k6765 in k6769 in k6773 in k6777 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in ... */
static void C_ccall f_6763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6763,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[155],t1);
t3=C_a_i_list(&a,5,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6349,a[2]=((C_word*)t0)[6],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6351,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:769: ##sys#er-transformer */
t7=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k6765 in k6769 in k6773 in k6777 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in ... */
static void C_ccall f_6767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6767,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[154],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6763,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:768: ##sys#primitive-alias */
t5=*((C_word*)lf[108]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[155]);}

/* k6809 in k6806 in k6803 in k6791 in a6788 in k6933 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in ... */
static void C_ccall f_6811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6811,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6814,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm:741: r */
t4=((C_word*)t0)[7];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[174]);}

/* k6812 in k6809 in k6806 in k6803 in k6791 in a6788 in k6933 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in ... */
static void C_ccall f_6814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6814,2,t0,t1);}
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6825,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6827,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t7,a[7]=((C_word*)t0)[8],a[8]=((C_word)li57),tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t7)[1];
f_6827(t9,t5,t1,((C_word*)t0)[9]);}

/* k3732 in a3723 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in ... */
static void C_ccall f_3734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3734,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=C_i_car(t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3743,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:1221: ##sys#globalize */
t7=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t5,C_SCHEME_END_OF_LIST);}

/* k6791 in a6788 in k6933 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in ... */
static void C_ccall f_6793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6793,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=C_i_caddr(((C_word*)t0)[2]);
t5=t4;
t6=((C_word*)t0)[2];
t7=C_u_i_cdr(t6);
t8=C_u_i_cdr(t7);
t9=C_u_i_cdr(t8);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6805,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t9,a[5]=((C_word*)t0)[4],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:738: r */
t11=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,lf[171]);}

/* k6803 in k6791 in a6788 in k6933 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in ... */
static void C_ccall f_6805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6805,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6808,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:739: r */
t4=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[152]);}

/* k6806 in k6803 in k6791 in a6788 in k6933 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in ... */
static void C_ccall f_6808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6808,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6811,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm:740: r */
t4=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[153]);}

/* k3828 in map-loop2424 in k3781 in k3956 in k3775 in k3772 in loop in k3754 in k3751 in k3748 in k3745 in k3741 in k3732 in a3723 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in ... */
static void C_fcall f_3830(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[6])[1];
f_3817(t5,((C_word*)t0)[7],t3,t4);}

/* k6773 in k6777 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in ... */
static void C_ccall f_6775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6775,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[152],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6771,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:766: ##sys#primitive-alias */
t5=*((C_word*)lf[108]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[153]);}

/* k6777 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in ... */
static void C_ccall f_6779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6779,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[151],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6775,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:765: ##sys#primitive-alias */
t5=*((C_word*)lf[108]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[152]);}

/* k6769 in k6773 in k6777 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in ... */
static void C_ccall f_6771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6771,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[153],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6767,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:767: ##sys#primitive-alias */
t5=*((C_word*)lf[108]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[154]);}

/* k8277 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_8279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:359: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[216],C_SCHEME_END_OF_LIST,t1);}

/* k7172 in k7196 in k7204 in k7212 in recur in make-if-tree in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in ... */
static void C_ccall f_7174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7174,2,t0,t1);}
t2=C_a_i_list(&a,3,lf[30],((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,4,lf[157],((C_word*)t0)[4],((C_word*)t0)[5],t2));}

/* map-loop2424 in k3781 in k3956 in k3775 in k3772 in loop in k3754 in k3751 in k3748 in k3745 in k3741 in k3732 in a3723 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in ... */
static void C_fcall f_3817(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3817,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list(&a,4,lf[38],t7,C_SCHEME_TRUE,t6);
t9=C_a_i_list2(&a,2,t6,t8);
t10=C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=t10;
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3830,a[2]=((C_word*)t0)[2],a[3]=t11,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t13=t12;
f_3830(t13,C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t11));}
else{
t13=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t11);
t14=t12;
f_3830(t14,t13);}}
else{
t6=((C_word*)((C_word*)t0)[4])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k3813 in k3781 in k3956 in k3775 in k3772 in loop in k3754 in k3751 in k3748 in k3745 in k3741 in k3732 in a3723 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in ... */
static void C_ccall f_3815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3815,2,t0,t1);}
t2=C_a_i_list(&a,3,lf[30],t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[4],t2);
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,3,lf[26],((C_word*)t0)[6],t3));}

/* k8267 in fold in k8237 in k8229 in a8226 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in ... */
static void C_ccall f_8269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8269,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[4],t1));}

/* append*877 in k8283 in a8280 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_8291(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8291,4,t0,t1,t2,t3);}
if(C_truep(C_i_pairp(t2))){
t4=C_i_car(t2);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8312,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=t2;
t8=C_u_i_cdr(t7);
/* chicken-syntax.scm:370: append* */
t9=((C_word*)((C_word*)t0)[2])[1];
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,t8,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,t2,t3));}}

/* k7196 in k7204 in k7212 in recur in make-if-tree in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in ... */
static void C_ccall f_7198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7198,2,t0,t1);}
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,2,((C_word*)t0)[2],t2);
t4=C_a_i_list(&a,2,((C_word*)t0)[3],t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7174,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t7=((C_word*)t0)[7];
t8=C_u_i_cdr(t7);
t9=((C_word*)t0)[8];
t10=C_u_i_cdr(t9);
t11=C_a_i_cons(&a,2,((C_word*)t0)[9],((C_word*)t0)[10]);
/* chicken-syntax.scm:654: recur */
t12=((C_word*)((C_word*)t0)[11])[1];
f_7134(t12,t6,t8,t10,t11);}

/* a8280 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_8281(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8281,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8285,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:363: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[216],t2,lf[218]);}

/* k8283 in a8280 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_8285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8285,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8291,a[2]=t8,a[3]=((C_word)li93),tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8319,a[2]=t10,a[3]=((C_word)li94),tmp=(C_word)a,a+=4,tmp);
t13=C_set_block_item(t8,0,t11);
t14=C_set_block_item(t10,0,t12);
t15=C_SCHEME_END_OF_LIST;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_FALSE;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_i_check_list_2(t3,lf[28]);
t20=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8364,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t10,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_set_block_item(t22,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8711,a[2]=t18,a[3]=t22,a[4]=t16,a[5]=((C_word)li104),tmp=(C_word)a,a+=6,tmp));
t24=((C_word*)t22)[1];
f_8711(t24,t20,t3);}

/* a6439 in k6424 in k6417 in k6414 in k6411 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6353 in a6350 in k6761 in k6765 in k6769 in k6773 in k6777 in k3466 in k3463 in k3460 in ... */
static void C_ccall f_6440(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6440,4,t0,t1,t2,t3);}
t4=C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6450,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word)li52),tmp=(C_word)a,a+=14,tmp);
/* chicken-syntax.scm:797: ##sys#decompose-lambda-list */
t6=*((C_word*)lf[161]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t4,t5);}

/* k6605 in build in a6479 in k6462 in k6452 in a6449 in a6439 in k6424 in k6417 in k6414 in k6411 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6353 in a6350 in k6761 in k6765 in ... */
static void C_ccall f_6607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6607,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[2]);
t3=C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
t4=C_a_i_list(&a,2,t2,t3);
t5=C_a_i_list(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t6=C_a_i_list(&a,2,t1,t5);
t7=C_a_i_list(&a,2,t4,t6);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6618,a[2]=((C_word*)t0)[6],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=((C_word*)t0)[2];
t11=C_u_i_cdr(t10);
if(C_truep(C_i_pairp(t11))){
t12=((C_word*)t0)[2];
t13=C_u_i_cdr(t12);
/* chicken-syntax.scm:819: build */
t14=((C_word*)((C_word*)t0)[7])[1];
f_6554(t14,t9,t13,t1);}
else{
/* chicken-syntax.scm:820: build */
t12=((C_word*)((C_word*)t0)[7])[1];
f_6554(t12,t9,C_SCHEME_END_OF_LIST,t1);}}

/* k6436 in k6424 in k6417 in k6414 in k6411 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6353 in a6350 in k6761 in k6765 in k6769 in k6773 in k6777 in k3466 in k3463 in k3460 in ... */
static void C_ccall f_6438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6438,2,t0,t1);}
t2=C_a_i_list(&a,3,lf[30],((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,3,lf[99],((C_word*)t0)[4],t2));}

/* k6941 in k7014 in k7018 in k7022 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in ... */
static void C_ccall f_6943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:701: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[176],((C_word*)t0)[3],t1);}

/* a6944 in k7014 in k7018 in k7022 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in ... */
static void C_ccall f_6945(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6945,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6949,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:708: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[176],t2,lf[177]);}

/* k6933 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in ... */
static void C_ccall f_6935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6935,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[171],t1);
t3=C_a_i_list(&a,1,t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6787,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6789,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:732: ##sys#er-transformer */
t7=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k3390 in k3386 */
static void C_ccall f_3392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3392,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3395,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10928,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10930,a[2]=((C_word)li150),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:49: ##sys#er-transformer */
t6=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k3393 in k3390 in k3386 */
static void C_ccall f_3395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3398,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10568,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10570,a[2]=((C_word)li149),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:56: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_3398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3401,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10475,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10477,a[2]=((C_word)li145),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:123: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k6947 in a6944 in k7014 in k7018 in k7022 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in ... */
static void C_ccall f_6949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6949,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6952,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:709: r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[174]);}

/* a10929 in k3390 in k3386 */
static void C_ccall f_10930(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10930,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10934,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:51: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[286],t2,lf[288]);}

/* k10932 in a10929 in k3390 in k3386 */
static void C_ccall f_10934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10934,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[287],t2));}

/* k10918 in map-loop25 in k10589 in k10586 in k10583 in k10580 in k10572 in a10569 in k3393 in k3390 in k3386 */
static void C_ccall f_10920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10920,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_10891(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_10891(t6,((C_word*)t0)[5],t5);}}

/* k10926 in k3390 in k3386 */
static void C_ccall f_10928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:46: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[286],C_SCHEME_END_OF_LIST,t1);}

/* k7014 in k7018 in k7022 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in ... */
static void C_ccall f_7016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7016,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[153],t1);
t3=C_a_i_list(&a,3,((C_word*)t0)[2],((C_word*)t0)[3],t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6943,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6945,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:706: ##sys#er-transformer */
t7=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k3386 */
static void C_ccall f_3388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3388,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3392,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:44: ##sys#macro-environment */
t3=*((C_word*)lf[289]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k6616 in k6605 in build in a6479 in k6462 in k6452 in a6449 in a6439 in k6424 in k6417 in k6414 in k6411 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6353 in a6350 in k6761 in ... */
static void C_ccall f_6618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6618,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,3,lf[30],((C_word*)t0)[3],t1));}

/* k6950 in k6947 in a6944 in k7014 in k7018 in k7022 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in ... */
static void C_ccall f_6952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6952,2,t0,t1);}
t2=t1;
t3=C_i_cadr(((C_word*)t0)[2]);
t4=C_a_i_list(&a,2,t2,t3);
t5=C_a_i_list(&a,1,t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6992,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t6,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:711: r */
t8=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,lf[171]);}

/* map-loop1601 in k6390 in k6353 in a6350 in k6761 in k6765 in k6769 in k6773 in k6777 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in ... */
static void C_fcall f_6706(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6706,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6735,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6694,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:779: ##sys#decompose-lambda-list */
t7=*((C_word*)lf[161]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,t5,t6);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6702 in k6390 in k6353 in a6350 in k6761 in k6765 in k6769 in k6773 in k6777 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in ... */
static void C_ccall f_6704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[167]+1),t1);}

/* k6733 in map-loop1601 in k6390 in k6353 in a6350 in k6761 in k6765 in k6769 in k6773 in k6777 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in ... */
static void C_ccall f_6735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6735,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6706(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6706(t6,((C_word*)t0)[5],t5);}}

/* k7022 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in ... */
static void C_ccall f_7024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7024,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[171],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7020,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:704: ##sys#primitive-alias */
t5=*((C_word*)lf[108]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[152]);}

/* k7018 in k7022 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in ... */
static void C_ccall f_7020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7020,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[152],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7016,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:705: ##sys#primitive-alias */
t5=*((C_word*)lf[108]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[153]);}

/* k7055 in k7273 in k7261 in k7258 in k7255 in k7252 in k7224 in k7218 in k7215 in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in ... */
static void C_ccall f_7057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7057,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7061,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:629: reverse */
t4=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in ... */
static void C_ccall f_7034(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7034,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7038,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:619: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[178],t2,lf[189]);}

/* k7030 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in ... */
static void C_ccall f_7032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:613: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[178],((C_word*)t0)[3],t1);}

/* k6653 in build in a6479 in k6462 in k6452 in a6449 in a6439 in k6424 in k6417 in k6414 in k6411 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6353 in a6350 in k6761 in k6765 in ... */
static void C_ccall f_6655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:815: r */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in ... */
static void C_ccall f_7038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7038,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=C_i_caddr(((C_word*)t0)[2]);
t5=t4;
t6=((C_word*)t0)[2];
t7=C_u_i_cdr(t6);
t8=C_u_i_cdr(t7);
t9=C_u_i_cdr(t8);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7128,a[2]=((C_word*)t0)[3],a[3]=((C_word)li61),tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7217,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t9,a[6]=((C_word*)t0)[4],a[7]=t10,tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:658: ##sys#check-syntax */
t12=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t12+1)))(5,t12,t11,lf[178],t5,lf[188]);}

/* k8815 in a8812 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_8817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8817,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=C_i_caddr(((C_word*)t0)[2]);
t5=t4;
if(C_truep(C_i_nullp(t3))){
t6=C_a_i_list(&a,3,lf[99],C_SCHEME_END_OF_LIST,t5);
t7=C_a_i_list(&a,1,lf[227]);
t8=C_a_i_list(&a,3,lf[99],C_SCHEME_END_OF_LIST,t7);
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_a_i_list(&a,3,lf[142],t6,t8));}
else{
t6=C_i_cdr(t3);
if(C_truep(C_i_nullp(t6))){
t7=C_u_i_car(t3);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_list(&a,3,lf[212],t7,t5));}
else{
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=*((C_word*)lf[32]+1);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8858,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8936,a[2]=t10,a[3]=t14,a[4]=t8,a[5]=t11,a[6]=((C_word)li109),tmp=(C_word)a,a+=7,tmp));
t16=((C_word*)t14)[1];
f_8936(t16,t12,t3);}}}

/* a8812 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_8813(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8813,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8817,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:328: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[221],t2,lf[228]);}

/* k8809 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_8811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:324: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[221],C_SCHEME_END_OF_LIST,t1);}

/* k4086 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in ... */
static void C_ccall f_4088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1206: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[51],C_SCHEME_END_OF_LIST,t1);}

/* a4089 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in ... */
static void C_ccall f_4090(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4090,5,t0,t1,t2,t3,t4);}
t5=C_i_cdr(t2);
t6=t5;
t7=t6;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4100,a[2]=t6,a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t7))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4258,a[2]=t7,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4314,a[2]=t7,a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=C_i_car(t7);
/* chicken-syntax.scm:1208: ##sys#list? */
t12=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}
else{
t9=t8;
f_4100(2,t9,C_SCHEME_FALSE);}}

/* k3772 in loop in k3754 in k3751 in k3748 in k3745 in k3741 in k3732 in a3723 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in ... */
static void C_ccall f_3774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3774,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3777,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm:1231: reverse */
t4=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[10]);}

/* k3775 in k3772 in loop in k3754 in k3751 in k3748 in k3745 in k3741 in k3732 in a3723 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in ... */
static void C_ccall f_3777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3777,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3958,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3960,a[2]=t5,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_3960(t7,t3,((C_word*)t0)[10],C_fix(1));}

/* k4911 in k4901 in a4892 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in ... */
static void C_ccall f_4913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4913,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[2],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,t1,t3));}

/* k4901 in a4892 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in ... */
static void C_fcall f_4903(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4903,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4913,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1104: rename2058 */
t5=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[89]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4927,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t3=C_i_cdr(((C_word*)t0)[2]);
if(C_truep(C_i_pairp(t3))){
t4=C_i_cdr(t3);
t5=t2;
f_4927(t5,C_eqp(t4,C_SCHEME_END_OF_LIST));}
else{
t4=t2;
f_4927(t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_4927(t3,C_SCHEME_FALSE);}}}

/* k4925 in k4901 in a4892 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in ... */
static void C_fcall f_4927(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4927,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=C_i_cdr(((C_word*)t0)[2]);
t5=C_i_car(t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4940,a[2]=t6,a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1104: rename2058 */
t8=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,lf[89]);}
else{
/* chicken-syntax.scm:1104: ##sys#syntax-rules-mismatch */
t2=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[5]);}}

/* k9644 in k9637 in k9625 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9646,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9810,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_i_check_list_2(((C_word*)t0)[4],lf[28]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9822,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9894,a[2]=t7,a[3]=t11,a[4]=t5,a[5]=((C_word)li131),tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_9894(t13,t9,((C_word*)t0)[5],((C_word*)t0)[4]);}

/* k8481 in fold in k8408 in k8396 in k8384 in k8365 in k8362 in k8283 in a8280 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in ... */
static void C_fcall f_8483(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8483,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_caar(((C_word*)t0)[2]);
t3=C_i_car(((C_word*)t0)[3]);
t4=C_a_i_list(&a,2,t2,t3);
t5=C_a_i_list(&a,1,t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8494,a[2]=((C_word*)t0)[4],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=C_i_cdr(((C_word*)t0)[5]);
t9=((C_word*)t0)[3];
t10=C_u_i_cdr(t9);
t11=((C_word*)t0)[2];
t12=C_u_i_cdr(t11);
/* chicken-syntax.scm:405: fold */
t13=((C_word*)((C_word*)t0)[6])[1];
f_8412(t13,t7,t8,t10,t12);}
else{
t2=C_i_car(((C_word*)t0)[3]);
t3=C_a_i_list(&a,3,lf[99],C_SCHEME_END_OF_LIST,t2);
t4=t3;
t5=((C_word*)t0)[2];
t6=C_u_i_car(t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8531,a[2]=t6,a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t8=C_i_cdr(((C_word*)t0)[5]);
t9=((C_word*)t0)[3];
t10=C_u_i_cdr(t9);
t11=((C_word*)t0)[2];
t12=C_u_i_cdr(t11);
/* chicken-syntax.scm:411: fold */
t13=((C_word*)((C_word*)t0)[6])[1];
f_8412(t13,t7,t8,t10,t12);}}

/* k9637 in k9625 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9639,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9646,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t0)[5];
t9=C_SCHEME_END_OF_LIST;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9945,a[2]=t8,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[6],a[6]=t7,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10089,a[2]=t12,a[3]=t15,a[4]=t10,a[5]=((C_word)li135),tmp=(C_word)a,a+=6,tmp));
t17=((C_word*)t15)[1];
f_10089(t17,t13,((C_word*)t0)[6]);}

/* k9634 in g233 in k9625 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:218: r */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* k4938 in k4925 in k4901 in a4892 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in ... */
static void C_ccall f_4940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4940,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,t1,t3));}

/* k8492 in k8481 in fold in k8408 in k8396 in k8384 in k8365 in k8362 in k8283 in a8280 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in ... */
static void C_ccall f_8494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8494,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,3,lf[30],((C_word*)t0)[3],t1));}

/* k7490 in k7487 in k7484 in k7476 in a7473 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in ... */
static void C_ccall f_7492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7492,2,t0,t1);}
t2=t1;
t3=C_a_i_list(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t4=C_a_i_list(&a,1,t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7503,a[2]=((C_word*)t0)[4],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7505,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li73),tmp=(C_word)a,a+=8,tmp));
t10=((C_word*)t8)[1];
f_7505(t10,t6,((C_word*)t0)[7],C_SCHEME_FALSE);}

/* k9690 in k9677 in k9808 in k9644 in k9637 in k9625 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9692,2,t0,t1);}
t2=C_a_i_list(&a,1,lf[227]);
t3=C_a_i_list(&a,1,t2);
/* chicken-syntax.scm:214: ##sys#append */
t4=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k9681 in k9677 in k9808 in k9644 in k9637 in k9625 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:214: ##sys#append */
t2=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k4012 in loop in k3754 in k3751 in k3748 in k3745 in k3741 in k3732 in a3723 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in ... */
static void C_fcall f_4014(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4014,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_i_car(((C_word*)t0)[3]);
t5=C_a_i_cons(&a,2,t4,((C_word*)t0)[4]);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4031,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t3,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
t8=C_i_cadr(((C_word*)t0)[3]);
/* chicken-syntax.scm:1271: ##compiler#check-and-validate-type */
t9=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,lf[34]);}
else{
/* chicken-syntax.scm:1275: syntax-error */
t2=*((C_word*)lf[45]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[7],lf[34],lf[46],((C_word*)t0)[3],((C_word*)t0)[8]);}}

/* k7470 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in ... */
static void C_ccall f_7472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:500: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[190],C_SCHEME_END_OF_LIST,t1);}

/* k9059 in k9056 in k9048 in a9030 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9061,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_i_check_list_2(((C_word*)t0)[2],lf[28]);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9067,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9460,a[2]=t6,a[3]=t10,a[4]=t4,a[5]=((C_word)li122),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_9460(t12,t8,((C_word*)t0)[2]);}

/* k9065 in k9059 in k9056 in k9048 in a9030 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9067,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9070,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9425,a[2]=t6,a[3]=t9,a[4]=t4,a[5]=((C_word)li121),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_9425(t11,t7,((C_word*)t0)[7]);}

/* map-loop983 in fold in k8408 in k8396 in k8384 in k8365 in k8362 in k8283 in a8280 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in ... */
static void C_fcall f_8444(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8444,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8473,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:400: g989 */
t5=((C_word*)t0)[5];
f_8428(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8440 in fold in k8408 in k8396 in k8384 in k8365 in k8362 in k8283 in a8280 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in ... */
static void C_ccall f_8442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8442,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[30],t2));}

/* g1784 in k5907 in k5904 in k5901 in parse-clause in k5895 in k5892 in k5889 in k5886 in k5883 in k5880 in a5877 in k6143 in k6147 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in ... */
static C_word C_fcall f_5931(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_overflow_check;
t2=C_a_i_list(&a,2,lf[114],t1);
return(C_a_i_list(&a,3,((C_word*)t0)[2],t2,((C_word*)t0)[3]));}

/* k9668 in k9808 in k9644 in k9637 in k9625 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9670,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=C_a_i_cons(&a,2,lf[99],t2);
t4=C_a_i_list(&a,4,lf[235],((C_word*)t0)[2],((C_word*)t0)[3],t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_list(&a,3,lf[30],((C_word*)t0)[5],t4));}

/* k9677 in k9808 in k9644 in k9637 in k9625 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9679,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9683,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9692,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9702,a[2]=t7,a[3]=t10,a[4]=t5,a[5]=((C_word)li128),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_9702(t12,t8,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* g599 in k9068 in k9065 in k9059 in k9056 in k9048 in a9030 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_9071(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9071,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9079,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_symbolp(t2))){
/* chicken-syntax.scm:277: gensym */
t4=*((C_word*)lf[32]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
/* chicken-syntax.scm:278: gensym */
t4=*((C_word*)lf[32]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[234]);}}

/* k9068 in k9065 in k9059 in k9056 in k9048 in a9030 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9070,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9071,a[2]=((C_word*)t0)[2],a[3]=((C_word)li113),tmp=(C_word)a,a+=4,tmp);
t8=C_i_check_list_2(((C_word*)t0)[3],lf[28]);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9085,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9390,a[2]=t6,a[3]=t11,a[4]=t4,a[5]=t7,a[6]=((C_word)li120),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_9390(t13,t9,((C_word*)t0)[3]);}

/* map-loop1778 in k5907 in k5904 in k5901 in parse-clause in k5895 in k5892 in k5889 in k5886 in k5883 in k5880 in a5877 in k6143 in k6147 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in ... */
static void C_fcall f_5947(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(18);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5947,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=f_5931(C_a_i(&a,15),((C_word*)t0)[2],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate2(((C_word *)((C_word*)t0)[5])+1,t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[5])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9077 in g599 in k9068 in k9065 in k9059 in k9056 in k9048 in a9030 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:286: r */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* k5943 in k5907 in k5904 in k5901 in parse-clause in k5895 in k5892 in k5889 in k5886 in k5883 in k5880 in a5877 in k6143 in k6147 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in ... */
static void C_ccall f_5945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5945,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,2,t3,((C_word*)t0)[5]));}

/* k4029 in k4012 in loop in k3754 in k3751 in k3748 in k3745 in k3741 in k3732 in a3723 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in ... */
static void C_ccall f_4031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4031,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
/* chicken-syntax.scm:1267: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3764(t3,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],t2);}

/* g627 in k9083 in k9068 in k9065 in k9059 in k9056 in k9048 in a9030 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_9086(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9086,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9094,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:287: gensym */
t3=*((C_word*)lf[32]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9083 in k9068 in k9065 in k9059 in k9056 in k9048 in a9030 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9085,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9086,a[2]=((C_word*)t0)[2],a[3]=((C_word)li114),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9097,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9355,a[2]=t6,a[3]=t10,a[4]=t4,a[5]=t7,a[6]=((C_word)li119),tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_9355(t12,t8,((C_word*)t0)[8]);}

/* k9095 in k9083 in k9068 in k9065 in k9059 in k9056 in k9048 in a9030 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9097,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_i_check_list_2(((C_word*)t0)[2],lf[28]);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9107,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9306,a[2]=t6,a[3]=t10,a[4]=t4,a[5]=((C_word)li118),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_9306(t12,t8,((C_word*)t0)[2],((C_word*)t0)[8]);}

/* k9092 in g627 in k9083 in k9068 in k9065 in k9059 in k9056 in k9048 in a9030 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:287: r */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* k8471 in map-loop983 in fold in k8408 in k8396 in k8384 in k8365 in k8362 in k8283 in a8280 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in ... */
static void C_ccall f_8473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8473,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8444(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8444(t6,((C_word*)t0)[5],t5);}}

/* k5414 in loop in k5332 in k5329 in k5326 in k5323 in a5320 in k5489 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in ... */
static void C_ccall f_5416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5416,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5419,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5436,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1007: gensym */
t4=*((C_word*)lf[32]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5442,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
t4=C_u_i_car(t3);
/* chicken-syntax.scm:1009: c */
t5=((C_word*)t0)[9];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,((C_word*)t0)[10],t4);}}

/* k5417 in k5414 in loop in k5332 in k5329 in k5326 in k5323 in a5320 in k5489 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in ... */
static void C_ccall f_5419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5419,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
t5=C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* chicken-syntax.scm:1008: loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_5341(t6,((C_word*)t0)[6],t3,t4,t5,C_SCHEME_FALSE);}

/* k5904 in k5901 in parse-clause in k5895 in k5892 in k5889 in k5886 in k5883 in k5880 in a5877 in k6143 in k6147 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in ... */
static void C_fcall f_5906(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5906,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5909,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[7])){
t4=C_a_i_list(&a,2,((C_word*)t0)[7],((C_word*)t0)[8]);
t5=C_a_i_list(&a,1,t4);
t6=C_i_cddr(((C_word*)t0)[9]);
t7=C_a_i_cons(&a,2,t5,t6);
t8=t3;
f_5909(t8,C_a_i_cons(&a,2,lf[30],t7));}
else{
t4=((C_word*)t0)[9];
t5=C_u_i_cdr(t4);
t6=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t5);
t7=t3;
f_5909(t7,C_a_i_cons(&a,2,lf[30],t6));}}

/* k5907 in k5904 in k5901 in parse-clause in k5895 in k5892 in k5889 in k5886 in k5883 in k5880 in a5877 in k6143 in k6147 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in ... */
static void C_fcall f_5909(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5909,NULL,2,t0,t1);}
t2=t1;
if(C_truep(C_i_nullp(((C_word*)t0)[2]))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,2,((C_word*)t0)[4],t2));}
else{
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5931,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word)li39),tmp=(C_word)a,a+=5,tmp);
t8=C_i_check_list_2(((C_word*)t0)[2],lf[28]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5945,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5947,a[2]=t7,a[3]=t6,a[4]=t11,a[5]=t4,a[6]=((C_word)li40),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_5947(t13,t9,((C_word*)t0)[2]);}}

/* k5901 in parse-clause in k5895 in k5892 in k5889 in k5886 in k5883 in k5880 in a5877 in k6143 in k6147 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in ... */
static void C_fcall f_5903(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5903,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5906,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t2)){
t4=t3;
f_5906(t4,C_i_cadr(((C_word*)t0)[8]));}
else{
t4=((C_word*)t0)[8];
t5=t3;
f_5906(t5,C_u_i_car(t4));}}

/* k9622 in g205 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:217: r */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* k9625 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9627,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9628,a[2]=((C_word*)t0)[2],a[3]=((C_word)li127),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9639,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10124,a[2]=t6,a[3]=t10,a[4]=t4,a[5]=t7,a[6]=((C_word)li136),tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_10124(t12,t8,((C_word*)t0)[6]);}

/* g233 in k9625 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_9628(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9628,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9636,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:218: gensym */
t3=*((C_word*)lf[32]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9615,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9616,a[2]=((C_word*)t0)[2],a[3]=((C_word)li126),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9627,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10159,a[2]=t6,a[3]=t10,a[4]=t4,a[5]=t7,a[6]=((C_word)li137),tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_10159(t12,t8,((C_word*)t0)[5]);}

/* g205 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_9616(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9616,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9624,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:217: gensym */
t3=*((C_word*)lf[32]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8434 in g989 in fold in k8408 in k8396 in k8384 in k8365 in k8362 in k8283 in a8280 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in ... */
static void C_ccall f_8436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8436,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,2,((C_word*)t0)[3],t1));}

/* a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9600(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9600,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9604,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:213: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[251],t2,lf[252]);}

/* k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9604,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_i_check_list_2(t3,lf[28]);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9615,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10194,a[2]=t10,a[3]=t14,a[4]=t8,a[5]=((C_word)li138),tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_10194(t16,t12,t3);}

/* k4301 in k4287 in loop2242 in k4271 in k4265 in k4262 in k4256 in a4089 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in ... */
static void C_ccall f_4303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1208: loop2242 */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4282(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* a7888 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_7889(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7889,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7893,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:432: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[211],t2,lf[214]);}

/* k7885 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_7887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:428: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[211],C_SCHEME_END_OF_LIST,t1);}

/* k7881 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_7883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7883,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[208],t1);
t3=C_a_i_list(&a,1,t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7839,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7841,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:451: ##sys#er-transformer */
t7=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k8630 in loop in k8384 in k8365 in k8362 in k8283 in a8280 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in ... */
static void C_ccall f_8632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8632,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
/* chicken-syntax.scm:394: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_8594(t5,((C_word*)t0)[5],t4,t2);}

/* map-loop932 in k8365 in k8362 in k8283 in a8280 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 in ... */
static void C_fcall f_8638(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8638,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8667,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:385: g938 */
t5=((C_word*)t0)[5];
f_8368(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* a7473 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in ... */
static void C_ccall f_7474(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7474,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7478,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:504: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[190],t2,lf[199]);}

/* k7476 in a7473 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in ... */
static void C_ccall f_7478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7478,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7486,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t6,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:507: r */
t8=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,lf[174]);}

/* k5130 in k5127 in k5124 in a5121 in k5309 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in ... */
static void C_ccall f_5132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5132,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5135,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=C_i_cdr(((C_word*)t0)[2]);
if(C_truep(C_i_nullp(t4))){
/* chicken-syntax.scm:1026: syntax-error */
t5=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,lf[103],lf[105],((C_word*)t0)[2]);}
else{
t5=t3;
f_5135(2,t5,C_SCHEME_UNDEFINED);}}

/* k4312 in a4089 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in ... */
static void C_ccall f_4314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4314,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4317,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(((C_word*)t0)[2]);
/* chicken-syntax.scm:1208: ##sys#length */
t4=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[3];
f_4258(2,t2,C_SCHEME_FALSE);}}

/* k4315 in k4312 in a4089 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in ... */
static void C_ccall f_4317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4317,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4323,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1208: ##sys#>= */
t4=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,C_fix(0));}

/* k5133 in k5130 in k5127 in k5124 in a5121 in k5309 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in ... */
static void C_ccall f_5135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5135,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5142,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word)li30),tmp=(C_word)a,a+=10,tmp));
t7=((C_word*)t5)[1];
f_5142(t7,((C_word*)t0)[8],t3,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* k7891 in a7888 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_7893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7893,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7901,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_i_check_list_2(t3,lf[28]);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8186,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8188,a[2]=t11,a[3]=t15,a[4]=t9,a[5]=((C_word)li89),tmp=(C_word)a,a+=6,tmp));
t17=((C_word*)t15)[1];
f_8188(t17,t13,t3);}

/* k7484 in k7476 in a7473 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in ... */
static void C_ccall f_7486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7486,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7489,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:508: r */
t4=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[27]);}

/* k7487 in k7484 in k7476 in a7473 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in ... */
static void C_ccall f_7489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7489,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7492,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:509: r */
t4=((C_word*)t0)[7];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[198]);}

/* k5118 in k5309 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in ... */
static void C_ccall f_5120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1017: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[103],((C_word*)t0)[3],t1);}

/* k4321 in k4315 in k4312 in a4089 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in ... */
static void C_ccall f_4323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4323,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4332,a[2]=t4,a[3]=((C_word)li13),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4332(t6,((C_word*)t0)[3],t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_4258(2,t2,C_SCHEME_FALSE);}}

/* a5121 in k5309 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in ... */
static void C_ccall f_5122(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5122,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5126,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:1022: r */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[102]);}

/* k5127 in k5124 in a5121 in k5309 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in ... */
static void C_ccall f_5129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5129,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5132,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:1024: r */
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[106]);}

/* k5124 in a5121 in k5309 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in ... */
static void C_ccall f_5126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5126,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5129,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:1023: r */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[107]);}

/* k8665 in map-loop932 in k8365 in k8362 in k8283 in a8280 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in ... */
static void C_ccall f_8667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8667,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8638(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8638(t6,((C_word*)t0)[5],t5);}}

/* k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in ... */
static void C_ccall f_7468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7468,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[152],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7464,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:616: ##sys#primitive-alias */
t5=*((C_word*)lf[108]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[153]);}

/* k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in ... */
static void C_ccall f_7464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7464,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[153],t1);
t3=C_a_i_list(&a,2,((C_word*)t0)[2],t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7032,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7034,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:617: ##sys#er-transformer */
t7=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k5497 in k5866 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in ... */
static void C_ccall f_5499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:912: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[113],((C_word*)t0)[3],t1);}

/* k5489 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in ... */
static void C_ccall f_5491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5491,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[102],t1);
t3=C_a_i_list(&a,1,t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5319,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5321,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:988: ##sys#er-transformer */
t7=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* loop in k8362 in k8283 in a8280 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_8673(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8673,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8686,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_listp(t4))){
/* chicken-syntax.scm:381: append */
t6=*((C_word*)lf[164]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,t3);}
else{
if(C_truep(C_i_pairp(t4))){
/* chicken-syntax.scm:382: append* */
t6=((C_word*)((C_word*)t0)[3])[1];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,t3);}
else{
t6=C_a_i_cons(&a,2,t4,t3);
t7=t2;
t8=C_u_i_cdr(t7);
/* chicken-syntax.scm:384: loop */
t11=t1;
t12=t8;
t13=t6;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}}}

/* k8684 in loop in k8362 in k8283 in a8280 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 in ... */
static void C_ccall f_8686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* chicken-syntax.scm:384: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_8673(t4,((C_word*)t0)[4],t3,t1);}

/* k5153 in k5150 in loop in k5133 in k5130 in k5127 in k5124 in a5121 in k5309 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in ... */
static void C_ccall f_5155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5155,2,t0,t1);}
t2=t1;
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5161,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5198,a[2]=((C_word*)t0)[7],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1032: gensym */
t5=*((C_word*)lf[32]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t3=C_i_car(t2);
t4=C_u_i_cdr(t2);
t5=C_a_i_cons(&a,2,t3,t4);
t6=C_a_i_list(&a,3,lf[99],((C_word*)t0)[6],t5);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_list(&a,3,lf[30],((C_word*)t0)[5],t6));}}

/* k5150 in loop in k5133 in k5130 in k5127 in k5124 in a5121 in k5309 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in ... */
static void C_ccall f_5152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5152,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5155,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:1030: reverse */
t4=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}

/* k8975 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_8977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:315: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[229],C_SCHEME_END_OF_LIST,t1);}

/* a8978 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_8979(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8979,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8983,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:319: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[229],t2,lf[230]);}

/* loop in k5133 in k5130 in k5127 in k5124 in a5121 in k5309 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in ... */
static void C_fcall f_5142(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5142,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep(C_i_nullp(t2))){
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5152,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:1029: reverse */
t8=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}
else{
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5221,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t4,a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
t8=C_i_car(t2);
/* chicken-syntax.scm:1039: c */
t9=((C_word*)t0)[6];
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,((C_word*)t0)[8],t8);}}

/* k5635 in k5593 in k5586 in k5580 in loop in k5788 in k5536 in k5530 in k5527 in k5521 in k5518 in k5503 in a5500 in k5866 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in ... */
static void C_ccall f_5637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5637,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_5603(t2,C_SCHEME_END_OF_LIST);}
else{
t2=C_a_i_list(&a,2,lf[121],lf[121]);
t3=C_a_i_list(&a,3,t2,((C_word*)t0)[3],((C_word*)t0)[4]);
t4=((C_word*)t0)[2];
f_5603(t4,C_a_i_list(&a,1,t3));}}

/* k8981 in a8978 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_8983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8983,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,lf[227]);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
t7=C_a_i_cons(&a,2,lf[26],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_list(&a,4,lf[157],t2,t3,t7));}

/* k4397 in a4394 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in ... */
static void C_ccall f_4399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4399,2,t0,t1);}
if(C_truep(C_i_memq(lf[13],*((C_word*)lf[14]+1)))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4415,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* chicken-syntax.scm:1202: ##compiler#check-and-validate-type */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,lf[52]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_caddr(((C_word*)t0)[2]));}}

/* k5605 in k5601 in k5593 in k5586 in k5580 in loop in k5788 in k5536 in k5530 in k5527 in k5521 in k5518 in k5503 in a5500 in k5866 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in ... */
static void C_ccall f_5607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:944: ##sys#append */
t2=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k4391 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in ... */
static void C_ccall f_4393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1195: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[52],C_SCHEME_END_OF_LIST,t1);}

/* a4394 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in ... */
static void C_ccall f_4395(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4395,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4399,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1199: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[52],t2,lf[61]);}

/* k5440 in k5414 in loop in k5332 in k5329 in k5326 in k5323 in a5320 in k5489 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in ... */
static void C_ccall f_5442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5442,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
if(C_truep(C_i_nullp(t3))){
/* chicken-syntax.scm:1011: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5341(t4,((C_word*)t0)[4],C_SCHEME_END_OF_LIST,((C_word*)t0)[5],((C_word*)t0)[6],C_SCHEME_TRUE);}
else{
/* chicken-syntax.scm:1012: syntax-error */
t4=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[4],lf[109],lf[110],((C_word*)t0)[7]);}}
else{
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[2];
t5=C_u_i_car(t4);
t6=C_a_i_cons(&a,2,t5,((C_word*)t0)[6]);
/* chicken-syntax.scm:1015: loop */
t7=((C_word*)((C_word*)t0)[3])[1];
f_5341(t7,((C_word*)t0)[4],t3,((C_word*)t0)[5],t6,C_SCHEME_FALSE);}}

/* k5601 in k5593 in k5586 in k5580 in loop in k5788 in k5536 in k5530 in k5527 in k5521 in k5518 in k5503 in a5500 in k5866 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in ... */
static void C_fcall f_5603(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5603,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5607,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
t6=C_fixnum_increase(((C_word*)t0)[4]);
/* chicken-syntax.scm:980: loop */
t7=((C_word*)((C_word*)t0)[5])[1];
f_5563(t7,t3,t5,t6);}

/* k3874 in k3956 in k3775 in k3772 in loop in k3754 in k3751 in k3748 in k3745 in k3741 in k3732 in a3723 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in ... */
static void C_ccall f_3876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1238: ##sys#put! */
t2=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[40],t1);}

/* k3781 in k3956 in k3775 in k3772 in loop in k3754 in k3751 in k3748 in k3745 in k3741 in k3732 in a3723 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in ... */
static void C_ccall f_3783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3783,2,t0,t1);}
t2=C_a_i_list(&a,2,lf[35],((C_word*)t0)[2]);
t3=C_a_i_list(&a,2,lf[36],((C_word*)t0)[2]);
t4=C_a_i_list(&a,3,lf[37],t2,t3);
t5=t4;
t6=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t7=t6;
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3815,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t7,a[5]=((C_word*)t0)[6],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3817,a[2]=t11,a[3]=t14,a[4]=t9,a[5]=((C_word)li4),tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_3817(t16,t12,((C_word*)t0)[3],((C_word*)t0)[7]);}

/* k5656 in k5586 in k5580 in loop in k5788 in k5536 in k5530 in k5527 in k5521 in k5518 in k5503 in a5500 in k5866 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in ... */
static void C_ccall f_5658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5658,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_list(&a,3,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);
t3=((C_word*)t0)[5];
f_5595(t3,C_a_i_list(&a,3,((C_word*)t0)[6],((C_word*)t0)[7],t2));}
else{
t2=((C_word*)t0)[5];
f_5595(t2,C_a_i_list(&a,3,((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[3]));}}

/* k5434 in k5414 in loop in k5332 in k5329 in k5326 in k5323 in a5320 in k5489 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in ... */
static void C_ccall f_5436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1007: r */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* k7865 in k7846 in k7843 in a7840 in k7881 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in ... */
static void C_ccall f_7867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7867,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_a_i_list(&a,3,t1,((C_word*)t0)[3],t2);
t4=C_a_i_list(&a,3,lf[99],((C_word*)t0)[3],t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_list(&a,3,lf[142],((C_word*)t0)[5],t4));}

/* k4592 in k4615 in k4546 in k4543 in a4540 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in ... */
static void C_ccall f_4594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4594,2,t0,t1);}
t2=C_a_i_list(&a,2,lf[20],t1);
t3=C_a_i_list(&a,2,lf[20],((C_word*)t0)[2]);
t4=C_a_i_list(&a,5,lf[71],((C_word*)t0)[3],((C_word*)t0)[4],t2,t3);
t5=C_a_i_list(&a,3,lf[72],lf[73],lf[74]);
t6=C_a_i_list(&a,2,lf[75],t4);
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_list(&a,5,lf[76],((C_word*)t0)[6],C_SCHEME_TRUE,t5,t6));}

/* k8963 in map-loop781 in k8815 in a8812 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_8965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8965,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8936(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8936(t6,((C_word*)t0)[5],t5);}}

/* k3893 in k3956 in k3775 in k3772 in loop in k3754 in k3751 in k3748 in k3745 in k3741 in k3732 in a3723 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in ... */
static void C_fcall f_3895(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3895,NULL,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_list1(&a,1,t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3884,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1251: ##compiler#variable-mark */
t6=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[4],lf[40]);}

/* a7840 in k7881 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 in ... */
static void C_ccall f_7841(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7841,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7845,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:453: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[209],t2,lf[210]);}

/* a4892 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in ... */
static void C_ccall f_4893(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4893,5,t0,t1,t2,t3,t4);}
t5=C_i_cdr(t2);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4903,a[2]=t6,a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t6))){
t8=C_i_cdr(t6);
t9=t7;
f_4903(t9,C_eqp(t8,C_SCHEME_END_OF_LIST));}
else{
t8=t7;
f_4903(t8,C_SCHEME_FALSE);}}

/* k3882 in k3893 in k3956 in k3775 in k3772 in loop in k3754 in k3751 in k3748 in k3745 in k3741 in k3732 in a3723 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in ... */
static void C_ccall f_3884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
/* chicken-syntax.scm:1240: ##sys#append */
t3=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],((C_word*)t0)[3],t2);}
else{
/* chicken-syntax.scm:1240: ##sys#append */
t2=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}}

/* k4889 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in ... */
static void C_ccall f_4891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1102: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[88],C_SCHEME_END_OF_LIST,t1);}

/* loop in k3754 in k3751 in k3748 in k3745 in k3741 in k3732 in a3723 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in ... */
static void C_fcall f_3764(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(11);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3764,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3774,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t3,a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm:1230: reverse */
t6=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
t5=C_i_car(t2);
t6=t5;
if(C_truep(C_i_symbolp(t6))){
t7=t2;
t8=C_u_i_cdr(t7);
t9=C_a_i_cons(&a,2,t6,t3);
t10=C_a_i_cons(&a,2,lf[44],t4);
/* chicken-syntax.scm:1265: loop */
t17=t1;
t18=t8;
t19=t9;
t20=t10;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4014,a[2]=t2,a[3]=t6,a[4]=t3,a[5]=t4,a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_i_listp(t6))){
t8=C_u_i_length(t6);
t9=C_eqp(C_fix(2),t8);
if(C_truep(t9)){
t10=C_i_car(t6);
t11=t7;
f_4014(t11,C_i_symbolp(t10));}
else{
t10=t7;
f_4014(t10,C_SCHEME_FALSE);}}
else{
t8=t7;
f_4014(t8,C_SCHEME_FALSE);}}}}

/* k4537 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in ... */
static void C_ccall f_4539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1146: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[70],C_SCHEME_END_OF_LIST,t1);}

/* k7843 in a7840 in k7881 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in ... */
static void C_ccall f_7845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7848,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:454: r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[174]);}

/* k7846 in k7843 in a7840 in k7881 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in ... */
static void C_ccall f_7848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7848,2,t0,t1);}
t2=t1;
t3=C_i_caddr(((C_word*)t0)[2]);
t4=C_a_i_list(&a,3,lf[99],C_SCHEME_END_OF_LIST,t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7867,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:457: r */
t7=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[208]);}

/* k5170 in k5159 in k5153 in k5150 in loop in k5133 in k5130 in k5127 in k5124 in a5121 in k5309 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in ... */
static void C_ccall f_5172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5172,2,t0,t1);}
t2=t1;
t3=C_i_car(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5188,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t6=C_u_i_cdr(((C_word*)t0)[2]);
t7=C_a_i_list(&a,1,((C_word*)t0)[6]);
/* chicken-syntax.scm:1032: ##sys#append */
t8=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,t6,t7);}

/* k4349 in k4337 in loop2242 in k4321 in k4315 in k4312 in a4089 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in ... */
static void C_fcall f_4351(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4351,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4362,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1208: ##sys#+ */
t5=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[5],C_fix(-1));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4543 in a4540 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in ... */
static void C_ccall f_4545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4548,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1151: ##sys#strip-syntax */
t3=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k4546 in k4543 in a4540 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in ... */
static void C_ccall f_4548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4548,2,t0,t1);}
t2=C_i_cadr(t1);
t3=C_i_car(t2);
t4=t3;
t5=C_i_caddr(t1);
t6=t5;
t7=C_u_i_cdr(t1);
t8=C_u_i_cdr(t7);
t9=C_u_i_cdr(t8);
t10=C_a_i_list(&a,2,lf[20],t4);
t11=t10;
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_FALSE;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_u_i_cdr(t2);
t17=C_i_check_list_2(t16,lf[28]);
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4617,a[2]=t9,a[3]=t11,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4619,a[2]=t15,a[3]=t20,a[4]=t13,a[5]=((C_word)li19),tmp=(C_word)a,a+=6,tmp));
t22=((C_word*)t20)[1];
f_4619(t22,t18,t16);}

/* a4540 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in ... */
static void C_ccall f_4541(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4541,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4545,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1150: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[70],t2,lf[78]);}

/* k4360 in k4349 in k4337 in loop2242 in k4321 in k4315 in k4312 in a4089 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in ... */
static void C_ccall f_4362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1208: loop2242 */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4332(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k5159 in k5153 in k5150 in loop in k5133 in k5130 in k5127 in k5124 in a5121 in k5309 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in ... */
static void C_ccall f_5161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5161,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5172,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:1032: ##sys#append */
t4=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[6],t2);}

/* k10516 in k10501 in k10479 in a10476 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_10518(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10518,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_a_i_list(&a,2,t2,((C_word*)t0)[3]);
t4=C_a_i_list(&a,1,t3);
t5=C_a_i_cons(&a,2,t4,((C_word*)t0)[4]);
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_cons(&a,2,lf[30],t5));}
else{
t2=C_a_i_list(&a,3,lf[99],C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[4]);
t4=C_a_i_cons(&a,2,lf[99],t3);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_list(&a,3,lf[142],t2,t4));}}

/* k10580 in k10572 in a10569 in k3393 in k3390 in k3386 */
static void C_ccall f_10582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10582,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10585,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:62: r */
t4=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[47]);}

/* k10583 in k10580 in k10572 in a10569 in k3393 in k3390 in k3386 */
static void C_ccall f_10585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10585,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10588,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm:63: r */
t4=((C_word*)t0)[7];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[123]);}

/* k10586 in k10583 in k10580 in k10572 in a10569 in k3393 in k3390 in k3386 */
static void C_ccall f_10588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10588,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10591,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm:64: r */
t4=((C_word*)t0)[8];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[112]);}

/* k6143 in k6147 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in ... */
static void C_ccall f_6145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6145,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[127],t1);
t3=C_a_i_list(&a,2,((C_word*)t0)[2],t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5876,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5878,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:878: ##sys#er-transformer */
t7=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k9268 in map-loop682 in k9105 in k9095 in k9083 in k9068 in k9065 in k9059 in k9056 in k9048 in a9030 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in ... */
static void C_fcall f_9270(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[6])[1];
f_9257(t5,((C_word*)t0)[7],t3,t4);}

/* a6158 in k6266 in k6270 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in ... */
static void C_ccall f_6159(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6159,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6163,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:858: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[133],t2,lf[145]);}

/* k6155 in k6266 in k6270 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in ... */
static void C_ccall f_6157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:852: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[133],((C_word*)t0)[3],t1);}

/* k3611 in k3605 in a3602 in k3523 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in ... */
static void C_ccall f_3613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3613,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3616,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:1286: get-line-number */
t4=*((C_word*)lf[31]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k3614 in k3611 in k3605 in a3602 in k3523 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in ... */
static void C_ccall f_3616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3616,2,t0,t1);}
t2=t1;
t3=C_i_cadr(((C_word*)t0)[2]);
t4=C_a_i_list(&a,2,((C_word*)t0)[3],t3);
t5=C_a_i_list(&a,1,t4);
t6=t5;
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3637,a[2]=((C_word*)t0)[4],a[3]=((C_word)li1),tmp=(C_word)a,a+=4,tmp);
t12=((C_word*)t0)[2];
t13=C_u_i_cdr(t12);
t14=C_u_i_cdr(t13);
t15=C_i_check_list_2(t14,lf[28]);
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3675,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3677,a[2]=t10,a[3]=t18,a[4]=t8,a[5]=t11,a[6]=((C_word)li2),tmp=(C_word)a,a+=7,tmp));
t20=((C_word*)t18)[1];
f_3677(t20,t16,t14);}

/* a10569 in k3393 in k3390 in k3386 */
static void C_ccall f_10570(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10570,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10574,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:58: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[276],t2,lf[285]);}

/* k10572 in a10569 in k3393 in k3390 in k3386 */
static void C_ccall f_10574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10574,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10582,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:61: symbol->string */
t8=*((C_word*)lf[181]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}

/* k10479 in a10476 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_10481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10481,2,t0,t1);}
t2=C_i_cddr(((C_word*)t0)[2]);
if(C_truep(C_i_nullp(t2))){
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
t5=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t4);
t6=C_a_i_cons(&a,2,lf[99],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_list(&a,3,lf[142],t6,lf[273]));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10503,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:129: ##sys#check-syntax */
t4=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[272],((C_word*)t0)[2],lf[274]);}}

/* k6147 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in ... */
static void C_ccall f_6149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6149,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[27],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6145,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:877: ##sys#primitive-alias */
t5=*((C_word*)lf[108]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[127]);}

/* k10566 in k3393 in k3390 in k3386 */
static void C_ccall f_10568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:54: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[276],C_SCHEME_END_OF_LIST,t1);}

/* k10473 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_10475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:120: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[272],C_SCHEME_END_OF_LIST,t1);}

/* a10476 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_10477(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10477,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10481,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:125: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[272],t2,lf[275]);}

/* a10396 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_10397(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10397,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10401,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:163: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[264],t2,lf[266]);}

/* k10393 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_10395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:159: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[264],C_SCHEME_END_OF_LIST,t1);}

/* k5196 in k5153 in k5150 in loop in k5133 in k5130 in k5127 in k5124 in a5121 in k5309 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in ... */
static void C_ccall f_5198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1032: r */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* k4337 in loop2242 in k4321 in k4315 in k4312 in a4089 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in ... */
static void C_ccall f_4339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4339,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_eqp(((C_word*)t0)[3],C_SCHEME_END_OF_LIST));}
else{
t2=C_i_car(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4351,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t2))){
t4=C_i_cdr(t2);
if(C_truep(C_i_pairp(t4))){
t5=C_i_cdr(t4);
t6=t3;
f_4351(t6,C_eqp(t5,C_SCHEME_END_OF_LIST));}
else{
t5=t3;
f_4351(t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_4351(t4,C_SCHEME_FALSE);}}}

/* loop2242 in k4321 in k4315 in k4312 in a4089 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in ... */
static void C_fcall f_4332(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4332,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4339,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:1208: ##sys#= */
t5=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,C_fix(0));}

/* k3599 in k3523 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in ... */
static void C_ccall f_3601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1279: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[25],C_SCHEME_END_OF_LIST,t1);}

/* a3602 in k3523 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in ... */
static void C_ccall f_3603(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3603,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3607,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1283: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[25],t2,lf[33]);}

/* k3605 in a3602 in k3523 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in ... */
static void C_ccall f_3607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3607,2,t0,t1);}
t2=C_i_memq(lf[13],*((C_word*)lf[14]+1));
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3613,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1285: gensym */
t5=*((C_word*)lf[32]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* quotify-proc1256 in a7736 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in ... */
static void C_fcall f_7739(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7739,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7743,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:465: ##sys#check-syntax */
t5=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,t3,t2,lf[206]);}

/* k7733 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 in ... */
static void C_ccall f_7735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:459: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[203],C_SCHEME_END_OF_LIST,t1);}

/* k5186 in k5170 in k5159 in k5153 in k5150 in loop in k5133 in k5130 in k5127 in k5124 in a5121 in k5309 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in ... */
static void C_ccall f_5188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5188,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=C_a_i_list(&a,3,lf[99],((C_word*)t0)[4],t3);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_list(&a,3,lf[30],((C_word*)t0)[6],t4));}

/* k10383 in k10376 in k10321 in k10310 in a10307 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_10385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_10326(t3,t2);}

/* a7736 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 in ... */
static void C_ccall f_7737(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7737,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7739,a[2]=t4,a[3]=t3,a[4]=((C_word)li77),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7827,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=C_i_cdr(t2);
/* chicken-syntax.scm:478: quotify-proc */
t8=t5;
f_7739(t8,t6,t7,lf[203]);}

/* k10376 in k10321 in k10310 in a10307 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_10378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10378,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10385,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:178: string-append */
t3=*((C_word*)lf[180]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[261],t1,lf[262],((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
f_10326(t2,C_SCHEME_FALSE);}}

/* k6107 in map-loop1809 in k6025 in k5895 in k5892 in k5889 in k5886 in k5883 in k5880 in a5877 in k6143 in k6147 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in ... */
static void C_ccall f_6109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6109,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6080(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6080(t6,((C_word*)t0)[5],t5);}}

/* k6161 in a6158 in k6266 in k6270 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in ... */
static void C_ccall f_6163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6163,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6166,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:859: r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[144]);}

/* g2485 in k3614 in k3611 in k3605 in a3602 in k3523 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in ... */
static void C_fcall f_3637(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3637,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3641,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=C_i_car(t2);
/* chicken-syntax.scm:1292: ##sys#strip-syntax */
t5=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k6164 in k6161 in a6158 in k6266 in k6270 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in ... */
static void C_ccall f_6166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6166,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6169,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:860: r */
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[143]);}

/* k6167 in k6164 in k6161 in a6158 in k6266 in k6270 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in ... */
static void C_ccall f_6169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6169,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6180,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:861: r */
t4=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[138]);}

/* k3639 in g2485 in k3614 in k3611 in k3605 in a3602 in k3523 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in ... */
static void C_ccall f_3641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3648,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_eqp(t1,lf[27]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_a_i_cons(&a,2,lf[26],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_list2(&a,2,lf[27],t6));}
else{
if(C_truep(((C_word*)t0)[4])){
/* chicken-syntax.scm:1297: ##compiler#check-and-validate-type */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t1,lf[25]);}
else{
t4=t1;
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
t7=C_a_i_cons(&a,2,lf[26],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_list2(&a,2,t4,t7));}}}

/* k10697 in k10694 in k10691 in mapslots in k10839 in k10865 in k10650 in k10589 in k10586 in k10583 in k10580 in k10572 in a10569 in k3393 in k3390 in k3386 */
static void C_ccall f_10699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[79],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10699,2,t0,t1);}
t2=t1;
t3=C_a_i_list(&a,2,lf[125],lf[278]);
t4=C_a_i_list(&a,2,lf[114],((C_word*)t0)[2]);
t5=C_a_i_list(&a,3,lf[118],lf[125],t4);
t6=C_a_i_list(&a,2,lf[119],t5);
t7=C_a_i_list(&a,4,lf[122],lf[125],((C_word*)t0)[3],lf[278]);
t8=C_a_i_list(&a,4,lf[99],t3,t6,t7);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10725,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10729,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[8],a[6]=t9,a[7]=((C_word*)t0)[9],a[8]=t2,a[9]=t10,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[7])){
t12=t11;
f_10729(t12,C_SCHEME_END_OF_LIST);}
else{
t12=C_a_i_list(&a,3,((C_word*)t0)[9],((C_word*)t0)[10],t9);
t13=t11;
f_10729(t13,C_a_i_list(&a,1,t12));}}

/* k3646 in k3639 in g2485 in k3614 in k3611 in k3605 in a3602 in k3523 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in ... */
static void C_ccall f_3648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3648,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_a_i_cons(&a,2,lf[26],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_list2(&a,2,t1,t4));}

/* k10694 in k10691 in mapslots in k10839 in k10865 in k10650 in k10589 in k10586 in k10583 in k10580 in k10572 in a10569 in k3393 in k3390 in k3386 */
static void C_ccall f_10696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10696,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10699,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10822,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:94: string-append */
t5=*((C_word*)lf[180]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[10],lf[279],((C_word*)t0)[11]);}

/* k10691 in mapslots in k10839 in k10865 in k10650 in k10589 in k10586 in k10583 in k10580 in k10572 in a10569 in k3393 in k3390 in k3386 */
static void C_ccall f_10693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10693,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10696,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t2,tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10826,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:93: string-append */
t5=*((C_word*)lf[180]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,((C_word*)t0)[10],lf[280],t2,lf[281]);}

/* k9105 in k9095 in k9083 in k9068 in k9065 in k9059 in k9056 in k9048 in a9030 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9107,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_i_check_list_2(((C_word*)t0)[2],lf[28]);
t8=C_i_check_list_2(((C_word*)t0)[3],lf[28]);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9121,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9257,a[2]=t6,a[3]=t11,a[4]=t4,a[5]=((C_word)li117),tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_9257(t13,t9,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3523 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in ... */
static void C_ccall f_3525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3525,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3528,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3601,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3603,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1281: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3526 in k3523 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in ... */
static void C_ccall f_3528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3528,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3531,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3541,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3543,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1306: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in ... */
static void C_ccall f_3522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3522,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3525,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3722,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3724,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1214: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k10399 in a10396 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_10401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10401,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,2,lf[265],t2));}

/* k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in ... */
static void C_ccall f_3516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3516,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3519,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4393,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4395,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1197: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in ... */
static void C_ccall f_3519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3519,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3522,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4088,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4090,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1208: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in ... */
static void C_ccall f_3513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3513,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3516,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4431,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4433,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1177: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in ... */
static void C_ccall f_3510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3510,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3513,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4539,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4541,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1148: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k10324 in k10321 in k10310 in a10307 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_10326(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10326,NULL,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=C_a_i_list(&a,1,t2);
t4=t3;
t5=C_a_i_list(&a,2,lf[119],((C_word*)t0)[2]);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10349,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[5]))){
t8=C_u_i_cdr(((C_word*)t0)[5]);
t9=t7;
f_10349(t9,C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t8));}
else{
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10368,a[2]=t7,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:186: ##sys#strip-syntax */
t9=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,((C_word*)t0)[3]);}}

/* k10321 in k10310 in a10307 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_10323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10323,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10326,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_stringp(((C_word*)((C_word*)t0)[5])[1]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10378,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:177: get-line-number */
t5=*((C_word*)lf[31]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[6]);}
else{
t4=t3;
f_10326(t4,C_SCHEME_UNDEFINED);}}

/* a10427 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_10428(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10428,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10432,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:143: r */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[236]);}

/* k10424 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_10426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:139: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[268],C_SCHEME_END_OF_LIST,t1);}

/* k10310 in a10307 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_10312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10312,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
t7=C_i_nullp(t6);
t8=(C_truep(t7)?lf[260]:C_i_car(t6));
t9=t8;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10323,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t10,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:175: r */
t12=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,lf[174]);}

/* a10413 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_10414(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10414,5,t0,t1,t2,t3,t4);}
t5=C_i_cdr(t2);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_cons(&a,2,lf[37],t5));}

/* k10410 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_10412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:153: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[267],C_SCHEME_END_OF_LIST,t1);}

/* k7086 in k7112 in k7104 in recur in k7063 in k7059 in k7055 in k7273 in k7261 in k7258 in k7255 in k7252 in k7224 in k7218 in k7215 in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in ... */
static void C_ccall f_7088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7088,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k6178 in k6167 in k6164 in k6161 in a6158 in k6266 in k6270 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in ... */
static void C_ccall f_6180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6180,2,t0,t1);}
t2=t1;
t3=C_a_i_list(&a,1,((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6196,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:864: r */
t6=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[139]);}

/* k10304 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_10306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:166: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[259],C_SCHEME_END_OF_LIST,t1);}

/* a10307 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_10308(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10308,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10312,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:171: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[259],t2,lf[263]);}

/* k6194 in k6178 in k6167 in k6164 in k6161 in a6158 in k6266 in k6270 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in ... */
static void C_ccall f_6196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[111],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6196,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=C_i_caddr(((C_word*)t0)[2]);
t5=C_a_i_list(&a,3,lf[99],C_SCHEME_END_OF_LIST,t4);
t6=C_a_i_list(&a,2,((C_word*)t0)[3],t5);
t7=C_a_i_list(&a,3,lf[99],t3,t6);
t8=((C_word*)t0)[2];
t9=C_u_i_cdr(t8);
t10=C_u_i_cdr(t9);
t11=C_u_i_cdr(t10);
t12=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t11);
t13=C_a_i_cons(&a,2,lf[99],t12);
t14=C_a_i_list(&a,3,lf[140],lf[141],((C_word*)t0)[4]);
t15=C_a_i_list(&a,3,lf[99],C_SCHEME_END_OF_LIST,t14);
t16=C_a_i_list(&a,2,((C_word*)t0)[3],t15);
t17=C_a_i_list(&a,3,lf[99],((C_word*)t0)[4],t16);
t18=C_a_i_list(&a,3,lf[142],t13,t17);
t19=C_a_i_list(&a,3,lf[99],C_SCHEME_END_OF_LIST,t18);
t20=C_a_i_list(&a,3,t1,t7,t19);
t21=C_a_i_list(&a,3,lf[99],((C_word*)t0)[5],t20);
t22=C_a_i_list(&a,2,((C_word*)t0)[6],t21);
t23=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,C_a_i_list(&a,1,t22));}

/* k7059 in k7055 in k7273 in k7261 in k7258 in k7255 in k7252 in k7224 in k7218 in k7215 in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in ... */
static void C_ccall f_7061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7061,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7065,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:630: reverse */
t4=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* recur in k7063 in k7059 in k7055 in k7273 in k7261 in k7258 in k7255 in k7252 in k7224 in k7218 in k7215 in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in ... */
static void C_fcall f_7067(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7067,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(C_i_nullp(t2))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=C_i_cdr(t2);
t7=t6;
t8=C_i_car(t3);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7106,a[2]=t5,a[3]=t9,a[4]=t1,a[5]=t3,a[6]=t4,a[7]=((C_word*)t0)[2],a[8]=t7,tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm:635: reverse */
t11=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,t7);}}

/* k7063 in k7059 in k7055 in k7273 in k7261 in k7258 in k7255 in k7252 in k7224 in k7218 in k7215 in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in ... */
static void C_ccall f_7065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7065,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7067,a[2]=t3,a[3]=((C_word)li65),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_7067(t5,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1,((C_word*)t0)[5]);}

/* k10430 in a10427 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_10432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10432,2,t0,t1);}
t2=C_a_i_list(&a,1,lf[269]);
t3=C_i_cdr(((C_word*)t0)[2]);
t4=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=C_a_i_cons(&a,2,lf[99],t4);
t6=C_a_i_list(&a,1,lf[270]);
t7=C_a_i_list(&a,2,lf[271],t6);
t8=C_a_i_list(&a,3,lf[140],lf[141],t1);
t9=C_a_i_list(&a,4,lf[99],t1,t7,t8);
t10=C_a_i_list(&a,3,lf[142],t5,t9);
t11=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_a_i_list(&a,3,lf[26],t2,t10));}

/* k9119 in k9105 in k9095 in k9083 in k9068 in k9065 in k9059 in k9056 in k9048 in a9030 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 in ... */
static void C_ccall f_9121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9121,2,t0,t1);}
t2=t1;
t3=C_a_i_list(&a,2,((C_word*)t0)[2],C_SCHEME_FALSE);
t4=C_a_i_list(&a,1,t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9165,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9167,a[2]=((C_word*)t0)[2],a[3]=((C_word)li115),tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9194,a[2]=((C_word*)t0)[2],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9204,a[2]=t11,a[3]=t10,a[4]=t14,a[5]=t8,a[6]=((C_word)li116),tmp=(C_word)a,a+=7,tmp));
t16=((C_word*)t14)[1];
f_9204(t16,t12,((C_word*)t0)[7],((C_word*)t0)[8]);}

/* k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in ... */
static void C_ccall f_3504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3504,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3507,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4743,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4745,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1112: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in ... */
static void C_ccall f_3507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3507,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3510,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4656,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4658,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1121: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k10366 in k10324 in k10321 in k10310 in a10307 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_10368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10368,2,t0,t1);}
t2=C_a_i_list(&a,2,lf[114],t1);
t3=C_a_i_list(&a,1,t2);
t4=((C_word*)t0)[2];
f_10349(t4,C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t3));}

/* k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in ... */
static void C_ccall f_3501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3501,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3504,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4891,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4893,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1104: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k10347 in k10324 in k10321 in k10310 in a10307 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_10349(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10349,NULL,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[245],t1);
t3=C_a_i_list(&a,4,lf[157],((C_word*)t0)[2],((C_word*)t0)[3],t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,3,lf[30],((C_word*)t0)[5],t3));}

/* k4766 in k4753 in a4744 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in ... */
static void C_ccall f_4768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4768,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,t1,t2));}

/* k4791 in k4788 in k4782 in a4744 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in ... */
static void C_ccall f_4793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4793,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4799,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1112: ##sys#>= */
t4=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,C_fix(0));}

/* k4797 in k4791 in k4788 in k4782 in a4744 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in ... */
static void C_ccall f_4799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4799,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[2]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4808,a[2]=t4,a[3]=((C_word)li22),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4808(t6,((C_word*)t0)[3],t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_4755(2,t2,C_SCHEME_FALSE);}}

/* k4788 in k4782 in a4744 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in ... */
static void C_ccall f_4790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4790,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4793,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
/* chicken-syntax.scm:1112: ##sys#length */
t4=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[3];
f_4755(2,t2,C_SCHEME_FALSE);}}

/* k3545 in a3542 in k3526 in k3523 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in ... */
static void C_ccall f_3547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3547,2,t0,t1);}
if(C_truep(C_i_memq(lf[13],*((C_word*)lf[14]+1)))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3556,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
/* chicken-syntax.scm:1311: ##sys#strip-syntax */
t4=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[21]);}}

/* k3539 in k3526 in k3523 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in ... */
static void C_ccall f_3541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1304: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[12],C_SCHEME_END_OF_LIST,t1);}

/* a3542 in k3526 in k3523 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in ... */
static void C_ccall f_3543(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3543,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3547,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1308: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[12],t2,lf[23]);}

/* k5866 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in ... */
static void C_ccall f_5868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5868,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[112],t1);
t3=C_a_i_list(&a,1,t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5499,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5501,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:915: ##sys#er-transformer */
t7=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k4782 in a4744 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in ... */
static void C_ccall f_4784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4784,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4790,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
/* chicken-syntax.scm:1112: ##sys#list? */
t4=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[3];
f_4755(2,t2,C_SCHEME_FALSE);}}

/* k3535 in k3532 in k3529 in k3526 in k3523 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in ... */
static void C_ccall f_3537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* k3529 in k3526 in k3523 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in ... */
static void C_ccall f_3531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3531,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3534,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1323: ##sys#macro-subset */
t3=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],*((C_word*)lf[10]+1));}

/* k3532 in k3529 in k3526 in k3523 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in ... */
static void C_ccall f_3534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3534,2,t0,t1);}
t2=C_mutate2((C_word*)lf[1]+1 /* (set! ##sys#chicken-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3537,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1329: register-feature! */
t4=*((C_word*)lf[2]+1);
((C_proc8)(void*)(*((C_word*)t4+1)))(8,t4,t3,lf[3],lf[4],lf[5],lf[6],lf[7],lf[8]);}

/* a5877 in k6143 in k6147 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in ... */
static void C_ccall f_5878(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5878,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5882,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:880: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[128],t2,lf[137]);}

/* k5874 in k6143 in k6147 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in ... */
static void C_ccall f_5876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:874: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[128],((C_word*)t0)[3],t1);}

/* k5886 in k5883 in k5880 in a5877 in k6143 in k6147 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in ... */
static void C_ccall f_5888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5888,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5891,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:883: r */
t4=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[134]);}

/* map-loop894 in k8283 in a8280 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_8711(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8711,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5880 in a5877 in k6143 in k6147 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in ... */
static void C_ccall f_5882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5882,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5885,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:881: r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[136]);}

/* k5883 in k5880 in a5877 in k6143 in k6147 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in ... */
static void C_ccall f_5885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5885,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5888,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:882: r */
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[135]);}

/* k7204 in k7212 in recur in make-if-tree in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in ... */
static void C_ccall f_7206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7206,2,t0,t1);}
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7198,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[3],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm:653: r */
t6=((C_word*)t0)[11];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[153]);}

/* k5895 in k5892 in k5889 in k5886 in k5883 in k5880 in a5877 in k6143 in k6147 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in ... */
static void C_ccall f_5897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5897,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5899,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word)li41),tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6027,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm:897: r */
t5=((C_word*)t0)[8];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[133]);}

/* parse-clause in k5895 in k5892 in k5889 in k5886 in k5883 in k5880 in a5877 in k6143 in k6147 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in ... */
static void C_ccall f_5899(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5899,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5903,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t4=C_i_car(t2);
if(C_truep(C_i_symbolp(t4))){
t5=t2;
t6=t3;
f_5903(t6,C_u_i_car(t5));}
else{
t5=t3;
f_5903(t5,C_SCHEME_FALSE);}}

/* k5889 in k5886 in k5883 in k5880 in a5877 in k6143 in k6147 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in ... */
static void C_ccall f_5891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5891,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5894,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:884: r */
t4=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[127]);}

/* k5892 in k5889 in k5886 in k5883 in k5880 in a5877 in k6143 in k6147 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in ... */
static void C_ccall f_5894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5894,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5897,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm:885: r */
t4=((C_word*)t0)[7];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[27]);}

/* k7713 in k7697 in fold in k7642 in a7639 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in ... */
static void C_ccall f_7715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7715,2,t0,t1);}
t2=C_a_i_list(&a,4,lf[157],((C_word*)t0)[2],t1,C_SCHEME_FALSE);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,3,lf[30],((C_word*)t0)[4],t2));}

/* k9596 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:209: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[251],C_SCHEME_END_OF_LIST,t1);}

/* k3583 in k3560 in k3557 in k3554 in k3545 in a3542 in k3526 in k3523 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in ... */
static void C_ccall f_3585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3585,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_list(&a,4,lf[16],((C_word*)t0)[3],((C_word*)t0)[4],t2);
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,2,lf[17],t3));}

/* k4863 in loop2089 in k4847 in k4841 in k4838 in a4744 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in ... */
static void C_ccall f_4865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4865,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_eqp(((C_word*)t0)[3],C_SCHEME_END_OF_LIST));}
else{
t2=C_i_cdr(((C_word*)t0)[3]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4879,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1112: ##sys#+ */
t5=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[5],C_fix(-1));}}

/* k9583 in k9576 in k9569 in loop in k9516 in k9513 in k9510 in k9501 in a9498 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t3=C_slot(((C_word*)t0)[3],C_fix(1));
/* chicken-syntax.scm:261: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_9550(t4,((C_word*)t0)[5],t3);}
else{
t2=((C_word*)t0)[3];
t3=C_u_i_car(t2);
/* chicken-syntax.scm:260: ##sys#error */
t4=*((C_word*)lf[245]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[6],lf[246],t3);}}

/* k8056 in map-loop1180 in g1163 in k7943 in k7918 in k7899 in k7891 in a7888 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in ... */
static void C_ccall f_8058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8058,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8029(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8029(t6,((C_word*)t0)[5],t5);}}

/* k7237 in prefix-sym in k7224 in k7218 in k7215 in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in ... */
static void C_ccall f_7239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:662: string-append */
t2=*((C_word*)lf[180]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k7233 in prefix-sym in k7224 in k7218 in k7215 in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in ... */
static void C_ccall f_7235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:662: string->symbol */
t2=*((C_word*)lf[179]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7246 in g1454 in k7224 in k7218 in k7215 in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in ... */
static void C_ccall f_7248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:667: r */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* k4877 in k4863 in loop2089 in k4847 in k4841 in k4838 in a4744 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in ... */
static void C_ccall f_4879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1112: loop2089 */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4858(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* g1454 in k7224 in k7218 in k7215 in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in ... */
static void C_fcall f_7240(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7240,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7248,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:667: prefix-sym */
f_7227(t3,lf[182],t2);}

/* map-loop1130 in k7918 in k7899 in k7891 in a7888 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in ... */
static void C_fcall f_8106(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8106,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_list(&a,2,t3,lf[213]);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8098 in map-loop1157 in k7943 in k7918 in k7899 in k7891 in a7888 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in ... */
static void C_ccall f_8100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8100,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8071(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8071(t6,((C_word*)t0)[5],t5);}}

/* k7215 in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in ... */
static void C_ccall f_7217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7220,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:659: ##sys#check-syntax */
t3=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[178],((C_word*)t0)[5],lf[187]);}

/* loop in k9516 in k9513 in k9510 in k9501 in a9498 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_9550(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9550,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=t2;
t4=C_u_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9561,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9571,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=((C_word*)t0)[6],a[10]=t4,a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
/* chicken-syntax.scm:257: c */
t7=((C_word*)t0)[6];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t4,((C_word*)t0)[9]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7212 in recur in make-if-tree in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in ... */
static void C_ccall f_7214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7214,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7206,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm:652: r */
t5=((C_word*)t0)[11];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[152]);}

/* k7224 in k7218 in k7215 in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in ... */
static void C_ccall f_7226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7226,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7227,a[2]=((C_word)li62),tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7240,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word)li63),tmp=(C_word)a,a+=5,tmp);
t9=C_i_check_list_2(t2,lf[28]);
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7254,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7384,a[2]=t7,a[3]=t12,a[4]=t5,a[5]=t8,a[6]=((C_word)li68),tmp=(C_word)a,a+=7,tmp));
t14=((C_word*)t12)[1];
f_7384(t14,t10,t2);}

/* prefix-sym in k7224 in k7218 in k7215 in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in ... */
static void C_fcall f_7227(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7227,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7235,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7239,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:662: symbol->string */
t6=*((C_word*)lf[181]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}

/* k7218 in k7215 in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in ... */
static void C_ccall f_7220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7220,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_i_check_list_2(((C_word*)t0)[2],lf[28]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7226,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7419,a[2]=t5,a[3]=t9,a[4]=t3,a[5]=((C_word)li69),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_7419(t11,t7,((C_word*)t0)[2]);}

/* k9569 in loop in k9516 in k9513 in k9510 in k9501 in a9498 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9571,2,t0,t1);}
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t3=C_slot(((C_word*)t0)[3],C_fix(1));
/* chicken-syntax.scm:261: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_9550(t4,((C_word*)t0)[5],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9578,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm:258: c */
t3=((C_word*)t0)[9];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[10],((C_word*)t0)[12]);}}

/* k9576 in k9569 in loop in k9516 in k9513 in k9510 in k9501 in a9498 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9578,2,t0,t1);}
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t3=C_slot(((C_word*)t0)[3],C_fix(1));
/* chicken-syntax.scm:261: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_9550(t4,((C_word*)t0)[5],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9585,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:259: c */
t3=((C_word*)t0)[8];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[9],((C_word*)t0)[10]);}}

/* k3560 in k3557 in k3554 in k3545 in a3542 in k3526 in k3523 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in ... */
static void C_ccall f_3562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3562,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=t2;
t4=C_a_i_list(&a,2,((C_word*)t0)[2],lf[15]);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3585,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t5,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:1318: ##compiler#check-and-validate-type */
t7=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,t1,lf[12],((C_word*)t0)[3]);}

/* k9559 in loop in k9516 in k9513 in k9510 in k9501 in a9498 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
/* chicken-syntax.scm:261: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9550(t3,((C_word*)t0)[4],t2);}

/* k3557 in k3554 in k3545 in a3542 in k3526 in k3523 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in ... */
static void C_ccall f_3559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3559,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3562,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=C_i_caddr(((C_word*)t0)[4]);
/* chicken-syntax.scm:1313: ##sys#strip-syntax */
t5=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3554 in k3545 in a3542 in k3526 in k3523 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in ... */
static void C_ccall f_3556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3556,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3559,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1312: r */
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[20]);}

/* lookup in k7918 in k7899 in k7891 in a7888 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in ... */
static void C_ccall f_7921(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7921,3,t0,t1,t2);}
t3=C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_cdr(t3));}

/* k7918 in k7899 in k7891 in a7888 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in ... */
static void C_ccall f_7920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7920,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7921,a[2]=t2,a[3]=((C_word)li81),tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7945,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8106,a[2]=t7,a[3]=t10,a[4]=t5,a[5]=((C_word)li87),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_8106(t12,t8,((C_word*)t0)[5]);}

/* map-loop1505 in k7261 in k7258 in k7255 in k7252 in k7224 in k7218 in k7215 in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in ... */
static void C_fcall f_7314(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7314,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7343,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:676: g1511 */
t5=((C_word*)t0)[5];
f_7264(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* map-loop1098 in k7899 in k7891 in a7888 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in ... */
static void C_fcall f_8141(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8141,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8170,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:436: g1104 */
t5=((C_word*)t0)[5];
f_7902(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7255 in k7252 in k7224 in k7218 in k7215 in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in ... */
static void C_ccall f_7257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7257,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7260,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm:671: r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[186]);}

/* k7912 in g1104 in k7899 in k7891 in a7888 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in ... */
static void C_ccall f_7914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:436: r */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* k7908 in g1104 in k7899 in k7891 in a7888 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in ... */
static void C_ccall f_7910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7910,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k7252 in k7224 in k7218 in k7215 in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in ... */
static void C_ccall f_7254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7254,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7257,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7349,a[2]=t6,a[3]=t9,a[4]=t4,a[5]=((C_word)li67),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_7349(t11,t7,((C_word*)t0)[9]);}

/* g1104 in k7899 in k7891 in a7888 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in ... */
static void C_fcall f_7902(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7902,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7910,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7914,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:436: gensym */
t5=*((C_word*)lf[32]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k7899 in k7891 in a7888 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 in ... */
static void C_ccall f_7901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7901,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7902,a[2]=((C_word*)t0)[2],a[3]=((C_word)li80),tmp=(C_word)a,a+=4,tmp);
t8=C_i_check_list_2(t2,lf[28]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7920,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8141,a[2]=t6,a[3]=t11,a[4]=t4,a[5]=t7,a[6]=((C_word)li88),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_8141(t13,t9,t2);}

/* k7837 in k7881 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 in ... */
static void C_ccall f_7839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:448: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[209],((C_word*)t0)[3],t1);}

/* k7825 in a7736 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in ... */
static void C_ccall f_7827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7827,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,lf[207],t1));}

/* k9980 in map-loop314 in k9956 in k9952 in k9943 in k9637 in k9625 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_9982(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[6])[1];
f_9969(t5,((C_word*)t0)[7],t3,t4);}

/* map-loop348 in k9644 in k9637 in k9625 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_9894(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9894,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list(&a,3,lf[212],t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=t9;
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9907,a[2]=((C_word*)t0)[2],a[3]=t10,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t12=t11;
f_9907(t12,C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t10));}
else{
t12=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t10);
t13=t11;
f_9907(t13,t12);}}
else{
t6=((C_word*)((C_word*)t0)[4])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k9952 in k9943 in k9637 in k9625 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9954,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t0)[2];
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9958,a[2]=t7,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t6,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t9=C_u_i_length(((C_word*)t0)[4]);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10020,a[2]=t11,a[3]=((C_word)li133),tmp=(C_word)a,a+=4,tmp));
t13=((C_word*)t11)[1];
f_10020(t13,t8,t9);}

/* k9956 in k9952 in k9943 in k9637 in k9625 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9958,2,t0,t1);}
t2=C_i_check_list_2(((C_word*)t0)[2],lf[28]);
t3=C_i_check_list_2(t1,lf[28]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9967,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9969,a[2]=((C_word*)t0)[5],a[3]=t6,a[4]=((C_word*)t0)[6],a[5]=((C_word)li132),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_9969(t8,t4,((C_word*)t0)[2],t1);}

/* k9943 in k9637 in k9625 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9945,2,t0,t1);}
t2=C_i_check_list_2(((C_word*)t0)[2],lf[28]);
t3=C_i_check_list_2(t1,lf[28]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9954,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10040,a[2]=((C_word*)t0)[6],a[3]=t6,a[4]=((C_word*)t0)[7],a[5]=((C_word)li134),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_10040(t8,t4,((C_word*)t0)[2],t1);}

/* k4654 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in ... */
static void C_ccall f_4656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1119: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[79],C_SCHEME_END_OF_LIST,t1);}

/* map-loop1862 in k5530 in k5527 in k5521 in k5518 in k5503 in a5500 in k5866 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in ... */
static void C_fcall f_5827(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5827,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6054 in k6047 in k6025 in k5895 in k5892 in k5889 in k5886 in k5883 in k5880 in a5877 in k6143 in k6147 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in ... */
static void C_ccall f_6056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6056,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6060,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_assq(((C_word*)t0)[7],((C_word*)t0)[8]))){
/* chicken-syntax.scm:901: ##sys#append */
t4=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);}
else{
t4=C_a_i_list(&a,2,lf[131],((C_word*)t0)[6]);
t5=C_a_i_list(&a,2,((C_word*)t0)[7],t4);
t6=C_a_i_list(&a,1,t5);
/* chicken-syntax.scm:901: ##sys#append */
t7=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,((C_word*)t0)[8],t6);}}

/* a4657 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in ... */
static void C_ccall f_4658(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4658,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4662,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1123: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[79],t2,lf[85]);}

/* k8021 in map-loop1206 in k7973 in g1163 in k7943 in k7918 in k7899 in k7891 in a7888 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in ... */
static void C_ccall f_8023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8023,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7994(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7994(t6,((C_word*)t0)[5],t5);}}

/* map-loop384 in k9820 in k9644 in k9637 in k9625 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_9845(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9845,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list(&a,3,lf[212],t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=t9;
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9858,a[2]=((C_word*)t0)[2],a[3]=t10,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t12=t11;
f_9858(t12,C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t10));}
else{
t12=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t10);
t13=t11;
f_9858(t13,t12);}}
else{
t6=((C_word*)((C_word*)t0)[4])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k6047 in k6025 in k5895 in k5892 in k5889 in k5886 in k5883 in k5880 in a5877 in k6143 in k6147 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in ... */
static void C_ccall f_6049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6049,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6056,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm:902: r */
t4=((C_word*)t0)[8];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[132]);}

/* k4646 in map-loop2163 in k4546 in k4543 in a4540 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in ... */
static void C_ccall f_4648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4648,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4619(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4619(t6,((C_word*)t0)[5],t5);}}

/* map-loop1180 in g1163 in k7943 in k7918 in k7899 in k7891 in a7888 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in ... */
static void C_fcall f_8029(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8029,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8058,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:443: g1186 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9965 in k9956 in k9952 in k9943 in k9637 in k9625 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:214: ##sys#append */
t2=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* map-loop314 in k9956 in k9952 in k9943 in k9637 in k9625 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_9969(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9969,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=t9;
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9982,a[2]=((C_word*)t0)[2],a[3]=t10,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t12=t11;
f_9982(t12,C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t10));}
else{
t12=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t10);
t13=t11;
f_9982(t13,t12);}}
else{
t6=((C_word*)((C_word*)t0)[4])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k4615 in k4546 in k4543 in a4540 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in ... */
static void C_ccall f_4617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4617,2,t0,t1);}
t2=C_a_i_list(&a,2,lf[20],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4594,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:1164: ##sys#validate-exports */
t5=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[6],lf[70]);}

/* map-loop2163 in k4546 in k4543 in a4540 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in ... */
static void C_fcall f_4619(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4619,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4648,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=C_i_car(t4);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4603,a[2]=t5,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=C_i_cadr(t4);
/* chicken-syntax.scm:1161: ##sys#validate-exports */
t10=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,t9,lf[70]);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g1897 in k5536 in k5530 in k5527 in k5521 in k5518 in k5503 in a5500 in k5866 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in ... */
static C_word C_fcall f_5777(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_overflow_check;
if(C_truep(C_i_memq(t1,((C_word*)t0)[2]))){
t2=t1;
return(t2);}
else{
return(lf[115]);}}

/* map-loop1809 in k6025 in k5895 in k5892 in k5889 in k5886 in k5883 in k5880 in a5877 in k6143 in k6147 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in ... */
static void C_fcall f_6080(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6080,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6109,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:901: g1815 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4601 in map-loop2163 in k4546 in k4543 in a4540 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in ... */
static void C_ccall f_4603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4603,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k5788 in k5536 in k5530 in k5527 in k5521 in k5518 in k5503 in a5500 in k5866 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in ... */
static void C_ccall f_5790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[62],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5790,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,lf[116],t2);
t4=C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[4],t3);
t5=t4;
t6=C_a_i_list(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
t7=C_a_i_list(&a,2,lf[114],((C_word*)t0)[7]);
t8=C_a_i_list(&a,3,lf[117],((C_word*)t0)[6],t7);
t9=C_a_i_list(&a,3,((C_word*)t0)[3],t6,t8);
t10=t9;
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5561,a[2]=t10,a[3]=t5,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5563,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t13,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word)li35),tmp=(C_word)a,a+=10,tmp));
t15=((C_word*)t13)[1];
f_5563(t15,t11,((C_word*)t0)[12],C_fix(1));}

/* map-loop1891 in k5536 in k5530 in k5527 in k5521 in k5518 in k5503 in a5500 in k5866 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in ... */
static void C_fcall f_5792(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5792,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=f_5777(((C_word*)t0)[2],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate2(((C_word *)((C_word*)t0)[5])+1,t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[5])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6025 in k5895 in k5892 in k5889 in k5886 in k5883 in k5880 in a5877 in k6143 in k6147 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in ... */
static void C_ccall f_6027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[64],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6027,2,t0,t1);}
t2=t1;
t3=C_a_i_list(&a,2,lf[114],lf[129]);
t4=C_a_i_list(&a,3,lf[117],((C_word*)t0)[2],t3);
t5=C_a_i_list(&a,3,lf[130],((C_word*)t0)[2],C_fix(1));
t6=C_a_i_list(&a,3,((C_word*)t0)[3],t4,t5);
t7=C_a_i_list(&a,2,((C_word*)t0)[4],t6);
t8=C_a_i_list(&a,1,t7);
t9=t8;
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=((C_word*)t0)[5];
t15=C_i_cddr(((C_word*)t0)[6]);
t16=C_i_check_list_2(t15,lf[28]);
t17=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6049,a[2]=t9,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t2,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6080,a[2]=t13,a[3]=t19,a[4]=t11,a[5]=t14,a[6]=((C_word)li42),tmp=(C_word)a,a+=7,tmp));
t21=((C_word*)t19)[1];
f_6080(t21,t17,t15);}

/* map-loop1476 in k7252 in k7224 in k7218 in k7215 in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in ... */
static void C_fcall f_7349(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7349,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cadr(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7341 in map-loop1505 in k7261 in k7258 in k7255 in k7252 in k7224 in k7218 in k7215 in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in ... */
static void C_ccall f_7343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7343,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7314(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7314(t6,((C_word*)t0)[5],t5);}}

/* k9856 in map-loop384 in k9820 in k9644 in k9637 in k9625 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_9858(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[6])[1];
f_9845(t5,((C_word*)t0)[7],t3,t4);}

/* a6693 in map-loop1601 in k6390 in k6353 in a6350 in k6761 in k6765 in k6769 in k6773 in k6777 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in ... */
static void C_ccall f_6694(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6694,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k5518 in k5503 in a5500 in k5866 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in ... */
static void C_ccall f_5520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5520,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5523,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm:926: r */
t4=((C_word*)t0)[8];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[112]);}

/* k5521 in k5518 in k5503 in a5500 in k5866 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in ... */
static void C_ccall f_5523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5523,2,t0,t1);}
t2=t1;
t3=C_i_cdr(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5529,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t2,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm:928: r */
t6=((C_word*)t0)[9];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[125]);}

/* k6058 in k6054 in k6047 in k6025 in k5895 in k5892 in k5889 in k5886 in k5883 in k5880 in a5877 in k6143 in k6147 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in ... */
static void C_ccall f_6060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6060,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_list(&a,3,lf[30],((C_word*)t0)[3],t2);
t4=C_i_cadr(((C_word*)t0)[4]);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_list(&a,4,((C_word*)t0)[6],((C_word*)t0)[7],t3,t4));}

/* k5527 in k5521 in k5518 in k5503 in a5500 in k5866 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in ... */
static void C_ccall f_5529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5529,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5532,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm:929: r */
t4=((C_word*)t0)[11];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[124]);}

/* k8362 in k8283 in a8280 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_8364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8364,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8367,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8673,a[2]=t5,a[3]=((C_word*)t0)[7],a[4]=((C_word)li103),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_8673(t7,t3,t2,C_SCHEME_END_OF_LIST);}

/* g938 in k8365 in k8362 in k8283 in a8280 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 in ... */
static void C_fcall f_8368(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8368,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8376,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8380,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:385: gensym */
t5=*((C_word*)lf[32]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k8365 in k8362 in k8283 in a8280 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_8367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8367,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8368,a[2]=((C_word*)t0)[2],a[3]=((C_word)li95),tmp=(C_word)a,a+=4,tmp);
t8=C_i_check_list_2(t2,lf[28]);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8386,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8638,a[2]=t6,a[3]=t11,a[4]=t4,a[5]=t7,a[6]=((C_word)li102),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_8638(t13,t9,t2);}

/* map-loop1448 in k7224 in k7218 in k7215 in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in ... */
static void C_fcall f_7384(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7384,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7413,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:667: g1454 */
t5=((C_word*)t0)[5];
f_7240(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7782 in k7750 in k7741 in quotify-proc1256 in a7736 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in ... */
static void C_ccall f_7784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_u_i_car(((C_word*)t0)[2]);
/* chicken-syntax.scm:473: c */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[4],t1,t2);}

/* k7642 in a7639 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in ... */
static void C_ccall f_7644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7644,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
t5=C_u_i_cdr(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7654,a[2]=t5,a[3]=t7,a[4]=((C_word)li75),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_7654(t9,((C_word*)t0)[3],t2);}

/* k8883 in k8856 in k8815 in a8812 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_8885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8885,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,lf[99],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,3,lf[142],((C_word*)t0)[4],t3));}

/* k7778 in k7750 in k7741 in quotify-proc1256 in a7736 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in ... */
static void C_ccall f_7780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_7764(t2,C_i_not(t1));}

/* a7639 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in ... */
static void C_ccall f_7640(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7640,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7644,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:484: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[200],t2,lf[202]);}

/* map-loop810 in k8856 in k8815 in a8812 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_8887(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8887,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list(&a,3,lf[212],t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=t9;
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8900,a[2]=((C_word*)t0)[2],a[3]=t10,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t12=t11;
f_8900(t12,C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t10));}
else{
t12=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t10);
t13=t11;
f_8900(t13,t12);}}
else{
t6=((C_word*)((C_word*)t0)[4])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* a5500 in k5866 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in ... */
static void C_ccall f_5501(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5501,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5505,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:917: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[113],t2,lf[126]);}

/* k3976 in loop2 in k3775 in k3772 in loop in k3754 in k3751 in k3748 in k3745 in k3741 in k3732 in a3723 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in ... */
static void C_ccall f_3978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3978,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k5503 in a5500 in k5866 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in ... */
static void C_ccall f_5505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5505,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=C_i_caddr(((C_word*)t0)[2]);
t5=t4;
t6=C_i_cadddr(((C_word*)t0)[2]);
t7=t6;
t8=C_i_cddddr(((C_word*)t0)[2]);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5520,a[2]=t5,a[3]=t9,a[4]=t3,a[5]=t7,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm:925: r */
t11=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,lf[47]);}

/* loop in k9952 in k9943 in k9637 in k9625 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_10020(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10020,NULL,3,t0,t1,t2);}
t3=C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10034,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=C_fixnum_difference(t2,C_fix(1));
/* chicken-syntax.scm:225: loop */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* k8344 in k8340 in map*878 in k8283 in a8280 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 in ... */
static void C_ccall f_8346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8346,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k8340 in map*878 in k8283 in a8280 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_8342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8342,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8346,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* chicken-syntax.scm:374: map* */
t6=((C_word*)((C_word*)t0)[4])[1];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,((C_word*)t0)[5],t5);}

/* fold in k7642 in a7639 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in ... */
static void C_fcall f_7654(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7654,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[26],((C_word*)t0)[2]));}
else{
t3=C_i_car(t2);
t4=t3;
t5=t2;
t6=C_u_i_cdr(t5);
if(C_truep(C_i_pairp(t4))){
t7=C_i_cdr(t4);
if(C_truep(C_i_nullp(t7))){
t8=C_u_i_car(t4);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7696,a[2]=t1,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:493: fold */
t13=t9;
t14=t6;
t1=t13;
t2=t14;
goto loop;}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7699,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:495: ##sys#check-syntax */
t9=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[200],t4,lf[201]);}}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7681,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:492: fold */
t13=t7;
t14=t6;
t1=t13;
t2=t14;
goto loop;}}}

/* loop2 in k3775 in k3772 in loop in k3754 in k3751 in k3748 in k3745 in k3741 in k3732 in a3723 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in ... */
static void C_fcall f_3960(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3960,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=C_a_i_vector1(&a,1,t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3978,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_i_cdr(t2);
t8=C_fixnum_plus(t3,C_fix(1));
/* chicken-syntax.scm:1237: loop2 */
t10=t6;
t11=t7;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* k6862 in k6851 in loop in k6812 in k6809 in k6806 in k6803 in k6791 in a6788 in k6933 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in ... */
static void C_ccall f_6864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6864,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,3,lf[30],((C_word*)t0)[3],t1));}

/* map-loop172 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_10194(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10194,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5593 in k5586 in k5580 in loop in k5788 in k5536 in k5530 in k5527 in k5521 in k5518 in k5503 in a5500 in k5866 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in ... */
static void C_fcall f_5595(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5595,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5599,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5603,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[6])){
if(C_truep(((C_word*)t0)[7])){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5637,a[2]=t4,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t6=C_i_cadr(((C_word*)t0)[9]);
/* chicken-syntax.scm:975: c */
t7=((C_word*)t0)[10];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[7],t6);}
else{
t5=C_a_i_list(&a,3,((C_word*)t0)[11],((C_word*)t0)[12],((C_word*)t0)[8]);
t6=t4;
f_5603(t6,C_a_i_list(&a,1,t5));}}
else{
t5=t4;
f_5603(t5,C_SCHEME_END_OF_LIST);}}

/* k5597 in k5593 in k5586 in k5580 in loop in k5788 in k5536 in k5530 in k5527 in k5521 in k5518 in k5503 in a5500 in k5866 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in ... */
static void C_ccall f_5599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5599,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k10032 in loop in k9952 in k9943 in k9637 in k9625 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_10034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10034,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,C_SCHEME_FALSE,t1));}

/* k10186 in map-loop199 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_10188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10188,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_10159(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_10159(t6,((C_word*)t0)[5],t5);}}

/* k8374 in g938 in k8365 in k8362 in k8283 in a8280 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in ... */
static void C_ccall f_8376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8376,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k8378 in g938 in k8365 in k8362 in k8283 in a8280 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in ... */
static void C_ccall f_8380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:385: r */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* lookup in k8384 in k8365 in k8362 in k8283 in a8280 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in ... */
static void C_ccall f_8387(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8387,3,t0,t1,t2);}
t3=C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_cdr(t3));}

/* k8384 in k8365 in k8362 in k8283 in a8280 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 in ... */
static void C_ccall f_8386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8386,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8387,a[2]=t2,a[3]=((C_word)li96),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8398,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8594,a[2]=t6,a[3]=((C_word*)t0)[7],a[4]=t3,a[5]=((C_word)li101),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_8594(t8,t4,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}

/* k4413 in k4397 in a4394 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in ... */
static void C_ccall f_4415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4415,2,t0,t1);}
t2=C_i_caddr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,4,lf[38],t1,C_SCHEME_TRUE,t2));}

/* k7983 in g1212 in k7973 in g1163 in k7943 in k7918 in k7899 in k7891 in a7888 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in ... */
static void C_ccall f_7985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7985,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,3,lf[212],((C_word*)t0)[3],t1));}

/* k8856 in k8815 in a8812 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_8858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8858,2,t0,t1);}
t2=t1;
t3=C_a_i_list(&a,3,lf[99],C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
t4=t3;
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_i_check_list_2(t2,lf[28]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8885,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8887,a[2]=t8,a[3]=t12,a[4]=t6,a[5]=((C_word)li108),tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_8887(t14,t10,((C_word*)t0)[4],t2);}

/* k5735 in loop in k5788 in k5536 in k5530 in k5527 in k5521 in k5518 in k5503 in a5500 in k5866 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in ... */
static void C_ccall f_5737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5582(t2,(C_truep(t1)?C_i_cadr(((C_word*)t0)[3]):C_SCHEME_FALSE));}

/* k10051 in map-loop257 in k9943 in k9637 in k9625 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_10053(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[6])[1];
f_10040(t5,((C_word*)t0)[7],t3,t4);}

/* map-loop1206 in k7973 in g1163 in k7943 in k7918 in k7899 in k7891 in a7888 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in ... */
static void C_fcall f_7994(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7994,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8023,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:444: g1212 */
t5=((C_word*)t0)[5];
f_7977(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7990 in k7973 in g1163 in k7943 in k7918 in k7899 in k7891 in a7888 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in ... */
static void C_ccall f_7992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7992,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,lf[99],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,3,lf[142],((C_word*)t0)[4],t3));}

/* k10151 in map-loop227 in k9625 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_10153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10153,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_10124(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_10124(t6,((C_word*)t0)[5],t5);}}

/* k6501 in k6482 in a6479 in k6462 in k6452 in a6449 in a6439 in k6424 in k6417 in k6414 in k6411 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6353 in a6350 in k6761 in k6765 in ... */
static void C_ccall f_6503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6503,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,3,lf[30],t1,((C_word*)t0)[3]));}

/* map-loop1681 in k6482 in a6479 in k6462 in k6452 in a6449 in a6439 in k6424 in k6417 in k6414 in k6411 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6353 in a6350 in k6761 in k6765 in ... */
static void C_fcall f_6505(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6505,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list2(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=t9;
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6518,a[2]=((C_word*)t0)[2],a[3]=t10,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t12=t11;
f_6518(t12,C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t10));}
else{
t12=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t10);
t13=t11;
f_6518(t13,t12);}}
else{
t6=((C_word*)((C_word*)t0)[4])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k6516 in map-loop1681 in k6482 in a6479 in k6462 in k6452 in a6449 in a6439 in k6424 in k6417 in k6414 in k6411 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6353 in a6350 in k6761 in ... */
static void C_fcall f_6518(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[6])[1];
f_6505(t5,((C_word*)t0)[7],t3,t4);}

/* map-loop199 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_10159(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10159,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10188,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:217: g205 */
t4=((C_word*)t0)[5];
f_9616(t4,t3);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4435 in a4432 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in ... */
static void C_ccall f_4437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4437,2,t0,t1);}
if(C_truep(C_i_memq(lf[13],*((C_word*)lf[14]+1)))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4446,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_caddr(((C_word*)t0)[2]);
/* chicken-syntax.scm:1182: ##sys#strip-syntax */
t4=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[68]);}}

/* k4429 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in ... */
static void C_ccall f_4431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1175: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[62],C_SCHEME_END_OF_LIST,t1);}

/* a4432 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in ... */
static void C_ccall f_4433(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4433,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4437,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1179: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[62],t2,lf[69]);}

/* g719 in k9119 in k9105 in k9095 in k9083 in k9068 in k9065 in k9059 in k9056 in k9048 in a9030 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in ... */
static C_word C_fcall f_9167(C_word *a,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_stack_overflow_check;
t3=C_a_i_list(&a,1,t1);
t4=C_a_i_list(&a,2,lf[236],t3);
t5=C_a_i_list(&a,1,t4);
t6=C_a_i_list(&a,3,t1,t2,((C_word*)t0)[2]);
t7=C_a_i_list(&a,3,lf[212],t2,lf[236]);
return(C_a_i_list(&a,4,lf[30],t5,t6,t7));}

/* k9163 in k9119 in k9105 in k9095 in k9083 in k9068 in k9065 in k9059 in k9056 in k9048 in a9030 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in ... */
static void C_ccall f_9165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[69],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9165,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=C_a_i_cons(&a,2,lf[99],t2);
t4=C_a_i_list(&a,2,((C_word*)t0)[2],t3);
t5=C_a_i_list(&a,1,t4);
t6=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t7=C_a_i_cons(&a,2,lf[99],t6);
t8=C_a_i_list(&a,4,lf[235],((C_word*)t0)[2],t7,((C_word*)t0)[2]);
t9=C_a_i_list(&a,3,lf[30],t5,t8);
t10=C_a_i_list(&a,3,lf[30],((C_word*)t0)[4],t9);
t11=C_a_i_list(&a,3,lf[30],((C_word*)t0)[5],t10);
t12=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_a_i_list(&a,3,lf[30],((C_word*)t0)[7],t11));}

/* g1212 in k7973 in g1163 in k7943 in k7918 in k7899 in k7891 in a7888 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in ... */
static void C_fcall f_7977(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7977,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7985,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:444: lookup */
t4=((C_word*)t0)[2];
f_7921(3,t4,t3,t2);}

/* k4444 in k4435 in a4432 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in ... */
static void C_ccall f_4446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4446,2,t0,t1);}
t2=t1;
t3=C_i_cadr(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4454,a[2]=t2,a[3]=t4,a[4]=((C_word)li16),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4464,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t4,a[5]=((C_word)li17),tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:1182: ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],t5,t6);}

/* k7973 in g1163 in k7943 in k7918 in k7899 in k7891 in a7888 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in ... */
static void C_ccall f_7975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7975,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7977,a[2]=((C_word*)t0)[2],a[3]=((C_word)li82),tmp=(C_word)a,a+=4,tmp);
t8=((C_word*)t0)[3];
t9=C_u_i_car(t8);
t10=C_i_check_list_2(t9,lf[28]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7992,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7994,a[2]=t6,a[3]=t13,a[4]=t4,a[5]=t7,a[6]=((C_word)li83),tmp=(C_word)a,a+=7,tmp));
t15=((C_word*)t13)[1];
f_7994(t15,t11,t9);}

/* k5580 in loop in k5788 in k5536 in k5530 in k5527 in k5521 in k5518 in k5503 in a5500 in k5866 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in ... */
static void C_fcall f_5582(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[128],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5582,NULL,2,t0,t1);}
t2=t1;
t3=C_a_i_list(&a,1,((C_word*)t0)[2]);
t4=C_a_i_list(&a,2,lf[114],((C_word*)t0)[3]);
t5=C_i_cadr(((C_word*)t0)[4]);
t6=C_a_i_list(&a,2,lf[114],t5);
t7=C_a_i_list(&a,4,lf[118],((C_word*)t0)[2],t4,t6);
t8=C_a_i_list(&a,2,lf[119],t7);
t9=C_a_i_list(&a,3,lf[120],((C_word*)t0)[2],((C_word*)t0)[5]);
t10=C_a_i_list(&a,4,lf[99],t3,t8,t9);
t11=t10;
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5588,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t2,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t11,tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[9])){
t13=C_a_i_list(&a,2,((C_word*)t0)[2],((C_word*)t0)[14]);
t14=C_a_i_list(&a,2,lf[114],((C_word*)t0)[3]);
t15=C_a_i_list(&a,2,lf[114],t2);
t16=C_a_i_list(&a,4,lf[118],((C_word*)t0)[2],t14,t15);
t17=C_a_i_list(&a,2,lf[119],t16);
t18=C_a_i_list(&a,4,lf[122],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[14]);
t19=t12;
f_5588(t19,C_a_i_list(&a,4,lf[99],t13,t17,t18));}
else{
t13=t12;
f_5588(t13,C_SCHEME_FALSE);}}

/* k5586 in k5580 in loop in k5788 in k5536 in k5530 in k5527 in k5521 in k5518 in k5503 in a5500 in k5866 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in ... */
static void C_fcall f_5588(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5588,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5595,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t4=C_u_i_cdr(((C_word*)t0)[8]);
t5=C_u_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5658,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[10],a[7]=t5,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[7])){
t7=C_u_i_cdr(((C_word*)t0)[8]);
t8=C_u_i_car(t7);
/* chicken-syntax.scm:970: c */
t9=((C_word*)t0)[9];
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,((C_word*)t0)[7],t8);}
else{
t7=t6;
f_5658(2,t7,C_SCHEME_FALSE);}}

/* map-loop2479 in k3614 in k3611 in k3605 in a3602 in k3523 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in ... */
static void C_fcall f_3677(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3677,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3706,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:1291: g2485 */
t5=((C_word*)t0)[5];
f_3637(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7753 in k7750 in k7741 in quotify-proc1256 in a7736 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in ... */
static void C_ccall f_7755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7755,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list2(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]));}

/* k7943 in k7918 in k7899 in k7891 in a7888 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in ... */
static void C_ccall f_7945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7945,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7949,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7951,a[2]=((C_word*)t0)[3],a[3]=((C_word)li85),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8069,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8071,a[2]=t7,a[3]=t11,a[4]=t5,a[5]=t8,a[6]=((C_word)li86),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_8071(t13,t9,((C_word*)t0)[5]);}

/* k7947 in k7943 in k7918 in k7899 in k7891 in a7888 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in ... */
static void C_ccall f_7949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7949,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[30],t2));}

/* a4453 in k4444 in k4435 in a4432 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in ... */
static void C_ccall f_4454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4462,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1186: ##sys#strip-syntax */
t3=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k3673 in k3614 in k3611 in k3605 in a3602 in k3523 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in ... */
static void C_ccall f_3675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3675,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=C_a_i_cons(&a,2,lf[29],t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_list(&a,3,lf[30],((C_word*)t0)[5],t4));}

/* k7750 in k7741 in quotify-proc1256 in a7736 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in ... */
static void C_fcall f_7752(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7752,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7755,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_i_pairp(t2);
t5=C_i_not(t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7764,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_7764(t7,t5);}
else{
t7=C_i_car(t2);
t8=C_eqp(lf[99],t7);
if(C_truep(t8)){
t9=t6;
f_7764(t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7780,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7784,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:473: r */
t11=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,lf[205]);}}}

/* k5536 in k5530 in k5527 in k5521 in k5518 in k5503 in a5500 in k5866 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in ... */
static void C_ccall f_5538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5538,2,t0,t1);}
t2=C_a_i_list(&a,2,lf[114],((C_word*)t0)[2]);
t3=t2;
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5777,a[2]=((C_word*)t0)[3],a[3]=((C_word)li34),tmp=(C_word)a,a+=4,tmp);
t9=C_i_check_list_2(t1,lf[28]);
t10=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5790,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5792,a[2]=t8,a[3]=t7,a[4]=t12,a[5]=t5,a[6]=((C_word)li36),tmp=(C_word)a,a+=7,tmp));
t14=((C_word*)t12)[1];
f_5792(t14,t10,t1);}

/* k5530 in k5527 in k5521 in k5518 in k5503 in a5500 in k5866 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in ... */
static void C_ccall f_5532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5532,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_i_check_list_2(((C_word*)t0)[2],lf[28]);
t8=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5538,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t2,a[12]=((C_word*)t0)[2],tmp=(C_word)a,a+=13,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5827,a[2]=t6,a[3]=t10,a[4]=t4,a[5]=((C_word)li37),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_5827(t12,t8,((C_word*)t0)[2]);}

/* map-loop227 in k9625 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_10124(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10124,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10153,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:218: g233 */
t4=((C_word*)t0)[5];
f_9628(t4,t3);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6324 in k6280 in a6277 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in ... */
static void C_ccall f_6326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6326,2,t0,t1);}
t2=C_a_i_list(&a,2,lf[20],((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[147],t3));}

/* k7762 in k7750 in k7741 in quotify-proc1256 in a7736 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in ... */
static void C_fcall f_7764(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7764,NULL,2,t0,t1);}
if(C_truep(t1)){
/* chicken-syntax.scm:474: syntax-error */
t2=*((C_word*)lf[45]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[203],lf[204],((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list2(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]));}}

/* k10711 in k10723 in k10697 in k10694 in k10691 in mapslots in k10839 in k10865 in k10650 in k10589 in k10586 in k10583 in k10580 in k10572 in a10569 in k3393 in k3390 in k3386 */
static void C_ccall f_10713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10713,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k8396 in k8384 in k8365 in k8362 in k8283 in a8280 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in ... */
static void C_ccall f_8398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8398,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8410,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8559,a[2]=t6,a[3]=t9,a[4]=t4,a[5]=((C_word)li100),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_8559(t11,t7,((C_word*)t0)[7]);}

/* k5559 in k5788 in k5536 in k5530 in k5527 in k5521 in k5518 in k5503 in a5500 in k5866 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in ... */
static void C_ccall f_5561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5561,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[26],t3));}

/* g1163 in k7943 in k7918 in k7899 in k7891 in a7888 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in ... */
static void C_fcall f_7951(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7951,NULL,3,t0,t1,t2);}
t3=C_i_cadr(t2);
t4=C_a_i_list(&a,3,lf[99],C_SCHEME_END_OF_LIST,t3);
t5=t4;
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=((C_word*)t0)[2];
t11=t2;
t12=C_u_i_car(t11);
t13=C_i_check_list_2(t12,lf[28]);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7975,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8029,a[2]=t9,a[3]=t16,a[4]=t7,a[5]=t10,a[6]=((C_word)li84),tmp=(C_word)a,a+=7,tmp));
t18=((C_word*)t16)[1];
f_8029(t18,t14,t12);}

/* loop in k5788 in k5536 in k5530 in k5527 in k5521 in k5518 in k5503 in a5500 in k5866 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in ... */
static void C_fcall f_5563(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5563,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=C_i_car(t2);
t5=t4;
t6=C_i_cddr(t5);
t7=C_i_pairp(t6);
t8=t7;
t9=(C_truep(t8)?C_i_caddr(t5):C_SCHEME_FALSE);
t10=t9;
t11=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_5582,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t3,a[6]=t1,a[7]=t2,a[8]=((C_word*)t0)[4],a[9]=t8,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],a[12]=t10,a[13]=((C_word*)t0)[7],a[14]=((C_word*)t0)[8],tmp=(C_word)a,a+=15,tmp);
if(C_truep(C_i_pairp(t10))){
t12=C_u_i_cdr(t10);
if(C_truep(C_i_pairp(t12))){
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5737,a[2]=t11,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
t14=C_u_i_car(t10);
/* chicken-syntax.scm:949: c */
t15=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,lf[123],t14);}
else{
t13=t11;
f_5582(t13,C_SCHEME_FALSE);}}
else{
t12=t11;
f_5582(t12,C_SCHEME_FALSE);}}}

/* map-loop257 in k9943 in k9637 in k9625 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_10040(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10040,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=t9;
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10053,a[2]=((C_word*)t0)[2],a[3]=t10,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t12=t11;
f_10053(t12,C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t10));}
else{
t12=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t10);
t13=t11;
f_10053(t13,t12);}}
else{
t6=((C_word*)((C_word*)t0)[4])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k7636 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in ... */
static void C_ccall f_7638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:480: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[200],C_SCHEME_END_OF_LIST,t1);}

/* k4487 in a4463 in k4444 in k4435 in a4432 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in ... */
static void C_ccall f_4489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4489,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[37],t2));}

/* k7741 in quotify-proc1256 in a7736 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in ... */
static void C_ccall f_7743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7743,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[2]);
t3=C_i_pairp(t2);
t4=(C_truep(t3)?C_u_i_car(t2):t2);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7752,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t2))){
t7=C_u_i_cdr(t2);
t8=((C_word*)t0)[2];
t9=C_u_i_cdr(t8);
t10=C_a_i_cons(&a,2,t7,t9);
t11=t6;
f_7752(t11,C_a_i_cons(&a,2,lf[99],t10));}
else{
t7=t6;
f_7752(t7,C_i_cadr(((C_word*)t0)[2]));}}

/* k7679 in fold in k7642 in a7639 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in ... */
static void C_ccall f_7681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7681,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,4,lf[157],((C_word*)t0)[3],t1,C_SCHEME_FALSE));}

/* k7694 in fold in k7642 in a7639 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in ... */
static void C_ccall f_7696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7696,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,4,lf[157],((C_word*)t0)[3],t1,C_SCHEME_FALSE));}

/* k7697 in fold in k7642 in a7639 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in ... */
static void C_ccall f_7699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7699,2,t0,t1);}
t2=C_u_i_car(((C_word*)t0)[2]);
t3=C_i_cadr(((C_word*)t0)[2]);
t4=C_a_i_list(&a,2,t2,t3);
t5=C_a_i_list(&a,1,t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7715,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:498: fold */
t8=((C_word*)((C_word*)t0)[4])[1];
f_7654(t8,t7,((C_word*)t0)[5]);}

/* k4491 in a4463 in k4444 in k4435 in a4432 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in ... */
static void C_fcall f_4493(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4493,NULL,2,t0,t1);}
if(C_truep(((C_word*)t0)[2])){
t2=C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t3=C_a_i_list(&a,2,lf[65],t2);
t4=C_a_i_list(&a,1,t3);
/* chicken-syntax.scm:43: ##sys#append */
t5=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[4],t1,t4);}
else{
/* chicken-syntax.scm:43: ##sys#append */
t2=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],t1,C_SCHEME_END_OF_LIST);}}

/* k10820 in k10694 in k10691 in mapslots in k10839 in k10865 in k10650 in k10589 in k10586 in k10583 in k10580 in k10572 in a10569 in k3393 in k3390 in k3386 */
static void C_ccall f_10822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:94: string->symbol */
t2=*((C_word*)lf[179]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k10824 in k10691 in mapslots in k10839 in k10865 in k10650 in k10589 in k10586 in k10583 in k10580 in k10572 in a10569 in k3393 in k3390 in k3386 */
static void C_ccall f_10826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:93: string->symbol */
t2=*((C_word*)lf[179]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7501 in k7490 in k7487 in k7484 in k7476 in a7473 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in ... */
static void C_ccall f_7503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7503,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,3,lf[30],((C_word*)t0)[3],t1));}

/* expand in k7490 in k7487 in k7484 in k7476 in a7473 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in ... */
static void C_fcall f_7505(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7505,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[191]);}
else{
if(C_truep(C_i_pairp(t2))){
t4=C_slot(t2,C_fix(0));
t5=t4;
t6=C_slot(t2,C_fix(1));
t7=t6;
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7530,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t7,a[6]=t3,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm:520: ##sys#check-syntax */
t9=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[190],t5,lf[196]);}
else{
/* chicken-syntax.scm:516: syntax-error */
t4=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[190],lf[197],t2);}}}

/* map-loop1418 in k7218 in k7215 in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in ... */
static void C_fcall f_7419(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7419,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* map-loop25 in k10589 in k10586 in k10583 in k10580 in k10572 in a10569 in k3393 in k3390 in k3386 */
static void C_fcall f_10891(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10891,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10920,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:66: g31 */
t5=((C_word*)t0)[5];
f_10592(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7411 in map-loop1448 in k7224 in k7218 in k7215 in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in ... */
static void C_ccall f_7413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7413,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7384(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7384(t6,((C_word*)t0)[5],t5);}}

/* k10723 in k10697 in k10694 in k10691 in mapslots in k10839 in k10865 in k10650 in k10589 in k10586 in k10583 in k10580 in k10572 in a10569 in k3393 in k3390 in k3386 */
static void C_ccall f_10725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10725,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[26],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10713,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* chicken-syntax.scm:118: mapslots */
t7=((C_word*)((C_word*)t0)[5])[1];
f_10677(t7,t4,t5,t6);}

/* k10727 in k10697 in k10694 in k10691 in mapslots in k10839 in k10865 in k10650 in k10589 in k10586 in k10583 in k10580 in k10572 in a10569 in k3393 in k3390 in k3386 */
static void C_fcall f_10729(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[66],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10729,NULL,2,t0,t1);}
if(C_truep(((C_word*)t0)[2])){
t2=C_a_i_list(&a,1,lf[125]);
t3=C_a_i_list(&a,2,lf[114],((C_word*)t0)[3]);
t4=C_a_i_list(&a,3,lf[118],lf[125],t3);
t5=C_a_i_list(&a,2,lf[119],t4);
t6=C_a_i_list(&a,3,lf[120],lf[125],((C_word*)t0)[4]);
t7=C_a_i_list(&a,4,lf[99],t2,t5,t6);
t8=C_a_i_list(&a,3,((C_word*)t0)[5],t7,((C_word*)t0)[6]);
t9=C_a_i_list(&a,3,((C_word*)t0)[7],((C_word*)t0)[8],t8);
t10=C_a_i_list(&a,1,t9);
/* chicken-syntax.scm:43: ##sys#append */
t11=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,((C_word*)t0)[9],t1,t10);}
else{
t2=C_a_i_list(&a,1,lf[125]);
t3=C_a_i_list(&a,2,lf[114],((C_word*)t0)[3]);
t4=C_a_i_list(&a,3,lf[118],lf[125],t3);
t5=C_a_i_list(&a,2,lf[119],t4);
t6=C_a_i_list(&a,3,lf[120],lf[125],((C_word*)t0)[4]);
t7=C_a_i_list(&a,4,lf[99],t2,t5,t6);
t8=C_a_i_list(&a,3,((C_word*)t0)[7],((C_word*)t0)[8],t7);
t9=C_a_i_list(&a,1,t8);
/* chicken-syntax.scm:43: ##sys#append */
t10=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,((C_word*)t0)[9],t1,t9);}}

/* k9192 in k9119 in k9105 in k9095 in k9083 in k9068 in k9065 in k9059 in k9056 in k9048 in a9030 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in ... */
static void C_ccall f_9194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9194,2,t0,t1);}
t2=C_a_i_list(&a,3,lf[212],((C_word*)t0)[2],C_SCHEME_TRUE);
t3=C_a_i_list(&a,1,t2);
/* chicken-syntax.scm:280: ##sys#append */
t4=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],t1,t3);}

/* k8623 in loop in k8384 in k8365 in k8362 in k8283 in a8280 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in ... */
static void C_ccall f_8625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8625,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
/* chicken-syntax.scm:394: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_8594(t5,((C_word*)t0)[5],t4,t2);}

/* k6347 in k6761 in k6765 in k6769 in k6773 in k6777 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in ... */
static void C_ccall f_6349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:762: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[156],((C_word*)t0)[3],t1);}

/* k10839 in k10865 in k10650 in k10589 in k10586 in k10583 in k10580 in k10572 in a10569 in k3393 in k3390 in k3386 */
static void C_ccall f_10841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10841,2,t0,t1);}
t2=C_a_i_list(&a,1,lf[125]);
t3=C_a_i_list(&a,2,lf[20],((C_word*)t0)[2]);
t4=C_a_i_list(&a,3,lf[117],lf[125],t3);
t5=C_a_i_list(&a,3,lf[99],t2,t4);
t6=C_a_i_list(&a,3,((C_word*)t0)[3],t1,t5);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10675,a[2]=t7,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10677,a[2]=((C_word*)t0)[2],a[3]=t10,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word)li147),tmp=(C_word)a,a+=8,tmp));
t12=((C_word*)t10)[1];
f_10677(t12,t8,((C_word*)t0)[8],C_fix(1));}

/* k8898 in map-loop810 in k8856 in k8815 in a8812 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_8900(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[6])[1];
f_8887(t5,((C_word*)t0)[7],t3,t4);}

/* k6294 in k6280 in a6277 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in ... */
static void C_ccall f_6296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6296,2,t0,t1);}
t2=C_slot(((C_word*)t0)[2],C_fix(0));
t3=C_a_i_list(&a,2,lf[20],t2);
t4=C_slot(((C_word*)t0)[2],C_fix(1));
t5=C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=C_a_i_cons(&a,2,lf[99],t5);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_list(&a,3,lf[147],t3,t6));}

/* k10865 in k10650 in k10589 in k10586 in k10583 in k10580 in k10572 in a10569 in k3393 in k3390 in k3386 */
static void C_ccall f_10867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10867,2,t0,t1);}
t2=C_a_i_list(&a,2,lf[114],((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
t4=C_a_i_cons(&a,2,lf[116],t3);
t5=C_a_i_list(&a,3,lf[99],((C_word*)t0)[3],t4);
t6=C_a_i_list(&a,3,((C_word*)t0)[4],t1,t5);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10841,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10861,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* ##sys#string-append */
t10=*((C_word*)lf[282]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,((C_word*)t0)[7],lf[283]);}

/* k10859 in k10865 in k10650 in k10589 in k10586 in k10583 in k10580 in k10572 in a10569 in k3393 in k3390 in k3386 */
static void C_ccall f_10861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:85: string->symbol */
t2=*((C_word*)lf[179]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* build in a6479 in k6462 in k6452 in a6449 in a6439 in k6424 in k6417 in k6414 in k6411 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6353 in a6350 in k6761 in k6765 in k6769 in ... */
static void C_fcall f_6554(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6554,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
if(C_truep(((C_word*)t0)[2])){
t4=C_a_i_list(&a,2,((C_word*)t0)[2],t3);
t5=C_a_i_list(&a,1,t4);
t6=C_i_cdr(((C_word*)t0)[3]);
t7=C_a_i_cons(&a,2,t5,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_cons(&a,2,lf[30],t7));}
else{
t4=C_i_cddr(((C_word*)t0)[3]);
if(C_truep(C_i_nullp(t4))){
t5=((C_word*)t0)[3];
t6=C_u_i_cdr(t5);
t7=C_u_i_car(t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t5=((C_word*)t0)[3];
t6=C_u_i_cdr(t5);
t7=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_cons(&a,2,lf[30],t7));}}}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6607,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6655,a[2]=((C_word*)t0)[7],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:815: gensym */
t6=*((C_word*)lf[32]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k10650 in k10589 in k10586 in k10583 in k10580 in k10572 in a10569 in k3393 in k3390 in k3386 */
static void C_ccall f_10652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10652,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10867,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10887,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#string-append */
t5=*((C_word*)lf[282]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[284],((C_word*)t0)[6]);}

/* k6396 in k6393 in k6390 in k6353 in a6350 in k6761 in k6765 in k6769 in k6773 in k6777 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in ... */
static void C_ccall f_6398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6398,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6401,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:784: r */
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[166]);}

/* a4463 in k4444 in k4435 in a4432 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in ... */
static void C_ccall f_4464(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[30],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4464,5,t0,t1,t2,t3,t4);}
t5=t3;
if(C_truep(t2)){
t6=C_i_cdddr(((C_word*)t0)[2]);
t7=C_a_i_cons(&a,2,((C_word*)t0)[3],t6);
t8=C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=C_a_i_list(&a,2,lf[64],t8);
t10=t9;
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4489,a[2]=t10,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4493,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t13=C_a_i_list(&a,2,lf[66],((C_word*)t0)[4]);
t14=t12;
f_4493(t14,C_a_i_list(&a,1,t13));}
else{
t13=t12;
f_4493(t13,C_SCHEME_END_OF_LIST);}}
else{
/* chicken-syntax.scm:1188: syntax-error */
t6=*((C_word*)lf[45]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,lf[62],lf[67],((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* k4460 in a4453 in k4444 in k4435 in a4432 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in ... */
static void C_ccall f_4462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1186: ##compiler#validate-type */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k10885 in k10650 in k10589 in k10586 in k10583 in k10580 in k10572 in a10569 in k3393 in k3390 in k3386 */
static void C_ccall f_10887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:80: string->symbol */
t2=*((C_word*)lf[179]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6393 in k6390 in k6353 in a6350 in k6761 in k6765 in k6769 in k6773 in k6777 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in ... */
static void C_ccall f_6395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6395,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6398,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:783: genvars */
t4=((C_word*)t0)[5];
f_6357(t4,t3,t2);}

/* k6390 in k6353 in a6350 in k6761 in k6765 in k6769 in k6773 in k6777 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in ... */
static void C_ccall f_6392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6395,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_i_cdr(((C_word*)t0)[4]);
t8=C_i_check_list_2(t7,lf[28]);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6704,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6706,a[2]=t6,a[3]=t11,a[4]=t4,a[5]=((C_word)li55),tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_6706(t13,t9,t7);}

/* k6387 in loop in genvars in k6353 in a6350 in k6761 in k6765 in k6769 in k6773 in k6777 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in ... */
static void C_ccall f_6389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:776: r */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* k10501 in k10479 in a10476 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_10503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10503,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=C_i_caddr(((C_word*)t0)[2]);
t5=t4;
t6=((C_word*)t0)[2];
t7=C_u_i_cdr(t6);
t8=C_u_i_cdr(t7);
t9=C_u_i_cdr(t8);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10518,a[2]=t3,a[3]=t5,a[4]=t9,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t3))){
t11=C_u_i_cdr(t3);
t12=t10;
f_10518(t12,C_i_nullp(t11));}
else{
t11=t10;
f_10518(t11,C_SCHEME_FALSE);}}

/* k6379 in k6375 in loop in genvars in k6353 in a6350 in k6761 in k6765 in k6769 in k6773 in k6777 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in ... */
static void C_ccall f_6381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6381,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k6375 in loop in genvars in k6353 in a6350 in k6761 in k6765 in k6769 in k6773 in k6777 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in ... */
static void C_ccall f_6377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6377,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6381,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* chicken-syntax.scm:776: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_6363(t5,t3,t4);}

/* k6280 in a6277 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in ... */
static void C_ccall f_6282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6282,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
if(C_truep(C_i_pairp(t3))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6296,a[2]=t3,a[3]=t6,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t8=C_a_i_cons(&a,2,t3,t6);
/* chicken-syntax.scm:839: ##sys#check-syntax */
t9=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t7,lf[146],t8,lf[148]);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6326,a[2]=t3,a[3]=t6,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t8=C_a_i_cons(&a,2,t3,t6);
/* chicken-syntax.scm:846: ##sys#check-syntax */
t9=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t7,lf[146],t8,lf[149]);}}

/* k10589 in k10586 in k10583 in k10580 in k10572 in a10569 in k3393 in k3390 in k3386 */
static void C_ccall f_10591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10591,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10592,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li146),tmp=(C_word)a,a+=5,tmp);
t8=C_i_check_list_2(((C_word*)t0)[4],lf[28]);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10652,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t2,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10891,a[2]=t6,a[3]=t11,a[4]=t4,a[5]=t7,a[6]=((C_word)li148),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_10891(t13,t9,((C_word*)t0)[4]);}

/* g31 in k10589 in k10586 in k10583 in k10580 in k10572 in a10569 in k3393 in k3390 in k3386 */
static void C_fcall f_10592(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10592,NULL,3,t0,t1,t2);}
if(C_truep(C_i_symbolp(t2))){
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10620,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=C_u_i_car(t4);
/* chicken-syntax.scm:69: c */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t5,((C_word*)t0)[3]);}
else{
/* chicken-syntax.scm:75: syntax-error */
t3=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,lf[276],lf[277],t2);}}}

/* k6270 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in ... */
static void C_ccall f_6272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6272,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[138],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6268,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:855: ##sys#primitive-alias */
t5=*((C_word*)lf[108]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[139]);}

/* k3942 in map-loop2384 in k3956 in k3775 in k3772 in loop in k3754 in k3751 in k3748 in k3745 in k3741 in k3732 in a3723 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in ... */
static void C_ccall f_3944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3944,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3915(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3915(t6,((C_word*)t0)[5],t5);}}

/* k9833 in k9820 in k9644 in k9637 in k9625 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9835,2,t0,t1);}
t2=C_a_i_list(&a,1,lf[227]);
t3=C_a_i_list(&a,1,t2);
/* chicken-syntax.scm:214: ##sys#append */
t4=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k6274 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in ... */
static void C_ccall f_6276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:831: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[146],C_SCHEME_END_OF_LIST,t1);}

/* a6277 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in ... */
static void C_ccall f_6278(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6278,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6282,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:835: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[146],t2,lf[150]);}

/* k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_3413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3413,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3416,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10231,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10233,a[2]=((C_word)li140),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:191: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_3410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3413,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10306,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10308,a[2]=((C_word)li141),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:168: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k9820 in k9644 in k9637 in k9625 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9822,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9826,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9835,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9845,a[2]=t7,a[3]=t10,a[4]=t5,a[5]=((C_word)li130),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_9845(t12,t8,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k3956 in k3775 in k3772 in loop in k3754 in k3751 in k3748 in k3745 in k3741 in k3732 in a3723 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in ... */
static void C_ccall f_3958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3958,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3783,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3876,a[2]=t4,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3895,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t7=(C_truep(((C_word*)t0)[10])?C_i_pairp(((C_word*)t0)[10]):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_i_check_list_2(((C_word*)t0)[10],lf[28]);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3913,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3915,a[2]=t11,a[3]=t15,a[4]=t9,a[5]=((C_word)li5),tmp=(C_word)a,a+=6,tmp));
t17=((C_word*)t15)[1];
f_3915(t17,t13,((C_word*)t0)[10]);}
else{
t8=t6;
f_3895(t8,C_a_i_list1(&a,1,t3));}}

/* k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_3425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3425,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3428,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9005,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9007,a[2]=((C_word)li112),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:309: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_3428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3431,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8977,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8979,a[2]=((C_word)li111),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:317: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k9824 in k9820 in k9644 in k9637 in k9625 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:214: ##sys#append */
t2=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k9808 in k9644 in k9637 in k9625 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9810,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=C_a_i_cons(&a,2,lf[99],t2);
t4=t3;
t5=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
t6=C_a_i_cons(&a,2,lf[99],t5);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9670,a[2]=t4,a[3]=t7,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t9=C_SCHEME_END_OF_LIST;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9679,a[2]=t8,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9751,a[2]=t12,a[3]=t15,a[4]=t10,a[5]=((C_word)li129),tmp=(C_word)a,a+=6,tmp));
t17=((C_word*)t15)[1];
f_9751(t17,t13,((C_word*)t0)[7],((C_word*)t0)[5]);}

/* k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_3416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3419,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9598,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9600,a[2]=((C_word)li139),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:211: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_3419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3422,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9497,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9499,a[2]=((C_word)li125),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:243: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k9905 in map-loop348 in k9644 in k9637 in k9625 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_9907(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[6])[1];
f_9894(t5,((C_word*)t0)[7],t3,t4);}

/* k7276 in k7273 in k7261 in k7258 in k7255 in k7252 in k7224 in k7218 in k7215 in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in ... */
static void C_ccall f_7278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7278,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7281,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm:681: make-if-tree */
t4=((C_word*)t0)[9];
f_7128(t4,t3,((C_word*)t0)[10],((C_word*)t0)[11],((C_word*)t0)[6],((C_word*)t0)[2]);}

/* k3911 in k3956 in k3775 in k3772 in loop in k3754 in k3751 in k3748 in k3745 in k3741 in k3732 in a3723 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in ... */
static void C_ccall f_3913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3913,2,t0,t1);}
t2=((C_word*)t0)[2];
f_3895(t2,C_a_i_list2(&a,2,t1,((C_word*)t0)[3]));}

/* map-loop2384 in k3956 in k3775 in k3772 in loop in k3754 in k3751 in k3748 in k3745 in k3741 in k3732 in a3723 in k3520 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in ... */
static void C_fcall f_3915(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3915,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3944,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=*((C_word*)lf[18]+1);
/* chicken-syntax.scm:1245: g2407 */
t6=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,lf[34]);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6266 in k6270 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in ... */
static void C_ccall f_6268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6268,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[139],t1);
t3=C_a_i_list(&a,2,((C_word*)t0)[2],t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6157,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6159,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:856: ##sys#er-transformer */
t7=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k7270 in g1511 in k7261 in k7258 in k7255 in k7252 in k7224 in k7218 in k7215 in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in ... */
static void C_ccall f_7272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:676: r */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* k7273 in k7261 in k7258 in k7255 in k7252 in k7224 in k7218 in k7215 in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in ... */
static void C_ccall f_7275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7275,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7278,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t2,tmp=(C_word)a,a+=12,tmp);
t4=t3;
t5=((C_word*)t0)[6];
t6=t2;
t7=((C_word*)t0)[11];
t8=*((C_word*)lf[32]+1);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7057,a[2]=t4,a[3]=t5,a[4]=t7,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:628: reverse */
t10=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,((C_word*)t0)[10]);}

/* k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_3401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3404,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10426,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10428,a[2]=((C_word)li144),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:141: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k7286 in k7279 in k7276 in k7273 in k7261 in k7258 in k7255 in k7252 in k7224 in k7218 in k7215 in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in ... */
static void C_ccall f_7288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7288,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[5]);
t4=C_a_i_cons(&a,2,lf[99],t3);
t5=C_a_i_list(&a,2,((C_word*)t0)[6],t4);
t6=C_a_i_cons(&a,2,t5,((C_word*)t0)[7]);
t7=C_a_i_cons(&a,2,t2,t6);
t8=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_list(&a,3,t1,t7,((C_word*)t0)[9]));}

/* k7279 in k7276 in k7273 in k7261 in k7258 in k7255 in k7252 in k7224 in k7218 in k7215 in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in ... */
static void C_ccall f_7281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7281,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7288,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm:684: r */
t4=((C_word*)t0)[9];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[184]);}

/* mapslots in k10839 in k10865 in k10650 in k10589 in k10586 in k10583 in k10580 in k10572 in a10569 in k3393 in k3390 in k3386 */
static void C_fcall f_10677(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10677,NULL,4,t0,t1,t2,t3);}
t4=C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t2;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=C_i_car(t2);
t6=C_i_symbolp(t5);
t7=C_i_not(t6);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10693,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=t8,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t8)){
t10=C_i_cadr(t5);
/* chicken-syntax.scm:92: symbol->string */
t11=*((C_word*)lf[181]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t9,t10);}
else{
/* chicken-syntax.scm:92: symbol->string */
t10=*((C_word*)lf[181]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t5);}}}

/* k10673 in k10839 in k10865 in k10650 in k10589 in k10586 in k10583 in k10580 in k10572 in a10569 in k3393 in k3390 in k3386 */
static void C_ccall f_10675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10675,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[26],t3));}

/* k4669 in k4666 in k4663 in k4660 in a4657 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in ... */
static void C_ccall f_4671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4671,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=t2;
t4=C_a_i_list(&a,2,((C_word*)t0)[2],lf[80]);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4694,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t7=C_i_caddr(((C_word*)t0)[5]);
/* chicken-syntax.scm:1134: ##sys#strip-syntax */
t8=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}

/* k9516 in k9513 in k9510 in k9501 in a9498 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9518,2,t0,t1);}
t2=t1;
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9521,a[2]=t6,a[3]=t8,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9550,a[2]=t11,a[3]=t4,a[4]=t8,a[5]=t6,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t2,a[9]=((C_word*)t0)[6],a[10]=((C_word)li124),tmp=(C_word)a,a+=11,tmp));
t13=((C_word*)t11)[1];
f_9550(t13,t9,((C_word*)t0)[7]);}

/* k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_3404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3407,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10412,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10414,a[2]=((C_word)li143),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:155: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_3407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3410,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10395,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10397,a[2]=((C_word)li142),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:161: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k4663 in k4660 in a4657 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in ... */
static void C_ccall f_4665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4665,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4668,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1125: r */
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[20]);}

/* k4660 in a4657 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in ... */
static void C_ccall f_4662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4662,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4665,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
/* chicken-syntax.scm:1124: ##sys#strip-syntax */
t4=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* k4666 in k4663 in k4660 in a4657 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in ... */
static void C_ccall f_4668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4668,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4671,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=C_eqp(lf[44],((C_word*)t0)[2]);
if(C_truep(t4)){
/* chicken-syntax.scm:1127: syntax-error-hook */
t5=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[79],lf[84]);}
else{
t5=t3;
f_4671(2,t5,C_SCHEME_UNDEFINED);}}

/* k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_3422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3422,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3425,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9029,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9031,a[2]=((C_word)li123),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:273: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k10618 in g31 in k10589 in k10586 in k10583 in k10580 in k10572 in a10569 in k3393 in k3390 in k3386 */
static void C_ccall f_10620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
if(C_truep(C_i_pairp(t3))){
t4=C_i_cadr(((C_word*)t0)[2]);
if(C_truep(C_i_symbolp(t4))){
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
t7=C_u_i_cdr(t6);
if(C_truep(C_i_nullp(t7))){
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_i_cadr(((C_word*)t0)[2]));}
else{
/* chicken-syntax.scm:75: syntax-error */
t8=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,((C_word*)t0)[3],lf[276],lf[277],((C_word*)t0)[2]);}}
else{
/* chicken-syntax.scm:75: syntax-error */
t5=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[3],lf[276],lf[277],((C_word*)t0)[2]);}}
else{
/* chicken-syntax.scm:75: syntax-error */
t4=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],lf[276],lf[277],((C_word*)t0)[2]);}}
else{
/* chicken-syntax.scm:75: syntax-error */
t2=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[276],lf[277],((C_word*)t0)[2]);}}

/* k9510 in k9501 in a9498 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9512,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9515,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:249: r */
t4=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[248]);}

/* k9513 in k9510 in k9501 in a9498 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9515,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9518,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:250: r */
t4=((C_word*)t0)[7];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[247]);}

/* k7258 in k7255 in k7252 in k7224 in k7218 in k7215 in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in ... */
static void C_ccall f_7260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7260,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7263,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm:674: r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[185]);}

/* k4692 in k4669 in k4666 in k4663 in k4660 in a4657 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in ... */
static void C_ccall f_4694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4694,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4697,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_eqp(lf[44],t1);
if(C_truep(t3)){
t4=C_a_i_list(&a,2,((C_word*)t0)[2],lf[44]);
t5=C_a_i_list(&a,4,lf[16],((C_word*)t0)[3],((C_word*)t0)[4],t4);
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_list(&a,2,lf[17],t5));}
else{
if(C_truep(C_i_symbolp(t1))){
t4=C_a_i_list(&a,2,lf[81],t1);
t5=C_a_i_list(&a,2,((C_word*)t0)[2],t4);
t6=C_a_i_list(&a,4,lf[16],((C_word*)t0)[3],((C_word*)t0)[4],t5);
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_list(&a,2,lf[17],t6));}
else{
if(C_truep(C_i_listp(t1))){
/* chicken-syntax.scm:1138: ##sys#validate-exports */
t4=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t1,lf[79]);}
else{
t4=C_i_caddr(((C_word*)t0)[6]);
/* chicken-syntax.scm:1140: syntax-error-hook */
t5=*((C_word*)lf[82]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,lf[79],lf[83],t4);}}}}

/* k7261 in k7258 in k7255 in k7252 in k7224 in k7218 in k7215 in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in ... */
static void C_ccall f_7263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7263,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7264,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li64),tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7275,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[2],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7314,a[2]=t6,a[3]=t10,a[4]=t4,a[5]=t7,a[6]=((C_word)li66),tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_7314(t12,t8,((C_word*)t0)[5]);}

/* k4695 in k4692 in k4669 in k4666 in k4663 in k4660 in a4657 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in ... */
static void C_ccall f_4697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4697,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_list(&a,4,lf[16],((C_word*)t0)[3],((C_word*)t0)[4],t2);
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,2,lf[17],t3));}

/* g1511 in k7261 in k7258 in k7255 in k7252 in k7224 in k7218 in k7215 in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in ... */
static void C_fcall f_7264(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7264,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7272,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:676: prefix-sym */
f_7227(t3,lf[183],t2);}

/* k9501 in a9498 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9503,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
t7=C_a_i_cons(&a,2,lf[26],t6);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9512,a[2]=((C_word*)t0)[3],a[3]=t8,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:248: r */
t10=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,lf[249]);}

/* loop in genvars in k6353 in a6350 in k6761 in k6765 in k6769 in k6773 in k6777 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in ... */
static void C_fcall f_6363(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6363,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6377,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6389,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:776: gensym */
t5=*((C_word*)lf[32]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* genvars in k6353 in a6350 in k6761 in k6765 in k6769 in k6773 in k6777 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in ... */
static void C_fcall f_6357(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6357,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6363,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word)li46),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_6363(t6,t1,C_fix(0));}

/* k6353 in a6350 in k6761 in k6765 in k6769 in k6773 in k6777 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in ... */
static void C_ccall f_6355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6355,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6357,a[2]=((C_word*)t0)[2],a[3]=((C_word)li47),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6392,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:777: require */
t4=*((C_word*)lf[168]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[169]);}

/* a6350 in k6761 in k6765 in k6769 in k6773 in k6777 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in ... */
static void C_ccall f_6351(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6351,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6355,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:771: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[156],t2,lf[170]);}

/* k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in ... */
static void C_ccall f_3495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3495,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3498,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5009,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5011,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1087: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in ... */
static void C_ccall f_3492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3492,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3495,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5026,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5028,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1076: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in ... */
static void C_ccall f_3498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3498,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3501,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4988,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4990,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1094: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* map-loop1157 in k7943 in k7918 in k7899 in k7891 in a7888 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in ... */
static void C_fcall f_8071(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8071,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8100,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:440: g1163 */
t5=((C_word*)t0)[5];
f_7951(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8184 in k7891 in a7888 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 in ... */
static void C_ccall f_8186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[41]+1),t1);}

/* map-loop1070 in k7891 in a7888 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 in ... */
static void C_fcall f_8188(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8188,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9519 in k9516 in k9513 in k9510 in k9501 in a9498 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9521,2,t0,t1);}
if(C_truep(C_i_memq(lf[13],*((C_word*)lf[14]+1)))){
t2=(C_truep(((C_word*)((C_word*)t0)[2])[1])?((C_word*)((C_word*)t0)[3])[1]:C_SCHEME_FALSE);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_a_i_list(&a,2,lf[241],((C_word*)t0)[5]):(C_truep(((C_word*)((C_word*)t0)[2])[1])?C_a_i_list(&a,2,lf[242],((C_word*)t0)[5]):(C_truep(((C_word*)((C_word*)t0)[3])[1])?((C_word*)t0)[5]:lf[243]))));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)((C_word*)t0)[6])[1])?((C_word*)t0)[5]:lf[244]));}}

/* k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_3447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3447,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3450,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7883,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:450: ##sys#primitive-alias */
t4=*((C_word*)lf[108]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[208]);}

/* k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_3441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3444,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8225,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8227,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:415: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_3444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3444,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3447,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7887,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7889,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:430: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k8168 in map-loop1098 in k7899 in k7891 in a7888 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in ... */
static void C_ccall f_8170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8170,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8141(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8141(t6,((C_word*)t0)[5],t5);}}

/* k8067 in k7943 in k7918 in k7899 in k7891 in a7888 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in ... */
static void C_ccall f_8069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:433: ##sys#append */
t2=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_3438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3438,2,t0,t1);}
t2=C_mutate2((C_word*)lf[0]+1 /* (set! ##sys#define-values-definition ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3441,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8279,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8281,a[2]=((C_word)li105),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:361: ##sys#er-transformer */
t6=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_3431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3431,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3434,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8811,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8813,a[2]=((C_word)li110),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:326: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_3434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3434,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3438,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8748,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8750,a[2]=((C_word)li107),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:350: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* map-loop781 in k8815 in a8812 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_8936(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8936,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8965,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:339: g787 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in ... */
static void C_ccall f_3480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3483,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5868,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:914: ##sys#primitive-alias */
t4=*((C_word*)lf[108]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[112]);}

/* k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in ... */
static void C_ccall f_3471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3474,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6276,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6278,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:833: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k7112 in k7104 in recur in k7063 in k7059 in k7055 in k7273 in k7261 in k7258 in k7255 in k7252 in k7224 in k7218 in k7215 in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in ... */
static void C_ccall f_7114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7114,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_list(&a,3,lf[99],((C_word*)t0)[3],t2);
t4=C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7088,a[2]=((C_word*)t0)[5],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=((C_word*)t0)[6];
t8=C_u_i_cdr(t7);
t9=((C_word*)t0)[7];
t10=C_u_i_cdr(t9);
t11=((C_word*)t0)[6];
t12=C_u_i_car(t11);
/* chicken-syntax.scm:637: recur */
t13=((C_word*)((C_word*)t0)[8])[1];
f_7067(t13,t6,((C_word*)t0)[9],t8,t10,t12);}

/* k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in ... */
static void C_ccall f_3483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3483,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3486,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5491,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:987: ##sys#primitive-alias */
t4=*((C_word*)lf[108]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[102]);}

/* k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in ... */
static void C_ccall f_3486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3489,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5311,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1019: ##sys#primitive-alias */
t4=*((C_word*)lf[108]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[102]);}

/* k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in ... */
static void C_ccall f_3489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3492,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5055,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5057,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1060: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k7116 in k7104 in recur in k7063 in k7059 in k7055 in k7273 in k7261 in k7258 in k7255 in k7252 in k7224 in k7218 in k7215 in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in ... */
static void C_ccall f_7118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7118,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
/* chicken-syntax.scm:633: ##sys#append */
t4=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],t1,t3);}

/* k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in ... */
static void C_ccall f_3474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3477,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6272,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:854: ##sys#primitive-alias */
t4=*((C_word*)lf[108]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[138]);}

/* k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in ... */
static void C_ccall f_3477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3480,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6149,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:876: ##sys#primitive-alias */
t4=*((C_word*)lf[108]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[27]);}

/* k8229 in a8226 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_8231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8231,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8239,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:420: r */
t8=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,lf[216]);}

/* recur in make-if-tree in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in ... */
static void C_fcall f_7134(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7134,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7148,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:648: reverse */
t6=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}
else{
t5=C_i_car(t2);
t6=t5;
t7=C_a_i_list(&a,2,lf[171],((C_word*)t0)[3]);
t8=t7;
t9=C_i_car(t3);
t10=t9;
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7214,a[2]=t10,a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t1,a[6]=t8,a[7]=t2,a[8]=t3,a[9]=t4,a[10]=((C_word*)t0)[4],a[11]=((C_word*)t0)[5],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm:651: reverse */
t12=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t4);}}

/* k4992 in a4989 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in ... */
static void C_ccall f_4994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5001,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1097: r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[91]);}

/* k8237 in k8229 in a8226 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_8239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8239,2,t0,t1);}
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8244,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t4,a[5]=((C_word)li91),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_8244(t6,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* a4989 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in ... */
static void C_ccall f_4990(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4990,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4994,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1096: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[90],t2,lf[92]);}

/* k8223 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_8225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:413: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[215],C_SCHEME_END_OF_LIST,t1);}

/* a8226 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_8227(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8227,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8231,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:417: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[215],t2,lf[217]);}

/* k4986 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in ... */
static void C_ccall f_4988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1092: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[90],C_SCHEME_END_OF_LIST,t1);}

/* k7104 in recur in k7063 in k7059 in k7055 in k7273 in k7261 in k7258 in k7255 in k7252 in k7224 in k7218 in k7215 in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in ... */
static void C_ccall f_7106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7106,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7114,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7118,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:636: reverse */
t5=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[8]);}

/* fold in k8237 in k8229 in a8226 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 in ... */
static void C_fcall f_8244(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8244,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[30],t3));}
else{
t3=C_i_car(t2);
t4=C_a_i_list(&a,1,t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8269,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=t2;
t8=C_u_i_cdr(t7);
/* chicken-syntax.scm:425: fold */
t11=t6;
t12=t8;
t1=t11;
t2=t12;
goto loop;}}

/* k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_3450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3453,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7735,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7737,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:461: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* make-if-tree in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in ... */
static void C_fcall f_7128(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7128,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7134,a[2]=t4,a[3]=t5,a[4]=t7,a[5]=((C_word*)t0)[2],a[6]=((C_word)li60),tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_7134(t9,t1,t2,t3,C_SCHEME_END_OF_LIST);}

/* k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in ... */
static void C_ccall f_3468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3468,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3471,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6779,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:764: ##sys#primitive-alias */
t4=*((C_word*)lf[108]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[151]);}

/* k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in ... */
static void C_ccall f_3465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3468,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6935,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:731: ##sys#primitive-alias */
t4=*((C_word*)lf[108]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[171]);}

/* k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in ... */
static void C_ccall f_3462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3462,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3465,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7024,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:703: ##sys#primitive-alias */
t4=*((C_word*)lf[108]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[171]);}

/* k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in ... */
static void C_ccall f_3459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3459,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3462,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7468,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:615: ##sys#primitive-alias */
t4=*((C_word*)lf[108]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[152]);}

/* k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in ... */
static void C_ccall f_3456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3456,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3459,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7472,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7474,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:502: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 in ... */
static void C_ccall f_3453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3453,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3456,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7638,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7640,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:482: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k7146 in recur in make-if-tree in k7036 in a7033 in k7462 in k7466 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in ... */
static void C_ccall f_7148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7148,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* fold in k8408 in k8396 in k8384 in k8365 in k8362 in k8283 in a8280 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in ... */
static void C_fcall f_8412(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8412,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_nullp(t2))){
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8428,a[2]=((C_word*)t0)[2],a[3]=((C_word)li97),tmp=(C_word)a,a+=4,tmp);
t10=C_i_check_list_2(((C_word*)t0)[3],lf[28]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8442,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8444,a[2]=t8,a[3]=t13,a[4]=t6,a[5]=t9,a[6]=((C_word)li98),tmp=(C_word)a,a+=7,tmp));
t15=((C_word*)t13)[1];
f_8444(t15,t11,((C_word*)t0)[3]);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8483,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t6=C_i_car(t4);
if(C_truep(C_i_pairp(t6))){
t7=C_i_cdar(t4);
t8=t5;
f_8483(t8,C_i_nullp(t7));}
else{
t7=t5;
f_8483(t7,C_SCHEME_FALSE);}}}

/* k8408 in k8396 in k8384 in k8365 in k8362 in k8283 in a8280 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in ... */
static void C_ccall f_8410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8410,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8412,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word)li99),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_8412(t5,((C_word*)t0)[5],((C_word*)t0)[6],t1,((C_word*)t0)[7]);}

/* map-loop2318 in k4112 in k4098 in a4089 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in ... */
static void C_fcall f_4178(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4178,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cdr(t3);
t5=C_i_car(t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t7=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t6);
t8=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t6);
t9=C_slot(t2,C_fix(1));
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t6);
t8=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t6);
t9=C_slot(t2,C_fix(1));
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g989 in fold in k8408 in k8396 in k8384 in k8365 in k8362 in k8283 in a8280 in k3436 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in ... */
static void C_fcall f_8428(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8428,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8436,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:400: lookup */
t4=((C_word*)t0)[2];
f_8387(3,t4,t3,t2);}

/* loop2089 in k4797 in k4791 in k4788 in k4782 in a4744 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in ... */
static void C_fcall f_4808(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4808,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4815,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:1112: ##sys#= */
t5=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,C_fix(0));}

/* k4140 in k4130 in k4112 in k4098 in a4089 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in ... */
static void C_ccall f_4142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4142,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4150,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4152,a[2]=((C_word*)t0)[4],a[3]=((C_word)li9),tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1208: ##sys#map-n */
t5=*((C_word*)lf[53]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,((C_word*)t0)[5],((C_word*)t0)[6]);}

/* map-loop539 in k9059 in k9056 in k9048 in a9030 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_9460(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9460,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4166 in a4151 in k4140 in k4130 in k4112 in k4098 in a4089 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in ... */
static void C_ccall f_4168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4168,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=C_a_i_cons(&a,2,t1,t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k4827 in k4813 in loop2089 in k4797 in k4791 in k4788 in k4782 in a4744 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in ... */
static void C_ccall f_4829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1112: loop2089 */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4808(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* map-loop420 in k9808 in k9644 in k9637 in k9625 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_9751(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9751,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list(&a,3,lf[212],t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=t9;
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9764,a[2]=((C_word*)t0)[2],a[3]=t10,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t12=t11;
f_9764(t12,C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t10));}
else{
t12=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t10);
t13=t11;
f_9764(t13,t12);}}
else{
t6=((C_word*)((C_word*)t0)[4])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k4813 in loop2089 in k4797 in k4791 in k4788 in k4782 in a4744 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in ... */
static void C_ccall f_4815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4815,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_eqp(((C_word*)t0)[3],C_SCHEME_END_OF_LIST));}
else{
t2=C_i_cdr(((C_word*)t0)[3]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4829,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1112: ##sys#+ */
t5=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[5],C_fix(-1));}}

/* k4841 in k4838 in a4744 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in ... */
static void C_ccall f_4843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4843,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4849,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1112: ##sys#>= */
t4=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,C_fix(0));}

/* k4838 in a4744 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in ... */
static void C_ccall f_4840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4840,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4843,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(((C_word*)t0)[2]);
/* chicken-syntax.scm:1112: ##sys#length */
t4=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[3];
f_4784(2,t2,C_SCHEME_FALSE);}}

/* k4847 in k4841 in k4838 in a4744 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in ... */
static void C_ccall f_4849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4849,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4858,a[2]=t4,a[3]=((C_word)li23),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4858(t6,((C_word*)t0)[3],t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_4784(2,t2,C_SCHEME_FALSE);}}

/* map-loop621 in k9083 in k9068 in k9065 in k9059 in k9056 in k9048 in a9030 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_9355(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9355,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9384,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:287: g627 */
t4=((C_word*)t0)[5];
f_9086(t4,t3);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4753 in a4744 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in ... */
static void C_ccall f_4755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4755,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=C_i_cdr(((C_word*)t0)[2]);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4768,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1112: rename2092 */
t7=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[87]);}
else{
/* chicken-syntax.scm:1112: ##sys#syntax-rules-mismatch */
t2=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[5]);}}

/* k9762 in map-loop420 in k9808 in k9644 in k9637 in k9625 in k9613 in k9602 in a9599 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_9764(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[6])[1];
f_9751(t5,((C_word*)t0)[7],t3,t4);}

/* k9495 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:241: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[240],C_SCHEME_END_OF_LIST,t1);}

/* a9498 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_9499(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9499,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9503,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:245: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[240],t2,lf[250]);}

/* k4741 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in ... */
static void C_ccall f_4743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1110: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[86],C_SCHEME_END_OF_LIST,t1);}

/* a4744 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in k3451 in k3448 in k3445 in k3442 in ... */
static void C_ccall f_4745(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4745,5,t0,t1,t2,t3,t4);}
t5=C_i_cdr(t2);
t6=t5;
t7=t6;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4755,a[2]=t6,a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t7))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4784,a[2]=t7,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4840,a[2]=t7,a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=C_i_car(t7);
/* chicken-syntax.scm:1112: ##sys#list? */
t12=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}
else{
t9=t8;
f_4755(2,t9,C_SCHEME_FALSE);}}

/* loop2089 in k4847 in k4841 in k4838 in a4744 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3454 in ... */
static void C_fcall f_4858(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4858,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4865,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:1112: ##sys#= */
t5=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,C_fix(0));}

/* map-loop593 in k9068 in k9065 in k9059 in k9056 in k9048 in a9030 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_9390(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9390,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9419,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:286: g599 */
t5=((C_word*)t0)[5];
f_9071(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4112 in k4098 in a4089 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in ... */
static void C_ccall f_4114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4114,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_i_car(((C_word*)t0)[2]);
t8=C_i_check_list_2(t7,lf[28]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4132,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4178,a[2]=t6,a[3]=t11,a[4]=t4,a[5]=((C_word)li10),tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_4178(t13,t9,t7);}

/* k4130 in k4112 in k4098 in a4089 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in ... */
static void C_ccall f_4132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4132,2,t0,t1);}
t2=t1;
t3=C_i_cdr(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4142,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:1208: rename2245 */
t6=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[54]);}

/* for-each-loop850 in k8752 in a8749 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_fcall f_8786(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8786,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8796,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8759,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:354: ##sys#get */
t7=*((C_word*)lf[224]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,t4,lf[225],t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8780 in k8773 in k8752 in a8749 in k3432 in k3429 in k3426 in k3423 in k3420 in k3417 in k3414 in k3411 in k3408 in k3405 in k3402 in k3399 in k3396 in k3393 in k3390 in k3386 */
static void C_ccall f_8782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8782,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,t1,t3));}

/* k4098 in a4089 in k3517 in k3514 in k3511 in k3508 in k3505 in k3502 in k3499 in k3496 in k3493 in k3490 in k3487 in k3484 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in ... */
static void C_ccall f_4100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4100,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_i_car(((C_word*)t0)[2]);
t7=C_i_check_list_2(t6,lf[28]);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4114,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4213,a[2]=t5,a[3]=t10,a[4]=t3,a[5]=((C_word)li11),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_4213(t12,t8,t6);}
else{
/* chicken-syntax.scm:1208: ##sys#syntax-rules-mismatch */
t2=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[5]);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[674] = {
{"f_9425:chicken_2dsyntax_2escm",(void*)f_9425},
{"f_8796:chicken_2dsyntax_2escm",(void*)f_8796},
{"f_4150:chicken_2dsyntax_2escm",(void*)f_4150},
{"f_4152:chicken_2dsyntax_2escm",(void*)f_4152},
{"f_9384:chicken_2dsyntax_2escm",(void*)f_9384},
{"f_9419:chicken_2dsyntax_2escm",(void*)f_9419},
{"f_9306:chicken_2dsyntax_2escm",(void*)f_9306},
{"f_6789:chicken_2dsyntax_2escm",(void*)f_6789},
{"f_6787:chicken_2dsyntax_2escm",(void*)f_6787},
{"f_5032:chicken_2dsyntax_2escm",(void*)f_5032},
{"f_5039:chicken_2dsyntax_2escm",(void*)f_5039},
{"f_9702:chicken_2dsyntax_2escm",(void*)f_9702},
{"f_5028:chicken_2dsyntax_2escm",(void*)f_5028},
{"f_5026:chicken_2dsyntax_2escm",(void*)f_5026},
{"f_9715:chicken_2dsyntax_2escm",(void*)f_9715},
{"f_5011:chicken_2dsyntax_2escm",(void*)f_5011},
{"f_6992:chicken_2dsyntax_2escm",(void*)f_6992},
{"f_7557:chicken_2dsyntax_2escm",(void*)f_7557},
{"f_7553:chicken_2dsyntax_2escm",(void*)f_7553},
{"f_5015:chicken_2dsyntax_2escm",(void*)f_5015},
{"f_7550:chicken_2dsyntax_2escm",(void*)f_7550},
{"f_9319:chicken_2dsyntax_2escm",(void*)f_9319},
{"f_5321:chicken_2dsyntax_2escm",(void*)f_5321},
{"f_5325:chicken_2dsyntax_2escm",(void*)f_5325},
{"f_5328:chicken_2dsyntax_2escm",(void*)f_5328},
{"f_6982:chicken_2dsyntax_2escm",(void*)f_6982},
{"f_5221:chicken_2dsyntax_2escm",(void*)f_5221},
{"f_8559:chicken_2dsyntax_2escm",(void*)f_8559},
{"f_5224:chicken_2dsyntax_2escm",(void*)f_5224},
{"f_5311:chicken_2dsyntax_2escm",(void*)f_5311},
{"f_9007:chicken_2dsyntax_2escm",(void*)f_9007},
{"f_5319:chicken_2dsyntax_2escm",(void*)f_5319},
{"f_9005:chicken_2dsyntax_2escm",(void*)f_9005},
{"f_7539:chicken_2dsyntax_2escm",(void*)f_7539},
{"f_7536:chicken_2dsyntax_2escm",(void*)f_7536},
{"f_7530:chicken_2dsyntax_2escm",(void*)f_7530},
{"f_9011:chicken_2dsyntax_2escm",(void*)f_9011},
{"f_4213:chicken_2dsyntax_2escm",(void*)f_4213},
{"f_8531:chicken_2dsyntax_2escm",(void*)f_8531},
{"toplevel:chicken_2dsyntax_2escm",(void*)C_chicken_2dsyntax_toplevel},
{"f_9029:chicken_2dsyntax_2escm",(void*)f_9029},
{"f_10233:chicken_2dsyntax_2escm",(void*)f_10233},
{"f_9031:chicken_2dsyntax_2escm",(void*)f_9031},
{"f_10231:chicken_2dsyntax_2escm",(void*)f_10231},
{"f_8766:chicken_2dsyntax_2escm",(void*)f_8766},
{"f_5047:chicken_2dsyntax_2escm",(void*)f_5047},
{"f_8594:chicken_2dsyntax_2escm",(void*)f_8594},
{"f_8775:chicken_2dsyntax_2escm",(void*)f_8775},
{"f_10237:chicken_2dsyntax_2escm",(void*)f_10237},
{"f_5341:chicken_2dsyntax_2escm",(void*)f_5341},
{"f_9058:chicken_2dsyntax_2escm",(void*)f_9058},
{"f_9050:chicken_2dsyntax_2escm",(void*)f_9050},
{"f_7587:chicken_2dsyntax_2escm",(void*)f_7587},
{"f_7589:chicken_2dsyntax_2escm",(void*)f_7589},
{"f_8748:chicken_2dsyntax_2escm",(void*)f_8748},
{"f_5247:chicken_2dsyntax_2escm",(void*)f_5247},
{"f_5241:chicken_2dsyntax_2escm",(void*)f_5241},
{"f_5331:chicken_2dsyntax_2escm",(void*)f_5331},
{"f_5334:chicken_2dsyntax_2escm",(void*)f_5334},
{"f_8750:chicken_2dsyntax_2escm",(void*)f_8750},
{"f_8754:chicken_2dsyntax_2escm",(void*)f_8754},
{"f_8759:chicken_2dsyntax_2escm",(void*)f_8759},
{"f_10272:chicken_2dsyntax_2escm",(void*)f_10272},
{"f_5001:chicken_2dsyntax_2escm",(void*)f_5001},
{"f_10249:chicken_2dsyntax_2escm",(void*)f_10249},
{"f_5009:chicken_2dsyntax_2escm",(void*)f_5009},
{"f_4273:chicken_2dsyntax_2escm",(void*)f_4273},
{"f_5393:chicken_2dsyntax_2escm",(void*)f_5393},
{"f_6401:chicken_2dsyntax_2escm",(void*)f_6401},
{"f_6407:chicken_2dsyntax_2escm",(void*)f_6407},
{"f_6404:chicken_2dsyntax_2escm",(void*)f_6404},
{"f_5383:chicken_2dsyntax_2escm",(void*)f_5383},
{"f_5061:chicken_2dsyntax_2escm",(void*)f_5061},
{"f_5287:chicken_2dsyntax_2escm",(void*)f_5287},
{"f_5055:chicken_2dsyntax_2escm",(void*)f_5055},
{"f_5057:chicken_2dsyntax_2escm",(void*)f_5057},
{"f_4267:chicken_2dsyntax_2escm",(void*)f_4267},
{"f_4264:chicken_2dsyntax_2escm",(void*)f_4264},
{"f_6426:chicken_2dsyntax_2escm",(void*)f_6426},
{"f_6410:chicken_2dsyntax_2escm",(void*)f_6410},
{"f_6413:chicken_2dsyntax_2escm",(void*)f_6413},
{"f_6416:chicken_2dsyntax_2escm",(void*)f_6416},
{"f_6419:chicken_2dsyntax_2escm",(void*)f_6419},
{"f_7576:chicken_2dsyntax_2escm",(void*)f_7576},
{"f_4289:chicken_2dsyntax_2escm",(void*)f_4289},
{"f_4282:chicken_2dsyntax_2escm",(void*)f_4282},
{"f_7572:chicken_2dsyntax_2escm",(void*)f_7572},
{"f_4258:chicken_2dsyntax_2escm",(void*)f_4258},
{"f_6464:chicken_2dsyntax_2escm",(void*)f_6464},
{"f_10089:chicken_2dsyntax_2escm",(void*)f_10089},
{"f_6468:chicken_2dsyntax_2escm",(void*)f_6468},
{"f_6454:chicken_2dsyntax_2escm",(void*)f_6454},
{"f_6450:chicken_2dsyntax_2escm",(void*)f_6450},
{"f_3706:chicken_2dsyntax_2escm",(void*)f_3706},
{"f_6480:chicken_2dsyntax_2escm",(void*)f_6480},
{"f_6484:chicken_2dsyntax_2escm",(void*)f_6484},
{"f_9217:chicken_2dsyntax_2escm",(void*)f_9217},
{"f_6470:chicken_2dsyntax_2escm",(void*)f_6470},
{"f_6478:chicken_2dsyntax_2escm",(void*)f_6478},
{"f_6853:chicken_2dsyntax_2escm",(void*)f_6853},
{"f_8312:chicken_2dsyntax_2escm",(void*)f_8312},
{"f_8319:chicken_2dsyntax_2escm",(void*)f_8319},
{"f_5367:chicken_2dsyntax_2escm",(void*)f_5367},
{"f_5360:chicken_2dsyntax_2escm",(void*)f_5360},
{"f_5264:chicken_2dsyntax_2escm",(void*)f_5264},
{"f_3747:chicken_2dsyntax_2escm",(void*)f_3747},
{"f_3743:chicken_2dsyntax_2escm",(void*)f_3743},
{"f_5354:chicken_2dsyntax_2escm",(void*)f_5354},
{"f_5351:chicken_2dsyntax_2escm",(void*)f_5351},
{"f_9204:chicken_2dsyntax_2escm",(void*)f_9204},
{"f_3750:chicken_2dsyntax_2escm",(void*)f_3750},
{"f_3753:chicken_2dsyntax_2escm",(void*)f_3753},
{"f_3756:chicken_2dsyntax_2escm",(void*)f_3756},
{"f_9257:chicken_2dsyntax_2escm",(void*)f_9257},
{"f_6825:chicken_2dsyntax_2escm",(void*)f_6825},
{"f_6827:chicken_2dsyntax_2escm",(void*)f_6827},
{"f_3722:chicken_2dsyntax_2escm",(void*)f_3722},
{"f_3724:chicken_2dsyntax_2escm",(void*)f_3724},
{"f_6763:chicken_2dsyntax_2escm",(void*)f_6763},
{"f_6767:chicken_2dsyntax_2escm",(void*)f_6767},
{"f_6811:chicken_2dsyntax_2escm",(void*)f_6811},
{"f_6814:chicken_2dsyntax_2escm",(void*)f_6814},
{"f_3734:chicken_2dsyntax_2escm",(void*)f_3734},
{"f_6793:chicken_2dsyntax_2escm",(void*)f_6793},
{"f_6805:chicken_2dsyntax_2escm",(void*)f_6805},
{"f_6808:chicken_2dsyntax_2escm",(void*)f_6808},
{"f_3830:chicken_2dsyntax_2escm",(void*)f_3830},
{"f_6775:chicken_2dsyntax_2escm",(void*)f_6775},
{"f_6779:chicken_2dsyntax_2escm",(void*)f_6779},
{"f_6771:chicken_2dsyntax_2escm",(void*)f_6771},
{"f_8279:chicken_2dsyntax_2escm",(void*)f_8279},
{"f_7174:chicken_2dsyntax_2escm",(void*)f_7174},
{"f_3817:chicken_2dsyntax_2escm",(void*)f_3817},
{"f_3815:chicken_2dsyntax_2escm",(void*)f_3815},
{"f_8269:chicken_2dsyntax_2escm",(void*)f_8269},
{"f_8291:chicken_2dsyntax_2escm",(void*)f_8291},
{"f_7198:chicken_2dsyntax_2escm",(void*)f_7198},
{"f_8281:chicken_2dsyntax_2escm",(void*)f_8281},
{"f_8285:chicken_2dsyntax_2escm",(void*)f_8285},
{"f_6440:chicken_2dsyntax_2escm",(void*)f_6440},
{"f_6607:chicken_2dsyntax_2escm",(void*)f_6607},
{"f_6438:chicken_2dsyntax_2escm",(void*)f_6438},
{"f_6943:chicken_2dsyntax_2escm",(void*)f_6943},
{"f_6945:chicken_2dsyntax_2escm",(void*)f_6945},
{"f_6935:chicken_2dsyntax_2escm",(void*)f_6935},
{"f_3392:chicken_2dsyntax_2escm",(void*)f_3392},
{"f_3395:chicken_2dsyntax_2escm",(void*)f_3395},
{"f_3398:chicken_2dsyntax_2escm",(void*)f_3398},
{"f_6949:chicken_2dsyntax_2escm",(void*)f_6949},
{"f_10930:chicken_2dsyntax_2escm",(void*)f_10930},
{"f_10934:chicken_2dsyntax_2escm",(void*)f_10934},
{"f_10920:chicken_2dsyntax_2escm",(void*)f_10920},
{"f_10928:chicken_2dsyntax_2escm",(void*)f_10928},
{"f_7016:chicken_2dsyntax_2escm",(void*)f_7016},
{"f_3388:chicken_2dsyntax_2escm",(void*)f_3388},
{"f_6618:chicken_2dsyntax_2escm",(void*)f_6618},
{"f_6952:chicken_2dsyntax_2escm",(void*)f_6952},
{"f_6706:chicken_2dsyntax_2escm",(void*)f_6706},
{"f_6704:chicken_2dsyntax_2escm",(void*)f_6704},
{"f_6735:chicken_2dsyntax_2escm",(void*)f_6735},
{"f_7024:chicken_2dsyntax_2escm",(void*)f_7024},
{"f_7020:chicken_2dsyntax_2escm",(void*)f_7020},
{"f_7057:chicken_2dsyntax_2escm",(void*)f_7057},
{"f_7034:chicken_2dsyntax_2escm",(void*)f_7034},
{"f_7032:chicken_2dsyntax_2escm",(void*)f_7032},
{"f_6655:chicken_2dsyntax_2escm",(void*)f_6655},
{"f_7038:chicken_2dsyntax_2escm",(void*)f_7038},
{"f_8817:chicken_2dsyntax_2escm",(void*)f_8817},
{"f_8813:chicken_2dsyntax_2escm",(void*)f_8813},
{"f_8811:chicken_2dsyntax_2escm",(void*)f_8811},
{"f_4088:chicken_2dsyntax_2escm",(void*)f_4088},
{"f_4090:chicken_2dsyntax_2escm",(void*)f_4090},
{"f_3774:chicken_2dsyntax_2escm",(void*)f_3774},
{"f_3777:chicken_2dsyntax_2escm",(void*)f_3777},
{"f_4913:chicken_2dsyntax_2escm",(void*)f_4913},
{"f_4903:chicken_2dsyntax_2escm",(void*)f_4903},
{"f_4927:chicken_2dsyntax_2escm",(void*)f_4927},
{"f_9646:chicken_2dsyntax_2escm",(void*)f_9646},
{"f_8483:chicken_2dsyntax_2escm",(void*)f_8483},
{"f_9639:chicken_2dsyntax_2escm",(void*)f_9639},
{"f_9636:chicken_2dsyntax_2escm",(void*)f_9636},
{"f_4940:chicken_2dsyntax_2escm",(void*)f_4940},
{"f_8494:chicken_2dsyntax_2escm",(void*)f_8494},
{"f_7492:chicken_2dsyntax_2escm",(void*)f_7492},
{"f_9692:chicken_2dsyntax_2escm",(void*)f_9692},
{"f_9683:chicken_2dsyntax_2escm",(void*)f_9683},
{"f_4014:chicken_2dsyntax_2escm",(void*)f_4014},
{"f_7472:chicken_2dsyntax_2escm",(void*)f_7472},
{"f_9061:chicken_2dsyntax_2escm",(void*)f_9061},
{"f_9067:chicken_2dsyntax_2escm",(void*)f_9067},
{"f_8444:chicken_2dsyntax_2escm",(void*)f_8444},
{"f_8442:chicken_2dsyntax_2escm",(void*)f_8442},
{"f_5931:chicken_2dsyntax_2escm",(void*)f_5931},
{"f_9670:chicken_2dsyntax_2escm",(void*)f_9670},
{"f_9679:chicken_2dsyntax_2escm",(void*)f_9679},
{"f_9071:chicken_2dsyntax_2escm",(void*)f_9071},
{"f_9070:chicken_2dsyntax_2escm",(void*)f_9070},
{"f_5947:chicken_2dsyntax_2escm",(void*)f_5947},
{"f_9079:chicken_2dsyntax_2escm",(void*)f_9079},
{"f_5945:chicken_2dsyntax_2escm",(void*)f_5945},
{"f_4031:chicken_2dsyntax_2escm",(void*)f_4031},
{"f_9086:chicken_2dsyntax_2escm",(void*)f_9086},
{"f_9085:chicken_2dsyntax_2escm",(void*)f_9085},
{"f_9097:chicken_2dsyntax_2escm",(void*)f_9097},
{"f_9094:chicken_2dsyntax_2escm",(void*)f_9094},
{"f_8473:chicken_2dsyntax_2escm",(void*)f_8473},
{"f_5416:chicken_2dsyntax_2escm",(void*)f_5416},
{"f_5419:chicken_2dsyntax_2escm",(void*)f_5419},
{"f_5906:chicken_2dsyntax_2escm",(void*)f_5906},
{"f_5909:chicken_2dsyntax_2escm",(void*)f_5909},
{"f_5903:chicken_2dsyntax_2escm",(void*)f_5903},
{"f_9624:chicken_2dsyntax_2escm",(void*)f_9624},
{"f_9627:chicken_2dsyntax_2escm",(void*)f_9627},
{"f_9628:chicken_2dsyntax_2escm",(void*)f_9628},
{"f_9615:chicken_2dsyntax_2escm",(void*)f_9615},
{"f_9616:chicken_2dsyntax_2escm",(void*)f_9616},
{"f_8436:chicken_2dsyntax_2escm",(void*)f_8436},
{"f_9600:chicken_2dsyntax_2escm",(void*)f_9600},
{"f_9604:chicken_2dsyntax_2escm",(void*)f_9604},
{"f_4303:chicken_2dsyntax_2escm",(void*)f_4303},
{"f_7889:chicken_2dsyntax_2escm",(void*)f_7889},
{"f_7887:chicken_2dsyntax_2escm",(void*)f_7887},
{"f_7883:chicken_2dsyntax_2escm",(void*)f_7883},
{"f_8632:chicken_2dsyntax_2escm",(void*)f_8632},
{"f_8638:chicken_2dsyntax_2escm",(void*)f_8638},
{"f_7474:chicken_2dsyntax_2escm",(void*)f_7474},
{"f_7478:chicken_2dsyntax_2escm",(void*)f_7478},
{"f_5132:chicken_2dsyntax_2escm",(void*)f_5132},
{"f_4314:chicken_2dsyntax_2escm",(void*)f_4314},
{"f_4317:chicken_2dsyntax_2escm",(void*)f_4317},
{"f_5135:chicken_2dsyntax_2escm",(void*)f_5135},
{"f_7893:chicken_2dsyntax_2escm",(void*)f_7893},
{"f_7486:chicken_2dsyntax_2escm",(void*)f_7486},
{"f_7489:chicken_2dsyntax_2escm",(void*)f_7489},
{"f_5120:chicken_2dsyntax_2escm",(void*)f_5120},
{"f_4323:chicken_2dsyntax_2escm",(void*)f_4323},
{"f_5122:chicken_2dsyntax_2escm",(void*)f_5122},
{"f_5129:chicken_2dsyntax_2escm",(void*)f_5129},
{"f_5126:chicken_2dsyntax_2escm",(void*)f_5126},
{"f_8667:chicken_2dsyntax_2escm",(void*)f_8667},
{"f_7468:chicken_2dsyntax_2escm",(void*)f_7468},
{"f_7464:chicken_2dsyntax_2escm",(void*)f_7464},
{"f_5499:chicken_2dsyntax_2escm",(void*)f_5499},
{"f_5491:chicken_2dsyntax_2escm",(void*)f_5491},
{"f_8673:chicken_2dsyntax_2escm",(void*)f_8673},
{"f_8686:chicken_2dsyntax_2escm",(void*)f_8686},
{"f_5155:chicken_2dsyntax_2escm",(void*)f_5155},
{"f_5152:chicken_2dsyntax_2escm",(void*)f_5152},
{"f_8977:chicken_2dsyntax_2escm",(void*)f_8977},
{"f_8979:chicken_2dsyntax_2escm",(void*)f_8979},
{"f_5142:chicken_2dsyntax_2escm",(void*)f_5142},
{"f_5637:chicken_2dsyntax_2escm",(void*)f_5637},
{"f_8983:chicken_2dsyntax_2escm",(void*)f_8983},
{"f_4399:chicken_2dsyntax_2escm",(void*)f_4399},
{"f_5607:chicken_2dsyntax_2escm",(void*)f_5607},
{"f_4393:chicken_2dsyntax_2escm",(void*)f_4393},
{"f_4395:chicken_2dsyntax_2escm",(void*)f_4395},
{"f_5442:chicken_2dsyntax_2escm",(void*)f_5442},
{"f_5603:chicken_2dsyntax_2escm",(void*)f_5603},
{"f_3876:chicken_2dsyntax_2escm",(void*)f_3876},
{"f_3783:chicken_2dsyntax_2escm",(void*)f_3783},
{"f_5658:chicken_2dsyntax_2escm",(void*)f_5658},
{"f_5436:chicken_2dsyntax_2escm",(void*)f_5436},
{"f_7867:chicken_2dsyntax_2escm",(void*)f_7867},
{"f_4594:chicken_2dsyntax_2escm",(void*)f_4594},
{"f_8965:chicken_2dsyntax_2escm",(void*)f_8965},
{"f_3895:chicken_2dsyntax_2escm",(void*)f_3895},
{"f_7841:chicken_2dsyntax_2escm",(void*)f_7841},
{"f_4893:chicken_2dsyntax_2escm",(void*)f_4893},
{"f_3884:chicken_2dsyntax_2escm",(void*)f_3884},
{"f_4891:chicken_2dsyntax_2escm",(void*)f_4891},
{"f_3764:chicken_2dsyntax_2escm",(void*)f_3764},
{"f_4539:chicken_2dsyntax_2escm",(void*)f_4539},
{"f_7845:chicken_2dsyntax_2escm",(void*)f_7845},
{"f_7848:chicken_2dsyntax_2escm",(void*)f_7848},
{"f_5172:chicken_2dsyntax_2escm",(void*)f_5172},
{"f_4351:chicken_2dsyntax_2escm",(void*)f_4351},
{"f_4545:chicken_2dsyntax_2escm",(void*)f_4545},
{"f_4548:chicken_2dsyntax_2escm",(void*)f_4548},
{"f_4541:chicken_2dsyntax_2escm",(void*)f_4541},
{"f_4362:chicken_2dsyntax_2escm",(void*)f_4362},
{"f_5161:chicken_2dsyntax_2escm",(void*)f_5161},
{"f_10518:chicken_2dsyntax_2escm",(void*)f_10518},
{"f_10582:chicken_2dsyntax_2escm",(void*)f_10582},
{"f_10585:chicken_2dsyntax_2escm",(void*)f_10585},
{"f_10588:chicken_2dsyntax_2escm",(void*)f_10588},
{"f_6145:chicken_2dsyntax_2escm",(void*)f_6145},
{"f_9270:chicken_2dsyntax_2escm",(void*)f_9270},
{"f_6159:chicken_2dsyntax_2escm",(void*)f_6159},
{"f_6157:chicken_2dsyntax_2escm",(void*)f_6157},
{"f_3613:chicken_2dsyntax_2escm",(void*)f_3613},
{"f_3616:chicken_2dsyntax_2escm",(void*)f_3616},
{"f_10570:chicken_2dsyntax_2escm",(void*)f_10570},
{"f_10574:chicken_2dsyntax_2escm",(void*)f_10574},
{"f_10481:chicken_2dsyntax_2escm",(void*)f_10481},
{"f_6149:chicken_2dsyntax_2escm",(void*)f_6149},
{"f_10568:chicken_2dsyntax_2escm",(void*)f_10568},
{"f_10475:chicken_2dsyntax_2escm",(void*)f_10475},
{"f_10477:chicken_2dsyntax_2escm",(void*)f_10477},
{"f_10397:chicken_2dsyntax_2escm",(void*)f_10397},
{"f_10395:chicken_2dsyntax_2escm",(void*)f_10395},
{"f_5198:chicken_2dsyntax_2escm",(void*)f_5198},
{"f_4339:chicken_2dsyntax_2escm",(void*)f_4339},
{"f_4332:chicken_2dsyntax_2escm",(void*)f_4332},
{"f_3601:chicken_2dsyntax_2escm",(void*)f_3601},
{"f_3603:chicken_2dsyntax_2escm",(void*)f_3603},
{"f_3607:chicken_2dsyntax_2escm",(void*)f_3607},
{"f_7739:chicken_2dsyntax_2escm",(void*)f_7739},
{"f_7735:chicken_2dsyntax_2escm",(void*)f_7735},
{"f_5188:chicken_2dsyntax_2escm",(void*)f_5188},
{"f_10385:chicken_2dsyntax_2escm",(void*)f_10385},
{"f_7737:chicken_2dsyntax_2escm",(void*)f_7737},
{"f_10378:chicken_2dsyntax_2escm",(void*)f_10378},
{"f_6109:chicken_2dsyntax_2escm",(void*)f_6109},
{"f_6163:chicken_2dsyntax_2escm",(void*)f_6163},
{"f_3637:chicken_2dsyntax_2escm",(void*)f_3637},
{"f_6166:chicken_2dsyntax_2escm",(void*)f_6166},
{"f_6169:chicken_2dsyntax_2escm",(void*)f_6169},
{"f_3641:chicken_2dsyntax_2escm",(void*)f_3641},
{"f_10699:chicken_2dsyntax_2escm",(void*)f_10699},
{"f_3648:chicken_2dsyntax_2escm",(void*)f_3648},
{"f_10696:chicken_2dsyntax_2escm",(void*)f_10696},
{"f_10693:chicken_2dsyntax_2escm",(void*)f_10693},
{"f_9107:chicken_2dsyntax_2escm",(void*)f_9107},
{"f_3525:chicken_2dsyntax_2escm",(void*)f_3525},
{"f_3528:chicken_2dsyntax_2escm",(void*)f_3528},
{"f_3522:chicken_2dsyntax_2escm",(void*)f_3522},
{"f_10401:chicken_2dsyntax_2escm",(void*)f_10401},
{"f_3516:chicken_2dsyntax_2escm",(void*)f_3516},
{"f_3519:chicken_2dsyntax_2escm",(void*)f_3519},
{"f_3513:chicken_2dsyntax_2escm",(void*)f_3513},
{"f_3510:chicken_2dsyntax_2escm",(void*)f_3510},
{"f_10326:chicken_2dsyntax_2escm",(void*)f_10326},
{"f_10323:chicken_2dsyntax_2escm",(void*)f_10323},
{"f_10428:chicken_2dsyntax_2escm",(void*)f_10428},
{"f_10426:chicken_2dsyntax_2escm",(void*)f_10426},
{"f_10312:chicken_2dsyntax_2escm",(void*)f_10312},
{"f_10414:chicken_2dsyntax_2escm",(void*)f_10414},
{"f_10412:chicken_2dsyntax_2escm",(void*)f_10412},
{"f_7088:chicken_2dsyntax_2escm",(void*)f_7088},
{"f_6180:chicken_2dsyntax_2escm",(void*)f_6180},
{"f_10306:chicken_2dsyntax_2escm",(void*)f_10306},
{"f_10308:chicken_2dsyntax_2escm",(void*)f_10308},
{"f_6196:chicken_2dsyntax_2escm",(void*)f_6196},
{"f_7061:chicken_2dsyntax_2escm",(void*)f_7061},
{"f_7067:chicken_2dsyntax_2escm",(void*)f_7067},
{"f_7065:chicken_2dsyntax_2escm",(void*)f_7065},
{"f_10432:chicken_2dsyntax_2escm",(void*)f_10432},
{"f_9121:chicken_2dsyntax_2escm",(void*)f_9121},
{"f_3504:chicken_2dsyntax_2escm",(void*)f_3504},
{"f_3507:chicken_2dsyntax_2escm",(void*)f_3507},
{"f_10368:chicken_2dsyntax_2escm",(void*)f_10368},
{"f_3501:chicken_2dsyntax_2escm",(void*)f_3501},
{"f_10349:chicken_2dsyntax_2escm",(void*)f_10349},
{"f_4768:chicken_2dsyntax_2escm",(void*)f_4768},
{"f_4793:chicken_2dsyntax_2escm",(void*)f_4793},
{"f_4799:chicken_2dsyntax_2escm",(void*)f_4799},
{"f_4790:chicken_2dsyntax_2escm",(void*)f_4790},
{"f_3547:chicken_2dsyntax_2escm",(void*)f_3547},
{"f_3541:chicken_2dsyntax_2escm",(void*)f_3541},
{"f_3543:chicken_2dsyntax_2escm",(void*)f_3543},
{"f_5868:chicken_2dsyntax_2escm",(void*)f_5868},
{"f_4784:chicken_2dsyntax_2escm",(void*)f_4784},
{"f_3537:chicken_2dsyntax_2escm",(void*)f_3537},
{"f_3531:chicken_2dsyntax_2escm",(void*)f_3531},
{"f_3534:chicken_2dsyntax_2escm",(void*)f_3534},
{"f_5878:chicken_2dsyntax_2escm",(void*)f_5878},
{"f_5876:chicken_2dsyntax_2escm",(void*)f_5876},
{"f_5888:chicken_2dsyntax_2escm",(void*)f_5888},
{"f_8711:chicken_2dsyntax_2escm",(void*)f_8711},
{"f_5882:chicken_2dsyntax_2escm",(void*)f_5882},
{"f_5885:chicken_2dsyntax_2escm",(void*)f_5885},
{"f_7206:chicken_2dsyntax_2escm",(void*)f_7206},
{"f_5897:chicken_2dsyntax_2escm",(void*)f_5897},
{"f_5899:chicken_2dsyntax_2escm",(void*)f_5899},
{"f_5891:chicken_2dsyntax_2escm",(void*)f_5891},
{"f_5894:chicken_2dsyntax_2escm",(void*)f_5894},
{"f_7715:chicken_2dsyntax_2escm",(void*)f_7715},
{"f_9598:chicken_2dsyntax_2escm",(void*)f_9598},
{"f_3585:chicken_2dsyntax_2escm",(void*)f_3585},
{"f_4865:chicken_2dsyntax_2escm",(void*)f_4865},
{"f_9585:chicken_2dsyntax_2escm",(void*)f_9585},
{"f_8058:chicken_2dsyntax_2escm",(void*)f_8058},
{"f_7239:chicken_2dsyntax_2escm",(void*)f_7239},
{"f_7235:chicken_2dsyntax_2escm",(void*)f_7235},
{"f_7248:chicken_2dsyntax_2escm",(void*)f_7248},
{"f_4879:chicken_2dsyntax_2escm",(void*)f_4879},
{"f_7240:chicken_2dsyntax_2escm",(void*)f_7240},
{"f_8106:chicken_2dsyntax_2escm",(void*)f_8106},
{"f_8100:chicken_2dsyntax_2escm",(void*)f_8100},
{"f_7217:chicken_2dsyntax_2escm",(void*)f_7217},
{"f_9550:chicken_2dsyntax_2escm",(void*)f_9550},
{"f_7214:chicken_2dsyntax_2escm",(void*)f_7214},
{"f_7226:chicken_2dsyntax_2escm",(void*)f_7226},
{"f_7227:chicken_2dsyntax_2escm",(void*)f_7227},
{"f_7220:chicken_2dsyntax_2escm",(void*)f_7220},
{"f_9571:chicken_2dsyntax_2escm",(void*)f_9571},
{"f_9578:chicken_2dsyntax_2escm",(void*)f_9578},
{"f_3562:chicken_2dsyntax_2escm",(void*)f_3562},
{"f_9561:chicken_2dsyntax_2escm",(void*)f_9561},
{"f_3559:chicken_2dsyntax_2escm",(void*)f_3559},
{"f_3556:chicken_2dsyntax_2escm",(void*)f_3556},
{"f_7921:chicken_2dsyntax_2escm",(void*)f_7921},
{"f_7920:chicken_2dsyntax_2escm",(void*)f_7920},
{"f_7314:chicken_2dsyntax_2escm",(void*)f_7314},
{"f_8141:chicken_2dsyntax_2escm",(void*)f_8141},
{"f_7257:chicken_2dsyntax_2escm",(void*)f_7257},
{"f_7914:chicken_2dsyntax_2escm",(void*)f_7914},
{"f_7910:chicken_2dsyntax_2escm",(void*)f_7910},
{"f_7254:chicken_2dsyntax_2escm",(void*)f_7254},
{"f_7902:chicken_2dsyntax_2escm",(void*)f_7902},
{"f_7901:chicken_2dsyntax_2escm",(void*)f_7901},
{"f_7839:chicken_2dsyntax_2escm",(void*)f_7839},
{"f_7827:chicken_2dsyntax_2escm",(void*)f_7827},
{"f_9982:chicken_2dsyntax_2escm",(void*)f_9982},
{"f_9894:chicken_2dsyntax_2escm",(void*)f_9894},
{"f_9954:chicken_2dsyntax_2escm",(void*)f_9954},
{"f_9958:chicken_2dsyntax_2escm",(void*)f_9958},
{"f_9945:chicken_2dsyntax_2escm",(void*)f_9945},
{"f_4656:chicken_2dsyntax_2escm",(void*)f_4656},
{"f_5827:chicken_2dsyntax_2escm",(void*)f_5827},
{"f_6056:chicken_2dsyntax_2escm",(void*)f_6056},
{"f_4658:chicken_2dsyntax_2escm",(void*)f_4658},
{"f_8023:chicken_2dsyntax_2escm",(void*)f_8023},
{"f_9845:chicken_2dsyntax_2escm",(void*)f_9845},
{"f_6049:chicken_2dsyntax_2escm",(void*)f_6049},
{"f_4648:chicken_2dsyntax_2escm",(void*)f_4648},
{"f_8029:chicken_2dsyntax_2escm",(void*)f_8029},
{"f_9967:chicken_2dsyntax_2escm",(void*)f_9967},
{"f_9969:chicken_2dsyntax_2escm",(void*)f_9969},
{"f_4617:chicken_2dsyntax_2escm",(void*)f_4617},
{"f_4619:chicken_2dsyntax_2escm",(void*)f_4619},
{"f_5777:chicken_2dsyntax_2escm",(void*)f_5777},
{"f_6080:chicken_2dsyntax_2escm",(void*)f_6080},
{"f_4603:chicken_2dsyntax_2escm",(void*)f_4603},
{"f_5790:chicken_2dsyntax_2escm",(void*)f_5790},
{"f_5792:chicken_2dsyntax_2escm",(void*)f_5792},
{"f_6027:chicken_2dsyntax_2escm",(void*)f_6027},
{"f_7349:chicken_2dsyntax_2escm",(void*)f_7349},
{"f_7343:chicken_2dsyntax_2escm",(void*)f_7343},
{"f_9858:chicken_2dsyntax_2escm",(void*)f_9858},
{"f_6694:chicken_2dsyntax_2escm",(void*)f_6694},
{"f_5520:chicken_2dsyntax_2escm",(void*)f_5520},
{"f_5523:chicken_2dsyntax_2escm",(void*)f_5523},
{"f_6060:chicken_2dsyntax_2escm",(void*)f_6060},
{"f_5529:chicken_2dsyntax_2escm",(void*)f_5529},
{"f_8364:chicken_2dsyntax_2escm",(void*)f_8364},
{"f_8368:chicken_2dsyntax_2escm",(void*)f_8368},
{"f_8367:chicken_2dsyntax_2escm",(void*)f_8367},
{"f_7384:chicken_2dsyntax_2escm",(void*)f_7384},
{"f_7784:chicken_2dsyntax_2escm",(void*)f_7784},
{"f_7644:chicken_2dsyntax_2escm",(void*)f_7644},
{"f_8885:chicken_2dsyntax_2escm",(void*)f_8885},
{"f_7780:chicken_2dsyntax_2escm",(void*)f_7780},
{"f_7640:chicken_2dsyntax_2escm",(void*)f_7640},
{"f_8887:chicken_2dsyntax_2escm",(void*)f_8887},
{"f_5501:chicken_2dsyntax_2escm",(void*)f_5501},
{"f_3978:chicken_2dsyntax_2escm",(void*)f_3978},
{"f_5505:chicken_2dsyntax_2escm",(void*)f_5505},
{"f_10020:chicken_2dsyntax_2escm",(void*)f_10020},
{"f_8346:chicken_2dsyntax_2escm",(void*)f_8346},
{"f_8342:chicken_2dsyntax_2escm",(void*)f_8342},
{"f_7654:chicken_2dsyntax_2escm",(void*)f_7654},
{"f_3960:chicken_2dsyntax_2escm",(void*)f_3960},
{"f_6864:chicken_2dsyntax_2escm",(void*)f_6864},
{"f_10194:chicken_2dsyntax_2escm",(void*)f_10194},
{"f_5595:chicken_2dsyntax_2escm",(void*)f_5595},
{"f_5599:chicken_2dsyntax_2escm",(void*)f_5599},
{"f_10034:chicken_2dsyntax_2escm",(void*)f_10034},
{"f_10188:chicken_2dsyntax_2escm",(void*)f_10188},
{"f_8376:chicken_2dsyntax_2escm",(void*)f_8376},
{"f_8380:chicken_2dsyntax_2escm",(void*)f_8380},
{"f_8387:chicken_2dsyntax_2escm",(void*)f_8387},
{"f_8386:chicken_2dsyntax_2escm",(void*)f_8386},
{"f_4415:chicken_2dsyntax_2escm",(void*)f_4415},
{"f_7985:chicken_2dsyntax_2escm",(void*)f_7985},
{"f_8858:chicken_2dsyntax_2escm",(void*)f_8858},
{"f_5737:chicken_2dsyntax_2escm",(void*)f_5737},
{"f_10053:chicken_2dsyntax_2escm",(void*)f_10053},
{"f_7994:chicken_2dsyntax_2escm",(void*)f_7994},
{"f_7992:chicken_2dsyntax_2escm",(void*)f_7992},
{"f_10153:chicken_2dsyntax_2escm",(void*)f_10153},
{"f_6503:chicken_2dsyntax_2escm",(void*)f_6503},
{"f_6505:chicken_2dsyntax_2escm",(void*)f_6505},
{"f_6518:chicken_2dsyntax_2escm",(void*)f_6518},
{"f_10159:chicken_2dsyntax_2escm",(void*)f_10159},
{"f_4437:chicken_2dsyntax_2escm",(void*)f_4437},
{"f_4431:chicken_2dsyntax_2escm",(void*)f_4431},
{"f_4433:chicken_2dsyntax_2escm",(void*)f_4433},
{"f_9167:chicken_2dsyntax_2escm",(void*)f_9167},
{"f_9165:chicken_2dsyntax_2escm",(void*)f_9165},
{"f_7977:chicken_2dsyntax_2escm",(void*)f_7977},
{"f_4446:chicken_2dsyntax_2escm",(void*)f_4446},
{"f_7975:chicken_2dsyntax_2escm",(void*)f_7975},
{"f_5582:chicken_2dsyntax_2escm",(void*)f_5582},
{"f_5588:chicken_2dsyntax_2escm",(void*)f_5588},
{"f_3677:chicken_2dsyntax_2escm",(void*)f_3677},
{"f_7755:chicken_2dsyntax_2escm",(void*)f_7755},
{"f_7945:chicken_2dsyntax_2escm",(void*)f_7945},
{"f_7949:chicken_2dsyntax_2escm",(void*)f_7949},
{"f_4454:chicken_2dsyntax_2escm",(void*)f_4454},
{"f_3675:chicken_2dsyntax_2escm",(void*)f_3675},
{"f_7752:chicken_2dsyntax_2escm",(void*)f_7752},
{"f_5538:chicken_2dsyntax_2escm",(void*)f_5538},
{"f_5532:chicken_2dsyntax_2escm",(void*)f_5532},
{"f_10124:chicken_2dsyntax_2escm",(void*)f_10124},
{"f_6326:chicken_2dsyntax_2escm",(void*)f_6326},
{"f_7764:chicken_2dsyntax_2escm",(void*)f_7764},
{"f_10713:chicken_2dsyntax_2escm",(void*)f_10713},
{"f_8398:chicken_2dsyntax_2escm",(void*)f_8398},
{"f_5561:chicken_2dsyntax_2escm",(void*)f_5561},
{"f_7951:chicken_2dsyntax_2escm",(void*)f_7951},
{"f_5563:chicken_2dsyntax_2escm",(void*)f_5563},
{"f_10040:chicken_2dsyntax_2escm",(void*)f_10040},
{"f_7638:chicken_2dsyntax_2escm",(void*)f_7638},
{"f_4489:chicken_2dsyntax_2escm",(void*)f_4489},
{"f_7743:chicken_2dsyntax_2escm",(void*)f_7743},
{"f_7681:chicken_2dsyntax_2escm",(void*)f_7681},
{"f_7696:chicken_2dsyntax_2escm",(void*)f_7696},
{"f_7699:chicken_2dsyntax_2escm",(void*)f_7699},
{"f_4493:chicken_2dsyntax_2escm",(void*)f_4493},
{"f_10822:chicken_2dsyntax_2escm",(void*)f_10822},
{"f_10826:chicken_2dsyntax_2escm",(void*)f_10826},
{"f_7503:chicken_2dsyntax_2escm",(void*)f_7503},
{"f_7505:chicken_2dsyntax_2escm",(void*)f_7505},
{"f_7419:chicken_2dsyntax_2escm",(void*)f_7419},
{"f_10891:chicken_2dsyntax_2escm",(void*)f_10891},
{"f_7413:chicken_2dsyntax_2escm",(void*)f_7413},
{"f_10725:chicken_2dsyntax_2escm",(void*)f_10725},
{"f_10729:chicken_2dsyntax_2escm",(void*)f_10729},
{"f_9194:chicken_2dsyntax_2escm",(void*)f_9194},
{"f_8625:chicken_2dsyntax_2escm",(void*)f_8625},
{"f_6349:chicken_2dsyntax_2escm",(void*)f_6349},
{"f_10841:chicken_2dsyntax_2escm",(void*)f_10841},
{"f_8900:chicken_2dsyntax_2escm",(void*)f_8900},
{"f_6296:chicken_2dsyntax_2escm",(void*)f_6296},
{"f_10867:chicken_2dsyntax_2escm",(void*)f_10867},
{"f_10861:chicken_2dsyntax_2escm",(void*)f_10861},
{"f_6554:chicken_2dsyntax_2escm",(void*)f_6554},
{"f_10652:chicken_2dsyntax_2escm",(void*)f_10652},
{"f_6398:chicken_2dsyntax_2escm",(void*)f_6398},
{"f_4464:chicken_2dsyntax_2escm",(void*)f_4464},
{"f_4462:chicken_2dsyntax_2escm",(void*)f_4462},
{"f_10887:chicken_2dsyntax_2escm",(void*)f_10887},
{"f_6395:chicken_2dsyntax_2escm",(void*)f_6395},
{"f_6392:chicken_2dsyntax_2escm",(void*)f_6392},
{"f_6389:chicken_2dsyntax_2escm",(void*)f_6389},
{"f_10503:chicken_2dsyntax_2escm",(void*)f_10503},
{"f_6381:chicken_2dsyntax_2escm",(void*)f_6381},
{"f_6377:chicken_2dsyntax_2escm",(void*)f_6377},
{"f_6282:chicken_2dsyntax_2escm",(void*)f_6282},
{"f_10591:chicken_2dsyntax_2escm",(void*)f_10591},
{"f_10592:chicken_2dsyntax_2escm",(void*)f_10592},
{"f_6272:chicken_2dsyntax_2escm",(void*)f_6272},
{"f_3944:chicken_2dsyntax_2escm",(void*)f_3944},
{"f_9835:chicken_2dsyntax_2escm",(void*)f_9835},
{"f_6276:chicken_2dsyntax_2escm",(void*)f_6276},
{"f_6278:chicken_2dsyntax_2escm",(void*)f_6278},
{"f_3413:chicken_2dsyntax_2escm",(void*)f_3413},
{"f_3410:chicken_2dsyntax_2escm",(void*)f_3410},
{"f_9822:chicken_2dsyntax_2escm",(void*)f_9822},
{"f_3958:chicken_2dsyntax_2escm",(void*)f_3958},
{"f_3425:chicken_2dsyntax_2escm",(void*)f_3425},
{"f_3428:chicken_2dsyntax_2escm",(void*)f_3428},
{"f_9826:chicken_2dsyntax_2escm",(void*)f_9826},
{"f_9810:chicken_2dsyntax_2escm",(void*)f_9810},
{"f_3416:chicken_2dsyntax_2escm",(void*)f_3416},
{"f_3419:chicken_2dsyntax_2escm",(void*)f_3419},
{"f_9907:chicken_2dsyntax_2escm",(void*)f_9907},
{"f_7278:chicken_2dsyntax_2escm",(void*)f_7278},
{"f_3913:chicken_2dsyntax_2escm",(void*)f_3913},
{"f_3915:chicken_2dsyntax_2escm",(void*)f_3915},
{"f_6268:chicken_2dsyntax_2escm",(void*)f_6268},
{"f_7272:chicken_2dsyntax_2escm",(void*)f_7272},
{"f_7275:chicken_2dsyntax_2escm",(void*)f_7275},
{"f_3401:chicken_2dsyntax_2escm",(void*)f_3401},
{"f_7288:chicken_2dsyntax_2escm",(void*)f_7288},
{"f_7281:chicken_2dsyntax_2escm",(void*)f_7281},
{"f_10677:chicken_2dsyntax_2escm",(void*)f_10677},
{"f_10675:chicken_2dsyntax_2escm",(void*)f_10675},
{"f_4671:chicken_2dsyntax_2escm",(void*)f_4671},
{"f_9518:chicken_2dsyntax_2escm",(void*)f_9518},
{"f_3404:chicken_2dsyntax_2escm",(void*)f_3404},
{"f_3407:chicken_2dsyntax_2escm",(void*)f_3407},
{"f_4665:chicken_2dsyntax_2escm",(void*)f_4665},
{"f_4662:chicken_2dsyntax_2escm",(void*)f_4662},
{"f_4668:chicken_2dsyntax_2escm",(void*)f_4668},
{"f_3422:chicken_2dsyntax_2escm",(void*)f_3422},
{"f_10620:chicken_2dsyntax_2escm",(void*)f_10620},
{"f_9512:chicken_2dsyntax_2escm",(void*)f_9512},
{"f_9515:chicken_2dsyntax_2escm",(void*)f_9515},
{"f_7260:chicken_2dsyntax_2escm",(void*)f_7260},
{"f_4694:chicken_2dsyntax_2escm",(void*)f_4694},
{"f_7263:chicken_2dsyntax_2escm",(void*)f_7263},
{"f_4697:chicken_2dsyntax_2escm",(void*)f_4697},
{"f_7264:chicken_2dsyntax_2escm",(void*)f_7264},
{"f_9503:chicken_2dsyntax_2escm",(void*)f_9503},
{"f_6363:chicken_2dsyntax_2escm",(void*)f_6363},
{"f_6357:chicken_2dsyntax_2escm",(void*)f_6357},
{"f_6355:chicken_2dsyntax_2escm",(void*)f_6355},
{"f_6351:chicken_2dsyntax_2escm",(void*)f_6351},
{"f_3495:chicken_2dsyntax_2escm",(void*)f_3495},
{"f_3492:chicken_2dsyntax_2escm",(void*)f_3492},
{"f_3498:chicken_2dsyntax_2escm",(void*)f_3498},
{"f_8071:chicken_2dsyntax_2escm",(void*)f_8071},
{"f_8186:chicken_2dsyntax_2escm",(void*)f_8186},
{"f_8188:chicken_2dsyntax_2escm",(void*)f_8188},
{"f_9521:chicken_2dsyntax_2escm",(void*)f_9521},
{"f_3447:chicken_2dsyntax_2escm",(void*)f_3447},
{"f_3441:chicken_2dsyntax_2escm",(void*)f_3441},
{"f_3444:chicken_2dsyntax_2escm",(void*)f_3444},
{"f_8170:chicken_2dsyntax_2escm",(void*)f_8170},
{"f_8069:chicken_2dsyntax_2escm",(void*)f_8069},
{"f_3438:chicken_2dsyntax_2escm",(void*)f_3438},
{"f_3431:chicken_2dsyntax_2escm",(void*)f_3431},
{"f_3434:chicken_2dsyntax_2escm",(void*)f_3434},
{"f_8936:chicken_2dsyntax_2escm",(void*)f_8936},
{"f_3480:chicken_2dsyntax_2escm",(void*)f_3480},
{"f_3471:chicken_2dsyntax_2escm",(void*)f_3471},
{"f_7114:chicken_2dsyntax_2escm",(void*)f_7114},
{"f_3483:chicken_2dsyntax_2escm",(void*)f_3483},
{"f_3486:chicken_2dsyntax_2escm",(void*)f_3486},
{"f_3489:chicken_2dsyntax_2escm",(void*)f_3489},
{"f_7118:chicken_2dsyntax_2escm",(void*)f_7118},
{"f_3474:chicken_2dsyntax_2escm",(void*)f_3474},
{"f_3477:chicken_2dsyntax_2escm",(void*)f_3477},
{"f_8231:chicken_2dsyntax_2escm",(void*)f_8231},
{"f_7134:chicken_2dsyntax_2escm",(void*)f_7134},
{"f_4994:chicken_2dsyntax_2escm",(void*)f_4994},
{"f_8239:chicken_2dsyntax_2escm",(void*)f_8239},
{"f_4990:chicken_2dsyntax_2escm",(void*)f_4990},
{"f_8225:chicken_2dsyntax_2escm",(void*)f_8225},
{"f_8227:chicken_2dsyntax_2escm",(void*)f_8227},
{"f_4988:chicken_2dsyntax_2escm",(void*)f_4988},
{"f_7106:chicken_2dsyntax_2escm",(void*)f_7106},
{"f_8244:chicken_2dsyntax_2escm",(void*)f_8244},
{"f_3450:chicken_2dsyntax_2escm",(void*)f_3450},
{"f_7128:chicken_2dsyntax_2escm",(void*)f_7128},
{"f_3468:chicken_2dsyntax_2escm",(void*)f_3468},
{"f_3465:chicken_2dsyntax_2escm",(void*)f_3465},
{"f_3462:chicken_2dsyntax_2escm",(void*)f_3462},
{"f_3459:chicken_2dsyntax_2escm",(void*)f_3459},
{"f_3456:chicken_2dsyntax_2escm",(void*)f_3456},
{"f_3453:chicken_2dsyntax_2escm",(void*)f_3453},
{"f_7148:chicken_2dsyntax_2escm",(void*)f_7148},
{"f_8412:chicken_2dsyntax_2escm",(void*)f_8412},
{"f_8410:chicken_2dsyntax_2escm",(void*)f_8410},
{"f_4178:chicken_2dsyntax_2escm",(void*)f_4178},
{"f_8428:chicken_2dsyntax_2escm",(void*)f_8428},
{"f_4808:chicken_2dsyntax_2escm",(void*)f_4808},
{"f_4142:chicken_2dsyntax_2escm",(void*)f_4142},
{"f_9460:chicken_2dsyntax_2escm",(void*)f_9460},
{"f_4168:chicken_2dsyntax_2escm",(void*)f_4168},
{"f_4829:chicken_2dsyntax_2escm",(void*)f_4829},
{"f_9751:chicken_2dsyntax_2escm",(void*)f_9751},
{"f_4815:chicken_2dsyntax_2escm",(void*)f_4815},
{"f_4843:chicken_2dsyntax_2escm",(void*)f_4843},
{"f_4840:chicken_2dsyntax_2escm",(void*)f_4840},
{"f_4849:chicken_2dsyntax_2escm",(void*)f_4849},
{"f_9355:chicken_2dsyntax_2escm",(void*)f_9355},
{"f_4755:chicken_2dsyntax_2escm",(void*)f_4755},
{"f_9764:chicken_2dsyntax_2escm",(void*)f_9764},
{"f_9497:chicken_2dsyntax_2escm",(void*)f_9497},
{"f_9499:chicken_2dsyntax_2escm",(void*)f_9499},
{"f_4743:chicken_2dsyntax_2escm",(void*)f_4743},
{"f_4745:chicken_2dsyntax_2escm",(void*)f_4745},
{"f_4858:chicken_2dsyntax_2escm",(void*)f_4858},
{"f_9390:chicken_2dsyntax_2escm",(void*)f_9390},
{"f_4114:chicken_2dsyntax_2escm",(void*)f_4114},
{"f_4132:chicken_2dsyntax_2escm",(void*)f_4132},
{"f_8786:chicken_2dsyntax_2escm",(void*)f_8786},
{"f_8782:chicken_2dsyntax_2escm",(void*)f_8782},
{"f_4100:chicken_2dsyntax_2escm",(void*)f_4100},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  for-each		1
S|  ##sys#map		10
S|  map		37
o|eliminated procedure checks: 640 
o|specializations:
o|  1 (caddr (pair * (pair * pair)))
o|  3 (cadr (pair * pair))
o|  1 (zero? fixnum)
o|  2 (length list)
o|  24 (##sys#check-list (or pair list) *)
o|  6 (cdddr (pair * (pair * pair)))
o|  2 (string-append string string)
o|  49 (cdr pair)
o|  23 (car pair)
o|  17 (cddr (pair * pair))
o|Removed `not' forms: 12 
o|contracted procedure: k3551 
o|inlining procedure: k3548 
o|inlining procedure: k3548 
o|inlining procedure: k3658 
o|inlining procedure: k3658 
o|inlining procedure: k3679 
o|inlining procedure: k3679 
o|contracted procedure: k3729 
o|inlining procedure: k3726 
o|inlining procedure: k3766 
o|inlining procedure: k3819 
o|contracted procedure: "(chicken-syntax.scm:1258) g24302440" 
o|inlining procedure: k3819 
o|inlining procedure: k3885 
o|inlining procedure: k3885 
o|inlining procedure: k3893 
o|inlining procedure: k3917 
o|contracted procedure: "(chicken-syntax.scm:1245) g23902399" 
o|propagated global variable: g24072408 ##compiler#check-and-validate-type 
o|inlining procedure: k3917 
o|inlining procedure: k3893 
o|inlining procedure: k3962 
o|inlining procedure: k3962 
o|inlining procedure: k3766 
o|inlining procedure: k4009 
o|inlining procedure: k4009 
o|inlining procedure: k4046 
o|inlining procedure: k4046 
o|inlining procedure: k3726 
o|inlining procedure: k4095 
o|inlining procedure: k4180 
o|contracted procedure: "(chicken-syntax.scm:1208) g23242333" 
o|inlining procedure: k4180 
o|inlining procedure: k4215 
o|contracted procedure: "(chicken-syntax.scm:1208) g22962305" 
o|inlining procedure: k4215 
o|inlining procedure: k4095 
o|inlining procedure: k4253 
o|inlining procedure: k4268 
o|inlining procedure: k4284 
o|inlining procedure: k4284 
o|inlining procedure: k4268 
o|inlining procedure: k4253 
o|inlining procedure: k4318 
o|inlining procedure: k4334 
o|inlining procedure: k4334 
o|inlining procedure: k4369 
o|inlining procedure: k4369 
o|inlining procedure: k4318 
o|contracted procedure: k4403 
o|inlining procedure: k4400 
o|inlining procedure: k4400 
o|contracted procedure: k4441 
o|inlining procedure: k4438 
o|contracted procedure: k4469 
o|inlining procedure: k4466 
o|inlining procedure: k4495 
o|inlining procedure: k4495 
o|inlining procedure: k4466 
o|inlining procedure: k4438 
o|inlining procedure: k4621 
o|contracted procedure: "(chicken-syntax.scm:1159) g21692178" 
o|inlining procedure: k4621 
o|inlining procedure: k4695 
o|inlining procedure: k4695 
o|inlining procedure: k4710 
o|inlining procedure: k4710 
o|inlining procedure: k4750 
o|inlining procedure: k4750 
o|inlining procedure: k4779 
o|inlining procedure: k4794 
o|inlining procedure: k4810 
o|inlining procedure: k4810 
o|inlining procedure: k4794 
o|inlining procedure: k4779 
o|inlining procedure: k4844 
o|inlining procedure: k4860 
o|inlining procedure: k4860 
o|inlining procedure: k4844 
o|inlining procedure: k4898 
o|inlining procedure: k4898 
o|inlining procedure: k4962 
o|inlining procedure: k4962 
o|inlining procedure: k5065 
o|inlining procedure: k5065 
o|inlining procedure: k5144 
o|inlining procedure: k5144 
o|inlining procedure: k5242 
o|inlining procedure: k5242 
o|inlining procedure: k5343 
o|inlining procedure: k5343 
o|inlining procedure: k5437 
o|inlining procedure: k5437 
o|inlining procedure: k5565 
o|inlining procedure: k5565 
o|inlining procedure: k5614 
o|contracted procedure: k5620 
o|inlining procedure: k5614 
o|inlining procedure: k5653 
o|inlining procedure: k5653 
o|inlining procedure: k5726 
o|inlining procedure: k5726 
o|inlining procedure: k5779 
o|inlining procedure: k5779 
o|inlining procedure: k5794 
o|inlining procedure: k5794 
o|inlining procedure: k5829 
o|inlining procedure: k5829 
o|inlining procedure: k5910 
o|inlining procedure: k5910 
o|inlining procedure: k5949 
o|inlining procedure: k5949 
o|inlining procedure: k6062 
o|inlining procedure: k6062 
o|inlining procedure: k6082 
o|inlining procedure: k6082 
o|inlining procedure: k6288 
o|inlining procedure: k6288 
o|inlining procedure: k6365 
o|inlining procedure: k6365 
o|inlining procedure: k6485 
o|inlining procedure: k6485 
o|inlining procedure: k6507 
o|inlining procedure: k6507 
o|inlining procedure: k6556 
o|inlining procedure: k6584 
o|inlining procedure: k6584 
o|inlining procedure: k6556 
o|inlining procedure: k6616 
o|inlining procedure: k6616 
o|inlining procedure: k6656 
o|inlining procedure: k6656 
o|inlining procedure: k6708 
o|contracted procedure: "(chicken-syntax.scm:778) g16071616" 
o|inlining procedure: k6708 
o|inlining procedure: k6829 
o|inlining procedure: k6829 
o|removed unused formal parameters: (rename1402) 
o|inlining procedure: k7136 
o|inlining procedure: k7136 
o|removed unused parameter to known procedure: rename1402 "(chicken-syntax.scm:681) make-if-tree1382" 
o|contracted procedure: "(chicken-syntax.scm:679) make-default-procs1381" 
o|inlining procedure: k7069 
o|inlining procedure: k7069 
o|inlining procedure: k7316 
o|inlining procedure: k7316 
o|inlining procedure: k7351 
o|inlining procedure: k7351 
o|inlining procedure: k7386 
o|inlining procedure: k7386 
o|inlining procedure: k7421 
o|inlining procedure: k7421 
o|inlining procedure: k7507 
o|inlining procedure: k7507 
o|contracted procedure: k7516 
o|inlining procedure: k7531 
o|inlining procedure: k7531 
o|inlining procedure: k7591 
o|inlining procedure: k7591 
o|inlining procedure: k7656 
o|inlining procedure: k7656 
o|contracted procedure: k7672 
o|inlining procedure: k7682 
o|inlining procedure: k7682 
o|inlining procedure: k7753 
o|inlining procedure: k7753 
o|contracted procedure: k7771 
o|inlining procedure: k7768 
o|inlining procedure: k7768 
o|inlining procedure: k7996 
o|inlining procedure: k7996 
o|inlining procedure: k8031 
o|inlining procedure: k8031 
o|inlining procedure: k8073 
o|inlining procedure: k8073 
o|inlining procedure: k8108 
o|contracted procedure: "(chicken-syntax.scm:439) g11361145" 
o|inlining procedure: k8108 
o|inlining procedure: k8143 
o|inlining procedure: k8143 
o|inlining procedure: k8190 
o|contracted procedure: "(chicken-syntax.scm:435) g10761085" 
o|inlining procedure: k8190 
o|inlining procedure: k8246 
o|inlining procedure: k8246 
o|contracted procedure: k8296 
o|inlining procedure: k8293 
o|inlining procedure: k8293 
o|inlining procedure: k8321 
o|inlining procedure: k8321 
o|contracted procedure: k8330 
o|inlining procedure: k8414 
o|inlining procedure: k8446 
o|inlining procedure: k8446 
o|inlining procedure: k8414 
o|inlining procedure: k8561 
o|contracted procedure: "(chicken-syntax.scm:396) g10241033" 
o|inlining procedure: k8561 
o|inlining procedure: k8596 
o|inlining procedure: k8596 
o|contracted procedure: k8616 
o|inlining procedure: k8640 
o|inlining procedure: k8640 
o|inlining procedure: k8675 
o|inlining procedure: k8675 
o|inlining procedure: k8698 
o|inlining procedure: k8698 
o|inlining procedure: k8713 
o|inlining procedure: k8713 
o|inlining procedure: k8788 
o|contracted procedure: "(chicken-syntax.scm:353) g851858" 
o|inlining procedure: k8788 
o|inlining procedure: k8824 
o|inlining procedure: k8824 
o|inlining procedure: k8889 
o|contracted procedure: "(chicken-syntax.scm:343) g816826" 
o|inlining procedure: k8889 
o|inlining procedure: k8938 
o|inlining procedure: k8938 
o|contracted procedure: "(chicken-syntax.scm:286) pname530" 
o|inlining procedure: k9036 
o|inlining procedure: k9036 
o|removed unused formal parameters: (z638) 
o|inlining procedure: k9206 
o|inlining procedure: k9206 
o|inlining procedure: k9259 
o|inlining procedure: k9259 
o|inlining procedure: k9308 
o|inlining procedure: k9308 
o|inlining procedure: k9357 
o|removed unused parameter to known procedure: z638 "(chicken-syntax.scm:287) g627636" 
o|inlining procedure: k9357 
o|inlining procedure: k9392 
o|inlining procedure: k9392 
o|inlining procedure: k9427 
o|inlining procedure: k9427 
o|inlining procedure: k9462 
o|inlining procedure: k9462 
o|inlining procedure: k9522 
o|inlining procedure: k9537 
o|inlining procedure: k9537 
o|inlining procedure: k9522 
o|inlining procedure: k9552 
o|inlining procedure: k9573 
o|inlining procedure: k9573 
o|inlining procedure: k9552 
o|removed unused formal parameters: (x216) 
o|removed unused formal parameters: (x244) 
o|inlining procedure: k9704 
o|contracted procedure: "(chicken-syntax.scm:237) g462472" 
o|inlining procedure: k9704 
o|inlining procedure: k9753 
o|contracted procedure: "(chicken-syntax.scm:235) g426436" 
o|inlining procedure: k9753 
o|inlining procedure: k9847 
o|contracted procedure: "(chicken-syntax.scm:230) g390400" 
o|inlining procedure: k9847 
o|inlining procedure: k9896 
o|contracted procedure: "(chicken-syntax.scm:228) g354364" 
o|inlining procedure: k9896 
o|inlining procedure: k9971 
o|inlining procedure: k9971 
o|inlining procedure: k10022 
o|inlining procedure: k10022 
o|inlining procedure: k10042 
o|inlining procedure: k10042 
o|inlining procedure: k10091 
o|inlining procedure: k10091 
o|inlining procedure: k10126 
o|removed unused parameter to known procedure: x244 "(chicken-syntax.scm:218) g233242" 
o|inlining procedure: k10126 
o|inlining procedure: k10161 
o|removed unused parameter to known procedure: x216 "(chicken-syntax.scm:217) g205214" 
o|inlining procedure: k10161 
o|inlining procedure: k10196 
o|inlining procedure: k10196 
o|inlining procedure: k10274 
o|inlining procedure: k10274 
o|inlining procedure: k10351 
o|inlining procedure: k10351 
o|inlining procedure: k10379 
o|inlining procedure: k10379 
o|inlining procedure: k10482 
o|inlining procedure: k10482 
o|inlining procedure: k10594 
o|inlining procedure: k10594 
o|inlining procedure: k10615 
o|inlining procedure: k10627 
o|inlining procedure: k10627 
o|inlining procedure: k10615 
o|inlining procedure: k10679 
o|inlining procedure: k10679 
o|inlining procedure: k10739 
o|inlining procedure: k10739 
o|inlining procedure: k10828 
o|inlining procedure: k10828 
o|substituted constant variable: a10863 
o|substituted constant variable: a10888 
o|inlining procedure: k10893 
o|inlining procedure: k10893 
o|replaced variables: 1140 
o|removed binding forms: 396 
o|substituted constant variable: r354910943 
o|substituted constant variable: r388610954 
o|substituted constant variable: r388610954 
o|substituted constant variable: r396310962 
o|substituted constant variable: r404710968 
o|substituted constant variable: r372710969 
o|substituted constant variable: r426910980 
o|substituted constant variable: r425410981 
o|substituted constant variable: r437010986 
o|substituted constant variable: r431910987 
o|substituted constant variable: r449610994 
o|substituted constant variable: r449610994 
o|substituted constant variable: r443910997 
o|substituted constant variable: r469611000 
o|substituted constant variable: r469611000 
o|substituted constant variable: r479511012 
o|substituted constant variable: r478011013 
o|substituted constant variable: r484511017 
o|substituted constant variable: r496311021 
o|substituted constant variable: r556611032 
o|substituted constant variable: r572711041 
o|substituted constant variable: r578011043 
o|substituted constant variable: r606311052 
o|substituted constant variable: r606311052 
o|converted assignments to bindings: (parse-clause1758) 
o|substituted constant variable: r636611060 
o|substituted constant variable: r665711074 
o|converted assignments to bindings: (genvars1593) 
o|substituted constant variable: r707011082 
o|converted assignments to bindings: (make-if-tree1382) 
o|substituted constant variable: r750811092 
o|substituted constant variable: r776911112 
o|substituted constant variable: r832211130 
o|substituted constant variable: r1002311190 
o|substituted constant variable: r1038011211 
o|substituted constant variable: r1062811218 
o|substituted constant variable: r1061611219 
o|simplifications: ((let . 3)) 
o|replaced variables: 19 
o|removed binding forms: 1224 
o|removed call to pure procedure with unused result: "(chicken-syntax.scm:287) slot" 
o|inlining procedure: k9559 
o|inlining procedure: k9559 
o|inlining procedure: k9559 
o|removed call to pure procedure with unused result: "(chicken-syntax.scm:218) slot" 
o|removed call to pure procedure with unused result: "(chicken-syntax.scm:217) slot" 
o|replaced variables: 37 
o|removed binding forms: 54 
o|contracted procedure: k9386 
o|contracted procedure: k10155 
o|contracted procedure: k10190 
o|removed binding forms: 42 
o|removed binding forms: 3 
o|simplifications: ((if . 25) (##core#call . 1107)) 
o|  call simplifications:
o|    string?
o|    cdar
o|    caar
o|    not	3
o|    apply	2
o|    fx-	2
o|    fx>=
o|    assq	3
o|    cddddr
o|    cddr	6
o|    add1
o|    ##sys#call-with-values	2
o|    ##sys#pair?	7
o|    ##sys#eq?	7
o|    ##sys#car	15
o|    ##sys#cdr	22
o|    cdddr	2
o|    cadddr	2
o|    list?	3
o|    fx=
o|    symbol?	8
o|    null?	32
o|    vector
o|    cdr	20
o|    fx+	3
o|    ##sys#check-list	36
o|    pair?	85
o|    cons	75
o|    ##sys#setslot	47
o|    ##sys#slot	126
o|    car	46
o|    eq?	7
o|    list	9
o|    ##sys#cons	143
o|    memq	7
o|    cadr	50
o|    caddr	17
o|    ##sys#list	312
o|contracted procedure: k3595 
o|contracted procedure: k3571 
o|contracted procedure: k3575 
o|contracted procedure: k3579 
o|contracted procedure: k3567 
o|contracted procedure: k3587 
o|contracted procedure: k3591 
o|contracted procedure: k3608 
o|contracted procedure: k3716 
o|contracted procedure: k3712 
o|contracted procedure: k3621 
o|contracted procedure: k3650 
o|contracted procedure: k3655 
o|contracted procedure: k3665 
o|contracted procedure: k3670 
o|contracted procedure: k3633 
o|contracted procedure: k3629 
o|contracted procedure: k3625 
o|contracted procedure: k3682 
o|contracted procedure: k3685 
o|contracted procedure: k3696 
o|contracted procedure: k3708 
o|contracted procedure: k4082 
o|contracted procedure: k3735 
o|contracted procedure: k3738 
o|contracted procedure: k3757 
o|contracted procedure: k3769 
o|contracted procedure: k3778 
o|contracted procedure: k3866 
o|contracted procedure: k3870 
o|contracted procedure: k3788 
o|contracted procedure: k3796 
o|contracted procedure: k3800 
o|contracted procedure: k3792 
o|contracted procedure: k3859 
o|contracted procedure: k3822 
o|contracted procedure: k3825 
o|contracted procedure: k3836 
o|contracted procedure: k3840 
o|contracted procedure: k3852 
o|contracted procedure: k3856 
o|contracted procedure: k3810 
o|contracted procedure: k3889 
o|contracted procedure: k3878 
o|contracted procedure: k3896 
o|contracted procedure: k3908 
o|contracted procedure: k3920 
o|contracted procedure: k3923 
o|contracted procedure: k3934 
o|contracted procedure: k3946 
o|contracted procedure: k3965 
o|contracted procedure: k3972 
o|contracted procedure: k3980 
o|contracted procedure: k3984 
o|contracted procedure: k3987 
o|contracted procedure: k3993 
o|contracted procedure: k4002 
o|contracted procedure: k4006 
o|contracted procedure: k4037 
o|contracted procedure: k4021 
o|contracted procedure: k4025 
o|contracted procedure: k4033 
o|contracted procedure: k4043 
o|contracted procedure: k4049 
o|contracted procedure: k4056 
o|contracted procedure: k4078 
o|contracted procedure: k4067 
o|contracted procedure: k4092 
o|contracted procedure: k4106 
o|contracted procedure: k4109 
o|contracted procedure: k4124 
o|contracted procedure: k4127 
o|contracted procedure: k4133 
o|contracted procedure: k4144 
o|contracted procedure: k4174 
o|contracted procedure: k4170 
o|contracted procedure: k4162 
o|contracted procedure: k4158 
o|contracted procedure: k4183 
o|contracted procedure: k4186 
o|contracted procedure: k4197 
o|contracted procedure: k4209 
o|contracted procedure: k4121 
o|contracted procedure: k4218 
o|contracted procedure: k4244 
o|contracted procedure: k4240 
o|contracted procedure: k4221 
o|contracted procedure: k4232 
o|contracted procedure: k4250 
o|contracted procedure: k4278 
o|contracted procedure: k4297 
o|contracted procedure: k4305 
o|contracted procedure: k4309 
o|contracted procedure: k4328 
o|contracted procedure: k4346 
o|contracted procedure: k4356 
o|contracted procedure: k4363 
o|contracted procedure: k4366 
o|contracted procedure: k4372 
o|contracted procedure: k4379 
o|contracted procedure: k4383 
o|contracted procedure: k4387 
o|contracted procedure: k4425 
o|contracted procedure: k4417 
o|contracted procedure: k4421 
o|contracted procedure: k4533 
o|contracted procedure: k4447 
o|contracted procedure: k4525 
o|contracted procedure: k4521 
o|contracted procedure: k4517 
o|contracted procedure: k4483 
o|contracted procedure: k4479 
o|contracted procedure: k4506 
o|contracted procedure: k4502 
o|contracted procedure: k4495 
o|contracted procedure: k4513 
o|contracted procedure: k4529 
o|contracted procedure: k4549 
o|contracted procedure: k4552 
o|contracted procedure: k4555 
o|contracted procedure: k4576 
o|contracted procedure: k4612 
o|contracted procedure: k4580 
o|contracted procedure: k4584 
o|contracted procedure: k4588 
o|contracted procedure: k4561 
o|contracted procedure: k4568 
o|contracted procedure: k4572 
o|contracted procedure: k4624 
o|contracted procedure: k4627 
o|contracted procedure: k4638 
o|contracted procedure: k4650 
o|contracted procedure: k4598 
o|contracted procedure: k4608 
o|contracted procedure: k4680 
o|contracted procedure: k4684 
o|contracted procedure: k4676 
o|contracted procedure: k4698 
o|contracted procedure: k4704 
o|inlining procedure: k4695 
o|contracted procedure: k4713 
o|contracted procedure: k4723 
o|contracted procedure: k4727 
o|contracted procedure: k4730 
o|contracted procedure: k4737 
o|contracted procedure: k4747 
o|contracted procedure: k4756 
o|contracted procedure: k4759 
o|contracted procedure: k4770 
o|contracted procedure: k4776 
o|contracted procedure: k4804 
o|contracted procedure: k4823 
o|contracted procedure: k4831 
o|contracted procedure: k4835 
o|contracted procedure: k4854 
o|contracted procedure: k4873 
o|contracted procedure: k4881 
o|contracted procedure: k4885 
o|contracted procedure: k4895 
o|contracted procedure: k4904 
o|contracted procedure: k4919 
o|contracted procedure: k4915 
o|contracted procedure: k4928 
o|contracted procedure: k4950 
o|contracted procedure: k4931 
o|contracted procedure: k4946 
o|contracted procedure: k4942 
o|contracted procedure: k4956 
o|contracted procedure: k4959 
o|contracted procedure: k4965 
o|contracted procedure: k4972 
o|contracted procedure: k4975 
o|contracted procedure: k4982 
o|contracted procedure: k5003 
o|contracted procedure: k5020 
o|contracted procedure: k5049 
o|contracted procedure: k5041 
o|contracted procedure: k5062 
o|contracted procedure: k5068 
o|contracted procedure: k5091 
o|contracted procedure: k5087 
o|contracted procedure: k5081 
o|contracted procedure: k5075 
o|contracted procedure: k5107 
o|contracted procedure: k5103 
o|contracted procedure: k5305 
o|contracted procedure: k5114 
o|contracted procedure: k5147 
o|contracted procedure: k5182 
o|contracted procedure: k5178 
o|contracted procedure: k5174 
o|contracted procedure: k5166 
o|contracted procedure: k5192 
o|contracted procedure: k5211 
o|contracted procedure: k5207 
o|contracted procedure: k5203 
o|contracted procedure: k5231 
o|contracted procedure: k5235 
o|contracted procedure: k5251 
o|contracted procedure: k5279 
o|contracted procedure: k5271 
o|contracted procedure: k5275 
o|contracted procedure: k5291 
o|contracted procedure: k5301 
o|contracted procedure: k5294 
o|contracted procedure: k5485 
o|contracted procedure: k5313 
o|contracted procedure: k5346 
o|contracted procedure: k5377 
o|contracted procedure: k5373 
o|contracted procedure: k5369 
o|contracted procedure: k5387 
o|contracted procedure: k5408 
o|contracted procedure: k5402 
o|contracted procedure: k5398 
o|contracted procedure: k5426 
o|contracted procedure: k5430 
o|contracted procedure: k5446 
o|contracted procedure: k5463 
o|contracted procedure: k5471 
o|contracted procedure: k5481 
o|contracted procedure: k5474 
o|contracted procedure: k5862 
o|contracted procedure: k5493 
o|contracted procedure: k5506 
o|contracted procedure: k5509 
o|contracted procedure: k5512 
o|contracted procedure: k5515 
o|contracted procedure: k5524 
o|contracted procedure: k5533 
o|contracted procedure: k5773 
o|contracted procedure: k5782 
o|contracted procedure: k5785 
o|contracted procedure: k5769 
o|contracted procedure: k5765 
o|contracted procedure: k5547 
o|contracted procedure: k5753 
o|contracted procedure: k5761 
o|contracted procedure: k5757 
o|contracted procedure: k5555 
o|contracted procedure: k5551 
o|contracted procedure: k5543 
o|contracted procedure: k5568 
o|contracted procedure: k5571 
o|contracted procedure: k5749 
o|contracted procedure: k5574 
o|contracted procedure: k5577 
o|contracted procedure: k5696 
o|contracted procedure: k5712 
o|contracted procedure: k5720 
o|contracted procedure: k5716 
o|contracted procedure: k5708 
o|contracted procedure: k5700 
o|contracted procedure: k5704 
o|contracted procedure: k5583 
o|contracted procedure: k5611 
o|contracted procedure: k5631 
o|contracted procedure: k5627 
o|contracted procedure: k5639 
o|contracted procedure: k5646 
o|contracted procedure: k5653 
o|contracted procedure: k5672 
o|contracted procedure: k5688 
o|contracted procedure: k5692 
o|contracted procedure: k5684 
o|contracted procedure: k5676 
o|contracted procedure: k5680 
o|contracted procedure: k5723 
o|contracted procedure: k5729 
o|contracted procedure: k5797 
o|contracted procedure: k5800 
o|contracted procedure: k5811 
o|contracted procedure: k5823 
o|contracted procedure: k5832 
o|contracted procedure: k5858 
o|contracted procedure: k5854 
o|contracted procedure: k5835 
o|contracted procedure: k5846 
o|contracted procedure: k6135 
o|contracted procedure: k6139 
o|contracted procedure: k5870 
o|contracted procedure: k5913 
o|contracted procedure: k5937 
o|contracted procedure: k5940 
o|contracted procedure: k5927 
o|contracted procedure: k5923 
o|contracted procedure: k5952 
o|contracted procedure: k5955 
o|contracted procedure: k5966 
o|contracted procedure: k5978 
o|contracted procedure: k5997 
o|contracted procedure: k5989 
o|contracted procedure: k5993 
o|contracted procedure: k5985 
o|contracted procedure: k6004 
o|contracted procedure: k6018 
o|contracted procedure: k6013 
o|contracted procedure: k6131 
o|contracted procedure: k6123 
o|contracted procedure: k6127 
o|contracted procedure: k6119 
o|contracted procedure: k6115 
o|contracted procedure: k6037 
o|contracted procedure: k6041 
o|contracted procedure: k6044 
o|contracted procedure: k6050 
o|contracted procedure: k6029 
o|contracted procedure: k6033 
o|contracted procedure: k6065 
o|contracted procedure: k6076 
o|contracted procedure: k6072 
o|contracted procedure: k6062 
o|contracted procedure: k6085 
o|contracted procedure: k6088 
o|contracted procedure: k6099 
o|contracted procedure: k6111 
o|contracted procedure: k6258 
o|contracted procedure: k6262 
o|contracted procedure: k6151 
o|contracted procedure: k6186 
o|contracted procedure: k6254 
o|contracted procedure: k6238 
o|contracted procedure: k6250 
o|contracted procedure: k6246 
o|contracted procedure: k6242 
o|contracted procedure: k6198 
o|contracted procedure: k6230 
o|contracted procedure: k6210 
o|contracted procedure: k6226 
o|contracted procedure: k6222 
o|contracted procedure: k6218 
o|contracted procedure: k6214 
o|contracted procedure: k6206 
o|contracted procedure: k6202 
o|contracted procedure: k6190 
o|contracted procedure: k6182 
o|contracted procedure: k6174 
o|contracted procedure: k6283 
o|contracted procedure: k6291 
o|contracted procedure: k6317 
o|contracted procedure: k6301 
o|contracted procedure: k6313 
o|contracted procedure: k6309 
o|contracted procedure: k6305 
o|contracted procedure: k6321 
o|contracted procedure: k6335 
o|contracted procedure: k6331 
o|contracted procedure: k6339 
o|contracted procedure: k6741 
o|contracted procedure: k6745 
o|contracted procedure: k6749 
o|contracted procedure: k6753 
o|contracted procedure: k6757 
o|contracted procedure: k6343 
o|contracted procedure: k6368 
o|contracted procedure: k6383 
o|contracted procedure: k6680 
o|contracted procedure: k6676 
o|contracted procedure: k6432 
o|contracted procedure: k6428 
o|contracted procedure: k6446 
o|contracted procedure: k6459 
o|contracted procedure: k6488 
o|contracted procedure: k6495 
o|contracted procedure: k6498 
o|contracted procedure: k6547 
o|contracted procedure: k6510 
o|contracted procedure: k6540 
o|contracted procedure: k6544 
o|contracted procedure: k6536 
o|contracted procedure: k6513 
o|contracted procedure: k6524 
o|contracted procedure: k6528 
o|contracted procedure: k6559 
o|contracted procedure: k6581 
o|contracted procedure: k6573 
o|contracted procedure: k6577 
o|contracted procedure: k6569 
o|contracted procedure: k6602 
o|contracted procedure: k6587 
o|contracted procedure: k6596 
o|contracted procedure: k6645 
o|contracted procedure: k6649 
o|contracted procedure: k6633 
o|contracted procedure: k6641 
o|contracted procedure: k6637 
o|contracted procedure: k6612 
o|contracted procedure: k6619 
o|contracted procedure: k6659 
o|contracted procedure: k6670 
o|contracted procedure: k6696 
o|contracted procedure: k6699 
o|contracted procedure: k6711 
o|contracted procedure: k6714 
o|contracted procedure: k6725 
o|contracted procedure: k6737 
o|contracted procedure: k6690 
o|contracted procedure: k6929 
o|contracted procedure: k6781 
o|contracted procedure: k6794 
o|contracted procedure: k6797 
o|contracted procedure: k6925 
o|contracted procedure: k6819 
o|contracted procedure: k6832 
o|contracted procedure: k6839 
o|contracted procedure: k6842 
o|contracted procedure: k6848 
o|contracted procedure: k6898 
o|contracted procedure: k6902 
o|contracted procedure: k6906 
o|contracted procedure: k6894 
o|contracted procedure: k6868 
o|contracted procedure: k6880 
o|contracted procedure: k6884 
o|contracted procedure: k6888 
o|contracted procedure: k6876 
o|contracted procedure: k6872 
o|contracted procedure: k6858 
o|contracted procedure: k6921 
o|contracted procedure: k6917 
o|contracted procedure: k6913 
o|contracted procedure: k7002 
o|contracted procedure: k7006 
o|contracted procedure: k7010 
o|contracted procedure: k6937 
o|contracted procedure: k6998 
o|contracted procedure: k6994 
o|contracted procedure: k6957 
o|contracted procedure: k6965 
o|contracted procedure: k6969 
o|contracted procedure: k6983 
o|contracted procedure: k6972 
o|contracted procedure: k6976 
o|contracted procedure: k6961 
o|contracted procedure: k7454 
o|contracted procedure: k7458 
o|contracted procedure: k7026 
o|contracted procedure: k7039 
o|contracted procedure: k7042 
o|contracted procedure: k7139 
o|contracted procedure: k7149 
o|contracted procedure: k7156 
o|contracted procedure: k7208 
o|contracted procedure: k7160 
o|contracted procedure: k7200 
o|contracted procedure: k7184 
o|contracted procedure: k7192 
o|contracted procedure: k7188 
o|contracted procedure: k7168 
o|contracted procedure: k7164 
o|contracted procedure: k7180 
o|contracted procedure: k7221 
o|contracted procedure: k7249 
o|contracted procedure: k7294 
o|contracted procedure: k7310 
o|contracted procedure: k7306 
o|contracted procedure: k7302 
o|contracted procedure: k7298 
o|contracted procedure: k7290 
o|contracted procedure: k7072 
o|contracted procedure: k7075 
o|contracted procedure: k7096 
o|contracted procedure: k7108 
o|contracted procedure: k7100 
o|contracted procedure: k7082 
o|contracted procedure: k7124 
o|contracted procedure: k7120 
o|contracted procedure: k7319 
o|contracted procedure: k7322 
o|contracted procedure: k7333 
o|contracted procedure: k7345 
o|contracted procedure: k7354 
o|contracted procedure: k7380 
o|contracted procedure: k7376 
o|contracted procedure: k7357 
o|contracted procedure: k7368 
o|contracted procedure: k7389 
o|contracted procedure: k7392 
o|contracted procedure: k7403 
o|contracted procedure: k7415 
o|contracted procedure: k7424 
o|contracted procedure: k7450 
o|contracted procedure: k7446 
o|contracted procedure: k7427 
o|contracted procedure: k7438 
o|contracted procedure: k7479 
o|contracted procedure: k7632 
o|contracted procedure: k7497 
o|contracted procedure: k7510 
o|contracted procedure: k7628 
o|contracted procedure: k7522 
o|contracted procedure: k7525 
o|contracted procedure: k7582 
o|contracted procedure: k7562 
o|contracted procedure: k7566 
o|contracted procedure: k7594 
o|contracted procedure: k7597 
o|contracted procedure: k7608 
o|contracted procedure: k7620 
o|contracted procedure: k7624 
o|contracted procedure: k7645 
o|contracted procedure: k7659 
o|contracted procedure: k7665 
o|contracted procedure: k7729 
o|contracted procedure: k7725 
o|contracted procedure: k7685 
o|contracted procedure: k7721 
o|contracted procedure: k7717 
o|contracted procedure: k7705 
o|contracted procedure: k7709 
o|contracted procedure: k7744 
o|contracted procedure: k7816 
o|contracted procedure: k7747 
o|contracted procedure: k7796 
o|contracted procedure: k7759 
o|contracted procedure: k7792 
o|contracted procedure: k7788 
o|contracted procedure: k7799 
o|contracted procedure: k7806 
o|contracted procedure: k7829 
o|contracted procedure: k7877 
o|contracted procedure: k7833 
o|contracted procedure: k7873 
o|contracted procedure: k7853 
o|contracted procedure: k7869 
o|contracted procedure: k7861 
o|contracted procedure: k7857 
o|contracted procedure: k7894 
o|contracted procedure: k7915 
o|contracted procedure: k7927 
o|contracted procedure: k7934 
o|contracted procedure: k8064 
o|contracted procedure: k7957 
o|contracted procedure: k7970 
o|contracted procedure: k7987 
o|contracted procedure: k7965 
o|contracted procedure: k7961 
o|contracted procedure: k7999 
o|contracted procedure: k8002 
o|contracted procedure: k8013 
o|contracted procedure: k8025 
o|contracted procedure: k8034 
o|contracted procedure: k8037 
o|contracted procedure: k8048 
o|contracted procedure: k8060 
o|contracted procedure: k8076 
o|contracted procedure: k8079 
o|contracted procedure: k8090 
o|contracted procedure: k8102 
o|contracted procedure: k8111 
o|contracted procedure: k8137 
o|contracted procedure: k8133 
o|contracted procedure: k8114 
o|contracted procedure: k8125 
o|contracted procedure: k8146 
o|contracted procedure: k8149 
o|contracted procedure: k8160 
o|contracted procedure: k8172 
o|contracted procedure: k8181 
o|contracted procedure: k8193 
o|contracted procedure: k8219 
o|contracted procedure: k8215 
o|contracted procedure: k8196 
o|contracted procedure: k8207 
o|contracted procedure: k8232 
o|contracted procedure: k8249 
o|contracted procedure: k8256 
o|contracted procedure: k8273 
o|contracted procedure: k8263 
o|contracted procedure: k8286 
o|contracted procedure: k8316 
o|contracted procedure: k8306 
o|contracted procedure: k8324 
o|contracted procedure: k8354 
o|contracted procedure: k8350 
o|contracted procedure: k8359 
o|contracted procedure: k8381 
o|contracted procedure: k8393 
o|contracted procedure: k8417 
o|contracted procedure: k8437 
o|contracted procedure: k8424 
o|contracted procedure: k8449 
o|contracted procedure: k8452 
o|contracted procedure: k8463 
o|contracted procedure: k8475 
o|contracted procedure: k8508 
o|contracted procedure: k8512 
o|contracted procedure: k8504 
o|contracted procedure: k8488 
o|contracted procedure: k8496 
o|contracted procedure: k8541 
o|contracted procedure: k8519 
o|contracted procedure: k8523 
o|contracted procedure: k8533 
o|contracted procedure: k8555 
o|contracted procedure: k8544 
o|contracted procedure: k8551 
o|contracted procedure: k8564 
o|contracted procedure: k8590 
o|contracted procedure: k8586 
o|contracted procedure: k8567 
o|contracted procedure: k8578 
o|contracted procedure: k8599 
o|contracted procedure: k8605 
o|contracted procedure: k8634 
o|inlining procedure: k8608 
o|inlining procedure: k8608 
o|contracted procedure: k8643 
o|contracted procedure: k8646 
o|contracted procedure: k8657 
o|contracted procedure: k8669 
o|contracted procedure: k8678 
o|contracted procedure: k8681 
o|contracted procedure: k8692 
o|contracted procedure: k8701 
o|inlining procedure: k8684 
o|contracted procedure: k8716 
o|contracted procedure: k8742 
o|contracted procedure: k8738 
o|contracted procedure: k8719 
o|contracted procedure: k8730 
o|contracted procedure: k8767 
o|contracted procedure: k8770 
o|contracted procedure: k8791 
o|contracted procedure: k8801 
o|contracted procedure: k8805 
o|contracted procedure: k8818 
o|contracted procedure: k8821 
o|contracted procedure: k8827 
o|contracted procedure: k8834 
o|contracted procedure: k8842 
o|contracted procedure: k8838 
o|contracted procedure: k8971 
o|contracted procedure: k8848 
o|contracted procedure: k8863 
o|contracted procedure: k8880 
o|contracted procedure: k8871 
o|contracted procedure: k8867 
o|contracted procedure: k8929 
o|contracted procedure: k8892 
o|contracted procedure: k8922 
o|contracted procedure: k8926 
o|contracted procedure: k8918 
o|contracted procedure: k8895 
o|contracted procedure: k8906 
o|contracted procedure: k8910 
o|contracted procedure: k8941 
o|contracted procedure: k8944 
o|contracted procedure: k8955 
o|contracted procedure: k8967 
o|contracted procedure: k8988 
o|contracted procedure: k8992 
o|contracted procedure: k8996 
o|contracted procedure: k9016 
o|contracted procedure: k9020 
o|contracted procedure: k9051 
o|contracted procedure: k9062 
o|contracted procedure: k9039 
o|contracted procedure: k9080 
o|contracted procedure: k9102 
o|contracted procedure: k9113 
o|contracted procedure: k9116 
o|contracted procedure: k9253 
o|contracted procedure: k9127 
o|contracted procedure: k9159 
o|contracted procedure: k9155 
o|contracted procedure: k9151 
o|contracted procedure: k9135 
o|contracted procedure: k9147 
o|contracted procedure: k9143 
o|contracted procedure: k9139 
o|contracted procedure: k9131 
o|contracted procedure: k9123 
o|contracted procedure: k9109 
o|contracted procedure: k9189 
o|contracted procedure: k9185 
o|contracted procedure: k9173 
o|contracted procedure: k9177 
o|contracted procedure: k9181 
o|contracted procedure: k9200 
o|contracted procedure: k9196 
o|contracted procedure: k9246 
o|contracted procedure: k9209 
o|contracted procedure: k9212 
o|contracted procedure: k9223 
o|contracted procedure: k9227 
o|contracted procedure: k9239 
o|contracted procedure: k9243 
o|contracted procedure: k9299 
o|contracted procedure: k9262 
o|contracted procedure: k9292 
o|contracted procedure: k9296 
o|contracted procedure: k9288 
o|contracted procedure: k9265 
o|contracted procedure: k9276 
o|contracted procedure: k9280 
o|contracted procedure: k9348 
o|contracted procedure: k9311 
o|contracted procedure: k9341 
o|contracted procedure: k9345 
o|contracted procedure: k9337 
o|contracted procedure: k9314 
o|contracted procedure: k9325 
o|contracted procedure: k9329 
o|contracted procedure: k9360 
o|contracted procedure: k9363 
o|contracted procedure: k9374 
o|contracted procedure: k9395 
o|contracted procedure: k9398 
o|contracted procedure: k9409 
o|contracted procedure: k9421 
o|contracted procedure: k9430 
o|contracted procedure: k9456 
o|contracted procedure: k9452 
o|contracted procedure: k9433 
o|contracted procedure: k9444 
o|contracted procedure: k9465 
o|contracted procedure: k9491 
o|contracted procedure: k9487 
o|contracted procedure: k9468 
o|contracted procedure: k9479 
o|contracted procedure: k9504 
o|contracted procedure: k9507 
o|contracted procedure: k9525 
o|contracted procedure: k9531 
o|contracted procedure: k9555 
o|contracted procedure: k9566 
o|contracted procedure: k956611516 
o|contracted procedure: k956611520 
o|contracted procedure: k956611524 
o|contracted procedure: k9605 
o|contracted procedure: k9610 
o|contracted procedure: k9804 
o|contracted procedure: k9652 
o|contracted procedure: k9800 
o|contracted procedure: k9656 
o|contracted procedure: k9664 
o|contracted procedure: k9660 
o|contracted procedure: k9648 
o|contracted procedure: k9698 
o|contracted procedure: k9694 
o|contracted procedure: k9744 
o|contracted procedure: k9707 
o|contracted procedure: k9737 
o|contracted procedure: k9741 
o|contracted procedure: k9733 
o|contracted procedure: k9710 
o|contracted procedure: k9721 
o|contracted procedure: k9725 
o|contracted procedure: k9793 
o|contracted procedure: k9756 
o|contracted procedure: k9786 
o|contracted procedure: k9790 
o|contracted procedure: k9782 
o|contracted procedure: k9759 
o|contracted procedure: k9770 
o|contracted procedure: k9774 
o|contracted procedure: k9817 
o|contracted procedure: k9841 
o|contracted procedure: k9837 
o|contracted procedure: k9887 
o|contracted procedure: k9850 
o|contracted procedure: k9880 
o|contracted procedure: k9884 
o|contracted procedure: k9876 
o|contracted procedure: k9853 
o|contracted procedure: k9864 
o|contracted procedure: k9868 
o|contracted procedure: k9936 
o|contracted procedure: k9899 
o|contracted procedure: k9929 
o|contracted procedure: k9933 
o|contracted procedure: k9925 
o|contracted procedure: k9902 
o|contracted procedure: k9913 
o|contracted procedure: k9917 
o|contracted procedure: k9946 
o|contracted procedure: k9949 
o|contracted procedure: k9959 
o|contracted procedure: k9962 
o|contracted procedure: k10011 
o|contracted procedure: k9974 
o|contracted procedure: k10004 
o|contracted procedure: k10008 
o|contracted procedure: k10000 
o|contracted procedure: k9977 
o|contracted procedure: k9988 
o|contracted procedure: k9992 
o|contracted procedure: k10025 
o|contracted procedure: k10036 
o|contracted procedure: k10082 
o|contracted procedure: k10045 
o|contracted procedure: k10075 
o|contracted procedure: k10079 
o|contracted procedure: k10071 
o|contracted procedure: k10048 
o|contracted procedure: k10059 
o|contracted procedure: k10063 
o|contracted procedure: k10094 
o|contracted procedure: k10120 
o|contracted procedure: k10116 
o|contracted procedure: k10097 
o|contracted procedure: k10108 
o|contracted procedure: k10129 
o|contracted procedure: k10132 
o|contracted procedure: k10143 
o|contracted procedure: k10164 
o|contracted procedure: k10167 
o|contracted procedure: k10178 
o|contracted procedure: k10199 
o|contracted procedure: k10225 
o|contracted procedure: k10221 
o|contracted procedure: k10202 
o|contracted procedure: k10213 
o|contracted procedure: k10238 
o|contracted procedure: k10241 
o|contracted procedure: k10300 
o|contracted procedure: k10254 
o|contracted procedure: k10296 
o|contracted procedure: k10262 
o|contracted procedure: k10266 
o|contracted procedure: k10258 
o|contracted procedure: k10277 
o|contracted procedure: k10292 
o|contracted procedure: k10284 
o|contracted procedure: k10288 
o|contracted procedure: k10274 
o|contracted procedure: k10313 
o|contracted procedure: k10386 
o|contracted procedure: k10318 
o|contracted procedure: k10370 
o|contracted procedure: k10331 
o|contracted procedure: k10339 
o|contracted procedure: k10343 
o|contracted procedure: k10335 
o|contracted procedure: k10354 
o|contracted procedure: k10362 
o|contracted procedure: k10351 
o|contracted procedure: k10373 
o|contracted procedure: k10406 
o|contracted procedure: k10420 
o|contracted procedure: k10437 
o|contracted procedure: k10469 
o|contracted procedure: k10465 
o|contracted procedure: k10445 
o|contracted procedure: k10461 
o|contracted procedure: k10453 
o|contracted procedure: k10457 
o|contracted procedure: k10449 
o|contracted procedure: k10441 
o|contracted procedure: k10562 
o|contracted procedure: k10485 
o|contracted procedure: k10496 
o|contracted procedure: k10492 
o|contracted procedure: k10504 
o|contracted procedure: k10507 
o|contracted procedure: k10535 
o|contracted procedure: k10531 
o|contracted procedure: k10527 
o|contracted procedure: k10523 
o|contracted procedure: k10542 
o|contracted procedure: k10550 
o|contracted procedure: k10546 
o|contracted procedure: k10553 
o|contracted procedure: k10575 
o|contracted procedure: k10597 
o|contracted procedure: k10612 
o|contracted procedure: k10624 
o|contracted procedure: k10640 
o|contracted procedure: k10630 
o|inlining procedure: k10603 
o|inlining procedure: k10603 
o|inlining procedure: k10603 
o|inlining procedure: k10603 
o|inlining procedure: k10603 
o|contracted procedure: k10647 
o|contracted procedure: k10881 
o|contracted procedure: k10877 
o|contracted procedure: k10873 
o|contracted procedure: k10869 
o|contracted procedure: k10661 
o|contracted procedure: k10847 
o|contracted procedure: k10855 
o|contracted procedure: k10851 
o|contracted procedure: k10843 
o|contracted procedure: k10669 
o|contracted procedure: k10665 
o|contracted procedure: k10657 
o|contracted procedure: k10682 
o|contracted procedure: k10685 
o|contracted procedure: k10835 
o|contracted procedure: k10688 
o|contracted procedure: k10800 
o|contracted procedure: k10816 
o|contracted procedure: k10812 
o|contracted procedure: k10804 
o|contracted procedure: k10808 
o|contracted procedure: k10700 
o|contracted procedure: k10707 
o|contracted procedure: k10715 
o|contracted procedure: k10719 
o|contracted procedure: k10735 
o|contracted procedure: k10731 
o|contracted procedure: k10750 
o|contracted procedure: k10766 
o|contracted procedure: k10762 
o|contracted procedure: k10754 
o|contracted procedure: k10758 
o|contracted procedure: k10746 
o|contracted procedure: k10773 
o|contracted procedure: k10789 
o|contracted procedure: k10785 
o|contracted procedure: k10777 
o|contracted procedure: k10781 
o|contracted procedure: k10796 
o|contracted procedure: k10828 
o|contracted procedure: k10896 
o|contracted procedure: k10899 
o|contracted procedure: k10910 
o|contracted procedure: k10922 
o|contracted procedure: k10939 
o|simplifications: ((let . 109)) 
o|removed binding forms: 912 
o|inlining procedure: k3646 
o|inlining procedure: k3646 
o|inlining procedure: k3688 
o|inlining procedure: k3688 
o|inlining procedure: k3926 
o|inlining procedure: k3926 
o|inlining procedure: k4189 
o|inlining procedure: k4189 
o|inlining procedure: k4224 
o|inlining procedure: k4224 
o|inlining procedure: k4630 
o|inlining procedure: k4630 
o|inlining procedure: k4688 
o|inlining procedure: k4688 
o|inlining procedure: k4688 
o|inlining procedure: k5803 
o|inlining procedure: k5803 
o|inlining procedure: k5838 
o|inlining procedure: k5838 
o|inlining procedure: k5958 
o|inlining procedure: k5958 
o|inlining procedure: k6091 
o|inlining procedure: k6091 
o|inlining procedure: k6717 
o|inlining procedure: k6717 
o|inlining procedure: k7325 
o|inlining procedure: k7325 
o|inlining procedure: k7360 
o|inlining procedure: k7360 
o|inlining procedure: k7395 
o|inlining procedure: k7395 
o|inlining procedure: k7430 
o|inlining procedure: k7430 
o|inlining procedure: k7600 
o|inlining procedure: k7600 
o|inlining procedure: k8005 
o|inlining procedure: k8005 
o|inlining procedure: k8040 
o|inlining procedure: k8040 
o|inlining procedure: k8082 
o|inlining procedure: k8082 
o|inlining procedure: k8117 
o|inlining procedure: k8117 
o|inlining procedure: k8152 
o|inlining procedure: k8152 
o|inlining procedure: k8199 
o|inlining procedure: k8199 
o|inlining procedure: k8455 
o|inlining procedure: k8455 
o|inlining procedure: k8570 
o|inlining procedure: k8570 
o|inlining procedure: k8649 
o|inlining procedure: k8649 
o|inlining procedure: k8722 
o|inlining procedure: k8722 
o|inlining procedure: k8947 
o|inlining procedure: k8947 
o|inlining procedure: k9366 
o|inlining procedure: k9366 
o|inlining procedure: k9401 
o|inlining procedure: k9401 
o|inlining procedure: k9436 
o|inlining procedure: k9436 
o|inlining procedure: k9471 
o|inlining procedure: k9471 
o|inlining procedure: k10100 
o|inlining procedure: k10100 
o|inlining procedure: k10135 
o|inlining procedure: k10135 
o|inlining procedure: k10170 
o|inlining procedure: k10170 
o|inlining procedure: k10205 
o|inlining procedure: k10205 
o|substituted constant variable: r1060412270 
o|substituted constant variable: r1060412271 
o|substituted constant variable: r1060412272 
o|substituted constant variable: r1060412273 
o|inlining procedure: k10739 
o|inlining procedure: k10739 
o|inlining procedure: k10902 
o|inlining procedure: k10902 
o|simplifications: ((let . 1)) 
o|replaced variables: 237 
o|removed binding forms: 2 
o|removed conditional forms: 4 
o|substituted constant variable: r364712278 
o|substituted constant variable: r364712278 
o|replaced variables: 1 
o|removed binding forms: 238 
o|contracted procedure: k3848 
o|contracted procedure: k4205 
o|replaced variables: 142 
o|removed binding forms: 5 
o|removed binding forms: 36 
o|direct leaf routine/allocation: g18971906 0 
o|direct leaf routine/allocation: g17841793 15 
o|direct leaf routine/allocation: g13471356 9 
o|direct leaf routine/allocation: g719729 42 
o|contracted procedure: "(chicken-syntax.scm:935) k5819" 
o|contracted procedure: "(chicken-syntax.scm:894) k5974" 
o|contracted procedure: "(chicken-syntax.scm:532) k7616" 
o|contracted procedure: "(chicken-syntax.scm:297) k9235" 
o|removed binding forms: 4 
o|customizable procedures: (g3140 map-loop2551 k10727 mapslots61 k10516 k10324 k10347 k10270 map-loop172189 g205214 map-loop199217 g233242 map-loop227245 map-loop278295 k10051 map-loop257302 loop333 k9980 map-loop314336 k9905 map-loop348372 k9856 map-loop384408 k9762 map-loop420444 k9713 map-loop456480 loop505 map-loop539556 map-loop566583 g599608 map-loop593611 g627636 map-loop621639 k9317 map-loop651670 k9268 map-loop682701 k9215 map-loop713737 map-loop781798 k8898 map-loop810834 for-each-loop850862 map-loop894911 loop919 g938947 map-loop932950 loop960 map-loop10181036 k8481 fold970 g989998 map-loop9831001 fold1052 map-loop10701088 g11041113 map-loop10981116 map-loop11301148 g11631172 map-loop11571234 map-loop11801197 g12121221 map-loop12061227 quotify-proc12561258 k7750 k7762 fold1282 map-loop13411362 expand1317 map-loop14181435 g14541463 map-loop14481466 map-loop14761493 g15111520 map-loop15051523 recur1388 make-if-tree1382 prefix-sym1442 recur1403 loop1571 map-loop16011622 genvars1593 k6462 build1658 k6516 map-loop16811700 loop1595 map-loop18091826 k5901 k5904 k5907 map-loop17781799 map-loop18621879 map-loop18911909 k5580 k5586 k5593 k5601 loop1916 loop1960 loop1990 k4901 k4925 loop20892110 loop20892121 map-loop21632183 k4491 k4349 loop22422263 loop22422279 map-loop22902308 map-loop23182336 k4012 loop2363 loop22377 map-loop23842409 k3893 k3828 map-loop24242448 g24852494 map-loop24792501) 
o|calls to known targets: 307 
o|identified direct recursive calls: f_3960 1 
o|identified direct recursive calls: f_3764 1 
o|identified direct recursive calls: f_4178 2 
o|identified direct recursive calls: f_4213 2 
o|identified direct recursive calls: f_5792 2 
o|identified direct recursive calls: f_5827 2 
o|identified direct recursive calls: f_5947 2 
o|identified direct recursive calls: f_7349 2 
o|identified direct recursive calls: f_7419 2 
o|identified direct recursive calls: f_7589 2 
o|identified direct recursive calls: f_7654 2 
o|identified direct recursive calls: f_8106 2 
o|identified direct recursive calls: f_8188 2 
o|identified direct recursive calls: f_8244 1 
o|identified direct recursive calls: f_8559 2 
o|identified direct recursive calls: f_8673 1 
o|identified direct recursive calls: f_8711 2 
o|identified direct recursive calls: f_9425 2 
o|identified direct recursive calls: f_9460 2 
o|identified direct recursive calls: f_10020 1 
o|identified direct recursive calls: f_10089 2 
o|identified direct recursive calls: f_10194 2 
o|fast box initializations: 73 
o|dropping unused closure argument: f_7227 
*/
/* end of file */
