/* Generated from optimizer.scm by the CHICKEN compiler
   http://www.call-cc.org
   2014-06-02 16:39
   Version 4.9.0 (rev 3f195ba)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2014-06-02 on yves (Linux)
   command line: optimizer.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -no-lambda-info -local -no-trace -extend private-namespace.scm -no-trace -output-file optimizer.c
   unit: optimizer
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_chicken_2dsyntax_toplevel)
C_externimport void C_ccall C_chicken_2dsyntax_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[229];
static double C_possibly_force_alignment;


C_noret_decl(f_11176)
static void C_fcall f_11176(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7711)
static void C_ccall f_7711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9507)
static void C_ccall f_9507(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9212)
static void C_ccall f_9212(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7719)
static void C_ccall f_7719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10846)
static void C_ccall f_10846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11479)
static void C_ccall f_11479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11472)
static void C_ccall f_11472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6338)
static void C_ccall f_6338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6332)
static void C_ccall f_6332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10864)
static void C_ccall f_10864(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7590)
static void C_ccall f_7590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10679)
static void C_ccall f_10679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7599)
static void C_fcall f_7599(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10676)
static void C_ccall f_10676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5407)
static void C_ccall f_5407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4593)
static void C_ccall f_4593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4590)
static void C_fcall f_4590(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10682)
static void C_ccall f_10682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8212)
static void C_ccall f_8212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8218)
static void C_fcall f_8218(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10690)
static void C_ccall f_10690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5421)
static void C_fcall f_5421(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8562)
static void C_ccall f_8562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9742)
static void C_ccall f_9742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12638)
static void C_ccall f_12638(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(C_optimizer_toplevel)
C_externexport void C_ccall C_optimizer_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5495)
static void C_ccall f_5495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4292)
static void C_ccall f_4292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5487)
static void C_ccall f_5487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6805)
static void C_fcall f_6805(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8588)
static void C_ccall f_8588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8584)
static void C_fcall f_8584(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9765)
static void C_ccall f_9765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11389)
static void C_fcall f_11389(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5458)
static void C_fcall f_5458(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9738)
static void C_ccall f_9738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5448)
static void C_ccall f_5448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8825)
static void C_ccall f_8825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5984)
static void C_ccall f_5984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5445)
static void C_ccall f_5445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12513)
static void C_ccall f_12513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12517)
static void C_ccall f_12517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9460)
static void C_ccall f_9460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9462)
static void C_ccall f_9462(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4370)
static void C_ccall f_4370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12521)
static void C_ccall f_12521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10659)
static void C_ccall f_10659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10656)
static void C_ccall f_10656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4379)
static void C_ccall f_4379(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6829)
static void C_ccall f_6829(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4311)
static void C_ccall f_4311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12505)
static void C_ccall f_12505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7448)
static void C_ccall f_7448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3995)
static void C_ccall f_3995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3998)
static void C_ccall f_3998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5435)
static void C_fcall f_5435(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5323)
static void C_ccall f_5323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5326)
static void C_ccall f_5326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5329)
static void C_ccall f_5329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5312)
static void C_ccall f_5312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5313)
static void C_fcall f_5313(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8247)
static void C_ccall f_8247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6105)
static void C_ccall f_6105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10174)
static void C_ccall f_10174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6472)
static void C_ccall f_6472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12371)
static void C_ccall f_12371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11084)
static void C_ccall f_11084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12361)
static void C_ccall f_12361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11087)
static void C_ccall f_11087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10195)
static void C_ccall f_10195(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12390)
static void C_ccall f_12390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6469)
static void C_ccall f_6469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6466)
static void C_ccall f_6466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7518)
static void C_ccall f_7518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12380)
static void C_fcall f_12380(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6433)
static void C_ccall f_6433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5372)
static void C_fcall f_5372(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6487)
static void C_fcall f_6487(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6486)
static void C_ccall f_6486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8887)
static void C_ccall f_8887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8883)
static void C_fcall f_8883(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4646)
static void C_ccall f_4646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4649)
static void C_fcall f_4649(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6459)
static void C_fcall f_6459(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6455)
static C_word C_fcall f_6455(C_word t0);
C_noret_decl(f_6452)
static void C_ccall f_6452(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5334)
static void C_ccall f_5334(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5337)
static void C_ccall f_5337(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10339)
static void C_fcall f_10339(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8848)
static void C_ccall f_8848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6227)
static void C_ccall f_6227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10344)
static void C_ccall f_10344(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5351)
static void C_ccall f_5351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8732)
static void C_ccall f_8732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5382)
static void C_ccall f_5382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5341)
static void C_ccall f_5341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5348)
static void C_ccall f_5348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4683)
static void C_ccall f_4683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4685)
static void C_fcall f_4685(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8107)
static void C_ccall f_8107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12841)
static void C_ccall f_12841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4676)
static void C_fcall f_4676(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12685)
static void C_ccall f_12685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7324)
static void C_fcall f_7324(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4807)
static void C_ccall f_4807(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10140)
static void C_ccall f_10140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4802)
static void C_ccall f_4802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10158)
static void C_ccall f_10158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6546)
static void C_fcall f_6546(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4819)
static void C_ccall f_4819(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6540)
static void C_ccall f_6540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4813)
static void C_ccall f_4813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6555)
static void C_fcall f_6555(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4832)
static void C_ccall f_4832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9712)
static void C_ccall f_9712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9718)
static void C_fcall f_9718(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10490)
static void C_ccall f_10490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12899)
static void C_fcall f_12899(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4852)
static void C_ccall f_4852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9416)
static void C_ccall f_9416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4714)
static void C_ccall f_4714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8093)
static void C_fcall f_8093(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8090)
static void C_fcall f_8090(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4721)
static void C_ccall f_4721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8084)
static void C_ccall f_8084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9131)
static void C_ccall f_9131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4825)
static void C_ccall f_4825(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7359)
static void C_ccall f_7359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6565)
static void C_ccall f_6565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6568)
static void C_ccall f_6568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12868)
static void C_fcall f_12868(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8058)
static void C_ccall f_8058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11343)
static void C_fcall f_11343(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6562)
static void C_ccall f_6562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7362)
static void C_fcall f_7362(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6583)
static void C_ccall f_6583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7226)
static void C_fcall f_7226(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5309)
static void C_fcall f_5309(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9184)
static void C_ccall f_9184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9186)
static void C_ccall f_9186(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6779)
static void C_ccall f_6779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6772)
static void C_ccall f_6772(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6772)
static void C_ccall f_6772r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3916)
static void C_ccall f_3916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3919)
static void C_ccall f_3919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3940)
static void C_ccall f_3940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12332)
static void C_fcall f_12332(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3937)
static void C_fcall f_3937(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7865)
static void C_ccall f_7865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12006)
static void C_ccall f_12006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7293)
static void C_ccall f_7293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7299)
static void C_ccall f_7299(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_12010)
static void C_ccall f_12010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12014)
static void C_ccall f_12014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12018)
static void C_ccall f_12018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11420)
static void C_ccall f_11420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9105)
static void C_ccall f_9105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3925)
static void C_ccall f_3925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3922)
static void C_ccall f_3922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13263)
static void C_ccall f_13263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9990)
static void C_ccall f_9990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13267)
static void C_ccall f_13267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4879)
static void C_ccall f_4879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4872)
static void C_ccall f_4872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10297)
static void C_ccall f_10297(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6787)
static void C_ccall f_6787(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6785)
static void C_ccall f_6785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10292)
static void C_fcall f_10292(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6782)
static void C_ccall f_6782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13271)
static void C_ccall f_13271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4882)
static void C_ccall f_4882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6799)
static void C_fcall f_6799(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6797)
static void C_ccall f_6797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9973)
static void C_ccall f_9973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12028)
static void C_ccall f_12028(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_12026)
static void C_ccall f_12026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8679)
static void C_fcall f_8679(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7239)
static void C_fcall f_7239(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12295)
static void C_ccall f_12295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12297)
static void C_fcall f_12297(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9692)
static void C_ccall f_9692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9696)
static void C_ccall f_9696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9688)
static void C_ccall f_9688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6749)
static void C_fcall f_6749(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9698)
static void C_ccall f_9698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12275)
static void C_ccall f_12275(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6759)
static void C_ccall f_6759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13289)
static void C_ccall f_13289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12269)
static void C_ccall f_12269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13280)
static void C_ccall f_13280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12727)
static void C_ccall f_12727(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7277)
static void C_ccall f_7277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7279)
static void C_ccall f_7279(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7279)
static void C_ccall f_7279r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7283)
static void C_ccall f_7283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10979)
static void C_fcall f_10979(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9663)
static void C_ccall f_9663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10989)
static void C_ccall f_10989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7039)
static void C_ccall f_7039(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8032)
static void C_ccall f_8032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10992)
static void C_ccall f_10992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10998)
static void C_ccall f_10998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10995)
static void C_ccall f_10995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6311)
static void C_fcall f_6311(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4666)
static void C_fcall f_4666(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6304)
static void C_ccall f_6304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9345)
static void C_ccall f_9345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12737)
static void C_fcall f_12737(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10942)
static void C_ccall f_10942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10945)
static void C_ccall f_10945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6514)
static void C_fcall f_6514(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10948)
static void C_ccall f_10948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7071)
static void C_ccall f_7071(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6505)
static void C_ccall f_6505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6508)
static void C_ccall f_6508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5551)
static void C_ccall f_5551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4038)
static void C_ccall f_4038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6534)
static void C_fcall f_6534(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4428)
static void C_ccall f_4428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11770)
static void C_ccall f_11770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4434)
static void C_ccall f_4434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11605)
static void C_ccall f_11605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11780)
static void C_fcall f_11780(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4615)
static void C_ccall f_4615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11779)
static void C_ccall f_11779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11776)
static void C_ccall f_11776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11773)
static void C_ccall f_11773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8350)
static void C_ccall f_8350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8354)
static void C_ccall f_8354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7817)
static void C_ccall f_7817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11785)
static void C_fcall f_11785(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11784)
static void C_ccall f_11784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8342)
static void C_ccall f_8342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11628)
static void C_ccall f_11628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12082)
static void C_ccall f_12082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11631)
static void C_ccall f_11631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11632)
static void C_fcall f_11632(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8532)
static void C_ccall f_8532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6174)
static void C_ccall f_6174(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11640)
static void C_ccall f_11640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11643)
static void C_ccall f_11643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11644)
static void C_fcall f_11644(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5646)
static void C_ccall f_5646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5658)
static void C_ccall f_5658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6142)
static void C_ccall f_6142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5648)
static void C_fcall f_5648(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6198)
static void C_ccall f_6198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9381)
static void C_ccall f_9381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9387)
static void C_fcall f_9387(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8528)
static void C_ccall f_8528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4123)
static C_word C_fcall f_4123(C_word t0);
C_noret_decl(f_9096)
static void C_ccall f_9096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12097)
static void C_ccall f_12097(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10245)
static void C_ccall f_10245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9390)
static void C_ccall f_9390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12074)
static void C_ccall f_12074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6130)
static void C_ccall f_6130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6132)
static void C_fcall f_6132(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9375)
static void C_ccall f_9375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13125)
static void C_ccall f_13125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13121)
static void C_ccall f_13121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13129)
static void C_ccall f_13129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6157)
static void C_ccall f_6157(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6156)
static void C_ccall f_6156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9052)
static void C_ccall f_9052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5774)
static void C_ccall f_5774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7010)
static void C_fcall f_7010(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13142)
static void C_ccall f_13142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10256)
static void C_ccall f_10256(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10251)
static void C_fcall f_10251(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11767)
static void C_ccall f_11767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11764)
static void C_ccall f_11764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9072)
static void C_ccall f_9072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10229)
static void C_ccall f_10229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4400)
static void C_ccall f_4400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13026)
static void C_ccall f_13026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5660)
static void C_fcall f_5660(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8969)
static void C_ccall f_8969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10719)
static void C_ccall f_10719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8635)
static void C_ccall f_8635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3742)
static void C_ccall f_3742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10724)
static void C_fcall f_10724(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5037)
static void C_fcall f_5037(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5697)
static void C_ccall f_5697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3732)
static void C_fcall f_3732(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9002)
static void C_fcall f_9002(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5030)
static void C_ccall f_5030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10734)
static void C_ccall f_10734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5033)
static void C_ccall f_5033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5689)
static void C_ccall f_5689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11817)
static void C_ccall f_11817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10747)
static void C_ccall f_10747(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7069)
static void C_ccall f_7069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5054)
static void C_ccall f_5054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5047)
static void C_ccall f_5047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5796)
static void C_ccall f_5796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4475)
static void C_ccall f_4475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11837)
static void C_ccall f_11837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4471)
static void C_fcall f_4471(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4479)
static void C_fcall f_4479(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12942)
static void C_ccall f_12942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4486)
static void C_ccall f_4486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4483)
static void C_ccall f_4483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13216)
static void C_ccall f_13216(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13) C_noret;
C_noret_decl(f_9914)
static void C_ccall f_9914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4913)
static void C_ccall f_4913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11829)
static void C_ccall f_11829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11825)
static void C_ccall f_11825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11821)
static void C_ccall f_11821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11902)
static void C_fcall f_11902(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12952)
static void C_ccall f_12952(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12950)
static void C_ccall f_12950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9920)
static void C_ccall f_9920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5754)
static void C_ccall f_5754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11912)
static void C_ccall f_11912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5741)
static void C_ccall f_5741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4906)
static void C_ccall f_4906(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9908)
static void C_ccall f_9908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4901)
static void C_ccall f_4901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4953)
static void C_ccall f_4953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13229)
static void C_ccall f_13229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5537)
static void C_ccall f_5537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5533)
static void C_ccall f_5533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13235)
static void C_ccall f_13235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9323)
static void C_ccall f_9323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9321)
static void C_ccall f_9321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13099)
static void C_ccall f_13099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9627)
static void C_ccall f_9627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9333)
static void C_ccall f_9333(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6028)
static void C_ccall f_6028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11673)
static void C_ccall f_11673(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13086)
static void C_ccall f_13086(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10) C_noret;
C_noret_decl(f_11684)
static void C_ccall f_11684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6056)
static void C_ccall f_6056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7646)
static void C_ccall f_7646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11872)
static void C_fcall f_11872(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4933)
static void C_ccall f_4933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5513)
static void C_ccall f_5513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13062)
static void C_ccall f_13062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7691)
static void C_ccall f_7691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7117)
static void C_ccall f_7117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11847)
static void C_ccall f_11847(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5507)
static void C_ccall f_5507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5501)
static void C_ccall f_5501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8416)
static void C_fcall f_8416(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8406)
static void C_ccall f_8406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5624)
static void C_ccall f_5624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12575)
static void C_ccall f_12575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11250)
static void C_ccall f_11250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11252)
static void C_ccall f_11252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11258)
static void C_fcall f_11258(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3868)
static void C_ccall f_3868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11925)
static void C_fcall f_11925(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11882)
static void C_ccall f_11882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11935)
static void C_fcall f_11935(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5016)
static void C_fcall f_5016(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3883)
static void C_ccall f_3883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6997)
static void C_ccall f_6997(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8472)
static void C_ccall f_8472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5009)
static void C_ccall f_5009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5006)
static void C_ccall f_5006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6962)
static void C_ccall f_6962(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5107)
static void C_fcall f_5107(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5101)
static void C_ccall f_5101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8112)
static void C_ccall f_8112(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7957)
static void C_ccall f_7957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5619)
static void C_ccall f_5619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5630)
static void C_ccall f_5630(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8101)
static void C_ccall f_8101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11707)
static void C_fcall f_11707(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7199)
static void C_ccall f_7199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10076)
static void C_fcall f_10076(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6980)
static void C_ccall f_6980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5607)
static void C_ccall f_5607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10073)
static void C_fcall f_10073(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5604)
static void C_fcall f_5604(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6989)
static void C_ccall f_6989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12115)
static void C_fcall f_12115(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6956)
static void C_ccall f_6956(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11736)
static void C_ccall f_11736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8432)
static void C_ccall f_8432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8436)
static void C_ccall f_8436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3875)
static void C_ccall f_3875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3879)
static void C_ccall f_3879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5079)
static void C_ccall f_5079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7998)
static void C_ccall f_7998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7990)
static void C_ccall f_7990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6974)
static void C_ccall f_6974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5705)
static void C_ccall f_5705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9878)
static void C_ccall f_9878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6977)
static void C_ccall f_6977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5069)
static void C_fcall f_5069(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4393)
static void C_ccall f_4393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12105)
static void C_ccall f_12105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12109)
static void C_ccall f_12109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11668)
static void C_ccall f_11668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10590)
static void C_fcall f_10590(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5192)
static void C_ccall f_5192(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5190)
static void C_ccall f_5190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10564)
static void C_ccall f_10564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5211)
static void C_ccall f_5211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10589)
static void C_ccall f_10589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4075)
static void C_ccall f_4075(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10586)
static void C_ccall f_10586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10580)
static void C_ccall f_10580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9838)
static void C_fcall f_9838(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8183)
static void C_fcall f_8183(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12149)
static void C_ccall f_12149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12145)
static void C_ccall f_12145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9835)
static void C_ccall f_9835(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6738)
static void C_ccall f_6738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4001)
static void C_ccall f_4001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12555)
static void C_ccall f_12555(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9) C_noret;
C_noret_decl(f_8754)
static void C_ccall f_8754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8758)
static void C_ccall f_8758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5152)
static void C_fcall f_5152(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6722)
static void C_ccall f_6722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10577)
static void C_ccall f_10577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10573)
static void C_fcall f_10573(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4028)
static void C_fcall f_4028(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5149)
static void C_ccall f_5149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7143)
static void C_fcall f_7143(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4389)
static void C_fcall f_4389(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7153)
static void C_ccall f_7153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5275)
static void C_fcall f_5275(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4580)
static void C_fcall f_4580(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5161)
static void C_ccall f_5161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7166)
static void C_fcall f_7166(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4059)
static void C_ccall f_4059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7176)
static void C_ccall f_7176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5291)
static void C_ccall f_5291(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4069)
static void C_fcall f_4069(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4066)
static void C_ccall f_4066(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4063)
static void C_ccall f_4063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7189)
static void C_fcall f_7189(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12441)
static void C_ccall f_12441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5997)
static void C_ccall f_5997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5999)
static void C_fcall f_5999(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10823)
static void C_fcall f_10823(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5990)
static void C_fcall f_5990(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6062)
static void C_ccall f_6062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11595)
static void C_fcall f_11595(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12419)
static void C_ccall f_12419(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_6073)
static void C_ccall f_6073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4161)
static void C_ccall f_4161(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10286)
static void C_ccall f_10286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7625)
static void C_ccall f_7625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11564)
static void C_ccall f_11564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6082)
static void C_ccall f_6082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6423)
static void C_fcall f_6423(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11574)
static void C_ccall f_11574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5251)
static void C_ccall f_5251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6099)
static void C_fcall f_6099(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4105)
static C_word C_fcall f_4105(C_word t0);
C_noret_decl(f_4109)
static void C_fcall f_4109(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7604)
static void C_ccall f_7604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8153)
static void C_ccall f_8153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8155)
static void C_ccall f_8155(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4153)
static void C_ccall f_4153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4150)
static void C_ccall f_4150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10032)
static void C_fcall f_10032(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11557)
static void C_ccall f_11557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11551)
static void C_ccall f_11551(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7758)
static void C_ccall f_7758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11275)
static void C_ccall f_11275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11278)
static void C_ccall f_11278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6945)
static void C_ccall f_6945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3792)
static void C_fcall f_3792(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3798)
static void C_ccall f_3798(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3796)
static void C_ccall f_3796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4525)
static void C_ccall f_4525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6932)
static void C_ccall f_6932(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11283)
static C_word C_fcall f_11283(C_word *a,C_word t0);
C_noret_decl(f_6930)
static void C_ccall f_6930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4177)
static void C_ccall f_4177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4171)
static void C_ccall f_4171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11280)
static void C_ccall f_11280(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10044)
static void C_fcall f_10044(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4537)
static void C_ccall f_4537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4146)
static void C_fcall f_4146(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4531)
static void C_ccall f_4531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11583)
static void C_fcall f_11583(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6273)
static void C_fcall f_6273(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9579)
static void C_ccall f_9579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10054)
static void C_ccall f_10054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6283)
static void C_ccall f_6283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10833)
static void C_ccall f_10833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6900)
static void C_ccall f_6900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4557)
static void C_ccall f_4557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3755)
static void C_fcall f_3755(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5933)
static void C_ccall f_5933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3672)
static void C_ccall f_3672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5939)
static void C_ccall f_5939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3678)
static void C_ccall f_3678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3675)
static void C_ccall f_3675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12181)
static void C_ccall f_12181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12177)
static void C_ccall f_12177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3706)
static void C_fcall f_3706(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4278)
static void C_fcall f_4278(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6298)
static void C_ccall f_6298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3690)
static void C_fcall f_3690(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10016)
static void C_ccall f_10016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11269)
static void C_ccall f_11269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10545)
static void C_fcall f_10545(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_10549)
static void C_ccall f_10549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3720)
static void C_fcall f_3720(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3680)
static void C_ccall f_3680(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5949)
static void C_ccall f_5949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10543)
static void C_ccall f_10543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3683)
static void C_fcall f_3683(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6239)
static void C_ccall f_6239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4491)
static void C_fcall f_4491(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6235)
static void C_ccall f_6235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13387)
static void C_ccall f_13387(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_4216)
static C_word C_fcall f_4216(C_word t0,C_word t1);
C_noret_decl(f_6208)
static void C_fcall f_6208(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6250)
static void C_ccall f_6250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3718)
static void C_fcall f_3718(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3713)
static C_word C_fcall f_3713(C_word t0);
C_noret_decl(f_3711)
static void C_ccall f_3711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13395)
static void C_ccall f_13395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6246)
static void C_ccall f_6246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13056)
static void C_ccall f_13056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4232)
static void C_fcall f_4232(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9288)
static void C_ccall f_9288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4230)
static void C_ccall f_4230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12169)
static void C_ccall f_12169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10536)
static void C_ccall f_10536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6267)
static void C_fcall f_6267(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_10479)
static void C_ccall f_10479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10503)
static void C_ccall f_10503(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5903)
static void C_ccall f_5903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13032)
static void C_ccall f_13032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5128)
static void C_ccall f_5128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4779)
static void C_ccall f_4779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4786)
static void C_ccall f_4786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6922)
static void C_ccall f_6922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11403)
static void C_fcall f_11403(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6915)
static void C_fcall f_6915(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6914)
static void C_ccall f_6914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13410)
static void C_ccall f_13410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13414)
static C_word C_fcall f_13414(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_12479)
static void C_ccall f_12479(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6865)
static void C_ccall f_6865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12477)
static void C_ccall f_12477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10605)
static void C_ccall f_10605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3809)
static void C_fcall f_3809(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6873)
static void C_ccall f_6873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13400)
static void C_fcall f_13400(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5916)
static void C_ccall f_5916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5217)
static void C_ccall f_5217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11147)
static void C_fcall f_11147(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11157)
static void C_ccall f_11157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3845)
static void C_ccall f_3845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8322)
static void C_ccall f_8322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11135)
static void C_ccall f_11135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8313)
static void C_ccall f_8313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3836)
static void C_fcall f_3836(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3839)
static void C_ccall f_3839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6887)
static void C_ccall f_6887(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6881)
static void C_ccall f_6881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11451)
static void C_fcall f_11451(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6386)
static void C_ccall f_6386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11464)
static void C_fcall f_11464(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6395)
static void C_ccall f_6395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6390)
static void C_ccall f_6390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6842)
static void C_fcall f_6842(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5818)
static void C_ccall f_5818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5815)
static void C_ccall f_5815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6855)
static void C_fcall f_6855(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6854)
static void C_ccall f_6854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6851)
static void C_ccall f_6851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5809)
static void C_ccall f_5809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6348)
static void C_ccall f_6348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6345)
static void C_ccall f_6345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5800)
static void C_ccall f_5800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11186)
static void C_ccall f_11186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11026)
static void C_ccall f_11026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6342)
static void C_ccall f_6342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9704)
static void C_ccall f_9704(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6357)
static void C_ccall f_6357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6354)
static void C_ccall f_6354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6351)
static void C_ccall f_6351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10446)
static void C_ccall f_10446(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12230)
static void C_ccall f_12230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12232)
static void C_fcall f_12232(C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_11176)
static void C_fcall trf_11176(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11176(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11176(t0,t1,t2);}

C_noret_decl(trf_7599)
static void C_fcall trf_7599(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7599(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7599(t0,t1);}

C_noret_decl(trf_4590)
static void C_fcall trf_4590(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4590(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4590(t0,t1);}

C_noret_decl(trf_8218)
static void C_fcall trf_8218(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8218(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8218(t0,t1,t2);}

C_noret_decl(trf_5421)
static void C_fcall trf_5421(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5421(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5421(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6805)
static void C_fcall trf_6805(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6805(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6805(t0,t1,t2,t3);}

C_noret_decl(trf_8584)
static void C_fcall trf_8584(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8584(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8584(t0,t1);}

C_noret_decl(trf_11389)
static void C_fcall trf_11389(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11389(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11389(t0,t1);}

C_noret_decl(trf_5458)
static void C_fcall trf_5458(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5458(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5458(t0,t1,t2);}

C_noret_decl(trf_5435)
static void C_fcall trf_5435(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5435(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5435(t0,t1,t2);}

C_noret_decl(trf_5313)
static void C_fcall trf_5313(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5313(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5313(t0,t1,t2);}

C_noret_decl(trf_12380)
static void C_fcall trf_12380(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12380(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12380(t0,t1,t2);}

C_noret_decl(trf_5372)
static void C_fcall trf_5372(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5372(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5372(t0,t1,t2);}

C_noret_decl(trf_6487)
static void C_fcall trf_6487(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6487(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6487(t0,t1,t2);}

C_noret_decl(trf_8883)
static void C_fcall trf_8883(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8883(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8883(t0,t1);}

C_noret_decl(trf_4649)
static void C_fcall trf_4649(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4649(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4649(t0,t1);}

C_noret_decl(trf_6459)
static void C_fcall trf_6459(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6459(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6459(t0,t1,t2,t3);}

C_noret_decl(trf_10339)
static void C_fcall trf_10339(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10339(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10339(t0,t1);}

C_noret_decl(trf_4685)
static void C_fcall trf_4685(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4685(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4685(t0,t1,t2);}

C_noret_decl(trf_4676)
static void C_fcall trf_4676(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4676(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4676(t0,t1,t2);}

C_noret_decl(trf_7324)
static void C_fcall trf_7324(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7324(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7324(t0,t1);}

C_noret_decl(trf_6546)
static void C_fcall trf_6546(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6546(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6546(t0,t1);}

C_noret_decl(trf_6555)
static void C_fcall trf_6555(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6555(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6555(t0,t1);}

C_noret_decl(trf_9718)
static void C_fcall trf_9718(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9718(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9718(t0,t1,t2,t3);}

C_noret_decl(trf_12899)
static void C_fcall trf_12899(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12899(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12899(t0,t1);}

C_noret_decl(trf_8093)
static void C_fcall trf_8093(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8093(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8093(t0,t1);}

C_noret_decl(trf_8090)
static void C_fcall trf_8090(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8090(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8090(t0,t1);}

C_noret_decl(trf_12868)
static void C_fcall trf_12868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12868(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_12868(t0,t1,t2,t3,t4);}

C_noret_decl(trf_11343)
static void C_fcall trf_11343(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11343(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_11343(t0,t1,t2,t3);}

C_noret_decl(trf_7362)
static void C_fcall trf_7362(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7362(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7362(t0,t1);}

C_noret_decl(trf_7226)
static void C_fcall trf_7226(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7226(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7226(t0,t1,t2,t3);}

C_noret_decl(trf_5309)
static void C_fcall trf_5309(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5309(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5309(t0,t1);}

C_noret_decl(trf_12332)
static void C_fcall trf_12332(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12332(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12332(t0,t1,t2);}

C_noret_decl(trf_3937)
static void C_fcall trf_3937(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3937(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3937(t0,t1);}

C_noret_decl(trf_10292)
static void C_fcall trf_10292(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10292(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10292(t0,t1);}

C_noret_decl(trf_6799)
static void C_fcall trf_6799(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6799(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6799(t0,t1,t2,t3);}

C_noret_decl(trf_8679)
static void C_fcall trf_8679(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8679(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8679(t0,t1);}

C_noret_decl(trf_7239)
static void C_fcall trf_7239(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7239(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7239(t0,t1);}

C_noret_decl(trf_12297)
static void C_fcall trf_12297(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12297(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12297(t0,t1,t2);}

C_noret_decl(trf_6749)
static void C_fcall trf_6749(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6749(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6749(t0,t1,t2);}

C_noret_decl(trf_10979)
static void C_fcall trf_10979(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10979(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10979(t0,t1,t2);}

C_noret_decl(trf_6311)
static void C_fcall trf_6311(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6311(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6311(t0,t1);}

C_noret_decl(trf_4666)
static void C_fcall trf_4666(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4666(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4666(t0,t1);}

C_noret_decl(trf_12737)
static void C_fcall trf_12737(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12737(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_12737(t0,t1,t2,t3);}

C_noret_decl(trf_6514)
static void C_fcall trf_6514(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6514(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6514(t0,t1);}

C_noret_decl(trf_6534)
static void C_fcall trf_6534(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6534(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6534(t0,t1);}

C_noret_decl(trf_11780)
static void C_fcall trf_11780(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11780(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11780(t0,t1,t2);}

C_noret_decl(trf_11785)
static void C_fcall trf_11785(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11785(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11785(t0,t1,t2);}

C_noret_decl(trf_11632)
static void C_fcall trf_11632(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11632(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11632(t0,t1,t2);}

C_noret_decl(trf_11644)
static void C_fcall trf_11644(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11644(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11644(t0,t1,t2);}

C_noret_decl(trf_5648)
static void C_fcall trf_5648(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5648(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5648(t0,t1,t2);}

C_noret_decl(trf_9387)
static void C_fcall trf_9387(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9387(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9387(t0,t1);}

C_noret_decl(trf_6132)
static void C_fcall trf_6132(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6132(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6132(t0,t1,t2);}

C_noret_decl(trf_7010)
static void C_fcall trf_7010(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7010(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7010(t0,t1);}

C_noret_decl(trf_10251)
static void C_fcall trf_10251(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10251(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10251(t0,t1);}

C_noret_decl(trf_5660)
static void C_fcall trf_5660(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5660(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5660(t0,t1,t2);}

C_noret_decl(trf_10724)
static void C_fcall trf_10724(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10724(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10724(t0,t1,t2);}

C_noret_decl(trf_5037)
static void C_fcall trf_5037(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5037(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5037(t0,t1,t2);}

C_noret_decl(trf_3732)
static void C_fcall trf_3732(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3732(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3732(t0,t1,t2);}

C_noret_decl(trf_9002)
static void C_fcall trf_9002(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9002(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9002(t0,t1);}

C_noret_decl(trf_4471)
static void C_fcall trf_4471(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4471(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4471(t0,t1,t2);}

C_noret_decl(trf_4479)
static void C_fcall trf_4479(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4479(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4479(t0,t1,t2);}

C_noret_decl(trf_11902)
static void C_fcall trf_11902(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11902(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11902(t0,t1,t2);}

C_noret_decl(trf_11872)
static void C_fcall trf_11872(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11872(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11872(t0,t1,t2);}

C_noret_decl(trf_8416)
static void C_fcall trf_8416(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8416(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8416(t0,t1);}

C_noret_decl(trf_11258)
static void C_fcall trf_11258(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11258(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11258(t0,t1);}

C_noret_decl(trf_11925)
static void C_fcall trf_11925(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11925(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11925(t0,t1,t2);}

C_noret_decl(trf_11935)
static void C_fcall trf_11935(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11935(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11935(t0,t1);}

C_noret_decl(trf_5016)
static void C_fcall trf_5016(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5016(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5016(t0,t1);}

C_noret_decl(trf_5107)
static void C_fcall trf_5107(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5107(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5107(t0,t1);}

C_noret_decl(trf_11707)
static void C_fcall trf_11707(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11707(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11707(t0,t1,t2);}

C_noret_decl(trf_10076)
static void C_fcall trf_10076(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10076(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_10076(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_10073)
static void C_fcall trf_10073(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10073(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_10073(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5604)
static void C_fcall trf_5604(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5604(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5604(t0,t1);}

C_noret_decl(trf_12115)
static void C_fcall trf_12115(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12115(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_12115(t0,t1,t2,t3);}

C_noret_decl(trf_5069)
static void C_fcall trf_5069(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5069(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5069(t0,t1,t2);}

C_noret_decl(trf_10590)
static void C_fcall trf_10590(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10590(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10590(t0,t1,t2);}

C_noret_decl(trf_9838)
static void C_fcall trf_9838(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9838(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_9838(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8183)
static void C_fcall trf_8183(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8183(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8183(t0,t1,t2);}

C_noret_decl(trf_5152)
static void C_fcall trf_5152(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5152(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5152(t0,t1);}

C_noret_decl(trf_10573)
static void C_fcall trf_10573(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10573(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10573(t0,t1);}

C_noret_decl(trf_4028)
static void C_fcall trf_4028(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4028(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4028(t0,t1,t2);}

C_noret_decl(trf_7143)
static void C_fcall trf_7143(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7143(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7143(t0,t1,t2);}

C_noret_decl(trf_4389)
static void C_fcall trf_4389(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4389(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4389(t0,t1);}

C_noret_decl(trf_5275)
static void C_fcall trf_5275(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5275(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5275(t0,t1);}

C_noret_decl(trf_4580)
static void C_fcall trf_4580(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4580(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4580(t0,t1,t2);}

C_noret_decl(trf_7166)
static void C_fcall trf_7166(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7166(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7166(t0,t1,t2);}

C_noret_decl(trf_4069)
static void C_fcall trf_4069(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4069(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4069(t0,t1,t2,t3);}

C_noret_decl(trf_7189)
static void C_fcall trf_7189(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7189(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7189(t0,t1,t2,t3);}

C_noret_decl(trf_5999)
static void C_fcall trf_5999(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5999(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5999(t0,t1,t2);}

C_noret_decl(trf_10823)
static void C_fcall trf_10823(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10823(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10823(t0,t1,t2);}

C_noret_decl(trf_5990)
static void C_fcall trf_5990(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5990(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5990(t0,t1,t2);}

C_noret_decl(trf_11595)
static void C_fcall trf_11595(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11595(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11595(t0,t1,t2);}

C_noret_decl(trf_6423)
static void C_fcall trf_6423(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6423(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6423(t0,t1,t2);}

C_noret_decl(trf_6099)
static void C_fcall trf_6099(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6099(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6099(t0,t1);}

C_noret_decl(trf_4109)
static void C_fcall trf_4109(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4109(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4109(t0,t1);}

C_noret_decl(trf_10032)
static void C_fcall trf_10032(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10032(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10032(t0,t1,t2);}

C_noret_decl(trf_3792)
static void C_fcall trf_3792(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3792(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3792(t0,t1);}

C_noret_decl(trf_10044)
static void C_fcall trf_10044(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10044(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10044(t0,t1,t2);}

C_noret_decl(trf_4146)
static void C_fcall trf_4146(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4146(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4146(t0,t1,t2);}

C_noret_decl(trf_11583)
static void C_fcall trf_11583(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11583(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11583(t0,t1,t2);}

C_noret_decl(trf_6273)
static void C_fcall trf_6273(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6273(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6273(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3755)
static void C_fcall trf_3755(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3755(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3755(t0,t1,t2,t3);}

C_noret_decl(trf_3706)
static void C_fcall trf_3706(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3706(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3706(t0,t1,t2,t3);}

C_noret_decl(trf_4278)
static void C_fcall trf_4278(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4278(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4278(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3690)
static void C_fcall trf_3690(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3690(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3690(t0,t1);}

C_noret_decl(trf_10545)
static void C_fcall trf_10545(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10545(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_10545(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_3720)
static void C_fcall trf_3720(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3720(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3720(t0,t1,t2);}

C_noret_decl(trf_3683)
static void C_fcall trf_3683(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3683(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3683(t0,t1,t2);}

C_noret_decl(trf_4491)
static void C_fcall trf_4491(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4491(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4491(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6208)
static void C_fcall trf_6208(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6208(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6208(t0,t1);}

C_noret_decl(trf_3718)
static void C_fcall trf_3718(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3718(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3718(t0,t1,t2,t3);}

C_noret_decl(trf_4232)
static void C_fcall trf_4232(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4232(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4232(t0,t1,t2);}

C_noret_decl(trf_6267)
static void C_fcall trf_6267(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6267(void *dummy){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
f_6267(t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(trf_11403)
static void C_fcall trf_11403(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11403(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11403(t0,t1);}

C_noret_decl(trf_6915)
static void C_fcall trf_6915(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6915(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6915(t0,t1,t2);}

C_noret_decl(trf_3809)
static void C_fcall trf_3809(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3809(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3809(t0,t1);}

C_noret_decl(trf_13400)
static void C_fcall trf_13400(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13400(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13400(t0,t1,t2);}

C_noret_decl(trf_11147)
static void C_fcall trf_11147(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11147(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11147(t0,t1,t2);}

C_noret_decl(trf_3836)
static void C_fcall trf_3836(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3836(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3836(t0,t1);}

C_noret_decl(trf_11451)
static void C_fcall trf_11451(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11451(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11451(t0,t1);}

C_noret_decl(trf_11464)
static void C_fcall trf_11464(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11464(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11464(t0,t1);}

C_noret_decl(trf_6842)
static void C_fcall trf_6842(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6842(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6842(t0,t1,t2,t3);}

C_noret_decl(trf_6855)
static void C_fcall trf_6855(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6855(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6855(t0,t1,t2);}

C_noret_decl(trf_12232)
static void C_fcall trf_12232(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12232(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12232(t0,t1,t2);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr10)
static void C_fcall tr10(C_proc10 k) C_regparm C_noret;
C_regparm static void C_fcall tr10(C_proc10 k){
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
(k)(10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(tr11)
static void C_fcall tr11(C_proc11 k) C_regparm C_noret;
C_regparm static void C_fcall tr11(C_proc11 k){
C_word t10=C_pick(0);
C_word t9=C_pick(1);
C_word t8=C_pick(2);
C_word t7=C_pick(3);
C_word t6=C_pick(4);
C_word t5=C_pick(5);
C_word t4=C_pick(6);
C_word t3=C_pick(7);
C_word t2=C_pick(8);
C_word t1=C_pick(9);
C_word t0=C_pick(10);
C_adjust_stack(-11);
(k)(11,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}

C_noret_decl(tr14)
static void C_fcall tr14(C_proc14 k) C_regparm C_noret;
C_regparm static void C_fcall tr14(C_proc14 k){
C_word t13=C_pick(0);
C_word t12=C_pick(1);
C_word t11=C_pick(2);
C_word t10=C_pick(3);
C_word t9=C_pick(4);
C_word t8=C_pick(5);
C_word t7=C_pick(6);
C_word t6=C_pick(7);
C_word t5=C_pick(8);
C_word t4=C_pick(9);
C_word t3=C_pick(10);
C_word t2=C_pick(11);
C_word t1=C_pick(12);
C_word t0=C_pick(13);
C_adjust_stack(-14);
(k)(14,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* for-each-loop2425 in rec in k10584 in k10578 in k10575 in k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_11176(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11176,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11186,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:1513: g2426 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7709 in k7689 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_7711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7711,2,t0,t1);}
t2=t1;
t3=C_i_car(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7719,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=C_i_cadr(((C_word*)t0)[6]);
/* optimizer.scm:980: qnode */
t7=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* a9506 in k9385 in k9379 in k9373 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9507(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9507,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=C_eqp(lf[34],t4);
if(C_truep(t5)){
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=C_i_car(t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_eqp(((C_word*)t0)[2],t8));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* a9211 in k9094 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9212(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9212,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=C_eqp(lf[34],t4);
if(C_truep(t5)){
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=C_i_car(t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_eqp(((C_word*)t0)[2],t8));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k7717 in k7709 in k7689 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_7719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7719,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_a_i_list5(&a,5,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t1,t2);
t4=((C_word*)t0)[6];
t5=t4;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[7],t3));}

/* a10845 in k10587 in k10584 in k10578 in k10575 in k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10846,4,t0,t1,t2,t3);}
t4=C_i_cdr(t2);
t5=C_i_cdr(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_eqp(t4,t5));}

/* k11477 in k11387 in walk in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_11479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
f_11464(t3,C_i_length(t2));}
else{
t2=((C_word*)t0)[2];
f_11464(t2,C_fix(0));}}

/* k11470 in k11462 in k11387 in walk in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_11472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=C_i_length(t2);
t4=((C_word*)t0)[2];
f_11451(t4,C_eqp(((C_word*)t0)[3],t3));}
else{
t2=((C_word*)t0)[2];
f_11451(t2,C_eqp(((C_word*)t0)[3],C_fix(0)));}}

/* k6336 in k6330 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6338,2,t0,t1);}
t2=C_set_block_item(lf[31] /* ##compiler#simplified-ops */,0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6342,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:523: walk */
t4=((C_word*)((C_word*)t0)[8])[1];
f_4278(t4,t3,((C_word*)t0)[9],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* k6330 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6332,2,t0,t1);}
if(C_truep(t1)){
/* optimizer.scm:519: values */
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[3],C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6338,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[3],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm:521: debugging */
t3=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[28],lf[118]);}}

/* rec in k10584 in k10578 in k10575 in k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10864(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10864,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(2));
t5=t2;
t6=C_slot(t5,C_fix(3));
t7=t6;
t8=t2;
t9=C_slot(t8,C_fix(1));
t10=C_eqp(t9,lf[12]);
if(C_truep(t10)){
t11=C_i_car(t7);
t12=C_i_cadr(t7);
t13=C_slot(t11,C_fix(2));
t14=C_slot(t12,C_fix(2));
t15=C_slot(t11,C_fix(1));
t16=C_eqp(lf[3],t15);
if(C_truep(t16)){
t17=C_i_car(t13);
t18=C_eqp(((C_word*)t0)[2],t17);
if(C_truep(t18)){
t19=C_a_i_cons(&a,2,C_a_i_cons(&a,2,C_SCHEME_FALSE,t2),((C_word*)((C_word*)t0)[3])[1]);
t20=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t19);
t21=C_i_car(t14);
t22=C_eqp(((C_word*)t0)[4],t21);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10942,a[2]=t7,a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t24=C_u_i_cdr(t7);
t25=C_i_length(t24);
t26=C_eqp(((C_word*)t0)[6],t25);
if(C_truep(t26)){
t27=t23;
f_10942(2,t27,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm:1478: quit */
t27=*((C_word*)lf[167]+1);
((C_proc4)(void*)(*((C_word*)t27+1)))(4,t27,t23,lf[172],((C_word*)t0)[2]);}}
else{
t23=C_u_i_car(t14);
t24=C_i_assq(t23,((C_word*)((C_word*)t0)[7])[1]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10979,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],a[4]=t7,a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:1476: g2375 */
t26=t25;
f_10979(t26,t1,t24);}
else{
/* optimizer.scm:1498: bomb */
t25=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t25+1)))(4,t25,t1,lf[175],t14);}}}
else{
t19=C_u_i_car(t13);
t20=C_eqp(((C_word*)t0)[4],t19);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11084,a[2]=t7,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1500: node-class-set! */
t22=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t22+1)))(4,t22,t21,t2,lf[176]);}
else{
/* optimizer.scm:1503: bomb */
t21=*((C_word*)lf[156]+1);
((C_proc3)(void*)(*((C_word*)t21+1)))(3,t21,t1,lf[177]);}}}
else{
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,C_SCHEME_UNDEFINED);}}
else{
t11=C_eqp(t9,lf[6]);
if(C_truep(t11)){
t12=C_i_car(t4);
t13=C_i_car(t7);
if(C_truep(C_i_memq(t12,((C_word*)t0)[9]))){
t14=C_a_i_cons(&a,2,C_a_i_cons(&a,2,t12,t13),((C_word*)((C_word*)t0)[7])[1]);
t15=C_mutate2(((C_word *)((C_word*)t0)[7])+1,t14);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11135,a[2]=((C_word*)t0)[8],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t17=C_i_cadr(t7);
/* optimizer.scm:1509: copy-node! */
t18=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t16,t17,t2);}
else{
t14=((C_word*)((C_word*)t0)[8])[1];
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11147,a[2]=t16,a[3]=t14,tmp=(C_word)a,a+=4,tmp));
t18=((C_word*)t16)[1];
f_11147(t18,t1,t7);}}
else{
t12=((C_word*)((C_word*)t0)[8])[1];
t13=C_i_check_list_2(t7,lf[2]);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11176,a[2]=t15,a[3]=t12,tmp=(C_word)a,a+=4,tmp));
t17=((C_word*)t15)[1];
f_11176(t17,t1,t7);}}}

/* k7588 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_7590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7590,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7599,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_7599(t5,t3);}
else{
t5=C_i_length(((C_word*)t0)[5]);
t6=((C_word*)t0)[2];
t7=C_u_i_cdr(t6);
t8=C_u_i_car(t7);
t9=t4;
f_7599(t9,C_i_nequalp(t5,t8));}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k10677 in k10674 in k10657 in k10654 in k10587 in k10584 in k10578 in k10575 in k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10679,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10682,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1547: copy-node! */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[4]);}

/* k7597 in k7588 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_7599(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7599,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7604,tmp=(C_word)a,a+=2,tmp);
t3=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7646,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t6=((C_word*)t0)[5];
t7=C_u_i_car(t6);
/* optimizer.scm:967: varnode */
t8=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t5,t7);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k10674 in k10657 in k10654 in k10587 in k10584 in k10578 in k10575 in k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10676,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10679,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10747,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm:1538: fold-right */
t4=*((C_word*)lf[137]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,((C_word*)t0)[5],((C_word*)t0)[2]);}

/* k5405 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5407,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_length(((C_word*)t0)[2]);
if(C_truep(C_i_lessp(t2,((C_word*)t0)[3]))){
/* optimizer.scm:397: walk-generic */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6267(t3,((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[8],((C_word*)t0)[9],((C_word*)t0)[10],((C_word*)t0)[11],C_SCHEME_TRUE);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5421,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[15],a[9]=t4,a[10]=((C_word*)t0)[16],a[11]=((C_word*)t0)[17],a[12]=((C_word*)t0)[18],tmp=(C_word)a,a+=13,tmp));
t6=((C_word*)t4)[1];
f_5421(t6,((C_word*)t0)[5],((C_word*)t0)[19],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}}
else{
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5604,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[20],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[21],a[16]=((C_word*)t0)[6],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5741,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[20],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:424: test */
t4=((C_word*)((C_word*)t0)[18])[1];
f_4069(t4,t3,((C_word*)t0)[22],lf[64]);}}

/* k4591 in k4588 in g354 in k4529 in k4523 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:245: varnode */
t2=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k4588 in g354 in k4529 in k4523 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_4590(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4590,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4593,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:244: debugging */
t3=*((C_word*)lf[17]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[18],lf[52],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* optimizer.scm:246: varnode */
t2=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[4]);}}

/* k10680 in k10677 in k10674 in k10657 in k10654 in k10587 in k10584 in k10578 in k10575 in k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 in ... */
static void C_ccall f_10682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10682,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10724,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_10724(t6,((C_word*)t0)[3],t2);}

/* k8210 in map-loop1719 in k8099 in k8091 in k8088 in k8056 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_8212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8212,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8183(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8183(t6,((C_word*)t0)[5],t5);}}

/* map-loop1691 in k8091 in k8088 in k8056 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_8218(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8218,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8247,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:1037: gensym */
t4=*((C_word*)lf[87]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10688 in for-each-loop2510 in k10680 in k10677 in k10674 in k10657 in k10654 in k10587 in k10584 in k10578 in k10575 in k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in ... */
static void C_ccall f_10690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10690,2,t0,t1);}
t2=C_slot(((C_word*)t0)[2],C_fix(3));
t3=C_a_i_record4(&a,4,lf[14],lf[15],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_set_car(t2,t3));}

/* loop in k5405 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_5421(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5421,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=C_i_nullp(t2);
t7=(C_truep(t6)?t6:C_i_zerop(t3));
if(C_truep(t7)){
t8=f_4105(((C_word*)((C_word*)t0)[2])[1]);
t9=C_SCHEME_END_OF_LIST;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5435,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5495,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=t12,a[8]=t10,a[9]=t13,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm:405: append-reverse */
t15=*((C_word*)lf[86]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,t5,t4);}
else{
t8=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5501,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=t3,a[6]=t4,a[7]=((C_word*)t0)[9],a[8]=t5,a[9]=((C_word*)t0)[3],a[10]=((C_word*)t0)[4],a[11]=((C_word*)t0)[5],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
t9=C_i_car(t2);
/* optimizer.scm:408: test */
t10=((C_word*)((C_word*)t0)[12])[1];
f_4069(t10,t8,t9,lf[60]);}}

/* k8560 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_8562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8562,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[2]);
t3=(C_truep(t2)?t2:*((C_word*)lf[145]+1));
if(C_truep(t3)){
t4=((C_word*)t0)[2];
t5=C_u_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8584,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[6]))){
t7=((C_word*)t0)[6];
t8=C_u_i_cdr(t7);
t9=t6;
f_8584(t9,C_a_i_cons(&a,2,C_SCHEME_TRUE,t8));}
else{
t7=t6;
f_8584(t7,((C_word*)t0)[6]);}}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k9740 in k9736 in loop in a9703 in k9690 in k9661 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9742,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* a12637 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_12638(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_12638,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
if(C_truep(C_i_equalp(t4,*((C_word*)lf[217]+1)))){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12685,a[2]=t4,a[3]=t5,a[4]=t7,a[5]=t8,a[6]=t1,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:763: get-list */
t10=*((C_word*)lf[124]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,t2,t3,lf[78]);}}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_optimizer_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_optimizer_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("optimizer_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1849)){
C_save(t1);
C_rereclaim2(1849*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,229);
lf[0]=C_h_intern(&lf[0],34,"\010compilerscan-toplevel-assignments");
lf[1]=C_h_intern(&lf[1],13,"alist-update!");
lf[2]=C_h_intern(&lf[2],8,"for-each");
lf[3]=C_h_intern(&lf[3],13,"\004corevariable");
lf[4]=C_h_intern(&lf[4],6,"remove");
lf[5]=C_h_intern(&lf[5],2,"if");
lf[6]=C_h_intern(&lf[6],3,"let");
lf[7]=C_h_intern(&lf[7],6,"append");
lf[8]=C_h_intern(&lf[8],4,"last");
lf[9]=C_h_intern(&lf[9],7,"butlast");
lf[10]=C_h_intern(&lf[10],6,"lambda");
lf[11]=C_h_intern(&lf[11],11,"\004corelambda");
lf[12]=C_h_intern(&lf[12],9,"\004corecall");
lf[13]=C_h_intern(&lf[13],4,"set!");
lf[14]=C_h_intern(&lf[14],4,"node");
lf[15]=C_h_intern(&lf[15],14,"\004coreundefined");
lf[16]=C_h_intern(&lf[16],19,"\010compilercopy-node!");
lf[17]=C_h_intern(&lf[17],18,"\010compilerdebugging");
lf[18]=C_h_intern(&lf[18],1,"o");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000&dropping redundant toplevel assignment");
lf[20]=C_h_intern(&lf[20],9,"alist-ref");
lf[21]=C_h_intern(&lf[21],9,"\004corecond");
lf[22]=C_h_intern(&lf[22],11,"\004coreswitch");
lf[23]=C_h_intern(&lf[23],8,"\003sysput!");
lf[24]=C_h_intern(&lf[24],21,"\010compileralways-bound");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\014safe globals");
lf[26]=C_h_intern(&lf[26],17,"delete-duplicates");
lf[27]=C_h_intern(&lf[27],3,"eq\077");
lf[28]=C_h_intern(&lf[28],1,"p");
lf[29]=C_decode_literal(C_heaptop,"\376B\000\000 scanning toplevel assignments...");
lf[30]=C_h_intern(&lf[30],24,"\010compilersimplifications");
lf[31]=C_h_intern(&lf[31],23,"\010compilersimplified-ops");
lf[32]=C_h_intern(&lf[32],41,"\010compilerperform-high-level-optimizations");
lf[33]=C_h_intern(&lf[33],12,"\010compilerget");
lf[34]=C_h_intern(&lf[34],5,"quote");
lf[35]=C_h_intern(&lf[35],3,"map");
lf[36]=C_h_intern(&lf[36],19,"\010compilermatch-node");
lf[37]=C_h_intern(&lf[37],3,"any");
lf[38]=C_h_intern(&lf[38],18,"\003syshash-table-ref");
lf[39]=C_h_intern(&lf[39],30,"\010compilerbroken-constant-nodes");
lf[40]=C_h_intern(&lf[40],14,"\010compilerqnode");
lf[41]=C_h_intern(&lf[41],11,"lset-adjoin");
lf[42]=C_h_intern(&lf[42],27,"\010compilerconstant-form-eval");
lf[43]=C_h_intern(&lf[43],5,"every");
lf[44]=C_h_intern(&lf[44],9,"foldable\077");
lf[45]=C_h_intern(&lf[45],7,"\003sysget");
lf[46]=C_h_intern(&lf[46],18,"\010compilerintrinsic");
lf[47]=C_h_intern(&lf[47],13,"\010compilerput!");
lf[48]=C_h_intern(&lf[48],10,"replacable");
lf[49]=C_h_intern(&lf[49],5,"value");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\035substituted constant variable");
lf[51]=C_h_intern(&lf[51],16,"\010compilervarnode");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\032propagated global variable");
lf[53]=C_h_intern(&lf[53],2,"no");
lf[54]=C_h_intern(&lf[54],15,"\010compilerinline");
lf[55]=C_h_intern(&lf[55],11,"collapsable");
lf[56]=C_h_intern(&lf[56],6,"global");
lf[57]=C_h_intern(&lf[57],9,"replacing");
lf[58]=C_h_intern(&lf[58],12,"contractable");
lf[59]=C_h_intern(&lf[59],9,"removable");
lf[60]=C_h_intern(&lf[60],6,"unused");
lf[61]=C_h_intern(&lf[61],9,"partition");
lf[62]=C_h_intern(&lf[62],26,"\010compilerbuild-lambda-list");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\047merged explicitly consed rest parameter");
lf[64]=C_h_intern(&lf[64],13,"explicit-rest");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000 removed unused formal parameters");
lf[66]=C_h_intern(&lf[66],30,"\010compilerdecompose-lambda-list");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\047merged explicitly consed rest parameter");
lf[68]=C_h_intern(&lf[68],21,"has-unused-parameters");
lf[69]=C_h_intern(&lf[69],18,"\004coredirect_lambda");
lf[70]=C_h_intern(&lf[70],13,"inline-target");
lf[71]=C_h_intern(&lf[71],31,"\010compilerinline-lambda-bindings");
lf[72]=C_h_intern(&lf[72],4,"void");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\024contracted procedure");
lf[74]=C_h_intern(&lf[74],24,"\010compilercheck-signature");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\0001removed call to pure procedure with unused result");
lf[76]=C_h_intern(&lf[76],37,"\010compilerexpression-has-side-effects\077");
lf[77]=C_h_intern(&lf[77],8,"assigned");
lf[78]=C_h_intern(&lf[78],10,"references");
lf[79]=C_h_intern(&lf[79],7,"unknown");
lf[80]=C_h_intern(&lf[80],1,"i");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\0008not inlining procedure because it refers to contractable");
lf[82]=C_h_intern(&lf[82],7,"call/cc");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\022inlining procedure");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\017global inlining");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\010inlining");
lf[86]=C_h_intern(&lf[86],14,"append-reverse");
lf[87]=C_h_intern(&lf[87],6,"gensym");
lf[88]=C_h_intern(&lf[88],1,"t");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000+removed unused parameter to known procedure");
lf[90]=C_h_intern(&lf[90],8,"split-at");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[92]=C_h_intern(&lf[92],20,"\004coreinline_allocate");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\042consed rest parameter at call site");
lf[94]=C_h_intern(&lf[94],21,"\010compilerllist-length");
lf[95]=C_h_intern(&lf[95],23,"\010compilerinline-locally");
lf[96]=C_h_intern(&lf[96],24,"\010compilerinline-max-size");
lf[97]=C_h_intern(&lf[97],9,"inlinable");
lf[98]=C_h_intern(&lf[98],22,"\010compilerinline-global");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000 inlining call to intrinsic alias");
lf[100]=C_h_intern(&lf[100],13,"\010compilerpure");
lf[101]=C_h_intern(&lf[101],11,"local-value");
lf[102]=C_h_intern(&lf[102],18,"\010compilercall-info");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\034removing global contractable");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\0006removed side-effect free assignment to unused variable");
lf[105]=C_h_intern(&lf[105],16,"inline-transient");
lf[106]=C_h_intern(&lf[106],26,"\010compilervariable-visible\077");
lf[107]=C_h_intern(&lf[107],7,"reverse");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\031removed conditional forms");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\025removed binding forms");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\022replaced variables");
lf[111]=C_h_intern(&lf[111],5,"print");
lf[112]=C_h_intern(&lf[112],7,"newline");
lf[113]=C_h_intern(&lf[113],6,"print\052");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\004    ");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\027  call simplifications:");
lf[116]=C_h_intern(&lf[116],30,"\010compilerwith-debugging-output");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\017simplifications");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\022traversal phase...");
lf[119]=C_h_intern(&lf[119],34,"\010compilerperform-pre-optimization!");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\023Removed `not\047 forms");
lf[121]=C_h_intern(&lf[121],24,"node-subexpressions-set!");
lf[122]=C_h_intern(&lf[122],20,"node-parameters-set!");
lf[123]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[124]=C_h_intern(&lf[124],17,"\010compilerget-list");
lf[125]=C_h_intern(&lf[125],3,"not");
lf[126]=C_h_intern(&lf[126],10,"call-sites");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\031pre-optimization phase...");
lf[128]=C_h_intern(&lf[128],24,"register-simplifications");
lf[129]=C_h_intern(&lf[129],19,"\003syshash-table-set!");
lf[130]=C_h_intern(&lf[130],38,"\010compilerreorganize-recursive-bindings");
lf[131]=C_h_intern(&lf[131],28,"\010compilerscan-used-variables");
lf[132]=C_h_intern(&lf[132],6,"filter");
lf[133]=C_h_intern(&lf[133],6,"lset<=");
lf[134]=C_h_intern(&lf[134],10,"filter-map");
lf[135]=C_h_intern(&lf[135],10,"append-map");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000!converted assignments to bindings");
lf[137]=C_h_intern(&lf[137],10,"fold-right");
lf[138]=C_h_intern(&lf[138],4,"fold");
lf[139]=C_h_intern(&lf[139],16,"topological-sort");
lf[140]=C_h_intern(&lf[140],27,"\010compilersubstitution-table");
lf[141]=C_h_intern(&lf[141],16,"\010compilerrewrite");
lf[142]=C_h_intern(&lf[142],28,"\010compilersimplify-named-call");
lf[143]=C_h_intern(&lf[143],37,"\010compilerinline-substitutions-enabled");
lf[144]=C_h_intern(&lf[144],11,"\004coreinline");
lf[145]=C_h_intern(&lf[145],6,"unsafe");
lf[146]=C_h_intern(&lf[146],11,"number-type");
lf[147]=C_h_intern(&lf[147],6,"fixnum");
lf[148]=C_h_intern(&lf[148],21,"\010compilerfold-boolean");
lf[149]=C_h_intern(&lf[149],6,"flonum");
lf[150]=C_h_intern(&lf[150],7,"generic");
lf[151]=C_h_intern(&lf[151],5,"cons\052");
lf[152]=C_h_intern(&lf[152],9,"\004coreproc");
lf[153]=C_h_intern(&lf[153],4,"conc");
lf[154]=C_h_intern(&lf[154],5,"fifth");
lf[155]=C_h_intern(&lf[155],19,"\010compilerfold-inner");
lf[156]=C_h_intern(&lf[156],13,"\010compilerbomb");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\023bad type (optimize)");
lf[158]=C_h_intern(&lf[158],34,"\010compilertransform-direct-lambdas!");
lf[159]=C_h_intern(&lf[159],24,"\010compilercallback-lambda");
lf[160]=C_h_intern(&lf[160],5,"boxed");
lf[161]=C_h_intern(&lf[161],15,"\004coreinline_ref");
lf[162]=C_h_intern(&lf[162],37,"\010compilerestimate-foreign-result-size");
lf[163]=C_h_intern(&lf[163],19,"\004coreinline_loc_ref");
lf[164]=C_h_intern(&lf[164],16,"\004coredirect_call");
lf[165]=C_h_intern(&lf[165],5,"lset=");
lf[166]=C_h_intern(&lf[166],6,"delete");
lf[167]=C_h_intern(&lf[167],13,"\010compilerquit");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000;known procedure called with wrong number of arguments: `~A\047");
lf[169]=C_h_intern(&lf[169],15,"lset-difference");
lf[170]=C_h_intern(&lf[170],15,"node-class-set!");
lf[171]=C_h_intern(&lf[171],12,"\004corerecurse");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000Gknown procedure called recursively with wrong number of arguments: `~A\047");
lf[173]=C_h_intern(&lf[173],4,"take");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000Gknown procedure called recursively with wrong number of arguments: `~A\047");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\014missing kvar");
lf[176]=C_h_intern(&lf[176],11,"\004corereturn");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\017bad call (leaf)");
lf[178]=C_h_intern(&lf[178],6,"cdaddr");
lf[179]=C_h_intern(&lf[179],6,"caaddr");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid parameter list");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\0006direct leaf routine with hoistable closures/allocation");
lf[182]=C_h_intern(&lf[182],6,"unzip1");
lf[183]=C_h_intern(&lf[183],16,"\003sysmake-promise");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\036direct leaf routine/allocation");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000(direct leaf routine optimization pass...");
lf[186]=C_h_intern(&lf[186],36,"\010compilerdetermine-loop-and-dispatch");
lf[187]=C_h_intern(&lf[187],16,"\003sysdynamic-wind");
lf[188]=C_h_intern(&lf[188],13,"list-tabulate");
lf[189]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[190]=C_h_intern(&lf[190],2,"f_");
lf[191]=C_h_intern(&lf[191],1,"x");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\012clustering");
lf[193]=C_h_intern(&lf[193],1,"a");
lf[194]=C_h_intern(&lf[194],3,"max");
lf[195]=C_h_intern(&lf[195],1,"k");
lf[196]=C_h_intern(&lf[196],8,"dispatch");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\027collecting clusters ...");
lf[198]=C_h_intern(&lf[198],11,"make-vector");
lf[199]=C_h_intern(&lf[199],3,"var");
lf[200]=C_h_intern(&lf[200],2,"d2");
lf[201]=C_h_intern(&lf[201],1,"y");
lf[202]=C_h_intern(&lf[202],2,"d3");
lf[203]=C_h_intern(&lf[203],1,"z");
lf[204]=C_h_intern(&lf[204],2,"d1");
lf[205]=C_h_intern(&lf[205],2,"op");
lf[206]=C_h_intern(&lf[206],5,"clist");
lf[207]=C_h_intern(&lf[207],34,"\010compilermembership-test-operators");
lf[208]=C_h_intern(&lf[208],32,"\010compilermembership-unfold-limit");
lf[209]=C_h_intern(&lf[209],4,"var1");
lf[210]=C_h_intern(&lf[210],4,"var0");
lf[211]=C_h_intern(&lf[211],6,"const1");
lf[212]=C_h_intern(&lf[212],4,"var2");
lf[213]=C_h_intern(&lf[213],6,"const2");
lf[214]=C_h_intern(&lf[214],5,"body2");
lf[215]=C_h_intern(&lf[215],4,"rest");
lf[216]=C_h_intern(&lf[216],5,"body1");
lf[217]=C_h_intern(&lf[217],27,"\010compilereq-inline-operator");
lf[218]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\002\376\377\016");
lf[219]=C_h_intern(&lf[219],19,"\010compilerimmediate\077");
lf[220]=C_h_intern(&lf[220],5,"const");
lf[221]=C_h_intern(&lf[221],1,"n");
lf[222]=C_h_intern(&lf[222],7,"clauses");
lf[223]=C_h_intern(&lf[223],1,"d");
lf[224]=C_h_intern(&lf[224],4,"body");
lf[225]=C_h_intern(&lf[225],4,"more");
lf[226]=C_h_intern(&lf[226],4,"args");
lf[227]=C_h_intern(&lf[227],1,"b");
lf[228]=C_h_intern(&lf[228],1,"c");
C_register_lf2(lf,229,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3672,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k5493 in loop in k5405 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5495,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5445,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5458,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_5458(t7,t3,t2);}

/* k4290 in walk in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4292,2,t0,t1);}
t2=t1;
t3=C_slot(t2,C_fix(3));
t4=t3;
t5=C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4311,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t7=C_eqp(t5,lf[5]);
if(C_truep(t7)){
t8=C_i_car(t4);
t9=C_slot(t8,C_fix(1));
t10=C_eqp(lf[34],t9);
if(C_truep(t10)){
t11=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[4])[1],C_fix(1));
t12=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t11);
t13=f_4105(((C_word*)((C_word*)t0)[5])[1]);
t14=C_u_i_car(t4);
t15=C_slot(t14,C_fix(2));
t16=C_i_car(t15);
t17=(C_truep(t16)?C_i_cadr(t4):C_i_caddr(t4));
/* optimizer.scm:180: walk */
t18=((C_word*)((C_word*)t0)[6])[1];
f_4278(t18,t6,t17,((C_word*)t0)[7],((C_word*)t0)[8]);}
else{
/* optimizer.scm:170: simplify */
t11=((C_word*)((C_word*)t0)[2])[1];
f_4146(t11,((C_word*)t0)[3],t2);}}
else{
t8=C_eqp(t5,lf[12]);
if(C_truep(t8)){
t9=C_i_car(t4);
t10=C_slot(t9,C_fix(1));
t11=C_eqp(lf[3],t10);
if(C_truep(t11)){
t12=C_u_i_car(t4);
t13=C_slot(t12,C_fix(2));
t14=C_i_car(t13);
t15=t14;
t16=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4370,a[2]=t4,a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=t6,a[8]=t15,a[9]=((C_word*)t0)[2],a[10]=((C_word*)t0)[3],tmp=(C_word)a,a+=11,tmp);
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4428,a[2]=t4,a[3]=t16,a[4]=((C_word*)t0)[11],a[5]=t15,tmp=(C_word)a,a+=6,tmp);
/* tweaks.scm:51: ##sys#get */
t18=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t17,t15,lf[46]);}
else{
/* optimizer.scm:170: simplify */
t12=((C_word*)((C_word*)t0)[2])[1];
f_4146(t12,((C_word*)t0)[3],t2);}}
else{
/* optimizer.scm:170: simplify */
t9=((C_word*)((C_word*)t0)[2])[1];
f_4146(t9,((C_word*)t0)[3],t2);}}}

/* k5485 in map-loop675 in k5493 in loop in k5405 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5487,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_5458(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_5458(t6,((C_word*)t0)[5],t5);}}

/* find in find-path in k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_6805(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6805,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_memq(t2,t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=C_i_assq(t2,((C_word*)((C_word*)t0)[2])[1]);
t5=C_i_cdr(t4);
t6=C_i_memq(((C_word*)t0)[3],t5);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=C_a_i_cons(&a,2,t2,t3);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6829,a[2]=((C_word*)t0)[4],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:836: any */
t10=*((C_word*)lf[37]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,t9,t5);}}}

/* k8586 in k8582 in k8560 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_8588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8588,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[3],t1));}

/* k8582 in k8560 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_8584(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8584,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8588,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_list2(&a,2,((C_word*)t0)[3],C_SCHEME_TRUE);
t5=C_a_i_record4(&a,4,lf[14],lf[152],t4,C_SCHEME_END_OF_LIST);
/* optimizer.scm:1105: cons* */
t6=*((C_word*)lf[151]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t3,t5,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k9763 in loop in a9703 in k9690 in k9661 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9765,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k11387 in walk in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_11389(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11389,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[5]);
/* optimizer.scm:1609: walk */
t4=((C_word*)((C_word*)t0)[6])[1];
f_11343(t4,((C_word*)t0)[7],((C_word*)t0)[8],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11403,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_slot(((C_word*)t0)[9],C_fix(1));
t4=C_eqp(lf[13],t3);
if(C_truep(t4)){
t5=C_slot(((C_word*)t0)[9],C_fix(3));
t6=C_i_car(t5);
t7=t6;
t8=C_slot(((C_word*)t0)[9],C_fix(2));
t9=C_i_car(t8);
t10=t9;
t11=C_slot(t7,C_fix(1));
t12=C_eqp(lf[11],t11);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11451,a[2]=t10,a[3]=((C_word*)t0)[5],a[4]=t7,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11464,a[2]=t13,a[3]=((C_word*)t0)[12],a[4]=t10,tmp=(C_word)a,a+=5,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11479,a[2]=t14,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:1616: get */
t16=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t16+1)))(5,t16,t15,((C_word*)t0)[12],t10,lf[78]);}
else{
t13=t2;
f_11403(t13,C_SCHEME_FALSE);}}
else{
t5=t2;
f_11403(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_11403(t3,C_SCHEME_FALSE);}}}

/* map-loop675 in k5493 in loop in k5405 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_5458(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5458,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5487,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:402: g681 */
t5=((C_word*)t0)[5];
f_5435(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9736 in loop in a9703 in k9690 in k9661 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9738,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9742,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* optimizer.scm:1314: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_9718(t6,t3,C_SCHEME_END_OF_LIST,t5);}

/* k5446 in k5443 in k5493 in loop in k5405 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5448,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[3],((C_word*)t0)[4]));}

/* k8823 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_8825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8825,2,t0,t1);}
t2=t1;
if(C_truep(*((C_word*)lf[143]+1))){
t3=C_i_not(((C_word*)t0)[2]);
t4=(C_truep(t3)?t3:C_i_nequalp(((C_word*)t0)[3],((C_word*)t0)[2]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8848,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[3],a[8]=t2,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t6=((C_word*)t0)[10];
/* tweaks.scm:51: ##sys#get */
t7=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,lf[46]);}
else{
t5=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k5982 in k5995 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* k5443 in k5493 in loop in k5405 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5445,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5448,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:406: invalidate-gae! */
f_4109(t3,((C_word*)t0)[5]);}

/* k12511 in a12478 in k12439 in a12418 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_12513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12513,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12517,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:815: qnode */
t4=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* k12515 in k12511 in a12478 in k12439 in a12418 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_12517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12517,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_record4(&a,4,lf[14],lf[144],((C_word*)t0)[3],t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12505,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:816: qnode */
t6=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,C_SCHEME_TRUE);}

/* k9458 in k9388 in k9385 in k9379 in k9373 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9460,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[4],t2));}

/* a9461 in k9388 in k9385 in k9379 in k9373 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9462(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9462,4,t0,t1,t2,t3);}
t4=C_eqp(*((C_word*)lf[146]+1),lf[147]);
if(C_truep(t4)){
t5=C_a_i_list1(&a,1,((C_word*)t0)[2]);
t6=C_a_i_list2(&a,2,t2,t3);
t7=t1;
t8=t7;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_record4(&a,4,lf[14],lf[144],t5,t6));}
else{
t5=C_a_i_list2(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
t6=C_a_i_list2(&a,2,t2,t3);
t7=t1;
t8=t7;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_record4(&a,4,lf[14],lf[92],t5,t6));}}

/* k4368 in k4290 in walk in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4370,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cddr(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4379,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:192: constant-form-eval */
t4=*((C_word*)lf[42]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[7],((C_word*)t0)[8],t2,t3);}
else{
/* optimizer.scm:170: simplify */
t2=((C_word*)((C_word*)t0)[9])[1];
f_4146(t2,((C_word*)t0)[10],((C_word*)t0)[4]);}}

/* k12519 in k12439 in a12418 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_12521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:810: fold-right */
t2=*((C_word*)lf[137]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}

/* k10657 in k10654 in k10587 in k10584 in k10578 in k10575 in k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10659,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[2])?C_i_pairp(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=C_a_i_record4(&a,4,lf[14],C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10676,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:1536: copy-node! */
t6=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t4);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k10654 in k10587 in k10584 in k10578 in k10575 in k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10656,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10659,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10823,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_10823(t6,t2,t1);}

/* a4378 in k4368 in k4290 in walk in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4379(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4379,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(t2)){
t6=f_4105(((C_word*)((C_word*)t0)[2])[1]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4400,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:204: qnode */
t8=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t4);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4389,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[5])){
t7=t6;
f_4389(t7,C_SCHEME_UNDEFINED);}
else{
t7=C_set_block_item(((C_word*)t0)[6],0,C_SCHEME_FALSE);
t8=t6;
f_4389(t8,t7);}}}

/* a6828 in find in find-path in k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6829(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6829,3,t0,t1,t2);}
/* optimizer.scm:836: find */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6805(t3,t1,t2,((C_word*)t0)[3]);}

/* k4309 in k4290 in walk in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:170: simplify */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4146(t2,((C_word*)t0)[3],t1);}

/* k12503 in k12515 in k12511 in a12478 in k12439 in a12418 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_12505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12505,2,t0,t1);}
t2=C_a_i_list3(&a,3,((C_word*)t0)[2],t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[4];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[14],lf[21],C_SCHEME_END_OF_LIST,t2));}

/* k7446 in k7357 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_7448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7448,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
f_7362(t3,C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[4],t2));}

/* k3993 in scan-toplevel-assignments in k3676 in k3673 in k3670 */
static void C_ccall f_3995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3998,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:109: scan */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3755(t3,t2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}

/* k3996 in k3993 in scan-toplevel-assignments in k3676 in k3673 in k3670 */
static void C_ccall f_3998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3998,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4001,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4059,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:111: delete-duplicates */
t4=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[27]+1));}
else{
t3=t2;
f_4001(2,t3,C_SCHEME_UNDEFINED);}}

/* g681 in loop in k5405 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_5435(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5435,NULL,3,t0,t1,t2);}
/* optimizer.scm:402: g698 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4278(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k5321 in k5310 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5323,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5326,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
/* optimizer.scm:379: check-signature */
t3=*((C_word*)lf[74]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[17],((C_word*)t0)[14],((C_word*)t0)[13]);}

/* k5324 in k5321 in k5310 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5329,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
/* optimizer.scm:380: debugging */
t3=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[18],lf[83],((C_word*)t0)[9]);}

/* k5327 in k5324 in k5321 in k5310 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5329,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_5334,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
/* optimizer.scm:381: call/cc */
t3=*((C_word*)lf[82]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[16],t2);}

/* k5310 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5313,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[3];
t4=C_i_check_list_2(t3,lf[2]);
t5=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_5323,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[2],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5372,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_5372(t9,t5,t3);}

/* g624 in k5310 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_5313(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5313,NULL,3,t0,t1,t2);}
t3=*((C_word*)lf[47]+1);
/* optimizer.scm:378: g639 */
t4=*((C_word*)lf[47]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,((C_word*)t0)[2],t2,lf[70],C_SCHEME_TRUE);}

/* k8245 in map-loop1691 in k8091 in k8088 in k8056 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_8247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8247,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8218(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8218(t6,((C_word*)t0)[5],t5);}}

/* k6103 in k6097 in k6080 in k6054 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6105,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record4(&a,4,lf[14],lf[15],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}

/* k10172 in a10157 in rec in scan in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1385: rec */
t2=((C_word*)((C_word*)t0)[2])[1];
f_10076(t2,((C_word*)t0)[3],((C_word*)t0)[4],C_SCHEME_FALSE,C_SCHEME_FALSE,t1);}

/* k6470 in k6467 in k6464 in perform-pre-optimization! in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[3])[1]);}

/* k12369 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_12371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_pairp(((C_word*)((C_word*)t0)[2])[1]);
/* optimizer.scm:1762: values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[4],t2);}

/* k11082 in rec in k10584 in k10578 in k10575 in k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_11084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11084,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11087,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1501: node-parameters-set! */
t3=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}

/* k12359 in map-loop2701 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_12361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12361,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_12332(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_12332(t6,((C_word*)t0)[5],t5);}}

/* k11085 in k11082 in rec in k10584 in k10578 in k10575 in k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_11087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_u_i_cdr(((C_word*)t0)[2]);
/* optimizer.scm:1502: node-subexpressions-set! */
t3=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[4],t2);}

/* a10194 in rec in scan in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10195(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10195,3,t0,t1,t2);}
/* optimizer.scm:1390: rec */
t3=((C_word*)((C_word*)t0)[2])[1];
f_10076(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k12388 in for-each-loop2682 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_12390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_12380(t3,((C_word*)t0)[4],t2);}

/* k6467 in k6464 in perform-pre-optimization! in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6469,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6472,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_greaterp(((C_word*)((C_word*)t0)[4])[1],C_fix(0)))){
/* optimizer.scm:597: debugging */
t3=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[18],lf[120],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)((C_word*)t0)[3])[1]);}}

/* k6464 in perform-pre-optimization! in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6466,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6469,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6486,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* tweaks.scm:51: ##sys#get */
t4=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[125],lf[46]);}

/* k7516 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_7518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7518,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_caddr(((C_word*)t0)[2]);
t3=(C_truep(t2)?t2:*((C_word*)lf[145]+1));
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[3]);
t5=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t6=((C_word*)t0)[2];
t7=C_u_i_cdr(t6);
t8=C_u_i_car(t7);
t9=C_a_i_list1(&a,1,t8);
t10=((C_word*)t0)[3];
t11=C_a_i_record4(&a,4,lf[14],lf[144],t9,t10);
t12=C_a_i_list2(&a,2,((C_word*)t0)[4],t11);
t13=((C_word*)t0)[5];
t14=t13;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_a_i_record4(&a,4,lf[14],lf[12],t5,t12));}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* for-each-loop2682 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_12380(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12380,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12390,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:1647: g2683 */
t5=((C_word*)t0)[3];
f_11632(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6431 in for-each-loop925 in k6388 in a6385 in k6343 in k6340 in k6336 in k6330 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6423(t3,((C_word*)t0)[4],t2);}

/* for-each-loop623 in k5310 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_5372(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5372,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5382,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:378: g624 */
t5=((C_word*)t0)[3];
f_5313(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g976 in k6484 in k6464 in perform-pre-optimization! in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_6487(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6487,NULL,3,t0,t1,t2);}
t3=C_i_cdr(t2);
t4=t3;
t5=C_slot(t4,C_fix(3));
t6=t5;
t7=C_i_cadr(t6);
t8=C_slot(t7,C_fix(2));
t9=C_i_car(t8);
t10=t9;
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6505,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t6,a[6]=t4,a[7]=((C_word*)t0)[4],a[8]=t10,tmp=(C_word)a,a+=9,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6722,a[2]=t11,a[3]=((C_word*)t0)[5],a[4]=t10,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:565: test */
t13=((C_word*)((C_word*)t0)[5])[1];
f_6459(t13,t12,t10,lf[79]);}

/* k6484 in k6464 in perform-pre-optimization! in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6486,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6487,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6738,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:595: test */
t4=((C_word*)((C_word*)t0)[5])[1];
f_6459(t4,t3,lf[125],lf[126]);}
else{
t2=((C_word*)t0)[6];
f_6469(2,t2,C_SCHEME_UNDEFINED);}}

/* k8885 in k8846 in k8823 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_8887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8887,2,t0,t1);}
t2=C_eqp(C_SCHEME_TRUE,((C_word*)t0)[2]);
if(C_truep(t2)){
t3=C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
t4=((C_word*)t0)[4];
f_8883(t4,C_a_i_list2(&a,2,t1,t3));}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t3=C_u_i_car(((C_word*)t0)[2]);
t4=C_a_i_times(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[4];
f_8883(t5,C_a_i_list2(&a,2,t1,t4));}
else{
t3=((C_word*)t0)[4];
f_8883(t3,C_a_i_list2(&a,2,t1,((C_word*)t0)[2]));}}}

/* k8881 in k8846 in k8823 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_8883(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8883,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_a_i_record4(&a,4,lf[14],lf[92],t1,t2);
t4=C_a_i_list2(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[4];
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[5],t4));}

/* k4644 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4649,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t1)){
t3=t2;
f_4649(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4779,a[2]=t2,a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:252: test */
t4=((C_word*)((C_word*)t0)[11])[1];
f_4069(t4,t3,((C_word*)t0)[10],lf[58]);}}

/* k4647 in k4644 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_4649(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4649,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_4105(((C_word*)((C_word*)t0)[2])[1]);
t3=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t3);
t5=C_i_cadr(((C_word*)t0)[4]);
/* optimizer.scm:256: walk */
t6=((C_word*)((C_word*)t0)[5])[1];
f_4278(t6,((C_word*)t0)[6],t5,((C_word*)t0)[7],((C_word*)t0)[8]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4666,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4721,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t4=C_i_car(((C_word*)t0)[4]);
t5=C_slot(t4,C_fix(1));
t6=C_eqp(lf[3],t5);
if(C_truep(t6)){
t7=C_u_i_car(((C_word*)t0)[4]);
t8=C_slot(t7,C_fix(2));
t9=C_i_car(t8);
/* optimizer.scm:259: test */
t10=((C_word*)((C_word*)t0)[11])[1];
f_4069(t10,t3,t9,lf[56]);}
else{
t7=t3;
f_4721(2,t7,C_SCHEME_FALSE);}}}

/* test in perform-pre-optimization! in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_6459(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6459,NULL,4,t0,t1,t2,t3);}
/* optimizer.scm:554: get */
t4=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* touch in perform-pre-optimization! in k4061 in k3676 in k3673 in k3670 */
static C_word C_fcall f_6455(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_overflow_check;
t1=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
return(C_SCHEME_TRUE);}

/* ##compiler#perform-pre-optimization! in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6452(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6452,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6455,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t13=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6459,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6466,a[2]=t1,a[3]=t5,a[4]=t7,a[5]=t9,a[6]=t3,a[7]=t11,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:556: debugging */
t15=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,lf[28],lf[127]);}

/* a5333 in k5327 in k5324 in k5321 in k5310 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5334(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5334,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5337,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5351,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(((C_word*)t0)[12],C_fix(3));
t6=C_i_car(t5);
/* optimizer.scm:390: inline-lambda-bindings */
t7=*((C_word*)lf[71]+1);
((C_proc8)(void*)(*((C_word*)t7+1)))(8,t7,t4,((C_word*)t0)[13],((C_word*)t0)[14],t6,C_SCHEME_TRUE,((C_word*)t0)[15],t3);}

/* cfk in a5333 in k5327 in k5324 in k5321 in k5310 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5337(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5337,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5341,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm:384: debugging */
t4=*((C_word*)lf[17]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,lf[80],lf[81],((C_word*)t0)[10],t2);}

/* k10337 in rec in scan in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_10339(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10339,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10344,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_u_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm:1425: every */
t4=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[5],t2,t3);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8846 in k8823 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_8848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8848,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[145]+1);
t3=(C_truep(*((C_word*)lf[145]+1))?*((C_word*)lf[145]+1):((C_word*)t0)[2]);
if(C_truep(t3)){
t4=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8883,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8887,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(C_truep(((C_word*)t0)[8])?(C_truep(C_fixnum_greaterp(((C_word*)t0)[7],C_fix(0)))?C_fixnum_less_or_equal_p(((C_word*)t0)[7],C_fix(8)):C_SCHEME_FALSE):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=C_i_cadr(((C_word*)t0)[9]);
/* optimizer.scm:1161: conc */
t10=*((C_word*)lf[153]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t9,((C_word*)t0)[7]);}
else{
t9=t7;
f_8887(2,t9,C_i_cadr(((C_word*)t0)[9]));}}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6225 in k6233 in k6237 in k6206 in k6248 in k6080 in k6054 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6099(t2,C_i_not(t1));}

/* a10343 in k10337 in rec in scan in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10344(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10344,3,t0,t1,t2);}
/* optimizer.scm:1425: rec */
t3=((C_word*)((C_word*)t0)[2])[1];
f_10076(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k5349 in a5333 in k5327 in k5324 in k5321 in k5310 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_4105(((C_word*)((C_word*)t0)[2])[1]);
/* optimizer.scm:394: walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4278(t3,((C_word*)t0)[4],t1,((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k8730 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_8732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8732,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_eqp(*((C_word*)lf[146]+1),t2);
if(C_truep(t3)){
t4=C_i_caddr(((C_word*)t0)[2]);
t5=C_a_i_list2(&a,2,C_SCHEME_TRUE,t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8754,a[2]=((C_word*)t0)[3],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8758,a[2]=t7,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t9=((C_word*)t0)[2];
t10=C_u_i_cdr(t9);
t11=C_u_i_cdr(t10);
t12=C_u_i_car(t11);
/* optimizer.scm:1132: varnode */
t13=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t8,t12);}
else{
t4=C_i_cadr(((C_word*)t0)[2]);
t5=C_eqp(*((C_word*)lf[146]+1),t4);
if(C_truep(t5)){
t6=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t7=C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[5]);
t8=((C_word*)t0)[3];
t9=t8;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_a_i_record4(&a,4,lf[14],lf[12],t6,t7));}
else{
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5380 in for-each-loop623 in k5310 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5372(t3,((C_word*)t0)[4],t2);}

/* k5339 in cfk in a5333 in k5327 in k5324 in k5321 in k5310 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5348,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:389: walk-generic */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6267(t3,t2,((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[8],((C_word*)t0)[9],((C_word*)t0)[10],C_SCHEME_TRUE);}

/* k5346 in k5339 in cfk in a5333 in k5327 in k5324 in k5321 in k5310 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 in ... */
static void C_ccall f_5348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:388: return */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* k4681 in k4664 in k4647 in k4644 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4683,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record4(&a,4,lf[14],lf[6],((C_word*)t0)[3],t1));}

/* map-loop397 in k4664 in k4647 in k4644 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_4685(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4685,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4714,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:264: g403 */
t5=((C_word*)t0)[5];
f_4676(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8105 in k8099 in k8091 in k8088 in k8056 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_8107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8107,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8112,tmp=(C_word)a,a+=2,tmp);
t3=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t4=t3;
t5=C_eqp(*((C_word*)lf[146]+1),lf[147]);
t6=(C_truep(t5)?C_i_car(((C_word*)t0)[2]):C_i_cadr(((C_word*)t0)[2]));
t7=C_a_i_list1(&a,1,t6);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8153,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8155,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:1049: fold-boolean */
t11=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,t1);}

/* k12839 in k13054 in k13060 in loop1 in a12726 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_12841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12841,2,t0,t1);}
t2=t1;
if(C_truep(C_i_pairp(t2))){
t3=C_i_car(((C_word*)t0)[2]);
t4=C_u_i_car(t2);
t5=C_eqp(t3,t4);
if(C_truep(t5)){
t6=C_i_car(((C_word*)t0)[3]);
t7=C_a_i_list1(&a,1,t6);
t8=C_u_i_cdr(t2);
t9=C_i_cadr(((C_word*)t0)[4]);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12868,a[2]=t11,a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_12868(t13,((C_word*)t0)[6],t7,t8,t9);}
else{
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* g403 in k4664 in k4647 in k4644 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_4676(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4676,NULL,3,t0,t1,t2);}
/* optimizer.scm:264: g420 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4278(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k12683 in a12637 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_12685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12685,2,t0,t1);}
t2=C_i_length(t1);
t3=C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=C_a_i_list1(&a,1,((C_word*)t0)[2]);
t5=((C_word*)t0)[3];
t6=C_a_i_record4(&a,4,lf[14],lf[144],t4,t5);
t7=C_a_i_list3(&a,3,t6,((C_word*)t0)[4],((C_word*)t0)[5]);
t8=((C_word*)t0)[6];
t9=((C_word*)t0)[7];
t10=t8;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_a_i_record4(&a,4,lf[14],lf[5],t9,t7));}
else{
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k7322 in loop in a9703 in k9690 in k9661 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_7324(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm:923: qnode */
t3=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],t2);}
else{
/* optimizer.scm:924: qnode */
t2=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* a4806 in k4800 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4807(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4807,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4813,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4825,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t3,a[9]=t4,a[10]=((C_word*)t0)[2],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm:272: ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* k10138 in rec in scan in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10140,2,t0,t1);}
t2=C_i_not(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=C_i_memq(((C_word*)t0)[3],((C_word*)t0)[4]);
t4=C_i_not(t3);
if(C_truep(t4)){
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=((C_word*)((C_word*)t0)[5])[1];
if(C_truep(t5)){
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[6])[1],C_fix(2));
t7=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_TRUE);}}}}

/* k4800 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4802,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4807,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm:270: decompose-lambda-list */
t3=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[9],((C_word*)t0)[10],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4901,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
/* optimizer.scm:286: test */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4069(t3,t2,((C_word*)t0)[6],lf[64]);}}

/* a10157 in rec in scan in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10158,5,t0,t1,t2,t3,t4);}
t5=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t6=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t5);
t7=C_i_car(((C_word*)t0)[4]);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10174,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1385: append */
t10=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t2,((C_word*)t0)[6]);}

/* k6544 in k6538 in k6532 in k6512 in k6506 in k6503 in g976 in k6484 in k6464 in perform-pre-optimization! in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_6546(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6546,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[2],C_fix(3));
t3=C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6555,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t5=C_slot(t3,C_fix(1));
t6=C_eqp(lf[3],t5);
if(C_truep(t6)){
t7=C_slot(t3,C_fix(2));
t8=C_i_car(t7);
t9=t4;
f_6555(t9,C_eqp(((C_word*)t0)[9],t8));}
else{
t7=t4;
f_6555(t7,C_SCHEME_FALSE);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* a4818 in a4812 in a4806 in k4800 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4819(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4819,3,t0,t1,t2);}
/* optimizer.scm:273: test */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4069(t3,t1,t2,lf[60]);}

/* k6538 in k6532 in k6512 in k6506 in k6503 in g976 in k6484 in k6464 in perform-pre-optimization! in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6540,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6546,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=C_i_length(t1);
t4=C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=C_slot(((C_word*)t0)[2],C_fix(1));
t6=t2;
f_6546(t6,C_eqp(lf[5],t5));}
else{
t5=t2;
f_6546(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_6546(t3,C_SCHEME_FALSE);}}

/* a4812 in a4806 in k4800 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4813,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4819,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:273: partition */
t3=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[3]);}

/* k6553 in k6544 in k6538 in k6532 in k6512 in k6506 in k6503 in g976 in k6484 in k6464 in perform-pre-optimization! in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_6555(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6555,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6562,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:589: node-parameters-set! */
t5=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[8],lf[123]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k4830 in a4824 in a4806 in k4800 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4832,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=C_i_cadr(((C_word*)t0)[2]);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4872,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4879,a[2]=((C_word*)t0)[8],a[3]=t6,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[10])){
/* optimizer.scm:279: test */
t8=((C_word*)((C_word*)t0)[11])[1];
f_4069(t8,t7,((C_word*)t0)[5],lf[64]);}
else{
t8=t7;
f_4879(2,t8,C_SCHEME_FALSE);}}

/* k9710 in a9703 in k9690 in k9661 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1307: append */
t2=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* loop in a9703 in k9690 in k9661 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_9718(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9718,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
if(C_truep(C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9738,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=C_i_car(t3);
t6=t4;
t7=t5;
if(C_truep(C_i_symbolp(t7))){
/* optimizer.scm:922: varnode */
t8=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7324,a[2]=t7,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(t7))){
t9=C_u_i_car(t7);
t10=t8;
f_7324(t10,C_eqp(lf[34],t9));}
else{
t9=t8;
f_7324(t9,C_SCHEME_FALSE);}}}}
else{
if(C_truep(C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=C_i_car(t2);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9765,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=t2;
t8=C_u_i_cdr(t7);
t9=C_i_cdr(t3);
/* optimizer.scm:1316: loop */
t17=t6;
t18=t8;
t19=t9;
t1=t17;
t2=t18;
t3=t19;
goto loop;}}}

/* k10488 in k10477 in rec in scan in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1436: rec */
t2=((C_word*)((C_word*)t0)[2])[1];
f_10076(t2,((C_word*)t0)[3],((C_word*)t0)[4],C_SCHEME_FALSE,C_SCHEME_FALSE,t1);}

/* k12897 in loop2 in k12839 in k13054 in k13060 in loop1 in a12726 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_12899(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12899,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_slot(t2,C_fix(3));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=C_i_cdr(((C_word*)t0)[4]);
t7=C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm:726: loop2 */
t8=((C_word*)((C_word*)t0)[5])[1];
f_12868(t8,((C_word*)t0)[6],t5,t6,t7);}
else{
if(C_truep(C_i_nullp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12942,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12952,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm:730: ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[6],t2,t3);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* k4850 in k4870 in k4830 in a4824 in a4806 in k4800 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4852,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
t3=((C_word*)t0)[2];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[14],lf[11],((C_word*)t0)[3],t2));}

/* k9414 in k9388 in k9385 in k9379 in k9373 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9416,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[4],t2));}

/* k4712 in map-loop397 in k4664 in k4647 in k4644 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4714,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4685(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4685(t6,((C_word*)t0)[5],t5);}}

/* k8091 in k8088 in k8056 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_8093(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8093,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t0)[2];
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8101,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8218,a[2]=t5,a[3]=t9,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_8218(t11,t7,t6);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8088 in k8056 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_8090(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8090,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8093,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_8093(t3,t1);}
else{
t3=C_eqp(*((C_word*)lf[146]+1),lf[147]);
t4=(C_truep(t3)?C_i_caddr(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t2;
f_8093(t5,t4);}
else{
t5=C_eqp(*((C_word*)lf[146]+1),lf[149]);
t6=t2;
f_8093(t6,(C_truep(t5)?C_i_cadddr(((C_word*)t0)[3]):C_SCHEME_FALSE));}}}

/* k4719 in k4647 in k4644 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4721,2,t0,t1);}
if(C_truep(t1)){
t2=C_u_i_car(((C_word*)t0)[2]);
t3=C_slot(t2,C_fix(2));
t4=C_i_car(t3);
t5=((C_word*)t0)[3];
f_4666(t5,C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[4],t4),((C_word*)t0)[5]));}
else{
t2=((C_word*)t0)[3];
f_4666(t2,((C_word*)t0)[5]);}}

/* k8082 in k8056 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_8084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8084,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[4],t2));}

/* k9129 in k9103 in k9094 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9131,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[4],t2));}

/* a4824 in a4806 in k4800 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4825(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4825,4,t0,t1,t2,t3);}
t4=f_4105(((C_word*)((C_word*)t0)[2])[1]);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4832,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm:275: debugging */
t6=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[18],lf[65],t2);}

/* k7357 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_7359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7359,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7362,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_length(((C_word*)t0)[4]);
t4=C_i_car(((C_word*)t0)[3]);
if(C_truep(C_i_nequalp(t3,t4))){
t5=C_i_car(((C_word*)t0)[4]);
t6=C_i_cadr(((C_word*)t0)[4]);
t7=C_slot(t5,C_fix(1));
t8=C_eqp(lf[3],t7);
if(C_truep(t8)){
t9=C_slot(t6,C_fix(1));
t10=C_eqp(lf[3],t9);
if(C_truep(t10)){
t11=C_slot(t5,C_fix(2));
t12=C_slot(t6,C_fix(2));
if(C_truep(C_i_equalp(t11,t12))){
t13=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t14=t13;
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7448,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t14,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:938: qnode */
t16=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t16+1)))(3,t16,t15,C_SCHEME_TRUE);}
else{
t13=t2;
f_7362(t13,C_SCHEME_FALSE);}}
else{
t11=t2;
f_7362(t11,C_SCHEME_FALSE);}}
else{
t9=t2;
f_7362(t9,C_SCHEME_FALSE);}}
else{
t5=t2;
f_7362(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6563 in k6560 in k6553 in k6544 in k6538 in k6532 in k6512 in k6506 in k6503 in g976 in k6484 in k6464 in perform-pre-optimization! in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6568,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(((C_word*)t0)[4]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6583,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=C_u_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm:593: reverse */
t7=*((C_word*)lf[107]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k6566 in k6563 in k6560 in k6553 in k6544 in k6538 in k6532 in k6512 in k6506 in k6503 in g976 in k6484 in k6464 in perform-pre-optimization! in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:594: touch */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_6455(((C_word*)((C_word*)t0)[3])[1]));}

/* loop2 in k12839 in k13054 in k13060 in loop1 in a12726 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_12868(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12868,NULL,5,t0,t1,t2,t3,t4);}
t5=t4;
t6=C_slot(t5,C_fix(1));
t7=t4;
t8=C_slot(t7,C_fix(2));
t9=t8;
t10=t4;
t11=C_slot(t10,C_fix(3));
t12=t11;
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12899,a[2]=t12,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=t4,tmp=(C_word)a,a+=9,tmp);
t14=C_eqp(t6,lf[6]);
if(C_truep(t14)){
t15=C_i_cdr(t9);
if(C_truep(C_i_nullp(t15))){
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13032,a[2]=t13,a[3]=t3,a[4]=t12,a[5]=t9,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t17=C_u_i_car(t9);
/* optimizer.scm:721: get */
t18=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t18+1)))(5,t18,t16,((C_word*)t0)[4],t17,lf[105]);}
else{
t16=t13;
f_12899(t16,C_SCHEME_FALSE);}}
else{
t15=t13;
f_12899(t15,C_SCHEME_FALSE);}}

/* k8056 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_8058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8058,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_length(((C_word*)t0)[2]);
if(C_truep(C_fixnum_lessp(t2,C_fix(2)))){
t3=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8084,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1033: qnode */
t6=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,C_SCHEME_TRUE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8090,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(*((C_word*)lf[145]+1))){
t4=C_eqp(*((C_word*)lf[146]+1),lf[150]);
t5=t3;
f_8090(t5,C_i_not(t4));}
else{
t4=t3;
f_8090(t4,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* walk in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_11343(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11343,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=C_slot(t4,C_fix(3));
t6=t5;
t7=t2;
t8=C_slot(t7,C_fix(2));
t9=t2;
t10=C_slot(t9,C_fix(1));
t11=C_eqp(t10,lf[6]);
if(C_truep(t11)){
t12=C_i_car(t8);
t13=t12;
t14=C_i_car(t6);
t15=t14;
t16=C_i_cadr(t6);
t17=t16;
t18=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_11389,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t13,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t1,a[8]=t17,a[9]=t15,a[10]=((C_word*)t0)[4],a[11]=((C_word*)t0)[5],a[12]=((C_word*)t0)[6],tmp=(C_word)a,a+=13,tmp);
t19=((C_word*)((C_word*)t0)[2])[1];
if(C_truep(t19)){
t20=t18;
f_11389(t20,C_SCHEME_FALSE);}
else{
t20=C_slot(t15,C_fix(1));
t21=t18;
f_11389(t21,C_eqp(lf[15],t20));}}
else{
t12=C_eqp(t10,lf[11]);
t13=(C_truep(t12)?t12:C_eqp(t10,lf[69]));
if(C_truep(t13)){
t14=C_i_caddr(t8);
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11551,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:1629: decompose-lambda-list */
t16=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t1,t14,t15);}
else{
t14=f_11283(C_a_i(&a,6),((C_word*)((C_word*)t0)[5])[1]);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11583,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t16=C_i_check_list_2(t6,lf[2]);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11595,a[2]=t18,a[3]=t15,tmp=(C_word)a,a+=4,tmp));
t20=((C_word*)t18)[1];
f_11595(t20,t1,t6);}}}

/* k6560 in k6553 in k6544 in k6538 in k6532 in k6512 in k6506 in k6503 in g976 in k6484 in k6464 in perform-pre-optimization! in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6562,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6565,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_u_i_cdr(((C_word*)t0)[6]);
/* optimizer.scm:590: node-subexpressions-set! */
t4=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[7],t3);}

/* k7360 in k7357 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_7362(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7362,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep(*((C_word*)lf[143]+1))){
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=C_i_cadr(((C_word*)t0)[3]);
t4=C_a_i_list1(&a,1,t3);
t5=((C_word*)t0)[4];
t6=C_a_i_record4(&a,4,lf[14],lf[144],t4,t5);
t7=C_a_i_list2(&a,2,((C_word*)t0)[5],t6);
t8=((C_word*)t0)[2];
t9=t8;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_a_i_record4(&a,4,lf[14],lf[12],t2,t7));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* k6581 in k6563 in k6560 in k6553 in k6544 in k6538 in k6532 in k6512 in k6506 in k6503 in g976 in k6484 in k6464 in perform-pre-optimization! in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6583,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
/* optimizer.scm:591: node-subexpressions-set! */
t3=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[4],t2);}

/* map-loop1299 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_7226(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7226,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_cons(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=t9;
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7239,a[2]=((C_word*)t0)[2],a[3]=t10,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t12=t11;
f_7239(t12,C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t10));}
else{
t12=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t10);
t13=t11;
f_7239(t13,t12);}}
else{
t6=((C_word*)((C_word*)t0)[4])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_5309(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5309,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_5312,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t3=(C_truep(((C_word*)t0)[18])?lf[84]:lf[85]);
t4=C_i_cadddr(((C_word*)t0)[19]);
/* optimizer.scm:372: debugging */
t5=*((C_word*)lf[17]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t2,lf[80],t3,((C_word*)t0)[10],((C_word*)t0)[20],t4);}
else{
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5407,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[21],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[16],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[3],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[22],a[15]=((C_word*)t0)[23],a[16]=((C_word*)t0)[2],a[17]=((C_word*)t0)[10],a[18]=((C_word*)t0)[24],a[19]=((C_word*)t0)[25],a[20]=((C_word*)t0)[26],a[21]=((C_word*)t0)[14],a[22]=((C_word*)t0)[20],tmp=(C_word)a,a+=23,tmp);
/* optimizer.scm:395: test */
t3=((C_word*)((C_word*)t0)[24])[1];
f_4069(t3,t2,((C_word*)t0)[20],lf[68]);}}

/* k9182 in k9103 in k9094 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9184,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[4],t2));}

/* a9185 in k9103 in k9094 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9186(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9186,4,t0,t1,t2,t3);}
t4=C_a_i_list1(&a,1,((C_word*)t0)[2]);
t5=C_a_i_list2(&a,2,t2,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_record4(&a,4,lf[14],lf[144],t4,t5));}

/* k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word ab[446],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6779,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6782,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_a_i_list(&a,1,lf[209]);
t4=C_a_i_list(&a,1,lf[205]);
t5=C_a_i_list(&a,1,lf[210]);
t6=C_a_i_list(&a,2,lf[3],t5);
t7=C_a_i_list(&a,1,lf[211]);
t8=C_a_i_list(&a,2,lf[34],t7);
t9=C_a_i_list(&a,4,lf[144],t4,t6,t8);
t10=C_a_i_list(&a,1,lf[209]);
t11=C_a_i_list(&a,2,lf[3],t10);
t12=C_a_i_list(&a,1,lf[212]);
t13=C_a_i_list(&a,1,lf[205]);
t14=C_a_i_list(&a,1,lf[210]);
t15=C_a_i_list(&a,2,lf[3],t14);
t16=C_a_i_list(&a,1,lf[213]);
t17=C_a_i_list(&a,2,lf[34],t16);
t18=C_a_i_list(&a,4,lf[144],t13,t15,t17);
t19=C_a_i_list(&a,1,lf[212]);
t20=C_a_i_list(&a,2,lf[3],t19);
t21=C_a_i_list(&a,5,lf[5],lf[200],t20,lf[214],lf[215]);
t22=C_a_i_list(&a,4,lf[6],t12,t18,t21);
t23=C_a_i_list(&a,5,lf[5],lf[204],t11,lf[216],t22);
t24=C_a_i_list(&a,4,lf[6],t3,t9,t23);
t25=C_a_i_list(&a,11,lf[210],lf[209],lf[212],lf[205],lf[211],lf[213],lf[216],lf[214],lf[204],lf[200],lf[215]);
t26=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13216,tmp=(C_word)a,a+=2,tmp);
t27=C_a_i_list(&a,3,t24,t25,t26);
t28=C_a_i_list(&a,1,lf[199]);
t29=C_a_i_list(&a,1,lf[205]);
t30=C_a_i_list(&a,1,lf[210]);
t31=C_a_i_list(&a,2,lf[3],t30);
t32=C_a_i_list(&a,1,lf[220]);
t33=C_a_i_list(&a,2,lf[34],t32);
t34=C_a_i_list(&a,4,lf[144],t29,t31,t33);
t35=C_a_i_list(&a,1,lf[199]);
t36=C_a_i_list(&a,2,lf[3],t35);
t37=C_a_i_list(&a,1,lf[221]);
t38=C_a_i_list(&a,1,lf[210]);
t39=C_a_i_list(&a,2,lf[3],t38);
t40=C_a_i_cons(&a,2,t39,lf[222]);
t41=C_a_i_cons(&a,2,t37,t40);
t42=C_a_i_cons(&a,2,lf[22],t41);
t43=C_a_i_list(&a,5,lf[5],lf[223],t36,lf[224],t42);
t44=C_a_i_list(&a,4,lf[6],t28,t34,t43);
t45=C_a_i_list(&a,8,lf[199],lf[205],lf[210],lf[220],lf[223],lf[224],lf[221],lf[222]);
t46=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13086,tmp=(C_word)a,a+=2,tmp);
t47=C_a_i_list(&a,3,t44,t45,t46);
t48=C_a_i_list(&a,1,lf[209]);
t49=C_a_i_list(&a,2,lf[15],C_SCHEME_END_OF_LIST);
t50=C_a_i_list(&a,4,lf[6],t48,t49,lf[225]);
t51=C_a_i_list(&a,2,lf[209],lf[225]);
t52=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12727,tmp=(C_word)a,a+=2,tmp);
t53=C_a_i_list(&a,3,t50,t51,t52);
t54=C_a_i_list(&a,1,lf[199]);
t55=C_a_i_list(&a,1,lf[205]);
t56=C_a_i_cons(&a,2,t55,lf[226]);
t57=C_a_i_cons(&a,2,lf[144],t56);
t58=C_a_i_list(&a,1,lf[199]);
t59=C_a_i_list(&a,2,lf[3],t58);
t60=C_a_i_list(&a,5,lf[5],lf[223],t59,lf[191],lf[201]);
t61=C_a_i_list(&a,4,lf[6],t54,t57,t60);
t62=C_a_i_list(&a,6,lf[199],lf[205],lf[226],lf[223],lf[191],lf[201]);
t63=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12638,tmp=(C_word)a,a+=2,tmp);
t64=C_a_i_list(&a,3,t61,t62,t63);
t65=C_a_i_list(&a,4,t27,t47,t53,t64);
/* optimizer.scm:604: ##sys#hash-table-set! */
t66=*((C_word*)lf[129]+1);
((C_proc5)(void*)(*((C_word*)t66+1)))(5,t66,t2,*((C_word*)lf[30]+1),lf[6],t65);}

/* register-simplifications in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6772(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_6772r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6772r(t0,t1,t2,t3);}}

static void C_ccall f_6772r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
/* optimizer.scm:604: ##sys#hash-table-set! */
t4=*((C_word*)lf[129]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,*((C_word*)lf[30]+1),t2,t3);}

/* k3914 in k3834 in scan in scan-toplevel-assignments in k3676 in k3673 in k3670 */
static void C_ccall f_3916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3919,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm:93: alist-ref */
t3=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[9])[1]);}

/* k3917 in k3914 in k3834 in scan in scan-toplevel-assignments in k3676 in k3673 in k3670 */
static void C_ccall f_3919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3919,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3922,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3937,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t5=C_i_memq(((C_word*)t0)[4],((C_word*)((C_word*)t0)[8])[1]);
t6=t4;
f_3937(t6,C_i_not(t5));}
else{
t5=t4;
f_3937(t5,C_SCHEME_FALSE);}}

/* k3938 in k3935 in k3917 in k3914 in k3834 in scan in scan-toplevel-assignments in k3676 in k3673 in k3670 */
static void C_ccall f_3940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3940,2,t0,t1);}
t2=C_a_i_record4(&a,4,lf[14],lf[15],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
/* optimizer.scm:100: copy-node! */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,((C_word*)t0)[3]);}

/* map-loop2701 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_12332(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12332,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12361,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:1655: g2707 */
t5=((C_word*)t0)[5];
f_11644(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3935 in k3917 in k3914 in k3834 in scan in scan-toplevel-assignments in k3676 in k3673 in k3670 */
static void C_fcall f_3937(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3937,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3940,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:99: debugging */
t3=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[18],lf[19],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[2];
f_3922(2,t2,C_SCHEME_UNDEFINED);}}

/* k7863 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_7865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7865,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
t4=C_u_i_car(t3);
t5=C_a_i_list1(&a,1,t4);
t6=C_i_cadr(((C_word*)t0)[2]);
t7=C_a_i_list1(&a,1,t6);
t8=((C_word*)t0)[3];
t9=C_a_i_record4(&a,4,lf[14],lf[144],t7,t8);
t10=C_a_i_list1(&a,1,t9);
t11=C_a_i_record4(&a,4,lf[14],lf[144],t5,t10);
t12=C_a_i_list2(&a,2,((C_word*)t0)[4],t11);
t13=((C_word*)t0)[5];
t14=t13;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_a_i_record4(&a,4,lf[14],lf[12],t2,t12));}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k12004 in k12072 in k12175 in k12179 in k11933 in descend in k11774 in k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in ... */
static void C_ccall f_12006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12006,2,t0,t1);}
t2=C_a_i_record4(&a,4,lf[14],lf[12],lf[189],t1);
t3=C_a_i_list2(&a,2,((C_word*)t0)[2],t2);
t4=C_a_i_record4(&a,4,lf[14],lf[6],((C_word*)t0)[3],t3);
t5=C_a_i_list2(&a,2,((C_word*)t0)[4],t4);
t6=C_a_i_record4(&a,4,lf[14],lf[6],((C_word*)t0)[5],t5);
/* optimizer.scm:1693: copy-node! */
t7=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[6],t6,((C_word*)t0)[7]);}

/* k7291 in k7281 in rewrite in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_7293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:917: ##sys#hash-table-set! */
t2=*((C_word*)lf[129]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],*((C_word*)lf[140]+1),((C_word*)t0)[3],t1);}

/* ##compiler#simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_7299(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_7299,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
switch(t6){
case C_fix(1):
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7359,a[2]=t1,a[3]=t7,a[4]=t8,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t10=t4;
/* tweaks.scm:51: ##sys#get */
t11=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,lf[46]);
case C_fix(2):
if(C_truep(*((C_word*)lf[143]+1))){
t9=C_i_length(t8);
t10=C_i_car(t7);
if(C_truep(C_i_nequalp(t9,t10))){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7518,a[2]=t7,a[3]=t8,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t12=t4;
/* tweaks.scm:51: ##sys#get */
t13=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t11,t12,lf[46]);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(3):
if(C_truep(*((C_word*)lf[143]+1))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7590,a[2]=t7,a[3]=t5,a[4]=t1,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t10=t4;
/* tweaks.scm:51: ##sys#get */
t11=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,lf[46]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(4):
if(C_truep(*((C_word*)lf[143]+1))){
if(C_truep(*((C_word*)lf[145]+1))){
t9=C_i_length(t8);
t10=C_eqp(C_fix(2),t9);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7691,a[2]=t7,a[3]=t8,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t12=t4;
/* tweaks.scm:51: ##sys#get */
t13=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t11,t12,lf[46]);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(5):
if(C_truep(*((C_word*)lf[143]+1))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7758,a[2]=t8,a[3]=t7,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t10=t4;
/* tweaks.scm:51: ##sys#get */
t11=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,lf[46]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(6):
t9=C_i_caddr(t7);
t10=(C_truep(t9)?t9:*((C_word*)lf[145]+1));
if(C_truep(t10)){
if(C_truep(*((C_word*)lf[143]+1))){
t11=C_i_length(t8);
t12=C_eqp(C_fix(1),t11);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7865,a[2]=t7,a[3]=t8,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t14=t4;
/* tweaks.scm:51: ##sys#get */
t15=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,t14,lf[46]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}
case C_fix(7):
t9=C_i_cadddr(t7);
t10=(C_truep(t9)?t9:*((C_word*)lf[145]+1));
if(C_truep(t10)){
if(C_truep(*((C_word*)lf[143]+1))){
t11=C_i_length(t8);
t12=t7;
t13=C_u_i_car(t12);
if(C_truep(C_i_nequalp(t11,t13))){
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7957,a[2]=t7,a[3]=t5,a[4]=t1,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t15=t4;
/* tweaks.scm:51: ##sys#get */
t16=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t14,t15,lf[46]);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}
case C_fix(8):
if(C_truep(*((C_word*)lf[143]+1))){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8032,a[2]=t7,a[3]=t1,a[4]=t2,a[5]=t5,a[6]=t8,tmp=(C_word)a,a+=7,tmp);
t10=t4;
/* tweaks.scm:51: ##sys#get */
t11=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,lf[46]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(9):
if(C_truep(*((C_word*)lf[143]+1))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8058,a[2]=t8,a[3]=t5,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t10=t4;
/* tweaks.scm:51: ##sys#get */
t11=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,lf[46]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(10):
if(C_truep(*((C_word*)lf[143]+1))){
t9=C_i_cadddr(t7);
t10=(C_truep(t9)?t9:*((C_word*)lf[145]+1));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8313,a[2]=t8,a[3]=t7,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t12=t4;
/* tweaks.scm:51: ##sys#get */
t13=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t11,t12,lf[46]);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(11):
if(C_truep(*((C_word*)lf[143]+1))){
t9=C_i_caddr(t7);
t10=(C_truep(t9)?t9:*((C_word*)lf[145]+1));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8406,a[2]=t7,a[3]=t1,a[4]=t5,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t12=t4;
/* tweaks.scm:51: ##sys#get */
t13=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t11,t12,lf[46]);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(12):
if(C_truep(*((C_word*)lf[143]+1))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8472,a[2]=t7,a[3]=t8,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t10=t4;
/* tweaks.scm:51: ##sys#get */
t11=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,lf[46]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(13):
if(C_truep(*((C_word*)lf[143]+1))){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8562,a[2]=t7,a[3]=t1,a[4]=t5,a[5]=t8,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t10=t4;
/* tweaks.scm:51: ##sys#get */
t11=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,lf[46]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(14):
if(C_truep(*((C_word*)lf[143]+1))){
t9=C_i_cadr(t7);
t10=C_i_length(t8);
if(C_truep(C_i_nequalp(t9,t10))){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8635,a[2]=t7,a[3]=t8,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t12=t4;
/* tweaks.scm:51: ##sys#get */
t13=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t11,t12,lf[46]);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(15):
if(C_truep(*((C_word*)lf[143]+1))){
t9=C_i_length(t8);
t10=C_eqp(C_fix(1),t9);
if(C_truep(t10)){
t11=*((C_word*)lf[145]+1);
t12=(C_truep(*((C_word*)lf[145]+1))?*((C_word*)lf[145]+1):C_i_cadddr(t7));
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8732,a[2]=t7,a[3]=t1,a[4]=t5,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t14=t4;
/* tweaks.scm:51: ##sys#get */
t15=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,t14,lf[46]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(16):
t9=C_i_car(t7);
t10=t9;
t11=C_i_length(t8);
t12=t11;
t13=C_i_caddr(t7);
t14=t13;
t15=C_i_cadddr(t7);
t16=t15;
t17=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8825,a[2]=t10,a[3]=t12,a[4]=t14,a[5]=t8,a[6]=t5,a[7]=t1,a[8]=t16,a[9]=t7,a[10]=t4,tmp=(C_word)a,a+=11,tmp);
t18=C_i_cddddr(t7);
if(C_truep(C_i_pairp(t18))){
/* optimizer.scm:1150: fifth */
t19=*((C_word*)lf[154]+1);
((C_proc3)(void*)(*((C_word*)t19+1)))(3,t19,t17,t7);}
else{
t19=t17;
f_8825(2,t19,C_SCHEME_FALSE);}
case C_fix(17):
if(C_truep(*((C_word*)lf[143]+1))){
t9=C_i_length(t8);
t10=C_i_car(t7);
if(C_truep(C_i_nequalp(t9,t10))){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8969,a[2]=t8,a[3]=t5,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t12=t4;
/* tweaks.scm:51: ##sys#get */
t13=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t11,t12,lf[46]);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(18):
if(C_truep(*((C_word*)lf[143]+1))){
if(C_truep(C_i_nullp(t8))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9052,a[2]=t5,a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t10=t4;
/* tweaks.scm:51: ##sys#get */
t11=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,lf[46]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(19):
if(C_truep(*((C_word*)lf[143]+1))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9096,a[2]=t7,a[3]=t5,a[4]=t1,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t10=t4;
/* tweaks.scm:51: ##sys#get */
t11=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,lf[46]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(20):
t9=C_i_length(t8);
t10=t9;
t11=C_i_cadddr(t7);
t12=(C_truep(t11)?t11:*((C_word*)lf[145]+1));
if(C_truep(t12)){
if(C_truep(*((C_word*)lf[143]+1))){
t13=t7;
t14=C_u_i_car(t13);
if(C_truep(C_i_nequalp(t10,t14))){
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9288,a[2]=t7,a[3]=t5,a[4]=t1,a[5]=t10,a[6]=t8,tmp=(C_word)a,a+=7,tmp);
t16=t4;
/* tweaks.scm:51: ##sys#get */
t17=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t17+1)))(4,t17,t15,t16,lf[46]);}
else{
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_SCHEME_FALSE);}}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}
case C_fix(21):
if(C_truep(*((C_word*)lf[143]+1))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9375,a[2]=t7,a[3]=t5,a[4]=t1,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t10=t4;
/* tweaks.scm:51: ##sys#get */
t11=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,lf[46]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(22):
t9=C_i_car(t7);
t10=C_i_length(t8);
t11=C_i_cadddr(t7);
t12=t11;
if(C_truep(*((C_word*)lf[143]+1))){
if(C_truep(C_i_nequalp(t10,t9))){
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9579,a[2]=t7,a[3]=t8,a[4]=t5,a[5]=t1,a[6]=t12,tmp=(C_word)a,a+=7,tmp);
t14=t4;
/* tweaks.scm:51: ##sys#get */
t15=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,t14,lf[46]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}
case C_fix(23):
if(C_truep(*((C_word*)lf[143]+1))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9663,a[2]=t7,a[3]=t8,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t10=t4;
/* tweaks.scm:51: ##sys#get */
t11=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,lf[46]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
default:
/* optimizer.scm:1318: bomb */
t9=*((C_word*)lf[156]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t1,lf[157]);}}

/* k12008 in k12072 in k12175 in k12179 in k11933 in descend in k11774 in k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in ... */
static void C_ccall f_12010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12010,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12014,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12018,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12028,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm:1735: list-tabulate */
t6=*((C_word*)lf[188]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[3],t5);}

/* k12012 in k12008 in k12072 in k12175 in k12179 in k11933 in descend in k11774 in k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in ... */
static void C_ccall f_12014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1733: cons* */
t2=*((C_word*)lf[151]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k12016 in k12008 in k12072 in k12175 in k12179 in k11933 in descend in k11774 in k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in ... */
static void C_ccall f_12018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12018,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12026,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1736: qnode */
t4=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_fix(0));}

/* k11418 in k11401 in k11387 in walk in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_11420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11420,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
/* optimizer.scm:1627: walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_11343(t3,((C_word*)t0)[5],((C_word*)t0)[6],t2);}

/* k9103 in k9094 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9105,2,t0,t1);}
if(C_truep(C_i_nullp(t1))){
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9131,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1205: qnode */
t5=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=C_i_cdr(t1);
if(C_truep(C_i_nullp(t2))){
t3=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t4=C_u_i_car(t1);
t5=C_a_i_list2(&a,2,((C_word*)t0)[2],t4);
t6=((C_word*)t0)[3];
t7=t6;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_record4(&a,4,lf[14],lf[12],t3,t5));}
else{
t3=C_i_cadddr(((C_word*)t0)[5]);
t4=(C_truep(t3)?t3:C_eqp(*((C_word*)lf[146]+1),lf[147]));
if(C_truep(t4)){
t5=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9184,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9186,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:1213: fold-inner */
t9=*((C_word*)lf[155]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,t1);}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}}}

/* k3923 in k3920 in k3917 in k3914 in k3834 in scan in scan-toplevel-assignments in k3676 in k3673 in k3670 */
static void C_ccall f_3925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:104: remember */
t2=((C_word*)((C_word*)t0)[2])[1];
f_3706(t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k3920 in k3917 in k3914 in k3834 in scan in scan-toplevel-assignments in k3676 in k3673 in k3670 */
static void C_ccall f_3922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3925,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_memq(((C_word*)t0)[4],((C_word*)t0)[6]))){
/* optimizer.scm:104: remember */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3706(t3,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);}
else{
/* optimizer.scm:103: mark */
t3=((C_word*)((C_word*)t0)[7])[1];
f_3683(t3,t2,((C_word*)t0)[4]);}}

/* k13261 in k13278 in k13287 in k13233 in k13227 in a13215 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_13263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13263,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13267,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:653: qnode */
t4=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}

/* k9988 in walk in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9990,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_9878(2,t2,C_SCHEME_FALSE);}
else{
if(C_truep(C_i_listp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9908,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm:1346: get */
t3=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[9],((C_word*)t0)[6],lf[49]);}
else{
t2=((C_word*)t0)[2];
f_9878(2,t2,C_SCHEME_FALSE);}}}

/* k13265 in k13261 in k13278 in k13287 in k13233 in k13227 in a13215 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_13267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13267,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13271,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:655: qnode */
t4=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}

/* k4877 in k4830 in a4824 in a4806 in k4800 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4879,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4882,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:280: debugging */
t3=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[18],lf[63],((C_word*)t0)[5]);}
else{
/* optimizer.scm:283: build-lambda-list */
t2=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[5]);}}

/* k4870 in k4830 in a4824 in a4806 in k4800 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4872,2,t0,t1);}
t2=C_i_cadddr(((C_word*)t0)[2]);
t3=C_a_i_list4(&a,4,((C_word*)t0)[3],((C_word*)t0)[4],t1,t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4852,a[2]=((C_word*)t0)[5],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_i_car(((C_word*)t0)[6]);
t7=C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[8]);
/* optimizer.scm:285: walk */
t8=((C_word*)((C_word*)t0)[9])[1];
f_4278(t8,t5,t6,t7,C_SCHEME_END_OF_LIST);}

/* a10296 in k10290 in k10284 in rec in scan in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10297(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10297,3,t0,t1,t2);}
/* optimizer.scm:1412: rec */
t3=((C_word*)((C_word*)t0)[2])[1];
f_10076(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* ##compiler#reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6787(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6787,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=t2;
t12=t3;
t13=C_i_check_list_2(t11,lf[35]);
t14=C_i_check_list_2(t12,lf[35]);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6797,a[2]=t6,a[3]=t2,a[4]=t3,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7226,a[2]=t10,a[3]=t17,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t19=((C_word*)t17)[1];
f_7226(t19,t15,t11,t12);}

/* k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6785,2,t0,t1);}
t2=C_mutate2((C_word*)lf[130]+1 /* (set! ##compiler#reorganize-recursive-bindings ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6787,tmp=(C_word)a,a+=2,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7277,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:913: make-vector */
t4=*((C_word*)lf[198]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k10290 in k10284 in rec in scan in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_10292(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10292,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10297,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1412: every */
t3=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[166],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6782,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6785,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_a_i_list(&a,1,lf[199]);
t4=C_a_i_list(&a,2,lf[3],t3);
t5=C_a_i_list(&a,4,lf[12],lf[200],t4,lf[201]);
t6=C_a_i_list(&a,1,lf[199]);
t7=C_a_i_list(&a,2,lf[3],t6);
t8=C_a_i_list(&a,4,lf[12],lf[202],t7,lf[203]);
t9=C_a_i_list(&a,5,lf[5],lf[204],lf[191],t5,t8);
t10=C_a_i_list(&a,7,lf[204],lf[200],lf[202],lf[191],lf[201],lf[203],lf[199]);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12555,tmp=(C_word)a,a+=2,tmp);
t12=C_a_i_list(&a,3,t9,t10,t11);
t13=C_a_i_list(&a,1,lf[205]);
t14=C_a_i_list(&a,1,lf[206]);
t15=C_a_i_list(&a,2,lf[34],t14);
t16=C_a_i_list(&a,4,lf[144],t13,lf[191],t15);
t17=C_a_i_list(&a,5,lf[5],lf[204],t16,lf[201],lf[203]);
t18=C_a_i_list(&a,6,lf[204],lf[205],lf[191],lf[206],lf[201],lf[203]);
t19=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12419,tmp=(C_word)a,a+=2,tmp);
t20=C_a_i_list(&a,3,t17,t18,t19);
t21=C_a_i_list(&a,2,t12,t20);
/* optimizer.scm:604: ##sys#hash-table-set! */
t22=*((C_word*)lf[129]+1);
((C_proc5)(void*)(*((C_word*)t22+1)))(5,t22,t2,*((C_word*)lf[30]+1),lf[5],t21);}

/* k13269 in k13265 in k13261 in k13278 in k13287 in k13233 in k13227 in a13215 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_13271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13271,2,t0,t1);}
t2=C_a_i_list6(&a,6,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1,((C_word*)t0)[5],((C_word*)t0)[6]);
t3=((C_word*)t0)[7];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[14],lf[22],lf[218],t2));}

/* k4880 in k4877 in k4830 in a4824 in a4806 in k4800 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4882,2,t0,t1);}
t2=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
/* optimizer.scm:282: build-lambda-list */
t3=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[4],t2,C_SCHEME_FALSE);}

/* find-path in k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_6799(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6799,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6805,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_6805(t7,t1,t2,C_SCHEME_END_OF_LIST);}

/* k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6797,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6799,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6842,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[4];
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6854,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7189,a[2]=t9,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t11=((C_word*)t9)[1];
f_7189(t11,t7,t5,t6);}

/* k9971 in k9918 in k9912 in k9906 in k9988 in walk in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9973,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_9878(2,t2,C_SCHEME_FALSE);}
else{
t2=C_i_length(((C_word*)t0)[3]);
t3=C_i_length(((C_word*)t0)[4]);
t4=C_eqp(t2,t3);
if(C_truep(t4)){
t5=C_i_car(((C_word*)t0)[5]);
t6=C_i_car(((C_word*)t0)[6]);
t7=C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
/* optimizer.scm:1355: scan */
t8=((C_word*)((C_word*)t0)[8])[1];
f_10073(t8,((C_word*)t0)[2],t5,t6,((C_word*)t0)[7],((C_word*)t0)[9],t7);}
else{
t5=((C_word*)t0)[2];
f_9878(2,t5,C_SCHEME_FALSE);}}}

/* a12027 in k12008 in k12072 in k12175 in k12179 in k11933 in descend in k11774 in k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in ... */
static void C_ccall f_12028(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12028,2,t0,t1);}
/* optimizer.scm:1735: qnode */
t2=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_FALSE);}

/* k12024 in k12016 in k12008 in k12072 in k12175 in k12179 in k11933 in descend in k11774 in k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in ... */
static void C_ccall f_12026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12026,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
/* optimizer.scm:1734: append */
t3=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],((C_word*)t0)[3],t2);}

/* k8677 in k8633 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_8679(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8679,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_a_i_record4(&a,4,lf[14],lf[144],t1,t2);
t4=C_a_i_list2(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[4];
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[5],t4));}

/* k7237 in map-loop1299 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_7239(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[6])[1];
f_7226(t5,((C_word*)t0)[7],t3,t4);}

/* k12293 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_12295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[194]+1),t1);}

/* map-loop2785 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_12297(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_12297,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_caddr(t3);
t5=C_i_length(t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t7=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t6);
t8=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t6);
t9=C_slot(t2,C_fix(1));
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t6);
t8=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t6);
t9=C_slot(t2,C_fix(1));
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9690 in k9661 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9692,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9696,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9698,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9704,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:1306: ##sys#call-with-values */
C_call_with_values(4,0,t3,t4,t5);}

/* k9694 in k9690 in k9661 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1303: cons* */
t2=*((C_word*)lf[151]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k9686 in k9661 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9688,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[3],t1));}

/* for-each-loop975 in k6736 in k6484 in k6464 in perform-pre-optimization! in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_6749(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6749,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6759,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:560: g976 */
t5=((C_word*)t0)[3];
f_6487(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* a9697 in k9690 in k9661 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9698,2,t0,t1);}
/* optimizer.scm:1306: split-at */
t2=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* a12274 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_12275(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12275,2,t0,t1);}
/* optimizer.scm:1677: gensym */
t2=*((C_word*)lf[87]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,lf[193]);}

/* k6757 in for-each-loop975 in k6736 in k6484 in k6464 in perform-pre-optimization! in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6749(t3,((C_word*)t0)[4],t2);}

/* k13287 in k13233 in k13227 in a13215 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_13289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13289,2,t0,t1);}
t2=C_i_length(t1);
t3=C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13280,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm:648: get-list */
t5=*((C_word*)lf[124]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[9],((C_word*)t0)[10],lf[78]);}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k12267 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_12269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12269,2,t0,t1);}
t2=C_a_i_list1(&a,1,((C_word*)t0)[2]);
/* optimizer.scm:1676: append */
t3=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t1,t2);}

/* k13278 in k13287 in k13233 in k13227 in a13215 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_13280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13280,2,t0,t1);}
t2=C_i_length(t1);
t3=C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13263,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:652: varnode */
t5=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[8]);}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* a12726 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_12727(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12727,5,t0,t1,t2,t3,t4);}
t5=C_a_i_list1(&a,1,t3);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12737,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_12737(t9,t1,t5,t4);}

/* k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_7277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7277,2,t0,t1);}
t2=C_mutate2((C_word*)lf[140]+1 /* (set! ##compiler#substitution-table ...) */,t1);
t3=C_mutate2((C_word*)lf[141]+1 /* (set! ##compiler#rewrite ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7279,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate2((C_word*)lf[142]+1 /* (set! ##compiler#simplify-named-call ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7299,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate2((C_word*)lf[158]+1 /* (set! ##compiler#transform-direct-lambdas! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9835,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate2((C_word*)lf[186]+1 /* (set! ##compiler#determine-loop-and-dispatch ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11280,tmp=(C_word)a,a+=2,tmp));
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}

/* ##compiler#rewrite in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_7279(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_7279r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7279r(t0,t1,t2,t3);}}

static void C_ccall f_7279r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7283,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:916: ##sys#hash-table-ref */
t5=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[140]+1),t2);}

/* k7281 in rewrite in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_7283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7283,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7293,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_list1(&a,1,((C_word*)t0)[4]);
/* optimizer.scm:917: append */
t5=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,t4);}

/* g2375 in rec in k10584 in k10578 in k10575 in k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_10979(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10979,NULL,3,t0,t1,t2);}
t3=C_i_cdr(t2);
t4=t3;
t5=C_slot(t4,C_fix(3));
t6=C_i_car(t5);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10989,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t7,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t4,tmp=(C_word)a,a+=9,tmp);
t9=C_i_cdr(((C_word*)t0)[4]);
t10=C_i_length(t9);
t11=C_eqp(((C_word*)t0)[6],t10);
if(C_truep(t11)){
t12=t8;
f_10989(2,t12,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm:1489: quit */
t12=*((C_word*)lf[167]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t8,lf[174],((C_word*)t0)[7]);}}

/* k9661 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9663,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=C_i_length(((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
t6=C_u_i_car(t5);
if(C_truep(C_i_greater_or_equalp(t4,t6))){
t7=C_i_cadr(((C_word*)t0)[2]);
t8=C_a_i_list2(&a,2,C_SCHEME_TRUE,t7);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9688,a[2]=((C_word*)t0)[4],a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9692,a[2]=t10,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t12=((C_word*)t0)[2];
t13=C_u_i_cdr(t12);
t14=C_u_i_car(t13);
/* optimizer.scm:1304: varnode */
t15=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t11,t14);}
else{
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k10987 in g2375 in rec in k10584 in k10578 in k10575 in k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10992,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm:1492: node-class-set! */
t3=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[7],lf[6]);}

/* a7038 in k7008 in a6996 in k6975 in k6972 in k6912 in k6852 in k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_7039(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7039,4,t0,t1,t2,t3);}
t4=C_a_i_list1(&a,1,t2);
t5=C_a_i_record4(&a,4,lf[14],lf[15],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t6=C_a_i_list2(&a,2,t5,t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_record4(&a,4,lf[14],lf[6],t4,t6));}

/* k8030 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_8032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
/* optimizer.scm:1023: g1666 */
t3=t2;
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[6]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k10990 in k10987 in g2375 in rec in k10584 in k10578 in k10575 in k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10992,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10995,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11026,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t4=C_slot(((C_word*)t0)[8],C_fix(2));
t5=C_i_caddr(t4);
/* optimizer.scm:1493: take */
t6=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t5,C_fix(1));}

/* k10996 in k10993 in k10990 in k10987 in g2375 in rec in k10584 in k10578 in k10575 in k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 in ... */
static void C_ccall f_10998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1497: rec */
t2=((C_word*)((C_word*)t0)[2])[1];
f_10864(3,t2,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k10993 in k10990 in k10987 in g2375 in rec in k10584 in k10578 in k10575 in k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10998,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_a_i_list2(&a,2,C_SCHEME_FALSE,((C_word*)t0)[5]);
t4=C_i_cddr(((C_word*)t0)[6]);
t5=C_a_i_record4(&a,4,lf[14],lf[171],t3,t4);
t6=C_a_i_list2(&a,2,t5,((C_word*)t0)[4]);
/* optimizer.scm:1494: node-subexpressions-set! */
t7=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t2,((C_word*)t0)[7],t6);}

/* k6309 in k6302 in lp in walk-generic in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_6311(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6311,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
/* optimizer.scm:515: lp */
t5=((C_word*)((C_word*)t0)[5])[1];
f_6273(t5,((C_word*)t0)[6],t1,t3,t4);}

/* k4664 in k4647 in k4644 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_4666(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4666,NULL,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4676,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4683,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4685,a[2]=t6,a[3]=t10,a[4]=t4,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_4685(t12,t8,((C_word*)t0)[6]);}

/* k6302 in lp in walk-generic in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6304,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6311,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[6])){
t4=((C_word*)t0)[2];
t5=C_u_i_car(t4);
t6=t3;
f_6311(t6,C_eqp(t2,t5));}
else{
t4=t3;
f_6311(t4,C_SCHEME_FALSE);}}

/* k9343 in a9332 in k9286 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9345,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
/* optimizer.scm:1232: append */
t3=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],((C_word*)t0)[3],t2,((C_word*)t0)[4]);}

/* loop1 in a12726 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_12737(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12737,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=C_slot(t4,C_fix(1));
t6=t3;
t7=C_slot(t6,C_fix(2));
t8=t7;
t9=t3;
t10=C_slot(t9,C_fix(3));
t11=t10;
t12=C_eqp(t5,lf[6]);
if(C_truep(t12)){
t13=C_i_cdr(t8);
if(C_truep(C_i_nullp(t13))){
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13062,a[2]=t1,a[3]=t11,a[4]=t8,a[5]=t2,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t15=C_u_i_car(t8);
/* optimizer.scm:702: get */
t16=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t16+1)))(5,t16,t14,((C_word*)t0)[3],t15,lf[105]);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}

/* k10940 in rec in k10584 in k10578 in k10575 in k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10945,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:1481: node-class-set! */
t3=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],lf[171]);}

/* k10943 in k10940 in rec in k10584 in k10578 in k10575 in k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10948,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_a_i_list2(&a,2,C_SCHEME_TRUE,((C_word*)t0)[5]);
/* optimizer.scm:1482: node-parameters-set! */
t4=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[4],t3);}

/* k6512 in k6506 in k6503 in g976 in k6484 in k6464 in perform-pre-optimization! in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_6514(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6514,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[2],C_fix(2));
t3=C_i_caddr(t2);
t4=t3;
t5=C_slot(((C_word*)t0)[2],C_fix(3));
t6=C_i_car(t5);
t7=t6;
t8=C_slot(t7,C_fix(3));
t9=t8;
t10=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6534,a[2]=t4,a[3]=t7,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t9,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
if(C_truep(C_i_listp(t4))){
t11=C_i_cdr(t4);
t12=t10;
f_6534(t12,C_i_nullp(t11));}
else{
t11=t10;
f_6534(t11,C_SCHEME_FALSE);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k10946 in k10943 in k10940 in rec in k10584 in k10578 in k10575 in k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cddr(((C_word*)t0)[2]);
/* optimizer.scm:1483: node-subexpressions-set! */
t3=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[4],t2);}

/* a7070 in k7008 in a6996 in k6975 in k6972 in k6912 in k6852 in k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_7071(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7071,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7117,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:897: gensym */
t5=*((C_word*)lf[87]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k6503 in g976 in k6484 in k6464 in perform-pre-optimization! in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6505,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6508,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm:566: get-list */
t4=*((C_word*)lf[124]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[7],((C_word*)t0)[8],lf[78]);}

/* k6506 in k6503 in g976 in k6484 in k6464 in perform-pre-optimization! in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6514,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[2])){
if(C_truep(t1)){
t3=C_i_length(t1);
t4=C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=C_i_length(((C_word*)t0)[6]);
t6=C_eqp(C_fix(3),t5);
if(C_truep(t6)){
t7=C_slot(((C_word*)t0)[2],C_fix(1));
t8=t2;
f_6514(t8,C_eqp(lf[11],t7));}
else{
t7=t2;
f_6514(t7,C_SCHEME_FALSE);}}
else{
t5=t2;
f_6514(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_6514(t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_6514(t3,C_SCHEME_FALSE);}}

/* k5549 in k5511 in k5505 in k5499 in loop in k5405 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5551,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5533,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t5=((C_word*)t0)[5];
t6=C_u_i_car(t5);
/* optimizer.scm:417: walk */
t7=((C_word*)((C_word*)t0)[8])[1];
f_4278(t7,t4,t6,((C_word*)t0)[9],((C_word*)t0)[10]);}

/* k4036 in for-each-loop110 in k3999 in k3996 in k3993 in scan-toplevel-assignments in k3676 in k3673 in k3670 */
static void C_ccall f_4038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4028(t3,((C_word*)t0)[4],t2);}

/* k6532 in k6512 in k6506 in k6503 in g976 in k6484 in k6464 in perform-pre-optimization! in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_6534(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6534,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6540,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t3,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm:577: get-list */
t5=*((C_word*)lf[124]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[10],t3,lf[78]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k4426 in k4290 in walk in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4428,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4434,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:190: foldable? */
t3=*((C_word*)lf[44]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[3];
f_4370(2,t2,C_SCHEME_FALSE);}}

/* k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_11770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11770,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11773,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12269,a[2]=((C_word*)t0)[7],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12275,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm:1677: list-tabulate */
t6=*((C_word*)lf[188]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t2,t5);}

/* k4432 in k4426 in k4290 in walk in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_i_cddr(((C_word*)t0)[2]);
/* optimizer.scm:191: every */
t3=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1],t2);}
else{
t2=((C_word*)t0)[3];
f_4370(2,t2,C_SCHEME_FALSE);}}

/* k11603 in for-each-loop2656 in walk in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_11605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11595(t3,((C_word*)t0)[4],t2);}

/* g2910 in k11777 in k11774 in k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_11780(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11780,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11784,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_i_car(t2);
/* optimizer.scm:1742: get */
t5=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,((C_word*)t0)[4],t4,lf[126]);}

/* k4613 in g354 in k4529 in k4523 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_eqp(lf[53],t1);
t3=((C_word*)t0)[2];
f_4590(t3,C_i_not(t2));}

/* k11777 in k11774 in k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_11779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11779,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11780,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11902,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_11902(t6,((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k11774 in k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_11776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11776,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11779,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11925,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_11925(t6,t2,((C_word*)t0)[10]);}

/* k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_11773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11773,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11776,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12230,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12232,a[2]=t7,a[3]=t10,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_12232(t12,t8,((C_word*)t0)[6]);}

/* k8348 in k8340 in k8320 in k8311 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_8350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8350,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8354,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=((C_word*)t0)[7];
t5=C_u_i_cdr(t4);
if(C_truep(C_i_nullp(t5))){
t6=C_i_caddr(((C_word*)t0)[8]);
/* optimizer.scm:1067: varnode */
t7=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t3,t6);}
else{
t6=t3;
f_8354(2,t6,C_i_cadr(((C_word*)t0)[7]));}}

/* k8352 in k8348 in k8340 in k8320 in k8311 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_8354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8354,2,t0,t1);}
t2=C_a_i_list5(&a,5,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t1);
t3=((C_word*)t0)[6];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[7],t2));}

/* k7815 in k7756 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_7817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7817,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_record4(&a,4,lf[14],lf[144],((C_word*)t0)[3],t2);
t4=C_a_i_list2(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[5];
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[6],t4));}

/* g2924 in k11782 in g2910 in k11777 in k11774 in k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in ... */
static void C_fcall f_11785(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11785,NULL,3,t0,t1,t2);}
t3=C_i_cdr(t2);
t4=t3;
t5=C_slot(t4,C_fix(3));
t6=C_i_cdr(t5);
t7=t6;
t8=C_slot(t4,C_fix(2));
t9=t8;
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11817,a[2]=t9,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11821,a[2]=t10,a[3]=t7,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:1750: varnode */
t12=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,((C_word*)t0)[4]);}

/* k11782 in g2910 in k11777 in k11774 in k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 in ... */
static void C_ccall f_11784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11784,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11785,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_check_list_2(t1,lf[2]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11872,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_11872(t7,((C_word*)t0)[5],t1);}

/* k8340 in k8320 in k8311 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_8342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8342,2,t0,t1);}
t2=t1;
t3=C_i_car(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8350,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t6=C_i_cadr(((C_word*)t0)[6]);
/* optimizer.scm:1065: qnode */
t7=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_11628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11628,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11631,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:1644: walk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_11343(t3,t2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}

/* k12080 in k12167 in k12175 in k12179 in k11933 in descend in k11774 in k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in ... */
static void C_ccall f_12082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=((C_word*)t0)[2];
t3=C_slot(t2,C_fix(3));
t4=C_i_cdr(t3);
/* optimizer.scm:1713: append */
t5=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[3],((C_word*)t0)[4],t1,t4);}

/* k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_11631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11632,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
t4=C_i_check_list_2(t3,lf[2]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12371,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12380,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_12380(t9,t5,t3);}

/* g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_11632(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11632,NULL,3,t0,t1,t2);}
t3=C_i_car(t2);
t4=t3;
t5=t2;
t6=C_u_i_cdr(t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11640,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:1651: gensym */
t8=*((C_word*)lf[87]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,lf[196]);}

/* k8530 in k8470 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_8532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1095: cons* */
t2=*((C_word*)lf[151]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* f_6174 in k6154 in k6196 in k6097 in k6080 in k6054 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6174(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6174,3,t0,t1,t2);}
t3=C_i_car(t2);
t4=C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
t5=t2;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_i_set_i_slot(t5,C_fix(1),C_SCHEME_FALSE));}
else{
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_11640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11640,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11643,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:1652: gensym */
t4=*((C_word*)lf[87]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[80]);}

/* k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_11643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11643,2,t0,t1);}
t2=t1;
t3=C_fix(1);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11644,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t10=C_i_check_list_2(((C_word*)t0)[2],lf[35]);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11764,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12332,a[2]=t8,a[3]=t13,a[4]=t6,a[5]=t9,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_12332(t15,t11,((C_word*)t0)[2]);}

/* g2707 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_11644(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11644,NULL,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(2));
t5=C_i_car(t4);
t6=t5;
t7=t2;
t8=C_slot(t7,C_fix(3));
t9=C_i_car(t8);
t10=t9;
t11=C_slot(t10,C_fix(2));
t12=C_i_caddr(t11);
t13=t12;
t14=C_SCHEME_END_OF_LIST;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_FALSE;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=*((C_word*)lf[87]+1);
t19=C_i_check_list_2(t13,lf[35]);
t20=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11668,a[2]=t10,a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=t13,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_set_block_item(t22,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11707,a[2]=t17,a[3]=t22,a[4]=t15,a[5]=t18,tmp=(C_word)a,a+=6,tmp));
t24=((C_word*)t22)[1];
f_11707(t24,t20,t13);}

/* k5644 in k5656 in k5695 in a5629 in k5617 in k5605 in k5602 in k5405 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 in ... */
static void C_ccall f_5646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* k5656 in k5695 in a5629 in k5617 in k5605 in k5602 in k5405 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5658,2,t0,t1);}
t2=C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[2],t1);
t3=t2;
t4=C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5646,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:447: invalidate-gae! */
f_4109(t6,((C_word*)t0)[6]);}

/* k6140 in for-each-loop880 in k6154 in k6196 in k6097 in k6080 in k6054 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6132(t3,((C_word*)t0)[4],t2);}

/* g746 in a5629 in k5617 in k5605 in k5602 in k5405 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_5648(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5648,NULL,3,t0,t1,t2);}
/* optimizer.scm:435: g763 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4278(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k6196 in k6097 in k6080 in k6054 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6198,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
t3=C_a_i_record4(&a,4,lf[14],lf[13],((C_word*)t0)[2],t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6156,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:493: test */
t6=((C_word*)((C_word*)t0)[6])[1];
f_4069(t6,t5,((C_word*)t0)[3],lf[56]);}

/* k9379 in k9373 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9381,2,t0,t1);}
t2=t1;
t3=C_i_cadddr(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9387,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(*((C_word*)lf[145]+1))){
t6=((C_word*)t0)[2];
t7=C_u_i_cdr(t6);
t8=C_u_i_cdr(t7);
t9=t5;
f_9387(t9,C_u_i_car(t8));}
else{
t6=((C_word*)t0)[2];
t7=C_u_i_cdr(t6);
t8=t5;
f_9387(t8,C_u_i_car(t7));}}

/* k9385 in k9379 in k9373 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_9387(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9387,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9390,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9507,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:1249: remove */
t5=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[7]);}

/* k8526 in k8470 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_8528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8528,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[3],t1));}

/* for-each-loop188 in invalidate-gae! in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static C_word C_fcall f_4123(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_overflow_check;
loop:
if(C_truep(C_i_pairp(t1))){
t2=C_slot(t1,C_fix(0));
t3=C_i_set_cdr(t2,C_SCHEME_FALSE);
t4=C_slot(t1,C_fix(1));
t7=t4;
t1=t7;
goto loop;}
else{
t2=C_SCHEME_UNDEFINED;
return(t2);}}

/* k9094 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9096,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=(C_truep(*((C_word*)lf[145]+1))?C_i_caddr(((C_word*)t0)[2]):C_i_cadr(((C_word*)t0)[2]));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9105,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9212,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:1200: remove */
t8=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a12096 in k12167 in k12175 in k12179 in k11933 in descend in k11774 in k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in ... */
static void C_ccall f_12097(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12097,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12105,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=C_i_cadr(t2);
/* optimizer.scm:1717: qnode */
t5=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k10243 in rec in scan in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10245,2,t0,t1);}
t2=C_i_zerop(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10251,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_10251(t4,t2);}
else{
t4=((C_word*)((C_word*)t0)[6])[1];
if(C_truep(t4)){
t5=t3;
f_10251(t5,C_SCHEME_FALSE);}
else{
t5=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[7])[1],t1);
t6=C_mutate2(((C_word *)((C_word*)t0)[7])+1,t5);
t7=t3;
f_10251(t7,C_SCHEME_TRUE);}}}

/* k9388 in k9385 in k9379 in k9373 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9390,2,t0,t1);}
if(C_truep(C_i_nullp(t1))){
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9416,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1254: qnode */
t5=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=C_i_cdr(t1);
if(C_truep(C_i_nullp(t2))){
t3=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t4=C_u_i_car(t1);
t5=C_a_i_list2(&a,2,((C_word*)t0)[2],t4);
t6=((C_word*)t0)[3];
t7=t6;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_record4(&a,4,lf[14],lf[12],t3,t5));}
else{
t3=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9460,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9462,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1262: fold-inner */
t7=*((C_word*)lf[155]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t1);}}}

/* k12072 in k12175 in k12179 in k11933 in descend in k11774 in k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in ... */
static void C_ccall f_12074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12074,2,t0,t1);}
t2=C_a_i_record4(&a,4,lf[14],lf[22],((C_word*)t0)[2],t1);
t3=C_a_i_list1(&a,1,t2);
t4=C_a_i_record4(&a,4,lf[14],lf[11],((C_word*)t0)[3],t3);
t5=C_a_i_list1(&a,1,t4);
t6=C_a_i_record4(&a,4,lf[14],lf[13],((C_word*)t0)[4],t5);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12006,a[2]=t7,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12010,a[2]=t8,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1733: varnode */
t10=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,((C_word*)t0)[11]);}

/* k6128 in k6154 in k6196 in k6097 in k6080 in k6054 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* for-each-loop880 in k6154 in k6196 in k6097 in k6080 in k6054 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_6132(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6132,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6142,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:491: g881 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9373 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9375,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9381,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:1245: fifth */
t5=*((C_word*)lf[154]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k13123 in k13140 in k13097 in a13085 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_13125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13125,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13129,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:678: qnode */
t4=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* k13119 in k13140 in k13097 in a13085 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_13121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13121,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record4(&a,4,lf[14],lf[22],((C_word*)t0)[3],t1));}

/* k13127 in k13123 in k13140 in k13097 in a13085 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_13129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:677: cons* */
t2=*((C_word*)lf[151]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* f_6157 in k6154 in k6196 in k6097 in k6080 in k6054 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6157(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6157,3,t0,t1,t2);}
t3=C_i_cdr(t2);
t4=C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
t5=t2;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_i_set_i_slot(t5,C_fix(1),C_SCHEME_FALSE));}
else{
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k6154 in k6196 in k6097 in k6080 in k6054 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6156,2,t0,t1);}
t2=(C_truep(t1)?(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6157,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6174,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp));
t3=t2;
t4=((C_word*)t0)[3];
t5=C_i_check_list_2(t4,lf[2]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6130,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6132,a[2]=t8,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_6132(t10,t6,t4);}

/* k9050 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9052,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9072,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=C_i_car(((C_word*)t0)[4]);
/* optimizer.scm:1187: qnode */
t6=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5772 in k5794 in k5798 in k5752 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_eqp(t1,lf[53]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_5309(t3,C_SCHEME_FALSE);}
else{
if(C_truep(((C_word*)t0)[3])){
t3=((C_word*)t0)[2];
f_5309(t3,((C_word*)t0)[3]);}
else{
t3=C_i_cadddr(((C_word*)t0)[4]);
t4=((C_word*)t0)[2];
f_5309(t4,C_i_lessp(t3,*((C_word*)lf[96]+1)));}}}

/* k7008 in a6996 in k6975 in k6972 in k6912 in k6852 in k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_7010(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7010,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t2);
t4=C_i_assq(((C_word*)t0)[2],((C_word*)t0)[4]);
t5=C_i_cdr(t4);
t6=C_a_i_list2(&a,2,t5,((C_word*)t0)[5]);
t7=((C_word*)t0)[6];
t8=t7;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_record4(&a,4,lf[14],lf[6],((C_word*)t0)[7],t6));}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7039,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7069,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7071,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:894: fold-right */
t5=*((C_word*)lf[137]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,((C_word*)t0)[5],((C_word*)t0)[7]);}}

/* k13140 in k13097 in a13085 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_13142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13142,2,t0,t1);}
t2=C_i_length(t1);
t3=C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
t5=C_a_i_list1(&a,1,t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13121,a[2]=((C_word*)t0)[3],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13125,a[2]=t7,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:677: varnode */
t9=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,((C_word*)t0)[7]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* a10255 in k10249 in k10243 in rec in scan in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10256(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10256,3,t0,t1,t2);}
/* optimizer.scm:1404: rec */
t3=((C_word*)((C_word*)t0)[2])[1];
f_10076(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k10249 in k10243 in rec in scan in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_10251(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10251,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10256,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1404: every */
t3=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_11767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11767,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11770,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_i_check_list_2(((C_word*)t0)[5],lf[35]);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12295,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12297,a[2]=t6,a[3]=t10,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_12297(t12,t8,((C_word*)t0)[5]);}

/* k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_11764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11764,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11767,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm:1674: gensym */
t4=*((C_word*)lf[87]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[195]);}

/* k9070 in k9050 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9072,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[4],t2));}

/* k10227 in rec in scan in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10229,2,t0,t1);}
if(C_truep(C_i_nullp(t1))){
t2=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]),((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t2);
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4398 in a4378 in k4368 in k4290 in walk in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4400,2,t0,t1);}
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=C_i_cadr(((C_word*)t0)[2]);
t4=C_a_i_list2(&a,2,t3,t1);
t5=((C_word*)t0)[3];
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_record4(&a,4,lf[14],lf[12],t2,t4));}

/* k13024 in k13030 in loop2 in k12839 in k13054 in k13060 in loop1 in a12726 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_13026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_12899(t2,C_SCHEME_FALSE);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t2=C_i_car(((C_word*)t0)[4]);
t3=C_slot(t2,C_fix(1));
t4=C_eqp(lf[13],t3);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
t6=C_u_i_car(t5);
t7=C_u_i_car(((C_word*)t0)[4]);
t8=C_slot(t7,C_fix(2));
t9=C_i_car(t8);
t10=((C_word*)t0)[2];
f_12899(t10,C_eqp(t6,t9));}
else{
t5=((C_word*)t0)[2];
f_12899(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
f_12899(t2,C_SCHEME_FALSE);}}}

/* map-loop740 in k5695 in a5629 in k5617 in k5605 in k5602 in k5405 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_5660(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5660,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5689,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:435: g746 */
t5=((C_word*)t0)[5];
f_5648(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8967 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_8969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8969,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9002,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(*((C_word*)lf[145]+1))){
t5=C_i_cddr(((C_word*)t0)[5]);
t6=C_i_pairp(t5);
t7=t4;
f_9002(t7,(C_truep(t6)?C_i_caddr(((C_word*)t0)[5]):C_i_cadr(((C_word*)t0)[5])));}
else{
t5=t4;
f_9002(t5,C_i_cadr(((C_word*)t0)[5]));}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k10717 in for-each-loop2510 in k10680 in k10677 in k10674 in k10657 in k10654 in k10587 in k10584 in k10578 in k10575 in k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in ... */
static void C_ccall f_10719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10719,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
/* optimizer.scm:1551: node-parameters-set! */
t3=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],((C_word*)t0)[3],t2);}

/* k8633 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_8635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8635,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=C_eqp(*((C_word*)lf[146]+1),t3);
if(C_truep(t4)){
t5=C_i_cadddr(((C_word*)t0)[2]);
t6=(C_truep(t5)?t5:*((C_word*)lf[145]+1));
if(C_truep(t6)){
t7=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8679,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t8,tmp=(C_word)a,a+=6,tmp);
if(C_truep(*((C_word*)lf[145]+1))){
t10=((C_word*)t0)[2];
t11=C_u_i_cdr(t10);
t12=C_u_i_cdr(t11);
t13=C_u_i_cdr(t12);
t14=C_u_i_car(t13);
t15=t9;
f_8679(t15,C_a_i_list1(&a,1,t14));}
else{
t10=((C_word*)t0)[2];
t11=C_u_i_cdr(t10);
t12=C_u_i_cdr(t11);
t13=C_u_i_car(t12);
t14=t9;
f_8679(t14,C_a_i_list1(&a,1,t13));}}
else{
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3740 in for-each-loop42 in scan-each in scan-toplevel-assignments in k3676 in k3673 in k3670 */
static void C_ccall f_3742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3732(t3,((C_word*)t0)[4],t2);}

/* for-each-loop2510 in k10680 in k10677 in k10674 in k10657 in k10654 in k10587 in k10584 in k10578 in k10575 in k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in ... */
static void C_fcall f_10724(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10724,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10734,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=C_i_cdr(t4);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10690,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10719,a[2]=t8,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1551: gensym */
t10=*((C_word*)lf[87]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g503 in k5031 in k5028 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_5037(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5037,NULL,3,t0,t1,t2);}
t3=*((C_word*)lf[47]+1);
/* optimizer.scm:326: g518 */
t4=*((C_word*)lf[47]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,((C_word*)t0)[2],t2,lf[70],C_SCHEME_TRUE);}

/* k5695 in a5629 in k5617 in k5605 in k5602 in k5405 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5697,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5658,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5660,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_5660(t7,t3,t2);}

/* for-each-loop42 in scan-each in scan-toplevel-assignments in k3676 in k3673 in k3670 */
static void C_fcall f_3732(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3732,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3742,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:41: g43 */
t5=((C_word*)t0)[3];
f_3720(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9000 in k8967 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_9002(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9002,NULL,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
t3=((C_word*)t0)[2];
t4=C_a_i_record4(&a,4,lf[14],lf[144],t2,t3);
t5=C_a_i_list2(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[4];
t7=t6;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[5],t5));}

/* k5028 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5033,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm:324: debugging */
t3=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[18],lf[73],((C_word*)t0)[11]);}

/* k10732 in for-each-loop2510 in k10680 in k10677 in k10674 in k10657 in k10654 in k10587 in k10584 in k10578 in k10575 in k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in ... */
static void C_ccall f_10734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10724(t3,((C_word*)t0)[4],t2);}

/* k5031 in k5028 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5033,2,t0,t1);}
t2=f_4105(((C_word*)((C_word*)t0)[2])[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5037,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)t0)[4];
t5=C_i_check_list_2(t4,lf[2]);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5047,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[3],tmp=(C_word)a,a+=10,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5069,a[2]=t8,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_5069(t10,t6,t4);}

/* k5687 in map-loop740 in k5695 in a5629 in k5617 in k5605 in k5602 in k5405 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 in ... */
static void C_ccall f_5689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5689,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_5660(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_5660(t6,((C_word*)t0)[5],t5);}}

/* k11815 in g2924 in k11782 in g2910 in k11777 in k11774 in k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in ... */
static void C_ccall f_11817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11817,2,t0,t1);}
t2=C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[2],t1);
/* optimizer.scm:1747: copy-node! */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[4]);}

/* a10746 in k10674 in k10657 in k10654 in k10587 in k10584 in k10578 in k10575 in k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10747(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10747,4,t0,t1,t2,t3);}
t4=C_i_car(t2);
t5=C_a_i_list1(&a,1,t4);
t6=t2;
t7=C_u_i_cdr(t6);
t8=C_slot(t7,C_fix(3));
t9=C_i_car(t8);
t10=C_slot(t9,C_fix(1));
t11=C_slot(t9,C_fix(2));
t12=C_slot(t9,C_fix(3));
t13=C_a_i_record4(&a,4,lf[14],t10,t11,t12);
t14=C_a_i_list2(&a,2,t13,t3);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_a_i_record4(&a,4,lf[14],lf[6],t5,t14));}

/* k7067 in k7008 in a6996 in k6975 in k6972 in k6912 in k6852 in k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_7069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:889: fold-right */
t2=*((C_word*)lf[137]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}

/* k5052 in k5045 in k5031 in k5028 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:327: walk */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4278(t2,((C_word*)t0)[3],t1,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k5045 in k5031 in k5028 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5047,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5054,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_slot(((C_word*)t0)[6],C_fix(3));
t4=C_i_car(t3);
/* optimizer.scm:328: inline-lambda-bindings */
t5=*((C_word*)lf[71]+1);
((C_proc8)(void*)(*((C_word*)t5+1)))(8,t5,t2,((C_word*)t0)[7],((C_word*)t0)[8],t4,C_SCHEME_FALSE,((C_word*)t0)[9],*((C_word*)lf[72]+1));}

/* k5794 in k5798 in k5752 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5796,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_5309(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5774,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tweaks.scm:57: ##sys#get */
t3=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],lf[54]);}}

/* k4473 in replace-var in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4475,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4479,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:134: g314 */
t3=t2;
f_4479(t3,((C_word*)t0)[5],t1);}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k11835 in k11827 in k11819 in g2924 in k11782 in g2910 in k11777 in k11774 in k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in ... */
static void C_ccall f_11837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11837,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
/* optimizer.scm:1751: append */
t3=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t2);}

/* replace-var in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_4471(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4471,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4475,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:215: test */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4069(t4,t3,t2,lf[48]);}

/* g314 in k4473 in replace-var in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_4479(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4479,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4483,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:217: replace-var */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4471(t4,t3,t2);}

/* a12941 in k12897 in loop2 in k12839 in k13054 in k13060 in loop1 in a12726 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_12942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12950,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:731: reverse */
t3=*((C_word*)lf[107]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k4484 in k4481 in g314 in k4473 in replace-var in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* k4481 in g314 in k4473 in replace-var in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4483,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4486,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:219: put! */
t4=*((C_word*)lf[47]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[3],((C_word*)t0)[4],lf[48],t2);}

/* a13215 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_13216(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13){
C_word tmp;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr14,(void*)f_13216,14,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13);}
if(C_truep(C_i_equalp(t6,*((C_word*)lf[217]+1)))){
t14=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_13229,a[2]=t9,a[3]=t10,a[4]=t13,a[5]=t1,a[6]=t8,a[7]=t7,a[8]=t3,a[9]=t2,a[10]=t5,a[11]=t4,tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm:645: immediate? */
t15=*((C_word*)lf[219]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t14,t7);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}

/* k9912 in k9906 in k9988 in walk in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9914,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9920,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm:1348: get-list */
t4=*((C_word*)lf[124]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[10],((C_word*)t0)[7],lf[126]);}
else{
t3=((C_word*)t0)[4];
f_9878(2,t3,C_SCHEME_FALSE);}}

/* k4911 in a4905 in k4899 in k4800 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4913,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=C_i_cadr(((C_word*)t0)[2]);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4953,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
t7=C_a_i_plus(&a,2,((C_word*)t0)[8],C_fix(1));
/* optimizer.scm:296: build-lambda-list */
t8=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t6,((C_word*)t0)[9],t7,C_SCHEME_FALSE);}

/* k11827 in k11819 in g2924 in k11782 in g2910 in k11777 in k11774 in k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in ... */
static void C_ccall f_11829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11829,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11837,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_i_cadr(((C_word*)t0)[4]);
/* optimizer.scm:1756: qnode */
t5=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k11823 in k11819 in g2924 in k11782 in g2910 in k11777 in k11774 in k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in ... */
static void C_ccall f_11825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1750: cons* */
t2=*((C_word*)lf[151]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k11819 in g2924 in k11782 in g2910 in k11777 in k11774 in k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in ... */
static void C_ccall f_11821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11821,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11825,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11829,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=C_i_length(((C_word*)t0)[3]);
t6=C_a_i_minus(&a,2,((C_word*)t0)[5],t5);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11847,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm:1753: list-tabulate */
t8=*((C_word*)lf[188]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,t6,t7);}

/* for-each-loop2909 in k11777 in k11774 in k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_11902(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11902,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11912,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:1740: g2910 */
t5=((C_word*)t0)[3];
f_11780(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* a12951 in k12897 in loop2 in k12839 in k13054 in k13060 in loop1 in a12726 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_12952(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12952,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t2:C_SCHEME_FALSE));}

/* k12948 in a12941 in k12897 in loop2 in k12839 in k13054 in k13060 in loop1 in a12726 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_12950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:731: reorganize-recursive-bindings */
t2=*((C_word*)lf[130]+1);
f_6787(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}

/* k9918 in k9912 in k9906 in k9988 in walk in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9920,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=C_eqp(((C_word*)t0)[2],((C_word*)t0)[3]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9973,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t5=C_slot(((C_word*)t0)[3],C_fix(2));
t6=C_i_car(t5);
/* tweaks.scm:57: ##sys#get */
t7=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t6,lf[159]);}
else{
t4=((C_word*)t0)[4];
f_9878(2,t4,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[4];
f_9878(2,t3,C_SCHEME_FALSE);}}

/* k5752 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5754,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5800,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:366: test */
t3=((C_word*)((C_word*)t0)[6])[1];
f_4069(t3,t2,((C_word*)t0)[7],lf[70]);}
else{
t2=((C_word*)t0)[2];
f_5309(t2,C_SCHEME_FALSE);}}

/* k11910 in for-each-loop2909 in k11777 in k11774 in k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 in ... */
static void C_ccall f_11912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11902(t3,((C_word*)t0)[4],t2);}

/* k5739 in k5405 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_i_memq(((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t3=((C_word*)t0)[4];
f_5604(t3,C_i_not(t2));}
else{
t2=((C_word*)t0)[4];
f_5604(t2,C_SCHEME_FALSE);}}

/* a4905 in k4899 in k4800 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4906(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4906,5,t0,t1,t2,t3,t4);}
t5=f_4105(((C_word*)((C_word*)t0)[2])[1]);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4913,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t3,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm:291: debugging */
t7=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[18],lf[67],t4);}

/* k9906 in k9988 in walk in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9908,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9914,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm:1347: get-list */
t4=*((C_word*)lf[124]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[9],((C_word*)t0)[6],lf[78]);}
else{
t3=((C_word*)t0)[3];
f_9878(2,t3,C_SCHEME_FALSE);}}

/* k4899 in k4800 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4901,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4906,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:287: decompose-lambda-list */
t3=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[8],((C_word*)t0)[9],t2);}
else{
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
/* optimizer.scm:299: walk-generic */
t3=((C_word*)((C_word*)t0)[10])[1];
f_6267(t3,((C_word*)t0)[8],((C_word*)t0)[11],((C_word*)t0)[12],((C_word*)t0)[3],((C_word*)t0)[4],t2,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}}

/* k4951 in k4911 in a4905 in k4899 in k4800 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4953,2,t0,t1);}
t2=C_i_cadddr(((C_word*)t0)[2]);
t3=C_a_i_list4(&a,4,((C_word*)t0)[3],((C_word*)t0)[4],t1,t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4933,a[2]=((C_word*)t0)[5],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_i_car(((C_word*)t0)[6]);
t7=C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[8]);
/* optimizer.scm:298: walk */
t8=((C_word*)((C_word*)t0)[9])[1];
f_4278(t8,t5,t6,t7,C_SCHEME_END_OF_LIST);}

/* k13227 in a13215 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_13229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13229,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_13235,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm:646: immediate? */
t3=*((C_word*)lf[219]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5535 in k5531 in k5549 in k5511 in k5505 in k5499 in loop in k5405 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 in ... */
static void C_ccall f_5537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5537,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[14],lf[6],((C_word*)t0)[4],t2));}

/* k5531 in k5549 in k5511 in k5505 in k5499 in loop in k5405 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5533,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5537,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[4];
t5=C_u_i_cdr(t4);
t6=C_a_i_minus(&a,2,((C_word*)t0)[5],C_fix(1));
t7=((C_word*)t0)[6];
t8=C_u_i_cdr(t7);
/* optimizer.scm:418: loop */
t9=((C_word*)((C_word*)t0)[7])[1];
f_5421(t9,t3,t5,t6,t8,((C_word*)t0)[8]);}

/* k13233 in k13227 in a13215 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_13235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13235,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_13289,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm:647: get-list */
t3=*((C_word*)lf[124]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[9],((C_word*)t0)[11],lf[78]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a9322 in k9286 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9323,2,t0,t1);}
t2=C_a_i_minus(&a,2,((C_word*)t0)[2],C_fix(1));
/* optimizer.scm:1231: split-at */
t3=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,((C_word*)t0)[3],t2);}

/* k9319 in k9286 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9321,2,t0,t1);}
t2=C_a_i_record4(&a,4,lf[14],lf[144],((C_word*)t0)[2],t1);
t3=C_a_i_list2(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[4];
t5=t4;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[5],t3));}

/* k13097 in a13085 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_13099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13099,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13142,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:673: get-list */
t3=*((C_word*)lf[124]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[8],((C_word*)t0)[9],lf[78]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k9625 in k9577 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9627,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
t3=((C_word*)t0)[2];
t4=C_a_i_record4(&a,4,lf[14],lf[144],t2,t3);
t5=C_a_i_list2(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[4];
t7=t6;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[5],t5));}

/* a9332 in k9286 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9333(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9333,4,t0,t1,t2,t3);}
t4=t2;
t5=t3;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9345,a[2]=t1,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=C_i_caddr(((C_word*)t0)[2]);
/* optimizer.scm:1233: qnode */
t8=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}

/* k6026 in map-loop808 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6028,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_5999(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_5999(t6,((C_word*)t0)[5],t5);}}

/* a11672 in k11666 in g2707 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_11673(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11673,5,t0,t1,t2,t3,t4);}
t5=C_slot(((C_word*)t0)[2],C_fix(3));
t6=C_i_car(t5);
t7=t6;
t8=((C_word*)((C_word*)t0)[3])[1];
t9=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t10=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t9);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11684,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t8,a[5]=((C_word*)t0)[5],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t12=C_a_i_record4(&a,4,lf[14],lf[15],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
/* optimizer.scm:1669: copy-node! */
t13=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t11,t12,((C_word*)t0)[6]);}

/* a13085 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_13086(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10){
C_word tmp;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr11,(void*)f_13086,11,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}
if(C_truep(C_i_equalp(t4,*((C_word*)lf[217]+1)))){
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13099,a[2]=t9,a[3]=t1,a[4]=t8,a[5]=t10,a[6]=t6,a[7]=t5,a[8]=t2,a[9]=t3,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm:672: immediate? */
t12=*((C_word*)lf[219]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t6);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}

/* k11682 in a11672 in k11666 in g2707 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_11684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11684,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list4(&a,4,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6]));}

/* k6054 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6056,2,t0,t1);}
if(C_truep(t1)){
t2=f_4105(((C_word*)((C_word*)t0)[2])[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6062,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6073,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:476: test */
t5=((C_word*)((C_word*)t0)[5])[1];
f_4069(t5,t4,((C_word*)t0)[4],lf[56]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6082,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm:479: test */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4069(t3,t2,((C_word*)t0)[4],lf[48]);}}

/* k7644 in k7597 in k7588 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_7646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7646,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[3],t2);
/* optimizer.scm:964: fold-right */
t4=*((C_word*)lf[137]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[4],((C_word*)t0)[5],t3,((C_word*)t0)[6]);}

/* for-each-loop2923 in k11782 in g2910 in k11777 in k11774 in k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in ... */
static void C_fcall f_11872(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11872,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11882,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:1741: g2924 */
t5=((C_word*)t0)[3];
f_11785(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4931 in k4951 in k4911 in a4905 in k4899 in k4800 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4933,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
t3=((C_word*)t0)[2];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[14],lf[11],((C_word*)t0)[3],t2));}

/* k5511 in k5505 in k5499 in loop in k5405 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5513,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5551,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm:416: gensym */
t3=*((C_word*)lf[87]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[88]);}
else{
t2=((C_word*)t0)[3];
t3=C_u_i_cdr(t2);
t4=C_a_i_minus(&a,2,((C_word*)t0)[4],C_fix(1));
t5=((C_word*)t0)[5];
t6=C_u_i_cdr(t5);
/* optimizer.scm:419: loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_5421(t7,((C_word*)t0)[2],t3,t4,t6,((C_word*)t0)[7]);}}

/* k13060 in loop1 in a12726 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_13062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13062,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13056,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_u_i_car(((C_word*)t0)[4]);
/* optimizer.scm:703: get */
t4=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[7],t3,lf[78]);}}

/* k7689 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_7691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7691,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_a_i_list2(&a,2,C_SCHEME_FALSE,t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7711,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t6=((C_word*)t0)[2];
t7=C_u_i_car(t6);
/* optimizer.scm:977: varnode */
t8=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t5,t7);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7115 in a7070 in k7008 in a6996 in k6975 in k6972 in k6912 in k6852 in k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_7117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7117,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
t3=C_a_i_list1(&a,1,((C_word*)t0)[2]);
t4=C_i_assq(((C_word*)t0)[2],((C_word*)t0)[3]);
t5=C_i_cdr(t4);
t6=C_a_i_list1(&a,1,t5);
t7=C_a_i_record4(&a,4,lf[14],lf[13],t3,t6);
t8=C_a_i_list2(&a,2,t7,((C_word*)t0)[4]);
t9=((C_word*)t0)[5];
t10=t9;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_a_i_record4(&a,4,lf[14],lf[6],t2,t8));}

/* a11846 in k11819 in g2924 in k11782 in g2910 in k11777 in k11774 in k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in ... */
static void C_ccall f_11847(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11847,2,t0,t1);}
/* optimizer.scm:1755: qnode */
t2=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_FALSE);}

/* k5505 in k5499 in loop in k5405 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5507,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5513,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=C_i_car(((C_word*)t0)[5]);
/* optimizer.scm:413: expression-has-side-effects? */
t4=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[11]);}

/* k5499 in loop in k5405 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5501,2,t0,t1);}
if(C_truep(t1)){
t2=f_4105(((C_word*)((C_word*)t0)[2])[1]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5507,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t4=((C_word*)t0)[4];
t5=C_u_i_car(t4);
/* optimizer.scm:410: debugging */
t6=*((C_word*)lf[17]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t3,lf[18],lf[89],t5,((C_word*)t0)[13]);}
else{
t2=((C_word*)t0)[4];
t3=C_u_i_cdr(t2);
t4=C_a_i_minus(&a,2,((C_word*)t0)[5],C_fix(1));
t5=C_i_cdr(((C_word*)t0)[6]);
t6=((C_word*)t0)[6];
t7=C_u_i_car(t6);
t8=C_a_i_cons(&a,2,t7,((C_word*)t0)[8]);
/* optimizer.scm:420: loop */
t9=((C_word*)((C_word*)t0)[7])[1];
f_5421(t9,((C_word*)t0)[3],t3,t4,t5,t8);}}

/* k8414 in k8404 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_8416(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8416,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_a_i_list2(&a,2,C_SCHEME_TRUE,t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8432,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8436,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t7=((C_word*)t0)[2];
t8=C_u_i_cdr(t7);
t9=C_u_i_car(t8);
/* optimizer.scm:1080: varnode */
t10=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t6,t9);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8404 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_8406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8406,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8416,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_8416(t6,t4);}
else{
t6=C_i_length(((C_word*)t0)[5]);
t7=((C_word*)t0)[2];
t8=C_u_i_car(t7);
t9=t5;
f_8416(t9,C_i_nequalp(t6,t8));}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a5623 in k5617 in k5605 in k5602 in k5405 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5624,2,t0,t1);}
/* optimizer.scm:431: split-at */
t2=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k12573 in a12554 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_12575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12575,2,t0,t1);}
t2=C_a_i_list3(&a,3,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);
t3=C_a_i_record4(&a,4,lf[14],lf[21],C_SCHEME_END_OF_LIST,t2);
t4=C_a_i_list2(&a,2,t1,t3);
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[6];
t7=t5;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_record4(&a,4,lf[14],lf[12],t6,t4));}

/* k11248 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_11250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1446: debugging */
t2=*((C_word*)lf[17]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[2],lf[18],lf[181],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}

/* a11251 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_11252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11252,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11258,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11269,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* tmp13566 */
t4=t2;
f_11258(t4,t3);}

/* tmp13566 in a11251 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_11258(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11258,NULL,2,t0,t1);}
/* optimizer.scm:1446: unzip1 */
t2=*((C_word*)lf[182]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k3866 in k3834 in scan in scan-toplevel-assignments in k3676 in k3673 in k3670 */
static void C_ccall f_3868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3875,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:83: last */
t3=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* descend in k11774 in k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_11925(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11925,NULL,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(3));
t5=C_i_cadr(t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_11935,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t6,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t2,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
t8=C_slot(t6,C_fix(1));
t9=C_eqp(lf[6],t8);
if(C_truep(t9)){
t10=C_slot(t6,C_fix(3));
t11=C_i_car(t10);
t12=C_slot(t11,C_fix(1));
t13=t7;
f_11935(t13,C_eqp(lf[15],t12));}
else{
t10=t7;
f_11935(t10,C_SCHEME_FALSE);}}

/* k11880 in for-each-loop2923 in k11782 in g2910 in k11777 in k11774 in k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in ... */
static void C_ccall f_11882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11872(t3,((C_word*)t0)[4],t2);}

/* k11933 in descend in k11774 in k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_11935(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11935,NULL,2,t0,t1);}
if(C_truep(t1)){
/* optimizer.scm:1691: descend */
t2=((C_word*)((C_word*)t0)[2])[1];
f_11925(t2,((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t2=C_a_i_list1(&a,1,((C_word*)t0)[5]);
t3=t2;
t4=C_a_i_record4(&a,4,lf[14],lf[15],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12181,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t5,a[6]=t3,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm:1700: gensym */
t7=*((C_word*)lf[87]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_5016(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5016,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[2],C_fix(2));
t3=C_i_caddr(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5030,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[2],a[9]=t4,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm:323: check-signature */
t6=*((C_word*)lf[74]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[11],((C_word*)t0)[9],t4);}
else{
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_5101,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[16],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[4],a[13]=((C_word*)t0)[17],a[14]=((C_word*)t0)[2],a[15]=((C_word*)t0)[3],a[16]=((C_word*)t0)[6],a[17]=((C_word*)t0)[11],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
/* tweaks.scm:57: ##sys#get */
t3=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[11],lf[100]);}}

/* k3881 in k3834 in scan in scan-toplevel-assignments in k3676 in k3673 in k3670 */
static void C_ccall f_3883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:82: scan-each */
t2=((C_word*)((C_word*)t0)[2])[1];
f_3718(t2,((C_word*)t0)[3],t1,((C_word*)t0)[4]);}

/* a6996 in k6975 in k6972 in k6912 in k6852 in k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6997(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6997,4,t0,t1,t2,t3);}
t4=C_i_assq(t2,((C_word*)((C_word*)t0)[2])[1]);
t5=C_i_cdr(t4);
t6=t5;
t7=C_i_car(t6);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7010,a[2]=t8,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t1,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t10=C_u_i_cdr(t6);
if(C_truep(C_i_nullp(t10))){
t11=C_i_assq(t8,((C_word*)((C_word*)t0)[5])[1]);
t12=C_i_cdr(t11);
t13=C_i_memq(t8,t12);
t14=t9;
f_7010(t14,C_i_not(t13));}
else{
t11=t9;
f_7010(t11,C_SCHEME_FALSE);}}

/* k8470 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_8472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8472,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[2]);
t3=(C_truep(t2)?t2:*((C_word*)lf[145]+1));
if(C_truep(t3)){
t4=C_i_length(((C_word*)t0)[3]);
t5=C_i_caddr(((C_word*)t0)[2]);
if(C_truep(C_i_less_or_equalp(t4,t5))){
t6=C_eqp(t4,C_fix(1));
if(C_truep(t6)){
t7=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t8=C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t9=((C_word*)t0)[5];
t10=t9;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_a_i_record4(&a,4,lf[14],lf[12],t7,t8));}
else{
t7=((C_word*)t0)[2];
t8=C_u_i_car(t7);
t9=C_a_i_list2(&a,2,C_SCHEME_TRUE,t8);
t10=t9;
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8528,a[2]=((C_word*)t0)[5],a[3]=t10,tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8532,a[2]=t11,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t13=((C_word*)t0)[2];
t14=C_u_i_car(t13);
/* optimizer.scm:1095: varnode */
t15=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t12,t14);}}
else{
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5009,2,t0,t1);}
t2=t1;
t3=C_u_i_cdr(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_5016,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[2],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],tmp=(C_word)a,a+=21,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5903,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:316: test */
t6=((C_word*)((C_word*)t0)[15])[1];
f_4069(t6,t5,((C_word*)t0)[10],lf[58]);}

/* k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5006,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_5009,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5949,a[2]=t3,a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:312: test */
t5=((C_word*)((C_word*)t0)[14])[1];
f_4069(t5,t4,((C_word*)t0)[9],lf[79]);}

/* a6961 in a6955 in g1395 in k6912 in k6852 in k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6962(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6962,3,t0,t1,t2);}
/* optimizer.scm:863: find-path */
t3=((C_word*)t0)[2];
f_6799(t3,t1,((C_word*)t0)[3],t2);}

/* k5105 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_5107(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* optimizer.scm:353: walk-generic */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6267(t2,((C_word*)t0)[2],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[8],((C_word*)t0)[9],C_SCHEME_FALSE);}}

/* k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5101,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5107,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t3)){
t5=C_slot(t3,C_fix(1));
t6=C_eqp(lf[3],t5);
if(C_truep(t6)){
t7=C_slot(t3,C_fix(2));
t8=C_i_car(t7);
t9=t8;
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5128,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5251,a[2]=t10,a[3]=((C_word*)t0)[13],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:337: test */
t12=((C_word*)((C_word*)t0)[13])[1];
f_4069(t12,t11,t9,lf[79]);}
else{
t10=t4;
f_5107(t10,C_SCHEME_FALSE);}}
else{
t7=t4;
f_5107(t7,C_SCHEME_FALSE);}}
else{
t5=t4;
f_5107(t5,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_5275,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[2],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[13],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[3],tmp=(C_word)a,a+=21,tmp);
if(C_truep(((C_word*)t0)[14])){
t3=C_slot(((C_word*)t0)[14],C_fix(1));
t4=t2;
f_5275(t4,C_eqp(lf[11],t3));}
else{
t3=t2;
f_5275(t3,C_SCHEME_FALSE);}}}

/* a8111 in k8105 in k8099 in k8091 in k8088 in k8056 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_8112(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8112,5,t0,t1,t2,t3,t4);}
t5=C_a_i_list1(&a,1,t3);
t6=C_a_i_list2(&a,2,t2,t4);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_record4(&a,4,lf[14],lf[6],t5,t6));}

/* k7955 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_7957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7957,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=t2;
t4=C_i_cadr(((C_word*)t0)[2]);
t5=C_a_i_list1(&a,1,t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7990,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7998,a[2]=t7,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t9=C_i_caddr(((C_word*)t0)[2]);
/* optimizer.scm:1019: qnode */
t10=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5617 in k5605 in k5602 in k5405 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5624,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5630,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm:431: ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[11],t2,t3);}

/* a5629 in k5617 in k5605 in k5602 in k5405 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5630(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5630,4,t0,t1,t2,t3);}
t4=t2;
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5648,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5697,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[4],a[8]=t8,a[9]=t6,a[10]=t9,tmp=(C_word)a,a+=11,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5705,a[2]=t10,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
/* optimizer.scm:441: qnode */
t12=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,C_SCHEME_END_OF_LIST);}
else{
t12=C_i_length(t3);
t13=C_a_i_times(&a,2,C_fix(3),t12);
t14=C_a_i_list2(&a,2,lf[91],t13);
t15=C_a_i_record4(&a,4,lf[14],lf[92],t14,t3);
t16=C_a_i_list1(&a,1,t15);
/* optimizer.scm:437: append */
t17=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t17+1)))(4,t17,t10,t4,t16);}}

/* k8099 in k8091 in k8088 in k8056 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_8101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8101,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=*((C_word*)lf[51]+1);
t8=C_i_check_list_2(t2,lf[35]);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8107,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8183,a[2]=t6,a[3]=t11,a[4]=t4,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_8183(t13,t9,t2);}

/* map-loop2735 in g2707 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_11707(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11707,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11736,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:1662: g2741 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7197 in for-each-loop1330 in k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_7199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_slot(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_7189(t4,((C_word*)t0)[5],t2,t3);}

/* rec in scan in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_10076(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10076,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=t7;
t9=t2;
t10=C_slot(t9,C_fix(3));
t11=t10;
t12=t2;
t13=C_slot(t12,C_fix(1));
t14=C_eqp(t13,lf[3]);
if(C_truep(t14)){
t15=C_i_car(t8);
t16=t15;
t17=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10140,a[2]=t1,a[3]=t16,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:1373: get */
t18=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t18+1)))(5,t18,t17,((C_word*)t0)[5],t16,lf[160]);}
else{
t15=C_eqp(t13,lf[11]);
if(C_truep(t15)){
if(C_truep(t3)){
t16=C_i_caddr(t8);
t17=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10158,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t11,a[5]=((C_word*)t0)[7],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:1381: decompose-lambda-list */
t18=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t1,t16,t17);}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}}
else{
t16=C_eqp(t13,lf[92]);
if(C_truep(t16)){
t17=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t17)){
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,C_SCHEME_FALSE);}
else{
t18=C_i_cadr(t8);
t19=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[4])[1],t18);
t20=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t19);
t21=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10195,a[2]=((C_word*)t0)[7],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1390: every */
t22=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t22+1)))(4,t22,t1,t21,t11);}}
else{
t17=C_eqp(t13,lf[69]);
if(C_truep(t17)){
if(C_truep(t4)){
if(C_truep(((C_word*)t0)[8])){
t18=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10229,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[9],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t19=C_i_car(t11);
/* optimizer.scm:1393: scan-used-variables */
t20=*((C_word*)lf[131]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t18,t19,t5);}
else{
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,C_SCHEME_FALSE);}}
else{
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,C_SCHEME_FALSE);}}
else{
t18=C_eqp(t13,lf[161]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10245,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=t1,a[5]=t11,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t20=C_i_cadr(t8);
/* optimizer.scm:1398: estimate-foreign-result-size */
t21=*((C_word*)lf[162]+1);
((C_proc3)(void*)(*((C_word*)t21+1)))(3,t21,t19,t20);}
else{
t19=C_eqp(t13,lf[163]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10286,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=t1,a[5]=t11,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t21=C_i_car(t8);
/* optimizer.scm:1406: estimate-foreign-result-size */
t22=*((C_word*)lf[162]+1);
((C_proc3)(void*)(*((C_word*)t22+1)))(3,t22,t20,t21);}
else{
t20=C_eqp(t13,lf[12]);
if(C_truep(t20)){
t21=C_i_car(t11);
t22=C_slot(t21,C_fix(1));
t23=C_eqp(lf[3],t22);
if(C_truep(t23)){
t24=C_slot(t21,C_fix(2));
t25=C_i_car(t24);
t26=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10339,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=t11,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t27=C_eqp(t25,((C_word*)t0)[10]);
if(C_truep(t27)){
if(C_truep(C_i_zerop(((C_word*)((C_word*)t0)[4])[1]))){
t28=C_i_cadr(t11);
t29=C_slot(t28,C_fix(1));
t30=C_eqp(lf[3],t29);
if(C_truep(t30)){
t31=C_slot(t28,C_fix(2));
t32=C_i_car(t31);
t33=C_a_i_cons(&a,2,t32,((C_word*)((C_word*)t0)[11])[1]);
t34=C_mutate2(((C_word *)((C_word*)t0)[11])+1,t33);
t35=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t36=t26;
f_10339(t36,C_SCHEME_TRUE);}
else{
t31=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t32=t26;
f_10339(t32,C_SCHEME_TRUE);}}
else{
t28=t26;
f_10339(t28,C_SCHEME_FALSE);}}
else{
t28=t26;
f_10339(t28,C_eqp(t25,((C_word*)t0)[12]));}}
else{
t24=t1;
((C_proc2)(void*)(*((C_word*)t24+1)))(2,t24,C_SCHEME_FALSE);}}
else{
t21=C_eqp(t13,lf[164]);
if(C_truep(t21)){
t22=C_i_cadddr(t8);
t23=C_i_zerop(t22);
if(C_truep(t23)){
t24=t1;
((C_proc2)(void*)(*((C_word*)t24+1)))(2,t24,t23);}
else{
t24=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t24)){
t25=t1;
((C_proc2)(void*)(*((C_word*)t25+1)))(2,t25,C_SCHEME_FALSE);}
else{
t25=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[4])[1],t22);
t26=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t25);
t27=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10446,a[2]=((C_word*)t0)[7],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1432: every */
t28=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t28+1)))(4,t28,t1,t27,t11);}}}
else{
t22=C_eqp(t13,lf[13]);
if(C_truep(t22)){
t23=C_i_car(t11);
t24=C_i_car(t8);
/* optimizer.scm:1433: rec */
t69=t1;
t70=t23;
t71=t24;
t72=C_SCHEME_FALSE;
t73=t5;
t1=t69;
t2=t70;
t3=t71;
t4=t72;
t5=t73;
goto loop;}
else{
t23=C_eqp(t13,lf[6]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10479,a[2]=t11,a[3]=((C_word*)t0)[7],a[4]=t1,a[5]=t8,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t25=C_i_car(t11);
t26=C_i_car(t8);
/* optimizer.scm:1435: rec */
t69=t24;
t70=t25;
t71=t26;
t72=t2;
t73=t5;
t1=t69;
t2=t70;
t3=t71;
t4=t72;
t5=t73;
goto loop;}
else{
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10503,a[2]=((C_word*)t0)[7],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1437: every */
t25=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t25+1)))(4,t25,t1,t24,t11);}}}}}}}}}}}

/* k6978 in k6975 in k6972 in k6912 in k6852 in k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6980,2,t0,t1);}
t2=t1;
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6989,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:906: debugging */
t4=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[18],lf[136],((C_word*)((C_word*)t0)[2])[1]);}
else{
/* optimizer.scm:908: values */
C_values(4,0,((C_word*)t0)[3],t2,C_SCHEME_FALSE);}}

/* k5605 in k5602 in k5405 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5607,2,t0,t1);}
t2=t1;
t3=C_i_length(((C_word*)t0)[2]);
if(C_truep(C_i_lessp(t3,t2))){
/* optimizer.scm:428: walk-generic */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6267(t4,((C_word*)t0)[4],t2,((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[8],((C_word*)t0)[9],C_SCHEME_TRUE);}
else{
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5619,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[4],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm:430: debugging */
t5=*((C_word*)lf[17]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[18],lf[93],((C_word*)t0)[14],t2);}}

/* scan in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_10073(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10073,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_10076,a[2]=t6,a[3]=t10,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t8,a[7]=t12,a[8]=t5,a[9]=((C_word*)t0)[4],a[10]=t4,a[11]=((C_word*)t0)[5],a[12]=t3,tmp=(C_word)a,a+=13,tmp));
t14=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_END_OF_LIST);
t15=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_END_OF_LIST);
t16=C_set_block_item(((C_word*)t0)[2],0,C_fix(0));
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10536,a[2]=t1,a[3]=t8,a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:1441: rec */
t18=((C_word*)t12)[1];
f_10076(t18,t17,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,t6);}

/* k5602 in k5405 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_5604(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5604,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_5607,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* optimizer.scm:426: llist-length */
t3=*((C_word*)lf[94]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[15]);}
else{
/* optimizer.scm:449: walk-generic */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6267(t2,((C_word*)t0)[4],((C_word*)t0)[16],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[8],((C_word*)t0)[9],C_SCHEME_TRUE);}}

/* k6987 in k6978 in k6975 in k6972 in k6912 in k6852 in k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:907: values */
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[3],C_SCHEME_TRUE);}

/* loop in k12103 in a12096 in k12167 in k12175 in k12179 in k11933 in descend in k11774 in k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in ... */
static void C_fcall f_12115(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12115,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_cadddr(((C_word*)t0)[2]));}
else{
t4=C_i_car(t3);
t5=C_a_i_list1(&a,1,t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12145,a[2]=t1,a[3]=t6,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t8=C_i_car(t2);
/* optimizer.scm:1724: varnode */
t9=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}}

/* a6955 in g1395 in k6912 in k6852 in k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6956(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6956,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6962,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:863: filter */
t4=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,((C_word*)t0)[3]);}

/* k11734 in map-loop2735 in g2707 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_11736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11736,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_11707(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_11707(t6,((C_word*)t0)[5],t5);}}

/* k8430 in k8414 in k8404 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_8432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8432,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[3],t1));}

/* k8434 in k8414 in k8404 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_8436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1080: cons* */
t2=*((C_word*)lf[151]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k3873 in k3866 in k3834 in scan in scan-toplevel-assignments in k3676 in k3673 in k3670 */
static void C_ccall f_3875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3875,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3879,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:83: append */
t4=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k3877 in k3873 in k3866 in k3834 in scan in scan-toplevel-assignments in k3676 in k3673 in k3670 */
static void C_ccall f_3879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:83: scan */
t2=((C_word*)((C_word*)t0)[2])[1];
f_3755(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k5077 in for-each-loop502 in k5031 in k5028 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5069(t3,((C_word*)t0)[4],t2);}

/* k7996 in k7955 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_7998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7998,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
/* optimizer.scm:1018: append */
t3=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],((C_word*)t0)[3],t2);}

/* k7988 in k7955 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_7990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7990,2,t0,t1);}
t2=C_a_i_record4(&a,4,lf[14],lf[144],((C_word*)t0)[2],t1);
t3=C_a_i_list2(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[4];
t5=t4;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[5],t3));}

/* k6972 in k6912 in k6852 in k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6977,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:875: topological-sort */
t3=*((C_word*)lf[139]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[7])[1],*((C_word*)lf[27]+1));}

/* k5703 in a5629 in k5617 in k5605 in k5602 in k5405 in k5307 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5705,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
/* optimizer.scm:437: append */
t3=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],((C_word*)t0)[3],t2);}

/* k9876 in walk in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm:1356: transform */
t2=((C_word*)((C_word*)t0)[2])[1];
f_10545(t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[8],((C_word*)((C_word*)t0)[9])[1]);}
else{
t2=C_i_car(((C_word*)t0)[10]);
/* optimizer.scm:1357: walk */
t3=((C_word*)((C_word*)t0)[11])[1];
f_9838(t3,((C_word*)t0)[3],C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}}

/* k6975 in k6972 in k6912 in k6852 in k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6977,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6980,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6997,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:880: fold */
t6=*((C_word*)lf[138]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,t5,((C_word*)t0)[6],t1);}

/* for-each-loop502 in k5031 in k5028 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_5069(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5069,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5079,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:326: g503 */
t5=((C_word*)t0)[3];
f_5037(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4391 in k4387 in a4378 in k4368 in k4290 in walk in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2((C_word*)lf[39]+1 /* (set! ##compiler#broken-constant-nodes ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}

/* k12103 in a12096 in k12167 in k12175 in k12179 in k11933 in descend in k11774 in k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in ... */
static void C_ccall f_12105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12105,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12109,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_caddr(((C_word*)t0)[3]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12115,a[2]=((C_word*)t0)[3],a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_12115(t8,t3,((C_word*)t0)[4],t4);}

/* k12107 in k12103 in a12096 in k12167 in k12175 in k12179 in k11933 in descend in k11774 in k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in ... */
static void C_ccall f_12109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12109,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list2(&a,2,((C_word*)t0)[3],t1));}

/* k11666 in g2707 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_11668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11668,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11673,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:1663: decompose-lambda-list */
t3=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[7],((C_word*)t0)[5],t2);}

/* g2447 in k10587 in k10584 in k10578 in k10575 in k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_10590(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10590,NULL,3,t0,t1,t2);}
t3=C_i_cdr(t2);
t4=t3;
t5=C_slot(t4,C_fix(3));
t6=t5;
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10605,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t8=C_i_cdr(t6);
t9=C_i_length(t8);
t10=C_eqp(((C_word*)t0)[4],t9);
if(C_truep(t10)){
t11=t7;
f_10605(2,t11,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm:1521: quit */
t11=*((C_word*)lf[167]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t7,lf[168],((C_word*)t0)[5]);}}

/* a5191 in k5150 in k5147 in k5126 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5192(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5192,3,t0,t1,t2);}
t3=*((C_word*)lf[76]+1);
/* optimizer.scm:344: g566 */
t4=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,((C_word*)t0)[2]);}

/* k5188 in k5150 in k5147 in k5126 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5190,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_5107(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5161,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:346: debugging */
t3=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[18],lf[75],((C_word*)t0)[4]);}}

/* k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10564,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=t2;
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_10573,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=t5,a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
if(C_truep(C_i_listp(((C_word*)t0)[2]))){
t7=C_u_i_length(((C_word*)t0)[2]);
t8=C_eqp(t7,C_fix(4));
if(C_truep(t8)){
t9=C_i_caddr(((C_word*)t0)[2]);
t10=t6;
f_10573(t10,C_i_listp(t9));}
else{
t9=t6;
f_10573(t9,C_SCHEME_FALSE);}}
else{
t7=t6;
f_10573(t7,C_SCHEME_FALSE);}}

/* k5209 in k5215 in k5147 in k5126 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5152(t2,C_i_not(t1));}

/* k10587 in k10584 in k10578 in k10575 in k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10590,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10656,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10846,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm:1531: lset-difference */
t5=*((C_word*)lf[169]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,((C_word*)t0)[9],((C_word*)((C_word*)t0)[10])[1]);}

/* constant-node? in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4075(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4075,3,t0,t1,t2);}
t3=C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_eqp(lf[34],t3));}

/* k10584 in k10578 in k10575 in k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10589,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=((C_word*)t0)[11];
t4=C_slot(t3,C_fix(3));
t5=C_i_car(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10864,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[13],a[8]=t7,a[9]=((C_word*)t0)[14],tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_10864(3,t9,t2,t5);}

/* k10578 in k10575 in k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10580,2,t0,t1);}
t2=C_u_i_cdr(((C_word*)t0)[2]);
t3=C_u_i_cdr(t2);
t4=C_i_setslot(t3,C_fix(0),t1);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_10586,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
/* optimizer.scm:1461: node-class-set! */
t6=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[12],lf[69]);}

/* walk in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_9838(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word *a;
loop:
a=C_alloc(22);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9838,NULL,5,t0,t1,t2,t3,t4);}
t5=t3;
t6=C_slot(t5,C_fix(2));
t7=t3;
t8=C_slot(t7,C_fix(3));
t9=t8;
t10=t3;
t11=C_slot(t10,C_fix(1));
t12=C_eqp(t11,lf[11]);
if(C_truep(t12)){
t13=C_i_caddr(t6);
t14=t13;
t15=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9878,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t4,a[9]=((C_word*)t0)[5],a[10]=t9,a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t2)){
t16=C_u_i_cdr(t6);
if(C_truep(C_u_i_car(t16))){
t17=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9990,a[2]=t15,a[3]=t14,a[4]=t3,a[5]=t9,a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm:1344: get */
t18=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t18+1)))(5,t18,t17,((C_word*)t0)[8],t2,lf[79]);}
else{
t17=t15;
f_9878(2,t17,C_SCHEME_FALSE);}}
else{
t16=t15;
f_9878(2,t16,C_SCHEME_FALSE);}}
else{
t13=C_eqp(t11,lf[13]);
if(C_truep(t13)){
t14=C_i_car(t6);
t15=C_i_car(t9);
/* optimizer.scm:1358: walk */
t31=t1;
t32=t14;
t33=t15;
t34=C_SCHEME_FALSE;
t1=t31;
t2=t32;
t3=t33;
t4=t34;
goto loop;}
else{
t14=C_eqp(t11,lf[6]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10016,a[2]=t9,a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t16=C_i_car(t6);
t17=C_i_car(t9);
/* optimizer.scm:1360: walk */
t31=t15;
t32=t16;
t33=t17;
t34=t3;
t1=t31;
t2=t32;
t3=t33;
t4=t34;
goto loop;}
else{
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10032,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t16=C_i_check_list_2(t9,lf[2]);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10044,a[2]=t18,a[3]=t15,tmp=(C_word)a,a+=4,tmp));
t20=((C_word*)t18)[1];
f_10044(t20,t1,t9);}}}}

/* map-loop1719 in k8099 in k8091 in k8088 in k8056 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_8183(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8183,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8212,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:1038: g1725 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k12147 in k12143 in loop in k12103 in a12096 in k12167 in k12175 in k12179 in k11933 in descend in k11774 in k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in ... */
static void C_ccall f_12149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12149,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[14],lf[6],((C_word*)t0)[4],t2));}

/* k12143 in loop in k12103 in a12096 in k12167 in k12175 in k12179 in k11933 in descend in k11774 in k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in ... */
static void C_ccall f_12145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12145,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12149,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[4];
t5=C_u_i_cdr(t4);
t6=((C_word*)t0)[5];
t7=C_u_i_cdr(t6);
/* optimizer.scm:1725: loop */
t8=((C_word*)((C_word*)t0)[6])[1];
f_12115(t8,t3,t5,t7);}

/* ##compiler#transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9835(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9835,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_fix(0);
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9838,a[2]=t17,a[3]=t7,a[4]=t9,a[5]=t11,a[6]=t13,a[7]=t15,a[8]=t3,tmp=(C_word)a,a+=9,tmp));
t19=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10073,a[2]=t11,a[3]=t3,a[4]=t9,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t20=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10545,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11275,a[2]=t1,a[3]=t5,a[4]=t13,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:1556: debugging */
t22=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t22+1)))(4,t22,t21,lf[28],lf[185]);}

/* k6736 in k6484 in k6464 in perform-pre-optimization! in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6738,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=C_i_check_list_2(t2,lf[2]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6749,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_6749(t7,((C_word*)t0)[3],t2);}

/* k3999 in k3996 in k3993 in scan-toplevel-assignments in k3676 in k3673 in k3670 */
static void C_ccall f_4001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4001,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[2])[1];
t3=C_i_check_list_2(t2,lf[2]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4028,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_4028(t7,((C_word*)t0)[3],t2);}

/* a12554 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_12555(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr10,(void*)f_12555,10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}
if(C_truep(*((C_word*)lf[143]+1))){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12575,a[2]=t6,a[3]=t7,a[4]=t8,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:786: varnode */
t11=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,t9);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k8752 in k8730 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_8754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8754,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[3],t1));}

/* k8756 in k8730 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_8758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1132: cons* */
t2=*((C_word*)lf[151]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k5150 in k5147 in k5126 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_5152(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5152,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5190,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5192,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=C_u_i_cdr(((C_word*)t0)[6]);
/* optimizer.scm:344: any */
t5=*((C_word*)lf[37]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}
else{
t2=((C_word*)t0)[2];
f_5107(t2,C_SCHEME_FALSE);}}

/* k6720 in g976 in k6484 in k6464 in perform-pre-optimization! in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_6505(2,t2,C_SCHEME_FALSE);}
else{
/* optimizer.scm:565: test */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6459(t2,((C_word*)t0)[2],((C_word*)t0)[4],lf[49]);}}

/* k10575 in k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10577,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_10580,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t2,a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* optimizer.scm:1457: cdaddr */
t4=*((C_word*)lf[178]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_10573(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10573,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_u_i_car(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_10577,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* optimizer.scm:1456: caaddr */
t4=*((C_word*)lf[179]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
/* optimizer.scm:1554: bomb */
t2=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[8],lf[180],((C_word*)t0)[2]);}}

/* for-each-loop110 in k3999 in k3996 in k3993 in scan-toplevel-assignments in k3676 in k3673 in k3670 */
static void C_fcall f_4028(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4028,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4038,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_SCHEME_END_OF_LIST;
if(C_truep(C_i_nullp(t5))){
/* tweaks.scm:54: ##sys#put! */
t6=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t3,t4,lf[24],C_SCHEME_TRUE);}
else{
t6=C_i_car(t5);
/* tweaks.scm:54: ##sys#put! */
t7=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t3,t4,lf[24],t6);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5147 in k5126 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5149,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5152,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_5152(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5217,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t4=C_u_i_car(((C_word*)t0)[7]);
/* optimizer.scm:342: test */
t5=((C_word*)((C_word*)t0)[8])[1];
f_4069(t5,t3,t4,lf[78]);}}

/* for-each-loop1394 in k6912 in k6852 in k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_7143(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7143,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7153,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:857: g1395 */
t5=((C_word*)t0)[3];
f_6915(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4387 in a4378 in k4368 in k4290 in walk in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_4389(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4389,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4393,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:199: lset-adjoin */
t3=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[27]+1),*((C_word*)lf[39]+1),((C_word*)t0)[3]);}

/* k7151 in for-each-loop1394 in k6912 in k6852 in k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_7153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7143(t3,((C_word*)t0)[4],t2);}

/* k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_5275(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5275,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[2],C_fix(2));
t3=t2;
t4=C_i_caddr(t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_5291,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[2],a[15]=t5,a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],tmp=(C_word)a,a+=22,tmp);
/* optimizer.scm:359: decompose-lambda-list */
t7=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[20],t5,t6);}
else{
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5815,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[20],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],a[12]=((C_word*)t0)[7],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=C_slot(((C_word*)t0)[2],C_fix(1));
t4=C_eqp(lf[3],t3);
if(C_truep(t4)){
t5=C_slot(((C_word*)t0)[2],C_fix(2));
t6=C_i_car(t5);
/* tweaks.scm:51: ##sys#get */
t7=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t2,t6,lf[46]);}
else{
t5=t2;
f_5815(2,t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_5815(2,t3,C_SCHEME_FALSE);}}}

/* g354 in k4529 in k4523 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_4580(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4580,NULL,3,t0,t1,t2);}
t3=C_i_cdr(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4590,a[2]=t1,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4615,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* tweaks.scm:57: ##sys#get */
t7=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t4,lf[54]);}
else{
t6=t5;
f_4590(t6,C_SCHEME_FALSE);}}

/* k5159 in k5188 in k5150 in k5147 in k5126 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5161,2,t0,t1);}
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=C_a_i_record4(&a,4,lf[14],lf[15],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t4=C_a_i_list2(&a,2,((C_word*)t0)[2],t3);
t5=((C_word*)t0)[3];
f_5107(t5,C_a_i_record4(&a,4,lf[14],lf[12],t2,t4));}

/* for-each-loop1370 in k6852 in k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_7166(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7166,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7176,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:844: g1371 */
t5=((C_word*)t0)[3];
f_6855(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4057 in k3996 in k3993 in scan-toplevel-assignments in k3676 in k3673 in k3670 */
static void C_ccall f_4059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:111: debugging */
t2=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[18],lf[25],t1);}

/* k7174 in for-each-loop1370 in k6852 in k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_7176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7166(t3,((C_word*)t0)[4],t2);}

/* a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5291(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5291,5,t0,t1,t2,t3,t4);}
t5=C_i_car(((C_word*)t0)[2]);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_5809,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=t1,a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[2],a[19]=t6,a[20]=t3,a[21]=((C_word*)t0)[18],a[22]=((C_word*)t0)[19],a[23]=((C_word*)t0)[20],a[24]=t2,a[25]=((C_word*)t0)[21],tmp=(C_word)a,a+=26,tmp);
/* tweaks.scm:57: ##sys#get */
t8=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)t0)[17],lf[98]);}

/* test in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_4069(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4069,NULL,4,t0,t1,t2,t3);}
/* optimizer.scm:142: get */
t4=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* ##compiler#perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4066(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word ab[86],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4066,4,t0,t1,t2,t3);}
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_fix(0);
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_FALSE;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_SCHEME_UNDEFINED;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_SCHEME_UNDEFINED;
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_SCHEME_UNDEFINED;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_SCHEME_UNDEFINED;
t29=(*a=C_VECTOR_TYPE|1,a[1]=t28,tmp=(C_word)a,a+=2,tmp);
t30=C_SCHEME_UNDEFINED;
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=C_SCHEME_UNDEFINED;
t33=(*a=C_VECTOR_TYPE|1,a[1]=t32,tmp=(C_word)a,a+=2,tmp);
t34=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4069,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t35=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4075,tmp=(C_word)a,a+=2,tmp));
t36=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4105,a[2]=t15,tmp=(C_word)a,a+=3,tmp));
t37=C_set_block_item(t23,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4109,tmp=(C_word)a,a+=2,tmp));
t38=C_set_block_item(t25,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4146,a[2]=t13,a[3]=t21,a[4]=t25,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t39=C_set_block_item(t27,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4278,a[2]=t15,a[3]=t25,a[4]=t7,a[5]=t21,a[6]=t27,a[7]=t19,a[8]=t31,tmp=(C_word)a,a+=9,tmp));
t40=C_set_block_item(t29,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4471,a[2]=t3,a[3]=t29,a[4]=t17,tmp=(C_word)a,a+=5,tmp));
t41=C_set_block_item(t31,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4491,a[2]=t21,a[3]=t17,a[4]=t9,a[5]=t29,a[6]=t5,a[7]=t27,a[8]=t33,a[9]=t3,a[10]=t23,a[11]=t11,tmp=(C_word)a,a+=12,tmp));
t42=C_set_block_item(t33,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6267,a[2]=t23,a[3]=t27,tmp=(C_word)a,a+=4,tmp));
t43=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6332,a[2]=t1,a[3]=t2,a[4]=t15,a[5]=t7,a[6]=t5,a[7]=t9,a[8]=t13,a[9]=t27,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm:518: perform-pre-optimization! */
t44=*((C_word*)lf[119]+1);
f_6452(4,t44,t43,t2,t3);}

/* k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4063,2,t0,t1);}
t2=C_mutate2((C_word*)lf[30]+1 /* (set! ##compiler#simplifications ...) */,t1);
t3=C_set_block_item(lf[31] /* ##compiler#simplified-ops */,0,C_SCHEME_END_OF_LIST);
t4=C_mutate2((C_word*)lf[32]+1 /* (set! ##compiler#perform-high-level-optimizations ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4066,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate2((C_word*)lf[119]+1 /* (set! ##compiler#perform-pre-optimization! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6452,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate2((C_word*)lf[128]+1 /* (set! register-simplifications ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6772,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6779,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=C_a_i_list(&a,1,lf[193]);
t9=C_a_i_list(&a,2,lf[3],t8);
t10=C_a_i_cons(&a,2,lf[227],lf[228]);
t11=C_a_i_cons(&a,2,t9,t10);
t12=C_a_i_cons(&a,2,lf[223],t11);
t13=C_a_i_cons(&a,2,lf[12],t12);
t14=C_a_i_list(&a,4,lf[193],lf[227],lf[228],lf[223]);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13387,tmp=(C_word)a,a+=2,tmp);
t16=C_a_i_list(&a,3,t13,t14,t15);
t17=C_a_i_list(&a,1,t16);
/* optimizer.scm:604: ##sys#hash-table-set! */
t18=*((C_word*)lf[129]+1);
((C_proc5)(void*)(*((C_word*)t18+1)))(5,t18,t7,*((C_word*)lf[30]+1),lf[12],t17);}

/* for-each-loop1330 in k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_7189(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7189,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7199,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
/* optimizer.scm:826: g1331 */
t9=((C_word*)t0)[3];
f_6842(t9,t6,t7,t8);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k12439 in a12418 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_12441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12441,2,t0,t1);}
t2=t1;
t3=C_i_cdr(((C_word*)t0)[2]);
t4=C_a_i_list1(&a,1,t3);
t5=t4;
t6=C_a_i_list1(&a,1,t2);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12477,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12479,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12521,a[2]=t8,a[3]=t9,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:818: qnode */
t11=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,C_SCHEME_FALSE);}

/* k5995 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5997,2,t0,t1);}
t2=C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5984,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:468: invalidate-gae! */
f_4109(t4,((C_word*)t0)[5]);}

/* map-loop808 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_5999(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5999,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6028,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:467: g814 */
t5=((C_word*)t0)[5];
f_5990(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* for-each-loop2446 in k10654 in k10587 in k10584 in k10578 in k10575 in k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_10823(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10823,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10833,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:1516: g2447 */
t5=((C_word*)t0)[3];
f_10590(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g814 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_5990(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5990,NULL,3,t0,t1,t2);}
/* optimizer.scm:467: g831 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4278(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k6060 in k6054 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6062,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record4(&a,4,lf[14],lf[15],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}

/* for-each-loop2656 in walk in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_11595(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11595,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11605,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:1639: g2657 */
t5=((C_word*)t0)[3];
f_11583(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* a12418 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_12419(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_12419,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=C_i_assoc(t4,*((C_word*)lf[207]+1));
t10=t9;
if(C_truep(t10)){
if(C_truep(C_i_listp(t6))){
t11=C_i_length(t6);
if(C_truep(C_i_lessp(t11,*((C_word*)lf[208]+1)))){
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12441,a[2]=t10,a[3]=t7,a[4]=t8,a[5]=t3,a[6]=t5,a[7]=t1,a[8]=t6,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm:801: gensym */
t13=*((C_word*)lf[87]+1);
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}

/* k6071 in k6054 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6073,2,t0,t1);}
if(C_truep(t1)){
/* optimizer.scm:477: debugging */
t2=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[80],lf[103],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[4];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record4(&a,4,lf[14],lf[15],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}}

/* a4160 in k4148 in simplify in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4161(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4161,3,t0,t1,t2);}
t3=C_i_cadr(t2);
t4=t3;
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4171,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t4,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t6=t2;
t7=C_u_i_car(t6);
/* optimizer.scm:154: match-node */
t8=*((C_word*)lf[36]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t5,((C_word*)t0)[6],t7,t4);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k10284 in rec in scan in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10286,2,t0,t1);}
t2=C_i_zerop(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10292,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_10292(t4,t2);}
else{
t4=((C_word*)((C_word*)t0)[6])[1];
if(C_truep(t4)){
t5=t3;
f_10292(t5,C_SCHEME_FALSE);}
else{
t5=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[7])[1],t1);
t6=C_mutate2(((C_word *)((C_word*)t0)[7])+1,t5);
t7=t3;
f_10292(t7,C_SCHEME_TRUE);}}}

/* k7623 in a7603 in k7597 in k7588 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_7625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7625,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
t3=C_a_i_list2(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t4=((C_word*)t0)[4];
t5=t4;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[14],lf[6],t2,t3));}

/* a11563 in a11550 in walk in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_11564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11564,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[2]);
/* optimizer.scm:1635: walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_11343(t3,t1,t2,((C_word*)t0)[4]);}

/* k6080 in k6054 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6082,2,t0,t1);}
if(C_truep(t1)){
t2=f_4105(((C_word*)((C_word*)t0)[2])[1]);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[14],lf[15],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6099,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6250,a[2]=t2,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:482: test */
t4=((C_word*)((C_word*)t0)[7])[1];
f_4069(t4,t3,((C_word*)t0)[4],lf[56]);}}

/* for-each-loop925 in k6388 in a6385 in k6343 in k6340 in k6336 in k6330 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_6423(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6423,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6433,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6395,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=C_i_car(t6);
/* optimizer.scm:532: print* */
t9=*((C_word*)lf[113]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,lf[114],t8);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* a11573 in a11550 in walk in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_11574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11574,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[5])[1]);
t4=C_mutate2(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[6])[1]);
t5=C_mutate2(((C_word *)((C_word*)t0)[5])+1,((C_word*)((C_word*)t0)[7])[1]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}

/* k5249 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_5128(2,t2,C_SCHEME_FALSE);}
else{
/* optimizer.scm:338: test */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4069(t2,((C_word*)t0)[2],((C_word*)t0)[4],lf[49]);}}

/* k6097 in k6080 in k6054 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_6099(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6099,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_4105(((C_word*)((C_word*)t0)[2])[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6105,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:488: debugging */
t4=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[18],lf[104],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6198,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[8]);
/* optimizer.scm:491: walk */
t4=((C_word*)((C_word*)t0)[9])[1];
f_4278(t4,t2,t3,((C_word*)t0)[10],((C_word*)t0)[6]);}}

/* touch in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static C_word C_fcall f_4105(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_overflow_check;
t1=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
return(t1);}

/* invalidate-gae! in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_4109(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4109,NULL,2,t1,t2);}
t3=C_i_check_list_2(t2,lf[2]);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4123,tmp=(C_word)a,a+=2,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_4123(t2));}

/* a7603 in k7597 in k7588 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_7604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7604,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7625,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:966: gensym */
t5=*((C_word*)lf[87]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k8151 in k8105 in k8099 in k8091 in k8088 in k8056 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_8153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8153,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[3],t2);
/* optimizer.scm:1039: fold-right */
t4=*((C_word*)lf[137]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,((C_word*)t0)[4],((C_word*)t0)[5],t3,((C_word*)t0)[6],((C_word*)t0)[7]);}

/* a8154 in k8105 in k8099 in k8091 in k8088 in k8056 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_8155(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8155,4,t0,t1,t2,t3);}
t4=C_a_i_list2(&a,2,t2,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[14],lf[144],((C_word*)t0)[2],t4));}

/* k4151 in k4148 in simplify in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k4148 in simplify in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4150,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4153,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4161,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:152: any */
t4=*((C_word*)lf[37]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}
else{
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g2187 in walk in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_10032(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10032,NULL,3,t0,t1,t2);}
/* optimizer.scm:1362: walk */
t3=((C_word*)((C_word*)t0)[2])[1];
f_9838(t3,t1,C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}

/* a11556 in a11550 in walk in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_11557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11557,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[5])[1]);
t4=C_mutate2(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[6])[1]);
t5=C_mutate2(((C_word *)((C_word*)t0)[5])+1,((C_word*)((C_word*)t0)[7])[1]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}

/* a11550 in walk in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_11551(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11551,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11557,a[2]=t10,a[3]=((C_word*)t0)[2],a[4]=t12,a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11564,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11574,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t8,a[5]=((C_word*)t0)[3],a[6]=t10,a[7]=t12,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:1631: ##sys#dynamic-wind */
t16=*((C_word*)lf[187]+1);
((C_proc5)(void*)(*((C_word*)t16+1)))(5,t16,t1,t13,t14,t15);}

/* k7756 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_7758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7758,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_length(((C_word*)t0)[2]);
t3=C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=C_i_caddr(((C_word*)t0)[3]);
t5=C_i_not(t4);
t6=(C_truep(t5)?t5:C_eqp(t4,*((C_word*)lf[146]+1)));
if(C_truep(t6)){
t7=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t8=t7;
t9=((C_word*)t0)[3];
t10=C_u_i_car(t9);
t11=C_a_i_list1(&a,1,t10);
t12=t11;
t13=C_i_car(((C_word*)t0)[2]);
t14=t13;
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7817,a[2]=t14,a[3]=t12,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t8,tmp=(C_word)a,a+=7,tmp);
t16=((C_word*)t0)[3];
t17=C_u_i_cdr(t16);
t18=C_u_i_car(t17);
/* optimizer.scm:995: qnode */
t19=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t19+1)))(3,t19,t15,t18);}
else{
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k11273 in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_11275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11275,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11278,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1557: walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_9838(t3,t2,C_SCHEME_FALSE,((C_word*)t0)[5],C_SCHEME_FALSE);}

/* k11276 in k11273 in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_11278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[3])[1]);}

/* k6943 in a6931 in k6920 in g1395 in k6912 in k6852 in k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_u_i_car(t2));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3790 in scan in scan-toplevel-assignments in k3676 in k3673 in k3670 */
static void C_fcall f_3792(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3792,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3796,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3798,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:72: remove */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a3797 in k3790 in scan in scan-toplevel-assignments in k3676 in k3673 in k3670 */
static void C_ccall f_3798(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3798,3,t0,t1,t2);}
t3=C_i_car(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_eqp(t3,((C_word*)t0)[2]));}

/* k3794 in k3790 in scan in scan-toplevel-assignments in k3676 in k3673 in k3670 */
static void C_ccall f_3796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4523 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4525,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4531,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm:231: test */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4069(t4,t3,t2,lf[55]);}

/* a6931 in k6920 in g1395 in k6912 in k6852 in k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6932(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6932,3,t0,t1,t2);}
t3=C_eqp(t2,((C_word*)t0)[2]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6945,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_i_cdr(t2);
/* optimizer.scm:869: lset<= */
t6=*((C_word*)lf[133]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,*((C_word*)lf[27]+1),t5,((C_word*)t0)[3]);}}

/* close in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static C_word C_fcall f_11283(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_stack_overflow_check;
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t1=C_i_length(((C_word*)((C_word*)t0)[2])[1]);
if(C_truep(C_fixnum_greaterp(t1,C_fix(1)))){
t2=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]),((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t2);
t4=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_END_OF_LIST);
t5=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_FALSE);
return(t5);}
else{
t2=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_END_OF_LIST);
t3=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_FALSE);
return(t3);}}
else{
t1=C_SCHEME_UNDEFINED;
return(t1);}}

/* k6928 in k6920 in g1395 in k6912 in k6852 in k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6930,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1),((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k4175 in k4169 in a4160 in k4148 in simplify in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4177,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_caar(((C_word*)t0)[2]);
t3=C_i_assq(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t3)){
t4=C_i_cdr(t3);
t5=C_a_i_plus(&a,2,t4,C_fix(1));
t6=C_i_set_cdr(t3,t5);
t7=f_4105(((C_word*)((C_word*)t0)[4])[1]);
/* optimizer.scm:163: simplify */
t8=((C_word*)((C_word*)t0)[5])[1];
f_4146(t8,((C_word*)t0)[6],t1);}
else{
t4=C_a_i_cons(&a,2,C_a_i_cons(&a,2,t2,C_fix(1)),((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t4);
t6=f_4105(((C_word*)((C_word*)t0)[4])[1]);
/* optimizer.scm:163: simplify */
t7=((C_word*)((C_word*)t0)[5])[1];
f_4146(t7,((C_word*)t0)[6],t1);}}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4169 in a4160 in k4148 in simplify in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4171,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4177,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=C_i_caddr(((C_word*)t0)[2]);
t5=t4;
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4216,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t11=C_i_check_list_2(((C_word*)t0)[7],lf[35]);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4230,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4232,a[2]=t10,a[3]=t9,a[4]=t14,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_4232(t16,t12,((C_word*)t0)[7]);}
else{
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* ##compiler#determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_11280(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11280,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11283,a[2]=t9,a[3]=t7,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t15=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11343,a[2]=t7,a[3]=t13,a[4]=t9,a[5]=t11,a[6]=t3,tmp=(C_word)a,a+=7,tmp));
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11628,a[2]=t3,a[3]=t5,a[4]=t1,a[5]=t2,a[6]=t13,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:1641: debugging */
t17=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t17+1)))(4,t17,t16,lf[28],lf[197]);}

/* for-each-loop2186 in walk in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_10044(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10044,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10054,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:1362: g2187 */
t5=((C_word*)t0)[3];
f_10032(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4535 in k4529 in k4523 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4537,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4557,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:234: test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4069(t3,t2,((C_word*)t0)[4],lf[49]);}

/* simplify in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_4146(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4146,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4150,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=t2;
t5=C_slot(t4,C_fix(1));
/* optimizer.scm:151: ##sys#hash-table-ref */
t6=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,*((C_word*)lf[30]+1),t5);}

/* k4529 in k4523 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4531,2,t0,t1);}
if(C_truep(t1)){
t2=f_4105(((C_word*)((C_word*)t0)[2])[1]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4537,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:233: debugging */
t4=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[18],lf[50],((C_word*)t0)[5]);}
else{
t2=C_u_i_car(((C_word*)t0)[6]);
t3=C_eqp(((C_word*)t0)[5],t2);
if(C_truep(t3)){
t4=C_i_assq(((C_word*)t0)[5],((C_word*)t0)[7]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4580,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:230: g354 */
t6=t5;
f_4580(t6,((C_word*)t0)[3],t4);}
else{
/* optimizer.scm:247: varnode */
t5=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,((C_word*)t0)[3],((C_word*)t0)[5]);}}
else{
t4=f_4105(((C_word*)((C_word*)t0)[2])[1]);
t5=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[8])[1],C_fix(1));
t6=C_mutate2(((C_word *)((C_word*)t0)[8])+1,t5);
/* optimizer.scm:238: varnode */
t7=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,((C_word*)t0)[3],((C_word*)t0)[5]);}}}

/* g2657 in walk in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_11583(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11583,NULL,3,t0,t1,t2);}
/* optimizer.scm:1639: g2672 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_11343(t3,t1,t2,((C_word*)t0)[3]);}

/* lp in walk-generic in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_6273(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6273,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_nullp(t3))){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6283,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
/* optimizer.scm:510: invalidate-gae! */
f_4109(t5,((C_word*)t0)[7]);}
else{
t6=t5;
f_6283(2,t6,C_SCHEME_UNDEFINED);}}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6304,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[8],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=C_i_car(t3);
/* optimizer.scm:514: walk */
t7=((C_word*)((C_word*)t0)[9])[1];
f_4278(t7,t5,t6,((C_word*)t0)[10],((C_word*)t0)[7]);}}

/* k9577 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9579,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_caddr(((C_word*)t0)[2]);
t3=(C_truep(t2)?t2:*((C_word*)lf[145]+1));
if(C_truep(t3)){
t4=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t5=t4;
t6=C_eqp(*((C_word*)lf[146]+1),lf[147]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9627,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:1285: fifth */
t8=*((C_word*)lf[154]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t0)[2]);}
else{
t7=C_i_cadr(((C_word*)t0)[2]);
t8=C_a_i_list2(&a,2,t7,((C_word*)t0)[6]);
t9=((C_word*)t0)[3];
t10=C_a_i_record4(&a,4,lf[14],lf[92],t8,t9);
t11=C_a_i_list2(&a,2,((C_word*)t0)[4],t10);
t12=((C_word*)t0)[5];
t13=t12;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_a_i_record4(&a,4,lf[14],lf[12],t5,t11));}}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k10052 in for-each-loop2186 in walk in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10044(t3,((C_word*)t0)[4],t2);}

/* k6281 in lp in walk-generic in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6283,2,t0,t1);}
if(C_truep(((C_word*)t0)[2])){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6298,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:512: reverse */
t3=*((C_word*)lf[107]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}}

/* k10831 in for-each-loop2446 in k10654 in k10587 in k10584 in k10578 in k10575 in k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10823(t3,((C_word*)t0)[4],t2);}

/* k6898 in a6886 in g1371 in k6852 in k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm:850: find-path */
t2=((C_word*)t0)[2];
f_6799(t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4555 in k4535 in k4529 in k4523 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(t1,C_fix(2));
t3=C_i_car(t2);
/* optimizer.scm:234: qnode */
t4=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* scan in scan-toplevel-assignments in k3676 in k3673 in k3670 */
static void C_fcall f_3755(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3755,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=C_slot(t4,C_fix(2));
t6=t5;
t7=t2;
t8=C_slot(t7,C_fix(3));
t9=t8;
t10=t2;
t11=C_slot(t10,C_fix(1));
t12=t11;
t13=C_eqp(t12,lf[3]);
if(C_truep(t13)){
t14=C_i_car(t6);
t15=t14;
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3792,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t15,tmp=(C_word)a,a+=5,tmp);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3809,a[2]=t15,a[3]=((C_word*)t0)[3],a[4]=t16,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_memq(t15,t3))){
t18=t17;
f_3809(t18,C_SCHEME_FALSE);}
else{
t18=C_i_memq(t15,((C_word*)((C_word*)t0)[3])[1]);
t19=t17;
f_3809(t19,C_i_not(t18));}}
else{
t14=C_eqp(t12,lf[5]);
t15=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3836,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t9,a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=t3,a[8]=t12,a[9]=t6,a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=t2,a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[3],tmp=(C_word)a,a+=15,tmp);
if(C_truep(t14)){
t16=t15;
f_3836(t16,t14);}
else{
t16=C_eqp(t12,lf[21]);
t17=t15;
f_3836(t17,(C_truep(t16)?t16:C_eqp(t12,lf[22])));}}}

/* k5931 in k5901 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5933,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_5016(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5916,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_slot(((C_word*)t0)[3],C_fix(2));
t4=C_i_car(t3);
/* optimizer.scm:319: test */
t5=((C_word*)((C_word*)t0)[4])[1];
f_4069(t5,t2,t4,lf[70]);}}

/* k3670 */
static void C_ccall f_3672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3672,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3675,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k5937 in k5947 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
f_5009(2,t3,t2);}
else{
/* optimizer.scm:314: test */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4069(t2,((C_word*)t0)[2],((C_word*)t0)[4],lf[101]);}}

/* k3676 in k3673 in k3670 */
static void C_ccall f_3678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3678,2,t0,t1);}
t2=C_mutate2((C_word*)lf[0]+1 /* (set! ##compiler#scan-toplevel-assignments ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3680,tmp=(C_word)a,a+=2,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4063,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:131: make-vector */
t4=*((C_word*)lf[198]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k3673 in k3670 */
static void C_ccall f_3675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3678,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_chicken_2dsyntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k12179 in k11933 in descend in k11774 in k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 in ... */
static void C_ccall f_12181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12181,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
t3=t2;
t4=C_a_i_list1(&a,1,((C_word*)t0)[2]);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_12177,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[2],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
/* optimizer.scm:1707: gensym */
t7=*((C_word*)lf[87]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[190]);}

/* k12175 in k12179 in k11933 in descend in k11774 in k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in ... */
static void C_ccall f_12177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12177,2,t0,t1);}
t2=C_a_i_list4(&a,4,t1,C_SCHEME_TRUE,((C_word*)t0)[2],C_fix(0));
t3=t2;
t4=C_a_i_minus(&a,2,((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t5=C_a_i_list1(&a,1,t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12074,a[2]=t6,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12169,a[2]=((C_word*)t0)[9],a[3]=t7,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:1714: varnode */
t9=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,((C_word*)t0)[13]);}

/* remember in scan-toplevel-assignments in k3676 in k3673 in k3670 */
static void C_fcall f_3706(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3706,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3711,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:53: alist-update! */
t5=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* walk in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_4278(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4278,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_memq(t2,*((C_word*)lf[39]+1)))){
t5=t2;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=((C_word*)((C_word*)t0)[2])[1];
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4292,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=t4,a[9]=t5,a[10]=((C_word*)t0)[2],a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm:172: walk1 */
t7=((C_word*)((C_word*)t0)[8])[1];
f_4491(t7,t6,t2,t3,t4);}}

/* k6296 in k6281 in lp in walk-generic in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6298,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[4];
t5=t2;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[14],t3,t4,t1));}

/* k3688 in mark in scan-toplevel-assignments in k3676 in k3673 in k3670 */
static void C_fcall f_3690(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3690,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k10014 in walk in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm:1361: walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9838(t3,((C_word*)t0)[4],C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}

/* k11267 in a11251 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_11269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11269,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
/* optimizer.scm:1446: ##sys#make-promise */
t3=*((C_word*)lf[183]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_10545(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10545,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10549,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t7,a[5]=t3,a[6]=t6,a[7]=t5,a[8]=t1,a[9]=t4,a[10]=((C_word*)t0)[3],tmp=(C_word)a,a+=11,tmp);
if(C_truep(C_i_pairp(t5))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11250,a[2]=t8,a[3]=t3,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11252,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:1446: ##sys#make-promise */
t11=*((C_word*)lf[183]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t9,t10);}
else{
/* optimizer.scm:1447: debugging */
t9=*((C_word*)lf[17]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t8,lf[18],lf[184],t3,t7);}}

/* k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10549,2,t0,t1);}
t2=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[3];
t4=C_slot(t3,C_fix(2));
t5=t4;
t6=C_i_caddr(t5);
t7=C_i_length(t6);
t8=t7;
t9=C_SCHEME_END_OF_LIST;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10564,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t8,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[3],a[10]=t10,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm:1452: get */
t12=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t12+1)))(5,t12,t11,((C_word*)t0)[10],((C_word*)t0)[5],lf[126]);}

/* g43 in scan-each in scan-toplevel-assignments in k3676 in k3673 in k3670 */
static void C_fcall f_3720(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3720,NULL,3,t0,t1,t2);}
/* optimizer.scm:60: scan */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3755(t3,t1,t2,((C_word*)t0)[3]);}

/* ##compiler#scan-toplevel-assignments in k3676 in k3673 in k3670 */
static void C_ccall f_3680(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word ab[48],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3680,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_END_OF_LIST;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3683,a[2]=t4,a[3]=t8,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t22=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3706,a[2]=t10,tmp=(C_word)a,a+=3,tmp));
t23=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3713,a[2]=t8,a[3]=t10,tmp=(C_word)a,a+=4,tmp));
t24=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3718,a[2]=t20,tmp=(C_word)a,a+=3,tmp));
t25=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3755,a[2]=t10,a[3]=t6,a[4]=t16,a[5]=t20,a[6]=t18,a[7]=t14,a[8]=t12,tmp=(C_word)a,a+=9,tmp));
t26=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3995,a[2]=t4,a[3]=t1,a[4]=t20,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:108: debugging */
t27=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t27+1)))(4,t27,t26,lf[28],lf[29]);}

/* k5947 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5949,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_5009(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:313: test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4069(t3,t2,((C_word*)t0)[4],lf[49]);}}

/* k10541 in k10534 in scan in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1442: lset= */
t2=*((C_word*)lf[165]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],*((C_word*)lf[27]+1),((C_word*)((C_word*)t0)[3])[1],t1);}

/* mark in scan-toplevel-assignments in k3676 in k3673 in k3670 */
static void C_fcall f_3683(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3683,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3690,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=t3;
f_3690(t5,C_SCHEME_FALSE);}
else{
t5=C_i_memq(t2,((C_word*)((C_word*)t0)[4])[1]);
t6=t3;
f_3690(t6,C_i_not(t5));}}

/* k6237 in k6206 in k6248 in k6080 in k6054 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6239,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_6099(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6235,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:485: test */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4069(t3,t2,((C_word*)t0)[6],lf[78]);}}

/* walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_4491(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4491,NULL,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=C_slot(t5,C_fix(3));
t7=t6;
t8=t2;
t9=C_slot(t8,C_fix(2));
t10=t9;
t11=t2;
t12=C_slot(t11,C_fix(1));
t13=t12;
t14=C_eqp(t13,lf[3]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4525,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t10,a[6]=t4,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t16=C_i_car(t10);
/* optimizer.scm:230: replace-var */
t17=((C_word*)((C_word*)t0)[5])[1];
f_4471(t17,t15,t16);}
else{
t15=C_eqp(t13,lf[6]);
if(C_truep(t15)){
t16=C_i_car(t10);
t17=t16;
t18=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4646,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t7,a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=t3,a[8]=t4,a[9]=t10,a[10]=t17,a[11]=((C_word*)t0)[3],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm:251: test */
t19=((C_word*)((C_word*)t0)[3])[1];
f_4069(t19,t18,t17,lf[59]);}
else{
t16=C_eqp(t13,lf[11]);
if(C_truep(t16)){
t17=C_i_caddr(t10);
t18=t17;
t19=C_u_i_car(t10);
t20=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4802,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t10,a[5]=t7,a[6]=t19,a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=t18,a[11]=((C_word*)t0)[8],a[12]=t2,a[13]=t13,tmp=(C_word)a,a+=14,tmp);
/* optimizer.scm:269: test */
t21=((C_word*)((C_word*)t0)[3])[1];
f_4069(t21,t20,t19,lf[68]);}
else{
t17=C_eqp(t13,lf[69]);
if(C_truep(t17)){
/* optimizer.scm:302: walk-generic */
t18=((C_word*)((C_word*)t0)[8])[1];
f_6267(t18,t1,t2,t13,t10,t7,t3,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}
else{
t18=C_eqp(t13,lf[12]);
if(C_truep(t18)){
t19=C_i_car(t7);
t20=t19;
t21=C_slot(t20,C_fix(1));
t22=C_eqp(t21,lf[3]);
if(C_truep(t22)){
t23=C_slot(t20,C_fix(2));
t24=C_i_car(t23);
t25=t24;
t26=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_5006,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[9],a[5]=t3,a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=t4,a[9]=t25,a[10]=((C_word*)t0)[8],a[11]=t2,a[12]=t13,a[13]=t10,a[14]=((C_word*)t0)[3],a[15]=t20,a[16]=((C_word*)t0)[10],a[17]=((C_word*)t0)[11],tmp=(C_word)a,a+=18,tmp);
/* optimizer.scm:311: call-info */
t27=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t27+1)))(4,t27,t26,t10,t25);}
else{
t23=C_eqp(t21,lf[11]);
if(C_truep(t23)){
if(C_truep(C_i_car(t10))){
/* optimizer.scm:465: walk-generic */
t24=((C_word*)((C_word*)t0)[8])[1];
f_6267(t24,t1,t2,t13,t10,t7,t3,t4,C_SCHEME_FALSE);}
else{
t24=C_u_i_cdr(t10);
t25=C_a_i_cons(&a,2,C_SCHEME_TRUE,t24);
t26=t25;
t27=C_SCHEME_END_OF_LIST;
t28=(*a=C_VECTOR_TYPE|1,a[1]=t27,tmp=(C_word)a,a+=2,tmp);
t29=C_SCHEME_FALSE;
t30=(*a=C_VECTOR_TYPE|1,a[1]=t29,tmp=(C_word)a,a+=2,tmp);
t31=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5990,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t32=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5997,a[2]=t26,a[3]=t1,a[4]=((C_word*)t0)[10],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t33=C_SCHEME_UNDEFINED;
t34=(*a=C_VECTOR_TYPE|1,a[1]=t33,tmp=(C_word)a,a+=2,tmp);
t35=C_set_block_item(t34,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5999,a[2]=t30,a[3]=t34,a[4]=t28,a[5]=t31,tmp=(C_word)a,a+=6,tmp));
t36=((C_word*)t34)[1];
f_5999(t36,t32,t7);}}
else{
/* optimizer.scm:470: walk-generic */
t24=((C_word*)((C_word*)t0)[8])[1];
f_6267(t24,t1,t2,t13,t10,t7,t3,t4,C_SCHEME_TRUE);}}}
else{
t19=C_eqp(t13,lf[13]);
if(C_truep(t19)){
t20=C_i_car(t10);
t21=t20;
t22=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6056,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t21,a[5]=((C_word*)t0)[3],a[6]=t10,a[7]=t4,a[8]=t7,a[9]=((C_word*)t0)[7],a[10]=t3,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm:474: test */
t23=((C_word*)((C_word*)t0)[3])[1];
f_4069(t23,t22,t21,lf[58]);}
else{
/* optimizer.scm:503: walk-generic */
t20=((C_word*)((C_word*)t0)[8])[1];
f_6267(t20,t1,t2,t13,t10,t7,t3,t4,C_SCHEME_FALSE);}}}}}}}

/* k6233 in k6237 in k6206 in k6248 in k6080 in k6054 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6235,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_6099(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6227,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* optimizer.scm:486: expression-has-side-effects? */
t4=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[4]);}}

/* a13386 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_13387(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_13387,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13395,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t4,a[6]=t5,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:613: ##sys#hash-table-ref */
t8=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,*((C_word*)lf[140]+1),t3);}

/* g231 in k4169 in a4160 in k4148 in simplify in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static C_word C_fcall f_4216(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_overflow_check;
t2=C_i_assq(t1,((C_word*)t0)[2]);
return(C_i_cdr(t2));}

/* k6206 in k6248 in k6080 in k6054 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_6208(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6208,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6239,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:484: test */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4069(t3,t2,((C_word*)t0)[6],lf[105]);}
else{
t2=((C_word*)t0)[2];
f_6099(t2,C_SCHEME_FALSE);}}

/* k6248 in k6080 in k6054 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6250,2,t0,t1);}
t2=C_i_not(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6208,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_6208(t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6246,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:483: variable-visible? */
t5=*((C_word*)lf[106]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[6]);}}

/* scan-each in scan-toplevel-assignments in k3676 in k3673 in k3670 */
static void C_fcall f_3718(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3718,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3720,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_i_check_list_2(t2,lf[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3732,a[2]=t7,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_3732(t9,t1,t2);}

/* touch in scan-toplevel-assignments in k3676 in k3673 in k3670 */
static C_word C_fcall f_3713(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_stack_overflow_check;
t1=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_END_OF_LIST);
return(t2);}

/* k3709 in remember in scan-toplevel-assignments in k3676 in k3673 in k3670 */
static void C_ccall f_3711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k13393 in a13386 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_13395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13395,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13400,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_13400(t6,((C_word*)t0)[7],t2);}

/* k6244 in k6248 in k6080 in k6054 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6208(t2,C_i_not(t1));}

/* k13054 in k13060 in loop1 in a12726 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_13056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13056,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=C_i_car(((C_word*)t0)[3]);
t3=C_slot(t2,C_fix(2));
t4=t3;
t5=C_slot(t2,C_fix(3));
t6=t5;
t7=C_slot(t2,C_fix(1));
t8=C_eqp(t7,lf[15]);
if(C_truep(t8)){
t9=C_u_i_car(((C_word*)t0)[4]);
t10=C_a_i_cons(&a,2,t9,((C_word*)t0)[5]);
t11=C_i_cadr(((C_word*)t0)[3]);
/* optimizer.scm:708: loop1 */
t12=((C_word*)((C_word*)t0)[6])[1];
f_12737(t12,((C_word*)t0)[2],t10,t11);}
else{
t9=C_eqp(t7,lf[13]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12841,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:710: reverse */
t11=*((C_word*)lf[107]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,((C_word*)t0)[5]);}
else{
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}}}

/* map-loop225 in k4169 in a4160 in k4148 in simplify in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_4232(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4232,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=f_4216(((C_word*)t0)[2],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate2(((C_word *)((C_word*)t0)[5])+1,t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[5])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9286 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9288,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=t2;
t4=C_i_cadr(((C_word*)t0)[2]);
t5=C_a_i_list1(&a,1,t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9321,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9323,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9333,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:1231: ##sys#call-with-values */
C_call_with_values(4,0,t7,t8,t9);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4228 in k4169 in a4160 in k4148 in simplify in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k12167 in k12175 in k12179 in k11933 in descend in k11774 in k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in ... */
static void C_ccall f_12169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12169,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12082,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12097,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:1715: append-map */
t6=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[5]);}

/* k10534 in scan in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10536,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10543,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1442: delete */
t3=*((C_word*)lf[166]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[5])[1],*((C_word*)lf[27]+1));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* walk-generic in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_6267(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6267,NULL,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6273,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t8,a[6]=((C_word*)t0)[2],a[7]=t7,a[8]=t10,a[9]=((C_word*)t0)[3],a[10]=t6,tmp=(C_word)a,a+=11,tmp));
t12=((C_word*)t10)[1];
f_6273(t12,t1,C_SCHEME_TRUE,t5,C_SCHEME_END_OF_LIST);}

/* k10477 in rec in scan in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10479,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10490,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1436: append */
t5=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[5],((C_word*)t0)[6]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a10502 in rec in scan in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10503(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10503,3,t0,t1,t2);}
/* optimizer.scm:1437: rec */
t3=((C_word*)((C_word*)t0)[2])[1];
f_10076(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k5901 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5903,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5933,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:317: test */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4069(t3,t2,((C_word*)t0)[5],lf[57]);}
else{
t2=((C_word*)t0)[2];
f_5016(t2,C_SCHEME_FALSE);}}

/* k13030 in loop2 in k12839 in k13054 in k13060 in loop1 in a12726 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_13032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13032,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_12899(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13026,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_u_i_car(((C_word*)t0)[5]);
/* optimizer.scm:722: get */
t4=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[6],t3,lf[78]);}}

/* k5126 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5128,2,t0,t1);}
if(C_truep(t1)){
t2=C_slot(t1,C_fix(1));
t3=C_eqp(lf[11],t2);
if(C_truep(t3)){
t4=C_slot(t1,C_fix(2));
t5=C_i_caddr(t4);
t6=t5;
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5149,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t6,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t8=C_i_car(t6);
/* optimizer.scm:341: test */
t9=((C_word*)((C_word*)t0)[7])[1];
f_4069(t9,t7,t8,lf[60]);}
else{
t7=((C_word*)t0)[2];
f_5107(t7,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
f_5107(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
f_5107(t2,C_SCHEME_FALSE);}}

/* k4777 in k4644 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4779,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4786,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:253: test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4069(t3,t2,((C_word*)t0)[4],lf[57]);}
else{
t2=((C_word*)t0)[2];
f_4649(t2,C_SCHEME_FALSE);}}

/* k4784 in k4777 in k4644 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_4786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4649(t2,C_i_not(t1));}

/* k6920 in g1395 in k6912 in k6852 in k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6922,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6930,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6932,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:868: filter-map */
t5=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)((C_word*)t0)[6])[1]);}

/* k11401 in k11387 in walk in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_11403(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11403,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[5]);
/* optimizer.scm:1622: walk */
t5=((C_word*)((C_word*)t0)[6])[1];
f_11343(t5,((C_word*)t0)[7],((C_word*)t0)[8],t4);}
else{
t2=f_11283(C_a_i(&a,6),((C_word*)((C_word*)t0)[9])[1]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11420,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:1626: walk */
t4=((C_word*)((C_word*)t0)[6])[1];
f_11343(t4,t3,((C_word*)t0)[2],((C_word*)t0)[5]);}}

/* g1395 in k6912 in k6852 in k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_6915(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6915,NULL,3,t0,t1,t2);}
t3=C_i_car(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6922,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6956,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t7=t2;
t8=C_u_i_cdr(t7);
/* optimizer.scm:862: append-map */
t9=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t5,t6,t8);}

/* k6912 in k6852 in k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6914,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6915,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)((C_word*)t0)[2])[1];
t6=C_i_check_list_2(t5,lf[2]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6974,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7143,a[2]=t9,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t11=((C_word*)t9)[1];
f_7143(t11,t7,t5);}

/* k13408 in loop in k13393 in a13386 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_13410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13410,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13414,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:612: g1072 */
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_13414(C_a_i(&a,10),t2,t1));}
else{
t2=((C_word*)t0)[4];
t3=C_u_i_cdr(t2);
/* optimizer.scm:622: loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_13400(t4,((C_word*)t0)[3],t3);}}

/* g1072 in k13408 in loop in k13393 in a13386 in k4061 in k3676 in k3673 in k3670 */
static C_word C_fcall f_13414(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_stack_overflow_check;
t2=C_i_assq(((C_word*)t0)[2],*((C_word*)lf[31]+1));
if(C_truep(t2)){
t3=C_i_cdr(t2);
t4=C_a_i_plus(&a,2,t3,C_fix(1));
t5=C_i_set_cdr(t2,t4);
return(t1);}
else{
t3=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[2],C_fix(1)),*((C_word*)lf[31]+1));
t4=C_mutate2((C_word*)lf[31]+1 /* (set! ##compiler#simplified-ops ...) */,t3);
return(t1);}}

/* a12478 in k12439 in a12418 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_12479(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12479,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12513,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:815: varnode */
t5=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}

/* k6863 in g1371 in k6852 in k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6865,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6881,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:852: gensym */
t4=*((C_word*)lf[87]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k12475 in k12439 in a12418 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_12477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12477,2,t0,t1);}
t2=C_a_i_list3(&a,3,t1,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=((C_word*)t0)[4];
t4=C_a_i_record4(&a,4,lf[14],lf[5],t3,t2);
t5=C_a_i_list2(&a,2,((C_word*)t0)[5],t4);
t6=((C_word*)t0)[6];
t7=t6;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_record4(&a,4,lf[14],lf[6],((C_word*)t0)[7],t5));}

/* k10603 in g2447 in k10587 in k10584 in k10578 in k10575 in k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10605,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_a_i_list4(&a,4,C_SCHEME_TRUE,C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[4]);
t4=C_u_i_car(((C_word*)t0)[2]);
t5=C_u_i_cdr(((C_word*)t0)[2]);
t6=C_u_i_cdr(t5);
t7=C_a_i_cons(&a,2,t4,t6);
t8=C_a_i_record4(&a,4,lf[14],lf[164],t3,t7);
t9=C_a_i_list2(&a,2,t2,t8);
/* optimizer.scm:1524: node-subexpressions-set! */
t10=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,((C_word*)t0)[5],((C_word*)t0)[6],t9);}

/* k3807 in scan in scan-toplevel-assignments in k3676 in k3673 in k3670 */
static void C_fcall f_3809(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3809,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[4];
f_3792(t4,t3);}
else{
t2=((C_word*)t0)[4];
f_3792(t2,C_SCHEME_UNDEFINED);}}

/* k6871 in k6879 in k6863 in g1371 in k6852 in k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* loop in k13393 in a13386 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_13400(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13400,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13410,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=C_i_caar(t2);
t5=t2;
t6=C_u_i_car(t5);
t7=C_u_i_cdr(t6);
/* optimizer.scm:615: simplify-named-call */
t8=*((C_word*)lf[142]+1);
f_7299(9,t8,t3,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[2],((C_word*)t0)[6],t4,t7,((C_word*)t0)[7]);}}

/* k5914 in k5931 in k5901 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5016(t2,C_i_not(t1));}

/* k5215 in k5147 in k5126 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5217,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_5152(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5211,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_u_i_car(((C_word*)t0)[3]);
/* optimizer.scm:343: test */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4069(t4,t2,t3,lf[77]);}}

/* for-each-loop2408 in rec in k10584 in k10578 in k10575 in k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_11147(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11147,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11157,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:1511: g2409 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11155 in for-each-loop2408 in rec in k10584 in k10578 in k10575 in k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_11157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11147(t3,((C_word*)t0)[4],t2);}

/* k3843 in k3837 in k3834 in scan in scan-toplevel-assignments in k3676 in k3673 in k3670 */
static void C_ccall f_3845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_END_OF_LIST);
t3=C_i_cadr(((C_word*)t0)[3]);
/* optimizer.scm:79: scan */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3755(t4,((C_word*)t0)[5],t3,((C_word*)t0)[6]);}

/* k8320 in k8311 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_8322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8322,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=C_a_i_list2(&a,2,C_SCHEME_FALSE,t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8342,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t7=((C_word*)t0)[2];
t8=C_u_i_car(t7);
/* optimizer.scm:1062: varnode */
t9=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t6,t8);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k11133 in rec in k10584 in k10578 in k10575 in k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_11135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1510: rec */
t2=((C_word*)((C_word*)t0)[2])[1];
f_10864(3,t2,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k8311 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_8313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8313,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_length(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8322,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:1060: < */
C_lessp(5,0,t3,C_fix(0),t2,C_fix(3));}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3834 in scan in scan-toplevel-assignments in k3676 in k3673 in k3670 */
static void C_fcall f_3836(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3836,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3839,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* optimizer.scm:75: scan */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3755(t4,t2,t3,((C_word*)t0)[7]);}
else{
t2=C_eqp(((C_word*)t0)[8],lf[6]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3868,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3883,a[2]=((C_word*)t0)[10],a[3]=t3,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:82: butlast */
t5=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t3=C_eqp(((C_word*)t0)[8],lf[10]);
t4=(C_truep(t3)?t3:C_eqp(((C_word*)t0)[8],lf[11]));
if(C_truep(t4)){
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}
else{
t5=C_eqp(((C_word*)t0)[8],lf[12]);
if(C_truep(t5)){
/* optimizer.scm:87: touch */
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_3713(((C_word*)((C_word*)t0)[2])[1]));}
else{
t6=C_eqp(((C_word*)t0)[8],lf[13]);
if(C_truep(t6)){
t7=C_i_car(((C_word*)t0)[9]);
t8=t7;
t9=C_i_car(((C_word*)t0)[4]);
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3916,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[6],a[4]=t8,a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[3],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm:92: scan */
t11=((C_word*)((C_word*)t0)[5])[1];
f_3755(t11,t10,t9,((C_word*)t0)[7]);}
else{
/* optimizer.scm:106: scan-each */
t7=((C_word*)((C_word*)t0)[10])[1];
f_3718(t7,((C_word*)t0)[6],((C_word*)t0)[4],((C_word*)t0)[7]);}}}}}}

/* k3837 in k3834 in scan in scan-toplevel-assignments in k3676 in k3673 in k3670 */
static void C_ccall f_3839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3839,2,t0,t1);}
t2=f_3713(((C_word*)((C_word*)t0)[2])[1]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3845,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t4=C_u_i_car(((C_word*)t0)[4]);
/* optimizer.scm:77: scan */
t5=((C_word*)((C_word*)t0)[5])[1];
f_3755(t5,t3,t4,((C_word*)t0)[7]);}

/* a6886 in g1371 in k6852 in k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6887(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6887,3,t0,t1,t2);}
t3=C_eqp(t2,((C_word*)t0)[2]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6900,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:850: find-path */
t5=((C_word*)t0)[3];
f_6799(t5,t4,((C_word*)t0)[2],t2);}}

/* k6879 in k6863 in g1371 in k6852 in k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6881,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,C_a_i_cons(&a,2,t1,t2),((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6873,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=C_a_i_list1(&a,1,((C_word*)t0)[2]);
/* optimizer.scm:853: append */
t7=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,t6,((C_word*)t0)[3],((C_word*)((C_word*)t0)[5])[1]);}

/* k11449 in k11387 in walk in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_11451(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
if(C_truep(C_i_memq(((C_word*)t0)[2],((C_word*)t0)[3]))){
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=C_eqp(lf[11],t2);
if(C_truep(t3)){
t4=C_slot(((C_word*)t0)[4],C_fix(2));
t5=C_i_caddr(t4);
t6=((C_word*)t0)[5];
f_11403(t6,C_i_listp(t5));}
else{
t4=((C_word*)t0)[5];
f_11403(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
f_11403(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
f_11403(t2,C_SCHEME_FALSE);}}

/* a6385 in k6343 in k6340 in k6336 in k6330 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6390,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:529: print */
t3=*((C_word*)lf[111]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[115]);}

/* k11462 in k11387 in walk in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_11464(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11464,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11472,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1617: get */
t4=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],((C_word*)t0)[4],lf[126]);}

/* k6393 in for-each-loop925 in k6388 in a6385 in k6343 in k6340 in k6336 in k6330 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_u_i_cdr(((C_word*)t0)[2]);
if(C_truep(C_i_greaterp(t2,C_fix(1)))){
t3=C_u_i_cdr(((C_word*)t0)[2]);
/* optimizer.scm:534: print */
t4=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],C_make_character(9),t3);}
else{
/* optimizer.scm:535: newline */
t3=*((C_word*)lf[112]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k6388 in a6385 in k6343 in k6340 in k6336 in k6330 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6390,2,t0,t1);}
t2=*((C_word*)lf[31]+1);
t3=C_i_check_list_2(*((C_word*)lf[31]+1),lf[2]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6423,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_6423(t7,((C_word*)t0)[2],*((C_word*)lf[31]+1));}

/* g1331 in k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_6842(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6842,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6851,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:840: scan-used-variables */
t5=*((C_word*)lf[131]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,((C_word*)t0)[3]);}

/* k5816 in k5813 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5818,2,t0,t1);}
t2=C_u_i_cdr(((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[4],t3);
/* optimizer.scm:456: walk */
t5=((C_word*)((C_word*)t0)[5])[1];
f_4278(t5,((C_word*)t0)[6],t4,((C_word*)t0)[7],((C_word*)t0)[8]);}

/* k5813 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5815,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5818,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_slot(((C_word*)t0)[3],C_fix(2));
t4=C_i_car(t3);
/* optimizer.scm:454: debugging */
t5=*((C_word*)lf[17]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t2,lf[80],lf[99],((C_word*)t0)[9],t4);}
else{
/* optimizer.scm:462: walk-generic */
t2=((C_word*)((C_word*)t0)[10])[1];
f_6267(t2,((C_word*)t0)[6],((C_word*)t0)[11],((C_word*)t0)[12],((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[7],((C_word*)t0)[8],C_SCHEME_TRUE);}}

/* g1371 in k6852 in k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_6855(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6855,NULL,3,t0,t1,t2);}
if(C_truep(C_i_memq(t2,((C_word*)((C_word*)t0)[2])[1]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6865,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6887,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:849: filter */
t5=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[5]);}}

/* k6852 in k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6854,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6855,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t7=((C_word*)t0)[3];
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6914,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7166,a[2]=t10,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t12=((C_word*)t10)[1];
f_7166(t12,t8,t7);}

/* k6849 in g1331 in k6795 in reorganize-recursive-bindings in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6851,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1),((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5809,2,t0,t1);}
t2=C_i_structurep(t1,lf[14]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_5309,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=t3,a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],tmp=(C_word)a,a+=27,tmp);
if(C_truep(*((C_word*)lf[95]+1))){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5754,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[18],a[5]=((C_word*)t0)[17],a[6]=((C_word*)t0)[23],a[7]=((C_word*)t0)[19],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:365: test */
t6=((C_word*)((C_word*)t0)[23])[1];
f_4069(t6,t5,((C_word*)t0)[17],lf[97]);}
else{
t5=t4;
f_5309(t5,C_SCHEME_FALSE);}}

/* k6346 in k6343 in k6340 in k6336 in k6330 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6351,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_greaterp(((C_word*)((C_word*)t0)[7])[1],C_fix(0)))){
/* optimizer.scm:537: debugging */
t3=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[18],lf[110],((C_word*)((C_word*)t0)[7])[1]);}
else{
t3=t2;
f_6351(2,t3,C_SCHEME_UNDEFINED);}}

/* k6343 in k6340 in k6336 in k6330 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6345,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6348,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_pairp(*((C_word*)lf[31]+1)))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6386,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm:526: with-debugging-output */
t4=*((C_word*)lf[116]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[18],t3);}
else{
t3=t2;
f_6348(2,t3,C_SCHEME_UNDEFINED);}}

/* k5798 in k5752 in k5807 in a5290 in k5273 in k5099 in k5014 in k5007 in k5004 in walk1 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_5800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5800,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_5309(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5796,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:367: test */
t3=((C_word*)((C_word*)t0)[6])[1];
f_4069(t3,t2,((C_word*)t0)[7],lf[64]);}}

/* k11184 in for-each-loop2425 in rec in k10584 in k10578 in k10575 in k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_11186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11176(t3,((C_word*)t0)[4],t2);}

/* k11024 in k10990 in k10987 in g2375 in rec in k10584 in k10578 in k10575 in k10571 in k10562 in k10547 in transform in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_11026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1493: node-parameters-set! */
t2=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k6340 in k6336 in k6330 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6342,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6345,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[7])[1]))){
/* optimizer.scm:524: debugging */
t4=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[18],lf[117],((C_word*)((C_word*)t0)[7])[1]);}
else{
t4=t3;
f_6345(2,t4,C_SCHEME_UNDEFINED);}}

/* a9703 in k9690 in k9661 in simplify-named-call in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_9704(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9704,4,t0,t1,t2,t3);}
t4=t2;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9712,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_i_cddr(((C_word*)t0)[2]);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9718,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=((C_word*)t8)[1];
f_9718(t10,t5,t3,t6);}

/* k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6336 in k6330 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:540: values */
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}

/* k6352 in k6349 in k6346 in k6343 in k6340 in k6336 in k6330 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6357,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_greaterp(((C_word*)((C_word*)t0)[5])[1],C_fix(0)))){
/* optimizer.scm:539: debugging */
t3=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[18],lf[108],((C_word*)((C_word*)t0)[5])[1]);}
else{
/* optimizer.scm:540: values */
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}}

/* k6349 in k6346 in k6343 in k6340 in k6336 in k6330 in perform-high-level-optimizations in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_6351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6354,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_greaterp(((C_word*)((C_word*)t0)[6])[1],C_fix(0)))){
/* optimizer.scm:538: debugging */
t3=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[18],lf[109],((C_word*)((C_word*)t0)[6])[1]);}
else{
t3=t2;
f_6354(2,t3,C_SCHEME_UNDEFINED);}}

/* a10445 in rec in scan in transform-direct-lambdas! in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_10446(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10446,3,t0,t1,t2);}
/* optimizer.scm:1432: rec */
t3=((C_word*)((C_word*)t0)[2])[1];
f_10076(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k12228 in k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_ccall f_12230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1680: debugging */
t2=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[191],lf[192],t1);}

/* map-loop2816 in k11771 in k11768 in k11765 in k11762 in k11641 in k11638 in g2683 in k11629 in k11626 in determine-loop-and-dispatch in k7275 in k6783 in k6780 in k6777 in k4061 in k3676 in k3673 in k3670 */
static void C_fcall f_12232(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_12232,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[586] = {
{"f_11176:optimizer_2escm",(void*)f_11176},
{"f_7711:optimizer_2escm",(void*)f_7711},
{"f_9507:optimizer_2escm",(void*)f_9507},
{"f_9212:optimizer_2escm",(void*)f_9212},
{"f_7719:optimizer_2escm",(void*)f_7719},
{"f_10846:optimizer_2escm",(void*)f_10846},
{"f_11479:optimizer_2escm",(void*)f_11479},
{"f_11472:optimizer_2escm",(void*)f_11472},
{"f_6338:optimizer_2escm",(void*)f_6338},
{"f_6332:optimizer_2escm",(void*)f_6332},
{"f_10864:optimizer_2escm",(void*)f_10864},
{"f_7590:optimizer_2escm",(void*)f_7590},
{"f_10679:optimizer_2escm",(void*)f_10679},
{"f_7599:optimizer_2escm",(void*)f_7599},
{"f_10676:optimizer_2escm",(void*)f_10676},
{"f_5407:optimizer_2escm",(void*)f_5407},
{"f_4593:optimizer_2escm",(void*)f_4593},
{"f_4590:optimizer_2escm",(void*)f_4590},
{"f_10682:optimizer_2escm",(void*)f_10682},
{"f_8212:optimizer_2escm",(void*)f_8212},
{"f_8218:optimizer_2escm",(void*)f_8218},
{"f_10690:optimizer_2escm",(void*)f_10690},
{"f_5421:optimizer_2escm",(void*)f_5421},
{"f_8562:optimizer_2escm",(void*)f_8562},
{"f_9742:optimizer_2escm",(void*)f_9742},
{"f_12638:optimizer_2escm",(void*)f_12638},
{"toplevel:optimizer_2escm",(void*)C_optimizer_toplevel},
{"f_5495:optimizer_2escm",(void*)f_5495},
{"f_4292:optimizer_2escm",(void*)f_4292},
{"f_5487:optimizer_2escm",(void*)f_5487},
{"f_6805:optimizer_2escm",(void*)f_6805},
{"f_8588:optimizer_2escm",(void*)f_8588},
{"f_8584:optimizer_2escm",(void*)f_8584},
{"f_9765:optimizer_2escm",(void*)f_9765},
{"f_11389:optimizer_2escm",(void*)f_11389},
{"f_5458:optimizer_2escm",(void*)f_5458},
{"f_9738:optimizer_2escm",(void*)f_9738},
{"f_5448:optimizer_2escm",(void*)f_5448},
{"f_8825:optimizer_2escm",(void*)f_8825},
{"f_5984:optimizer_2escm",(void*)f_5984},
{"f_5445:optimizer_2escm",(void*)f_5445},
{"f_12513:optimizer_2escm",(void*)f_12513},
{"f_12517:optimizer_2escm",(void*)f_12517},
{"f_9460:optimizer_2escm",(void*)f_9460},
{"f_9462:optimizer_2escm",(void*)f_9462},
{"f_4370:optimizer_2escm",(void*)f_4370},
{"f_12521:optimizer_2escm",(void*)f_12521},
{"f_10659:optimizer_2escm",(void*)f_10659},
{"f_10656:optimizer_2escm",(void*)f_10656},
{"f_4379:optimizer_2escm",(void*)f_4379},
{"f_6829:optimizer_2escm",(void*)f_6829},
{"f_4311:optimizer_2escm",(void*)f_4311},
{"f_12505:optimizer_2escm",(void*)f_12505},
{"f_7448:optimizer_2escm",(void*)f_7448},
{"f_3995:optimizer_2escm",(void*)f_3995},
{"f_3998:optimizer_2escm",(void*)f_3998},
{"f_5435:optimizer_2escm",(void*)f_5435},
{"f_5323:optimizer_2escm",(void*)f_5323},
{"f_5326:optimizer_2escm",(void*)f_5326},
{"f_5329:optimizer_2escm",(void*)f_5329},
{"f_5312:optimizer_2escm",(void*)f_5312},
{"f_5313:optimizer_2escm",(void*)f_5313},
{"f_8247:optimizer_2escm",(void*)f_8247},
{"f_6105:optimizer_2escm",(void*)f_6105},
{"f_10174:optimizer_2escm",(void*)f_10174},
{"f_6472:optimizer_2escm",(void*)f_6472},
{"f_12371:optimizer_2escm",(void*)f_12371},
{"f_11084:optimizer_2escm",(void*)f_11084},
{"f_12361:optimizer_2escm",(void*)f_12361},
{"f_11087:optimizer_2escm",(void*)f_11087},
{"f_10195:optimizer_2escm",(void*)f_10195},
{"f_12390:optimizer_2escm",(void*)f_12390},
{"f_6469:optimizer_2escm",(void*)f_6469},
{"f_6466:optimizer_2escm",(void*)f_6466},
{"f_7518:optimizer_2escm",(void*)f_7518},
{"f_12380:optimizer_2escm",(void*)f_12380},
{"f_6433:optimizer_2escm",(void*)f_6433},
{"f_5372:optimizer_2escm",(void*)f_5372},
{"f_6487:optimizer_2escm",(void*)f_6487},
{"f_6486:optimizer_2escm",(void*)f_6486},
{"f_8887:optimizer_2escm",(void*)f_8887},
{"f_8883:optimizer_2escm",(void*)f_8883},
{"f_4646:optimizer_2escm",(void*)f_4646},
{"f_4649:optimizer_2escm",(void*)f_4649},
{"f_6459:optimizer_2escm",(void*)f_6459},
{"f_6455:optimizer_2escm",(void*)f_6455},
{"f_6452:optimizer_2escm",(void*)f_6452},
{"f_5334:optimizer_2escm",(void*)f_5334},
{"f_5337:optimizer_2escm",(void*)f_5337},
{"f_10339:optimizer_2escm",(void*)f_10339},
{"f_8848:optimizer_2escm",(void*)f_8848},
{"f_6227:optimizer_2escm",(void*)f_6227},
{"f_10344:optimizer_2escm",(void*)f_10344},
{"f_5351:optimizer_2escm",(void*)f_5351},
{"f_8732:optimizer_2escm",(void*)f_8732},
{"f_5382:optimizer_2escm",(void*)f_5382},
{"f_5341:optimizer_2escm",(void*)f_5341},
{"f_5348:optimizer_2escm",(void*)f_5348},
{"f_4683:optimizer_2escm",(void*)f_4683},
{"f_4685:optimizer_2escm",(void*)f_4685},
{"f_8107:optimizer_2escm",(void*)f_8107},
{"f_12841:optimizer_2escm",(void*)f_12841},
{"f_4676:optimizer_2escm",(void*)f_4676},
{"f_12685:optimizer_2escm",(void*)f_12685},
{"f_7324:optimizer_2escm",(void*)f_7324},
{"f_4807:optimizer_2escm",(void*)f_4807},
{"f_10140:optimizer_2escm",(void*)f_10140},
{"f_4802:optimizer_2escm",(void*)f_4802},
{"f_10158:optimizer_2escm",(void*)f_10158},
{"f_6546:optimizer_2escm",(void*)f_6546},
{"f_4819:optimizer_2escm",(void*)f_4819},
{"f_6540:optimizer_2escm",(void*)f_6540},
{"f_4813:optimizer_2escm",(void*)f_4813},
{"f_6555:optimizer_2escm",(void*)f_6555},
{"f_4832:optimizer_2escm",(void*)f_4832},
{"f_9712:optimizer_2escm",(void*)f_9712},
{"f_9718:optimizer_2escm",(void*)f_9718},
{"f_10490:optimizer_2escm",(void*)f_10490},
{"f_12899:optimizer_2escm",(void*)f_12899},
{"f_4852:optimizer_2escm",(void*)f_4852},
{"f_9416:optimizer_2escm",(void*)f_9416},
{"f_4714:optimizer_2escm",(void*)f_4714},
{"f_8093:optimizer_2escm",(void*)f_8093},
{"f_8090:optimizer_2escm",(void*)f_8090},
{"f_4721:optimizer_2escm",(void*)f_4721},
{"f_8084:optimizer_2escm",(void*)f_8084},
{"f_9131:optimizer_2escm",(void*)f_9131},
{"f_4825:optimizer_2escm",(void*)f_4825},
{"f_7359:optimizer_2escm",(void*)f_7359},
{"f_6565:optimizer_2escm",(void*)f_6565},
{"f_6568:optimizer_2escm",(void*)f_6568},
{"f_12868:optimizer_2escm",(void*)f_12868},
{"f_8058:optimizer_2escm",(void*)f_8058},
{"f_11343:optimizer_2escm",(void*)f_11343},
{"f_6562:optimizer_2escm",(void*)f_6562},
{"f_7362:optimizer_2escm",(void*)f_7362},
{"f_6583:optimizer_2escm",(void*)f_6583},
{"f_7226:optimizer_2escm",(void*)f_7226},
{"f_5309:optimizer_2escm",(void*)f_5309},
{"f_9184:optimizer_2escm",(void*)f_9184},
{"f_9186:optimizer_2escm",(void*)f_9186},
{"f_6779:optimizer_2escm",(void*)f_6779},
{"f_6772:optimizer_2escm",(void*)f_6772},
{"f_3916:optimizer_2escm",(void*)f_3916},
{"f_3919:optimizer_2escm",(void*)f_3919},
{"f_3940:optimizer_2escm",(void*)f_3940},
{"f_12332:optimizer_2escm",(void*)f_12332},
{"f_3937:optimizer_2escm",(void*)f_3937},
{"f_7865:optimizer_2escm",(void*)f_7865},
{"f_12006:optimizer_2escm",(void*)f_12006},
{"f_7293:optimizer_2escm",(void*)f_7293},
{"f_7299:optimizer_2escm",(void*)f_7299},
{"f_12010:optimizer_2escm",(void*)f_12010},
{"f_12014:optimizer_2escm",(void*)f_12014},
{"f_12018:optimizer_2escm",(void*)f_12018},
{"f_11420:optimizer_2escm",(void*)f_11420},
{"f_9105:optimizer_2escm",(void*)f_9105},
{"f_3925:optimizer_2escm",(void*)f_3925},
{"f_3922:optimizer_2escm",(void*)f_3922},
{"f_13263:optimizer_2escm",(void*)f_13263},
{"f_9990:optimizer_2escm",(void*)f_9990},
{"f_13267:optimizer_2escm",(void*)f_13267},
{"f_4879:optimizer_2escm",(void*)f_4879},
{"f_4872:optimizer_2escm",(void*)f_4872},
{"f_10297:optimizer_2escm",(void*)f_10297},
{"f_6787:optimizer_2escm",(void*)f_6787},
{"f_6785:optimizer_2escm",(void*)f_6785},
{"f_10292:optimizer_2escm",(void*)f_10292},
{"f_6782:optimizer_2escm",(void*)f_6782},
{"f_13271:optimizer_2escm",(void*)f_13271},
{"f_4882:optimizer_2escm",(void*)f_4882},
{"f_6799:optimizer_2escm",(void*)f_6799},
{"f_6797:optimizer_2escm",(void*)f_6797},
{"f_9973:optimizer_2escm",(void*)f_9973},
{"f_12028:optimizer_2escm",(void*)f_12028},
{"f_12026:optimizer_2escm",(void*)f_12026},
{"f_8679:optimizer_2escm",(void*)f_8679},
{"f_7239:optimizer_2escm",(void*)f_7239},
{"f_12295:optimizer_2escm",(void*)f_12295},
{"f_12297:optimizer_2escm",(void*)f_12297},
{"f_9692:optimizer_2escm",(void*)f_9692},
{"f_9696:optimizer_2escm",(void*)f_9696},
{"f_9688:optimizer_2escm",(void*)f_9688},
{"f_6749:optimizer_2escm",(void*)f_6749},
{"f_9698:optimizer_2escm",(void*)f_9698},
{"f_12275:optimizer_2escm",(void*)f_12275},
{"f_6759:optimizer_2escm",(void*)f_6759},
{"f_13289:optimizer_2escm",(void*)f_13289},
{"f_12269:optimizer_2escm",(void*)f_12269},
{"f_13280:optimizer_2escm",(void*)f_13280},
{"f_12727:optimizer_2escm",(void*)f_12727},
{"f_7277:optimizer_2escm",(void*)f_7277},
{"f_7279:optimizer_2escm",(void*)f_7279},
{"f_7283:optimizer_2escm",(void*)f_7283},
{"f_10979:optimizer_2escm",(void*)f_10979},
{"f_9663:optimizer_2escm",(void*)f_9663},
{"f_10989:optimizer_2escm",(void*)f_10989},
{"f_7039:optimizer_2escm",(void*)f_7039},
{"f_8032:optimizer_2escm",(void*)f_8032},
{"f_10992:optimizer_2escm",(void*)f_10992},
{"f_10998:optimizer_2escm",(void*)f_10998},
{"f_10995:optimizer_2escm",(void*)f_10995},
{"f_6311:optimizer_2escm",(void*)f_6311},
{"f_4666:optimizer_2escm",(void*)f_4666},
{"f_6304:optimizer_2escm",(void*)f_6304},
{"f_9345:optimizer_2escm",(void*)f_9345},
{"f_12737:optimizer_2escm",(void*)f_12737},
{"f_10942:optimizer_2escm",(void*)f_10942},
{"f_10945:optimizer_2escm",(void*)f_10945},
{"f_6514:optimizer_2escm",(void*)f_6514},
{"f_10948:optimizer_2escm",(void*)f_10948},
{"f_7071:optimizer_2escm",(void*)f_7071},
{"f_6505:optimizer_2escm",(void*)f_6505},
{"f_6508:optimizer_2escm",(void*)f_6508},
{"f_5551:optimizer_2escm",(void*)f_5551},
{"f_4038:optimizer_2escm",(void*)f_4038},
{"f_6534:optimizer_2escm",(void*)f_6534},
{"f_4428:optimizer_2escm",(void*)f_4428},
{"f_11770:optimizer_2escm",(void*)f_11770},
{"f_4434:optimizer_2escm",(void*)f_4434},
{"f_11605:optimizer_2escm",(void*)f_11605},
{"f_11780:optimizer_2escm",(void*)f_11780},
{"f_4615:optimizer_2escm",(void*)f_4615},
{"f_11779:optimizer_2escm",(void*)f_11779},
{"f_11776:optimizer_2escm",(void*)f_11776},
{"f_11773:optimizer_2escm",(void*)f_11773},
{"f_8350:optimizer_2escm",(void*)f_8350},
{"f_8354:optimizer_2escm",(void*)f_8354},
{"f_7817:optimizer_2escm",(void*)f_7817},
{"f_11785:optimizer_2escm",(void*)f_11785},
{"f_11784:optimizer_2escm",(void*)f_11784},
{"f_8342:optimizer_2escm",(void*)f_8342},
{"f_11628:optimizer_2escm",(void*)f_11628},
{"f_12082:optimizer_2escm",(void*)f_12082},
{"f_11631:optimizer_2escm",(void*)f_11631},
{"f_11632:optimizer_2escm",(void*)f_11632},
{"f_8532:optimizer_2escm",(void*)f_8532},
{"f_6174:optimizer_2escm",(void*)f_6174},
{"f_11640:optimizer_2escm",(void*)f_11640},
{"f_11643:optimizer_2escm",(void*)f_11643},
{"f_11644:optimizer_2escm",(void*)f_11644},
{"f_5646:optimizer_2escm",(void*)f_5646},
{"f_5658:optimizer_2escm",(void*)f_5658},
{"f_6142:optimizer_2escm",(void*)f_6142},
{"f_5648:optimizer_2escm",(void*)f_5648},
{"f_6198:optimizer_2escm",(void*)f_6198},
{"f_9381:optimizer_2escm",(void*)f_9381},
{"f_9387:optimizer_2escm",(void*)f_9387},
{"f_8528:optimizer_2escm",(void*)f_8528},
{"f_4123:optimizer_2escm",(void*)f_4123},
{"f_9096:optimizer_2escm",(void*)f_9096},
{"f_12097:optimizer_2escm",(void*)f_12097},
{"f_10245:optimizer_2escm",(void*)f_10245},
{"f_9390:optimizer_2escm",(void*)f_9390},
{"f_12074:optimizer_2escm",(void*)f_12074},
{"f_6130:optimizer_2escm",(void*)f_6130},
{"f_6132:optimizer_2escm",(void*)f_6132},
{"f_9375:optimizer_2escm",(void*)f_9375},
{"f_13125:optimizer_2escm",(void*)f_13125},
{"f_13121:optimizer_2escm",(void*)f_13121},
{"f_13129:optimizer_2escm",(void*)f_13129},
{"f_6157:optimizer_2escm",(void*)f_6157},
{"f_6156:optimizer_2escm",(void*)f_6156},
{"f_9052:optimizer_2escm",(void*)f_9052},
{"f_5774:optimizer_2escm",(void*)f_5774},
{"f_7010:optimizer_2escm",(void*)f_7010},
{"f_13142:optimizer_2escm",(void*)f_13142},
{"f_10256:optimizer_2escm",(void*)f_10256},
{"f_10251:optimizer_2escm",(void*)f_10251},
{"f_11767:optimizer_2escm",(void*)f_11767},
{"f_11764:optimizer_2escm",(void*)f_11764},
{"f_9072:optimizer_2escm",(void*)f_9072},
{"f_10229:optimizer_2escm",(void*)f_10229},
{"f_4400:optimizer_2escm",(void*)f_4400},
{"f_13026:optimizer_2escm",(void*)f_13026},
{"f_5660:optimizer_2escm",(void*)f_5660},
{"f_8969:optimizer_2escm",(void*)f_8969},
{"f_10719:optimizer_2escm",(void*)f_10719},
{"f_8635:optimizer_2escm",(void*)f_8635},
{"f_3742:optimizer_2escm",(void*)f_3742},
{"f_10724:optimizer_2escm",(void*)f_10724},
{"f_5037:optimizer_2escm",(void*)f_5037},
{"f_5697:optimizer_2escm",(void*)f_5697},
{"f_3732:optimizer_2escm",(void*)f_3732},
{"f_9002:optimizer_2escm",(void*)f_9002},
{"f_5030:optimizer_2escm",(void*)f_5030},
{"f_10734:optimizer_2escm",(void*)f_10734},
{"f_5033:optimizer_2escm",(void*)f_5033},
{"f_5689:optimizer_2escm",(void*)f_5689},
{"f_11817:optimizer_2escm",(void*)f_11817},
{"f_10747:optimizer_2escm",(void*)f_10747},
{"f_7069:optimizer_2escm",(void*)f_7069},
{"f_5054:optimizer_2escm",(void*)f_5054},
{"f_5047:optimizer_2escm",(void*)f_5047},
{"f_5796:optimizer_2escm",(void*)f_5796},
{"f_4475:optimizer_2escm",(void*)f_4475},
{"f_11837:optimizer_2escm",(void*)f_11837},
{"f_4471:optimizer_2escm",(void*)f_4471},
{"f_4479:optimizer_2escm",(void*)f_4479},
{"f_12942:optimizer_2escm",(void*)f_12942},
{"f_4486:optimizer_2escm",(void*)f_4486},
{"f_4483:optimizer_2escm",(void*)f_4483},
{"f_13216:optimizer_2escm",(void*)f_13216},
{"f_9914:optimizer_2escm",(void*)f_9914},
{"f_4913:optimizer_2escm",(void*)f_4913},
{"f_11829:optimizer_2escm",(void*)f_11829},
{"f_11825:optimizer_2escm",(void*)f_11825},
{"f_11821:optimizer_2escm",(void*)f_11821},
{"f_11902:optimizer_2escm",(void*)f_11902},
{"f_12952:optimizer_2escm",(void*)f_12952},
{"f_12950:optimizer_2escm",(void*)f_12950},
{"f_9920:optimizer_2escm",(void*)f_9920},
{"f_5754:optimizer_2escm",(void*)f_5754},
{"f_11912:optimizer_2escm",(void*)f_11912},
{"f_5741:optimizer_2escm",(void*)f_5741},
{"f_4906:optimizer_2escm",(void*)f_4906},
{"f_9908:optimizer_2escm",(void*)f_9908},
{"f_4901:optimizer_2escm",(void*)f_4901},
{"f_4953:optimizer_2escm",(void*)f_4953},
{"f_13229:optimizer_2escm",(void*)f_13229},
{"f_5537:optimizer_2escm",(void*)f_5537},
{"f_5533:optimizer_2escm",(void*)f_5533},
{"f_13235:optimizer_2escm",(void*)f_13235},
{"f_9323:optimizer_2escm",(void*)f_9323},
{"f_9321:optimizer_2escm",(void*)f_9321},
{"f_13099:optimizer_2escm",(void*)f_13099},
{"f_9627:optimizer_2escm",(void*)f_9627},
{"f_9333:optimizer_2escm",(void*)f_9333},
{"f_6028:optimizer_2escm",(void*)f_6028},
{"f_11673:optimizer_2escm",(void*)f_11673},
{"f_13086:optimizer_2escm",(void*)f_13086},
{"f_11684:optimizer_2escm",(void*)f_11684},
{"f_6056:optimizer_2escm",(void*)f_6056},
{"f_7646:optimizer_2escm",(void*)f_7646},
{"f_11872:optimizer_2escm",(void*)f_11872},
{"f_4933:optimizer_2escm",(void*)f_4933},
{"f_5513:optimizer_2escm",(void*)f_5513},
{"f_13062:optimizer_2escm",(void*)f_13062},
{"f_7691:optimizer_2escm",(void*)f_7691},
{"f_7117:optimizer_2escm",(void*)f_7117},
{"f_11847:optimizer_2escm",(void*)f_11847},
{"f_5507:optimizer_2escm",(void*)f_5507},
{"f_5501:optimizer_2escm",(void*)f_5501},
{"f_8416:optimizer_2escm",(void*)f_8416},
{"f_8406:optimizer_2escm",(void*)f_8406},
{"f_5624:optimizer_2escm",(void*)f_5624},
{"f_12575:optimizer_2escm",(void*)f_12575},
{"f_11250:optimizer_2escm",(void*)f_11250},
{"f_11252:optimizer_2escm",(void*)f_11252},
{"f_11258:optimizer_2escm",(void*)f_11258},
{"f_3868:optimizer_2escm",(void*)f_3868},
{"f_11925:optimizer_2escm",(void*)f_11925},
{"f_11882:optimizer_2escm",(void*)f_11882},
{"f_11935:optimizer_2escm",(void*)f_11935},
{"f_5016:optimizer_2escm",(void*)f_5016},
{"f_3883:optimizer_2escm",(void*)f_3883},
{"f_6997:optimizer_2escm",(void*)f_6997},
{"f_8472:optimizer_2escm",(void*)f_8472},
{"f_5009:optimizer_2escm",(void*)f_5009},
{"f_5006:optimizer_2escm",(void*)f_5006},
{"f_6962:optimizer_2escm",(void*)f_6962},
{"f_5107:optimizer_2escm",(void*)f_5107},
{"f_5101:optimizer_2escm",(void*)f_5101},
{"f_8112:optimizer_2escm",(void*)f_8112},
{"f_7957:optimizer_2escm",(void*)f_7957},
{"f_5619:optimizer_2escm",(void*)f_5619},
{"f_5630:optimizer_2escm",(void*)f_5630},
{"f_8101:optimizer_2escm",(void*)f_8101},
{"f_11707:optimizer_2escm",(void*)f_11707},
{"f_7199:optimizer_2escm",(void*)f_7199},
{"f_10076:optimizer_2escm",(void*)f_10076},
{"f_6980:optimizer_2escm",(void*)f_6980},
{"f_5607:optimizer_2escm",(void*)f_5607},
{"f_10073:optimizer_2escm",(void*)f_10073},
{"f_5604:optimizer_2escm",(void*)f_5604},
{"f_6989:optimizer_2escm",(void*)f_6989},
{"f_12115:optimizer_2escm",(void*)f_12115},
{"f_6956:optimizer_2escm",(void*)f_6956},
{"f_11736:optimizer_2escm",(void*)f_11736},
{"f_8432:optimizer_2escm",(void*)f_8432},
{"f_8436:optimizer_2escm",(void*)f_8436},
{"f_3875:optimizer_2escm",(void*)f_3875},
{"f_3879:optimizer_2escm",(void*)f_3879},
{"f_5079:optimizer_2escm",(void*)f_5079},
{"f_7998:optimizer_2escm",(void*)f_7998},
{"f_7990:optimizer_2escm",(void*)f_7990},
{"f_6974:optimizer_2escm",(void*)f_6974},
{"f_5705:optimizer_2escm",(void*)f_5705},
{"f_9878:optimizer_2escm",(void*)f_9878},
{"f_6977:optimizer_2escm",(void*)f_6977},
{"f_5069:optimizer_2escm",(void*)f_5069},
{"f_4393:optimizer_2escm",(void*)f_4393},
{"f_12105:optimizer_2escm",(void*)f_12105},
{"f_12109:optimizer_2escm",(void*)f_12109},
{"f_11668:optimizer_2escm",(void*)f_11668},
{"f_10590:optimizer_2escm",(void*)f_10590},
{"f_5192:optimizer_2escm",(void*)f_5192},
{"f_5190:optimizer_2escm",(void*)f_5190},
{"f_10564:optimizer_2escm",(void*)f_10564},
{"f_5211:optimizer_2escm",(void*)f_5211},
{"f_10589:optimizer_2escm",(void*)f_10589},
{"f_4075:optimizer_2escm",(void*)f_4075},
{"f_10586:optimizer_2escm",(void*)f_10586},
{"f_10580:optimizer_2escm",(void*)f_10580},
{"f_9838:optimizer_2escm",(void*)f_9838},
{"f_8183:optimizer_2escm",(void*)f_8183},
{"f_12149:optimizer_2escm",(void*)f_12149},
{"f_12145:optimizer_2escm",(void*)f_12145},
{"f_9835:optimizer_2escm",(void*)f_9835},
{"f_6738:optimizer_2escm",(void*)f_6738},
{"f_4001:optimizer_2escm",(void*)f_4001},
{"f_12555:optimizer_2escm",(void*)f_12555},
{"f_8754:optimizer_2escm",(void*)f_8754},
{"f_8758:optimizer_2escm",(void*)f_8758},
{"f_5152:optimizer_2escm",(void*)f_5152},
{"f_6722:optimizer_2escm",(void*)f_6722},
{"f_10577:optimizer_2escm",(void*)f_10577},
{"f_10573:optimizer_2escm",(void*)f_10573},
{"f_4028:optimizer_2escm",(void*)f_4028},
{"f_5149:optimizer_2escm",(void*)f_5149},
{"f_7143:optimizer_2escm",(void*)f_7143},
{"f_4389:optimizer_2escm",(void*)f_4389},
{"f_7153:optimizer_2escm",(void*)f_7153},
{"f_5275:optimizer_2escm",(void*)f_5275},
{"f_4580:optimizer_2escm",(void*)f_4580},
{"f_5161:optimizer_2escm",(void*)f_5161},
{"f_7166:optimizer_2escm",(void*)f_7166},
{"f_4059:optimizer_2escm",(void*)f_4059},
{"f_7176:optimizer_2escm",(void*)f_7176},
{"f_5291:optimizer_2escm",(void*)f_5291},
{"f_4069:optimizer_2escm",(void*)f_4069},
{"f_4066:optimizer_2escm",(void*)f_4066},
{"f_4063:optimizer_2escm",(void*)f_4063},
{"f_7189:optimizer_2escm",(void*)f_7189},
{"f_12441:optimizer_2escm",(void*)f_12441},
{"f_5997:optimizer_2escm",(void*)f_5997},
{"f_5999:optimizer_2escm",(void*)f_5999},
{"f_10823:optimizer_2escm",(void*)f_10823},
{"f_5990:optimizer_2escm",(void*)f_5990},
{"f_6062:optimizer_2escm",(void*)f_6062},
{"f_11595:optimizer_2escm",(void*)f_11595},
{"f_12419:optimizer_2escm",(void*)f_12419},
{"f_6073:optimizer_2escm",(void*)f_6073},
{"f_4161:optimizer_2escm",(void*)f_4161},
{"f_10286:optimizer_2escm",(void*)f_10286},
{"f_7625:optimizer_2escm",(void*)f_7625},
{"f_11564:optimizer_2escm",(void*)f_11564},
{"f_6082:optimizer_2escm",(void*)f_6082},
{"f_6423:optimizer_2escm",(void*)f_6423},
{"f_11574:optimizer_2escm",(void*)f_11574},
{"f_5251:optimizer_2escm",(void*)f_5251},
{"f_6099:optimizer_2escm",(void*)f_6099},
{"f_4105:optimizer_2escm",(void*)f_4105},
{"f_4109:optimizer_2escm",(void*)f_4109},
{"f_7604:optimizer_2escm",(void*)f_7604},
{"f_8153:optimizer_2escm",(void*)f_8153},
{"f_8155:optimizer_2escm",(void*)f_8155},
{"f_4153:optimizer_2escm",(void*)f_4153},
{"f_4150:optimizer_2escm",(void*)f_4150},
{"f_10032:optimizer_2escm",(void*)f_10032},
{"f_11557:optimizer_2escm",(void*)f_11557},
{"f_11551:optimizer_2escm",(void*)f_11551},
{"f_7758:optimizer_2escm",(void*)f_7758},
{"f_11275:optimizer_2escm",(void*)f_11275},
{"f_11278:optimizer_2escm",(void*)f_11278},
{"f_6945:optimizer_2escm",(void*)f_6945},
{"f_3792:optimizer_2escm",(void*)f_3792},
{"f_3798:optimizer_2escm",(void*)f_3798},
{"f_3796:optimizer_2escm",(void*)f_3796},
{"f_4525:optimizer_2escm",(void*)f_4525},
{"f_6932:optimizer_2escm",(void*)f_6932},
{"f_11283:optimizer_2escm",(void*)f_11283},
{"f_6930:optimizer_2escm",(void*)f_6930},
{"f_4177:optimizer_2escm",(void*)f_4177},
{"f_4171:optimizer_2escm",(void*)f_4171},
{"f_11280:optimizer_2escm",(void*)f_11280},
{"f_10044:optimizer_2escm",(void*)f_10044},
{"f_4537:optimizer_2escm",(void*)f_4537},
{"f_4146:optimizer_2escm",(void*)f_4146},
{"f_4531:optimizer_2escm",(void*)f_4531},
{"f_11583:optimizer_2escm",(void*)f_11583},
{"f_6273:optimizer_2escm",(void*)f_6273},
{"f_9579:optimizer_2escm",(void*)f_9579},
{"f_10054:optimizer_2escm",(void*)f_10054},
{"f_6283:optimizer_2escm",(void*)f_6283},
{"f_10833:optimizer_2escm",(void*)f_10833},
{"f_6900:optimizer_2escm",(void*)f_6900},
{"f_4557:optimizer_2escm",(void*)f_4557},
{"f_3755:optimizer_2escm",(void*)f_3755},
{"f_5933:optimizer_2escm",(void*)f_5933},
{"f_3672:optimizer_2escm",(void*)f_3672},
{"f_5939:optimizer_2escm",(void*)f_5939},
{"f_3678:optimizer_2escm",(void*)f_3678},
{"f_3675:optimizer_2escm",(void*)f_3675},
{"f_12181:optimizer_2escm",(void*)f_12181},
{"f_12177:optimizer_2escm",(void*)f_12177},
{"f_3706:optimizer_2escm",(void*)f_3706},
{"f_4278:optimizer_2escm",(void*)f_4278},
{"f_6298:optimizer_2escm",(void*)f_6298},
{"f_3690:optimizer_2escm",(void*)f_3690},
{"f_10016:optimizer_2escm",(void*)f_10016},
{"f_11269:optimizer_2escm",(void*)f_11269},
{"f_10545:optimizer_2escm",(void*)f_10545},
{"f_10549:optimizer_2escm",(void*)f_10549},
{"f_3720:optimizer_2escm",(void*)f_3720},
{"f_3680:optimizer_2escm",(void*)f_3680},
{"f_5949:optimizer_2escm",(void*)f_5949},
{"f_10543:optimizer_2escm",(void*)f_10543},
{"f_3683:optimizer_2escm",(void*)f_3683},
{"f_6239:optimizer_2escm",(void*)f_6239},
{"f_4491:optimizer_2escm",(void*)f_4491},
{"f_6235:optimizer_2escm",(void*)f_6235},
{"f_13387:optimizer_2escm",(void*)f_13387},
{"f_4216:optimizer_2escm",(void*)f_4216},
{"f_6208:optimizer_2escm",(void*)f_6208},
{"f_6250:optimizer_2escm",(void*)f_6250},
{"f_3718:optimizer_2escm",(void*)f_3718},
{"f_3713:optimizer_2escm",(void*)f_3713},
{"f_3711:optimizer_2escm",(void*)f_3711},
{"f_13395:optimizer_2escm",(void*)f_13395},
{"f_6246:optimizer_2escm",(void*)f_6246},
{"f_13056:optimizer_2escm",(void*)f_13056},
{"f_4232:optimizer_2escm",(void*)f_4232},
{"f_9288:optimizer_2escm",(void*)f_9288},
{"f_4230:optimizer_2escm",(void*)f_4230},
{"f_12169:optimizer_2escm",(void*)f_12169},
{"f_10536:optimizer_2escm",(void*)f_10536},
{"f_6267:optimizer_2escm",(void*)f_6267},
{"f_10479:optimizer_2escm",(void*)f_10479},
{"f_10503:optimizer_2escm",(void*)f_10503},
{"f_5903:optimizer_2escm",(void*)f_5903},
{"f_13032:optimizer_2escm",(void*)f_13032},
{"f_5128:optimizer_2escm",(void*)f_5128},
{"f_4779:optimizer_2escm",(void*)f_4779},
{"f_4786:optimizer_2escm",(void*)f_4786},
{"f_6922:optimizer_2escm",(void*)f_6922},
{"f_11403:optimizer_2escm",(void*)f_11403},
{"f_6915:optimizer_2escm",(void*)f_6915},
{"f_6914:optimizer_2escm",(void*)f_6914},
{"f_13410:optimizer_2escm",(void*)f_13410},
{"f_13414:optimizer_2escm",(void*)f_13414},
{"f_12479:optimizer_2escm",(void*)f_12479},
{"f_6865:optimizer_2escm",(void*)f_6865},
{"f_12477:optimizer_2escm",(void*)f_12477},
{"f_10605:optimizer_2escm",(void*)f_10605},
{"f_3809:optimizer_2escm",(void*)f_3809},
{"f_6873:optimizer_2escm",(void*)f_6873},
{"f_13400:optimizer_2escm",(void*)f_13400},
{"f_5916:optimizer_2escm",(void*)f_5916},
{"f_5217:optimizer_2escm",(void*)f_5217},
{"f_11147:optimizer_2escm",(void*)f_11147},
{"f_11157:optimizer_2escm",(void*)f_11157},
{"f_3845:optimizer_2escm",(void*)f_3845},
{"f_8322:optimizer_2escm",(void*)f_8322},
{"f_11135:optimizer_2escm",(void*)f_11135},
{"f_8313:optimizer_2escm",(void*)f_8313},
{"f_3836:optimizer_2escm",(void*)f_3836},
{"f_3839:optimizer_2escm",(void*)f_3839},
{"f_6887:optimizer_2escm",(void*)f_6887},
{"f_6881:optimizer_2escm",(void*)f_6881},
{"f_11451:optimizer_2escm",(void*)f_11451},
{"f_6386:optimizer_2escm",(void*)f_6386},
{"f_11464:optimizer_2escm",(void*)f_11464},
{"f_6395:optimizer_2escm",(void*)f_6395},
{"f_6390:optimizer_2escm",(void*)f_6390},
{"f_6842:optimizer_2escm",(void*)f_6842},
{"f_5818:optimizer_2escm",(void*)f_5818},
{"f_5815:optimizer_2escm",(void*)f_5815},
{"f_6855:optimizer_2escm",(void*)f_6855},
{"f_6854:optimizer_2escm",(void*)f_6854},
{"f_6851:optimizer_2escm",(void*)f_6851},
{"f_5809:optimizer_2escm",(void*)f_5809},
{"f_6348:optimizer_2escm",(void*)f_6348},
{"f_6345:optimizer_2escm",(void*)f_6345},
{"f_5800:optimizer_2escm",(void*)f_5800},
{"f_11186:optimizer_2escm",(void*)f_11186},
{"f_11026:optimizer_2escm",(void*)f_11026},
{"f_6342:optimizer_2escm",(void*)f_6342},
{"f_9704:optimizer_2escm",(void*)f_9704},
{"f_6357:optimizer_2escm",(void*)f_6357},
{"f_6354:optimizer_2escm",(void*)f_6354},
{"f_6351:optimizer_2escm",(void*)f_6351},
{"f_10446:optimizer_2escm",(void*)f_10446},
{"f_12230:optimizer_2escm",(void*)f_12230},
{"f_12232:optimizer_2escm",(void*)f_12232},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  o		1
S|  map		12
S|  for-each		20
o|eliminated procedure checks: 282 
o|eliminated procedure checks: 1 
o|eliminated procedure checks: 1 
o|eliminated procedure checks: 1 
o|specializations:
o|  1 (> fixnum fixnum)
o|  1 (set-car! pair *)
o|  2 (cddr (pair * pair))
o|  1 (length list)
o|  1 (##sys#call-with-values (procedure () *) *)
o|  1 (<= fixnum fixnum)
o|  1 (positive? fixnum)
o|  3 (third (pair * (pair * pair)))
o|  1 (fourth (pair * (pair * (pair * pair))))
o|  1 (eqv? (not float) *)
o|  1 (< fixnum fixnum)
o|  7 (second (pair * pair))
o|  1 (cdar (pair pair *))
o|  17 (= fixnum fixnum)
o|  2 (set-cdr! pair *)
o|  29 (cdr pair)
o|  13 (##sys#check-list (or pair list) *)
o|  14 (car pair)
o|  32 (first pair)
o|  63 (eqv? * (not float))
o|safe globals: (##compiler#scan-toplevel-assignments) 
o|Removed `not' forms: 31 
o|inlining procedure: k3685 
o|inlining procedure: k3685 
o|contracted procedure: k3695 
o|inlining procedure: k3734 
o|inlining procedure: k3734 
o|inlining procedure: k3781 
o|contracted procedure: k3814 
o|inlining procedure: k3781 
o|inlining procedure: k3860 
o|inlining procedure: k3860 
o|inlining procedure: k3893 
o|inlining procedure: k3893 
o|inlining procedure: k3923 
o|inlining procedure: k3923 
o|contracted procedure: "(optimizer.scm:101) g99100" 
o|substituted constant variable: a3964 
o|substituted constant variable: a3966 
o|substituted constant variable: a3971 
o|substituted constant variable: a3973 
o|substituted constant variable: a3975 
o|inlining procedure: k3979 
o|inlining procedure: k3979 
o|substituted constant variable: a3986 
o|substituted constant variable: a3988 
o|substituted constant variable: a3990 
o|substituted constant variable: a3992 
o|contracted procedure: "(optimizer.scm:65) g7475" 
o|contracted procedure: "(optimizer.scm:64) g6566" 
o|contracted procedure: "(optimizer.scm:63) g6263" 
o|inlining procedure: k4030 
o|contracted procedure: "(optimizer.scm:112) g111118" 
o|contracted procedure: "(optimizer.scm:112) g126127" 
o|inlining procedure: k4030 
o|contracted procedure: "(optimizer.scm:143) g178179" 
o|inlining procedure: k4125 
o|contracted procedure: "(optimizer.scm:134) g189196" 
o|inlining procedure: k4125 
o|inlining procedure: k4154 
o|inlining procedure: k4154 
o|inlining procedure: k4166 
o|inlining procedure: k4178 
o|inlining procedure: k4178 
o|inlining procedure: k4234 
o|inlining procedure: k4234 
o|inlining procedure: k4166 
o|contracted procedure: "(optimizer.scm:151) g216217" 
o|inlining procedure: k4280 
o|inlining procedure: k4280 
o|inlining procedure: k4309 
o|inlining procedure: k4332 
o|inlining procedure: k4332 
o|contracted procedure: "(optimizer.scm:180) node-value167" 
o|contracted procedure: "(optimizer.scm:144) g182183" 
o|inlining procedure: k4309 
o|inlining procedure: k4356 
o|contracted procedure: k4384 
o|inlining procedure: k4381 
o|contracted procedure: "(optimizer.scm:205) g301302" 
o|inlining procedure: k4381 
o|inlining procedure: k4429 
o|inlining procedure: k4429 
o|contracted procedure: "(optimizer.scm:189) g286287" 
o|contracted procedure: "(optimizer.scm:188) g282283" 
o|inlining procedure: k4356 
o|contracted procedure: "(optimizer.scm:187) g278279" 
o|substituted constant variable: a4467 
o|substituted constant variable: a4469 
o|contracted procedure: "(optimizer.scm:174) g269270" 
o|contracted procedure: "(optimizer.scm:173) g260261" 
o|inlining procedure: k4476 
o|inlining procedure: k4476 
o|inlining procedure: k4517 
o|contracted procedure: "(optimizer.scm:234) g346347" 
o|contracted procedure: k4561 
o|inlining procedure: k4558 
o|inlining procedure: k4585 
o|inlining procedure: k4585 
o|contracted procedure: "(optimizer.scm:243) g363364" 
o|inlining procedure: k4558 
o|inlining procedure: k4517 
o|inlining procedure: k4641 
o|inlining procedure: k4641 
o|contracted procedure: "(optimizer.scm:264) g390391" 
o|inlining procedure: k4687 
o|inlining procedure: k4687 
o|contracted procedure: "(optimizer.scm:261) g387388" 
o|contracted procedure: "(optimizer.scm:259) g384385" 
o|contracted procedure: "(optimizer.scm:258) g381382" 
o|inlining procedure: k4774 
o|inlining procedure: k4774 
o|inlining procedure: k4787 
o|contracted procedure: "(optimizer.scm:276) g441442" 
o|inlining procedure: k4896 
o|contracted procedure: "(optimizer.scm:292) g457458" 
o|inlining procedure: k4896 
o|inlining procedure: k4787 
o|inlining procedure: k4978 
o|propagated global variable: g518519 ##compiler#put! 
o|inlining procedure: k5011 
o|contracted procedure: "(optimizer.scm:329) g525526" 
o|inlining procedure: k5071 
o|inlining procedure: k5071 
o|contracted procedure: "(optimizer.scm:321) g496497" 
o|inlining procedure: k5011 
o|inlining procedure: k5108 
o|inlining procedure: k5108 
o|inlining procedure: k5114 
o|inlining procedure: k5129 
o|inlining procedure: k5141 
o|contracted procedure: k5156 
o|inlining procedure: k5153 
o|inlining procedure: k5153 
o|contracted procedure: "(optimizer.scm:350) g568569" 
o|contracted procedure: "(optimizer.scm:352) g573574" 
o|propagated global variable: g566567 ##compiler#expression-has-side-effects? 
o|contracted procedure: k5202 
o|inlining procedure: k5199 
o|inlining procedure: k5199 
o|inlining procedure: k5141 
o|contracted procedure: "(optimizer.scm:340) g553554" 
o|contracted procedure: "(optimizer.scm:339) g549550" 
o|inlining procedure: k5129 
o|contracted procedure: k5242 
o|contracted procedure: "(optimizer.scm:336) g544545" 
o|inlining procedure: k5114 
o|contracted procedure: "(optimizer.scm:335) g540541" 
o|inlining procedure: k5270 
o|propagated global variable: g639640 ##compiler#put! 
o|inlining procedure: k5304 
o|contracted procedure: "(optimizer.scm:391) g651652" 
o|inlining procedure: k5374 
o|inlining procedure: k5374 
o|inlining procedure: k5304 
o|inlining procedure: k5408 
o|inlining procedure: k5408 
o|inlining procedure: k5423 
o|contracted procedure: "(optimizer.scm:407) g707708" 
o|inlining procedure: k5460 
o|inlining procedure: k5460 
o|inlining procedure: k5423 
o|inlining procedure: k5508 
o|contracted procedure: "(optimizer.scm:414) g714715" 
o|inlining procedure: k5508 
o|inlining procedure: k5599 
o|contracted procedure: "(optimizer.scm:432) g733734" 
o|inlining procedure: k5662 
o|inlining procedure: k5662 
o|inlining procedure: k5703 
o|inlining procedure: k5703 
o|contracted procedure: "(optimizer.scm:442) g765766" 
o|inlining procedure: k5599 
o|inlining procedure: k5749 
o|contracted procedure: k5758 
o|contracted procedure: k5764 
o|inlining procedure: k5761 
o|inlining procedure: k5761 
o|inlining procedure: k5781 
o|inlining procedure: k5781 
o|substituted constant variable: a5792 
o|contracted procedure: "(optimizer.scm:368) g614615" 
o|inlining procedure: k5749 
o|contracted procedure: "(optimizer.scm:363) g593594" 
o|contracted procedure: "(optimizer.scm:363) g596597" 
o|contracted procedure: "(optimizer.scm:357) g584585" 
o|inlining procedure: k5270 
o|contracted procedure: "(optimizer.scm:457) g794795" 
o|contracted procedure: "(optimizer.scm:455) g791792" 
o|inlining procedure: k5853 
o|contracted procedure: "(optimizer.scm:452) g785786" 
o|contracted procedure: "(optimizer.scm:452) g788789" 
o|inlining procedure: k5853 
o|contracted procedure: "(optimizer.scm:451) g782783" 
o|contracted procedure: "(optimizer.scm:355) g580581" 
o|contracted procedure: "(optimizer.scm:332) g532533" 
o|contracted procedure: k5907 
o|inlining procedure: k5904 
o|inlining procedure: k5904 
o|contracted procedure: "(optimizer.scm:319) g492493" 
o|contracted procedure: k5934 
o|inlining procedure: k5940 
o|inlining procedure: k5940 
o|contracted procedure: "(optimizer.scm:310) g476477" 
o|inlining procedure: k5959 
o|contracted procedure: "(optimizer.scm:466) g801802" 
o|inlining procedure: k6001 
o|inlining procedure: k6001 
o|inlining procedure: k5959 
o|substituted constant variable: a6039 
o|substituted constant variable: a6041 
o|contracted procedure: "(optimizer.scm:306) g466467" 
o|inlining procedure: k4978 
o|inlining procedure: k6051 
o|contracted procedure: "(optimizer.scm:478) g846847" 
o|inlining procedure: k6051 
o|contracted procedure: "(optimizer.scm:481) g853854" 
o|inlining procedure: k6094 
o|contracted procedure: "(optimizer.scm:489) g865866" 
o|inlining procedure: k6094 
o|inlining procedure: k6134 
o|inlining procedure: k6134 
o|inlining procedure: k6159 
o|substituted constant variable: a6169 
o|inlining procedure: k6159 
o|inlining procedure: k6176 
o|substituted constant variable: a6186 
o|inlining procedure: k6176 
o|contracted procedure: "(optimizer.scm:491) g873874" 
o|contracted procedure: k6212 
o|inlining procedure: k6209 
o|inlining procedure: k6209 
o|contracted procedure: k6218 
o|substituted constant variable: a6255 
o|substituted constant variable: a6257 
o|substituted constant variable: a6259 
o|substituted constant variable: a6261 
o|substituted constant variable: a6263 
o|substituted constant variable: a6265 
o|contracted procedure: "(optimizer.scm:226) g331332" 
o|contracted procedure: "(optimizer.scm:225) g328329" 
o|contracted procedure: "(optimizer.scm:224) g325326" 
o|inlining procedure: k6275 
o|contracted procedure: "(optimizer.scm:512) g913914" 
o|inlining procedure: k6275 
o|inlining procedure: k6327 
o|inlining procedure: k6327 
o|inlining procedure: k6425 
o|contracted procedure: "(optimizer.scm:530) g926933" 
o|inlining procedure: k6396 
o|inlining procedure: k6396 
o|inlining procedure: k6425 
o|propagated global variable: g932934 ##compiler#simplified-ops 
o|inlining procedure: k6470 
o|inlining procedure: k6470 
o|inlining procedure: k6509 
o|inlining procedure: k6541 
o|contracted procedure: "(optimizer.scm:584) g10331034" 
o|contracted procedure: "(optimizer.scm:583) g10301031" 
o|contracted procedure: "(optimizer.scm:581) g10261027" 
o|inlining procedure: k6541 
o|inlining procedure: k6625 
o|contracted procedure: "(optimizer.scm:579) g10221023" 
o|inlining procedure: k6625 
o|substituted constant variable: a6643 
o|contracted procedure: "(optimizer.scm:573) g10141015" 
o|contracted procedure: "(optimizer.scm:572) g10101011" 
o|contracted procedure: "(optimizer.scm:571) g10061007" 
o|inlining procedure: k6509 
o|inlining procedure: k6676 
o|inlining procedure: k6685 
o|contracted procedure: "(optimizer.scm:570) g10021003" 
o|inlining procedure: k6685 
o|substituted constant variable: a6703 
o|substituted constant variable: a6708 
o|inlining procedure: k6676 
o|contracted procedure: k6713 
o|contracted procedure: "(optimizer.scm:564) g992993" 
o|contracted procedure: "(optimizer.scm:563) g988989" 
o|inlining procedure: k6751 
o|inlining procedure: k6751 
o|contracted procedure: "(optimizer.scm:559) g970971" 
o|contracted procedure: k6810 
o|inlining procedure: k6807 
o|inlining procedure: k6807 
o|contracted procedure: k6860 
o|inlining procedure: k6857 
o|inlining procedure: k6857 
o|contracted procedure: k6892 
o|inlining procedure: k6889 
o|inlining procedure: k6889 
o|contracted procedure: k6937 
o|inlining procedure: k6934 
o|inlining procedure: k6934 
o|inlining procedure: k6981 
o|inlining procedure: k6981 
o|inlining procedure: k7005 
o|contracted procedure: "(optimizer.scm:887) g14291430" 
o|inlining procedure: k7005 
o|contracted procedure: "(optimizer.scm:891) g14371438" 
o|contracted procedure: "(optimizer.scm:893) g14421443" 
o|contracted procedure: "(optimizer.scm:896) g14491450" 
o|contracted procedure: "(optimizer.scm:898) g14541455" 
o|inlining procedure: k7145 
o|inlining procedure: k7145 
o|inlining procedure: k7168 
o|inlining procedure: k7168 
o|inlining procedure: k7191 
o|inlining procedure: k7191 
o|inlining procedure: k7228 
o|inlining procedure: k7228 
o|removed side-effect free assignment to unused variable: test1489 
o|inlining procedure: k7343 
o|inlining procedure: k7363 
o|inlining procedure: k7363 
o|contracted procedure: "(optimizer.scm:940) g15311532" 
o|contracted procedure: "(optimizer.scm:942) g15361537" 
o|inlining procedure: k7411 
o|inlining procedure: k7423 
o|contracted procedure: "(optimizer.scm:938) g15251526" 
o|inlining procedure: k7423 
o|contracted procedure: "(optimizer.scm:937) g15221523" 
o|contracted procedure: "(optimizer.scm:937) g15191520" 
o|contracted procedure: "(optimizer.scm:936) g15151516" 
o|inlining procedure: k7411 
o|contracted procedure: "(optimizer.scm:935) g15111512" 
o|contracted procedure: "(optimizer.scm:931) g15011502" 
o|inlining procedure: k7343 
o|inlining procedure: k7499 
o|inlining procedure: k7508 
o|contracted procedure: "(optimizer.scm:952) g15521553" 
o|contracted procedure: "(optimizer.scm:956) g15571558" 
o|inlining procedure: k7508 
o|contracted procedure: "(optimizer.scm:949) g15441545" 
o|inlining procedure: k7499 
o|inlining procedure: k7571 
o|inlining procedure: k7580 
o|contracted procedure: "(optimizer.scm:966) g15731574" 
o|contracted procedure: "(optimizer.scm:967) g15781579" 
o|inlining procedure: k7580 
o|contracted procedure: "(optimizer.scm:962) g15641565" 
o|inlining procedure: k7571 
o|inlining procedure: k7669 
o|inlining procedure: k7675 
o|contracted procedure: "(optimizer.scm:976) g15901591" 
o|contracted procedure: "(optimizer.scm:975) g15871588" 
o|inlining procedure: k7675 
o|substituted constant variable: a7734 
o|inlining procedure: k7669 
o|inlining procedure: k7739 
o|inlining procedure: k7748 
o|inlining procedure: k7765 
o|contracted procedure: "(optimizer.scm:991) g16061607" 
o|contracted procedure: "(optimizer.scm:993) g16111612" 
o|inlining procedure: k7765 
o|substituted constant variable: a7826 
o|inlining procedure: k7748 
o|contracted procedure: "(optimizer.scm:987) g15971598" 
o|inlining procedure: k7739 
o|inlining procedure: k7837 
o|inlining procedure: k7849 
o|contracted procedure: "(optimizer.scm:1003) g16261627" 
o|contracted procedure: "(optimizer.scm:1005) g16311632" 
o|contracted procedure: "(optimizer.scm:1006) g16361637" 
o|contracted procedure: "(optimizer.scm:1002) g16231624" 
o|inlining procedure: k7849 
o|substituted constant variable: a7918 
o|inlining procedure: k7837 
o|inlining procedure: k7923 
o|inlining procedure: k7938 
o|inlining procedure: k7947 
o|contracted procedure: "(optimizer.scm:1015) g16511652" 
o|contracted procedure: "(optimizer.scm:1017) g16561657" 
o|inlining procedure: k7947 
o|contracted procedure: "(optimizer.scm:1014) g16481649" 
o|inlining procedure: k7938 
o|inlining procedure: k7923 
o|inlining procedure: k8019 
o|contracted procedure: "(optimizer.scm:1024) g16631664" 
o|inlining procedure: k8019 
o|inlining procedure: k8039 
o|inlining procedure: k8048 
o|contracted procedure: "(optimizer.scm:1033) g16731674" 
o|inlining procedure: k8085 
o|contracted procedure: "(optimizer.scm:1040) g17461747" 
o|contracted procedure: "(optimizer.scm:1041) g17511752" 
o|contracted procedure: "(optimizer.scm:1050) g17591760" 
o|inlining procedure: k8170 
o|inlining procedure: k8170 
o|inlining procedure: k8185 
o|inlining procedure: k8185 
o|inlining procedure: k8220 
o|contracted procedure: "(optimizer.scm:1037) g16971706" 
o|inlining procedure: k8220 
o|inlining procedure: k8085 
o|inlining procedure: k8255 
o|inlining procedure: k8255 
o|substituted constant variable: a8284 
o|inlining procedure: k8048 
o|contracted procedure: "(optimizer.scm:1031) g16701671" 
o|inlining procedure: k8039 
o|inlining procedure: k8291 
o|inlining procedure: k8303 
o|contracted procedure: "(optimizer.scm:1061) g17751776" 
o|inlining procedure: k8352 
o|inlining procedure: k8352 
o|inlining procedure: k8303 
o|contracted procedure: "(optimizer.scm:1058) g17701771" 
o|inlining procedure: k8291 
o|inlining procedure: k8378 
o|inlining procedure: k8387 
o|inlining procedure: k8408 
o|contracted procedure: "(optimizer.scm:1079) g17941795" 
o|inlining procedure: k8408 
o|contracted procedure: "(optimizer.scm:1075) g17861787" 
o|inlining procedure: k8387 
o|inlining procedure: k8378 
o|inlining procedure: k8459 
o|inlining procedure: k8473 
o|inlining procedure: k8491 
o|contracted procedure: "(optimizer.scm:1093) g18161817" 
o|inlining procedure: k8491 
o|contracted procedure: "(optimizer.scm:1094) g18211822" 
o|substituted constant variable: a8538 
o|inlining procedure: k8473 
o|contracted procedure: "(optimizer.scm:1088) g18011802" 
o|inlining procedure: k8459 
o|inlining procedure: k8543 
o|inlining procedure: k8552 
o|contracted procedure: "(optimizer.scm:1104) g18361837" 
o|contracted procedure: "(optimizer.scm:1105) g18411842" 
o|inlining procedure: k8552 
o|contracted procedure: "(optimizer.scm:1101) g18281829" 
o|inlining procedure: k8543 
o|inlining procedure: k8616 
o|inlining procedure: k8625 
o|inlining procedure: k8642 
o|contracted procedure: "(optimizer.scm:1115) g18571858" 
o|contracted procedure: "(optimizer.scm:1118) g18621863" 
o|inlining procedure: k8681 
o|inlining procedure: k8681 
o|inlining procedure: k8642 
o|inlining procedure: k8625 
o|contracted procedure: "(optimizer.scm:1112) g18491850" 
o|inlining procedure: k8616 
o|inlining procedure: k8701 
o|inlining procedure: k8710 
o|inlining procedure: k8722 
o|contracted procedure: "(optimizer.scm:1131) g18811882" 
o|inlining procedure: k8767 
o|contracted procedure: "(optimizer.scm:1134) g18861887" 
o|inlining procedure: k8767 
o|inlining procedure: k8722 
o|contracted procedure: "(optimizer.scm:1129) g18741875" 
o|propagated global variable: tmp18701872 unsafe 
o|propagated global variable: tmp18701872 unsafe 
o|inlining procedure: k8710 
o|substituted constant variable: a8800 
o|inlining procedure: k8701 
o|inlining procedure: k8826 
o|inlining procedure: k8838 
o|contracted procedure: "(optimizer.scm:1155) g19101911" 
o|contracted procedure: "(optimizer.scm:1158) g19151916" 
o|inlining procedure: k8889 
o|inlining procedure: k8889 
o|inlining procedure: k8922 
o|substituted constant variable: a8930 
o|inlining procedure: k8922 
o|propagated global variable: tmp19071909 unsafe 
o|propagated global variable: tmp19071909 unsafe 
o|inlining procedure: k8838 
o|contracted procedure: "(optimizer.scm:1153) g19031904" 
o|inlining procedure: k8826 
o|inlining procedure: k8944 
o|inlining procedure: k8953 
o|contracted procedure: "(optimizer.scm:1173) g19321933" 
o|contracted procedure: "(optimizer.scm:1176) g19371938" 
o|inlining procedure: k9000 
o|inlining procedure: k9000 
o|contracted procedure: "(optimizer.scm:1172) g19291930" 
o|inlining procedure: k8953 
o|inlining procedure: k8944 
o|inlining procedure: k9033 
o|inlining procedure: k9042 
o|contracted procedure: "(optimizer.scm:1187) g19491950" 
o|inlining procedure: k9042 
o|contracted procedure: "(optimizer.scm:1186) g19461947" 
o|inlining procedure: k9033 
o|inlining procedure: k9077 
o|inlining procedure: k9086 
o|contracted procedure: "(optimizer.scm:1205) g19741975" 
o|inlining procedure: k9132 
o|contracted procedure: "(optimizer.scm:1207) g19791980" 
o|inlining procedure: k9132 
o|contracted procedure: "(optimizer.scm:1209) g19871988" 
o|contracted procedure: "(optimizer.scm:1215) g19941995" 
o|inlining procedure: k9214 
o|contracted procedure: "(optimizer.scm:1203) g19671968" 
o|inlining procedure: k9214 
o|contracted procedure: "(optimizer.scm:1202) g19641965" 
o|inlining procedure: k9086 
o|contracted procedure: "(optimizer.scm:1196) g19561957" 
o|inlining procedure: k9077 
o|inlining procedure: k9260 
o|inlining procedure: k9272 
o|contracted procedure: "(optimizer.scm:1226) g20102011" 
o|contracted procedure: "(optimizer.scm:1229) g20152016" 
o|contracted procedure: "(optimizer.scm:1225) g20072008" 
o|inlining procedure: k9272 
o|inlining procedure: k9260 
o|inlining procedure: k9356 
o|inlining procedure: k9365 
o|contracted procedure: "(optimizer.scm:1254) g20502051" 
o|inlining procedure: k9417 
o|contracted procedure: "(optimizer.scm:1256) g20552056" 
o|inlining procedure: k9417 
o|contracted procedure: "(optimizer.scm:1258) g20602061" 
o|inlining procedure: k9464 
o|contracted procedure: "(optimizer.scm:1265) g20672068" 
o|inlining procedure: k9464 
o|contracted procedure: "(optimizer.scm:1266) g20722073" 
o|inlining procedure: k9509 
o|contracted procedure: "(optimizer.scm:1252) g20432044" 
o|inlining procedure: k9509 
o|contracted procedure: "(optimizer.scm:1251) g20402041" 
o|inlining procedure: k9365 
o|contracted procedure: "(optimizer.scm:1243) g20302031" 
o|inlining procedure: k9356 
o|inlining procedure: k9560 
o|inlining procedure: k9569 
o|contracted procedure: "(optimizer.scm:1279) g20902091" 
o|inlining procedure: k9606 
o|contracted procedure: "(optimizer.scm:1283) g20952096" 
o|inlining procedure: k9606 
o|contracted procedure: "(optimizer.scm:1287) g21002101" 
o|inlining procedure: k9569 
o|contracted procedure: "(optimizer.scm:1277) g20832084" 
o|inlining procedure: k9560 
o|inlining procedure: k9644 
o|inlining procedure: k9653 
o|contracted procedure: "(optimizer.scm:1301) g21122113" 
o|inlining procedure: k9720 
o|contracted procedure: "(optimizer.scm:1314) defarg1490" 
o|inlining procedure: k7310 
o|inlining procedure: k7310 
o|inlining procedure: k9720 
o|inlining procedure: k9653 
o|contracted procedure: "(optimizer.scm:1298) g21072108" 
o|inlining procedure: k9644 
o|substituted constant variable: a9789 
o|substituted constant variable: a9791 
o|substituted constant variable: a9793 
o|substituted constant variable: a9795 
o|substituted constant variable: a9797 
o|substituted constant variable: a9799 
o|substituted constant variable: a9801 
o|substituted constant variable: a9803 
o|substituted constant variable: a9805 
o|substituted constant variable: a9807 
o|substituted constant variable: a9809 
o|substituted constant variable: a9811 
o|substituted constant variable: a9813 
o|substituted constant variable: a9815 
o|substituted constant variable: a9817 
o|substituted constant variable: a9819 
o|substituted constant variable: a9821 
o|substituted constant variable: a9823 
o|substituted constant variable: a9825 
o|substituted constant variable: a9827 
o|substituted constant variable: a9829 
o|substituted constant variable: a9831 
o|substituted constant variable: a9833 
o|inlining procedure: k9864 
o|inlining procedure: k9889 
o|contracted procedure: k9897 
o|inlining procedure: k9900 
o|inlining procedure: k9915 
o|inlining procedure: k9924 
o|contracted procedure: k9933 
o|inlining procedure: k9936 
o|inlining procedure: k9936 
o|contracted procedure: "(optimizer.scm:1351) g21752176" 
o|contracted procedure: "(optimizer.scm:1352) g21792180" 
o|inlining procedure: k9924 
o|inlining procedure: k9915 
o|inlining procedure: k9900 
o|inlining procedure: k9889 
o|inlining procedure: k9864 
o|inlining procedure: k10008 
o|inlining procedure: k10008 
o|inlining procedure: k10046 
o|inlining procedure: k10046 
o|substituted constant variable: a10067 
o|substituted constant variable: a10069 
o|substituted constant variable: a10071 
o|contracted procedure: "(optimizer.scm:1339) g21622163" 
o|contracted procedure: "(optimizer.scm:1338) g21532154" 
o|contracted procedure: "(optimizer.scm:1337) g21502151" 
o|inlining procedure: k10102 
o|inlining procedure: k10120 
o|inlining procedure: k10120 
o|contracted procedure: k10126 
o|inlining procedure: k10102 
o|inlining procedure: k10147 
o|inlining procedure: k10147 
o|inlining procedure: k10175 
o|contracted procedure: k10184 
o|inlining procedure: k10175 
o|inlining procedure: k10210 
o|inlining procedure: k10216 
o|inlining procedure: k10216 
o|inlining procedure: k10210 
o|inlining procedure: k10234 
o|contracted procedure: k10264 
o|inlining procedure: k10261 
o|inlining procedure: k10261 
o|inlining procedure: k10234 
o|inlining procedure: k10281 
o|inlining procedure: k10281 
o|contracted procedure: k10305 
o|inlining procedure: k10302 
o|inlining procedure: k10302 
o|inlining procedure: k10316 
o|inlining procedure: k10331 
o|inlining procedure: k10331 
o|inlining procedure: k10354 
o|contracted procedure: "(optimizer.scm:1421) g22872288" 
o|contracted procedure: "(optimizer.scm:1420) g22842285" 
o|inlining procedure: k10354 
o|contracted procedure: "(optimizer.scm:1416) g22752276" 
o|contracted procedure: "(optimizer.scm:1415) g22702271" 
o|inlining procedure: k10316 
o|inlining procedure: k10429 
o|inlining procedure: k10429 
o|contracted procedure: k10435 
o|inlining procedure: k10451 
o|inlining procedure: k10451 
o|inlining procedure: k10474 
o|inlining procedure: k10474 
o|substituted constant variable: a10509 
o|substituted constant variable: a10511 
o|substituted constant variable: a10513 
o|substituted constant variable: a10515 
o|substituted constant variable: a10517 
o|substituted constant variable: a10519 
o|substituted constant variable: a10521 
o|substituted constant variable: a10523 
o|substituted constant variable: a10525 
o|substituted constant variable: a10527 
o|contracted procedure: "(optimizer.scm:1370) g22282229" 
o|contracted procedure: "(optimizer.scm:1369) g22192220" 
o|contracted procedure: "(optimizer.scm:1368) g22162217" 
o|inlining procedure: k10531 
o|inlining procedure: k10531 
o|contracted procedure: "(optimizer.scm:1527) g24622463" 
o|contracted procedure: "(optimizer.scm:1519) g24592460" 
o|inlining procedure: k10568 
o|inlining procedure: k10726 
o|contracted procedure: "(optimizer.scm:1548) g25112518" 
o|contracted procedure: "(optimizer.scm:1552) g25252526" 
o|contracted procedure: "(optimizer.scm:1552) g25222523" 
o|inlining procedure: k10726 
o|contracted procedure: "(optimizer.scm:1540) g24852486" 
o|contracted procedure: "(optimizer.scm:1543) g24942495" 
o|contracted procedure: "(optimizer.scm:1543) g25052506" 
o|contracted procedure: "(optimizer.scm:1543) g25022503" 
o|contracted procedure: "(optimizer.scm:1543) g24992500" 
o|contracted procedure: "(optimizer.scm:1542) g24912492" 
o|contracted procedure: "(optimizer.scm:1535) g24772478" 
o|inlining procedure: k10825 
o|inlining procedure: k10825 
o|inlining procedure: k10890 
o|inlining procedure: k10924 
o|contracted procedure: "(optimizer.scm:1496) g23862387" 
o|contracted procedure: "(optimizer.scm:1493) g23832384" 
o|contracted procedure: "(optimizer.scm:1487) g23802381" 
o|inlining procedure: k10976 
o|inlining procedure: k10976 
o|inlining procedure: k10924 
o|contracted procedure: "(optimizer.scm:1473) g23592360" 
o|contracted procedure: "(optimizer.scm:1472) g23562357" 
o|contracted procedure: "(optimizer.scm:1471) g23522353" 
o|inlining procedure: k10890 
o|inlining procedure: k11123 
o|inlining procedure: k11123 
o|inlining procedure: k11149 
o|inlining procedure: k11149 
o|inlining procedure: k11178 
o|inlining procedure: k11178 
o|substituted constant variable: a11199 
o|substituted constant variable: a11201 
o|contracted procedure: "(optimizer.scm:1467) g23462347" 
o|contracted procedure: "(optimizer.scm:1466) g23372338" 
o|contracted procedure: "(optimizer.scm:1465) g23342335" 
o|contracted procedure: "(optimizer.scm:1464) g24412442" 
o|inlining procedure: k10568 
o|inlining procedure: k11221 
o|inlining procedure: k11221 
o|substituted constant variable: a11236 
o|contracted procedure: "(optimizer.scm:1449) g23152316" 
o|inlining procedure: k11285 
o|substituted constant variable: a11307 
o|inlining procedure: k11285 
o|inlining procedure: k11369 
o|inlining procedure: k11398 
o|inlining procedure: k11398 
o|inlining procedure: k11428 
o|inlining procedure: k11446 
o|contracted procedure: "(optimizer.scm:1619) user-lambda?2556" 
o|inlining procedure: k11311 
o|contracted procedure: "(optimizer.scm:1594) g25652566" 
o|inlining procedure: k11311 
o|contracted procedure: "(optimizer.scm:1593) g25622563" 
o|inlining procedure: k11446 
o|inlining procedure: k11473 
o|inlining procedure: k11473 
o|inlining procedure: k11480 
o|inlining procedure: k11480 
o|contracted procedure: "(optimizer.scm:1615) g26142615" 
o|contracted procedure: "(optimizer.scm:1613) g26102611" 
o|contracted procedure: "(optimizer.scm:1612) g26072608" 
o|inlining procedure: k11428 
o|contracted procedure: "(optimizer.scm:1611) g26022603" 
o|contracted procedure: k11519 
o|contracted procedure: "(optimizer.scm:1606) g25962597" 
o|inlining procedure: k11369 
o|inlining procedure: k11597 
o|inlining procedure: k11597 
o|substituted constant variable: a11621 
o|substituted constant variable: a11623 
o|substituted constant variable: a11625 
o|contracted procedure: "(optimizer.scm:1599) g25792580" 
o|contracted procedure: "(optimizer.scm:1598) g25762577" 
o|contracted procedure: "(optimizer.scm:1597) g25732574" 
o|contracted procedure: "(optimizer.scm:1670) g27672768" 
o|contracted procedure: "(optimizer.scm:1666) g27642765" 
o|inlining procedure: k11709 
o|inlining procedure: k11709 
o|contracted procedure: "(optimizer.scm:1660) g27282729" 
o|contracted procedure: "(optimizer.scm:1659) g27242725" 
o|contracted procedure: "(optimizer.scm:1658) g27202721" 
o|contracted procedure: "(optimizer.scm:1748) g29392940" 
o|contracted procedure: "(optimizer.scm:1749) g29442945" 
o|contracted procedure: "(optimizer.scm:1746) g29362937" 
o|inlining procedure: k11874 
o|inlining procedure: k11874 
o|inlining procedure: k11904 
o|inlining procedure: k11904 
o|inlining procedure: k11930 
o|inlining procedure: k11930 
o|contracted procedure: "(optimizer.scm:1694) g28572858" 
o|contracted procedure: "(optimizer.scm:1699) g28672868" 
o|contracted procedure: "(optimizer.scm:1731) g29002901" 
o|contracted procedure: "(optimizer.scm:1702) g28722873" 
o|contracted procedure: "(optimizer.scm:1705) g28772878" 
o|contracted procedure: "(optimizer.scm:1710) g28822883" 
o|contracted procedure: "(optimizer.scm:1727) g28972898" 
o|inlining procedure: k12117 
o|inlining procedure: k12117 
o|contracted procedure: "(optimizer.scm:1722) g28912892" 
o|contracted procedure: "(optimizer.scm:1698) g28622863" 
o|contracted procedure: "(optimizer.scm:1690) g28542855" 
o|contracted procedure: "(optimizer.scm:1689) g28512852" 
o|contracted procedure: "(optimizer.scm:1688) g28472848" 
o|contracted procedure: "(optimizer.scm:1687) g28432844" 
o|inlining procedure: k12234 
o|inlining procedure: k12234 
o|inlining procedure: k12299 
o|contracted procedure: "(optimizer.scm:1675) g27912800" 
o|inlining procedure: k12299 
o|inlining procedure: k12334 
o|inlining procedure: k12334 
o|inlining procedure: k12382 
o|inlining procedure: k12382 
o|inlining procedure: "(optimizer.scm:770) register-simplifications" 
o|inlining procedure: k12424 
o|inlining procedure: k12433 
o|contracted procedure: "(optimizer.scm:803) g12691270" 
o|contracted procedure: "(optimizer.scm:807) g12741275" 
o|contracted procedure: "(optimizer.scm:812) g12811282" 
o|contracted procedure: "(optimizer.scm:815) g12861287" 
o|inlining procedure: k12433 
o|inlining procedure: k12424 
o|inlining procedure: k12557 
o|contracted procedure: "(optimizer.scm:784) g12461247" 
o|contracted procedure: "(optimizer.scm:787) g12511252" 
o|inlining procedure: k12557 
o|inlining procedure: "(optimizer.scm:625) register-simplifications" 
o|contracted procedure: k12643 
o|inlining procedure: k12640 
o|inlining procedure: k12640 
o|contracted procedure: "(optimizer.scm:764) g12241225" 
o|contracted procedure: "(optimizer.scm:766) g12291230" 
o|substituted constant variable: a12677 
o|inlining procedure: k12763 
o|contracted procedure: k12778 
o|inlining procedure: k12775 
o|inlining procedure: k12775 
o|contracted procedure: k12784 
o|inlining procedure: k12814 
o|inlining procedure: k12814 
o|inlining procedure: k12842 
o|inlining procedure: k12894 
o|contracted procedure: "(optimizer.scm:726) g12041205" 
o|inlining procedure: k12894 
o|inlining procedure: k12954 
o|inlining procedure: k12954 
o|inlining procedure: k12960 
o|contracted procedure: k12969 
o|contracted procedure: k12975 
o|inlining procedure: k12972 
o|inlining procedure: k12972 
o|inlining procedure: k12984 
o|contracted procedure: "(optimizer.scm:725) g12011202" 
o|inlining procedure: k12984 
o|contracted procedure: "(optimizer.scm:724) g11981199" 
o|inlining procedure: k12960 
o|contracted procedure: "(optimizer.scm:718) g11851186" 
o|contracted procedure: "(optimizer.scm:717) g11821183" 
o|contracted procedure: "(optimizer.scm:716) g11791180" 
o|inlining procedure: k12842 
o|substituted constant variable: a13050 
o|substituted constant variable: a13052 
o|contracted procedure: "(optimizer.scm:707) g11661167" 
o|contracted procedure: "(optimizer.scm:706) g11571158" 
o|contracted procedure: "(optimizer.scm:705) g11531154" 
o|inlining procedure: k12763 
o|contracted procedure: "(optimizer.scm:699) g11441145" 
o|contracted procedure: "(optimizer.scm:698) g11411142" 
o|contracted procedure: "(optimizer.scm:697) g11381139" 
o|inlining procedure: k13088 
o|inlining procedure: k13100 
o|contracted procedure: "(optimizer.scm:674) g11211122" 
o|inlining procedure: k13100 
o|substituted constant variable: a13134 
o|inlining procedure: k13088 
o|inlining procedure: k13218 
o|inlining procedure: k13230 
o|inlining procedure: k13242 
o|contracted procedure: "(optimizer.scm:649) g11011102" 
o|inlining procedure: k13242 
o|substituted constant variable: a13272 
o|substituted constant variable: a13281 
o|inlining procedure: k13230 
o|inlining procedure: k13218 
o|inlining procedure: "(optimizer.scm:607) register-simplifications" 
o|inlining procedure: k13402 
o|inlining procedure: k13402 
o|inlining procedure: k13419 
o|inlining procedure: k13419 
o|replaced variables: 1967 
o|removed binding forms: 607 
o|substituted constant variable: c101 
o|substituted constant variable: p102 
o|substituted constant variable: s103 
o|substituted constant variable: tmp132135 
o|substituted constant variable: mark134 
o|substituted constant variable: r417913502 
o|substituted constant variable: r416713505 
o|inlining procedure: k4309 
o|substituted constant variable: c303 
o|inlining procedure: k4309 
o|substituted constant variable: r443013520 
o|inlining procedure: k4309 
o|inlining procedure: k4309 
o|substituted constant variable: mark366 
o|substituted constant variable: c392 
o|substituted constant variable: r477513535 
o|substituted constant variable: c443 
o|substituted constant variable: c459 
o|substituted constant variable: r515413550 
o|substituted constant variable: c570 
o|substituted constant variable: c575 
o|substituted constant variable: p576 
o|substituted constant variable: s577 
o|substituted constant variable: r520013552 
o|substituted constant variable: r514213554 
o|substituted constant variable: r513013555 
o|substituted constant variable: r511513556 
o|converted assignments to bindings: (cfk647) 
o|substituted constant variable: c709 
o|substituted constant variable: c716 
o|substituted constant variable: c735 
o|substituted constant variable: c767 
o|substituted constant variable: r576213579 
o|substituted constant variable: mark617 
o|substituted constant variable: r575013583 
o|substituted constant variable: mark599 
o|substituted constant variable: c796 
o|substituted constant variable: r585413586 
o|substituted constant variable: mark535 
o|substituted constant variable: r590513587 
o|substituted constant variable: c803 
o|substituted constant variable: c848 
o|substituted constant variable: p849 
o|substituted constant variable: s850 
o|substituted constant variable: c855 
o|substituted constant variable: p856 
o|substituted constant variable: s857 
o|substituted constant variable: c867 
o|substituted constant variable: p868 
o|substituted constant variable: s869 
o|substituted constant variable: c875 
o|substituted constant variable: r621013606 
o|substituted constant variable: r662613624 
o|substituted constant variable: r668613628 
o|substituted constant variable: r667713629 
o|substituted constant variable: sym972 
o|substituted constant variable: r680813632 
o|substituted constant variable: r689013636 
o|substituted constant variable: r693513638 
o|substituted constant variable: c1431 
o|substituted constant variable: c1439 
o|substituted constant variable: c1444 
o|substituted constant variable: p1445 
o|substituted constant variable: s1446 
o|substituted constant variable: c1451 
o|substituted constant variable: c1456 
o|converted assignments to bindings: (find-path1339) 
o|substituted constant variable: c1533 
o|substituted constant variable: c1538 
o|substituted constant variable: c1527 
o|substituted constant variable: r742413657 
o|substituted constant variable: r741213658 
o|substituted constant variable: c1554 
o|substituted constant variable: c1559 
o|substituted constant variable: r750913662 
o|substituted constant variable: r750013663 
o|substituted constant variable: c1575 
o|substituted constant variable: c1580 
o|substituted constant variable: r758113666 
o|substituted constant variable: c1592 
o|substituted constant variable: r767613670 
o|substituted constant variable: r767013671 
o|substituted constant variable: c1608 
o|substituted constant variable: c1613 
o|substituted constant variable: r776613675 
o|substituted constant variable: r774913676 
o|substituted constant variable: c1628 
o|substituted constant variable: c1633 
o|substituted constant variable: c1638 
o|substituted constant variable: r785013680 
o|substituted constant variable: r783813681 
o|substituted constant variable: c1653 
o|substituted constant variable: c1658 
o|substituted constant variable: r794813685 
o|substituted constant variable: r793913686 
o|substituted constant variable: r802013689 
o|substituted constant variable: c1675 
o|substituted constant variable: c1748 
o|substituted constant variable: c1753 
o|substituted constant variable: c1761 
o|substituted constant variable: r808613701 
o|substituted constant variable: r804913704 
o|substituted constant variable: c1777 
o|substituted constant variable: r830413712 
o|substituted constant variable: r829213713 
o|substituted constant variable: c1796 
o|substituted constant variable: r840913717 
o|substituted constant variable: r838813718 
o|substituted constant variable: c1818 
o|substituted constant variable: c1823 
o|substituted constant variable: r847413724 
o|substituted constant variable: r846013725 
o|substituted constant variable: c1838 
o|substituted constant variable: c1843 
o|substituted constant variable: s1845 
o|substituted constant variable: r855313728 
o|substituted constant variable: c1859 
o|substituted constant variable: c1864 
o|substituted constant variable: r864313737 
o|substituted constant variable: r862613738 
o|substituted constant variable: r861713739 
o|substituted constant variable: c1883 
o|substituted constant variable: c1888 
o|substituted constant variable: r876813744 
o|substituted constant variable: r872313745 
o|substituted constant variable: r871113746 
o|substituted constant variable: c1912 
o|substituted constant variable: c1917 
o|inlining procedure: k8889 
o|substituted constant variable: r892313755 
o|substituted constant variable: r883913756 
o|substituted constant variable: r882713757 
o|substituted constant variable: c1934 
o|substituted constant variable: c1939 
o|substituted constant variable: r895413764 
o|substituted constant variable: c1951 
o|substituted constant variable: r904313768 
o|substituted constant variable: r903413769 
o|substituted constant variable: c1976 
o|substituted constant variable: c1981 
o|substituted constant variable: c1989 
o|substituted constant variable: c1996 
o|substituted constant variable: r921513775 
o|substituted constant variable: r908713776 
o|substituted constant variable: c2012 
o|substituted constant variable: c2017 
o|substituted constant variable: r927313780 
o|substituted constant variable: r926113781 
o|substituted constant variable: c2052 
o|substituted constant variable: c2057 
o|substituted constant variable: c2062 
o|substituted constant variable: c2069 
o|substituted constant variable: c2074 
o|substituted constant variable: r951013789 
o|substituted constant variable: r936613790 
o|substituted constant variable: c2092 
o|substituted constant variable: c2097 
o|substituted constant variable: c2102 
o|substituted constant variable: r957013798 
o|substituted constant variable: r956113799 
o|substituted constant variable: c2114 
o|substituted constant variable: r965413806 
o|substituted constant variable: r993713814 
o|substituted constant variable: mark2178 
o|substituted constant variable: r992513815 
o|substituted constant variable: r991613816 
o|substituted constant variable: r990113817 
o|substituted constant variable: r989013818 
o|substituted constant variable: r1014813829 
o|substituted constant variable: r1021713833 
o|substituted constant variable: r1021713834 
o|substituted constant variable: r1021113835 
o|substituted constant variable: r1026213837 
o|substituted constant variable: r1026213838 
o|substituted constant variable: r1028213841 
o|substituted constant variable: r1030313842 
o|substituted constant variable: r1030313843 
o|substituted constant variable: r1033213846 
o|substituted constant variable: r1035513847 
o|inlining procedure: k10363 
o|inlining procedure: k10363 
o|substituted constant variable: r1035513848 
o|substituted constant variable: r1047513855 
o|substituted constant variable: r1053213857 
o|substituted constant variable: c2464 
o|substituted constant variable: c2527 
o|substituted constant variable: p2528 
o|substituted constant variable: s2529 
o|substituted constant variable: c2487 
o|substituted constant variable: c2479 
o|substituted constant variable: p2480 
o|substituted constant variable: s2481 
o|substituted constant variable: c2388 
o|substituted constant variable: r1122213877 
o|inlining procedure: k11291 
o|inlining procedure: k11291 
o|substituted constant variable: r1131213886 
o|substituted constant variable: r1144713887 
o|substituted constant variable: r1147413890 
o|substituted constant variable: r1147413890 
o|folded constant expression: (length (quote ())) 
o|substituted constant variable: r1148113894 
o|substituted constant variable: r1148113894 
o|folded constant expression: (length (quote ())) 
o|substituted constant variable: r1142913896 
o|substituted constant variable: c2769 
o|substituted constant variable: p2770 
o|substituted constant variable: s2771 
o|substituted constant variable: c2941 
o|substituted constant variable: c2859 
o|substituted constant variable: c2869 
o|substituted constant variable: c2902 
o|substituted constant variable: p2903 
o|substituted constant variable: c2874 
o|substituted constant variable: c2879 
o|substituted constant variable: c2884 
o|substituted constant variable: c2893 
o|substituted constant variable: c2864 
o|substituted constant variable: p2865 
o|substituted constant variable: s2866 
o|substituted constant variable: class105413919 
o|substituted constant variable: c1271 
o|substituted constant variable: c1276 
o|substituted constant variable: c1283 
o|substituted constant variable: p1284 
o|substituted constant variable: c1288 
o|substituted constant variable: r1243413926 
o|substituted constant variable: r1242513927 
o|substituted constant variable: c1248 
o|substituted constant variable: c1253 
o|substituted constant variable: p1254 
o|substituted constant variable: r1255813929 
o|substituted constant variable: class105413931 
o|substituted constant variable: r1264113936 
o|substituted constant variable: c1226 
o|substituted constant variable: c1231 
o|substituted constant variable: r1277613939 
o|substituted constant variable: r1295513947 
o|substituted constant variable: r1297313949 
o|substituted constant variable: r1298513952 
o|substituted constant variable: r1296113953 
o|substituted constant variable: r1284313954 
o|substituted constant variable: r1276413955 
o|substituted constant variable: c1123 
o|substituted constant variable: r1310113958 
o|substituted constant variable: r1308913959 
o|substituted constant variable: c1103 
o|substituted constant variable: p1104 
o|substituted constant variable: r1324313963 
o|substituted constant variable: r1323113964 
o|substituted constant variable: r1321913965 
o|substituted constant variable: class105413967 
o|substituted constant variable: r1340313972 
o|simplifications: ((let . 2)) 
o|replaced variables: 167 
o|removed binding forms: 1860 
o|inlining procedure: k4006 
o|inlining procedure: k4187 
o|inlining procedure: k4151 
o|inlining procedure: k6060 
o|inlining procedure: k6355 
o|removed call to pure procedure with unused result: "(optimizer.scm:1037) slot" 
o|inlining procedure: k9003 
o|substituted constant variable: r103551384714060 
o|substituted constant variable: r103551384714063 
o|inlining procedure: k11466 
o|replaced variables: 320 
o|removed binding forms: 419 
o|substituted constant variable: r400714138 
o|substituted constant variable: r415214149 
o|substituted constant variable: r415214149 
o|substituted constant variable: r415214149 
o|contracted procedure: k8249 
o|substituted constant variable: r900414194 
o|substituted constant variable: r1146714211 
o|replaced variables: 3 
o|removed binding forms: 329 
o|removed conditional forms: 2 
o|inlining procedure: "(optimizer.scm:177) constant-node?166" 
o|removed binding forms: 8 
o|replaced variables: 1 
o|removed binding forms: 1 
o|simplifications: ((if . 36) (##core#call . 1226)) 
o|  call simplifications:
o|    ##sys#cons	9
o|    assoc
o|    -
o|    fx>
o|    ##sys#list	74
o|    list?	3
o|    set-car!
o|    >=
o|    symbol?
o|    cddddr
o|    fx<=
o|    <=
o|    fx<
o|    =	10
o|    equal?	4
o|    proper-list?	3
o|    >	5
o|    values	6
o|    ##sys#structure?
o|    *	2
o|    length	40
o|    <	5
o|    zero?	5
o|    sub1	5
o|    ##sys#call-with-values	5
o|    fourth	16
o|    +	7
o|    cddr	6
o|    list	144
o|    caddr	2
o|    cadr	3
o|    third	29
o|    ##sys#setslot	15
o|    apply	2
o|    caar	2
o|    assq	10
o|    alist-cons	10
o|    cdr	31
o|    add1	9
o|    set-cdr!	3
o|    null?	21
o|    ##sys#make-structure	99
o|    second	44
o|    first	94
o|    car	25
o|    eq?	142
o|    ##sys#check-list	21
o|    pair?	49
o|    ##sys#slot	178
o|    memq	14
o|    not	19
o|    cons	44
o|contracted procedure: k3692 
o|contracted procedure: k3702 
o|contracted procedure: k3725 
o|contracted procedure: k3737 
o|contracted procedure: k3747 
o|contracted procedure: k3751 
o|contracted procedure: k3762 
o|contracted procedure: k3770 
o|contracted procedure: k3778 
o|contracted procedure: k3784 
o|contracted procedure: k3787 
o|contracted procedure: k3804 
o|contracted procedure: k3811 
o|contracted procedure: k3825 
o|contracted procedure: k3821 
o|contracted procedure: k3831 
o|contracted procedure: k3851 
o|contracted procedure: k3857 
o|contracted procedure: k3863 
o|contracted procedure: k3887 
o|contracted procedure: k3890 
o|contracted procedure: k3896 
o|contracted procedure: k3905 
o|contracted procedure: k3908 
o|contracted procedure: k3911 
o|contracted procedure: k3929 
o|contracted procedure: k3950 
o|contracted procedure: k3957 
o|contracted procedure: k3976 
o|contracted procedure: k4021 
o|contracted procedure: k4033 
o|contracted procedure: k4043 
o|contracted procedure: k4047 
o|contracted procedure: k4012 
o|contracted procedure: k4006 
o|contracted procedure: k4050 
o|contracted procedure: k4086 
o|contracted procedure: k4116 
o|contracted procedure: k4128 
o|contracted procedure: k4142 
o|contracted procedure: k4131 
o|contracted procedure: k4138 
o|contracted procedure: k4163 
o|contracted procedure: k4181 
o|contracted procedure: k4184 
o|contracted procedure: k4204 
o|contracted procedure: k4200 
o|contracted procedure: k4187 
o|contracted procedure: k4208 
o|contracted procedure: k4212 
o|contracted procedure: k4222 
o|contracted procedure: k4225 
o|contracted procedure: k4237 
o|contracted procedure: k4240 
o|contracted procedure: k4251 
o|contracted procedure: k4263 
o|contracted procedure: k4274 
o|contracted procedure: k4283 
o|contracted procedure: k4298 
o|contracted procedure: k4306 
o|contracted procedure: k4312 
o|contracted procedure: k4322 
o|contracted procedure: k4332 
o|contracted procedure: k4101 
o|contracted procedure: k4347 
o|contracted procedure: k408614336 
o|contracted procedure: k4353 
o|contracted procedure: k4463 
o|contracted procedure: k4459 
o|contracted procedure: k4359 
o|contracted procedure: k4448 
o|contracted procedure: k4362 
o|contracted procedure: k4375 
o|contracted procedure: k4410 
o|contracted procedure: k4418 
o|contracted procedure: k4414 
o|contracted procedure: k4439 
o|contracted procedure: k4498 
o|contracted procedure: k4506 
o|contracted procedure: k4514 
o|contracted procedure: k4520 
o|contracted procedure: k4551 
o|contracted procedure: k4542 
o|contracted procedure: k4623 
o|contracted procedure: k4574 
o|contracted procedure: k4582 
o|contracted procedure: k4604 
o|contracted procedure: k4568 
o|contracted procedure: k4629 
o|contracted procedure: k4635 
o|contracted procedure: k4638 
o|contracted procedure: k4654 
o|contracted procedure: k4661 
o|contracted procedure: k4690 
o|contracted procedure: k4693 
o|contracted procedure: k4704 
o|contracted procedure: k4716 
o|contracted procedure: k4735 
o|contracted procedure: k4726 
o|contracted procedure: k4771 
o|contracted procedure: k4767 
o|contracted procedure: k4740 
o|contracted procedure: k4756 
o|contracted procedure: k4747 
o|contracted procedure: k4790 
o|contracted procedure: k4793 
o|contracted procedure: k4862 
o|contracted procedure: k4866 
o|contracted procedure: k4874 
o|contracted procedure: k4842 
o|contracted procedure: k4846 
o|contracted procedure: k4854 
o|contracted procedure: k4858 
o|contracted procedure: k4887 
o|contracted procedure: k4943 
o|contracted procedure: k4947 
o|contracted procedure: k4955 
o|contracted procedure: k4923 
o|contracted procedure: k4927 
o|contracted procedure: k4935 
o|contracted procedure: k4939 
o|contracted procedure: k4959 
o|contracted procedure: k4966 
o|contracted procedure: k4972 
o|contracted procedure: k4981 
o|contracted procedure: k4984 
o|contracted procedure: k4992 
o|contracted procedure: k4998 
o|contracted procedure: k5956 
o|contracted procedure: k5001 
o|contracted procedure: k5022 
o|contracted procedure: k5025 
o|contracted procedure: k5042 
o|contracted procedure: k5065 
o|contracted procedure: k5056 
o|contracted procedure: k5074 
o|contracted procedure: k5084 
o|contracted procedure: k5088 
o|contracted procedure: k5102 
o|contracted procedure: k5267 
o|contracted procedure: k5117 
o|contracted procedure: k5258 
o|contracted procedure: k5120 
o|contracted procedure: k5239 
o|contracted procedure: k5135 
o|contracted procedure: k5230 
o|contracted procedure: k5138 
o|contracted procedure: k5171 
o|contracted procedure: k5184 
o|contracted procedure: k5175 
o|contracted procedure: k5221 
o|contracted procedure: k5281 
o|contracted procedure: k5284 
o|contracted procedure: k5293 
o|contracted procedure: k5301 
o|contracted procedure: k5318 
o|contracted procedure: k5368 
o|contracted procedure: k5359 
o|contracted procedure: k5377 
o|contracted procedure: k5387 
o|contracted procedure: k5391 
o|contracted procedure: k5395 
o|contracted procedure: k5399 
o|contracted procedure: k5596 
o|contracted procedure: k5411 
o|contracted procedure: k5426 
o|contracted procedure: k5429 
o|contracted procedure: k5440 
o|contracted procedure: k5463 
o|contracted procedure: k5466 
o|contracted procedure: k5477 
o|contracted procedure: k5489 
o|contracted procedure: k5523 
o|contracted procedure: k5527 
o|contracted procedure: k5541 
o|contracted procedure: k5558 
o|contracted procedure: k5564 
o|contracted procedure: k5575 
o|contracted procedure: k5579 
o|contracted procedure: k5583 
o|contracted procedure: k5589 
o|contracted procedure: k5733 
o|contracted procedure: k5611 
o|contracted procedure: k5653 
o|contracted procedure: k5637 
o|contracted procedure: k5641 
o|contracted procedure: k5665 
o|contracted procedure: k5668 
o|contracted procedure: k5679 
o|contracted procedure: k5691 
o|contracted procedure: k5699 
o|contracted procedure: k5706 
o|contracted procedure: k5729 
o|contracted procedure: k5725 
o|contracted procedure: k5721 
o|contracted procedure: k5746 
o|contracted procedure: k5778 
o|contracted procedure: k5788 
o|contracted procedure: k5832 
o|contracted procedure: k5828 
o|contracted procedure: k5847 
o|contracted procedure: k5838 
o|contracted procedure: k5886 
o|contracted procedure: k5856 
o|contracted procedure: k5877 
o|contracted procedure: k5868 
o|contracted procedure: k5898 
o|contracted procedure: k5927 
o|contracted procedure: k5918 
o|contracted procedure: k5962 
o|contracted procedure: k5968 
o|contracted procedure: k5986 
o|contracted procedure: k5979 
o|contracted procedure: k6004 
o|contracted procedure: k6007 
o|contracted procedure: k6018 
o|contracted procedure: k6030 
o|contracted procedure: k6045 
o|contracted procedure: k6048 
o|contracted procedure: k6192 
o|contracted procedure: k6119 
o|contracted procedure: k6122 
o|contracted procedure: k6171 
o|contracted procedure: k6162 
o|contracted procedure: k6188 
o|contracted procedure: k6179 
o|contracted procedure: k6125 
o|contracted procedure: k6137 
o|contracted procedure: k6147 
o|contracted procedure: k6151 
o|contracted procedure: k6200 
o|contracted procedure: k6203 
o|contracted procedure: k6229 
o|contracted procedure: k6278 
o|contracted procedure: k6315 
o|contracted procedure: k6324 
o|contracted procedure: k6361 
o|contracted procedure: k6367 
o|contracted procedure: k6373 
o|contracted procedure: k6379 
o|contracted procedure: k6416 
o|contracted procedure: k6428 
o|contracted procedure: k6438 
o|contracted procedure: k6442 
o|contracted procedure: k6399 
o|contracted procedure: k6413 
o|propagated global variable: g932934 ##compiler#simplified-ops 
o|contracted procedure: k6445 
o|contracted procedure: k6473 
o|contracted procedure: k6489 
o|contracted procedure: k6497 
o|contracted procedure: k6733 
o|contracted procedure: k6729 
o|contracted procedure: k6500 
o|contracted procedure: k6673 
o|contracted procedure: k6515 
o|contracted procedure: k6664 
o|contracted procedure: k6518 
o|contracted procedure: k6526 
o|contracted procedure: k6535 
o|contracted procedure: k6622 
o|contracted procedure: k6547 
o|contracted procedure: k6557 
o|contracted procedure: k6577 
o|contracted procedure: k6573 
o|contracted procedure: k6613 
o|contracted procedure: k6588 
o|contracted procedure: k6604 
o|contracted procedure: k6595 
o|contracted procedure: k6645 
o|contracted procedure: k6628 
o|contracted procedure: k6640 
o|contracted procedure: k6648 
o|contracted procedure: k6655 
o|contracted procedure: k6710 
o|contracted procedure: k6682 
o|contracted procedure: k6705 
o|contracted procedure: k6688 
o|contracted procedure: k6700 
o|contracted procedure: k6739 
o|contracted procedure: k6742 
o|contracted procedure: k6754 
o|contracted procedure: k6764 
o|contracted procedure: k6768 
o|contracted procedure: k6789 
o|contracted procedure: k6792 
o|contracted procedure: k6839 
o|contracted procedure: k6835 
o|contracted procedure: k6813 
o|contracted procedure: k6816 
o|contracted procedure: k6822 
o|contracted procedure: k6845 
o|contracted procedure: k6909 
o|contracted procedure: k6883 
o|contracted procedure: k6867 
o|contracted procedure: k6875 
o|contracted procedure: k6905 
o|contracted procedure: k6917 
o|contracted procedure: k6924 
o|contracted procedure: k6952 
o|contracted procedure: k6948 
o|contracted procedure: k6969 
o|contracted procedure: k6984 
o|contracted procedure: k7139 
o|contracted procedure: k6999 
o|contracted procedure: k7002 
o|contracted procedure: k7012 
o|contracted procedure: k7032 
o|contracted procedure: k7028 
o|contracted procedure: k7024 
o|contracted procedure: k7050 
o|contracted procedure: k7063 
o|contracted procedure: k7054 
o|contracted procedure: k7082 
o|contracted procedure: k7099 
o|contracted procedure: k7111 
o|contracted procedure: k7107 
o|contracted procedure: k7103 
o|contracted procedure: k7095 
o|contracted procedure: k7086 
o|contracted procedure: k7118 
o|contracted procedure: k7133 
o|contracted procedure: k7129 
o|contracted procedure: k7125 
o|contracted procedure: k7148 
o|contracted procedure: k7158 
o|contracted procedure: k7162 
o|contracted procedure: k7171 
o|contracted procedure: k7181 
o|contracted procedure: k7185 
o|contracted procedure: k7219 
o|contracted procedure: k7194 
o|contracted procedure: k7204 
o|contracted procedure: k7208 
o|contracted procedure: k7212 
o|contracted procedure: k7216 
o|contracted procedure: k7268 
o|contracted procedure: k7231 
o|contracted procedure: k7261 
o|contracted procedure: k7265 
o|contracted procedure: k7257 
o|contracted procedure: k7234 
o|contracted procedure: k7245 
o|contracted procedure: k7249 
o|contracted procedure: k7284 
o|contracted procedure: k7295 
o|contracted procedure: k7346 
o|contracted procedure: k7378 
o|contracted procedure: k7399 
o|contracted procedure: k7395 
o|contracted procedure: k7391 
o|contracted procedure: k7382 
o|contracted procedure: k7486 
o|contracted procedure: k7490 
o|contracted procedure: k7402 
o|contracted procedure: k7405 
o|contracted procedure: k7408 
o|contracted procedure: k7482 
o|contracted procedure: k7414 
o|contracted procedure: k7473 
o|contracted procedure: k7420 
o|contracted procedure: k7455 
o|contracted procedure: k7464 
o|contracted procedure: k7426 
o|contracted procedure: k7438 
o|contracted procedure: k7442 
o|contracted procedure: k7496 
o|contracted procedure: k7564 
o|contracted procedure: k7568 
o|contracted procedure: k7505 
o|contracted procedure: k7522 
o|contracted procedure: k7525 
o|contracted procedure: k7528 
o|contracted procedure: k7540 
o|contracted procedure: k7557 
o|contracted procedure: k7553 
o|contracted procedure: k7544 
o|contracted procedure: k7574 
o|contracted procedure: k7660 
o|contracted procedure: k7594 
o|contracted procedure: k7615 
o|contracted procedure: k7619 
o|contracted procedure: k7636 
o|contracted procedure: k7640 
o|contracted procedure: k7632 
o|contracted procedure: k7653 
o|contracted procedure: k7666 
o|contracted procedure: k7736 
o|contracted procedure: k7678 
o|contracted procedure: k7731 
o|contracted procedure: k7701 
o|contracted procedure: k7713 
o|contracted procedure: k7721 
o|contracted procedure: k7705 
o|contracted procedure: k7725 
o|contracted procedure: k7742 
o|contracted procedure: k7828 
o|contracted procedure: k7762 
o|contracted procedure: k7768 
o|contracted procedure: k7771 
o|contracted procedure: k7774 
o|contracted procedure: k7786 
o|contracted procedure: k7803 
o|contracted procedure: k7811 
o|contracted procedure: k7807 
o|contracted procedure: k7799 
o|contracted procedure: k7790 
o|contracted procedure: k7834 
o|contracted procedure: k7840 
o|contracted procedure: k7843 
o|contracted procedure: k7920 
o|contracted procedure: k7852 
o|contracted procedure: k7875 
o|contracted procedure: k7892 
o|contracted procedure: k7913 
o|contracted procedure: k7909 
o|contracted procedure: k7905 
o|contracted procedure: k7896 
o|contracted procedure: k7888 
o|contracted procedure: k7879 
o|contracted procedure: k7926 
o|contracted procedure: k7932 
o|contracted procedure: k7935 
o|contracted procedure: k8008 
o|contracted procedure: k7944 
o|contracted procedure: k7967 
o|contracted procedure: k8004 
o|contracted procedure: k7984 
o|contracted procedure: k7980 
o|contracted procedure: k7971 
o|contracted procedure: k7992 
o|contracted procedure: k8000 
o|contracted procedure: k8016 
o|contracted procedure: k8033 
o|contracted procedure: k8042 
o|contracted procedure: k8281 
o|contracted procedure: k8062 
o|contracted procedure: k8074 
o|contracted procedure: k8078 
o|contracted procedure: k8102 
o|contracted procedure: k8123 
o|contracted procedure: k8127 
o|contracted procedure: k8140 
o|contracted procedure: k8173 
o|contracted procedure: k8170 
o|contracted procedure: k8148 
o|contracted procedure: k8144 
o|contracted procedure: k8136 
o|contracted procedure: k8166 
o|contracted procedure: k8188 
o|contracted procedure: k8191 
o|contracted procedure: k8202 
o|contracted procedure: k8214 
o|contracted procedure: k8223 
o|contracted procedure: k8226 
o|contracted procedure: k8237 
o|contracted procedure: k8267 
o|contracted procedure: k8252 
o|contracted procedure: k8261 
o|contracted procedure: k8277 
o|contracted procedure: k8288 
o|contracted procedure: k8297 
o|contracted procedure: k8300 
o|contracted procedure: k8314 
o|contracted procedure: k8332 
o|contracted procedure: k8344 
o|contracted procedure: k8336 
o|contracted procedure: k8355 
o|contracted procedure: k8362 
o|contracted procedure: k8371 
o|contracted procedure: k8381 
o|contracted procedure: k8390 
o|contracted procedure: k8393 
o|contracted procedure: k8411 
o|contracted procedure: k8441 
o|contracted procedure: k8426 
o|contracted procedure: k8448 
o|contracted procedure: k8456 
o|contracted procedure: k8476 
o|contracted procedure: k8479 
o|contracted procedure: k8482 
o|contracted procedure: k8540 
o|contracted procedure: k8488 
o|contracted procedure: k8494 
o|contracted procedure: k8506 
o|contracted procedure: k8510 
o|contracted procedure: k8522 
o|contracted procedure: k8546 
o|contracted procedure: k8566 
o|contracted procedure: k8569 
o|contracted procedure: k8599 
o|contracted procedure: k8595 
o|contracted procedure: k8602 
o|contracted procedure: k8613 
o|contracted procedure: k8694 
o|contracted procedure: k8698 
o|contracted procedure: k8622 
o|contracted procedure: k8639 
o|contracted procedure: k8645 
o|contracted procedure: k8648 
o|contracted procedure: k8660 
o|contracted procedure: k8673 
o|contracted procedure: k8664 
o|contracted procedure: k8704 
o|contracted procedure: k8802 
o|contracted procedure: k8713 
o|contracted procedure: k8719 
o|contracted procedure: k8794 
o|contracted procedure: k8736 
o|contracted procedure: k8764 
o|contracted procedure: k8748 
o|contracted procedure: k8790 
o|contracted procedure: k8770 
o|contracted procedure: k8782 
o|contracted procedure: k8786 
o|contracted procedure: k8808 
o|contracted procedure: k8811 
o|contracted procedure: k8814 
o|contracted procedure: k8817 
o|contracted procedure: k8820 
o|contracted procedure: k8832 
o|contracted procedure: k8835 
o|contracted procedure: k8852 
o|contracted procedure: k8864 
o|contracted procedure: k8877 
o|contracted procedure: k8868 
o|contracted procedure: k8892 
o|inlining procedure: k8889 
o|contracted procedure: k8901 
o|inlining procedure: k8889 
o|contracted procedure: k8909 
o|contracted procedure: k8916 
o|contracted procedure: k8941 
o|contracted procedure: k8934 
o|contracted procedure: k8947 
o|contracted procedure: k9020 
o|contracted procedure: k9024 
o|contracted procedure: k8956 
o|contracted procedure: k8979 
o|contracted procedure: k8996 
o|contracted procedure: k8992 
o|contracted procedure: k8983 
o|contracted procedure: k9016 
o|contracted procedure: k9003 
o|contracted procedure: k9030 
o|contracted procedure: k9039 
o|contracted procedure: k9062 
o|contracted procedure: k9066 
o|contracted procedure: k9074 
o|contracted procedure: k9080 
o|contracted procedure: k9097 
o|contracted procedure: k9100 
o|contracted procedure: k9109 
o|contracted procedure: k9121 
o|contracted procedure: k9125 
o|contracted procedure: k9208 
o|contracted procedure: k9135 
o|contracted procedure: k9147 
o|contracted procedure: k9151 
o|contracted procedure: k9159 
o|contracted procedure: k9162 
o|contracted procedure: k9174 
o|contracted procedure: k9178 
o|contracted procedure: k9197 
o|contracted procedure: k9201 
o|contracted procedure: k9242 
o|contracted procedure: k9217 
o|contracted procedure: k9233 
o|contracted procedure: k9224 
o|contracted procedure: k9254 
o|contracted procedure: k9257 
o|contracted procedure: k9263 
o|contracted procedure: k9266 
o|contracted procedure: k9275 
o|contracted procedure: k9298 
o|contracted procedure: k9351 
o|contracted procedure: k9315 
o|contracted procedure: k9311 
o|contracted procedure: k9302 
o|contracted procedure: k9329 
o|contracted procedure: k9339 
o|contracted procedure: k9347 
o|contracted procedure: k9359 
o|contracted procedure: k9376 
o|contracted procedure: k9382 
o|contracted procedure: k9394 
o|contracted procedure: k9406 
o|contracted procedure: k9410 
o|contracted procedure: k9503 
o|contracted procedure: k9420 
o|contracted procedure: k9432 
o|contracted procedure: k9436 
o|contracted procedure: k9450 
o|contracted procedure: k9454 
o|contracted procedure: k9467 
o|contracted procedure: k9479 
o|contracted procedure: k9483 
o|contracted procedure: k9495 
o|contracted procedure: k9499 
o|contracted procedure: k9537 
o|contracted procedure: k9512 
o|contracted procedure: k9528 
o|contracted procedure: k9519 
o|contracted procedure: k9548 
o|contracted procedure: k9551 
o|contracted procedure: k9554 
o|contracted procedure: k9557 
o|contracted procedure: k9566 
o|contracted procedure: k9583 
o|contracted procedure: k9586 
o|contracted procedure: k9598 
o|contracted procedure: k9602 
o|contracted procedure: k9609 
o|contracted procedure: k9621 
o|contracted procedure: k9641 
o|contracted procedure: k9637 
o|contracted procedure: k9647 
o|contracted procedure: k9664 
o|contracted procedure: k9780 
o|contracted procedure: k9670 
o|contracted procedure: k9776 
o|contracted procedure: k9682 
o|contracted procedure: k9714 
o|contracted procedure: k9723 
o|contracted procedure: k9729 
o|contracted procedure: k9746 
o|contracted procedure: k7313 
o|contracted procedure: k7329 
o|contracted procedure: k7335 
o|contracted procedure: k9752 
o|contracted procedure: k9759 
o|contracted procedure: k9769 
o|contracted procedure: k9845 
o|contracted procedure: k9853 
o|contracted procedure: k9861 
o|contracted procedure: k9867 
o|contracted procedure: k9870 
o|contracted procedure: k9886 
o|contracted procedure: k9903 
o|contracted procedure: k9927 
o|contracted procedure: k9958 
o|contracted procedure: k9962 
o|contracted procedure: k9939 
o|contracted procedure: k9946 
o|contracted procedure: k9950 
o|contracted procedure: k9954 
o|contracted procedure: k9984 
o|contracted procedure: k9975 
o|contracted procedure: k9994 
o|contracted procedure: k10001 
o|contracted procedure: k10005 
o|contracted procedure: k10011 
o|contracted procedure: k10021 
o|contracted procedure: k10025 
o|contracted procedure: k10029 
o|contracted procedure: k10037 
o|contracted procedure: k10049 
o|contracted procedure: k10059 
o|contracted procedure: k10063 
o|contracted procedure: k10083 
o|contracted procedure: k10091 
o|contracted procedure: k10099 
o|contracted procedure: k10105 
o|contracted procedure: k10108 
o|contracted procedure: k10111 
o|contracted procedure: k10134 
o|contracted procedure: k10117 
o|contracted procedure: k10130 
o|contracted procedure: k10144 
o|contracted procedure: k10154 
o|contracted procedure: k10161 
o|contracted procedure: k10168 
o|contracted procedure: k10178 
o|contracted procedure: k10201 
o|contracted procedure: k10188 
o|contracted procedure: k10207 
o|contracted procedure: k10219 
o|contracted procedure: k10223 
o|contracted procedure: k10231 
o|contracted procedure: k10237 
o|contracted procedure: k10246 
o|contracted procedure: k10268 
o|contracted procedure: k10272 
o|contracted procedure: k10278 
o|contracted procedure: k10287 
o|contracted procedure: k10309 
o|contracted procedure: k10313 
o|contracted procedure: k10319 
o|contracted procedure: k10322 
o|contracted procedure: k10414 
o|contracted procedure: k10328 
o|contracted procedure: k10405 
o|contracted procedure: k10334 
o|contracted procedure: k10351 
o|contracted procedure: k10357 
o|contracted procedure: k10360 
o|contracted procedure: k10393 
o|contracted procedure: k10367 
o|contracted procedure: k10384 
o|contracted procedure: k10375 
o|contracted procedure: k10371 
o|contracted procedure: k10420 
o|contracted procedure: k10423 
o|contracted procedure: k10426 
o|contracted procedure: k10439 
o|contracted procedure: k10454 
o|contracted procedure: k10461 
o|contracted procedure: k10465 
o|contracted procedure: k10471 
o|contracted procedure: k10484 
o|contracted procedure: k10492 
o|contracted procedure: k10496 
o|contracted procedure: k10556 
o|contracted procedure: k11238 
o|contracted procedure: k10559 
o|contracted procedure: k10565 
o|contracted procedure: k10581 
o|contracted procedure: k10592 
o|contracted procedure: k10600 
o|contracted procedure: k10614 
o|contracted procedure: k10627 
o|contracted procedure: k10631 
o|contracted procedure: k10623 
o|contracted procedure: k10610 
o|contracted procedure: k10651 
o|contracted procedure: k10647 
o|contracted procedure: k10639 
o|contracted procedure: k10663 
o|contracted procedure: k10671 
o|contracted procedure: k10729 
o|contracted procedure: k10739 
o|contracted procedure: k10743 
o|contracted procedure: k10685 
o|contracted procedure: k10700 
o|contracted procedure: k10709 
o|contracted procedure: k10713 
o|contracted procedure: k10816 
o|contracted procedure: k10758 
o|contracted procedure: k10810 
o|contracted procedure: k10762 
o|contracted procedure: k10783 
o|contracted procedure: k10792 
o|contracted procedure: k10801 
o|contracted procedure: k10774 
o|contracted procedure: k10765 
o|contracted procedure: k10828 
o|contracted procedure: k10838 
o|contracted procedure: k10842 
o|contracted procedure: k10852 
o|contracted procedure: k10856 
o|contracted procedure: k11208 
o|contracted procedure: k10860 
o|contracted procedure: k10871 
o|contracted procedure: k10879 
o|contracted procedure: k10887 
o|contracted procedure: k10893 
o|contracted procedure: k10896 
o|contracted procedure: k10899 
o|contracted procedure: k10907 
o|contracted procedure: k10915 
o|contracted procedure: k11108 
o|contracted procedure: k10921 
o|contracted procedure: k11099 
o|contracted procedure: k10927 
o|contracted procedure: k10931 
o|contracted procedure: k11073 
o|contracted procedure: k10937 
o|contracted procedure: k10953 
o|contracted procedure: k10957 
o|contracted procedure: k10968 
o|contracted procedure: k10960 
o|contracted procedure: k10973 
o|contracted procedure: k10981 
o|contracted procedure: k11061 
o|contracted procedure: k10984 
o|contracted procedure: k11016 
o|contracted procedure: k11020 
o|contracted procedure: k11012 
o|contracted procedure: k11003 
o|contracted procedure: k11037 
o|contracted procedure: k11028 
o|contracted procedure: k11052 
o|contracted procedure: k11048 
o|contracted procedure: k11040 
o|contracted procedure: k11079 
o|contracted procedure: k11114 
o|contracted procedure: k11117 
o|contracted procedure: k11120 
o|contracted procedure: k11126 
o|contracted procedure: k11130 
o|contracted procedure: k11140 
o|contracted procedure: k11152 
o|contracted procedure: k11162 
o|contracted procedure: k11166 
o|contracted procedure: k11169 
o|contracted procedure: k11181 
o|contracted procedure: k11191 
o|contracted procedure: k11195 
o|contracted procedure: k11218 
o|contracted procedure: k11224 
o|contracted procedure: k11231 
o|contracted procedure: k11241 
o|contracted procedure: k11263 
o|contracted procedure: k11288 
o|contracted procedure: k11304 
o|contracted procedure: k11296 
o|contracted procedure: k11300 
o|contracted procedure: k11350 
o|contracted procedure: k11358 
o|contracted procedure: k11366 
o|contracted procedure: k11372 
o|contracted procedure: k11375 
o|contracted procedure: k11378 
o|contracted procedure: k11381 
o|contracted procedure: k11395 
o|contracted procedure: k11405 
o|contracted procedure: k11412 
o|contracted procedure: k11425 
o|contracted procedure: k11516 
o|contracted procedure: k11431 
o|contracted procedure: k11507 
o|contracted procedure: k11434 
o|contracted procedure: k11498 
o|contracted procedure: k11437 
o|contracted procedure: k11489 
o|contracted procedure: k11443 
o|contracted procedure: k11455 
o|contracted procedure: k11339 
o|contracted procedure: k11314 
o|contracted procedure: k11330 
o|contracted procedure: k11321 
o|contracted procedure: k11466 
o|contracted procedure: k11531 
o|contracted procedure: k11537 
o|contracted procedure: k11540 
o|contracted procedure: k11547 
o|contracted procedure: k11570 
o|contracted procedure: k11588 
o|contracted procedure: k11600 
o|contracted procedure: k11610 
o|contracted procedure: k11614 
o|contracted procedure: k11634 
o|contracted procedure: k11756 
o|contracted procedure: k11646 
o|contracted procedure: k11747 
o|contracted procedure: k11649 
o|contracted procedure: k11657 
o|contracted procedure: k11660 
o|contracted procedure: k11663 
o|contracted procedure: k11703 
o|contracted procedure: k11675 
o|contracted procedure: k11679 
o|contracted procedure: k11694 
o|contracted procedure: k11712 
o|contracted procedure: k11715 
o|contracted procedure: k11726 
o|contracted procedure: k11738 
o|contracted procedure: k11759 
o|contracted procedure: k11787 
o|contracted procedure: k11862 
o|contracted procedure: k11790 
o|contracted procedure: k11811 
o|contracted procedure: k11802 
o|contracted procedure: k11831 
o|contracted procedure: k11839 
o|contracted procedure: k11853 
o|contracted procedure: k11843 
o|contracted procedure: k11865 
o|contracted procedure: k11877 
o|contracted procedure: k11887 
o|contracted procedure: k11891 
o|contracted procedure: k11895 
o|contracted procedure: k11907 
o|contracted procedure: k11917 
o|contracted procedure: k11921 
o|contracted procedure: k12224 
o|contracted procedure: k11927 
o|contracted procedure: k11952 
o|contracted procedure: k11965 
o|contracted procedure: k11978 
o|contracted procedure: k12034 
o|contracted procedure: k12051 
o|contracted procedure: k12171 
o|contracted procedure: k12068 
o|contracted procedure: k12064 
o|contracted procedure: k12055 
o|contracted procedure: k12047 
o|contracted procedure: k12038 
o|contracted procedure: k11991 
o|contracted procedure: k12000 
o|contracted procedure: k11982 
o|contracted procedure: k11974 
o|contracted procedure: k11956 
o|contracted procedure: k11948 
o|contracted procedure: k12020 
o|contracted procedure: k12076 
o|contracted procedure: k12093 
o|contracted procedure: k12084 
o|contracted procedure: k12111 
o|contracted procedure: k12120 
o|contracted procedure: k12159 
o|contracted procedure: k12135 
o|contracted procedure: k12139 
o|contracted procedure: k12155 
o|contracted procedure: k12163 
o|contracted procedure: k12215 
o|contracted procedure: k12182 
o|contracted procedure: k12206 
o|contracted procedure: k12185 
o|contracted procedure: k12197 
o|contracted procedure: k12237 
o|contracted procedure: k12263 
o|contracted procedure: k12259 
o|contracted procedure: k12240 
o|contracted procedure: k12251 
o|contracted procedure: k12271 
o|contracted procedure: k12290 
o|contracted procedure: k12302 
o|contracted procedure: k12305 
o|contracted procedure: k12316 
o|contracted procedure: k12328 
o|contracted procedure: k12287 
o|contracted procedure: k12337 
o|contracted procedure: k12340 
o|contracted procedure: k12351 
o|contracted procedure: k12363 
o|contracted procedure: k12366 
o|contracted procedure: k12376 
o|contracted procedure: k12385 
o|contracted procedure: k12395 
o|contracted procedure: k12399 
o|contracted procedure: k12610 
o|contracted procedure: k12606 
o|contracted procedure: k12590 
o|contracted procedure: k12602 
o|contracted procedure: k12598 
o|contracted procedure: k12594 
o|contracted procedure: k12547 
o|contracted procedure: k12551 
o|contracted procedure: k12586 
o|contracted procedure: k12582 
o|contracted procedure: k12569 
o|contracted procedure: k12403 
o|contracted procedure: k12535 
o|contracted procedure: k12543 
o|contracted procedure: k12539 
o|contracted procedure: k12531 
o|contracted procedure: k12411 
o|contracted procedure: k12415 
o|contracted procedure: k12421 
o|contracted procedure: k12430 
o|contracted procedure: k12527 
o|contracted procedure: k12436 
o|contracted procedure: k12523 
o|contracted procedure: k12442 
o|contracted procedure: k12454 
o|contracted procedure: k12471 
o|contracted procedure: k12467 
o|contracted procedure: k12458 
o|contracted procedure: k12507 
o|contracted procedure: k12499 
o|contracted procedure: k12490 
o|contracted procedure: k12407 
o|contracted procedure: k13291 
o|contracted procedure: k13355 
o|contracted procedure: k13371 
o|contracted procedure: k13359 
o|contracted procedure: k13367 
o|contracted procedure: k13363 
o|contracted procedure: k13295 
o|contracted procedure: k13351 
o|contracted procedure: k13303 
o|contracted procedure: k13311 
o|contracted procedure: k13331 
o|contracted procedure: k13347 
o|contracted procedure: k13335 
o|contracted procedure: k13343 
o|contracted procedure: k13339 
o|contracted procedure: k13315 
o|contracted procedure: k13327 
o|contracted procedure: k13323 
o|contracted procedure: k13319 
o|contracted procedure: k13307 
o|contracted procedure: k13299 
o|contracted procedure: k13208 
o|contracted procedure: k13212 
o|contracted procedure: k13221 
o|contracted procedure: k13283 
o|contracted procedure: k13239 
o|contracted procedure: k13274 
o|contracted procedure: k13245 
o|contracted procedure: k13257 
o|contracted procedure: k12614 
o|contracted procedure: k13144 
o|contracted procedure: k13188 
o|contracted procedure: k13204 
o|contracted procedure: k13192 
o|contracted procedure: k13200 
o|contracted procedure: k13196 
o|contracted procedure: k13148 
o|contracted procedure: k13184 
o|contracted procedure: k13156 
o|contracted procedure: k13168 
o|contracted procedure: k13180 
o|contracted procedure: k13176 
o|contracted procedure: k13172 
o|contracted procedure: k13164 
o|contracted procedure: k13160 
o|contracted procedure: k13152 
o|contracted procedure: k13078 
o|contracted procedure: k13082 
o|contracted procedure: k13091 
o|contracted procedure: k13136 
o|contracted procedure: k13103 
o|contracted procedure: k13131 
o|contracted procedure: k13115 
o|contracted procedure: k12618 
o|contracted procedure: k13070 
o|contracted procedure: k13074 
o|contracted procedure: k12719 
o|contracted procedure: k12723 
o|contracted procedure: k12733 
o|contracted procedure: k12744 
o|contracted procedure: k12752 
o|contracted procedure: k12760 
o|contracted procedure: k12766 
o|contracted procedure: k13066 
o|contracted procedure: k12772 
o|contracted procedure: k12787 
o|contracted procedure: k12795 
o|contracted procedure: k12803 
o|contracted procedure: k12811 
o|contracted procedure: k12817 
o|contracted procedure: k12824 
o|contracted procedure: k12828 
o|contracted procedure: k12836 
o|contracted procedure: k12845 
o|contracted procedure: k13044 
o|contracted procedure: k12851 
o|contracted procedure: k13040 
o|contracted procedure: k12858 
o|contracted procedure: k12864 
o|contracted procedure: k12875 
o|contracted procedure: k12883 
o|contracted procedure: k12891 
o|contracted procedure: k12929 
o|contracted procedure: k12925 
o|contracted procedure: k12916 
o|contracted procedure: k12904 
o|contracted procedure: k12908 
o|contracted procedure: k12912 
o|contracted procedure: k12935 
o|contracted procedure: k12957 
o|contracted procedure: k13036 
o|contracted procedure: k12963 
o|contracted procedure: k12981 
o|contracted procedure: k13020 
o|contracted procedure: k13016 
o|contracted procedure: k12987 
o|contracted procedure: k13005 
o|contracted procedure: k12996 
o|contracted procedure: k12622 
o|contracted procedure: k12691 
o|contracted procedure: k12715 
o|contracted procedure: k12711 
o|contracted procedure: k12695 
o|contracted procedure: k12707 
o|contracted procedure: k12703 
o|contracted procedure: k12699 
o|contracted procedure: k12630 
o|contracted procedure: k12634 
o|contracted procedure: k12687 
o|contracted procedure: k12679 
o|contracted procedure: k12649 
o|contracted procedure: k12674 
o|contracted procedure: k12670 
o|contracted procedure: k12661 
o|contracted procedure: k12626 
o|contracted procedure: k13469 
o|contracted procedure: k13461 
o|contracted procedure: k13465 
o|contracted procedure: k13457 
o|contracted procedure: k13453 
o|contracted procedure: k13379 
o|contracted procedure: k13383 
o|contracted procedure: k13396 
o|contracted procedure: k13405 
o|contracted procedure: k13416 
o|contracted procedure: k13430 
o|contracted procedure: k13426 
o|contracted procedure: k13419 
o|contracted procedure: k13434 
o|contracted procedure: k13446 
o|contracted procedure: k13375 
o|simplifications: ((let . 120)) 
o|removed binding forms: 1091 
o|inlining procedure: k4243 
o|inlining procedure: k4243 
o|inlining procedure: k4696 
o|inlining procedure: k4696 
o|inlining procedure: k5469 
o|inlining procedure: k5469 
o|inlining procedure: k5671 
o|inlining procedure: k5671 
o|inlining procedure: k5703 
o|inlining procedure: k6010 
o|inlining procedure: k6010 
o|inlining procedure: k8194 
o|inlining procedure: k8194 
o|inlining procedure: k8229 
o|inlining procedure: k8229 
o|inlining procedure: k9606 
o|inlining procedure: k9606 
o|inlining procedure: k11718 
o|inlining procedure: k11718 
o|inlining procedure: k12243 
o|inlining procedure: k12243 
o|inlining procedure: k12308 
o|inlining procedure: k12308 
o|inlining procedure: k12343 
o|inlining procedure: k12343 
o|replaced variables: 247 
o|removed binding forms: 1 
o|simplifications: ((if . 1)) 
o|replaced variables: 3 
o|removed binding forms: 192 
o|contracted procedure: k4318 
o|contracted procedure: k4335 
o|contracted procedure: k12324 
o|replaced variables: 44 
o|removed binding forms: 4 
o|removed binding forms: 11 
o|direct leaf routine/allocation: touch30 0 
o|direct leaf routine/allocation: touch168 0 
o|direct leaf routine/allocation: for-each-loop188206 0 
o|direct leaf routine/allocation: g231240 0 
o|direct leaf routine/allocation: touch965 0 
o|direct leaf routine/allocation: close2555 6 
o|direct leaf routine/allocation: g10721073 10 
o|contracted procedure: "(optimizer.scm:76) k3840" 
o|converted assignments to bindings: (for-each-loop188206) 
o|contracted procedure: "(optimizer.scm:162) k4190" 
o|contracted procedure: "(optimizer.scm:162) k419014146" 
o|contracted procedure: "(optimizer.scm:156) k4259" 
o|contracted procedure: "(optimizer.scm:179) k4325" 
o|contracted procedure: "(optimizer.scm:202) k4395" 
o|contracted procedure: "(optimizer.scm:232) k4532" 
o|contracted procedure: "(optimizer.scm:236) k4564" 
o|contracted procedure: "(optimizer.scm:254) k4650" 
o|contracted procedure: "(optimizer.scm:274) k4827" 
o|contracted procedure: "(optimizer.scm:290) k4908" 
o|contracted procedure: "(optimizer.scm:325) k5034" 
o|contracted procedure: "(optimizer.scm:393) k5352" 
o|contracted procedure: "(optimizer.scm:400) k5432" 
o|contracted procedure: "(optimizer.scm:409) k5502" 
o|contracted procedure: "(optimizer.scm:475) k6057" 
o|contracted procedure: "(optimizer.scm:480) k6083" 
o|contracted procedure: "(optimizer.scm:487) k6100" 
o|contracted procedure: "(optimizer.scm:1625) k11415" 
o|contracted procedure: "(optimizer.scm:1638) k11580" 
o|simplifications: ((let . 1)) 
o|removed binding forms: 20 
o|replaced variables: 4 
o|removed binding forms: 2 
o|customizable procedures: (loop1064 k12897 loop21172 loop11132 g26832690 for-each-loop26822960 g27072716 map-loop27012774 map-loop27852805 map-loop28162833 k11933 loop2888 descend2840 g29102917 for-each-loop29092953 g29242931 for-each-loop29232948 map-loop27352752 g26572664 for-each-loop26562674 k11387 k11462 k11449 k11401 walk2557 tmp13566 k10571 for-each-loop24252435 for-each-loop24082418 g23752376 g24472454 for-each-loop24462470 for-each-loop25102531 k10337 k10290 k10249 rec2209 g21872194 for-each-loop21862197 scan2143 walk2142 transform2144 k7322 loop2125 k9385 k9000 k8881 k8677 k8582 k8414 k8088 k8091 map-loop16911709 map-loop17191736 k7597 k7360 k7237 map-loop12991318 g13311353 for-each-loop13301358 g13711378 for-each-loop13701386 g13951402 for-each-loop13941412 k7008 find-path1339 find1342 g976983 for-each-loop9751043 test966 k6512 k6532 k6544 k6553 for-each-loop925937 k6309 lp905 k6206 k6097 for-each-loop880892 g814823 map-loop808833 k5014 k5273 k5307 k5602 g746755 map-loop740770 loop660 g681690 map-loop675700 invalidate-gae!169 g624631 for-each-loop623641 k5150 k5105 g503510 for-each-loop502520 walk-generic174 k4647 k4664 g403412 map-loop397422 g354355 k4588 test165 g314315 replace-var172 walk1173 k4387 walk171 map-loop225243 simplify170 for-each-loop110141 k3834 k3935 mark28 remember29 scan-each31 k3807 k3790 g4350 for-each-loop4253 scan32 k3688) 
o|calls to known targets: 406 
o|identified direct recursive calls: f_4123 1 
o|identified direct recursive calls: f_4232 2 
o|identified direct recursive calls: f_9718 1 
o|identified direct recursive calls: f_9838 2 
o|identified direct recursive calls: f_10076 2 
o|unused rest argument: _2947 f_11847 
o|unused rest argument: _2905 f_12028 
o|identified direct recursive calls: f_12232 2 
o|unused rest argument: _2813 f_12275 
o|identified direct recursive calls: f_12297 2 
o|fast box initializations: 63 
o|dropping unused closure argument: f_4123 
o|dropping unused closure argument: f_4109 
*/
/* end of file */
