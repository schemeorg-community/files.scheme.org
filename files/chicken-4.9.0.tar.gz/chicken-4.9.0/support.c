/* Generated from support.scm by the CHICKEN compiler
   http://www.call-cc.org
   2014-06-02 16:39
   Version 4.9.0 (rev 3f195ba)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2014-06-02 on yves (Linux)
   command line: support.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -no-lambda-info -local -no-trace -extend private-namespace.scm -no-trace -output-file support.c
   unit: support
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_chicken_2dsyntax_toplevel)
C_externimport void C_ccall C_chicken_2dsyntax_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[563];
static double C_possibly_force_alignment;


/* from k5525 */
static C_word C_fcall stub347(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub347(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_wordstobytes(t0));
return C_r;}

/* from k5518 */
static C_word C_fcall stub342(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub342(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_bytestowords(t0));
return C_r;}

C_noret_decl(f_13811)
static void C_fcall f_13811(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8267)
static void C_ccall f_8267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8363)
static void C_ccall f_8363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8365)
static void C_fcall f_8365(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9363)
static void C_ccall f_9363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15164)
static void C_ccall f_15164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7296)
static void C_ccall f_7296(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_15182)
static void C_fcall f_15182(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15180)
static void C_ccall f_15180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15798)
static void C_ccall f_15798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9227)
static void C_fcall f_9227(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9225)
static void C_ccall f_9225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15791)
static void C_ccall f_15791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12497)
static void C_ccall f_12497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7281)
static void C_ccall f_7281(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7287)
static void C_ccall f_7287(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9217)
static void C_ccall f_9217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9210)
static void C_fcall f_9210(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15013)
static void C_ccall f_15013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4891)
static void C_fcall f_4891(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5994)
static void C_ccall f_5994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5997)
static void C_ccall f_5997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12478)
static void C_ccall f_12478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13886)
static void C_fcall f_13886(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12484)
static void C_ccall f_12484(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7273)
static void C_ccall f_7273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8878)
static void C_ccall f_8878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7275)
static void C_ccall f_7275(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7892)
static void C_ccall f_7892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4929)
static void C_ccall f_4929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4917)
static void C_ccall f_4917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4914)
static void C_ccall f_4914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5828)
static void C_ccall f_5828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8849)
static void C_fcall f_8849(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7580)
static void C_fcall f_7580(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7880)
static void C_ccall f_7880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5969)
static void C_ccall f_5969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5961)
static void C_ccall f_5961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9513)
static void C_ccall f_9513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5965)
static void C_ccall f_5965(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5964)
static void C_ccall f_5964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9518)
static void C_ccall f_9518(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_15077)
static void C_ccall f_15077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9510)
static void C_ccall f_9510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15071)
static void C_ccall f_15071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7571)
static void C_ccall f_7571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4878)
static void C_ccall f_4878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7574)
static void C_ccall f_7574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5974)
static void C_ccall f_5974(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15088)
static void C_ccall f_15088(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11499)
static void C_ccall f_11499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4908)
static void C_ccall f_4908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11491)
static void C_ccall f_11491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15082)
static void C_ccall f_15082(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4863)
static void C_ccall f_4863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4868)
static void C_fcall f_4868(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5986)
static void C_ccall f_5986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10541)
static void C_ccall f_10541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5980)
static void C_ccall f_5980(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10544)
static void C_fcall f_10544(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15094)
static void C_ccall f_15094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11484)
static void C_ccall f_11484(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11488)
static void C_ccall f_11488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5852)
static void C_ccall f_5852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7855)
static void C_ccall f_7855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8800)
static void C_fcall f_8800(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4954)
static void C_ccall f_4954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5867)
static void C_ccall f_5867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4951)
static void C_ccall f_4951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7843)
static void C_ccall f_7843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8813)
static void C_fcall f_8813(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7847)
static void C_ccall f_7847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4945)
static void C_ccall f_4945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4947)
static void C_ccall f_4947(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4947)
static void C_ccall f_4947r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6119)
static void C_ccall f_6119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5830)
static void C_ccall f_5830(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6115)
static void C_ccall f_6115(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7876)
static void C_ccall f_7876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4938)
static void C_ccall f_4938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5846)
static void C_ccall f_5846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10507)
static void C_fcall f_10507(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10940)
static void C_ccall f_10940(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4923)
static void C_ccall f_4923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4920)
static void C_ccall f_4920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10948)
static void C_ccall f_10948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7813)
static void C_ccall f_7813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5063)
static void C_ccall f_5063(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5060)
static void C_ccall f_5060(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10926)
static void C_fcall f_10926(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5069)
static void C_fcall f_5069(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5037)
static void C_ccall f_5037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8778)
static void C_ccall f_8778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10430)
static void C_ccall f_10430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10435)
static void C_ccall f_10435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5043)
static void C_ccall f_5043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5040)
static void C_ccall f_5040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8781)
static void C_ccall f_8781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10426)
static void C_ccall f_10426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5092)
static void C_ccall f_5092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5096)
static void C_ccall f_5096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10101)
static void C_fcall f_10101(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10474)
static void C_ccall f_10474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10476)
static void C_ccall f_10476(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8683)
static void C_ccall f_8683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8685)
static void C_fcall f_8685(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10459)
static void C_ccall f_10459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9747)
static void C_ccall f_9747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10444)
static void C_ccall f_10444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10441)
static void C_ccall f_10441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10449)
static void C_fcall f_10449(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9771)
static void C_ccall f_9771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9774)
static void C_ccall f_9774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15020)
static void C_ccall f_15020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9755)
static void C_ccall f_9755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10088)
static void C_fcall f_10088(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6999)
static void C_ccall f_6999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6993)
static void C_ccall f_6993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6996)
static void C_ccall f_6996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8328)
static void C_ccall f_8328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8659)
static void C_ccall f_8659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10483)
static void C_ccall f_10483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14686)
static void C_ccall f_14686(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8337)
static void C_ccall f_8337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10174)
static void C_ccall f_10174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10171)
static void C_ccall f_10171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10177)
static void C_ccall f_10177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15050)
static void C_ccall f_15050(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_14654)
static void C_ccall f_14654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8630)
static void C_fcall f_8630(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14659)
static void C_ccall f_14659(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10161)
static void C_ccall f_10161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7671)
static void C_ccall f_7671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5417)
static void C_ccall f_5417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5413)
static void C_fcall f_5413(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10167)
static void C_ccall f_10167(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9604)
static void C_fcall f_9604(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8790)
static void C_ccall f_8790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7930)
static void C_fcall f_7930(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8794)
static void C_ccall f_8794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8798)
static void C_ccall f_8798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6637)
static void C_ccall f_6637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6634)
static void C_ccall f_6634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5427)
static void C_ccall f_5427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5421)
static void C_ccall f_5421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10157)
static void C_ccall f_10157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6624)
static void C_ccall f_6624(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10143)
static void C_fcall f_10143(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9920)
static void C_ccall f_9920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7928)
static void C_ccall f_7928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14640)
static void C_ccall f_14640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10137)
static void C_ccall f_10137(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7642)
static void C_fcall f_7642(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5406)
static void C_fcall f_5406(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7511)
static void C_ccall f_7511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10900)
static void C_ccall f_10900(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14618)
static void C_fcall f_14618(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14616)
static void C_fcall f_14616(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9334)
static void C_fcall f_9334(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9332)
static void C_ccall f_9332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7636)
static void C_ccall f_7636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9981)
static void C_fcall f_9981(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9325)
static void C_ccall f_9325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14669)
static void C_fcall f_14669(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15468)
static void C_ccall f_15468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9780)
static void C_ccall f_9780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14630)
static void C_fcall f_14630(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9314)
static void C_ccall f_9314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8236)
static void C_ccall f_8236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8238)
static void C_fcall f_8238(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6618)
static void C_ccall f_6618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15487)
static void C_ccall f_15487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15483)
static void C_ccall f_15483(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8213)
static void C_fcall f_8213(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15458)
static void C_ccall f_15458(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_15452)
static void C_ccall f_15452(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10398)
static void C_ccall f_10398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15471)
static void C_ccall f_15471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9912)
static void C_ccall f_9912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4819)
static void C_ccall f_4819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5916)
static void C_fcall f_5916(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4810)
static void C_ccall f_4810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15413)
static void C_ccall f_15413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15416)
static void C_fcall f_15416(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9904)
static void C_ccall f_9904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4836)
static void C_fcall f_4836(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4834)
static void C_fcall f_4834(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4831)
static void C_ccall f_4831(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5932)
static void C_ccall f_5932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15435)
static void C_ccall f_15435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15431)
static void C_ccall f_15431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4829)
static void C_ccall f_4829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5947)
static void C_ccall f_5947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5942)
static void C_ccall f_5942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15409)
static void C_ccall f_15409(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7501)
static void C_fcall f_7501(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4849)
static void C_ccall f_4849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4846)
static void C_ccall f_4846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4843)
static void C_ccall f_4843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10660)
static void C_ccall f_10660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7504)
static void C_ccall f_7504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4801)
static void C_ccall f_4801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4807)
static void C_ccall f_4807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4804)
static void C_ccall f_4804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10671)
static void C_ccall f_10671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10677)
static void C_ccall f_10677(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10621)
static void C_ccall f_10621(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10627)
static void C_ccall f_10627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10680)
static void C_fcall f_10680(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10688)
static C_word C_fcall f_10688(C_word t0,C_word t1);
C_noret_decl(f_6054)
static void C_ccall f_6054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12515)
static void C_ccall f_12515(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11208)
static void C_ccall f_11208(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6068)
static void C_ccall f_6068(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12528)
static void C_ccall f_12528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6065)
static void C_ccall f_6065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11200)
static void C_ccall f_11200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11202)
static void C_ccall f_11202(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14695)
static void C_fcall f_14695(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6039)
static void C_ccall f_6039(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6033)
static void C_ccall f_6033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5016)
static void C_ccall f_5016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5019)
static void C_ccall f_5019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6048)
static void C_fcall f_6048(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6047)
static void C_ccall f_6047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5022)
static void C_ccall f_5022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5025)
static void C_ccall f_5025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5028)
static void C_ccall f_5028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9099)
static void C_ccall f_9099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6071)
static void C_ccall f_6071(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f17172)
static void C_ccall f17172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8192)
static void C_ccall f_8192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9075)
static void C_ccall f_9075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9715)
static void C_ccall f_9715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11276)
static void C_ccall f_11276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9718)
static void C_ccall f_9718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6077)
static C_word C_fcall f_6077(C_word t0,C_word t1);
C_noret_decl(f_11272)
static void C_ccall f_11272(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8172)
static void C_ccall f_8172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8176)
static void C_ccall f_8176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11261)
static void C_ccall f_11261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15304)
static void C_ccall f_15304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15307)
static void C_ccall f_15307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15301)
static void C_ccall f_15301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14757)
static void C_ccall f_14757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8618)
static void C_fcall f_8618(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5172)
static void C_ccall f_5172(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5178)
static void C_fcall f_5178(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9046)
static void C_fcall f_9046(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15313)
static void C_ccall f_15313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15314)
static void C_fcall f_15314(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14766)
static void C_ccall f_14766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14763)
static void C_ccall f_14763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15310)
static void C_ccall f_15310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14769)
static void C_ccall f_14769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12591)
static void C_ccall f_12591(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11283)
static C_word C_fcall f_11283(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_12597)
static void C_ccall f_12597(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7383)
static void C_ccall f_7383(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7380)
static void C_ccall f_7380(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11281)
static void C_ccall f_11281(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_14734)
static void C_ccall f_14734(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12585)
static void C_ccall f_12585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14749)
static void C_ccall f_14749(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_14749)
static void C_ccall f_14749r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_14740)
static void C_ccall f_14740(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11221)
static void C_ccall f_11221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14798)
static void C_ccall f_14798(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12560)
static void C_fcall f_12560(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7350)
static void C_ccall f_7350(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11251)
static void C_ccall f_11251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7605)
static void C_ccall f_7605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7607)
static void C_fcall f_7607(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11249)
static void C_ccall f_11249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12556)
static void C_ccall f_12556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12552)
static void C_ccall f_12552(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7342)
static void C_ccall f_7342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7344)
static void C_ccall f_7344(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_15366)
static void C_ccall f_15366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15369)
static void C_ccall f_15369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14775)
static void C_ccall f_14775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14772)
static void C_ccall f_14772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8714)
static void C_ccall f_8714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14779)
static void C_ccall f_14779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14783)
static void C_ccall f_14783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14787)
static void C_ccall f_14787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10637)
static void C_ccall f_10637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10633)
static void C_fcall f_10633(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7365)
static void C_ccall f_7365(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12546)
static void C_ccall f_12546(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15386)
static void C_fcall f_15386(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15396)
static void C_ccall f_15396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10619)
static void C_ccall f_10619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7959)
static void C_ccall f_7959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9708)
static void C_ccall f_9708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14728)
static void C_ccall f_14728(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8628)
static void C_ccall f_8628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7919)
static void C_fcall f_7919(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6987)
static void C_fcall f_6987(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10212)
static void C_ccall f_10212(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11362)
static void C_fcall f_11362(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6914)
static void C_ccall f_6914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10206)
static void C_ccall f_10206(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10714)
static void C_fcall f_10714(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13588)
static void C_ccall f_13588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6908)
static void C_fcall f_6908(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9470)
static void C_ccall f_9470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9474)
static void C_ccall f_9474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13560)
static void C_fcall f_13560(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10753)
static void C_fcall f_10753(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11391)
static void C_ccall f_11391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8584)
static void C_ccall f_8584(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9488)
static void C_ccall f_9488(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_15324)
static void C_ccall f_15324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11397)
static void C_ccall f_11397(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_10736)
static void C_ccall f_10736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5115)
static void C_ccall f_5115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9438)
static void C_ccall f_9438(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5119)
static void C_ccall f_5119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10296)
static void C_ccall f_10296(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8567)
static void C_ccall f_8567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6706)
static void C_ccall f_6706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6709)
static void C_ccall f_6709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10290)
static void C_ccall f_10290(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15330)
static void C_ccall f_15330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5128)
static void C_fcall f_5128(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_15345)
static void C_ccall f_15345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10284)
static void C_ccall f_10284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15348)
static void C_ccall f_15348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15342)
static void C_ccall f_15342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7769)
static void C_fcall f_7769(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_15353)
static void C_fcall f_15353(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9444)
static void C_fcall f_9444(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8556)
static void C_ccall f_8556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4766)
static void C_ccall f_4766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10253)
static void C_ccall f_10253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10255)
static void C_fcall f_10255(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7792)
static void C_ccall f_7792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4756)
static void C_fcall f_4756(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4751)
static void C_ccall f_4751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7738)
static void C_ccall f_7738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14312)
static void C_fcall f_14312(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10824)
static void C_ccall f_10824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10010)
static void C_ccall f_10010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15784)
static void C_ccall f_15784(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_15784)
static void C_ccall f_15784r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6640)
static void C_ccall f_6640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6510)
static void C_fcall f_6510(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9024)
static void C_ccall f_9024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15782)
static void C_ccall f_15782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8135)
static void C_ccall f_8135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8570)
static void C_ccall f_8570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8578)
static void C_ccall f_8578(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6650)
static void C_ccall f_6650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6652)
static void C_fcall f_6652(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6507)
static void C_ccall f_6507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6503)
static void C_ccall f_6503(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6503)
static void C_ccall f_6503r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_9012)
static void C_ccall f_9012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9494)
static void C_ccall f_9494(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8106)
static void C_fcall f_8106(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8104)
static void C_ccall f_8104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15778)
static void C_ccall f_15778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15775)
static void C_ccall f_15775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15772)
static void C_ccall f_15772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10040)
static void C_fcall f_10040(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14330)
static void C_ccall f_14330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15745)
static void C_ccall f_15745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14344)
static void C_fcall f_14344(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10038)
static void C_ccall f_10038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7314)
static void C_ccall f_7314(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_15714)
static void C_ccall f_15714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15718)
static void C_ccall f_15718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10026)
static void C_ccall f_10026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10028)
static void C_fcall f_10028(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15769)
static void C_ccall f_15769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15766)
static void C_ccall f_15766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7305)
static void C_ccall f_7305(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15760)
static void C_ccall f_15760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5104)
static void C_ccall f_5104(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5107)
static void C_fcall f_5107(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14320)
static void C_fcall f_14320(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7332)
static void C_ccall f_7332(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_15735)
static void C_fcall f_15735(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15730)
static void C_ccall f_15730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7323)
static void C_ccall f_7323(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15702)
static void C_ccall f_15702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10793)
static void C_fcall f_10793(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10069)
static void C_ccall f_10069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10775)
static void C_ccall f_10775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13434)
static void C_ccall f_13434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6687)
static void C_ccall f_6687(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6696)
static void C_ccall f_6696(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6691)
static void C_fcall f_6691(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13100)
static void C_fcall f_13100(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6830)
static void C_fcall f_6830(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5690)
static void C_ccall f_5690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5692)
static void C_ccall f_5692(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14853)
static void C_fcall f_14853(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10894)
static void C_ccall f_10894(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_14851)
static void C_ccall f_14851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5662)
static void C_ccall f_5662(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6836)
static void C_ccall f_6836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14867)
static void C_ccall f_14867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5672)
static void C_ccall f_5672(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10874)
static void C_ccall f_10874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5678)
static void C_ccall f_5678(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6897)
static void C_ccall f_6897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5641)
static void C_ccall f_5641(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5647)
static void C_fcall f_5647(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10868)
static void C_ccall f_10868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14808)
static void C_fcall f_14808(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14805)
static void C_ccall f_14805(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_14805)
static void C_ccall f_14805r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_11579)
static void C_fcall f_11579(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14812)
static void C_ccall f_14812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14818)
static void C_ccall f_14818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14824)
static void C_ccall f_14824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11526)
static void C_ccall f_11526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6884)
static void C_fcall f_6884(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14394)
static void C_ccall f_14394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12640)
static void C_fcall f_12640(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11554)
static void C_fcall f_11554(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12646)
static void C_ccall f_12646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5686)
static void C_ccall f_5686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15821)
static void C_ccall f_15821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14376)
static void C_fcall f_14376(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15827)
static void C_ccall f_15827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11385)
static void C_ccall f_11385(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13444)
static void C_ccall f_13444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(C_support_toplevel)
C_externexport void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13440)
static void C_ccall f_13440(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12628)
static void C_fcall f_12628(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15834)
static void C_ccall f_15834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8927)
static void C_ccall f_8927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14384)
static void C_fcall f_14384(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15837)
static void C_ccall f_15837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15840)
static void C_ccall f_15840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15843)
static void C_ccall f_15843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14877)
static void C_ccall f_14877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9855)
static void C_fcall f_9855(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12607)
static void C_fcall f_12607(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9841)
static void C_ccall f_9841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14890)
static void C_ccall f_14890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8527)
static void C_fcall f_8527(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11181)
static void C_ccall f_11181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8525)
static void C_ccall f_8525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11178)
static void C_fcall f_11178(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12650)
static void C_fcall f_12650(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11171)
static void C_ccall f_11171(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_15809)
static void C_ccall f_15809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15217)
static void C_fcall f_15217(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11165)
static void C_ccall f_11165(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11163)
static void C_ccall f_11163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8044)
static void C_ccall f_8044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15813)
static void C_ccall f_15813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15816)
static void C_ccall f_15816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14274)
static void C_ccall f_14274(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_14278)
static void C_ccall f_14278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11140)
static void C_ccall f_11140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14280)
static void C_ccall f_14280(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11137)
static void C_fcall f_11137(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12616)
static void C_fcall f_12616(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11130)
static void C_ccall f_11130(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11124)
static void C_ccall f_11124(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6409)
static void C_ccall f_6409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6405)
static void C_ccall f_6405(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_15261)
static void C_fcall f_15261(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6273)
static void C_ccall f_6273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6244)
static void C_ccall f_6244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7704)
static void C_ccall f_7704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15289)
static void C_ccall f_15289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4744)
static void C_ccall f_4744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15298)
static void C_ccall f_15298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4736)
static void C_ccall f_4736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13045)
static void C_fcall f_13045(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4727)
static void C_ccall f_4727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4724)
static void C_ccall f_4724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4720)
static void C_ccall f_4720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6333)
static void C_ccall f_6333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13057)
static void C_fcall f_13057(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4711)
static void C_ccall f_4711(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4711)
static void C_ccall f_4711r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4714)
static void C_fcall f_4714(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6323)
static void C_fcall f_6323(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13023)
static void C_ccall f_13023(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4789)
static void C_ccall f_4789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4786)
static void C_ccall f_4786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13035)
static void C_ccall f_13035(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6310)
static void C_ccall f_6310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4779)
static void C_fcall f_4779(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11516)
static void C_fcall f_11516(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6300)
static void C_fcall f_6300(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11548)
static void C_ccall f_11548(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11542)
static void C_ccall f_11542(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13017)
static void C_ccall f_13017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5259)
static void C_ccall f_5259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5265)
static void C_ccall f_5265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11928)
static void C_fcall f_11928(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5240)
static void C_ccall f_5240(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11505)
static void C_ccall f_11505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5293)
static void C_ccall f_5293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5299)
static void C_ccall f_5299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4708)
static void C_ccall f_4708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6451)
static void C_ccall f_6451(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_14943)
static void C_ccall f_14943(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5270)
static void C_ccall f_5270(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14953)
static void C_ccall f_14953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14956)
static void C_ccall f_14956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14950)
static void C_ccall f_14950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6455)
static void C_ccall f_6455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14920)
static void C_ccall f_14920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14929)
static void C_ccall f_14929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14925)
static void C_ccall f_14925(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13063)
static void C_ccall f_13063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13067)
static void C_fcall f_13067(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14937)
static void C_ccall f_14937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9199)
static void C_ccall f_9199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14909)
static void C_ccall f_14909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14905)
static void C_ccall f_14905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14916)
static void C_ccall f_14916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5515)
static void C_ccall f_5515(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5513)
static void C_ccall f_5513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5522)
static void C_ccall f_5522(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9158)
static void C_fcall f_9158(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_15256)
static void C_ccall f_15256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15252)
static void C_ccall f_15252(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15598)
static void C_ccall f_15598(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11031)
static void C_ccall f_11031(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14466)
static void C_fcall f_14466(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8430)
static void C_ccall f_8430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5788)
static void C_fcall f_5788(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5784)
static void C_ccall f_5784(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5627)
static void C_ccall f_5627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14485)
static void C_ccall f_14485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14985)
static void C_ccall f_14985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14981)
static void C_ccall f_14981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14995)
static void C_ccall f_14995(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5601)
static void C_fcall f_5601(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7447)
static void C_ccall f_7447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7449)
static void C_fcall f_7449(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9172)
static void C_ccall f_9172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9176)
static void C_ccall f_9176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6007)
static void C_fcall f_6007(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14429)
static void C_ccall f_14429(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6005)
static void C_ccall f_6005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14961)
static void C_ccall f_14961(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15664)
static void C_ccall f_15664(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6558)
static void C_ccall f_6558(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_14432)
static void C_fcall f_14432(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5529)
static void C_ccall f_5529(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5529)
static void C_ccall f_5529r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_15675)
static void C_ccall f_15675(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9867)
static void C_fcall f_9867(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9865)
static void C_ccall f_9865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13947)
static void C_fcall f_13947(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11901)
static void C_fcall f_11901(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15686)
static void C_ccall f_15686(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8013)
static void C_ccall f_8013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15696)
static void C_ccall f_15696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8015)
static void C_fcall f_8015(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15496)
static void C_ccall f_15496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15690)
static void C_ccall f_15690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15492)
static void C_fcall f_15492(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13925)
static void C_fcall f_13925(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8997)
static void C_ccall f_8997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15622)
static void C_ccall f_15622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9838)
static void C_ccall f_9838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9832)
static void C_ccall f_9832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8965)
static void C_ccall f_8965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8961)
static void C_ccall f_8961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9829)
static void C_ccall f_9829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9825)
static void C_fcall f_9825(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9823)
static void C_ccall f_9823(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11003)
static void C_ccall f_11003(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13907)
static void C_fcall f_13907(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8973)
static void C_fcall f_8973(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11677)
static void C_fcall f_11677(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15643)
static void C_ccall f_15643(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_15643)
static void C_ccall f_15643r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_9896)
static void C_ccall f_9896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15658)
static void C_ccall f_15658(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11662)
static void C_ccall f_11662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7478)
static void C_ccall f_7478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11612)
static void C_ccall f_11612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11975)
static void C_fcall f_11975(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11971)
static void C_ccall f_11971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15618)
static void C_ccall f_15618(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6225)
static void C_ccall f_6225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6587)
static void C_fcall f_6587(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6584)
static void C_ccall f_6584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8903)
static void C_ccall f_8903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6591)
static void C_fcall f_6591(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13736)
static void C_fcall f_13736(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6567)
static void C_ccall f_6567(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6562)
static void C_ccall f_6562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13708)
static void C_ccall f_13708(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6577)
static void C_ccall f_6577(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6756)
static void C_fcall f_6756(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6762)
static void C_ccall f_6762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5354)
static void C_ccall f_5354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9800)
static void C_ccall f_9800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6730)
static void C_ccall f_6730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10322)
static void C_ccall f_10322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10324)
static void C_fcall f_10324(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6746)
static void C_ccall f_6746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5378)
static void C_ccall f_5378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6799)
static void C_ccall f_6799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6793)
static void C_fcall f_6793(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11434)
static void C_ccall f_11434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4671)
static void C_ccall f_4671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11431)
static void C_ccall f_11431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11594)
static void C_fcall f_11594(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4674)
static void C_ccall f_4674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4678)
static void C_ccall f_4678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11839)
static void C_fcall f_11839(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11428)
static void C_ccall f_11428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11422)
static void C_ccall f_11422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10363)
static void C_ccall f_10363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10366)
static void C_ccall f_10366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9543)
static void C_ccall f_9543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4697)
static void C_ccall f_4697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9539)
static void C_fcall f_9539(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5384)
static void C_fcall f_5384(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5382)
static void C_ccall f_5382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4683)
static void C_ccall f_4683(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4683)
static void C_ccall f_4683r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_14491)
static void C_ccall f_14491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14495)
static void C_ccall f_14495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11883)
static void C_fcall f_11883(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11886)
static void C_ccall f_11886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13712)
static void C_ccall f_13712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10372)
static void C_ccall f_10372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11717)
static void C_fcall f_11717(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5212)
static void C_fcall f_5212(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10353)
static void C_ccall f_10353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10359)
static void C_ccall f_10359(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6718)
static void C_ccall f_6718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6715)
static void C_ccall f_6715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6712)
static void C_ccall f_6712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9283)
static void C_ccall f_9283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9285)
static void C_fcall f_9285(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6011)
static void C_ccall f_6011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10388)
static void C_fcall f_10388(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10380)
static void C_ccall f_10380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5206)
static void C_ccall f_5206(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_15123)
static void C_ccall f_15123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11759)
static void C_fcall f_11759(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15132)
static void C_ccall f_15132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4668)
static void C_ccall f_4668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5366)
static void C_ccall f_5366(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11458)
static void C_ccall f_11458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11455)
static void C_ccall f_11455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11735)
static void C_fcall f_11735(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5573)
static void C_ccall f_5573(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_15149)
static void C_ccall f_15149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8416)
static void C_ccall f_8416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11452)
static void C_ccall f_11452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9256)
static void C_ccall f_9256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11446)
static void C_ccall f_11446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11443)
static void C_ccall f_11443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9101)
static void C_fcall f_9101(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5585)
static void C_ccall f_5585(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11720)
static void C_ccall f_11720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12046)
static void C_ccall f_12046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15158)
static void C_ccall f_15158(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_15158)
static void C_ccall f_15158r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5892)
static void C_fcall f_5892(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11440)
static void C_ccall f_11440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11479)
static void C_ccall f_11479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11476)
static void C_ccall f_11476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11470)
static void C_ccall f_11470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4999)
static void C_ccall f_4999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5599)
static void C_ccall f_5599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14560)
static void C_ccall f_14560(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11467)
static void C_ccall f_11467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11464)
static void C_ccall f_11464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9593)
static void C_ccall f_9593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4984)
static void C_ccall f_4984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4989)
static void C_fcall f_4989(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4981)
static void C_ccall f_4981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7835)
static void C_ccall f_7835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12011)
static void C_ccall f_12011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11416)
static void C_ccall f_11416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6176)
static void C_ccall f_6176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11419)
static void C_ccall f_11419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5886)
static void C_ccall f_5886(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11413)
static void C_ccall f_11413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6172)
static void C_ccall f_6172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4971)
static void C_fcall f_4971(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11410)
static void C_ccall f_11410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4970)
static void C_ccall f_4970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5884)
static void C_ccall f_5884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14541)
static void C_ccall f_14541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11404)
static void C_ccall f_11404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5542)
static void C_ccall f_5542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12008)
static void C_fcall f_12008(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4963)
static void C_ccall f_4963(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4963)
static void C_ccall f_4963r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4967)
static void C_fcall f_4967(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4961)
static void C_ccall f_4961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9130)
static void C_ccall f_9130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5554)
static void C_fcall f_5554(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14521)
static void C_ccall f_14521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14572)
static void C_ccall f_14572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15554)
static void C_ccall f_15554(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5726)
static void C_ccall f_5726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6196)
static void C_ccall f_6196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5738)
static void C_ccall f_5738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15578)
static void C_ccall f_15578(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8402)
static void C_fcall f_8402(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8406)
static void C_ccall f_8406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8409)
static void C_ccall f_8409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14530)
static void C_ccall f_14530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5754)
static void C_ccall f_5754(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15514)
static void C_ccall f_15514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11812)
static void C_fcall f_11812(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15526)
static void C_ccall f_15526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15541)
static void C_ccall f_15541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11842)
static void C_ccall f_11842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15538)
static void C_ccall f_15538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15549)
static void C_ccall f_15549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6373)
static void C_ccall f_6373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11785)
static void C_fcall f_11785(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6356)
static void C_ccall f_6356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6369)
static void C_ccall f_6369(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6346)
static void C_fcall f_6346(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5463)
static void C_ccall f_5463(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5467)
static void C_ccall f_5467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9633)
static void C_ccall f_9633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9639)
static void C_ccall f_9639(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_6399)
static void C_ccall f_6399(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6391)
static void C_ccall f_6391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5447)
static void C_ccall f_5447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10586)
static void C_ccall f_10586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8394)
static void C_ccall f_8394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9945)
static void C_fcall f_9945(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6387)
static void C_ccall f_6387(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6387)
static void C_ccall f_6387r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_10560)
static void C_ccall f_10560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5322)
static void C_ccall f_5322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5324)
static void C_ccall f_5324(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9930)
static void C_ccall f_9930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9932)
static void C_fcall f_9932(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9506)
static void C_ccall f_9506(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9500)
static void C_ccall f_9500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8343)
static void C_ccall f_8343(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_15110)
static void C_ccall f_15110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7578)
static void C_ccall f_7578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5488)
static void C_ccall f_5488(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9657)
static void C_fcall f_9657(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_15104)
static void C_ccall f_15104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15102)
static void C_ccall f_15102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7597)
static void C_ccall f_7597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5314)
static void C_ccall f_5314(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9649)
static void C_ccall f_9649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5312)
static void C_ccall f_5312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5330)
static void C_fcall f_5330(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5304)
static void C_ccall f_5304(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5302)
static void C_ccall f_5302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8299)
static void C_fcall f_8299(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8297)
static void C_ccall f_8297(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_13811)
static void C_fcall trf_13811(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13811(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13811(t0,t1);}

C_noret_decl(trf_8365)
static void C_fcall trf_8365(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8365(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8365(t0,t1,t2);}

C_noret_decl(trf_15182)
static void C_fcall trf_15182(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15182(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_15182(t0,t1,t2);}

C_noret_decl(trf_9227)
static void C_fcall trf_9227(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9227(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9227(t0,t1,t2);}

C_noret_decl(trf_9210)
static void C_fcall trf_9210(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9210(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9210(t0,t1);}

C_noret_decl(trf_4891)
static void C_fcall trf_4891(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4891(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4891(t0,t1,t2);}

C_noret_decl(trf_13886)
static void C_fcall trf_13886(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13886(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13886(t0,t1);}

C_noret_decl(trf_8849)
static void C_fcall trf_8849(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8849(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8849(t0,t1,t2);}

C_noret_decl(trf_7580)
static void C_fcall trf_7580(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7580(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7580(t0,t1,t2);}

C_noret_decl(trf_4868)
static void C_fcall trf_4868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4868(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4868(t0,t1,t2);}

C_noret_decl(trf_10544)
static void C_fcall trf_10544(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10544(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10544(t0,t1);}

C_noret_decl(trf_8800)
static void C_fcall trf_8800(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8800(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8800(t0,t1,t2,t3);}

C_noret_decl(trf_8813)
static void C_fcall trf_8813(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8813(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8813(t0,t1);}

C_noret_decl(trf_10507)
static void C_fcall trf_10507(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10507(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10507(t0,t1);}

C_noret_decl(trf_10926)
static void C_fcall trf_10926(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10926(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10926(t0,t1);}

C_noret_decl(trf_5069)
static void C_fcall trf_5069(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5069(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5069(t0,t1,t2);}

C_noret_decl(trf_10101)
static void C_fcall trf_10101(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10101(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10101(t0,t1);}

C_noret_decl(trf_8685)
static void C_fcall trf_8685(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8685(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8685(t0,t1,t2);}

C_noret_decl(trf_10449)
static void C_fcall trf_10449(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10449(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10449(t0,t1,t2);}

C_noret_decl(trf_10088)
static void C_fcall trf_10088(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10088(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10088(t0,t1,t2,t3);}

C_noret_decl(trf_8630)
static void C_fcall trf_8630(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8630(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8630(t0,t1,t2);}

C_noret_decl(trf_5413)
static void C_fcall trf_5413(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5413(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5413(t0,t1);}

C_noret_decl(trf_9604)
static void C_fcall trf_9604(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9604(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9604(t0,t1,t2);}

C_noret_decl(trf_7930)
static void C_fcall trf_7930(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7930(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7930(t0,t1,t2);}

C_noret_decl(trf_10143)
static void C_fcall trf_10143(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10143(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10143(t0,t1,t2);}

C_noret_decl(trf_7642)
static void C_fcall trf_7642(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7642(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7642(t0,t1,t2);}

C_noret_decl(trf_5406)
static void C_fcall trf_5406(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5406(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5406(t0,t1);}

C_noret_decl(trf_14618)
static void C_fcall trf_14618(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14618(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_14618(t0,t1,t2);}

C_noret_decl(trf_14616)
static void C_fcall trf_14616(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14616(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_14616(t0,t1,t2,t3);}

C_noret_decl(trf_9334)
static void C_fcall trf_9334(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9334(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9334(t0,t1,t2);}

C_noret_decl(trf_9981)
static void C_fcall trf_9981(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9981(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9981(t0,t1,t2);}

C_noret_decl(trf_14669)
static void C_fcall trf_14669(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14669(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_14669(t0,t1);}

C_noret_decl(trf_14630)
static void C_fcall trf_14630(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14630(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_14630(t0,t1,t2);}

C_noret_decl(trf_8238)
static void C_fcall trf_8238(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8238(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8238(t0,t1,t2);}

C_noret_decl(trf_8213)
static void C_fcall trf_8213(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8213(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8213(t0,t1);}

C_noret_decl(trf_5916)
static void C_fcall trf_5916(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5916(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5916(t0,t1);}

C_noret_decl(trf_15416)
static void C_fcall trf_15416(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15416(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_15416(t0,t1);}

C_noret_decl(trf_4836)
static void C_fcall trf_4836(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4836(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4836(t0,t1,t2);}

C_noret_decl(trf_4834)
static void C_fcall trf_4834(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4834(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4834(t0,t1,t2);}

C_noret_decl(trf_7501)
static void C_fcall trf_7501(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7501(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7501(t0,t1);}

C_noret_decl(trf_10680)
static void C_fcall trf_10680(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10680(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10680(t0,t1,t2,t3);}

C_noret_decl(trf_14695)
static void C_fcall trf_14695(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14695(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_14695(t0,t1,t2);}

C_noret_decl(trf_6048)
static void C_fcall trf_6048(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6048(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6048(t0,t1,t2);}

C_noret_decl(trf_8618)
static void C_fcall trf_8618(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8618(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8618(t0,t1);}

C_noret_decl(trf_5178)
static void C_fcall trf_5178(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5178(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5178(t0,t1,t2,t3);}

C_noret_decl(trf_9046)
static void C_fcall trf_9046(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9046(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9046(t0,t1,t2);}

C_noret_decl(trf_15314)
static void C_fcall trf_15314(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15314(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_15314(t0,t1,t2);}

C_noret_decl(trf_12560)
static void C_fcall trf_12560(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12560(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12560(t0,t1,t2);}

C_noret_decl(trf_7607)
static void C_fcall trf_7607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7607(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7607(t0,t1,t2);}

C_noret_decl(trf_10633)
static void C_fcall trf_10633(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10633(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10633(t0,t1);}

C_noret_decl(trf_15386)
static void C_fcall trf_15386(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15386(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_15386(t0,t1,t2);}

C_noret_decl(trf_7919)
static void C_fcall trf_7919(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7919(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7919(t0,t1);}

C_noret_decl(trf_6987)
static void C_fcall trf_6987(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6987(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6987(t0,t1);}

C_noret_decl(trf_11362)
static void C_fcall trf_11362(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11362(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11362(t0,t1,t2);}

C_noret_decl(trf_10714)
static void C_fcall trf_10714(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10714(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10714(t0,t1,t2,t3);}

C_noret_decl(trf_6908)
static void C_fcall trf_6908(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6908(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6908(t0,t1);}

C_noret_decl(trf_13560)
static void C_fcall trf_13560(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13560(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13560(t0,t1);}

C_noret_decl(trf_10753)
static void C_fcall trf_10753(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10753(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10753(t0,t1,t2,t3);}

C_noret_decl(trf_5128)
static void C_fcall trf_5128(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5128(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5128(t0,t1,t2,t3);}

C_noret_decl(trf_7769)
static void C_fcall trf_7769(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7769(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7769(t0,t1,t2,t3,t4);}

C_noret_decl(trf_15353)
static void C_fcall trf_15353(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15353(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_15353(t0,t1,t2);}

C_noret_decl(trf_9444)
static void C_fcall trf_9444(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9444(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9444(t0,t1,t2);}

C_noret_decl(trf_10255)
static void C_fcall trf_10255(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10255(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10255(t0,t1,t2);}

C_noret_decl(trf_4756)
static void C_fcall trf_4756(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4756(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4756(t0,t1,t2);}

C_noret_decl(trf_14312)
static void C_fcall trf_14312(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14312(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_14312(t0,t1);}

C_noret_decl(trf_6510)
static void C_fcall trf_6510(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6510(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6510(t0,t1);}

C_noret_decl(trf_6652)
static void C_fcall trf_6652(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6652(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6652(t0,t1,t2);}

C_noret_decl(trf_8106)
static void C_fcall trf_8106(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8106(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8106(t0,t1,t2);}

C_noret_decl(trf_10040)
static void C_fcall trf_10040(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10040(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10040(t0,t1,t2);}

C_noret_decl(trf_14344)
static void C_fcall trf_14344(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14344(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_14344(t0,t1);}

C_noret_decl(trf_10028)
static void C_fcall trf_10028(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10028(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10028(t0,t1,t2);}

C_noret_decl(trf_5107)
static void C_fcall trf_5107(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5107(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5107(t0,t1);}

C_noret_decl(trf_14320)
static void C_fcall trf_14320(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14320(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_14320(t0,t1,t2);}

C_noret_decl(trf_15735)
static void C_fcall trf_15735(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15735(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_15735(t0,t1,t2);}

C_noret_decl(trf_10793)
static void C_fcall trf_10793(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10793(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10793(t0,t1,t2,t3);}

C_noret_decl(trf_6691)
static void C_fcall trf_6691(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6691(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6691(t0,t1);}

C_noret_decl(trf_13100)
static void C_fcall trf_13100(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13100(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13100(t0,t1);}

C_noret_decl(trf_6830)
static void C_fcall trf_6830(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6830(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6830(t0,t1);}

C_noret_decl(trf_14853)
static void C_fcall trf_14853(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14853(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_14853(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5647)
static void C_fcall trf_5647(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5647(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5647(t0,t1,t2,t3);}

C_noret_decl(trf_14808)
static void C_fcall trf_14808(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14808(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_14808(t0,t1);}

C_noret_decl(trf_11579)
static void C_fcall trf_11579(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11579(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11579(t0,t1);}

C_noret_decl(trf_6884)
static void C_fcall trf_6884(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6884(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6884(t0,t1,t2);}

C_noret_decl(trf_12640)
static void C_fcall trf_12640(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12640(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12640(t0,t1);}

C_noret_decl(trf_11554)
static void C_fcall trf_11554(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11554(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11554(t0,t1,t2);}

C_noret_decl(trf_14376)
static void C_fcall trf_14376(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14376(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_14376(t0,t1);}

C_noret_decl(trf_12628)
static void C_fcall trf_12628(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12628(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12628(t0,t1);}

C_noret_decl(trf_14384)
static void C_fcall trf_14384(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14384(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_14384(t0,t1,t2);}

C_noret_decl(trf_9855)
static void C_fcall trf_9855(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9855(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9855(t0,t1,t2);}

C_noret_decl(trf_12607)
static void C_fcall trf_12607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12607(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12607(t0,t1);}

C_noret_decl(trf_8527)
static void C_fcall trf_8527(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8527(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8527(t0,t1,t2);}

C_noret_decl(trf_11178)
static void C_fcall trf_11178(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11178(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11178(t0,t1);}

C_noret_decl(trf_12650)
static void C_fcall trf_12650(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12650(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12650(t0,t1,t2);}

C_noret_decl(trf_15217)
static void C_fcall trf_15217(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15217(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_15217(t0,t1,t2);}

C_noret_decl(trf_11137)
static void C_fcall trf_11137(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11137(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11137(t0,t1);}

C_noret_decl(trf_12616)
static void C_fcall trf_12616(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12616(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12616(t0,t1);}

C_noret_decl(trf_15261)
static void C_fcall trf_15261(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15261(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_15261(t0,t1,t2,t3);}

C_noret_decl(trf_13045)
static void C_fcall trf_13045(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13045(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13045(t0,t1);}

C_noret_decl(trf_13057)
static void C_fcall trf_13057(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13057(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13057(t0,t1);}

C_noret_decl(trf_4714)
static void C_fcall trf_4714(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4714(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4714(t0,t1);}

C_noret_decl(trf_6323)
static void C_fcall trf_6323(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6323(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6323(t0,t1,t2);}

C_noret_decl(trf_4779)
static void C_fcall trf_4779(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4779(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4779(t0,t1,t2);}

C_noret_decl(trf_11516)
static void C_fcall trf_11516(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11516(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11516(t0,t1,t2);}

C_noret_decl(trf_6300)
static void C_fcall trf_6300(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6300(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6300(t0,t1,t2);}

C_noret_decl(trf_11928)
static void C_fcall trf_11928(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11928(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11928(t0,t1);}

C_noret_decl(trf_13067)
static void C_fcall trf_13067(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13067(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13067(t0,t1,t2);}

C_noret_decl(trf_9158)
static void C_fcall trf_9158(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9158(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_9158(t0,t1,t2,t3,t4);}

C_noret_decl(trf_14466)
static void C_fcall trf_14466(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14466(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_14466(t0,t1);}

C_noret_decl(trf_5788)
static void C_fcall trf_5788(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5788(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5788(t0,t1);}

C_noret_decl(trf_5601)
static void C_fcall trf_5601(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5601(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5601(t0,t1,t2);}

C_noret_decl(trf_7449)
static void C_fcall trf_7449(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7449(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7449(t0,t1,t2);}

C_noret_decl(trf_6007)
static void C_fcall trf_6007(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6007(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6007(t0,t1);}

C_noret_decl(trf_14432)
static void C_fcall trf_14432(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14432(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_14432(t0,t1,t2,t3);}

C_noret_decl(trf_9867)
static void C_fcall trf_9867(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9867(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9867(t0,t1,t2);}

C_noret_decl(trf_13947)
static void C_fcall trf_13947(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13947(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13947(t0,t1);}

C_noret_decl(trf_11901)
static void C_fcall trf_11901(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11901(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11901(t0,t1);}

C_noret_decl(trf_8015)
static void C_fcall trf_8015(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8015(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8015(t0,t1,t2);}

C_noret_decl(trf_15492)
static void C_fcall trf_15492(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15492(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_15492(t0,t1);}

C_noret_decl(trf_13925)
static void C_fcall trf_13925(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13925(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13925(t0,t1);}

C_noret_decl(trf_9825)
static void C_fcall trf_9825(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9825(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9825(t0,t1,t2);}

C_noret_decl(trf_13907)
static void C_fcall trf_13907(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13907(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13907(t0,t1);}

C_noret_decl(trf_8973)
static void C_fcall trf_8973(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8973(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8973(t0,t1,t2,t3);}

C_noret_decl(trf_11677)
static void C_fcall trf_11677(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11677(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11677(t0,t1);}

C_noret_decl(trf_11975)
static void C_fcall trf_11975(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11975(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11975(t0,t1,t2);}

C_noret_decl(trf_6587)
static void C_fcall trf_6587(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6587(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6587(t0,t1);}

C_noret_decl(trf_6591)
static void C_fcall trf_6591(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6591(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6591(t0,t1,t2);}

C_noret_decl(trf_13736)
static void C_fcall trf_13736(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13736(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13736(t0,t1);}

C_noret_decl(trf_6756)
static void C_fcall trf_6756(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6756(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6756(t0,t1);}

C_noret_decl(trf_10324)
static void C_fcall trf_10324(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10324(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10324(t0,t1,t2);}

C_noret_decl(trf_6793)
static void C_fcall trf_6793(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6793(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6793(t0,t1);}

C_noret_decl(trf_11594)
static void C_fcall trf_11594(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11594(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11594(t0,t1);}

C_noret_decl(trf_11839)
static void C_fcall trf_11839(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11839(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11839(t0,t1);}

C_noret_decl(trf_9539)
static void C_fcall trf_9539(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9539(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9539(t0,t1);}

C_noret_decl(trf_5384)
static void C_fcall trf_5384(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5384(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5384(t0,t1,t2);}

C_noret_decl(trf_11883)
static void C_fcall trf_11883(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11883(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11883(t0,t1);}

C_noret_decl(trf_11717)
static void C_fcall trf_11717(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11717(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11717(t0,t1);}

C_noret_decl(trf_5212)
static void C_fcall trf_5212(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5212(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5212(t0,t1,t2,t3);}

C_noret_decl(trf_9285)
static void C_fcall trf_9285(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9285(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9285(t0,t1,t2);}

C_noret_decl(trf_10388)
static void C_fcall trf_10388(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10388(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10388(t0,t1,t2);}

C_noret_decl(trf_11759)
static void C_fcall trf_11759(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11759(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11759(t0,t1);}

C_noret_decl(trf_11735)
static void C_fcall trf_11735(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11735(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11735(t0,t1);}

C_noret_decl(trf_9101)
static void C_fcall trf_9101(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9101(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9101(t0,t1,t2);}

C_noret_decl(trf_5892)
static void C_fcall trf_5892(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5892(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5892(t0,t1,t2);}

C_noret_decl(trf_4989)
static void C_fcall trf_4989(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4989(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4989(t0,t1,t2);}

C_noret_decl(trf_4971)
static void C_fcall trf_4971(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4971(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4971(t0,t1,t2);}

C_noret_decl(trf_12008)
static void C_fcall trf_12008(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12008(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12008(t0,t1);}

C_noret_decl(trf_4967)
static void C_fcall trf_4967(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4967(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4967(t0,t1);}

C_noret_decl(trf_5554)
static void C_fcall trf_5554(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5554(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5554(t0,t1);}

C_noret_decl(trf_8402)
static void C_fcall trf_8402(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8402(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8402(t0,t1);}

C_noret_decl(trf_11812)
static void C_fcall trf_11812(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11812(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11812(t0,t1);}

C_noret_decl(trf_11785)
static void C_fcall trf_11785(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11785(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11785(t0,t1);}

C_noret_decl(trf_6346)
static void C_fcall trf_6346(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6346(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6346(t0,t1,t2);}

C_noret_decl(trf_9945)
static void C_fcall trf_9945(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9945(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9945(t0,t1);}

C_noret_decl(trf_9932)
static void C_fcall trf_9932(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9932(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9932(t0,t1,t2,t3);}

C_noret_decl(trf_9657)
static void C_fcall trf_9657(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9657(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9657(t0,t1,t2,t3);}

C_noret_decl(trf_5330)
static void C_fcall trf_5330(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5330(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5330(t0,t1,t2,t3);}

C_noret_decl(trf_8299)
static void C_fcall trf_8299(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8299(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8299(t0,t1,t2);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr8)
static void C_fcall tr8(C_proc8 k) C_regparm C_noret;
C_regparm static void C_fcall tr8(C_proc8 k){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
(k)(8,t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* k13809 in k13734 in k13710 in foreign-type->scrutiny-type in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_13811(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13811,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_eqp(t2,lf[459]);
if(C_truep(t3)){
t4=C_a_i_list(&a,2,lf[462],((C_word*)t0)[3]);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_list(&a,3,lf[463],lf[464],t4));}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,2,lf[462],((C_word*)t0)[3]));}}
else{
t2=C_eqp(((C_word*)t0)[5],lf[365]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[465]);}
else{
t3=C_eqp(((C_word*)t0)[5],lf[409]);
if(C_truep(t3)){
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[466]);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[408]);
if(C_truep(t4)){
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[467]);}
else{
t5=C_eqp(((C_word*)t0)[5],lf[410]);
if(C_truep(t5)){
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[468]);}
else{
t6=C_eqp(((C_word*)t0)[5],lf[411]);
if(C_truep(t6)){
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,lf[469]);}
else{
t7=C_eqp(((C_word*)t0)[5],lf[412]);
if(C_truep(t7)){
t8=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[470]);}
else{
t8=C_eqp(((C_word*)t0)[5],lf[413]);
if(C_truep(t8)){
t9=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[471]);}
else{
t9=C_eqp(((C_word*)t0)[5],lf[414]);
if(C_truep(t9)){
t10=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[472]);}
else{
t10=C_eqp(((C_word*)t0)[5],lf[367]);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13886,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t10)){
t12=t11;
f_13886(t12,t10);}
else{
t12=C_eqp(((C_word*)t0)[5],lf[405]);
if(C_truep(t12)){
t13=t11;
f_13886(t13,t12);}
else{
t13=C_eqp(((C_word*)t0)[5],lf[406]);
if(C_truep(t13)){
t14=t11;
f_13886(t14,t13);}
else{
t14=C_eqp(((C_word*)t0)[5],lf[407]);
if(C_truep(t14)){
t15=t11;
f_13886(t15,t14);}
else{
t15=C_eqp(((C_word*)t0)[5],lf[403]);
if(C_truep(t15)){
t16=t11;
f_13886(t16,t15);}
else{
t16=C_eqp(((C_word*)t0)[5],lf[369]);
if(C_truep(t16)){
t17=t11;
f_13886(t17,t16);}
else{
t17=C_eqp(((C_word*)t0)[5],lf[373]);
t18=t11;
f_13886(t18,(C_truep(t17)?t17:C_eqp(((C_word*)t0)[5],lf[404])));}}}}}}}}}}}}}}}}

/* k8265 in map-loop1320 in k8211 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8267,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8238(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8238(t6,((C_word*)t0)[5],t5);}}

/* k8361 in k8404 in k8400 in a8342 in k8211 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8363,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record4(&a,4,lf[211],lf[251],((C_word*)t0)[3],t1));}

/* map-loop1397 in k8404 in k8400 in a8342 in k8211 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_8365(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8365,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8394,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:613: g1403 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9361 in map-loop1750 in k9208 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9363,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9334(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9334(t6,((C_word*)t0)[5],t5);}}

/* a15163 in a15157 in a15103 in a15081 in k15178 in k15069 in constant-form-eval in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15164,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* node-class-set! in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7296(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7296,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[211],C_SCHEME_FALSE);
/* support.scm:504: ##sys#block-set! */
t5=*((C_word*)lf[215]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* map-loop3646 in k15069 in constant-form-eval in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_15182(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_15182,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_list(&a,2,lf[97],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k15178 in k15069 in constant-form-eval in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15180,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15077,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15082,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm:1471: call-with-current-continuation */
t6=*((C_word*)lf[123]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k15796 in k15789 in print-version in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1613: print */
t2=*((C_word*)lf[293]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* map-loop1695 in k9215 in k9208 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_9227(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9227,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9256,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:668: g1701 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9223 in k9215 in k9208 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:668: cons* */
t2=*((C_word*)lf[268]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t1);}

/* k15789 in print-version in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15791,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15798,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1613: chicken-version */
t3=*((C_word*)lf[304]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_SCHEME_TRUE);}

/* k12495 in foreign-type-convert-result in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_12497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12497,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_i_vectorp(t1))){
t2=C_i_vector_ref(t1,C_fix(2));
t3=C_a_i_list2(&a,2,t2,((C_word*)t0)[2]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=((C_word*)t0)[2];
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* node? in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7281(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7281,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_structurep(t2,lf[211]));}

/* node-class in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7287(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7287,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[211],lf[213]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_block_ref(t2,C_fix(1)));}

/* k9215 in k9208 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9217,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)((C_word*)t0)[2])[1];
t8=C_u_i_cdr(((C_word*)t0)[3]);
t9=C_i_check_list_2(t8,lf[161]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9225,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9227,a[2]=t6,a[3]=t12,a[4]=t4,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_9227(t14,t10,t8);}

/* k9208 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_9210(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9210,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9217,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* support.scm:668: walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_8584(3,t4,t2,t3);}
else{
t2=C_eqp(((C_word*)t0)[7],lf[249]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[7],lf[271]));
if(C_truep(t3)){
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)((C_word*)t0)[2])[1];
t9=C_i_check_list_2(((C_word*)t0)[3],lf[161]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9283,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9285,a[2]=t7,a[3]=t12,a[4]=t5,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_9285(t14,t10,((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9325,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=((C_word*)((C_word*)t0)[2])[1];
t10=C_i_check_list_2(((C_word*)t0)[3],lf[161]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9332,a[2]=t4,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9334,a[2]=t8,a[3]=t13,a[4]=t6,a[5]=t9,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_9334(t15,t11,((C_word*)t0)[3]);}}}

/* ##compiler#call-info in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_15013,4,t0,t1,t2,t3);}
t4=C_i_cdr(t2);
t5=C_i_pairp(t4);
t6=(C_truep(t5)?C_i_cadr(t2):C_SCHEME_FALSE);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15020,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t6)){
if(C_truep(C_i_listp(t6))){
t8=C_i_car(t6);
t9=C_i_cadr(t6);
/* support.scm:1465: conc */
t10=*((C_word*)lf[504]+1);
((C_proc6)(void*)(*((C_word*)t10+1)))(6,t10,t7,lf[511],t8,lf[512],t3);}
else{
t8=t3;
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}
else{
t8=t3;
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}

/* test-mode in with-debugging-output in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_4891(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4891,NULL,3,t1,t2,t3);}
if(C_truep(C_i_symbolp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_memq(t2,t3));}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4908,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:93: lset-intersection */
t5=*((C_word*)lf[26]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,*((C_word*)lf[27]+1),t2,t3);}}

/* k5992 in a5985 in a5979 in a5973 in string->expr in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:305: quit */
t2=*((C_word*)lf[28]+1);
f_4947(5,t2,((C_word*)t0)[2],lf[114],((C_word*)t0)[3],t1);}

/* k5995 in a5985 in a5979 in a5973 in string->expr in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm:308: exn-msg */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
/* support.scm:309: ->string */
t2=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[4]);}}

/* a12477 in foreign-type-check in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_12478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12478,2,t0,t1);}
/* support.scm:1125: quit */
t2=*((C_word*)lf[28]+1);
f_4947(4,t2,t1,lf[431],((C_word*)t0)[2]);}

/* k13884 in k13809 in k13734 in k13710 in foreign-type->scrutiny-type in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_13886(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13886,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[423]);}
else{
t2=C_eqp(((C_word*)t0)[3],lf[375]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[473]);}
else{
t3=C_eqp(((C_word*)t0)[3],lf[377]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[393]);}
else{
t4=C_eqp(((C_word*)t0)[3],lf[378]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13907,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_13907(t6,t4);}
else{
t6=C_eqp(((C_word*)t0)[3],lf[398]);
if(C_truep(t6)){
t7=t5;
f_13907(t7,t6);}
else{
t7=C_eqp(((C_word*)t0)[3],lf[399]);
t8=t5;
f_13907(t8,(C_truep(t7)?t7:C_eqp(((C_word*)t0)[3],lf[400])));}}}}}}

/* ##compiler#foreign-type-convert-result in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_12484(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12484,4,t0,t1,t2,t3);}
if(C_truep(C_i_symbolp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12497,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1132: ##sys#hash-table-ref */
t5=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[395]+1),t3);}
else{
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k7271 in display-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_6691(t3,t2);}

/* k8876 in map-loop1577 in k8776 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8878,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8849(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8849(t6,((C_word*)t0)[5],t5);}}

/* f_7275 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7275(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7275,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[211],t2,t3,t4));}

/* k7890 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7892,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7769,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7769(t6,((C_word*)t0)[4],((C_word*)t0)[5],C_SCHEME_END_OF_LIST,t2);}

/* k4927 in k4921 in k4918 in k4915 in k4912 in with-debugging-output in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm:99: collect */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4834(t2,((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k4915 in k4912 in with-debugging-output in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4917,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4920,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* support.scm:96: display */
t4=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4912 in with-debugging-output in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4914,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4917,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm:95: with-output-to-string */
t3=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4938,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* support.scm:100: test-mode */
f_4891(t2,((C_word*)t0)[5],*((C_word*)lf[9]+1));}}

/* k5826 in immediate? in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5788(t2,C_i_not(t1));}

/* map-loop1577 in k8776 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_8849(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8849,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8878,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:636: g1583 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g1133 in k7572 in k7569 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_7580(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7580,NULL,3,t0,t1,t2);}
t3=C_i_cadr(t2);
/* support.scm:550: walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7383(3,t4,t1,t3);}

/* k7878 in loop in k7890 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:574: walk */
t2=((C_word*)((C_word*)t0)[2])[1];
f_7383(3,t2,((C_word*)t0)[3],t1);}

/* k5967 in string->expr in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:301: g489 */
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5961,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5964,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:302: condition-property-accessor */
t4=*((C_word*)lf[561]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[515],lf[516]);}

/* k9511 in k9508 in a9505 in a9493 in inline-lambda-bindings in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9513,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9518,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9539,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[6])){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9593,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* support.scm:695: last */
t6=*((C_word*)lf[263]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[4]);}
else{
t5=t4;
f_9539(t5,t2);}}

/* ##compiler#string->expr in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5965(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5965,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5969,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5974,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm:301: call-with-current-continuation */
t5=*((C_word*)lf[123]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[59],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5964,2,t0,t1);}
t2=t1;
t3=C_mutate2((C_word*)lf[113]+1 /* (set! ##compiler#string->expr ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5965,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t4=C_mutate2((C_word*)lf[124]+1 /* (set! ##compiler#decompose-lambda-list ...) */,*((C_word*)lf[125]+1));
t5=C_mutate2((C_word*)lf[126]+1 /* (set! ##compiler#llist-length ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6068,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate2((C_word*)lf[127]+1 /* (set! ##compiler#llist-match? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6071,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate2((C_word*)lf[128]+1 /* (set! ##compiler#expand-profile-lambda ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6115,tmp=(C_word)a,a+=2,tmp));
t8=C_SCHEME_TRUE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_mutate2((C_word*)lf[137]+1 /* (set! ##compiler#initialize-analysis-database ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6172,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t11=C_mutate2((C_word*)lf[148]+1 /* (set! ##compiler#get ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6369,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate2((C_word*)lf[150]+1 /* (set! ##compiler#get-all ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6387,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate2((C_word*)lf[152]+1 /* (set! ##compiler#put! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6405,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate2((C_word*)lf[154]+1 /* (set! ##compiler#collect! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6451,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate2((C_word*)lf[155]+1 /* (set! ##compiler#count! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6503,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate2((C_word*)lf[156]+1 /* (set! ##compiler#get-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6558,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate2((C_word*)lf[157]+1 /* (set! ##compiler#get-line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6567,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate2((C_word*)lf[159]+1 /* (set! ##compiler#get-line-2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6577,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate2((C_word*)lf[160]+1 /* (set! ##compiler#display-line-number-database ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6618,tmp=(C_word)a,a+=2,tmp));
t20=C_SCHEME_FALSE;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_mutate2((C_word*)lf[163]+1 /* (set! ##compiler#display-analysis-database ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6687,a[2]=t21,tmp=(C_word)a,a+=3,tmp));
t23=C_mutate2((C_word*)lf[210]+1 /* (set! make-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7275,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate2((C_word*)lf[212]+1 /* (set! node? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7281,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate2((C_word*)lf[213]+1 /* (set! node-class ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7287,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate2((C_word*)lf[214]+1 /* (set! node-class-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7296,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate2((C_word*)lf[216]+1 /* (set! node-parameters ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7305,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate2((C_word*)lf[217]+1 /* (set! node-parameters-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7314,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate2((C_word*)lf[218]+1 /* (set! node-subexpressions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7323,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate2((C_word*)lf[219]+1 /* (set! node-subexpressions-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7332,tmp=(C_word)a,a+=2,tmp));
t31=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7342,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t32=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15827,tmp=(C_word)a,a+=2,tmp);
/* support.scm:511: ##sys#register-record-printer */
t33=*((C_word*)lf[560]+1);
((C_proc4)(void*)(*((C_word*)t33+1)))(4,t33,t31,lf[211],t32);}

/* a9517 in k9511 in k9508 in a9505 in a9493 in inline-lambda-bindings in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9518(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9518,5,t0,t1,t2,t3,t4);}
t5=C_a_i_list1(&a,1,t2);
t6=C_a_i_list2(&a,2,t3,t4);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_record4(&a,4,lf[211],lf[109],t5,t6));}

/* k15075 in k15178 in k15069 in constant-form-eval in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1471: g3678 */
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k9508 in a9505 in a9493 in inline-lambda-bindings in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9510,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9513,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[7])){
/* support.scm:689: copy-node-tree-and-rename */
t4=*((C_word*)lf[284]+1);
f_9639(7,t4,t3,((C_word*)t0)[8],((C_word*)t0)[9],t2,((C_word*)t0)[10],((C_word*)t0)[11]);}
else{
t4=t3;
f_9513(2,t4,((C_word*)t0)[8]);}}

/* k15069 in constant-form-eval in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15071,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_i_check_list_2(t2,lf[161]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15180,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15182,a[2]=t6,a[3]=t10,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_15182(t12,t8,t2);}

/* k7569 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7574,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7642,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7642(t6,t2,t1);}

/* k4876 in for-each-loop101 in k4861 in collect in with-debugging-output in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4868(t3,((C_word*)t0)[4],t2);}

/* k7572 in k7569 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7574,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7578,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7580,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t9=C_i_cadr(((C_word*)t0)[4]);
t10=C_i_check_list_2(t9,lf[161]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7597,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7607,a[2]=t7,a[3]=t13,a[4]=t5,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_7607(t15,t11,t9);}

/* a5973 in string->expr in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5974(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5974,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5980,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6005,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:301: with-exception-handler */
t5=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a15087 in a15081 in k15178 in k15069 in constant-form-eval in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15088(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_15088,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15094,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1471: k3674 */
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a11498 in k11486 in pprint-expressions-to-file in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11499,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_i_check_list_2(t2,lf[34]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11516,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_11516(t7,t1,t2);}

/* k4906 in test-mode in with-debugging-output in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_pairp(t1));}

/* k11489 in k11486 in pprint-expressions-to-file in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(((C_word*)t0)[2])){
/* support.scm:1003: close-output-port */
t2=*((C_word*)lf[343]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* a15081 in k15178 in k15069 in constant-form-eval in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15082(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_15082,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15088,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15104,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* support.scm:1471: with-exception-handler */
t5=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* k4861 in collect in with-debugging-output in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4863,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4868,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4868(t5,((C_word*)t0)[3],t1);}

/* for-each-loop101 in k4861 in collect in with-debugging-output in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_4868(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4868,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4878,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:82: g102 */
t5=((C_word*)t0)[3];
f_4836(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* a5985 in a5979 in a5973 in string->expr in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5994,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5997,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:307: exn? */
t4=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k10539 in k10584 in k10505 in k10617 in k10481 in a10475 in emit-global-inline-file in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10541,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10544,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_eqp(t1,lf[306]);
if(C_truep(t3)){
t4=t2;
f_10544(t4,C_SCHEME_TRUE);}
else{
t4=C_eqp(t1,lf[307]);
if(C_truep(t4)){
t5=t2;
f_10544(t5,C_SCHEME_FALSE);}
else{
t5=C_i_cadddr(((C_word*)t0)[7]);
t6=t2;
f_10544(t6,C_i_lessp(t5,*((C_word*)lf[308]+1)));}}}

/* a5979 in a5973 in string->expr in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5980(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5980,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5986,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* support.scm:301: k485 */
t4=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* k10542 in k10539 in k10584 in k10505 in k10617 in k10481 in a10475 in emit-global-inline-file in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_10544(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10544,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10560,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=C_u_i_cdr(((C_word*)t0)[6]);
/* support.scm:796: node->sexpr */
t6=*((C_word*)lf[290]+1);
f_10206(3,t6,t4,t5);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a15093 in a15087 in a15081 in k15178 in k15069 in constant-form-eval in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15094,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15102,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1476: get-condition-property */
t3=*((C_word*)lf[514]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],lf[515],lf[516]);}

/* ##compiler#pprint-expressions-to-file in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11484(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11484,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11488,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
/* support.scm:995: open-output-file */
t5=*((C_word*)lf[346]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}
else{
t5=t4;
f_11488(2,t5,*((C_word*)lf[13]+1));}}

/* k11486 in pprint-expressions-to-file in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11488,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11491,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11499,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* support.scm:996: with-output-to-port */
t5=*((C_word*)lf[345]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,t4);}

/* k5850 in k5844 in basic-literal? in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5852,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5867,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=C_u_i_car(t3);
/* support.scm:282: basic-literal? */
t5=*((C_word*)lf[103]+1);
f_5830(3,t5,t2,t4);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* k7853 in loop in k7890 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7855,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7835,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7843,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7847,a[2]=((C_word*)t0)[5],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* support.scm:571: cadar */
t7=*((C_word*)lf[238]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[6]);}

/* map-loop1556 in k8779 in k8776 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_8800(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8800,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list2(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=t9;
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8813,a[2]=((C_word*)t0)[2],a[3]=t10,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t12=t11;
f_8813(t12,C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t10));}
else{
t12=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t10);
t13=t11;
f_8813(t13,t12);}}
else{
t6=((C_word*)((C_word*)t0)[4])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k4952 in k4949 in quit in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:107: exit */
t2=*((C_word*)lf[30]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(1));}

/* k5865 in k5850 in k5844 in basic-literal? in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* support.scm:283: basic-literal? */
t4=*((C_word*)lf[103]+1);
f_5830(3,t4,((C_word*)t0)[3],t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4949 in quit in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4954,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:106: newline */
t3=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k7841 in k7853 in loop in k7890 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7843,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
/* support.scm:571: reverse */
t3=*((C_word*)lf[91]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],t2);}

/* k8811 in map-loop1556 in k8779 in k8776 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_8813(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[6])[1];
f_8800(t5,((C_word*)t0)[7],t3,t4);}

/* k7845 in k7853 in loop in k7890 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:571: walk */
t2=((C_word*)((C_word*)t0)[2])[1];
f_7383(3,t2,((C_word*)t0)[3],t1);}

/* k4943 in k4936 in k4912 in with-debugging-output in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:101: collect */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4834(t2,((C_word*)t0)[3],t1);}

/* ##compiler#quit in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4947(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_4947r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4947r(t0,t1,t2,t3);}}

static void C_ccall f_4947r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(9);
t4=*((C_word*)lf[29]+1);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4951,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4961,a[2]=t5,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:105: string-append */
t7=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,lf[31],t2);}

/* k6117 in expand-profile-lambda in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[106],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6119,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]),*((C_word*)lf[130]+1));
t3=C_mutate2((C_word*)lf[130]+1 /* (set! ##compiler#profile-lambda-list ...) */,t2);
t4=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
t5=C_mutate2((C_word*)lf[129]+1 /* (set! ##compiler#profile-lambda-index ...) */,t4);
t6=C_a_i_list(&a,2,lf[97],((C_word*)t0)[2]);
t7=C_a_i_list(&a,3,lf[131],t6,*((C_word*)lf[132]+1));
t8=C_a_i_list(&a,3,lf[133],C_SCHEME_END_OF_LIST,t7);
t9=C_a_i_list(&a,3,lf[133],((C_word*)t0)[4],((C_word*)t0)[5]);
t10=C_a_i_list(&a,3,lf[134],t9,t1);
t11=C_a_i_list(&a,3,lf[133],C_SCHEME_END_OF_LIST,t10);
t12=C_a_i_list(&a,2,lf[97],((C_word*)t0)[2]);
t13=C_a_i_list(&a,3,lf[135],t12,*((C_word*)lf[132]+1));
t14=C_a_i_list(&a,3,lf[133],C_SCHEME_END_OF_LIST,t13);
t15=C_a_i_list(&a,4,lf[136],t8,t11,t14);
t16=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_a_i_list(&a,3,lf[133],t1,t15));}

/* ##compiler#basic-literal? in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5830(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5830,3,t0,t1,t2);}
t3=C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=C_i_symbolp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5846,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:279: constant? */
t6=*((C_word*)lf[96]+1);
f_5692(3,t6,t5,t2);}}}

/* ##compiler#expand-profile-lambda in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6115(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6115,5,t0,t1,t2,t3,t4);}
t5=*((C_word*)lf[129]+1);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6119,a[2]=t5,a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* support.scm:334: gensym */
t7=*((C_word*)lf[110]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k7874 in loop in k7890 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7876,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
/* support.scm:572: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7769(t3,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],t2);}

/* k4936 in k4912 in with-debugging-output in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4938,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4945,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:101: with-output-to-string */
t3=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5844 in basic-literal? in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5846,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5852,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_vectorp(((C_word*)t0)[3]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5884,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:280: vector->list */
t4=*((C_word*)lf[105]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=t2;
f_5852(2,t3,C_SCHEME_FALSE);}}}

/* k10505 in k10617 in k10481 in a10475 in emit-global-inline-file in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_10507(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10507,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_i_assq(lf[199],((C_word*)t0)[2]))){
t2=C_i_cdr(((C_word*)t0)[3]);
t3=C_slot(t2,C_fix(2));
t4=t3;
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10586,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[3],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* support.scm:789: get */
t6=*((C_word*)lf[148]+1);
f_6369(5,t6,t5,((C_word*)t0)[8],((C_word*)t0)[5],lf[206]);}
else{
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a10939 in k10924 in walk in expression-has-side-effects? in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10940(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10940,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10948,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:875: foreign-callback-stub-id */
t4=*((C_word*)lf[318]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4921 in k4918 in k4915 in k4912 in with-debugging-output in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4923,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4929,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:98: test-mode */
f_4891(t2,((C_word*)t0)[6],*((C_word*)lf[9]+1));}

/* k4918 in k4915 in k4912 in with-debugging-output in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4920,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4923,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm:97: flush-output */
t3=*((C_word*)lf[22]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k10946 in a10939 in k10924 in walk in expression-has-side-effects? in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_eqp(((C_word*)t0)[3],t1));}

/* k7811 in loop in k7890 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7813,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7792,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_a_i_record4(&a,4,lf[211],lf[226],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,t5,((C_word*)t0)[4]);
/* support.scm:565: reverse */
t7=*((C_word*)lf[91]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t4,t6);}

/* map-llist in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5063(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5063,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5069,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5069(t7,t1,t3);}

/* ##compiler#emit-syntax-trace-info in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5060(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5060,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_emit_syntax_trace_info(t2,t3,*((C_word*)lf[36]+1)));}

/* k10924 in walk in expression-has-side-effects? in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_10926(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10926,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=C_eqp(((C_word*)t0)[3],lf[133]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
t4=C_slot(t3,C_fix(2));
t5=C_i_car(t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10940,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* support.scm:874: find */
t8=*((C_word*)lf[319]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[2],t7,*((C_word*)lf[320]+1));}
else{
t3=C_eqp(((C_word*)t0)[3],lf[225]);
if(C_truep(t3)){
if(C_truep(t3)){
/* support.scm:877: any */
t4=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[6]);}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}}
else{
t4=C_eqp(((C_word*)t0)[3],lf[109]);
if(C_truep(t4)){
/* support.scm:877: any */
t5=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[6]);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}}}}}

/* loop in map-llist in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_5069(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5069,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep(C_i_symbolp(t2))){
/* support.scm:132: proc */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5092,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=C_i_car(t2);
/* support.scm:133: proc */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}}}

/* k5035 in k4965 in syntax-error-hook in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5037,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5040,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:119: ##sys#print */
t3=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)((C_word*)t0)[4])[1],C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k8776 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8778,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8781,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8849,a[2]=((C_word*)t0)[8],a[3]=t4,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_8849(t6,t2,t1);}

/* k10428 in a10425 in k10361 in emit-global-inline-file in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10441,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:808: reverse */
t3=*((C_word*)lf[91]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[3])[1]);}

/* k10433 in for-each-loop2209 in k10439 in k10428 in a10425 in k10361 in emit-global-inline-file in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:807: newline */
t2=*((C_word*)lf[12]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k5041 in k5038 in k5035 in k4965 in syntax-error-hook in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:119: ##sys#write-char-0 */
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(10),((C_word*)t0)[3]);}

/* k5038 in k5035 in k4965 in syntax-error-hook in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5040,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5043,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:119: ##sys#write-char-0 */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[3]);}

/* k8779 in k8776 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8781,2,t0,t1);}
t2=C_i_check_list_2(((C_word*)t0)[2],lf[161]);
t3=C_i_check_list_2(t1,lf[161]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8790,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8800,a[2]=((C_word*)t0)[6],a[3]=t6,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_8800(t8,t4,((C_word*)t0)[2],t1);}

/* a10425 in k10361 in emit-global-inline-file in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10426,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10430,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10474,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:802: chicken-version */
t4=*((C_word*)lf[304]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5090 in loop in map-llist in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5092,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5096,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* support.scm:133: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5069(t6,t3,t5);}

/* k5094 in k5090 in loop in map-llist in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5096,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k10099 in map-loop1853 in copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_10101(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[6])[1];
f_10088(t5,((C_word*)t0)[7],t3,t4);}

/* k10472 in a10425 in k10361 in emit-global-inline-file in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:802: print */
t2=*((C_word*)lf[293]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[2],lf[300],t1,lf[301],*((C_word*)lf[302]+1),lf[303]);}

/* a10475 in emit-global-inline-file in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10476(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10476,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10483,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* support.scm:781: variable-visible? */
t5=*((C_word*)lf[311]+1);
f_15618(3,t5,t4,t2);}

/* k8681 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8683,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[262],t2));}

/* map-loop1514 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_8685(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8685,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8714,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:628: g1520 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10457 in for-each-loop2209 in k10439 in k10428 in a10425 in k10361 in emit-global-inline-file in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10449(t3,((C_word*)t0)[4],t2);}

/* k9745 in k9753 in walk in k9647 in copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9747,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
t3=((C_word*)t0)[2];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[211],lf[244],((C_word*)t0)[3],t2));}

/* k10442 in k10439 in k10428 in a10425 in k10361 in emit-global-inline-file in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:809: print */
t2=*((C_word*)lf[293]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[298]);}

/* k10439 in k10428 in a10425 in k10361 in emit-global-inline-file in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10444,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10449,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_10449(t6,t2,t1);}

/* for-each-loop2209 in k10439 in k10428 in a10425 in k10361 in emit-global-inline-file in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_10449(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10449,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10459,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10435,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* support.scm:806: pp */
t7=*((C_word*)lf[299]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9769 in walk in k9647 in copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9771,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9774,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* support.scm:729: gensym */
t4=*((C_word*)lf[110]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k9772 in k9769 in walk in k9647 in copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9774,2,t0,t1);}
t2=t1;
t3=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[2],t2),((C_word*)t0)[3]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9780,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* support.scm:731: put! */
t6=*((C_word*)lf[152]+1);
f_6405(6,t6,t5,((C_word*)t0)[8],t2,lf[286],C_SCHEME_TRUE);}

/* k15018 in call-info in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k9753 in walk in k9647 in copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9755,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9747,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_i_car(((C_word*)t0)[3]);
/* support.scm:725: walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_9657(t6,t4,t5,((C_word*)t0)[5]);}

/* map-loop1853 in copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_10088(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10088,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_cons(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=t9;
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10101,a[2]=((C_word*)t0)[2],a[3]=t10,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t12=t11;
f_10101(t12,C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t10));}
else{
t12=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t10);
t13=t11;
f_10101(t13,t12);}}
else{
t6=((C_word*)((C_word*)t0)[4])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k6997 in k6994 in k6991 in k6985 in k6906 in loop in k6704 in a6695 in k6689 in display-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cdar(((C_word*)t0)[2]);
/* support.scm:481: ##sys#print */
t3=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],t2,C_SCHEME_TRUE,((C_word*)t0)[4]);}

/* k6991 in k6985 in k6906 in loop in k6704 in a6695 in k6689 in display-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6993,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6996,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_caar(((C_word*)t0)[2]);
/* support.scm:481: ##sys#print */
t4=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k6994 in k6991 in k6985 in k6906 in loop in k6704 in a6695 in k6689 in display-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6996,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6999,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:481: ##sys#write-char-0 */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(61),((C_word*)t0)[4]);}

/* k8326 in map-loop1351 in k8211 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8328,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8299(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8299(t6,((C_word*)t0)[5],t5);}}

/* k8657 in map-loop1485 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8659,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8630(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8630(t6,((C_word*)t0)[5],t5);}}

/* k10481 in a10475 in emit-global-inline-file in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10483,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_assq(lf[173],((C_word*)t0)[2]);
t3=t2;
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10619,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t5=((C_word*)t0)[4];
/* tweaks.scm:57: ##sys#get */
t6=*((C_word*)lf[253]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,lf[310]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* ##compiler#chop-extension in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14686(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14686,3,t0,t1,t2);}
t3=C_i_string_length(t2);
t4=C_a_i_minus(&a,2,t3,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14695,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_14695(t8,t1,t4);}

/* a8336 in k8211 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8337,2,t0,t1);}
/* support.scm:601: get-line-2 */
t2=*((C_word*)lf[159]+1);
f_6577(3,t2,t1,((C_word*)t0)[2]);}

/* k10172 in k10169 in copy-node! in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10174,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10177,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[4];
t4=C_slot(t3,C_fix(3));
t5=((C_word*)t0)[3];
t6=C_i_check_structure_2(t5,lf[211],C_SCHEME_FALSE);
/* support.scm:504: ##sys#block-set! */
t7=*((C_word*)lf[215]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t2,t5,C_fix(3),t4);}

/* k10169 in copy-node! in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10171,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10174,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=C_slot(t3,C_fix(2));
t5=((C_word*)t0)[3];
t6=C_i_check_structure_2(t5,lf[211],C_SCHEME_FALSE);
/* support.scm:504: ##sys#block-set! */
t7=*((C_word*)lf[215]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t2,t5,C_fix(2),t4);}

/* k10175 in k10172 in k10169 in copy-node! in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* ##compiler#constant-form-eval in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15050(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_15050,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_i_check_list_2(t3,lf[161]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15071,a[2]=t2,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15217,a[2]=t8,a[3]=t12,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t14=((C_word*)t12)[1];
f_15217(t14,t10,t3);}

/* k14652 in scan-free-variables in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1360: values */
C_values(4,0,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[4])[1]);}

/* map-loop1485 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_8630(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8630,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8659,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:626: g1491 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* ##compiler#chop-separator in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14659(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14659,3,t0,t1,t2);}
t3=C_i_string_length(t2);
t4=C_a_i_minus(&a,2,t3,C_fix(1));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14669,a[2]=t1,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_greaterp(t5,C_fix(0)))){
t7=C_i_string_ref(t2,t5);
t8=t6;
f_14669(t8,C_u_i_memq(t7,lf[483]));}
else{
t7=t6;
f_14669(t7,C_SCHEME_FALSE);}}

/* k10159 in k10155 in rec in tree-copy in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10161,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k7669 in map-loop1100 in k7569 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7671,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7642(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7642(t6,((C_word*)t0)[5],t5);}}

/* k5415 in k5411 in k5404 in loop in k5380 in c-ify-string in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5417,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5421,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[4];
t5=C_u_i_cdr(t4);
/* support.scm:197: loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_5384(t6,t3,t5);}

/* k5411 in k5404 in loop in k5380 in c-ify-string in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_5413(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5413,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5417,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5427,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm:196: number->string */
C_number_to_string(4,0,t4,((C_word*)t0)[5],C_fix(8));}

/* ##compiler#copy-node! in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10167(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10167,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10171,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=C_slot(t5,C_fix(1));
t7=t3;
t8=C_i_check_structure_2(t7,lf[211],C_SCHEME_FALSE);
/* support.scm:504: ##sys#block-set! */
t9=*((C_word*)lf[215]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t4,t7,C_fix(1),t6);}

/* map-loop1801 in a9505 in a9493 in inline-lambda-bindings in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_9604(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9604,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9633,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:687: g1807 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8788 in k8779 in k8776 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8790,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8794,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8798,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:637: last */
t5=*((C_word*)lf[263]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}

/* map-loop1198 in k7917 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_7930(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7930,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7959,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:580: g1204 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8792 in k8788 in k8779 in k8776 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8794,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,3,lf[109],((C_word*)t0)[3],t1));}

/* k8796 in k8788 in k8779 in k8776 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:637: walk */
t2=((C_word*)((C_word*)t0)[2])[1];
f_8584(3,t2,((C_word*)t0)[3],t1);}

/* k6635 in k6632 in a6623 in display-line-number-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6640,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t0)[4];
t8=C_i_check_list_2(t7,lf[161]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6650,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6652,a[2]=t6,a[3]=t11,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_6652(t13,t9,t7);}

/* k6632 in a6623 in display-line-number-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6637,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:430: ##sys#write-char-0 */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[3]);}

/* k5425 in k5411 in k5404 in loop in k5380 in c-ify-string in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=*((C_word*)lf[72]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5419 in k5415 in k5411 in k5404 in loop in k5380 in c-ify-string in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:192: append */
t2=*((C_word*)lf[70]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[71],((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k10155 in rec in tree-copy in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10157,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10161,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* support.scm:757: rec */
t6=((C_word*)((C_word*)t0)[4])[1];
f_10143(t6,t3,t5);}

/* a6623 in display-line-number-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6624(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6624,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=*((C_word*)lf[13]+1);
t5=*((C_word*)lf[13]+1);
t6=C_i_check_port_2(*((C_word*)lf[13]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[14]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6634,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:430: ##sys#print */
t8=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,t2,C_SCHEME_TRUE,*((C_word*)lf[13]+1));}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* rec in tree-copy in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_10143(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10143,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10157,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=C_u_i_car(t4);
/* support.scm:757: rec */
t8=t3;
t9=t5;
t1=t8;
t2=t9;
goto loop;}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9918 in k9902 in k9839 in k9836 in a9822 in walk in k9647 in copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:748: build-lambda-list */
t2=*((C_word*)lf[64]+1);
f_5324(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k7926 in k7917 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7928,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record4(&a,4,lf[211],((C_word*)t0)[3],((C_word*)t0)[4],t1));}

/* k14638 in for-each-loop3478 in walkeach in scan-free-variables in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_14630(t3,((C_word*)t0)[4],t2);}

/* ##compiler#tree-copy in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10137(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10137,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10143,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_10143(t6,t1,t2);}

/* map-loop1100 in k7569 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_7642(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7642,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7671,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_eqp(lf[232],t4);
if(C_truep(t5)){
/* support.scm:548: gensym */
t6=*((C_word*)lf[110]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=t3;
f_7671(2,t6,t4);}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5404 in loop in k5380 in c-ify-string in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_5406(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5406,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5413,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_lessp(((C_word*)t0)[5],C_fix(8)))){
t3=t2;
f_5413(t3,lf[73]);}
else{
t3=C_fixnum_lessp(((C_word*)t0)[5],C_fix(64));
t4=t2;
f_5413(t4,(C_truep(t3)?lf[74]:C_SCHEME_END_OF_LIST));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5447,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
/* support.scm:198: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5384(t5,t2,t4);}}

/* k7509 in k7502 in k7499 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7511,2,t0,t1);}
t2=C_i_inexact_to_exact(t1);
t3=((C_word*)t0)[2];
t4=C_a_i_list1(&a,1,t2);
t5=t3;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[211],lf[97],t4,C_SCHEME_END_OF_LIST));}

/* walk in expression-has-side-effects? in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10900(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10900,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(3));
t5=t4;
t6=t2;
t7=C_slot(t6,C_fix(1));
t8=t7;
t9=C_eqp(t8,lf[221]);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10926,a[2]=t1,a[3]=t8,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t9)){
t11=t10;
f_10926(t11,t9);}
else{
t11=C_eqp(t8,lf[97]);
if(C_truep(t11)){
t12=t10;
f_10926(t12,t11);}
else{
t12=C_eqp(t8,lf[226]);
t13=t10;
f_10926(t13,(C_truep(t12)?t12:C_eqp(t8,lf[243])));}}}

/* g3479 in walkeach in scan-free-variables in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_14618(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14618,NULL,3,t0,t1,t2);}
/* support.scm:1357: walk */
t3=((C_word*)((C_word*)t0)[2])[1];
f_14432(t3,t1,t2,((C_word*)t0)[3]);}

/* walkeach in scan-free-variables in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_14616(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14616,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14618,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_i_check_list_2(t2,lf[34]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14630,a[2]=t7,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_14630(t9,t1,t2);}

/* map-loop1750 in k9208 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_9334(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9334,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9363,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:671: g1756 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9330 in k9208 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:671: append */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k7634 in map-loop1127 in k7572 in k7569 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7636,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7607(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7607(t6,((C_word*)t0)[5],t5);}}

/* map-loop1934 in a9822 in walk in k9647 in copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_9981(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9981,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10010,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:739: g1940 */
t5=((C_word*)t0)[5];
f_9825(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9323 in k9208 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9325,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k14667 in chop-separator in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_14669(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* support.scm:1369: substring */
t2=*((C_word*)lf[482]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k15466 in user-read-hook in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15468,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15471,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1535: scan-sharp-greater-string */
t3=*((C_word*)lf[532]+1);
f_15483(3,t3,t2,((C_word*)t0)[3]);}

/* k9778 in k9772 in k9769 in walk in k9647 in copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9780,2,t0,t1);}
t2=C_a_i_list1(&a,1,((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9800,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=C_i_cadr(((C_word*)t0)[5]);
/* support.scm:734: walk */
t6=((C_word*)((C_word*)t0)[6])[1];
f_9657(t6,t4,t5,((C_word*)t0)[7]);}

/* for-each-loop3478 in walkeach in scan-free-variables in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_14630(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14630,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14640,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:1327: g3479 */
t5=((C_word*)t0)[3];
f_14618(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9312 in map-loop1724 in k9208 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9314,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9285(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9285(t6,((C_word*)t0)[5],t5);}}

/* k8234 in k8211 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8236,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record4(&a,4,lf[211],((C_word*)t0)[3],((C_word*)t0)[4],t1));}

/* map-loop1320 in k8211 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_8238(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8238,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8267,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:597: g1326 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* ##compiler#display-line-number-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6618,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6624,tmp=(C_word)a,a+=2,tmp);
/* support.scm:428: ##sys#hash-table-for-each */
t3=*((C_word*)lf[162]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,*((C_word*)lf[158]+1));}

/* k15485 in scan-sharp-greater-string in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15487,2,t0,t1);}
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15492,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_15492(t6,((C_word*)t0)[3]);}

/* ##compiler#scan-sharp-greater-string in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15483(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_15483,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15487,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1540: open-output-string */
t4=*((C_word*)lf[53]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k8211 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_8213(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8213,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=C_i_cadr(((C_word*)t0)[2]);
t5=t4;
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=((C_word*)((C_word*)t0)[3])[1];
t11=((C_word*)t0)[2];
t12=C_u_i_cdr(t11);
t13=C_u_i_cdr(t12);
t14=C_i_check_list_2(t13,lf[161]);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8236,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8238,a[2]=t9,a[3]=t17,a[4]=t7,a[5]=t10,tmp=(C_word)a,a+=6,tmp));
t19=((C_word*)t17)[1];
f_8238(t19,t15,t13);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[250]);
if(C_truep(t2)){
t3=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t4=t3;
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=((C_word*)((C_word*)t0)[3])[1];
t10=((C_word*)t0)[2];
t11=C_u_i_cdr(t10);
t12=C_i_check_list_2(t11,lf[161]);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8297,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8299,a[2]=t8,a[3]=t15,a[4]=t6,a[5]=t9,tmp=(C_word)a,a+=6,tmp));
t17=((C_word*)t15)[1];
f_8299(t17,t13,t11);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8337,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8343,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* support.scm:601: ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[4],t3,t4);}}}

/* ##sys#user-read-hook in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15458(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_15458,4,t0,t1,t2,t3);}
if(C_truep(C_i_char_equalp(C_make_character(62),t2))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15468,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* read-char/port */
t5=*((C_word*)lf[533]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}
else{
/* support.scm:1537: old-hook */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,t3);}}

/* ##compiler#read/source-info in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15452(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_15452,3,t0,t1,t2);}
/* support.scm:1525: ##sys#read */
t3=*((C_word*)lf[528]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,*((C_word*)lf[523]+1));}

/* k10396 in for-each-loop2231 in k10378 in k10370 in k10364 in k10361 in emit-global-inline-file in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10388(t3,((C_word*)t0)[4],t2);}

/* k15469 in k15466 in user-read-hook in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15471,2,t0,t1);}
t2=C_a_i_list(&a,2,lf[530],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,2,lf[531],t2));}

/* k9910 in k9902 in k9839 in k9836 in a9822 in walk in k9647 in copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9912,2,t0,t1);}
t2=C_i_cadddr(((C_word*)t0)[2]);
t3=C_a_i_list4(&a,4,((C_word*)t0)[3],((C_word*)t0)[4],t1,t2);
t4=t3;
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9855,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t10=C_i_check_list_2(((C_word*)t0)[7],lf[161]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9865,a[2]=((C_word*)t0)[8],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9867,a[2]=t8,a[3]=t13,a[4]=t6,a[5]=t9,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_9867(t15,t11,((C_word*)t0)[7]);}

/* k4817 in debugging in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k5914 in loop in canonicalize-begin-body in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_5916(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5916,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* support.scm:296: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5892(t4,((C_word*)t0)[4],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5942,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm:297: gensym */
t3=*((C_word*)lf[110]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[111]);}}

/* k4808 in k4805 in k4802 in k4799 in debugging in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* k15411 in read-info-hook in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* k15414 in read-info-hook in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_15416(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15416,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15431,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1519: conc */
t5=*((C_word*)lf[504]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,*((C_word*)lf[524]+1),lf[525],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k9902 in k9839 in k9836 in a9822 in walk in k9647 in copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9904,2,t0,t1);}
t2=t1;
t3=C_i_cadr(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9912,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9920,a[2]=t5,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[9])){
t7=((C_word*)t0)[9];
/* support.scm:709: alist-ref */
t8=*((C_word*)lf[285]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,t7,((C_word*)t0)[4],*((C_word*)lf[27]+1),t7);}
else{
/* support.scm:748: build-lambda-list */
t7=*((C_word*)lf[64]+1);
f_5324(5,t7,t5,((C_word*)t0)[7],((C_word*)t0)[8],C_SCHEME_FALSE);}}

/* g102 in collect in with-debugging-output in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_4836(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4836,NULL,3,t0,t1,t2);}
t3=*((C_word*)lf[8]+1);
t4=*((C_word*)lf[8]+1);
t5=C_i_check_port_2(*((C_word*)lf[8]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[21]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4843,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t7=((C_word*)t0)[2];
t8=C_u_i_car(t7);
/* support.scm:85: ##sys#print */
t9=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t6,t8,C_SCHEME_FALSE,*((C_word*)lf[8]+1));}
else{
t7=((C_word*)t0)[2];
/* support.scm:85: ##sys#print */
t8=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t6,t7,C_SCHEME_FALSE,t3);}}

/* collect in with-debugging-output in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_4834(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4834,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4836,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4863,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:89: string-split */
t5=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[25]);}

/* ##compiler#with-debugging-output in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4831(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4831,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4834,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t9=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4891,tmp=(C_word)a,a+=2,tmp));
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4914,a[2]=t5,a[3]=t1,a[4]=t7,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm:94: test-mode */
f_4891(t10,t2,*((C_word*)lf[1]+1));}

/* k5930 in k5940 in k5914 in loop in canonicalize-begin-body in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5932,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,3,lf[109],((C_word*)t0)[3],t1));}

/* k15433 in k15429 in k15414 in read-info-hook in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15435,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]),t2);
/* support.scm:1515: ##sys#hash-table-set! */
t4=*((C_word*)lf[153]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[4],*((C_word*)lf[158]+1),((C_word*)t0)[5],t3);}
else{
t2=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]),C_SCHEME_END_OF_LIST);
/* support.scm:1515: ##sys#hash-table-set! */
t3=*((C_word*)lf[153]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[4],*((C_word*)lf[158]+1),((C_word*)t0)[5],t2);}}

/* k15429 in k15414 in read-info-hook in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15431,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15435,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
t5=C_u_i_car(t4);
/* support.scm:1520: ##sys#hash-table-ref */
t6=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,*((C_word*)lf[158]+1),t5);}

/* k4827 in debugging in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:79: dump */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4779(t2,((C_word*)t0)[3],t1);}

/* k5945 in loop in canonicalize-begin-body in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
f_5916(t3,t2);}
else{
t2=((C_word*)t0)[2];
f_5916(t2,C_i_equalp(((C_word*)t0)[3],lf[112]));}}

/* k5940 in k5914 in loop in canonicalize-begin-body in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5942,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=C_a_i_list(&a,2,t1,t3);
t5=C_a_i_list(&a,1,t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5932,a[2]=((C_word*)t0)[3],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=((C_word*)t0)[2];
t9=C_u_i_cdr(t8);
/* support.scm:298: loop */
t10=((C_word*)((C_word*)t0)[4])[1];
f_5892(t10,t7,t9);}

/* ##compiler#read-info-hook in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15409(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_15409,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15413,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15416,a[2]=t3,a[3]=t5,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=C_eqp(lf[526],t2);
if(C_truep(t7)){
t8=C_i_car(t3);
t9=t6;
f_15416(t9,C_i_symbolp(t8));}
else{
t8=t6;
f_15416(t8,C_SCHEME_FALSE);}}

/* k7499 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_7501(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7501,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7504,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:535: warning */
t3=*((C_word*)lf[228]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[229],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
t3=C_a_i_list1(&a,1,((C_word*)t0)[3]);
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[211],lf[97],t3,C_SCHEME_END_OF_LIST));}}

/* k4847 in k4844 in k4841 in g102 in collect in with-debugging-output in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:85: ##sys#write-char-0 */
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(10),((C_word*)t0)[3]);}

/* k4844 in k4841 in g102 in collect in with-debugging-output in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4849,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:85: ##sys#print */
t3=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k4841 in g102 in collect in with-debugging-output in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4846,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:85: ##sys#write-char-0 */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(124),((C_word*)t0)[3]);}

/* k10658 in k10635 in loop in a10626 in load-inline-file in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:824: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_10633(t2,((C_word*)t0)[3]);}

/* k7502 in k7499 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7504,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7511,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:537: truncate */
t3=*((C_word*)lf[227]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k4799 in debugging in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4801,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4804,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* support.scm:72: display */
t4=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4805 in k4802 in k4799 in debugging in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4807,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4810,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_memq(((C_word*)t0)[3],*((C_word*)lf[9]+1)))){
/* support.scm:75: dump */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4779(t3,t2,((C_word*)t0)[5]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}}

/* k4802 in k4799 in debugging in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4807,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm:73: flush-output */
t3=*((C_word*)lf[22]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k10669 in k10635 in loop in a10626 in load-inline-file in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10671,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
if(C_truep(C_i_nullp(t2))){
/* tweaks.scm:54: ##sys#put! */
t3=*((C_word*)lf[142]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],((C_word*)t0)[3],lf[310],C_SCHEME_TRUE);}
else{
t3=C_i_car(t2);
/* tweaks.scm:54: ##sys#put! */
t4=*((C_word*)lf[142]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],((C_word*)t0)[3],lf[310],t3);}}

/* ##compiler#match-node in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10677(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10677,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10680,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t14=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10714,a[2]=t8,a[3]=t10,tmp=(C_word)a,a+=4,tmp));
t15=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10753,a[2]=t8,a[3]=t12,a[4]=t10,tmp=(C_word)a,a+=5,tmp));
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10868,a[2]=t6,a[3]=t1,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm:858: matchn */
t17=((C_word*)t12)[1];
f_10753(t17,t16,t2,t3);}

/* ##compiler#load-inline-file in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10621(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10621,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10627,tmp=(C_word)a,a+=2,tmp);
/* support.scm:815: with-input-from-file */
t4=*((C_word*)lf[313]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,t3);}

/* a10626 in load-inline-file in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10627,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10633,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_10633(t5,t1);}

/* resolve in match-node in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_10680(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10680,NULL,4,t0,t1,t2,t3);}
t4=C_i_assq(t2,((C_word*)((C_word*)t0)[2])[1]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10688,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm:829: g2293 */
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_10688(t5,t4));}
else{
if(C_truep(C_i_memq(t2,((C_word*)t0)[3]))){
t5=C_a_i_cons(&a,2,C_a_i_cons(&a,2,t2,t3),((C_word*)((C_word*)t0)[2])[1]);
t6=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_TRUE);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_eqp(t2,t3));}}}

/* g2293 in resolve in match-node in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static C_word C_fcall f_10688(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_overflow_check;
t2=C_i_cdr(t1);
return(C_i_equalp(((C_word*)t0)[2],t2));}

/* a6053 in tmp24293 in a6004 in a5973 in string->expr in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6054,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* ##compiler#foreign-type-convert-argument in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_12515(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12515,4,t0,t1,t2,t3);}
if(C_truep(C_i_symbolp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12528,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1139: ##sys#hash-table-ref */
t5=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[395]+1),t3);}
else{
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* a11207 in dump-global-refs in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11208(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11208,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11249,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:923: keyword? */
t5=*((C_word*)lf[323]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* ##compiler#llist-length in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6068(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6068,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_u_i_length(t2));}

/* k12526 in foreign-type-convert-argument in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_12528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12528,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_i_vectorp(t1))){
t2=C_i_vector_ref(t1,C_fix(1));
t3=C_a_i_list2(&a,2,t2,((C_word*)t0)[2]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=((C_word*)t0)[2];
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k6063 in a6004 in a5973 in string->expr in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6065,2,t0,t1);}
/* tmp24293 */
t2=((C_word*)t0)[2];
f_6048(t2,((C_word*)t0)[3],C_a_i_list(&a,1,t1));}

/* k11198 in a11170 in dump-defined-globals in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_11178(t2,C_SCHEME_FALSE);}
else{
t2=C_i_assq(lf[189],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_11178(t3,(C_truep(t2)?C_i_assq(lf[187],((C_word*)t0)[3]):C_SCHEME_FALSE));}}

/* ##compiler#dump-global-refs in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11202(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11202,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11208,tmp=(C_word)a,a+=2,tmp);
/* support.scm:921: ##sys#hash-table-for-each */
t4=*((C_word*)lf[162]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* loop in chop-extension in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_14695(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_14695,NULL,3,t0,t1,t2);}
if(C_truep(C_i_zerop(t2))){
t3=((C_word*)t0)[2];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_i_string_ref(((C_word*)t0)[2],t2);
if(C_truep(C_i_char_equalp(C_make_character(46),t3))){
/* support.scm:1376: substring */
t4=*((C_word*)lf[482]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,((C_word*)t0)[2],C_fix(0),t2);}
else{
t4=C_a_i_minus(&a,2,t2,C_fix(1));
/* support.scm:1377: loop */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}}

/* a6038 in a6032 in tmp14292 in a6004 in a5973 in string->expr in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6039(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6039,3,t0,t1,t2);}
/* support.scm:312: read */
t3=*((C_word*)lf[117]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* a6032 in tmp14292 in a6004 in a5973 in string->expr in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6039,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6047,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:312: read */
t4=*((C_word*)lf[117]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5014 in k4965 in syntax-error-hook in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5019,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:118: ##sys#print */
t3=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k5017 in k5014 in k4965 in syntax-error-hook in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5022,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:118: ##sys#print */
t3=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[38],C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* tmp24293 in a6004 in a5973 in string->expr in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_6048(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6048,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6054,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:301: k485 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* k6045 in a6032 in tmp14292 in a6004 in a5973 in string->expr in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:312: unfold */
t2=*((C_word*)lf[118]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],*((C_word*)lf[119]+1),*((C_word*)lf[120]+1),((C_word*)t0)[3],t1);}

/* k5020 in k5017 in k5014 in k4965 in syntax-error-hook in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5025,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:118: ##sys#print */
t3=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)((C_word*)t0)[4])[1],C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k5023 in k5020 in k5017 in k5014 in k4965 in syntax-error-hook in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5028,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:118: ##sys#write-char-0 */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[3]);}

/* k5026 in k5023 in k5020 in k5017 in k5014 in k4965 in syntax-error-hook in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:118: ##sys#write-char-0 */
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(10),((C_word*)t0)[3]);}

/* k9097 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:660: cons* */
t2=*((C_word*)lf[268]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[242],((C_word*)t0)[3],t1);}

/* ##compiler#llist-match? in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6071(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6071,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6077,tmp=(C_word)a,a+=2,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_6077(t2,t3));}

/* f17172 in print-version in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f17172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1613: print */
t2=*((C_word*)lf[293]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k8190 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8192,2,t0,t1);}
t2=C_i_cadr(t1);
t3=C_a_i_list4(&a,4,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8172,a[2]=((C_word*)t0)[5],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8176,a[2]=((C_word*)t0)[6],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* support.scm:594: sixth */
t7=*((C_word*)lf[247]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[7]);}

/* k9073 in map-loop1626 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9075,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9046(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9046(t6,((C_word*)t0)[5],t5);}}

/* k9713 in k9706 in walk in k9647 in copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9715,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_a_i_list1(&a,1,t1);
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[211],lf[221],t3,C_SCHEME_END_OF_LIST));}

/* k11274 in compute-database-statistics in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:972: values */
C_values(9,0,((C_word*)t0)[2],*((C_word*)lf[330]+1),*((C_word*)lf[331]+1),((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1]);}

/* k9716 in walk in k9647 in copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm:720: cfk */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_9708(2,t2,C_SCHEME_UNDEFINED);}}

/* loop in llist-match? in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static C_word C_fcall f_6077(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_stack_overflow_check;
loop:
if(C_truep(C_i_nullp(t1))){
return(C_i_nullp(t2));}
else{
t3=C_i_symbolp(t1);
if(C_truep(t3)){
return(t3);}
else{
if(C_truep(C_i_nullp(t2))){
return(C_i_not_pair_p(t1));}
else{
t4=C_i_cdr(t1);
t5=C_i_cdr(t2);
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}}}

/* ##compiler#compute-database-statistics in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11272(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11272,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_fix(0);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(0);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_fix(0);
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11276,a[2]=t1,a[3]=t6,a[4]=t4,a[5]=t8,a[6]=t12,a[7]=t10,tmp=(C_word)a,a+=8,tmp);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11281,a[2]=t10,a[3]=t8,a[4]=t6,a[5]=t4,a[6]=t12,tmp=(C_word)a,a+=7,tmp);
/* support.scm:958: ##sys#hash-table-for-each */
t15=*((C_word*)lf[162]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,t14,t2);}

/* k8170 in k8190 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8172,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
t3=((C_word*)t0)[2];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[211],lf[246],((C_word*)t0)[3],t2));}

/* k8174 in k8190 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:594: walk */
t2=((C_word*)((C_word*)t0)[2])[1];
f_7383(3,t2,((C_word*)t0)[3],t1);}

/* k11259 in toplevel-definition-hook in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:936: hide-variable */
t2=*((C_word*)lf[327]+1);
f_15578(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k15302 in k15299 in k15296 in k15287 in loop in dump-nodes in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15304,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_15307,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* support.scm:1491: ##sys#print */
t3=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[9],C_SCHEME_FALSE,((C_word*)t0)[8]);}

/* k15305 in k15302 in k15299 in k15296 in k15287 in loop in dump-nodes in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_15310,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* support.scm:1491: ##sys#write-char-0 */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[8]);}

/* k15299 in k15296 in k15287 in loop in dump-nodes in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_15304,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* support.scm:1491: ##sys#write-char-0 */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(60),((C_word*)t0)[8]);}

/* k14755 in make-random-name in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14757,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[51]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14763,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=((C_word*)t0)[3];
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14787,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t6))){
/* support.scm:1393: gensym */
t8=*((C_word*)lf[110]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=C_i_car(t6);
/* support.scm:1392: ##sys#print */
t9=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t5,t8,C_SCHEME_FALSE,t3);}}

/* k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_8618(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8618,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)((C_word*)t0)[2])[1];
t7=C_i_check_list_2(((C_word*)t0)[3],lf[161]);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8628,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8630,a[2]=t5,a[3]=t10,a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_8630(t12,t8,((C_word*)t0)[3]);}
else{
t2=C_eqp(((C_word*)t0)[6],lf[262]);
if(C_truep(t2)){
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)((C_word*)t0)[2])[1];
t8=C_i_check_list_2(((C_word*)t0)[3],lf[161]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8683,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8685,a[2]=t6,a[3]=t11,a[4]=t4,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_8685(t13,t9,((C_word*)t0)[3]);}
else{
t3=C_eqp(((C_word*)t0)[6],lf[221]);
if(C_truep(t3)){
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_car(((C_word*)t0)[7]));}
else{
t4=C_eqp(((C_word*)t0)[6],lf[97]);
if(C_truep(t4)){
t5=C_i_car(((C_word*)t0)[7]);
t6=C_booleanp(t5);
if(C_truep(t6)){
if(C_truep(t6)){
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t5);}
else{
t7=C_u_i_car(((C_word*)t0)[7]);
t8=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_list(&a,2,lf[97],t7));}}
else{
t7=C_i_stringp(t5);
if(C_truep(t7)){
if(C_truep(t7)){
t8=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t5);}
else{
t8=C_u_i_car(((C_word*)t0)[7]);
t9=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_a_i_list(&a,2,lf[97],t8));}}
else{
t8=C_i_numberp(t5);
t9=(C_truep(t8)?t8:C_charp(t5));
if(C_truep(t9)){
t10=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t5);}
else{
t10=C_u_i_car(((C_word*)t0)[7]);
t11=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_a_i_list(&a,2,lf[97],t10));}}}}
else{
t5=C_eqp(((C_word*)t0)[6],lf[109]);
if(C_truep(t5)){
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=((C_word*)t0)[7];
t11=C_SCHEME_END_OF_LIST;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_FALSE;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=((C_word*)((C_word*)t0)[2])[1];
t16=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8778,a[2]=t10,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t9,a[7]=t7,a[8]=t14,a[9]=t12,a[10]=t15,tmp=(C_word)a,a+=11,tmp);
/* support.scm:636: butlast */
t17=*((C_word*)lf[264]+1);
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t16,((C_word*)t0)[3]);}
else{
t6=C_eqp(((C_word*)t0)[6],lf[133]);
if(C_truep(t6)){
t7=C_i_cadr(((C_word*)t0)[7]);
t8=(C_truep(t7)?lf[234]:lf[133]);
t9=t8;
t10=C_i_caddr(((C_word*)t0)[7]);
t11=t10;
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8903,a[2]=((C_word*)t0)[4],a[3]=t9,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
t13=C_i_car(((C_word*)t0)[3]);
/* support.scm:643: walk */
t14=((C_word*)((C_word*)t0)[2])[1];
f_8584(3,t14,t12,t13);}
else{
t7=C_eqp(((C_word*)t0)[6],lf[235]);
if(C_truep(t7)){
t8=C_i_car(((C_word*)t0)[7]);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8927,a[2]=((C_word*)t0)[4],a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=C_i_car(((C_word*)t0)[3]);
/* support.scm:645: walk */
t12=((C_word*)((C_word*)t0)[2])[1];
f_8584(3,t12,t10,t11);}
else{
t8=C_eqp(((C_word*)t0)[6],lf[266]);
if(C_truep(t8)){
t9=C_i_car(((C_word*)t0)[3]);
/* support.scm:647: walk */
t10=((C_word*)((C_word*)t0)[2])[1];
f_8584(3,t10,((C_word*)t0)[4],t9);}
else{
t9=C_eqp(((C_word*)t0)[6],lf[236]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8961,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t11=C_i_car(((C_word*)t0)[3]);
/* support.scm:650: walk */
t12=((C_word*)((C_word*)t0)[2])[1];
f_8584(3,t12,t10,t11);}
else{
t10=C_eqp(((C_word*)t0)[6],lf[251]);
if(C_truep(t10)){
t11=C_SCHEME_END_OF_LIST;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_FALSE;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=((C_word*)((C_word*)t0)[2])[1];
t16=C_i_check_list_2(((C_word*)t0)[3],lf[161]);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9046,a[2]=t14,a[3]=t18,a[4]=t12,a[5]=t15,tmp=(C_word)a,a+=6,tmp));
t20=((C_word*)t18)[1];
f_9046(t20,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t11=C_eqp(((C_word*)t0)[6],lf[242]);
if(C_truep(t11)){
t12=C_i_car(((C_word*)t0)[7]);
t13=t12;
t14=C_SCHEME_END_OF_LIST;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_FALSE;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=((C_word*)((C_word*)t0)[2])[1];
t19=C_i_check_list_2(((C_word*)t0)[3],lf[161]);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9099,a[2]=((C_word*)t0)[4],a[3]=t13,tmp=(C_word)a,a+=4,tmp);
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_set_block_item(t22,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9101,a[2]=t17,a[3]=t22,a[4]=t15,a[5]=t18,tmp=(C_word)a,a+=6,tmp));
t24=((C_word*)t22)[1];
f_9101(t24,t20,((C_word*)t0)[3]);}
else{
t12=C_eqp(((C_word*)t0)[6],lf[226]);
if(C_truep(t12)){
t13=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_a_i_list1(&a,1,((C_word*)t0)[5]));}
else{
t13=C_eqp(((C_word*)t0)[6],lf[269]);
if(C_truep(t13)){
t14=C_i_car(((C_word*)t0)[7]);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9158,a[2]=((C_word*)t0)[2],a[3]=t16,tmp=(C_word)a,a+=4,tmp));
t18=((C_word*)t16)[1];
f_9158(t18,((C_word*)t0)[4],t14,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t14=C_eqp(((C_word*)t0)[6],lf[270]);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9210,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t14)){
t16=t15;
f_9210(t16,t14);}
else{
t16=C_eqp(((C_word*)t0)[6],lf[272]);
if(C_truep(t16)){
t17=t15;
f_9210(t17,t16);}
else{
t17=C_eqp(((C_word*)t0)[6],lf[273]);
t18=t15;
f_9210(t18,(C_truep(t17)?t17:C_eqp(((C_word*)t0)[6],lf[274])));}}}}}}}}}}}}}}}}

/* ##compiler#posq in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5172(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5172,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5178,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5178(t7,t1,t3,C_fix(0));}

/* loop in posq in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_5178(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5178,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=C_i_car(t2);
t5=C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=t2;
t7=C_u_i_cdr(t6);
t8=C_a_i_plus(&a,2,t3,C_fix(1));
/* support.scm:153: loop */
t10=t1;
t11=t7;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}}

/* map-loop1626 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_9046(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9046,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9075,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:659: g1632 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k15311 in k15308 in k15305 in k15302 in k15299 in k15296 in k15287 in loop in dump-nodes in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15313,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15314,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_check_list_2(((C_word*)t0)[4],lf[34]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15324,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15386,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_15386(t8,t4,((C_word*)t0)[4]);}

/* g3723 in k15311 in k15308 in k15305 in k15302 in k15299 in k15296 in k15287 in loop in dump-nodes in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_15314(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15314,NULL,3,t0,t1,t2);}
/* support.scm:1499: g3738 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_15261(t3,t1,((C_word*)t0)[3],t2);}

/* k14764 in k14761 in k14755 in make-random-name in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14769,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14783,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1394: current-seconds */
t4=*((C_word*)lf[492]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k14761 in k14755 in make-random-name in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14763,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14766,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1392: ##sys#write-char-0 */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(45),((C_word*)t0)[4]);}

/* k15308 in k15305 in k15302 in k15299 in k15296 in k15287 in loop in dump-nodes in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15313,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm:1491: ##sys#print */
t3=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[7],C_SCHEME_TRUE,((C_word*)t0)[8]);}

/* k14767 in k14764 in k14761 in k14755 in make-random-name in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14769,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14772,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14779,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1395: random */
t4=*((C_word*)lf[491]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_fix(1000));}

/* ##compiler#estimate-foreign-result-size in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_12591(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12591,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12597,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13017,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1158: follow-without-loop */
t5=*((C_word*)lf[92]+1);
f_5641(5,t5,t1,t2,t3,t4);}

/* g2451 in a11280 in compute-database-statistics in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static C_word C_fcall f_11283(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_stack_overflow_check;
t2=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_i_car(t1);
t5=C_eqp(t4,lf[189]);
if(C_truep(t5)){
t6=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t6);
return(t7);}
else{
t6=C_eqp(t4,lf[172]);
if(C_truep(t6)){
t7=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[4])[1],C_fix(1));
t8=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t7);
t9=t1;
t10=C_u_i_cdr(t9);
t11=C_slot(t10,C_fix(1));
t12=C_eqp(lf[133],t11);
if(C_truep(t12)){
t13=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t14=C_mutate2(((C_word *)((C_word*)t0)[5])+1,t13);
return(t14);}
else{
t13=C_SCHEME_UNDEFINED;
return(t13);}}
else{
t7=C_eqp(t4,lf[177]);
if(C_truep(t7)){
t8=t1;
t9=C_u_i_cdr(t8);
t10=C_i_length(t9);
t11=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[6])[1],t10);
t12=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t11);
return(t12);}
else{
t8=C_SCHEME_UNDEFINED;
return(t8);}}}}

/* a12596 in estimate-foreign-result-size in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_12597(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12597,4,t0,t1,t2,t3);}
t4=t2;
t5=C_eqp(t4,lf[348]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12607,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_12607(t7,t5);}
else{
t7=C_eqp(t4,lf[352]);
if(C_truep(t7)){
t8=t6;
f_12607(t8,t7);}
else{
t8=C_eqp(t4,lf[425]);
if(C_truep(t8)){
t9=t6;
f_12607(t9,t8);}
else{
t9=C_eqp(t4,lf[437]);
if(C_truep(t9)){
t10=t6;
f_12607(t10,t9);}
else{
t10=C_eqp(t4,lf[438]);
if(C_truep(t10)){
t11=t6;
f_12607(t11,t10);}
else{
t11=C_eqp(t4,lf[426]);
if(C_truep(t11)){
t12=t6;
f_12607(t12,t11);}
else{
t12=C_eqp(t4,lf[439]);
if(C_truep(t12)){
t13=t6;
f_12607(t13,t12);}
else{
t13=C_eqp(t4,lf[349]);
if(C_truep(t13)){
t14=t6;
f_12607(t14,t13);}
else{
t14=C_eqp(t4,lf[424]);
if(C_truep(t14)){
t15=t6;
f_12607(t15,t14);}
else{
t15=C_eqp(t4,lf[427]);
if(C_truep(t15)){
t16=t6;
f_12607(t16,t15);}
else{
t16=C_eqp(t4,lf[428]);
if(C_truep(t16)){
t17=t6;
f_12607(t17,t16);}
else{
t17=C_eqp(t4,lf[429]);
t18=t6;
f_12607(t18,(C_truep(t17)?t17:C_eqp(t4,lf[430])));}}}}}}}}}}}}

/* walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7383(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word *a;
loop:
a=C_alloc(20);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)tr3,(void*)f_7383,3,t0,t1,t2);}
if(C_truep(C_i_symbolp(t2))){
t3=t1;
t4=t2;
t5=C_a_i_list1(&a,1,t4);
t6=t3;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_record4(&a,4,lf[211],lf[221],t5,C_SCHEME_END_OF_LIST));}
else{
t3=t2;
if(C_truep(C_i_structurep(t3,lf[211]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
if(C_truep(C_i_not_pair_p(t2))){
/* support.scm:525: bomb */
t4=*((C_word*)lf[3]+1);
f_4683(4,t4,t1,lf[224],t2);}
else{
t4=C_i_car(t2);
if(C_truep(C_i_symbolp(t4))){
t5=t2;
t6=C_u_i_car(t5);
t7=C_eqp(t6,lf[225]);
t8=(C_truep(t7)?t7:C_eqp(t6,lf[226]));
if(C_truep(t8)){
t9=t2;
t10=C_u_i_car(t9);
t11=C_SCHEME_END_OF_LIST;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_FALSE;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=((C_word*)((C_word*)t0)[2])[1];
t16=t2;
t17=C_u_i_cdr(t16);
t18=C_i_check_list_2(t17,lf[161]);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7447,a[2]=t1,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7449,a[2]=t14,a[3]=t21,a[4]=t12,a[5]=t15,tmp=(C_word)a,a+=6,tmp));
t23=((C_word*)t21)[1];
f_7449(t23,t19,t17);}
else{
t9=C_eqp(t6,lf[97]);
if(C_truep(t9)){
t10=C_i_cadr(t2);
t11=t10;
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7501,a[2]=t1,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_numberp(t11))){
t13=C_eqp(lf[230],*((C_word*)lf[231]+1));
if(C_truep(t13)){
t14=C_i_integerp(t11);
t15=t12;
f_7501(t15,C_i_not(t14));}
else{
t14=t12;
f_7501(t14,C_SCHEME_FALSE);}}
else{
t13=t12;
f_7501(t13,C_SCHEME_FALSE);}}
else{
t10=C_eqp(t6,lf[109]);
if(C_truep(t10)){
t11=C_i_cadr(t2);
t12=C_i_caddr(t2);
t13=t12;
if(C_truep(C_i_nullp(t11))){
/* support.scm:543: walk */
t142=t1;
t143=t13;
t1=t142;
t2=t143;
c=3;
goto loop;}
else{
t14=C_SCHEME_END_OF_LIST;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_FALSE;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7571,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t13,a[6]=t17,a[7]=t15,tmp=(C_word)a,a+=8,tmp);
/* support.scm:549: unzip1 */
t19=*((C_word*)lf[233]+1);
((C_proc3)(void*)(*((C_word*)t19+1)))(3,t19,t18,t11);}}
else{
t11=C_eqp(t6,lf[234]);
t12=(C_truep(t11)?t11:C_eqp(t6,lf[133]));
if(C_truep(t12)){
t13=C_i_cadr(t2);
t14=C_a_i_list1(&a,1,t13);
t15=t14;
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7704,a[2]=t1,a[3]=t15,tmp=(C_word)a,a+=4,tmp);
t17=C_i_caddr(t2);
/* support.scm:553: walk */
t142=t16;
t143=t17;
t1=t142;
t2=t143;
c=3;
goto loop;}
else{
t13=C_eqp(t6,lf[235]);
if(C_truep(t13)){
t14=C_i_cadr(t2);
t15=C_i_caddr(t2);
t16=C_a_i_list2(&a,2,t14,t15);
t17=t16;
t18=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7738,a[2]=t1,a[3]=t17,tmp=(C_word)a,a+=4,tmp);
t19=C_i_cadddr(t2);
/* support.scm:557: walk */
t142=t18;
t143=t19;
t1=t142;
t2=t143;
c=3;
goto loop;}
else{
t14=C_eqp(t6,lf[236]);
if(C_truep(t14)){
t15=C_i_cdddr(t2);
t16=t15;
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7892,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t16,tmp=(C_word)a,a+=6,tmp);
t18=t2;
t19=C_u_i_cdr(t18);
t20=C_u_i_cdr(t19);
t21=C_u_i_car(t20);
/* support.scm:560: walk */
t142=t17;
t143=t21;
t1=t142;
t2=t143;
c=3;
goto loop;}
else{
t15=C_eqp(t6,lf[240]);
if(C_truep(t15)){
t16=C_i_cadr(t2);
t17=t2;
t18=C_u_i_car(t17);
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7919,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=t18,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t16))){
t20=C_u_i_car(t16);
t21=C_eqp(lf[97],t20);
if(C_truep(t21)){
t22=C_i_cadr(t16);
t23=t19;
f_7919(t23,C_a_i_list1(&a,1,t22));}
else{
t22=t19;
f_7919(t22,C_a_i_list1(&a,1,t16));}}
else{
t20=t19;
f_7919(t20,C_a_i_list1(&a,1,t16));}}
else{
t16=C_eqp(t6,lf[241]);
t17=(C_truep(t16)?t16:C_eqp(t6,lf[242]));
if(C_truep(t17)){
t18=t2;
t19=C_u_i_car(t18);
t20=C_i_cadr(t2);
t21=C_a_i_list1(&a,1,t20);
t22=t21;
t23=C_SCHEME_END_OF_LIST;
t24=(*a=C_VECTOR_TYPE|1,a[1]=t23,tmp=(C_word)a,a+=2,tmp);
t25=C_SCHEME_FALSE;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=((C_word*)((C_word*)t0)[2])[1];
t28=t2;
t29=C_u_i_cdr(t28);
t30=C_u_i_cdr(t29);
t31=C_i_check_list_2(t30,lf[161]);
t32=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8013,a[2]=t1,a[3]=t19,a[4]=t22,tmp=(C_word)a,a+=5,tmp);
t33=C_SCHEME_UNDEFINED;
t34=(*a=C_VECTOR_TYPE|1,a[1]=t33,tmp=(C_word)a,a+=2,tmp);
t35=C_set_block_item(t34,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8015,a[2]=t26,a[3]=t34,a[4]=t24,a[5]=t27,tmp=(C_word)a,a+=6,tmp));
t36=((C_word*)t34)[1];
f_8015(t36,t32,t30);}
else{
t18=C_eqp(t6,lf[243]);
if(C_truep(t18)){
t19=C_i_cadr(t2);
t20=C_a_i_list2(&a,2,t19,C_SCHEME_TRUE);
t21=t1;
t22=t21;
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,C_a_i_record4(&a,4,lf[211],lf[243],t20,C_SCHEME_END_OF_LIST));}
else{
t19=C_eqp(t6,lf[244]);
t20=(C_truep(t19)?t19:C_eqp(t6,lf[245]));
if(C_truep(t20)){
t21=C_i_cadr(t2);
t22=C_a_i_list1(&a,1,t21);
t23=t22;
t24=C_SCHEME_END_OF_LIST;
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_SCHEME_FALSE;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=((C_word*)((C_word*)t0)[2])[1];
t29=t2;
t30=C_u_i_cdr(t29);
t31=C_u_i_cdr(t30);
t32=C_i_check_list_2(t31,lf[161]);
t33=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8104,a[2]=t1,a[3]=t23,tmp=(C_word)a,a+=4,tmp);
t34=C_SCHEME_UNDEFINED;
t35=(*a=C_VECTOR_TYPE|1,a[1]=t34,tmp=(C_word)a,a+=2,tmp);
t36=C_set_block_item(t35,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8106,a[2]=t27,a[3]=t35,a[4]=t25,a[5]=t28,tmp=(C_word)a,a+=6,tmp));
t37=((C_word*)t35)[1];
f_8106(t37,t33,t31);}
else{
t21=C_eqp(t6,lf[246]);
if(C_truep(t21)){
t22=C_i_cadr(t2);
t23=C_i_cadr(t22);
t24=t23;
t25=C_i_caddr(t2);
t26=C_i_cadr(t25);
t27=t26;
t28=C_i_cadddr(t2);
t29=C_i_cadr(t28);
t30=t29;
t31=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8192,a[2]=t24,a[3]=t27,a[4]=t30,a[5]=t1,a[6]=((C_word*)t0)[2],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* support.scm:593: fifth */
t32=*((C_word*)lf[248]+1);
((C_proc3)(void*)(*((C_word*)t32+1)))(3,t32,t31,t2);}
else{
t22=C_eqp(t6,lf[249]);
t23=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8213,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t6,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t22)){
t24=t23;
f_8213(t24,t22);}
else{
t24=C_eqp(t6,lf[255]);
if(C_truep(t24)){
t25=t23;
f_8213(t25,t24);}
else{
t25=C_eqp(t6,lf[256]);
if(C_truep(t25)){
t26=t23;
f_8213(t26,t25);}
else{
t26=C_eqp(t6,lf[257]);
t27=t23;
f_8213(t27,(C_truep(t26)?t26:C_eqp(t6,lf[258])));}}}}}}}}}}}}}}}
else{
t5=C_a_i_list1(&a,1,C_SCHEME_FALSE);
t6=t5;
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=((C_word*)((C_word*)t0)[2])[1];
t12=t2;
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8525,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8527,a[2]=t10,a[3]=t15,a[4]=t8,a[5]=t11,tmp=(C_word)a,a+=6,tmp));
t17=((C_word*)t15)[1];
f_8527(t17,t13,t12);}}}}}

/* ##compiler#build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7380(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7380,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7383,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8567,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm:615: walk */
t9=((C_word*)t6)[1];
f_7383(3,t9,t8,t2);}

/* a11280 in compute-database-statistics in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11281(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11281,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11283,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t5=C_i_check_list_2(t3,lf[34]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11362,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_11362(t9,t1,t3);}

/* ##compiler#block-variable-literal? in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14734(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14734,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_structurep(t2,lf[486]));}

/* a12584 in final-foreign-type in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_12585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12585,2,t0,t1);}
/* support.scm:1152: quit */
t2=*((C_word*)lf[28]+1);
f_4947(4,t2,t1,lf[435],((C_word*)t0)[2]);}

/* ##compiler#make-random-name in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14749(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_14749r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_14749r(t0,t1,t2);}}

static void C_ccall f_14749r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14757,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1392: open-output-string */
t4=*((C_word*)lf[53]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* ##compiler#block-variable-literal-name in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14740(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14740,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[486],lf[489]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_block_ref(t2,C_fix(1)));}

/* k11219 in k11247 in a11207 in dump-global-refs in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:926: newline */
t2=*((C_word*)lf[12]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#set-real-name! in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14798(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_14798,4,t0,t1,t2,t3);}
/* support.scm:1406: ##sys#hash-table-set! */
t4=*((C_word*)lf[153]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,*((C_word*)lf[494]+1),t2,t3);}

/* g2848 in k12554 in a12551 in final-foreign-type in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_12560(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12560,NULL,3,t0,t1,t2);}
if(C_truep(C_i_vectorp(t2))){
t3=C_i_vector_ref(t2,C_fix(0));
/* support.scm:1150: next */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t3=t2;
/* support.scm:1150: next */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}}

/* ##compiler#varnode in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7350(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7350,3,t0,t1,t2);}
t3=C_a_i_list1(&a,1,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[211],lf[221],t3,C_SCHEME_END_OF_LIST));}

/* ##sys#toplevel-definition-hook in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_11251,6,t0,t1,t2,t3,t4,t5);}
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_not(t4));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11261,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:935: debugging */
t8=*((C_word*)lf[11]+1);
f_4711(5,t8,t7,lf[259],lf[328],t2);}
else{
t7=C_SCHEME_UNDEFINED;
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* k7603 in k7595 in k7572 in k7569 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7605,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
/* support.scm:550: append */
t3=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],((C_word*)t0)[3],t2);}

/* map-loop1127 in k7572 in k7569 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_7607(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7607,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7636,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:550: g1133 */
t5=((C_word*)t0)[5];
f_7580(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11247 in a11207 in dump-global-refs in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11249,2,t0,t1);}
t2=(C_truep(t1)?C_SCHEME_FALSE:C_i_assq(lf[189],((C_word*)t0)[2]));
if(C_truep(t2)){
t3=C_i_assq(lf[176],((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11221,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t3)){
t5=C_i_cdr(t3);
t6=C_i_length(t5);
t7=C_a_i_list2(&a,2,((C_word*)t0)[4],t6);
/* support.scm:925: write */
t8=*((C_word*)lf[207]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t4,t7);}
else{
t5=C_a_i_list2(&a,2,((C_word*)t0)[4],C_fix(0));
/* support.scm:925: write */
t6=*((C_word*)lf[207]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k12554 in a12551 in final-foreign-type in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_12556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12556,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12560,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1147: g2848 */
t3=t2;
f_12560(t3,((C_word*)t0)[3],t1);}
else{
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* a12551 in final-foreign-type in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_12552(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12552,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12556,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_symbolp(t2))){
/* support.scm:1148: ##sys#hash-table-ref */
t5=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[395]+1),t2);}
else{
t5=t4;
f_12556(2,t5,C_SCHEME_FALSE);}}

/* k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word ab[131],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7342,2,t0,t1);}
t2=C_mutate2((C_word*)lf[210]+1 /* (set! make-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7344,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate2((C_word*)lf[220]+1 /* (set! ##compiler#varnode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7350,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate2((C_word*)lf[222]+1 /* (set! ##compiler#qnode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7365,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate2((C_word*)lf[223]+1 /* (set! ##compiler#build-node-graph ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7380,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate2((C_word*)lf[261]+1 /* (set! ##compiler#build-expression-tree ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8578,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate2((C_word*)lf[277]+1 /* (set! ##compiler#fold-boolean ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9438,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate2((C_word*)lf[279]+1 /* (set! ##compiler#inline-lambda-bindings ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9488,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate2((C_word*)lf[284]+1 /* (set! ##compiler#copy-node-tree-and-rename ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9639,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate2((C_word*)lf[288]+1 /* (set! ##compiler#tree-copy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10137,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate2((C_word*)lf[289]+1 /* (set! ##compiler#copy-node! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10167,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate2((C_word*)lf[290]+1 /* (set! ##compiler#node->sexpr ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10206,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate2((C_word*)lf[291]+1 /* (set! ##compiler#sexpr->node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10290,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate2((C_word*)lf[292]+1 /* (set! ##compiler#emit-global-inline-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10359,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate2((C_word*)lf[312]+1 /* (set! ##compiler#load-inline-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10621,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate2((C_word*)lf[314]+1 /* (set! ##compiler#match-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10677,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate2((C_word*)lf[317]+1 /* (set! ##compiler#expression-has-side-effects? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10894,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate2((C_word*)lf[321]+1 /* (set! ##compiler#simple-lambda-node? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11003,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate2((C_word*)lf[322]+1 /* (set! ##compiler#dump-undefined-globals ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11124,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate2((C_word*)lf[324]+1 /* (set! ##compiler#dump-defined-globals ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11165,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate2((C_word*)lf[325]+1 /* (set! ##compiler#dump-global-refs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11202,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate2((C_word*)lf[326]+1 /* (set! ##sys#toplevel-definition-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11251,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate2((C_word*)lf[329]+1 /* (set! ##compiler#compute-database-statistics ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11272,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate2((C_word*)lf[332]+1 /* (set! ##compiler#print-program-statistics ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11385,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate2((C_word*)lf[342]+1 /* (set! ##compiler#pprint-expressions-to-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11484,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate2((C_word*)lf[347]+1 /* (set! ##compiler#foreign-type-check ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11542,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate2((C_word*)lf[432]+1 /* (set! ##compiler#foreign-type-convert-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12484,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate2((C_word*)lf[433]+1 /* (set! ##compiler#foreign-type-convert-argument ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12515,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate2((C_word*)lf[434]+1 /* (set! ##compiler#final-foreign-type ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12546,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate2((C_word*)lf[436]+1 /* (set! ##compiler#estimate-foreign-result-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12591,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate2((C_word*)lf[441]+1 /* (set! ##compiler#estimate-foreign-result-location-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13023,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate2((C_word*)lf[444]+1 /* (set! ##compiler#finish-foreign-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13440,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate2((C_word*)lf[458]+1 /* (set! ##compiler#foreign-type->scrutiny-type ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13708,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate2((C_word*)lf[478]+1 /* (set! ##compiler#scan-used-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14274,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate2((C_word*)lf[479]+1 /* (set! ##compiler#scan-free-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14429,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate2((C_word*)lf[481]+1 /* (set! ##compiler#chop-separator ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14659,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate2((C_word*)lf[484]+1 /* (set! ##compiler#chop-extension ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14686,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate2((C_word*)lf[485]+1 /* (set! ##compiler#make-block-variable-literal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14728,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate2((C_word*)lf[487]+1 /* (set! ##compiler#block-variable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14734,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate2((C_word*)lf[488]+1 /* (set! ##compiler#block-variable-literal-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14740,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate2((C_word*)lf[490]+1 /* (set! ##compiler#make-random-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14749,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate2((C_word*)lf[493]+1 /* (set! ##compiler#set-real-name! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14798,tmp=(C_word)a,a+=2,tmp));
t43=C_set_block_item(lf[495] /* real-name-max-depth */,0,C_fix(20));
t44=C_mutate2((C_word*)lf[46]+1 /* (set! ##compiler#real-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14805,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate2((C_word*)lf[501]+1 /* (set! ##compiler#real-name2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14925,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate2((C_word*)lf[502]+1 /* (set! ##compiler#display-real-name-table ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14937,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate2((C_word*)lf[503]+1 /* (set! ##compiler#source-info->string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14961,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate2((C_word*)lf[509]+1 /* (set! ##compiler#source-info->line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14995,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate2((C_word*)lf[510]+1 /* (set! ##compiler#call-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15013,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate2((C_word*)lf[513]+1 /* (set! ##compiler#constant-form-eval ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15050,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate2((C_word*)lf[521]+1 /* (set! ##compiler#dump-nodes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15252,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate2((C_word*)lf[523]+1 /* (set! ##compiler#read-info-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15409,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate2((C_word*)lf[527]+1 /* (set! ##compiler#read/source-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15452,tmp=(C_word)a,a+=2,tmp));
t54=*((C_word*)lf[529]+1);
t55=C_mutate2((C_word*)lf[529]+1 /* (set! ##sys#user-read-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15458,a[2]=t54,tmp=(C_word)a,a+=3,tmp));
t56=C_mutate2((C_word*)lf[532]+1 /* (set! ##compiler#scan-sharp-greater-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15483,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate2((C_word*)lf[102]+1 /* (set! ##compiler#big-fixnum? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15554,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate2((C_word*)lf[327]+1 /* (set! ##compiler#hide-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15578,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate2((C_word*)lf[537]+1 /* (set! ##compiler#export-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15598,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate2((C_word*)lf[311]+1 /* (set! ##compiler#variable-visible? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15618,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate2((C_word*)lf[540]+1 /* (set! ##compiler#mark-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15643,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate2((C_word*)lf[541]+1 /* (set! ##compiler#variable-mark ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15658,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate2((C_word*)lf[542]+1 /* (set! ##compiler#intrinsic? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15664,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate2((C_word*)lf[543]+1 /* (set! foldable? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15675,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate2((C_word*)lf[544]+1 /* (set! ##compiler#load-identifier-database ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15686,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate2((C_word*)lf[552]+1 /* (set! ##compiler#print-version ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15784,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate2((C_word*)lf[555]+1 /* (set! ##compiler#print-usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15809,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate2((C_word*)lf[557]+1 /* (set! ##compiler#print-debug-options ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15821,tmp=(C_word)a,a+=2,tmp));
t69=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t69+1)))(2,t69,C_SCHEME_UNDEFINED);}

/* make-node in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7344(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7344,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[211],t2,t3,t4));}

/* k15364 in doloop3753 in k15343 in k15340 in k15322 in k15311 in k15308 in k15305 in k15302 in k15299 in k15296 in k15287 in loop in dump-nodes in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15369,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_slot(((C_word*)t0)[5],((C_word*)t0)[2]);
/* support.scm:1503: ##sys#print */
t4=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_TRUE,((C_word*)t0)[6]);}

/* k15367 in k15364 in doloop3753 in k15343 in k15340 in k15322 in k15311 in k15308 in k15305 in k15302 in k15299 in k15296 in k15287 in loop in dump-nodes in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 in ... */
static void C_ccall f_15369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_15353(t3,((C_word*)t0)[4],t2);}

/* k14773 in k14770 in k14767 in k14764 in k14761 in k14755 in make-random-name in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1391: string->symbol */
t2=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k14770 in k14767 in k14764 in k14761 in k14755 in make-random-name in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14772,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14775,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1392: get-output-string */
t3=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k8712 in map-loop1514 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8714,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8685(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8685(t6,((C_word*)t0)[5],t5);}}

/* k14777 in k14767 in k14764 in k14761 in k14755 in make-random-name in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1392: ##sys#print */
t2=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k14781 in k14764 in k14761 in k14755 in make-random-name in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1392: ##sys#print */
t2=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k14785 in k14755 in make-random-name in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1392: ##sys#print */
t2=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k10635 in loop in a10626 in load-inline-file in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10637,2,t0,t1);}
if(C_truep(C_eofp(t1))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10660,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(t1);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10671,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_i_cadr(t1);
/* support.scm:823: sexpr->node */
t7=*((C_word*)lf[291]+1);
f_10290(3,t7,t5,t6);}}

/* loop in a10626 in load-inline-file in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_10633(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10633,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10637,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:818: read */
t3=*((C_word*)lf[117]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##compiler#qnode in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7365(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7365,3,t0,t1,t2);}
t3=C_a_i_list1(&a,1,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[211],lf[97],t3,C_SCHEME_END_OF_LIST));}

/* ##compiler#final-foreign-type in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_12546(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12546,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12552,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12585,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1145: follow-without-loop */
t5=*((C_word*)lf[92]+1);
f_5641(5,t5,t1,t2,t3,t4);}

/* for-each-loop3722 in k15311 in k15308 in k15305 in k15302 in k15299 in k15296 in k15287 in loop in dump-nodes in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_15386(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15386,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15396,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:1499: g3723 */
t5=((C_word*)t0)[3];
f_15314(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k15394 in for-each-loop3722 in k15311 in k15308 in k15305 in k15302 in k15299 in k15296 in k15287 in loop in dump-nodes in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_15386(t3,((C_word*)t0)[4],t2);}

/* k10617 in k10481 in a10475 in emit-global-inline-file in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10619,2,t0,t1);}
if(C_truep(C_i_structurep(t1,lf[211]))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=C_i_assq(lf[172],((C_word*)t0)[3]);
t3=C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10507,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t5=t4;
f_10507(t5,t3);}
else{
t5=C_i_cdr(t2);
t6=C_eqp(lf[169],t5);
t7=t4;
f_10507(t7,C_i_not(t6));}}}

/* k7957 in map-loop1198 in k7917 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7959,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7930(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7930(t6,((C_word*)t0)[5],t5);}}

/* k9706 in walk in k9647 in copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9708,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9715,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[3];
/* support.scm:709: alist-ref */
t4=*((C_word*)lf[285]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,((C_word*)t0)[4],t3,*((C_word*)lf[27]+1),((C_word*)t0)[4]);}

/* ##compiler#make-block-variable-literal in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14728(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14728,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record2(&a,2,lf[486],t2));}

/* k8626 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8628,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k7917 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_7919(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7919,NULL,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)((C_word*)t0)[2])[1];
t8=((C_word*)t0)[3];
t9=C_u_i_cdr(t8);
t10=C_u_i_cdr(t9);
t11=C_i_check_list_2(t10,lf[161]);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7928,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7930,a[2]=t6,a[3]=t14,a[4]=t4,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_7930(t16,t12,t10);}

/* k6985 in k6906 in loop in k6704 in a6695 in k6689 in display-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_6987(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6987,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[13]+1);
t3=*((C_word*)lf[13]+1);
t4=C_i_check_port_2(*((C_word*)lf[13]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[14]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6993,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:481: ##sys#write-char-0 */
t6=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_make_character(9),*((C_word*)lf[13]+1));}
else{
t2=C_eqp(((C_word*)t0)[4],lf[176]);
if(C_truep(t2)){
t3=C_i_cdar(((C_word*)t0)[2]);
t4=C_mutate2(((C_word *)((C_word*)t0)[5])+1,t3);
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
/* support.scm:487: loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_6884(t7,((C_word*)t0)[7],t6);}
else{
t3=C_eqp(((C_word*)t0)[4],lf[177]);
if(C_truep(t3)){
t4=C_i_cdar(((C_word*)t0)[2]);
t5=C_mutate2(((C_word *)((C_word*)t0)[8])+1,t4);
t6=((C_word*)t0)[2];
t7=C_u_i_cdr(t6);
/* support.scm:487: loop */
t8=((C_word*)((C_word*)t0)[6])[1];
f_6884(t8,((C_word*)t0)[7],t7);}
else{
t4=((C_word*)t0)[2];
t5=C_u_i_car(t4);
/* support.scm:486: bomb */
t6=*((C_word*)lf[3]+1);
f_4683(4,t6,((C_word*)t0)[3],lf[178],t5);}}}}

/* walk in node->sexpr in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10212(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10212,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=t4;
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=t7;
t9=C_SCHEME_END_OF_LIST;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=((C_word*)((C_word*)t0)[2])[1];
t14=t2;
t15=C_slot(t14,C_fix(3));
t16=C_i_check_list_2(t15,lf[161]);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10253,a[2]=t8,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10255,a[2]=t12,a[3]=t19,a[4]=t10,a[5]=t13,tmp=(C_word)a,a+=6,tmp));
t21=((C_word*)t19)[1];
f_10255(t21,t17,t15);}

/* for-each-loop2450 in a11280 in compute-database-statistics in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_11362(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(20);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_11362,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=f_11283(C_a_i(&a,20),((C_word*)t0)[2],t3);
t5=C_slot(t2,C_fix(1));
t8=t1;
t9=t5;
t1=t8;
t2=t9;
goto loop;}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6912 in k6906 in loop in k6704 in a6695 in k6689 in display-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_i_caar(((C_word*)t0)[2]);
t3=C_i_assq(t2,lf[171]);
t4=C_i_cdr(t3);
/* support.scm:470: ##sys#print */
t5=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[3],t4,C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* ##compiler#node->sexpr in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10206(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10206,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10212,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_10212(3,t6,t1,t2);}

/* match1 in match-node in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_10714(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10714,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_not_pair_p(t3))){
/* support.scm:840: resolve */
t4=((C_word*)((C_word*)t0)[2])[1];
f_10680(t4,t1,t3,t2);}
else{
if(C_truep(C_i_not_pair_p(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10736,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=C_i_car(t2);
t6=C_i_car(t3);
/* support.scm:842: match1 */
t8=t4;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}

/* k13586 in k13558 in k13442 in finish-foreign-result in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_13588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[60],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13588,2,t0,t1);}
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=C_a_i_list(&a,2,lf[452],t1);
t5=C_a_i_list(&a,2,lf[453],t4);
t6=C_i_caddr(((C_word*)t0)[3]);
t7=C_a_i_list(&a,2,lf[97],lf[387]);
t8=C_a_i_list(&a,4,lf[454],t6,t7,t1);
t9=C_a_i_list(&a,4,lf[455],t1,t5,t8);
t10=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_a_i_list(&a,3,lf[109],t3,t9));}

/* k6906 in loop in k6704 in a6695 in k6689 in display-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_6908(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6908,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[13]+1);
t3=*((C_word*)lf[13]+1);
t4=C_i_check_port_2(*((C_word*)lf[13]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[14]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6914,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:470: ##sys#write-char-0 */
t6=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_make_character(9),*((C_word*)lf[13]+1));}
else{
t2=C_eqp(((C_word*)t0)[4],lf[169]);
if(C_truep(t2)){
t3=C_mutate2(((C_word *)((C_word*)t0)[5])+1,lf[169]);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
/* support.scm:487: loop */
t6=((C_word*)((C_word*)t0)[6])[1];
f_6884(t6,((C_word*)t0)[7],t5);}
else{
t3=C_eqp(((C_word*)t0)[4],lf[172]);
if(C_truep(t3)){
t4=C_eqp(((C_word*)((C_word*)t0)[5])[1],lf[169]);
if(C_truep(t4)){
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
/* support.scm:487: loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_6884(t7,((C_word*)t0)[7],t6);}
else{
t5=C_i_cdar(((C_word*)t0)[2]);
t6=C_mutate2(((C_word *)((C_word*)t0)[5])+1,t5);
t7=((C_word*)t0)[2];
t8=C_u_i_cdr(t7);
/* support.scm:487: loop */
t9=((C_word*)((C_word*)t0)[6])[1];
f_6884(t9,((C_word*)t0)[7],t8);}}
else{
t4=C_eqp(((C_word*)t0)[4],lf[173]);
if(C_truep(t4)){
t5=C_eqp(((C_word*)((C_word*)t0)[5])[1],lf[169]);
if(C_truep(t5)){
t6=((C_word*)t0)[2];
t7=C_u_i_cdr(t6);
/* support.scm:487: loop */
t8=((C_word*)((C_word*)t0)[6])[1];
f_6884(t8,((C_word*)t0)[7],t7);}
else{
t6=C_i_cdar(((C_word*)t0)[2]);
t7=C_mutate2(((C_word *)((C_word*)t0)[8])+1,t6);
t8=((C_word*)t0)[2];
t9=C_u_i_cdr(t8);
/* support.scm:487: loop */
t10=((C_word*)((C_word*)t0)[6])[1];
f_6884(t10,((C_word*)t0)[7],t9);}}
else{
t5=C_eqp(((C_word*)t0)[4],lf[174]);
if(C_truep(t5)){
t6=C_i_cdar(((C_word*)t0)[2]);
t7=C_mutate2(((C_word *)((C_word*)t0)[9])+1,t6);
t8=((C_word*)t0)[2];
t9=C_u_i_cdr(t8);
/* support.scm:487: loop */
t10=((C_word*)((C_word*)t0)[6])[1];
f_6884(t10,((C_word*)t0)[7],t9);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[175]);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6987,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t6)){
t8=t7;
f_6987(t8,t6);}
else{
t8=C_eqp(((C_word*)t0)[4],lf[179]);
if(C_truep(t8)){
t9=t7;
f_6987(t9,t8);}
else{
t9=C_eqp(((C_word*)t0)[4],lf[180]);
if(C_truep(t9)){
t10=t7;
f_6987(t10,t9);}
else{
t10=C_eqp(((C_word*)t0)[4],lf[181]);
if(C_truep(t10)){
t11=t7;
f_6987(t11,t10);}
else{
t11=C_eqp(((C_word*)t0)[4],lf[182]);
if(C_truep(t11)){
t12=t7;
f_6987(t12,t11);}
else{
t12=C_eqp(((C_word*)t0)[4],lf[183]);
if(C_truep(t12)){
t13=t7;
f_6987(t13,t12);}
else{
t13=C_eqp(((C_word*)t0)[4],lf[184]);
if(C_truep(t13)){
t14=t7;
f_6987(t14,t13);}
else{
t14=C_eqp(((C_word*)t0)[4],lf[185]);
t15=t7;
f_6987(t15,(C_truep(t14)?t14:C_eqp(((C_word*)t0)[4],lf[186])));}}}}}}}}}}}}}

/* k9468 in fold in fold-boolean in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9470,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9474,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* support.scm:680: fold */
t6=((C_word*)((C_word*)t0)[4])[1];
f_9444(t6,t3,t5);}

/* k9472 in k9468 in fold in fold-boolean in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9474,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[211],lf[241],lf[278],t2));}

/* k13558 in k13442 in finish-foreign-result in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_13560(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13560,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[2]);
/* support.scm:1232: finish-foreign-result */
t3=*((C_word*)lf[444]+1);
f_13440(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[4]);}
else{
t2=C_i_length(((C_word*)t0)[2]);
t3=C_eqp(C_fix(3),t2);
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[2]);
t5=C_eqp(t4,lf[385]);
t6=(C_truep(t5)?t5:C_eqp(t4,lf[386]));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13588,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1236: gensym */
t8=*((C_word*)lf[110]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=C_eqp(t4,lf[389]);
if(C_truep(t7)){
t8=C_i_caddr(((C_word*)t0)[2]);
t9=C_a_i_list(&a,2,lf[97],lf[387]);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_a_i_list(&a,4,lf[454],t8,t9,((C_word*)t0)[4]));}
else{
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,((C_word*)t0)[4]);}}}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[4]);}}}

/* matchn in match-node in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_10753(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10753,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_not_pair_p(t3))){
/* support.scm:847: resolve */
t4=((C_word*)((C_word*)t0)[2])[1];
f_10680(t4,t1,t3,t2);}
else{
t4=t2;
t5=C_slot(t4,C_fix(1));
t6=C_i_car(t3);
t7=C_eqp(t5,t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10775,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t9=t2;
t10=C_slot(t9,C_fix(2));
t11=C_i_cadr(t3);
/* support.scm:849: match1 */
t12=((C_word*)((C_word*)t0)[4])[1];
f_10714(t12,t8,t10,t11);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}

/* a11390 in print-program-statistics in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11391,2,t0,t1);}
/* support.scm:982: compute-database-statistics */
t2=*((C_word*)lf[329]+1);
f_11272(3,t2,t1,((C_word*)t0)[2]);}

/* walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8584(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8584,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(3));
t5=t4;
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=t7;
t9=t2;
t10=C_slot(t9,C_fix(1));
t11=t10;
t12=t11;
t13=C_eqp(t12,lf[225]);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8618,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t1,a[5]=t11,a[6]=t12,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t13)){
t15=t14;
f_8618(t15,t13);}
else{
t15=C_eqp(t12,lf[275]);
t16=t14;
f_8618(t16,(C_truep(t15)?t15:C_eqp(t12,lf[276])));}}

/* ##compiler#inline-lambda-bindings in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9488(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr8,(void*)f_9488,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9494,a[2]=t3,a[3]=t5,a[4]=t4,a[5]=t6,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* support.scm:683: decompose-lambda-list */
t9=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t1,t2,t8);}

/* k15322 in k15311 in k15308 in k15305 in k15302 in k15299 in k15296 in k15287 in loop in dump-nodes in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15324,2,t0,t1);}
t2=C_block_size(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15330,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_fixnum_greaterp(t3,C_fix(4)))){
t5=*((C_word*)lf[13]+1);
t6=*((C_word*)lf[13]+1);
t7=C_i_check_port_2(*((C_word*)lf[13]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[14]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15342,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* support.scm:1502: ##sys#write-char-0 */
t9=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,C_make_character(91),*((C_word*)lf[13]+1));}
else{
/* write-char/port */
t5=*((C_word*)lf[522]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[3],C_make_character(62),*((C_word*)lf[13]+1));}}

/* a11396 in print-program-statistics in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11397(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_11397,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11404,a[2]=t1,a[3]=t8,a[4]=t7,a[5]=t6,a[6]=t5,a[7]=t4,a[8]=t3,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* support.scm:983: debugging */
t10=*((C_word*)lf[11]+1);
f_4711(4,t10,t9,lf[340],lf[341]);}

/* k10734 in match1 in match-node in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* support.scm:842: match1 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_10714(t6,((C_word*)t0)[5],t3,t5);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5113 in err in check-signature in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5115,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5119,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_cdr(((C_word*)t0)[3]);
/* support.scm:139: map-llist */
t5=*((C_word*)lf[43]+1);
f_5063(4,t5,t3,*((C_word*)lf[46]+1),t4);}

/* ##compiler#fold-boolean in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9438(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9438,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9444,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_9444(t7,t1,t3);}

/* k5117 in k5113 in err in check-signature in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:137: quit */
t2=*((C_word*)lf[28]+1);
f_4947(5,t2,((C_word*)t0)[2],lf[45],((C_word*)t0)[3],t1);}

/* walk in sexpr->node in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10296(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10296,3,t0,t1,t2);}
t3=C_i_car(t2);
t4=t3;
t5=C_i_cadr(t2);
t6=t5;
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=((C_word*)((C_word*)t0)[2])[1];
t12=t2;
t13=C_u_i_cdr(t12);
t14=C_u_i_cdr(t13);
t15=C_i_check_list_2(t14,lf[161]);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10322,a[2]=t1,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10324,a[2]=t10,a[3]=t18,a[4]=t8,a[5]=t11,tmp=(C_word)a,a+=6,tmp));
t20=((C_word*)t18)[1];
f_10324(t20,t16,t14);}

/* k8565 in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8567,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8570,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_positivep(((C_word*)((C_word*)t0)[3])[1]))){
/* support.scm:617: debugging */
t4=*((C_word*)lf[11]+1);
f_4711(5,t4,t3,lf[259],lf[260],((C_word*)((C_word*)t0)[3])[1]);}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k6704 in a6695 in k6689 in display-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6706,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6709,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6884,a[2]=t4,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_6884(t6,t2,((C_word*)t0)[8]);}

/* k6707 in k6704 in a6695 in k6689 in display-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6709,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6712,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6756,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t4=C_eqp(((C_word*)((C_word*)t0)[5])[1],lf[169]);
t5=t3;
f_6756(t5,C_i_not(t4));}
else{
t4=t3;
f_6756(t4,C_SCHEME_FALSE);}}

/* ##compiler#sexpr->node in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10290(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10290,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10296,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_10296(3,t6,t1,t2);}

/* k15328 in k15322 in k15311 in k15308 in k15305 in k15302 in k15299 in k15296 in k15287 in loop in dump-nodes in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=*((C_word*)lf[522]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(62),*((C_word*)lf[13]+1));}

/* loop in check-signature in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_5128(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5128,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t3))){
if(C_truep(C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* support.scm:141: err */
t4=((C_word*)t0)[2];
f_5107(t4,t1);}}
else{
t4=C_i_symbolp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep(C_i_nullp(t2))){
/* support.scm:143: err */
t5=((C_word*)t0)[2];
f_5107(t5,t1);}
else{
t5=C_i_cdr(t2);
t6=C_i_cdr(t3);
/* support.scm:144: loop */
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}}

/* k15343 in k15340 in k15322 in k15311 in k15308 in k15305 in k15302 in k15299 in k15296 in k15287 in loop in dump-nodes in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15345,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15348,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15353,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_15353(t6,t2,C_fix(5));}

/* k10282 in map-loop2109 in walk in node->sexpr in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10284,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_10255(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_10255(t6,((C_word*)t0)[5],t5);}}

/* k15346 in k15343 in k15340 in k15322 in k15311 in k15308 in k15305 in k15302 in k15299 in k15296 in k15287 in loop in dump-nodes in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=*((C_word*)lf[522]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(93),*((C_word*)lf[13]+1));}

/* k15340 in k15322 in k15311 in k15308 in k15305 in k15302 in k15299 in k15296 in k15287 in loop in dump-nodes in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15345,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_slot(((C_word*)t0)[4],C_fix(4));
/* support.scm:1502: ##sys#print */
t4=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_TRUE,((C_word*)t0)[5]);}

/* loop in k7890 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_7769(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7769,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_nullp(t2))){
t5=C_i_cadr(((C_word*)t0)[2]);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7813,a[2]=t6,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* support.scm:564: reverse */
t8=*((C_word*)lf[91]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}
else{
t5=C_i_caar(t2);
t6=C_eqp(lf[237],t5);
if(C_truep(t6)){
t7=C_i_cadr(((C_word*)t0)[2]);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7855,a[2]=t8,a[3]=t1,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t10=C_a_i_cons(&a,2,lf[239],t3);
/* support.scm:570: reverse */
t11=*((C_word*)lf[91]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t9,t10);}
else{
t7=t2;
t8=C_u_i_cdr(t7);
t9=C_i_caar(t2);
t10=C_a_i_cons(&a,2,t9,t3);
t11=t10;
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7876,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t8,a[6]=t11,tmp=(C_word)a,a+=7,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7880,a[2]=((C_word*)t0)[3],a[3]=t12,tmp=(C_word)a,a+=4,tmp);
/* support.scm:574: cadar */
t14=*((C_word*)lf[238]+1);
((C_proc3)(void*)(*((C_word*)t14+1)))(3,t14,t13,t2);}}}

/* doloop3753 in k15343 in k15340 in k15322 in k15311 in k15308 in k15305 in k15302 in k15299 in k15296 in k15287 in loop in dump-nodes in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_15353(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15353,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=*((C_word*)lf[13]+1);
t4=*((C_word*)lf[13]+1);
t5=C_i_check_port_2(*((C_word*)lf[13]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[14]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15366,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm:1503: ##sys#write-char-0 */
t7=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_make_character(32),*((C_word*)lf[13]+1));}}

/* fold in fold-boolean in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_9444(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9444,NULL,3,t0,t1,t2);}
t3=C_i_cddr(t2);
if(C_truep(C_i_nullp(t3))){
C_apply(4,0,t1,((C_word*)t0)[2],t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9470,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=C_u_i_car(t5);
t7=C_i_cadr(t2);
/* support.scm:679: proc */
t8=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,t6,t7);}}

/* k8554 in map-loop1428 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8556,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8527(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8527(t6,((C_word*)t0)[5],t5);}}

/* k4764 in for-each-loop47 in k4734 in k4722 in a4719 in text in debugging in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4756(t3,((C_word*)t0)[4],t2);}

/* k10251 in walk in node->sexpr in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10253,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,((C_word*)t0)[4],t2));}

/* map-loop2109 in walk in node->sexpr in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_10255(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10255,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10284,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:770: g2115 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7790 in k7811 in loop in k7890 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7792,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record4(&a,4,lf[211],lf[236],((C_word*)t0)[3],t1));}

/* for-each-loop47 in k4734 in k4722 in a4719 in text in debugging in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_4756(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4756,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4766,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=*((C_word*)lf[13]+1);
t7=*((C_word*)lf[13]+1);
t8=C_i_check_port_2(*((C_word*)lf[13]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[14]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4744,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4751,a[2]=t9,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* support.scm:65: force */
t11=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4749 in for-each-loop47 in k4734 in k4722 in a4719 in text in debugging in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:65: ##sys#print */
t2=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_TRUE,((C_word*)t0)[3]);}

/* k7736 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7738,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
t3=((C_word*)t0)[2];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[211],lf[235],((C_word*)t0)[3],t2));}

/* k14310 in walk in scan-used-variables in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_14312(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14312,NULL,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[2])[1];
t3=C_i_check_list_2(((C_word*)t0)[3],lf[34]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14320,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_14320(t7,((C_word*)t0)[4],((C_word*)t0)[3]);}

/* k10822 in loop in k10773 in matchn in match-node in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* support.scm:856: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_10793(t6,((C_word*)t0)[5],t3,t5);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k10008 in map-loop1934 in a9822 in walk in k9647 in copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10010,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9981(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9981(t6,((C_word*)t0)[5],t5);}}

/* ##compiler#print-version in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15784(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_15784r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_15784r(t0,t1,t2);}}

static void C_ccall f_15784r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t3=C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:C_i_car(t2));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15791,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t4)){
/* support.scm:1612: print* */
t6=*((C_word*)lf[553]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[554]);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f17172,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1613: chicken-version */
t7=*((C_word*)lf[304]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,C_SCHEME_TRUE);}}

/* k6638 in k6635 in k6632 in a6623 in display-line-number-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:430: ##sys#write-char-0 */
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(10),((C_word*)t0)[3]);}

/* k6508 in k6505 in count! in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_6510(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6510,NULL,2,t0,t1);}
if(C_truep(((C_word*)t0)[2])){
t2=C_i_assq(((C_word*)t0)[3],((C_word*)t0)[2]);
if(C_truep(t2)){
t3=C_slot(t2,C_fix(1));
t4=C_a_i_plus(&a,2,t3,t1);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_i_setslot(t2,C_fix(1),t4));}
else{
t3=C_slot(((C_word*)t0)[2],C_fix(1));
t4=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1),t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_i_setslot(((C_word*)t0)[2],C_fix(1),t4));}}
else{
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[5]);
t3=C_a_i_list1(&a,1,t2);
/* support.scm:408: ##sys#hash-table-set! */
t4=*((C_word*)lf[153]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[7],t3);}}

/* k9022 in loop in k8959 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9024,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9012,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[4];
t6=C_u_i_cdr(t5);
t7=((C_word*)t0)[5];
t8=C_u_i_cdr(t7);
/* support.scm:657: loop */
t9=((C_word*)((C_word*)t0)[6])[1];
f_8973(t9,t4,t6,t8);}

/* k15780 in k15688 in load-identifier-database in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1598: file-exists? */
t2=*((C_word*)lf[86]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k8133 in map-loop1271 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8135,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8106(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8106(t6,((C_word*)t0)[5],t5);}}

/* k8568 in k8565 in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* ##compiler#build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8578(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8578,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8584,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_8584(3,t6,t1,t2);}

/* k6648 in k6635 in k6632 in a6623 in display-line-number-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:430: ##sys#print */
t2=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_TRUE,((C_word*)t0)[3]);}

/* map-loop746 in k6635 in k6632 in a6623 in display-line-number-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_6652(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6652,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cdr(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6505 in count! in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6507,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6510,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t4=((C_word*)t0)[4];
t5=t3;
f_6510(t5,C_u_i_car(t4));}
else{
t4=t3;
f_6510(t4,C_fix(1));}}

/* ##compiler#count! in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6503(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr5r,(void*)f_6503r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6503r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6503r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6507,a[2]=t4,a[3]=t1,a[4]=t5,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm:402: ##sys#hash-table-ref */
t7=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t2,t3);}

/* k9010 in k9022 in loop in k8959 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9012,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* a9493 in inline-lambda-bindings in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9494(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9494,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9500,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9506,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* support.scm:685: ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* map-loop1271 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_8106(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8106,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8135,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:588: g1277 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8102 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8104,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record4(&a,4,lf[211],lf[244],((C_word*)t0)[3],t1));}

/* k15776 in k15773 in k15770 in k15767 in k15764 in k15758 in k15694 in k15688 in load-identifier-database in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1599: debugging */
t2=*((C_word*)lf[11]+1);
f_4711(4,t2,((C_word*)t0)[2],lf[547],t1);}

/* k15773 in k15770 in k15767 in k15764 in k15758 in k15694 in k15688 in load-identifier-database in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15775,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15778,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1599: get-output-string */
t3=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k15770 in k15767 in k15764 in k15758 in k15694 in k15688 in load-identifier-database in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15772,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15775,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1599: ##sys#write-char-0 */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[4]);}

/* map-loop2040 in k10024 in walk in k9647 in copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_10040(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10040,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10069,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:751: g2046 */
t5=((C_word*)t0)[5];
f_10028(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k14328 in for-each-loop3388 in k14310 in walk in scan-used-variables in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_14320(t3,((C_word*)t0)[4],t2);}

/* k15743 in for-each-loop3915 in k15728 in k15700 in k15694 in k15688 in load-identifier-database in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_15735(t3,((C_word*)t0)[4],t2);}

/* k14342 in walk in scan-used-variables in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_14344(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14344,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[4];
f_14312(t4,t3);}
else{
t2=((C_word*)t0)[4];
f_14312(t2,C_SCHEME_UNDEFINED);}}

/* k10036 in k10024 in walk in k9647 in copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10038,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record4(&a,4,lf[211],((C_word*)t0)[3],((C_word*)t0)[4],t1));}

/* node-parameters-set! in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7314(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7314,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[211],C_SCHEME_FALSE);
/* support.scm:504: ##sys#block-set! */
t5=*((C_word*)lf[215]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* k15712 in for-each-loop3915 in k15728 in k15700 in k15694 in k15688 in load-identifier-database in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1603: ##sys#put! */
t2=*((C_word*)lf[142]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[545],t1);}

/* k15716 in for-each-loop3915 in k15728 in k15700 in k15694 in k15688 in load-identifier-database in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15718,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=C_u_i_cdr(((C_word*)t0)[2]);
t4=C_a_i_list1(&a,1,t3);
/* support.scm:1605: append */
t5=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[3],t2,t4);}

/* k10024 in walk in k9647 in copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10026,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10028,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t8=C_i_check_list_2(((C_word*)t0)[4],lf[161]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10038,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10040,a[2]=t6,a[3]=t11,a[4]=t4,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_10040(t13,t9,((C_word*)t0)[4]);}

/* g2046 in k10024 in walk in k9647 in copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_10028(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10028,NULL,3,t0,t1,t2);}
/* support.scm:751: g2063 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_9657(t3,t1,t2,((C_word*)t0)[3]);}

/* k15767 in k15764 in k15758 in k15694 in k15688 in load-identifier-database in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15769,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15772,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1599: ##sys#print */
t3=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[548],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k15764 in k15758 in k15694 in k15688 in load-identifier-database in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15769,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1599: ##sys#print */
t3=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* node-parameters in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7305(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7305,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[211],lf[216]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_block_ref(t2,C_fix(2)));}

/* k15758 in k15694 in k15688 in load-identifier-database in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15760,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[51]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15766,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* support.scm:1599: ##sys#print */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[549],C_SCHEME_FALSE,t3);}

/* ##compiler#check-signature in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5104(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5104,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5107,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5128,a[2]=t5,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_5128(t9,t1,t3,t4);}

/* err in check-signature in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_5107(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5107,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5115,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:138: real-name */
t3=*((C_word*)lf[46]+1);
f_14805(3,t3,t2,((C_word*)t0)[3]);}

/* for-each-loop3388 in k14310 in walk in scan-used-variables in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_14320(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14320,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14330,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:1319: g3389 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* node-subexpressions-set! in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7332(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7332,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[211],C_SCHEME_FALSE);
/* support.scm:504: ##sys#block-set! */
t5=*((C_word*)lf[215]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* for-each-loop3915 in k15728 in k15700 in k15694 in k15688 in load-identifier-database in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_15735(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15735,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15745,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=C_i_car(t6);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15714,a[2]=t5,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15718,a[2]=t6,a[3]=t9,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1605: ##sys#get */
t11=*((C_word*)lf[253]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,t8,lf[545]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k15728 in k15700 in k15694 in k15688 in load-identifier-database in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15730,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15735,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_15735(t5,((C_word*)t0)[2],t1);}

/* node-subexpressions in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7323(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7323,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[211],lf[218]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_block_ref(t2,C_fix(3)));}

/* k15700 in k15694 in k15688 in load-identifier-database in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15702,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15730,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1606: read-file */
t3=*((C_word*)lf[546]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* loop in k10773 in matchn in match-node in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_10793(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10793,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_nullp(t2));}
else{
if(C_truep(C_i_not_pair_p(t3))){
/* support.scm:853: resolve */
t4=((C_word*)((C_word*)t0)[2])[1];
f_10680(t4,t1,t3,t2);}
else{
if(C_truep(C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10824,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=C_i_car(t2);
t6=C_i_car(t3);
/* support.scm:855: matchn */
t7=((C_word*)((C_word*)t0)[4])[1];
f_10753(t7,t4,t5,t6);}}}}

/* k10067 in map-loop2040 in k10024 in walk in k9647 in copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10069,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_10040(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_10040(t6,((C_word*)t0)[5],t5);}}

/* k10773 in matchn in match-node in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10775,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_slot(t2,C_fix(3));
t4=C_i_cddr(((C_word*)t0)[3]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10793,a[2]=((C_word*)t0)[4],a[3]=t6,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_10793(t8,((C_word*)t0)[6],t3,t4);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a13433 in estimate-foreign-result-location-size in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_13434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13434,2,t0,t1);}
/* support.scm:1209: quit */
t2=*((C_word*)lf[28]+1);
f_4947(4,t2,t1,lf[443],((C_word*)t0)[2]);}

/* ##compiler#display-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6687(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6687,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6691,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=t3;
f_6691(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7273,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:451: append */
t5=*((C_word*)lf[70]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,*((C_word*)lf[208]+1),*((C_word*)lf[209]+1),*((C_word*)lf[140]+1));}}

/* a6695 in k6689 in display-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6696(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6696,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
if(C_truep(C_i_memq(t2,((C_word*)((C_word*)t0)[2])[1]))){
t14=C_SCHEME_UNDEFINED;
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,t14);}
else{
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6706,a[2]=t1,a[3]=t11,a[4]=t13,a[5]=t5,a[6]=t7,a[7]=t9,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* support.scm:462: write */
t15=*((C_word*)lf[207]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t14,t2);}}

/* k6689 in display-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_6691(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6691,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6696,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:454: ##sys#hash-table-for-each */
t3=*((C_word*)lf[162]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[4]);}

/* k13098 in k13061 in k13055 in k13043 in a13034 in estimate-foreign-result-location-size in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_13100(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_i_foreign_fixnum_argumentp(C_fix(1));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub347(C_SCHEME_UNDEFINED,t3));}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
/* support.scm:1187: quit */
t4=*((C_word*)lf[28]+1);
f_4947(4,t4,t2,lf[442],t3);}}

/* k6828 in k6791 in k6754 in k6707 in k6704 in a6695 in k6689 in display-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_6830(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6830,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[13]+1);
t3=*((C_word*)lf[13]+1);
t4=C_i_check_port_2(*((C_word*)lf[13]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[14]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6836,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:493: ##sys#print */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[168],C_SCHEME_FALSE,*((C_word*)lf[13]+1));}
else{
t2=((C_word*)t0)[3];
f_6712(2,t2,C_SCHEME_UNDEFINED);}}

/* k5688 in k5684 in a5677 in sort-symbols in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:245: string<? */
t2=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* ##compiler#constant? in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5692(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5692,3,t0,t1,t2);}
t3=C_i_numberp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=C_i_stringp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=C_booleanp(t2);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=C_eofp(t2);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5726,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:256: blob? */
t9=*((C_word*)lf[99]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}}}}}}

/* loop in k14849 in k14918 in k14822 in real-name in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_14853(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14853,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_greaterp(t3,*((C_word*)lf[495]+1)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14867,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_a_i_cons(&a,2,lf[498],t2);
/* support.scm:1427: reverse */
t7=*((C_word*)lf[91]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}
else{
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_14877,a[2]=t4,a[3]=t1,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* support.scm:1429: resolve */
f_14808(t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14916,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1435: reverse */
t6=*((C_word*)lf[91]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}}}

/* ##compiler#expression-has-side-effects? in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10894(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10894,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10900,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_10900(3,t7,t1,t2);}

/* k14849 in k14918 in k14822 in real-name in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14851,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14853,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_14853(t5,((C_word*)t0)[4],((C_word*)t0)[5],C_fix(0),t1);}

/* a5661 in loop in follow-without-loop in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5662(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5662,3,t0,t1,t2);}
t3=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
/* support.scm:242: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_5647(t4,t1,t2,t3);}

/* k6834 in k6828 in k6791 in k6754 in k6707 in k6704 in a6695 in k6689 in display-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6836,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[2])[1];
t3=C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[2])[1];
t5=C_slot(t4,C_fix(2));
t6=C_a_i_cons(&a,2,t3,t5);
/* support.scm:493: ##sys#print */
t7=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,((C_word*)t0)[3],t6,C_SCHEME_TRUE,((C_word*)t0)[4]);}

/* k14865 in loop in k14849 in k14918 in k14822 in real-name in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1427: string-intersperse */
t2=*((C_word*)lf[496]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[497]);}

/* ##compiler#sort-symbols in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5672(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5672,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5678,tmp=(C_word)a,a+=2,tmp);
/* support.scm:245: sort */
t4=*((C_word*)lf[95]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,t3);}

/* k10872 in k10866 in match-node in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)((C_word*)t0)[2])[1];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* a5677 in sort-symbols in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5678(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5678,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5686,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:245: symbol->string */
t5=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6895 in loop in k6704 in a6695 in k6689 in display-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* support.scm:487: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6884(t4,((C_word*)t0)[4],t3);}

/* ##compiler#follow-without-loop in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5641(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5641,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5647,a[2]=t4,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5647(t8,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in follow-without-loop in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_5647(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5647,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_member(t2,t3))){
/* support.scm:241: abort */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5662,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm:242: proc */
t5=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t4);}}

/* k10866 in match-node in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10868,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10874,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[4];
t4=C_slot(t3,C_fix(1));
t5=((C_word*)t0)[4];
t6=C_slot(t5,C_fix(2));
/* support.scm:861: debugging */
t7=*((C_word*)lf[11]+1);
f_4711(7,t7,t2,lf[315],lf[316],t4,t6,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* resolve in real-name in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_14808(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14808,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14812,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1413: ##sys#hash-table-ref */
t4=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[494]+1),t2);}

/* ##compiler#real-name in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14805(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_14805r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_14805r(t0,t1,t2,t3);}}

static void C_ccall f_14805r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14808,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14824,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* support.scm:1418: resolve */
f_14808(t5,t2);}

/* k11577 in repeat in a11547 in foreign-type-check in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_11579(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11579,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(*((C_word*)lf[350]+1))){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,2,lf[353],((C_word*)t0)[2]));}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[354]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11594,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_11594(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[422]);
t5=t3;
f_11594(t5,(C_truep(t4)?t4:C_eqp(((C_word*)t0)[4],lf[423])));}}}

/* k14810 in resolve in real-name in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14812,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14818,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1415: ##sys#hash-table-ref */
t4=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[494]+1),t2);}
else{
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k14816 in k14810 in resolve in real-name in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[3]));}

/* k14822 in real-name in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14824,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14920,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm:1422: ##sys#symbol->qualified-string */
t5=*((C_word*)lf[252]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t1);}
else{
/* support.scm:1436: ##sys#symbol->qualified-string */
t2=*((C_word*)lf[252]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],t1);}}
else{
/* support.scm:1419: ##sys#symbol->qualified-string */
t2=*((C_word*)lf[252]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}}

/* k11524 in for-each-loop2548 in a11498 in k11486 in pprint-expressions-to-file in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11516(t3,((C_word*)t0)[4],t2);}

/* loop in k6704 in a6695 in k6689 in display-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_6884(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6884,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_i_caar(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6897,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_eqp(t4,lf[170]);
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6908,a[2]=t2,a[3]=t5,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[2],a[7]=t1,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t6)){
t8=t7;
f_6908(t8,t6);}
else{
t8=C_eqp(t4,lf[187]);
if(C_truep(t8)){
t9=t7;
f_6908(t9,t8);}
else{
t9=C_eqp(t4,lf[188]);
if(C_truep(t9)){
t10=t7;
f_6908(t10,t9);}
else{
t10=C_eqp(t4,lf[189]);
if(C_truep(t10)){
t11=t7;
f_6908(t11,t10);}
else{
t11=C_eqp(t4,lf[190]);
if(C_truep(t11)){
t12=t7;
f_6908(t12,t11);}
else{
t12=C_eqp(t4,lf[191]);
if(C_truep(t12)){
t13=t7;
f_6908(t13,t12);}
else{
t13=C_eqp(t4,lf[192]);
if(C_truep(t13)){
t14=t7;
f_6908(t14,t13);}
else{
t14=C_eqp(t4,lf[193]);
if(C_truep(t14)){
t15=t7;
f_6908(t15,t14);}
else{
t15=C_eqp(t4,lf[194]);
if(C_truep(t15)){
t16=t7;
f_6908(t16,t15);}
else{
t16=C_eqp(t4,lf[195]);
if(C_truep(t16)){
t17=t7;
f_6908(t17,t16);}
else{
t17=C_eqp(t4,lf[196]);
if(C_truep(t17)){
t18=t7;
f_6908(t18,t17);}
else{
t18=C_eqp(t4,lf[197]);
if(C_truep(t18)){
t19=t7;
f_6908(t19,t18);}
else{
t19=C_eqp(t4,lf[198]);
if(C_truep(t19)){
t20=t7;
f_6908(t20,t19);}
else{
t20=C_eqp(t4,lf[199]);
if(C_truep(t20)){
t21=t7;
f_6908(t21,t20);}
else{
t21=C_eqp(t4,lf[200]);
if(C_truep(t21)){
t22=t7;
f_6908(t22,t21);}
else{
t22=C_eqp(t4,lf[201]);
if(C_truep(t22)){
t23=t7;
f_6908(t23,t22);}
else{
t23=C_eqp(t4,lf[202]);
if(C_truep(t23)){
t24=t7;
f_6908(t24,t23);}
else{
t24=C_eqp(t4,lf[203]);
if(C_truep(t24)){
t25=t7;
f_6908(t25,t24);}
else{
t25=C_eqp(t4,lf[204]);
if(C_truep(t25)){
t26=t7;
f_6908(t26,t25);}
else{
t26=C_eqp(t4,lf[205]);
t27=t7;
f_6908(t27,(C_truep(t26)?t26:C_eqp(t4,lf[206])));}}}}}}}}}}}}}}}}}}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k14392 in for-each-loop3412 in k14374 in walk in scan-used-variables in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_14384(t3,((C_word*)t0)[4],t2);}

/* k12638 in k12626 in k12614 in k12605 in a12596 in estimate-foreign-result-size in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_12640(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12640,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_i_foreign_fixnum_argumentp(C_fix(4));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub347(C_SCHEME_UNDEFINED,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12646,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[4]))){
/* support.scm:1174: ##sys#hash-table-ref */
t3=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[395]+1),((C_word*)t0)[4]);}
else{
t3=t2;
f_12646(2,t3,C_SCHEME_FALSE);}}}

/* repeat in a11547 in foreign-type-check in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_11554(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11554,NULL,3,t0,t1,t2);}
t3=t2;
t4=C_eqp(t3,lf[348]);
t5=(C_truep(t4)?t4:C_eqp(t3,lf[349]));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(*((C_word*)lf[350]+1))?((C_word*)t0)[2]:C_a_i_list(&a,2,lf[351],((C_word*)t0)[2])));}
else{
t6=C_eqp(t3,lf[352]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11579,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_11579(t8,t6);}
else{
t8=C_eqp(t3,lf[424]);
if(C_truep(t8)){
t9=t7;
f_11579(t9,t8);}
else{
t9=C_eqp(t3,lf[425]);
if(C_truep(t9)){
t10=t7;
f_11579(t10,t9);}
else{
t10=C_eqp(t3,lf[426]);
if(C_truep(t10)){
t11=t7;
f_11579(t11,t10);}
else{
t11=C_eqp(t3,lf[427]);
if(C_truep(t11)){
t12=t7;
f_11579(t12,t11);}
else{
t12=C_eqp(t3,lf[428]);
if(C_truep(t12)){
t13=t7;
f_11579(t13,t12);}
else{
t13=C_eqp(t3,lf[429]);
t14=t7;
f_11579(t14,(C_truep(t13)?t13:C_eqp(t3,lf[430])));}}}}}}}}

/* k12644 in k12638 in k12626 in k12614 in k12605 in a12596 in estimate-foreign-result-size in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_12646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12646,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12650,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1174: g2967 */
t3=t2;
f_12650(t3,((C_word*)t0)[3],t1);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[4];
t3=C_u_i_car(t2);
t4=C_eqp(t3,lf[384]);
if(C_truep(t4)){
if(C_truep(t4)){
t5=((C_word*)t0)[3];
t6=C_i_foreign_fixnum_argumentp(C_fix(3));
t7=t5;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,stub347(C_SCHEME_UNDEFINED,t6));}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_fix(0));}}
else{
t5=C_eqp(t3,lf[392]);
if(C_truep(t5)){
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=C_i_foreign_fixnum_argumentp(C_fix(3));
t8=t6;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,stub347(C_SCHEME_UNDEFINED,t7));}
else{
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_fix(0));}}
else{
t6=C_eqp(t3,lf[393]);
if(C_truep(t6)){
if(C_truep(t6)){
t7=((C_word*)t0)[3];
t8=C_i_foreign_fixnum_argumentp(C_fix(3));
t9=t7;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,stub347(C_SCHEME_UNDEFINED,t8));}
else{
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_fix(0));}}
else{
t7=C_eqp(t3,lf[375]);
if(C_truep(t7)){
if(C_truep(t7)){
t8=((C_word*)t0)[3];
t9=C_i_foreign_fixnum_argumentp(C_fix(3));
t10=t8;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,stub347(C_SCHEME_UNDEFINED,t9));}
else{
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_fix(0));}}
else{
t8=C_eqp(t3,lf[377]);
if(C_truep(t8)){
if(C_truep(t8)){
t9=((C_word*)t0)[3];
t10=C_i_foreign_fixnum_argumentp(C_fix(3));
t11=t9;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,stub347(C_SCHEME_UNDEFINED,t10));}
else{
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_fix(0));}}
else{
t9=C_eqp(t3,lf[394]);
if(C_truep(t9)){
if(C_truep(t9)){
t10=((C_word*)t0)[3];
t11=C_i_foreign_fixnum_argumentp(C_fix(3));
t12=t10;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,stub347(C_SCHEME_UNDEFINED,t11));}
else{
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_fix(0));}}
else{
t10=C_eqp(t3,lf[385]);
if(C_truep(t10)){
if(C_truep(t10)){
t11=((C_word*)t0)[3];
t12=C_i_foreign_fixnum_argumentp(C_fix(3));
t13=t11;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,stub347(C_SCHEME_UNDEFINED,t12));}
else{
t11=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_fix(0));}}
else{
t11=C_eqp(t3,lf[386]);
if(C_truep(t11)){
if(C_truep(t11)){
t12=((C_word*)t0)[3];
t13=C_i_foreign_fixnum_argumentp(C_fix(3));
t14=t12;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,stub347(C_SCHEME_UNDEFINED,t13));}
else{
t12=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_fix(0));}}
else{
t12=C_eqp(t3,lf[389]);
if(C_truep(t12)){
t13=((C_word*)t0)[3];
t14=C_i_foreign_fixnum_argumentp(C_fix(3));
t15=t13;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,stub347(C_SCHEME_UNDEFINED,t14));}
else{
t13=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_fix(0));}}}}}}}}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}}

/* k5684 in a5677 in sort-symbols in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5686,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5690,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:245: symbol->string */
t4=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* ##compiler#print-debug-options in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15821,2,t0,t1);}
/* support.scm:1743: display */
t2=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,lf[558]);}

/* k14374 in walk in scan-used-variables in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_14376(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14376,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=((C_word*)((C_word*)t0)[3])[1];
t3=C_i_check_list_2(((C_word*)t0)[4],lf[34]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14384,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_14384(t7,((C_word*)t0)[2],((C_word*)t0)[4]);}}

/* a15826 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_15827,4,t0,t1,t2,t3);}
t4=t3;
t5=C_i_check_port_2(t4,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[21]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15834,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:511: ##sys#print */
t7=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[559],C_SCHEME_FALSE,t4);}

/* ##compiler#print-program-statistics in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11385(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11385,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11391,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11397,tmp=(C_word)a,a+=2,tmp);
/* support.scm:980: ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* k13442 in finish-foreign-result in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_13444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13444,2,t0,t1);}
t2=t1;
t3=C_eqp(t2,lf[378]);
t4=(C_truep(t3)?t3:C_eqp(t2,lf[399]));
if(C_truep(t4)){
t5=C_a_i_list(&a,2,lf[97],C_fix(0));
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_list(&a,3,lf[445],((C_word*)t0)[3],t5));}
else{
t5=C_eqp(t2,lf[381]);
if(C_truep(t5)){
t6=C_a_i_list(&a,2,lf[97],C_fix(0));
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_list(&a,3,lf[446],((C_word*)t0)[3],t6));}
else{
t6=C_eqp(t2,lf[398]);
t7=(C_truep(t6)?t6:C_eqp(t2,lf[400]));
if(C_truep(t7)){
t8=C_a_i_list(&a,2,lf[97],C_fix(0));
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_a_i_list(&a,3,lf[447],((C_word*)t0)[3],t8));}
else{
t8=C_eqp(t2,lf[396]);
t9=(C_truep(t8)?t8:C_eqp(t2,lf[397]));
if(C_truep(t9)){
t10=C_a_i_list(&a,2,lf[97],C_fix(0));
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_a_i_list(&a,3,lf[448],((C_word*)t0)[3],t10));}
else{
t10=C_eqp(t2,lf[382]);
if(C_truep(t10)){
t11=C_a_i_list(&a,2,lf[97],C_fix(0));
t12=C_a_i_list(&a,3,lf[445],((C_word*)t0)[3],t11);
t13=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_a_i_list(&a,2,lf[449],t12));}
else{
t11=C_eqp(t2,lf[401]);
if(C_truep(t11)){
t12=C_a_i_list(&a,2,lf[97],C_SCHEME_FALSE);
t13=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_a_i_list(&a,3,lf[450],((C_word*)t0)[3],t12));}
else{
t12=C_eqp(t2,lf[402]);
if(C_truep(t12)){
t13=C_a_i_list(&a,2,lf[97],C_SCHEME_FALSE);
t14=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_a_i_list(&a,3,lf[451],((C_word*)t0)[3],t13));}
else{
if(C_truep(C_i_listp(t2))){
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13560,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t14=C_i_car(t2);
t15=C_eqp(t14,lf[390]);
if(C_truep(t15)){
t16=C_i_length(t2);
t17=C_eqp(C_fix(2),t16);
if(C_truep(t17)){
t18=C_i_cadr(t2);
t19=C_u_i_memq(t18,lf[456]);
t20=t13;
f_13560(t20,t19);}
else{
t18=t13;
f_13560(t18,C_SCHEME_FALSE);}}
else{
t16=t13;
f_13560(t16,C_SCHEME_FALSE);}}
else{
t13=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,((C_word*)t0)[3]);}}}}}}}}}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_support_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("support_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(6164)){
C_save(t1);
C_rereclaim2(6164*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,563);
lf[0]=C_h_intern(&lf[0],30,"\010compilercompiler-cleanup-hook");
lf[1]=C_h_intern(&lf[1],26,"\010compilerdebugging-chicken");
lf[2]=C_h_intern(&lf[2],26,"\010compilerdisabled-warnings");
lf[3]=C_h_intern(&lf[3],13,"\010compilerbomb");
lf[4]=C_h_intern(&lf[4],5,"error");
lf[5]=C_h_intern(&lf[5],13,"string-append");
lf[6]=C_decode_literal(C_heaptop,"\376B\000\000\032[internal compiler error] ");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000\031[internal compiler error]");
lf[8]=C_h_intern(&lf[8],35,"\010compilercollected-debugging-output");
lf[9]=C_h_intern(&lf[9],24,"+logged-debugging-modes+");
lf[10]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001o\376\003\000\000\002\376\001\000\000\001x\376\003\000\000\002\376\001\000\000\001S\376\377\016");
lf[11]=C_h_intern(&lf[11],18,"\010compilerdebugging");
lf[12]=C_h_intern(&lf[12],7,"newline");
lf[13]=C_h_intern(&lf[13],19,"\003sysstandard-output");
lf[14]=C_h_intern(&lf[14],6,"printf");
lf[15]=C_h_intern(&lf[15],16,"\003syswrite-char-0");
lf[16]=C_h_intern(&lf[16],9,"\003sysprint");
lf[17]=C_h_intern(&lf[17],5,"force");
lf[18]=C_h_intern(&lf[18],7,"display");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[20]=C_h_intern(&lf[20],21,"with-output-to-string");
lf[21]=C_h_intern(&lf[21],7,"fprintf");
lf[22]=C_h_intern(&lf[22],12,"flush-output");
lf[23]=C_h_intern(&lf[23],30,"\010compilerwith-debugging-output");
lf[24]=C_h_intern(&lf[24],12,"string-split");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[26]=C_h_intern(&lf[26],17,"lset-intersection");
lf[27]=C_h_intern(&lf[27],3,"eq\077");
lf[28]=C_h_intern(&lf[28],13,"\010compilerquit");
lf[29]=C_h_intern(&lf[29],18,"\003sysstandard-error");
lf[30]=C_h_intern(&lf[30],4,"exit");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\010\012Error: ");
lf[32]=C_h_intern(&lf[32],21,"\003syssyntax-error-hook");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\005\011~s~%");
lf[34]=C_h_intern(&lf[34],8,"for-each");
lf[35]=C_h_intern(&lf[35],16,"print-call-chain");
lf[36]=C_h_intern(&lf[36],18,"\003syscurrent-thread");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\025\012\011Expansion history:\012");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\003): ");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\017\012Syntax error (");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\017\012Syntax error: ");
lf[41]=C_h_intern(&lf[41],12,"syntax-error");
lf[42]=C_h_intern(&lf[42],31,"\010compileremit-syntax-trace-info");
lf[43]=C_h_intern(&lf[43],9,"map-llist");
lf[44]=C_h_intern(&lf[44],24,"\010compilercheck-signature");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000@Arguments to inlined call of `~A\047 do not match parameter-list ~A");
lf[46]=C_h_intern(&lf[46],18,"\010compilerreal-name");
lf[47]=C_h_intern(&lf[47],13,"\010compilerposq");
lf[48]=C_h_intern(&lf[48],13,"\010compilerposv");
lf[49]=C_h_intern(&lf[49],18,"\010compilerstringify");
lf[50]=C_h_intern(&lf[50],14,"symbol->string");
lf[51]=C_h_intern(&lf[51],7,"sprintf");
lf[52]=C_h_intern(&lf[52],17,"get-output-string");
lf[53]=C_h_intern(&lf[53],18,"open-output-string");
lf[54]=C_h_intern(&lf[54],18,"\010compilersymbolify");
lf[55]=C_h_intern(&lf[55],14,"string->symbol");
lf[56]=C_h_intern(&lf[56],17,"\010compilerslashify");
lf[57]=C_h_intern(&lf[57],16,"string-translate");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[60]=C_h_intern(&lf[60],8,"->string");
lf[61]=C_h_intern(&lf[61],21,"\010compileruncommentify");
lf[62]=C_h_intern(&lf[62],17,"string-translate\052");
lf[63]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\002\052/\376B\000\000\003\052_/\376\377\016");
lf[64]=C_h_intern(&lf[64],26,"\010compilerbuild-lambda-list");
lf[65]=C_h_intern(&lf[65],29,"\010compilerstring->c-identifier");
lf[66]=C_h_intern(&lf[66],24,"\003sysstring->c-identifier");
lf[67]=C_h_intern(&lf[67],21,"\010compilerc-ify-string");
lf[68]=C_h_intern(&lf[68],16,"\003syslist->string");
lf[69]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\377\016");
lf[70]=C_h_intern(&lf[70],6,"append");
lf[71]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\377\016");
lf[72]=C_h_intern(&lf[72],16,"\003sysstring->list");
lf[73]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[74]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[75]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\003\000\000\002\376\377\012\000\000\047\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000\077\376\003\000\000\002\376\377\012\000\000\052\376\377\016");
lf[76]=C_h_intern(&lf[76],28,"\010compilervalid-c-identifier\077");
lf[77]=C_h_intern(&lf[77],3,"any");
lf[78]=C_h_intern(&lf[78],14,"\010compilerwords");
lf[79]=C_h_intern(&lf[79],21,"\010compilerwords->bytes");
lf[80]=C_h_intern(&lf[80],34,"\010compilercheck-and-open-input-file");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[82]=C_h_intern(&lf[82],18,"\003sysstandard-input");
lf[83]=C_h_intern(&lf[83],15,"open-input-file");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\024Can not open file ~s");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\031(~a) can not open file ~s");
lf[86]=C_h_intern(&lf[86],12,"file-exists\077");
lf[87]=C_h_intern(&lf[87],33,"\010compilerclose-checked-input-file");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[89]=C_h_intern(&lf[89],16,"close-input-port");
lf[90]=C_h_intern(&lf[90],19,"\010compilerfold-inner");
lf[91]=C_h_intern(&lf[91],7,"reverse");
lf[92]=C_h_intern(&lf[92],28,"\010compilerfollow-without-loop");
lf[93]=C_h_intern(&lf[93],21,"\010compilersort-symbols");
lf[94]=C_h_intern(&lf[94],8,"string<\077");
lf[95]=C_h_intern(&lf[95],4,"sort");
lf[96]=C_h_intern(&lf[96],18,"\010compilerconstant\077");
lf[97]=C_h_intern(&lf[97],5,"quote");
lf[98]=C_h_intern(&lf[98],18,"\003syssrfi-4-vector\077");
lf[99]=C_h_intern(&lf[99],5,"blob\077");
lf[100]=C_h_intern(&lf[100],29,"\010compilercollapsable-literal\077");
lf[101]=C_h_intern(&lf[101],19,"\010compilerimmediate\077");
lf[102]=C_h_intern(&lf[102],20,"\010compilerbig-fixnum\077");
lf[103]=C_h_intern(&lf[103],23,"\010compilerbasic-literal\077");
lf[104]=C_h_intern(&lf[104],5,"every");
lf[105]=C_h_intern(&lf[105],12,"vector->list");
lf[106]=C_h_intern(&lf[106],32,"\010compilercanonicalize-begin-body");
lf[107]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[108]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[109]=C_h_intern(&lf[109],3,"let");
lf[110]=C_h_intern(&lf[110],6,"gensym");
lf[111]=C_h_intern(&lf[111],1,"t");
lf[112]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[113]=C_h_intern(&lf[113],21,"\010compilerstring->expr");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot parse expression: ~s [~a]~%");
lf[115]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[116]=C_h_intern(&lf[116],5,"begin");
lf[117]=C_h_intern(&lf[117],4,"read");
lf[118]=C_h_intern(&lf[118],6,"unfold");
lf[119]=C_h_intern(&lf[119],11,"eof-object\077");
lf[120]=C_h_intern(&lf[120],6,"values");
lf[121]=C_h_intern(&lf[121],22,"with-input-from-string");
lf[122]=C_h_intern(&lf[122],22,"with-exception-handler");
lf[123]=C_h_intern(&lf[123],30,"call-with-current-continuation");
lf[124]=C_h_intern(&lf[124],30,"\010compilerdecompose-lambda-list");
lf[125]=C_h_intern(&lf[125],25,"\003sysdecompose-lambda-list");
lf[126]=C_h_intern(&lf[126],21,"\010compilerllist-length");
lf[127]=C_h_intern(&lf[127],21,"\010compilerllist-match\077");
lf[128]=C_h_intern(&lf[128],30,"\010compilerexpand-profile-lambda");
lf[129]=C_h_intern(&lf[129],29,"\010compilerprofile-lambda-index");
lf[130]=C_h_intern(&lf[130],28,"\010compilerprofile-lambda-list");
lf[131]=C_h_intern(&lf[131],17,"\003sysprofile-entry");
lf[132]=C_h_intern(&lf[132],33,"\010compilerprofile-info-vector-name");
lf[133]=C_h_intern(&lf[133],11,"\004corelambda");
lf[134]=C_h_intern(&lf[134],9,"\003sysapply");
lf[135]=C_h_intern(&lf[135],16,"\003sysprofile-exit");
lf[136]=C_h_intern(&lf[136],16,"\003sysdynamic-wind");
lf[137]=C_h_intern(&lf[137],37,"\010compilerinitialize-analysis-database");
lf[138]=C_h_intern(&lf[138],17,"standard-bindings");
lf[139]=C_h_intern(&lf[139],17,"extended-bindings");
lf[140]=C_h_intern(&lf[140],26,"\010compilerinternal-bindings");
lf[141]=C_h_intern(&lf[141],8,"internal");
lf[142]=C_h_intern(&lf[142],8,"\003sysput!");
lf[143]=C_h_intern(&lf[143],18,"\010compilerintrinsic");
lf[144]=C_h_intern(&lf[144],26,"\010compilerfoldable-bindings");
lf[145]=C_h_intern(&lf[145],17,"\010compilerfoldable");
lf[146]=C_h_intern(&lf[146],8,"extended");
lf[147]=C_h_intern(&lf[147],8,"standard");
lf[148]=C_h_intern(&lf[148],12,"\010compilerget");
lf[149]=C_h_intern(&lf[149],18,"\003syshash-table-ref");
lf[150]=C_h_intern(&lf[150],16,"\010compilerget-all");
lf[151]=C_h_intern(&lf[151],10,"filter-map");
lf[152]=C_h_intern(&lf[152],13,"\010compilerput!");
lf[153]=C_h_intern(&lf[153],19,"\003syshash-table-set!");
lf[154]=C_h_intern(&lf[154],17,"\010compilercollect!");
lf[155]=C_h_intern(&lf[155],15,"\010compilercount!");
lf[156]=C_h_intern(&lf[156],17,"\010compilerget-list");
lf[157]=C_h_intern(&lf[157],17,"\010compilerget-line");
lf[158]=C_h_intern(&lf[158],24,"\003sysline-number-database");
lf[159]=C_h_intern(&lf[159],19,"\010compilerget-line-2");
lf[160]=C_h_intern(&lf[160],37,"\010compilerdisplay-line-number-database");
lf[161]=C_h_intern(&lf[161],3,"map");
lf[162]=C_h_intern(&lf[162],23,"\003syshash-table-for-each");
lf[163]=C_h_intern(&lf[163],34,"\010compilerdisplay-analysis-database");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\005\011css=");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\006\011refs=");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\005\011val=");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\006\011lval=");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\006\011pval=");
lf[169]=C_h_intern(&lf[169],7,"unknown");
lf[170]=C_h_intern(&lf[170],8,"captured");
lf[171]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010captured\376\001\000\000\003cpt\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010assigned\376\001\000\000\003set\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005box"
"ed\376\001\000\000\003box\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006global\376\001\000\000\003glo\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020assigned-locally\376\001\000\000\003stl\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\014contractable\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020standard-binding\376\001\000\000\003stb\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\006simple\376\001\000\000\003sim\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011inlinable\376\001\000\000\003inl\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013collapsable\376"
"\001\000\000\003col\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011removable\376\001\000\000\003rem\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010constant\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002"
"\376\001\000\000\015inline-target\376\001\000\000\003ilt\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020inline-transient\376\001\000\000\003itr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011"
"undefined\376\001\000\000\003und\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011replacing\376\001\000\000\003rpg\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006unused\376\001\000\000\003uud\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\020extended-binding\376\001\000\000\003xtb\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015inline-export\376\001\000\000\003ilx\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\013hidden-refs\376\001\000\000\003hrf\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011value-ref\376\001\000\000\003vvf\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014custom"
"izable\376\001\000\000\003cst\376\003\000\000\002\376\003\000\000\002\376\001\000\000\025has-unused-parameters\376\001\000\000\003hup\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012boxed-r"
"est\376\001\000\000\003bxr\376\377\016");
lf[172]=C_h_intern(&lf[172],5,"value");
lf[173]=C_h_intern(&lf[173],11,"local-value");
lf[174]=C_h_intern(&lf[174],15,"potential-value");
lf[175]=C_h_intern(&lf[175],10,"replacable");
lf[176]=C_h_intern(&lf[176],10,"references");
lf[177]=C_h_intern(&lf[177],10,"call-sites");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\020Illegal property");
lf[179]=C_h_intern(&lf[179],4,"home");
lf[180]=C_h_intern(&lf[180],8,"contains");
lf[181]=C_h_intern(&lf[181],12,"contained-in");
lf[182]=C_h_intern(&lf[182],8,"use-expr");
lf[183]=C_h_intern(&lf[183],12,"closure-size");
lf[184]=C_h_intern(&lf[184],14,"rest-parameter");
lf[185]=C_h_intern(&lf[185],18,"captured-variables");
lf[186]=C_h_intern(&lf[186],13,"explicit-rest");
lf[187]=C_h_intern(&lf[187],8,"assigned");
lf[188]=C_h_intern(&lf[188],5,"boxed");
lf[189]=C_h_intern(&lf[189],6,"global");
lf[190]=C_h_intern(&lf[190],12,"contractable");
lf[191]=C_h_intern(&lf[191],16,"standard-binding");
lf[192]=C_h_intern(&lf[192],16,"assigned-locally");
lf[193]=C_h_intern(&lf[193],11,"collapsable");
lf[194]=C_h_intern(&lf[194],9,"removable");
lf[195]=C_h_intern(&lf[195],9,"undefined");
lf[196]=C_h_intern(&lf[196],9,"replacing");
lf[197]=C_h_intern(&lf[197],6,"unused");
lf[198]=C_h_intern(&lf[198],6,"simple");
lf[199]=C_h_intern(&lf[199],9,"inlinable");
lf[200]=C_h_intern(&lf[200],13,"inline-export");
lf[201]=C_h_intern(&lf[201],21,"has-unused-parameters");
lf[202]=C_h_intern(&lf[202],16,"extended-binding");
lf[203]=C_h_intern(&lf[203],12,"customizable");
lf[204]=C_h_intern(&lf[204],8,"constant");
lf[205]=C_h_intern(&lf[205],10,"boxed-rest");
lf[206]=C_h_intern(&lf[206],11,"hidden-refs");
lf[207]=C_h_intern(&lf[207],5,"write");
lf[208]=C_h_intern(&lf[208],34,"\010compilerdefault-standard-bindings");
lf[209]=C_h_intern(&lf[209],34,"\010compilerdefault-extended-bindings");
lf[210]=C_h_intern(&lf[210],9,"make-node");
lf[211]=C_h_intern(&lf[211],4,"node");
lf[212]=C_h_intern(&lf[212],5,"node\077");
lf[213]=C_h_intern(&lf[213],10,"node-class");
lf[214]=C_h_intern(&lf[214],15,"node-class-set!");
lf[215]=C_h_intern(&lf[215],14,"\003sysblock-set!");
lf[216]=C_h_intern(&lf[216],15,"node-parameters");
lf[217]=C_h_intern(&lf[217],20,"node-parameters-set!");
lf[218]=C_h_intern(&lf[218],19,"node-subexpressions");
lf[219]=C_h_intern(&lf[219],24,"node-subexpressions-set!");
lf[220]=C_h_intern(&lf[220],16,"\010compilervarnode");
lf[221]=C_h_intern(&lf[221],13,"\004corevariable");
lf[222]=C_h_intern(&lf[222],14,"\010compilerqnode");
lf[223]=C_h_intern(&lf[223],25,"\010compilerbuild-node-graph");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\016bad expression");
lf[225]=C_h_intern(&lf[225],2,"if");
lf[226]=C_h_intern(&lf[226],14,"\004coreundefined");
lf[227]=C_h_intern(&lf[227],8,"truncate");
lf[228]=C_h_intern(&lf[228],7,"warning");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\0006literal is out of range - will be truncated to integer");
lf[230]=C_h_intern(&lf[230],6,"fixnum");
lf[231]=C_h_intern(&lf[231],11,"number-type");
lf[232]=C_h_intern(&lf[232],4,"\000tmp");
lf[233]=C_h_intern(&lf[233],6,"unzip1");
lf[234]=C_h_intern(&lf[234],6,"lambda");
lf[235]=C_h_intern(&lf[235],8,"\004corethe");
lf[236]=C_h_intern(&lf[236],13,"\004coretypecase");
lf[237]=C_h_intern(&lf[237],4,"else");
lf[238]=C_h_intern(&lf[238],5,"cadar");
lf[239]=C_h_intern(&lf[239],1,"\052");
lf[240]=C_h_intern(&lf[240],14,"\004coreprimitive");
lf[241]=C_h_intern(&lf[241],11,"\004coreinline");
lf[242]=C_h_intern(&lf[242],13,"\004corecallunit");
lf[243]=C_h_intern(&lf[243],9,"\004coreproc");
lf[244]=C_h_intern(&lf[244],4,"set!");
lf[245]=C_h_intern(&lf[245],9,"\004coreset!");
lf[246]=C_h_intern(&lf[246],29,"\004coreforeign-callback-wrapper");
lf[247]=C_h_intern(&lf[247],5,"sixth");
lf[248]=C_h_intern(&lf[248],5,"fifth");
lf[249]=C_h_intern(&lf[249],20,"\004coreinline_allocate");
lf[250]=C_h_intern(&lf[250],8,"\004coreapp");
lf[251]=C_h_intern(&lf[251],9,"\004corecall");
lf[252]=C_h_intern(&lf[252],28,"\003syssymbol->qualified-string");
lf[253]=C_h_intern(&lf[253],7,"\003sysget");
lf[254]=C_h_intern(&lf[254],34,"\010compileralways-bound-to-procedure");
lf[255]=C_h_intern(&lf[255],15,"\004coreinline_ref");
lf[256]=C_h_intern(&lf[256],18,"\004coreinline_update");
lf[257]=C_h_intern(&lf[257],19,"\004coreinline_loc_ref");
lf[258]=C_h_intern(&lf[258],22,"\004coreinline_loc_update");
lf[259]=C_h_intern(&lf[259],1,"o");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\033eliminated procedure checks");
lf[261]=C_h_intern(&lf[261],30,"\010compilerbuild-expression-tree");
lf[262]=C_h_intern(&lf[262],12,"\004coreclosure");
lf[263]=C_h_intern(&lf[263],4,"last");
lf[264]=C_h_intern(&lf[264],7,"butlast");
lf[265]=C_h_intern(&lf[265],3,"the");
lf[266]=C_h_intern(&lf[266],15,"\004corethe/result");
lf[267]=C_h_intern(&lf[267],17,"compiler-typecase");
lf[268]=C_h_intern(&lf[268],5,"cons\052");
lf[269]=C_h_intern(&lf[269],9,"\004corebind");
lf[270]=C_h_intern(&lf[270],10,"\004coreunbox");
lf[271]=C_h_intern(&lf[271],16,"\004corelet_unboxed");
lf[272]=C_h_intern(&lf[272],8,"\004coreref");
lf[273]=C_h_intern(&lf[273],11,"\004coreupdate");
lf[274]=C_h_intern(&lf[274],13,"\004coreupdate_i");
lf[275]=C_h_intern(&lf[275],8,"\004corebox");
lf[276]=C_h_intern(&lf[276],9,"\004corecond");
lf[277]=C_h_intern(&lf[277],21,"\010compilerfold-boolean");
lf[278]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005C_and\376\377\016");
lf[279]=C_h_intern(&lf[279],31,"\010compilerinline-lambda-bindings");
lf[280]=C_h_intern(&lf[280],8,"split-at");
lf[281]=C_h_intern(&lf[281],10,"fold-right");
lf[282]=C_h_intern(&lf[282],4,"take");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[284]=C_h_intern(&lf[284],34,"\010compilercopy-node-tree-and-rename");
lf[285]=C_h_intern(&lf[285],9,"alist-ref");
lf[286]=C_h_intern(&lf[286],16,"inline-transient");
lf[287]=C_h_intern(&lf[287],1,"f");
lf[288]=C_h_intern(&lf[288],18,"\010compilertree-copy");
lf[289]=C_h_intern(&lf[289],19,"\010compilercopy-node!");
lf[290]=C_h_intern(&lf[290],20,"\010compilernode->sexpr");
lf[291]=C_h_intern(&lf[291],20,"\010compilersexpr->node");
lf[292]=C_h_intern(&lf[292],32,"\010compileremit-global-inline-file");
lf[293]=C_h_intern(&lf[293],5,"print");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[295]=C_h_intern(&lf[295],1,"i");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\0001the following procedures can be globally inlined:");
lf[297]=C_h_intern(&lf[297],12,"delete-file\052");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\015; END OF FILE");
lf[299]=C_h_intern(&lf[299],2,"pp");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\027; GENERATED BY CHICKEN ");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\006 FROM ");
lf[302]=C_h_intern(&lf[302],24,"\010compilersource-filename");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[304]=C_h_intern(&lf[304],15,"chicken-version");
lf[305]=C_h_intern(&lf[305],19,"with-output-to-file");
lf[306]=C_h_intern(&lf[306],3,"yes");
lf[307]=C_h_intern(&lf[307],2,"no");
lf[308]=C_h_intern(&lf[308],24,"\010compilerinline-max-size");
lf[309]=C_h_intern(&lf[309],15,"\010compilerinline");
lf[310]=C_h_intern(&lf[310],22,"\010compilerinline-global");
lf[311]=C_h_intern(&lf[311],26,"\010compilervariable-visible\077");
lf[312]=C_h_intern(&lf[312],25,"\010compilerload-inline-file");
lf[313]=C_h_intern(&lf[313],20,"with-input-from-file");
lf[314]=C_h_intern(&lf[314],19,"\010compilermatch-node");
lf[315]=C_h_intern(&lf[315],1,"a");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\007matched");
lf[317]=C_h_intern(&lf[317],37,"\010compilerexpression-has-side-effects\077");
lf[318]=C_h_intern(&lf[318],24,"foreign-callback-stub-id");
lf[319]=C_h_intern(&lf[319],4,"find");
lf[320]=C_h_intern(&lf[320],22,"foreign-callback-stubs");
lf[321]=C_h_intern(&lf[321],28,"\010compilersimple-lambda-node\077");
lf[322]=C_h_intern(&lf[322],31,"\010compilerdump-undefined-globals");
lf[323]=C_h_intern(&lf[323],8,"keyword\077");
lf[324]=C_h_intern(&lf[324],29,"\010compilerdump-defined-globals");
lf[325]=C_h_intern(&lf[325],25,"\010compilerdump-global-refs");
lf[326]=C_h_intern(&lf[326],28,"\003systoplevel-definition-hook");
lf[327]=C_h_intern(&lf[327],22,"\010compilerhide-variable");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\042hiding nonexported module bindings");
lf[329]=C_h_intern(&lf[329],36,"\010compilercompute-database-statistics");
lf[330]=C_h_intern(&lf[330],29,"\010compilercurrent-program-size");
lf[331]=C_h_intern(&lf[331],30,"\010compileroriginal-program-size");
lf[332]=C_h_intern(&lf[332],33,"\010compilerprint-program-statistics");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\027;   database entries: \011");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\027;   known call sites: \011");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\027;   global variables: \011");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\027;   known procedures: \011");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\042;   variables with known values: \011");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\032 \011original program size: \011");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\023;   program size: \011");
lf[340]=C_h_intern(&lf[340],1,"s");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\023program statistics:");
lf[342]=C_h_intern(&lf[342],35,"\010compilerpprint-expressions-to-file");
lf[343]=C_h_intern(&lf[343],17,"close-output-port");
lf[344]=C_h_intern(&lf[344],12,"pretty-print");
lf[345]=C_h_intern(&lf[345],19,"with-output-to-port");
lf[346]=C_h_intern(&lf[346],16,"open-output-file");
lf[347]=C_h_intern(&lf[347],27,"\010compilerforeign-type-check");
lf[348]=C_h_intern(&lf[348],4,"char");
lf[349]=C_h_intern(&lf[349],13,"unsigned-char");
lf[350]=C_h_intern(&lf[350],6,"unsafe");
lf[351]=C_h_intern(&lf[351],25,"\003sysforeign-char-argument");
lf[352]=C_h_intern(&lf[352],3,"int");
lf[353]=C_h_intern(&lf[353],27,"\003sysforeign-fixnum-argument");
lf[354]=C_h_intern(&lf[354],5,"float");
lf[355]=C_h_intern(&lf[355],27,"\003sysforeign-flonum-argument");
lf[356]=C_h_intern(&lf[356],4,"blob");
lf[357]=C_h_intern(&lf[357],14,"scheme-pointer");
lf[358]=C_h_intern(&lf[358],26,"\003sysforeign-block-argument");
lf[359]=C_h_intern(&lf[359],22,"nonnull-scheme-pointer");
lf[360]=C_h_intern(&lf[360],12,"nonnull-blob");
lf[361]=C_h_intern(&lf[361],14,"pointer-vector");
lf[362]=C_h_intern(&lf[362],35,"\003sysforeign-struct-wrapper-argument");
lf[363]=C_h_intern(&lf[363],22,"nonnull-pointer-vector");
lf[364]=C_h_intern(&lf[364],8,"u8vector");
lf[365]=C_h_intern(&lf[365],16,"nonnull-u8vector");
lf[366]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-u8vector\376\001\000\000\010u8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u16vector\376\001\000\000"
"\011u16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-s8vector\376\001\000\000\010s8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-s16"
"vector\376\001\000\000\011s16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u32vector\376\001\000\000\011u32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\021nonnull-s32vector\376\001\000\000\011s32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f32vector\376\001\000\000\011f32vector\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f64vector\376\001\000\000\011f64vector\376\377\016");
lf[367]=C_h_intern(&lf[367],7,"integer");
lf[368]=C_h_intern(&lf[368],28,"\003sysforeign-integer-argument");
lf[369]=C_h_intern(&lf[369],9,"integer64");
lf[370]=C_h_intern(&lf[370],30,"\003sysforeign-integer64-argument");
lf[371]=C_h_intern(&lf[371],16,"unsigned-integer");
lf[372]=C_h_intern(&lf[372],37,"\003sysforeign-unsigned-integer-argument");
lf[373]=C_h_intern(&lf[373],18,"unsigned-integer64");
lf[374]=C_h_intern(&lf[374],39,"\003sysforeign-unsigned-integer64-argument");
lf[375]=C_h_intern(&lf[375],9,"c-pointer");
lf[376]=C_h_intern(&lf[376],28,"\003sysforeign-pointer-argument");
lf[377]=C_h_intern(&lf[377],17,"nonnull-c-pointer");
lf[378]=C_h_intern(&lf[378],8,"c-string");
lf[379]=C_h_intern(&lf[379],17,"\003sysmake-c-string");
lf[380]=C_h_intern(&lf[380],27,"\003sysforeign-string-argument");
lf[381]=C_h_intern(&lf[381],16,"nonnull-c-string");
lf[382]=C_h_intern(&lf[382],6,"symbol");
lf[383]=C_h_intern(&lf[383],18,"\003syssymbol->string");
lf[384]=C_h_intern(&lf[384],3,"ref");
lf[385]=C_h_intern(&lf[385],8,"instance");
lf[386]=C_h_intern(&lf[386],12,"instance-ref");
lf[387]=C_h_intern(&lf[387],4,"this");
lf[388]=C_h_intern(&lf[388],8,"slot-ref");
lf[389]=C_h_intern(&lf[389],16,"nonnull-instance");
lf[390]=C_h_intern(&lf[390],5,"const");
lf[391]=C_h_intern(&lf[391],4,"enum");
lf[392]=C_h_intern(&lf[392],15,"nonnull-pointer");
lf[393]=C_h_intern(&lf[393],7,"pointer");
lf[394]=C_h_intern(&lf[394],8,"function");
lf[395]=C_h_intern(&lf[395],27,"\010compilerforeign-type-table");
lf[396]=C_h_intern(&lf[396],17,"nonnull-c-string\052");
lf[397]=C_h_intern(&lf[397],26,"nonnull-unsigned-c-string\052");
lf[398]=C_h_intern(&lf[398],9,"c-string\052");
lf[399]=C_h_intern(&lf[399],17,"unsigned-c-string");
lf[400]=C_h_intern(&lf[400],18,"unsigned-c-string\052");
lf[401]=C_h_intern(&lf[401],13,"c-string-list");
lf[402]=C_h_intern(&lf[402],14,"c-string-list\052");
lf[403]=C_h_intern(&lf[403],18,"unsigned-integer32");
lf[404]=C_h_intern(&lf[404],13,"unsigned-long");
lf[405]=C_h_intern(&lf[405],4,"long");
lf[406]=C_h_intern(&lf[406],6,"size_t");
lf[407]=C_h_intern(&lf[407],9,"integer32");
lf[408]=C_h_intern(&lf[408],17,"nonnull-u16vector");
lf[409]=C_h_intern(&lf[409],16,"nonnull-s8vector");
lf[410]=C_h_intern(&lf[410],17,"nonnull-s16vector");
lf[411]=C_h_intern(&lf[411],17,"nonnull-u32vector");
lf[412]=C_h_intern(&lf[412],17,"nonnull-s32vector");
lf[413]=C_h_intern(&lf[413],17,"nonnull-f32vector");
lf[414]=C_h_intern(&lf[414],17,"nonnull-f64vector");
lf[415]=C_h_intern(&lf[415],9,"u16vector");
lf[416]=C_h_intern(&lf[416],8,"s8vector");
lf[417]=C_h_intern(&lf[417],9,"s16vector");
lf[418]=C_h_intern(&lf[418],9,"u32vector");
lf[419]=C_h_intern(&lf[419],9,"s32vector");
lf[420]=C_h_intern(&lf[420],9,"f32vector");
lf[421]=C_h_intern(&lf[421],9,"f64vector");
lf[422]=C_h_intern(&lf[422],6,"double");
lf[423]=C_h_intern(&lf[423],6,"number");
lf[424]=C_h_intern(&lf[424],12,"unsigned-int");
lf[425]=C_h_intern(&lf[425],5,"short");
lf[426]=C_h_intern(&lf[426],14,"unsigned-short");
lf[427]=C_h_intern(&lf[427],4,"byte");
lf[428]=C_h_intern(&lf[428],13,"unsigned-byte");
lf[429]=C_h_intern(&lf[429],5,"int32");
lf[430]=C_h_intern(&lf[430],14,"unsigned-int32");
lf[431]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[432]=C_h_intern(&lf[432],36,"\010compilerforeign-type-convert-result");
lf[433]=C_h_intern(&lf[433],38,"\010compilerforeign-type-convert-argument");
lf[434]=C_h_intern(&lf[434],27,"\010compilerfinal-foreign-type");
lf[435]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[436]=C_h_intern(&lf[436],37,"\010compilerestimate-foreign-result-size");
lf[437]=C_h_intern(&lf[437],4,"bool");
lf[438]=C_h_intern(&lf[438],4,"void");
lf[439]=C_h_intern(&lf[439],13,"scheme-object");
lf[440]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[441]=C_h_intern(&lf[441],46,"\010compilerestimate-foreign-result-location-size");
lf[442]=C_decode_literal(C_heaptop,"\376B\000\0005cannot compute size of location for foreign type `~S\047");
lf[443]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[444]=C_h_intern(&lf[444],30,"\010compilerfinish-foreign-result");
lf[445]=C_h_intern(&lf[445],17,"\003syspeek-c-string");
lf[446]=C_h_intern(&lf[446],25,"\003syspeek-nonnull-c-string");
lf[447]=C_h_intern(&lf[447],26,"\003syspeek-and-free-c-string");
lf[448]=C_h_intern(&lf[448],34,"\003syspeek-and-free-nonnull-c-string");
lf[449]=C_h_intern(&lf[449],17,"\003sysintern-symbol");
lf[450]=C_h_intern(&lf[450],22,"\003syspeek-c-string-list");
lf[451]=C_h_intern(&lf[451],31,"\003syspeek-and-free-c-string-list");
lf[452]=C_h_intern(&lf[452],17,"\003sysnull-pointer\077");
lf[453]=C_h_intern(&lf[453],3,"not");
lf[454]=C_h_intern(&lf[454],4,"make");
lf[455]=C_h_intern(&lf[455],3,"and");
lf[456]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010c-string\376\003\000\000\002\376\001\000\000\011c-string\052\376\003\000\000\002\376\001\000\000\021unsigned-c-string\376\003\000\000\002\376\001\000\000\022unsign"
"ed-c-string\052\376\003\000\000\002\376\001\000\000\020nonnull-c-string\376\003\000\000\002\376\001\000\000\021nonnull-c-string\052\376\003\000\000\002\376\001\000\000\030nonnu"
"ll-unsigned-string\052\376\377\016");
lf[457]=C_h_intern(&lf[457],16,"\003sysstrip-syntax");
lf[458]=C_h_intern(&lf[458],36,"\010compilerforeign-type->scrutiny-type");
lf[459]=C_h_intern(&lf[459],3,"arg");
lf[460]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002or\376\003\000\000\002\376\001\000\000\007boolean\376\003\000\000\002\376\001\000\000\004blob\376\377\016");
lf[461]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002or\376\003\000\000\002\376\001\000\000\007boolean\376\003\000\000\002\376\001\000\000\016pointer-vector\376\377\016");
lf[462]=C_h_intern(&lf[462],6,"struct");
lf[463]=C_h_intern(&lf[463],2,"or");
lf[464]=C_h_intern(&lf[464],7,"boolean");
lf[465]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\010u8vector\376\377\016");
lf[466]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\010s8vector\376\377\016");
lf[467]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\011u16vector\376\377\016");
lf[468]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\011s16vector\376\377\016");
lf[469]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\011u32vector\376\377\016");
lf[470]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\011s32vector\376\377\016");
lf[471]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\011f32vector\376\377\016");
lf[472]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\011f64vector\376\377\016");
lf[473]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002or\376\003\000\000\002\376\001\000\000\007boolean\376\003\000\000\002\376\001\000\000\007pointer\376\003\000\000\002\376\001\000\000\010locative\376\377\016");
lf[474]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002or\376\003\000\000\002\376\001\000\000\007boolean\376\003\000\000\002\376\001\000\000\006string\376\377\016");
lf[475]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007list-of\376\003\000\000\002\376\001\000\000\006string\376\377\016");
lf[476]=C_h_intern(&lf[476],6,"string");
lf[477]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002or\376\003\000\000\002\376\001\000\000\007boolean\376\003\000\000\002\376\001\000\000\007pointer\376\003\000\000\002\376\001\000\000\010locative\376\377\016");
lf[478]=C_h_intern(&lf[478],28,"\010compilerscan-used-variables");
lf[479]=C_h_intern(&lf[479],28,"\010compilerscan-free-variables");
lf[480]=C_h_intern(&lf[480],11,"lset-adjoin");
lf[481]=C_h_intern(&lf[481],23,"\010compilerchop-separator");
lf[482]=C_h_intern(&lf[482],9,"substring");
lf[483]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[484]=C_h_intern(&lf[484],23,"\010compilerchop-extension");
lf[485]=C_h_intern(&lf[485],36,"\010compilermake-block-variable-literal");
lf[486]=C_h_intern(&lf[486],22,"block-variable-literal");
lf[487]=C_h_intern(&lf[487],32,"\010compilerblock-variable-literal\077");
lf[488]=C_h_intern(&lf[488],36,"\010compilerblock-variable-literal-name");
lf[489]=C_h_intern(&lf[489],27,"block-variable-literal-name");
lf[490]=C_h_intern(&lf[490],25,"\010compilermake-random-name");
lf[491]=C_h_intern(&lf[491],6,"random");
lf[492]=C_h_intern(&lf[492],15,"current-seconds");
lf[493]=C_h_intern(&lf[493],23,"\010compilerset-real-name!");
lf[494]=C_h_intern(&lf[494],24,"\010compilerreal-name-table");
lf[495]=C_h_intern(&lf[495],19,"real-name-max-depth");
lf[496]=C_h_intern(&lf[496],18,"string-intersperse");
lf[497]=C_decode_literal(C_heaptop,"\376B\000\000\004 in ");
lf[498]=C_decode_literal(C_heaptop,"\376B\000\000\003...");
lf[499]=C_decode_literal(C_heaptop,"\376B\000\000\004 in ");
lf[500]=C_decode_literal(C_heaptop,"\376B\000\000\004 in ");
lf[501]=C_h_intern(&lf[501],19,"\010compilerreal-name2");
lf[502]=C_h_intern(&lf[502],32,"\010compilerdisplay-real-name-table");
lf[503]=C_h_intern(&lf[503],28,"\010compilersource-info->string");
lf[504]=C_h_intern(&lf[504],4,"conc");
lf[505]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[506]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[507]=C_h_intern(&lf[507],11,"make-string");
lf[508]=C_h_intern(&lf[508],3,"max");
lf[509]=C_h_intern(&lf[509],26,"\010compilersource-info->line");
lf[510]=C_h_intern(&lf[510],18,"\010compilercall-info");
lf[511]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[512]=C_decode_literal(C_heaptop,"\376B\000\000\002) ");
lf[513]=C_h_intern(&lf[513],27,"\010compilerconstant-form-eval");
lf[514]=C_h_intern(&lf[514],22,"get-condition-property");
lf[515]=C_h_intern(&lf[515],3,"exn");
lf[516]=C_h_intern(&lf[516],7,"message");
lf[517]=C_decode_literal(C_heaptop,"\376B\000\000\032folded constant expression");
lf[518]=C_decode_literal(C_heaptop,"\376B\000\000Dattempt to constant-fold call to procedure that has multiple results");
lf[519]=C_h_intern(&lf[519],8,"\003syslist");
lf[520]=C_decode_literal(C_heaptop,"\376B\000\000.attempt to constant-fold call to non-procedure");
lf[521]=C_h_intern(&lf[521],19,"\010compilerdump-nodes");
lf[522]=C_h_intern(&lf[522],19,"\003syswrite-char/port");
lf[523]=C_h_intern(&lf[523],23,"\010compilerread-info-hook");
lf[524]=C_h_intern(&lf[524],27,"\003syscurrent-source-filename");
lf[525]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[526]=C_h_intern(&lf[526],9,"list-info");
lf[527]=C_h_intern(&lf[527],25,"\010compilerread/source-info");
lf[528]=C_h_intern(&lf[528],8,"\003sysread");
lf[529]=C_h_intern(&lf[529],18,"\003sysuser-read-hook");
lf[530]=C_h_intern(&lf[530],15,"foreign-declare");
lf[531]=C_h_intern(&lf[531],7,"declare");
lf[532]=C_h_intern(&lf[532],34,"\010compilerscan-sharp-greater-string");
lf[533]=C_h_intern(&lf[533],18,"\003sysread-char/port");
lf[534]=C_decode_literal(C_heaptop,"\376B\000\000&unexpected end of `#> ... <#\047 sequence");
lf[535]=C_h_intern(&lf[535],6,"hidden");
lf[536]=C_h_intern(&lf[536],19,"\010compilervisibility");
lf[537]=C_h_intern(&lf[537],24,"\010compilerexport-variable");
lf[538]=C_h_intern(&lf[538],8,"exported");
lf[539]=C_h_intern(&lf[539],26,"\010compilerblock-compilation");
lf[540]=C_h_intern(&lf[540],22,"\010compilermark-variable");
lf[541]=C_h_intern(&lf[541],22,"\010compilervariable-mark");
lf[542]=C_h_intern(&lf[542],19,"\010compilerintrinsic\077");
lf[543]=C_h_intern(&lf[543],9,"foldable\077");
lf[544]=C_h_intern(&lf[544],33,"\010compilerload-identifier-database");
lf[545]=C_h_intern(&lf[545],7,"\004coredb");
lf[546]=C_h_intern(&lf[546],9,"read-file");
lf[547]=C_h_intern(&lf[547],1,"p");
lf[548]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[549]=C_decode_literal(C_heaptop,"\376B\000\000\034loading identifier database ");
lf[550]=C_h_intern(&lf[550],13,"make-pathname");
lf[551]=C_h_intern(&lf[551],15,"repository-path");
lf[552]=C_h_intern(&lf[552],22,"\010compilerprint-version");
lf[553]=C_h_intern(&lf[553],6,"print\052");
lf[554]=C_decode_literal(C_heaptop,"\376B\000\000C(c) 2008-2014, The Chicken Team\012(c) 2000-2007, Felix L. Winkelmann\012");
lf[555]=C_h_intern(&lf[555],20,"\010compilerprint-usage");
lf[556]=C_decode_literal(C_heaptop,"\376B\000\030\033Usage: chicken FILENAME OPTION ...\012\012  `chicken\047 is the CHICKEN compiler.\012  "
"\012  FILENAME should be a complete source file name with extension, or \042-\042 for\012  s"
"tandard input. OPTION may be one of the following:\012\012  General options:\012\012    -hel"
"p                        display this text and exit\012    -version                "
"     display compiler version and exit\012    -release                     print re"
"lease number and exit\012    -verbose                     display information on co"
"mpilation progress\012\012  File and pathname options:\012\012    -output-file FILENAME     "
"   specifies output-filename, default is \047out.c\047\012    -include-path PATHNAME     "
"  specifies alternative path for included files\012    -to-stdout                  "
" write compiled file to stdout instead of file\012\012  Language options:\012\012    -featur"
"e SYMBOL              register feature identifier\012    -no-feature SYMBOL        "
"   disable built-in feature identifier\012\012  Syntax related options:\012\012    -case-ins"
"ensitive            don\047t preserve case of read symbols\012    -keyword-style STYLE"
"         allow alternative keyword syntax\012                                  (pre"
"fix, suffix or none)\012    -no-parentheses-synonyms     disables list delimiter sy"
"nonyms\012    -no-symbol-escape            disables support for escaped symbols\012   "
" -r5rs-syntax                 disables the Chicken extensions to\012               "
"                   R5RS syntax\012    -compile-syntax              macros are made "
"available at run-time\012    -emit-import-library MODULE  write compile-time module"
" information into\012                                  separate file\012    -emit-all-"
"import-libraries   emit import-libraries for all defined modules\012    -no-module-"
"registration      do not generate module registration code\012    -no-compiler-synt"
"ax          disable expansion of compiler-macros\012    -module                    "
"  wrap compiled code into implicit module\012\012  Translation options:\012\012    -explicit"
"-use                do not use units \047library\047 and \047eval\047 by\012                   "
"               default\012    -check-syntax                stop compilation after m"
"acro-expansion\012    -analyze-only                stop compilation after first ana"
"lysis pass\012\012  Debugging options:\012\012    -no-warnings                 disable warni"
"ngs\012    -debug-level NUMBER          set level of available debugging informatio"
"n\012    -no-trace                    disable tracing information\012    -profile     "
"                executable emits profiling information \012    -profile-name FILENA"
"ME       name of the generated profile information file\012    -accumulate-profile "
"         executable emits profiling information in\012                             "
"     append mode\012    -no-lambda-info              omit additional procedure-info"
"rmation\012    -types FILENAME              load additional type database\012    -emit"
"-type-file FILENAME     write type-declaration information into file\012\012  Optimiza"
"tion options:\012\012    -optimize-level NUMBER       enable certain sets of optimizat"
"ion options\012    -optimize-leaf-routines      enable leaf routine optimization\012  "
"  -no-usual-integrations       standard procedures may be redefined\012    -unsafe "
"                     disable all safety checks\012    -local                       "
"assume globals are only modified in current\012                                  fi"
"le\012    -block                       enable block-compilation\012    -disable-interr"
"upts          disable interrupts in compiled code\012    -fixnum-arithmetic        "
"   assume all numbers are fixnums\012    -disable-stack-overflow-checks  disables d"
"etection of stack-overflows\012    -inline                      enable inlining\012   "
" -inline-limit LIMIT          set inlining threshold\012    -inline-global         "
"      enable cross-module inlining\012    -specialize                  perform type"
"-based specialization of primitive calls\012    -emit-inline-file FILENAME   genera"
"te file with globally inlinable\012                                  procedures (im"
"plies -inline -local)\012    -consult-inline-file FILENAME  explicitly load inline "
"file\012    -no-argc-checks              disable argument count checks\012    -no-boun"
"d-checks             disable bound variable checks\012    -no-procedure-checks     "
"    disable procedure call checks\012    -no-procedure-checks-for-usual-bindings\012  "
"                                 disable procedure call checks only for usual\012  "
"                                 bindings\012    -no-procedure-checks-for-toplevel-"
"bindings\012                                   disable procedure call checks for to"
"plevel\012                                   bindings\012    -strict-types            "
"    assume variable do not change their type\012    -clustering                  co"
"mbine groups of local procedures into dispatch\012                                 "
"  loop\012    -lfa2                        perform additional lightweight flow-anal"
"ysis pass\012\012  Configuration options:\012\012    -unit NAME                   compile fi"
"le as a library unit\012    -uses NAME                   declare library unit as us"
"ed.\012    -heap-size NUMBER            specifies heap-size of compiled executable\012"
"    -nursery NUMBER  -stack-size NUMBER\012                                 specifi"
"es nursery size of compiled executable\012    -extend FILENAME             load fil"
"e before compilation commences\012    -prelude EXPRESSION          add expression t"
"o front of source file\012    -postlude EXPRESSION         add expression to end of"
" source file\012    -prologue FILENAME           include file before main source fi"
"le\012    -epilogue FILENAME           include file after main source file\012    -dyn"
"amic                     compile as dynamically loadable code\012    -require-exten"
"sion NAME      require and import extension NAME\012\012  Obscure options:\012\012    -debug"
" MODES                 display debugging output for the given modes\012    -raw    "
"                     do not generate implicit init- and exit code               "
"            \012    -emit-external-prototypes-first\012                               "
"  emit prototypes for callbacks before foreign\012                                 "
" declarations\012    -ignore-repository           do not refer to repository for ex"
"tensions\012    -setup-mode                  prefer the current directory when loca"
"ting extensions\012");
lf[557]=C_h_intern(&lf[557],28,"\010compilerprint-debug-options");
lf[558]=C_decode_literal(C_heaptop,"\376B\000\007\026\012Available debugging options:\012\012     a          show node-matching during si"
"mplification\012     b          show breakdown of time needed for each compiler pas"
"s\012     c          print every expression before macro-expansion\012     d          "
"lists all assigned global variables\012     e          show information about speci"
"alizations\012     h          you already figured that out\012     i          show inf"
"ormation about inlining\012     m          show GC statistics during compilation\012  "
"   n          print the line-number database \012     o          show performed opt"
"imizations\012     p          display information about what the compiler is curren"
"tly doing\012     r          show invocation parameters\012     s          show progra"
"m-size information and other statistics\012     t          show time needed for com"
"pilation\012     u          lists all unassigned global variable references\012     x "
"         display information about experimental features\012     D          when pr"
"inting nodes, use node-tree output\012     I          show inferred type informatio"
"n for unexported globals\012     M          show syntax-/runtime-requirements\012     "
"N          show the real-name mapping table\012     P          show expressions aft"
"er specialization\012     S          show applications of compiler syntax\012     T   "
"       show expressions after converting to node tree\012     1          show sourc"
"e expressions\012     2          show canonicalized expressions\012     3          sho"
"w expressions converted into CPS\012     4          show database after each analys"
"is pass\012     5          show expressions after each optimization pass\012     6    "
"      show expressions after each inlining pass\012     7          show expressions"
" after complete optimization\012     8          show database after final analysis\012"
"     9          show expressions after closure conversion\012\012");
lf[559]=C_decode_literal(C_heaptop,"\376B\000\000\007#<node ");
lf[560]=C_h_intern(&lf[560],27,"\003sysregister-record-printer");
lf[561]=C_h_intern(&lf[561],27,"condition-property-accessor");
lf[562]=C_h_intern(&lf[562],19,"condition-predicate");
C_register_lf2(lf,563,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4668,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* ##compiler#finish-foreign-result in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_13440(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_13440,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13444,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1215: ##sys#strip-syntax */
t5=*((C_word*)lf[457]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k12626 in k12614 in k12605 in a12596 in estimate-foreign-result-size in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_12628(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12628,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_i_foreign_fixnum_argumentp(C_fix(4));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub347(C_SCHEME_UNDEFINED,t3));}
else{
t2=C_eqp(((C_word*)t0)[3],lf[354]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12640,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_12640(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[3],lf[422]);
if(C_truep(t4)){
t5=t3;
f_12640(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[3],lf[423]);
if(C_truep(t5)){
t6=t3;
f_12640(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[3],lf[369]);
t7=t3;
f_12640(t7,(C_truep(t6)?t6:C_eqp(((C_word*)t0)[3],lf[373])));}}}}}

/* k15832 in a15826 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15837,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=C_slot(t3,C_fix(1));
/* support.scm:511: ##sys#print */
t5=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,t4,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k8925 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8927,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,3,lf[265],((C_word*)t0)[3],t1));}

/* for-each-loop3412 in k14374 in walk in scan-used-variables in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_14384(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14384,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14394,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:1321: g3413 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k15835 in k15832 in a15826 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15840,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:511: ##sys#write-char-0 */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[3]);}

/* k15838 in k15835 in k15832 in a15826 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15840,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15843,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[4];
t4=C_slot(t3,C_fix(2));
/* support.scm:511: ##sys#print */
t5=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,t4,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k15841 in k15838 in k15835 in k15832 in a15826 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:511: ##sys#write-char-0 */
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(62),((C_word*)t0)[3]);}

/* k14875 in loop in k14849 in k14918 in k14822 in real-name in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14877,2,t0,t1);}
t2=C_eqp(t1,((C_word*)t0)[2]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14890,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1431: reverse */
t4=*((C_word*)lf[91]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_14909,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* support.scm:1432: symbol->string */
t4=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}}

/* g2007 in k9910 in k9902 in k9839 in k9836 in a9822 in walk in k9647 in copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_9855(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9855,NULL,3,t0,t1,t2);}
/* support.scm:750: g2024 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_9657(t3,t1,t2,((C_word*)t0)[3]);}

/* k12605 in a12596 in estimate-foreign-result-size in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_12607(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12607,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=C_eqp(((C_word*)t0)[3],lf[378]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12616,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_12616(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[3],lf[381]);
if(C_truep(t4)){
t5=t3;
f_12616(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[3],lf[375]);
if(C_truep(t5)){
t6=t3;
f_12616(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[3],lf[377]);
if(C_truep(t6)){
t7=t3;
f_12616(t7,t6);}
else{
t7=C_eqp(((C_word*)t0)[3],lf[382]);
if(C_truep(t7)){
t8=t3;
f_12616(t8,t7);}
else{
t8=C_eqp(((C_word*)t0)[3],lf[398]);
if(C_truep(t8)){
t9=t3;
f_12616(t9,t8);}
else{
t9=C_eqp(((C_word*)t0)[3],lf[396]);
if(C_truep(t9)){
t10=t3;
f_12616(t10,t9);}
else{
t10=C_eqp(((C_word*)t0)[3],lf[399]);
if(C_truep(t10)){
t11=t3;
f_12616(t11,t10);}
else{
t11=C_eqp(((C_word*)t0)[3],lf[400]);
if(C_truep(t11)){
t12=t3;
f_12616(t12,t11);}
else{
t12=C_eqp(((C_word*)t0)[3],lf[397]);
if(C_truep(t12)){
t13=t3;
f_12616(t13,t12);}
else{
t13=C_eqp(((C_word*)t0)[3],lf[401]);
t14=t3;
f_12616(t14,(C_truep(t13)?t13:C_eqp(((C_word*)t0)[3],lf[402])));}}}}}}}}}}}}

/* k9839 in k9836 in a9822 in walk in k9647 in copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9841,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9904,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* support.scm:747: gensym */
t4=*((C_word*)lf[110]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[287]);}

/* k14888 in k14875 in loop in k14849 in k14918 in k14822 in real-name in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1431: string-intersperse */
t2=*((C_word*)lf[496]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[499]);}

/* map-loop1428 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_8527(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8527,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8556,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:614: g1434 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11179 in k11176 in a11170 in dump-defined-globals in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:917: newline */
t2=*((C_word*)lf[12]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k8523 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8525,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record4(&a,4,lf[211],lf[251],((C_word*)t0)[3],t1));}

/* k11176 in a11170 in dump-defined-globals in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_11178(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11178,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11181,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:916: write */
t3=*((C_word*)lf[207]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* g2967 in k12644 in k12638 in k12626 in k12614 in k12605 in a12596 in estimate-foreign-result-size in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_12650(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12650,NULL,3,t0,t1,t2);}
if(C_truep(C_i_vectorp(t2))){
t3=C_i_vector_ref(t2,C_fix(0));
/* support.scm:1176: next */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t3=t2;
/* support.scm:1176: next */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}}

/* a11170 in dump-defined-globals in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11171(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11171,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11178,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11200,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:913: keyword? */
t6=*((C_word*)lf[323]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* ##compiler#print-usage in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15809,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15813,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1616: print-version */
t3=*((C_word*)lf[552]+1);
f_15784(2,t3,t2);}

/* map-loop3615 in constant-form-eval in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_15217(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_15217,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_slot(t3,C_fix(2));
t5=C_i_car(t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t7=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t6);
t8=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t6);
t9=C_slot(t2,C_fix(1));
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t6);
t8=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t6);
t9=C_slot(t2,C_fix(1));
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* ##compiler#dump-defined-globals in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11165(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11165,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11171,tmp=(C_word)a,a+=2,tmp);
/* support.scm:911: ##sys#hash-table-for-each */
t4=*((C_word*)lf[162]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* k11161 in a11129 in dump-undefined-globals in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_11137(t2,C_SCHEME_FALSE);}
else{
if(C_truep(C_i_assq(lf[189],((C_word*)t0)[3]))){
t2=C_i_assq(lf[187],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_11137(t3,C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
f_11137(t2,C_SCHEME_FALSE);}}}

/* k8042 in map-loop1232 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8044,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8015(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8015(t6,((C_word*)t0)[5],t5);}}

/* k15811 in print-usage in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15813,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15816,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1617: newline */
t3=*((C_word*)lf[12]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k15814 in k15811 in print-usage in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1618: display */
t2=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[556]);}

/* ##compiler#scan-used-variables in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14274(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_14274,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14278,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14280,a[2]=t8,a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_14280(3,t10,t6,t2);}

/* k14276 in scan-used-variables in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[3])[1]);}

/* k11138 in k11135 in a11129 in dump-undefined-globals in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:907: newline */
t2=*((C_word*)lf[12]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* walk in scan-used-variables in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14280(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14280,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(3));
t5=t4;
t6=t2;
t7=C_slot(t6,C_fix(1));
t8=C_eqp(t7,lf[221]);
t9=(C_truep(t8)?t8:C_eqp(t7,lf[244]));
if(C_truep(t9)){
t10=t2;
t11=C_slot(t10,C_fix(2));
t12=C_i_car(t11);
t13=t12;
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14312,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14344,a[2]=t13,a[3]=((C_word*)t0)[3],a[4]=t14,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_memq(t13,((C_word*)t0)[4]))){
t16=C_i_memq(t13,((C_word*)((C_word*)t0)[3])[1]);
t17=t15;
f_14344(t17,C_i_not(t16));}
else{
t16=t15;
f_14344(t16,C_SCHEME_FALSE);}}
else{
t10=C_eqp(t7,lf[97]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14376,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t10)){
t12=t11;
f_14376(t12,t10);}
else{
t12=C_eqp(t7,lf[226]);
t13=t11;
f_14376(t13,(C_truep(t12)?t12:C_eqp(t7,lf[240])));}}}

/* k11135 in a11129 in dump-undefined-globals in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_11137(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11137,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11140,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:906: write */
t3=*((C_word*)lf[207]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k12614 in k12605 in a12596 in estimate-foreign-result-size in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_12616(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12616,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_i_foreign_fixnum_argumentp(C_fix(3));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub347(C_SCHEME_UNDEFINED,t3));}
else{
t2=C_eqp(((C_word*)t0)[3],lf[371]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12628,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_12628(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[3],lf[405]);
if(C_truep(t4)){
t5=t3;
f_12628(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[3],lf[367]);
if(C_truep(t5)){
t6=t3;
f_12628(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[3],lf[406]);
if(C_truep(t6)){
t7=t3;
f_12628(t7,t6);}
else{
t7=C_eqp(((C_word*)t0)[3],lf[404]);
if(C_truep(t7)){
t8=t3;
f_12628(t8,t7);}
else{
t8=C_eqp(((C_word*)t0)[3],lf[407]);
t9=t3;
f_12628(t9,(C_truep(t8)?t8:C_eqp(((C_word*)t0)[3],lf[403])));}}}}}}}

/* a11129 in dump-undefined-globals in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11130(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11130,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11137,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11163,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:903: keyword? */
t6=*((C_word*)lf[323]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* ##compiler#dump-undefined-globals in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11124(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11124,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11130,tmp=(C_word)a,a+=2,tmp);
/* support.scm:901: ##sys#hash-table-for-each */
t4=*((C_word*)lf[162]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* k6407 in put! in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6409,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_assq(((C_word*)t0)[2],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_setslot(t2,C_fix(1),((C_word*)t0)[4]));}
else{
if(C_truep(((C_word*)t0)[4])){
t3=C_slot(t1,C_fix(1));
t4=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[4]),t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_i_setslot(t1,C_fix(1),t4));}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}}
else{
if(C_truep(((C_word*)t0)[4])){
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[4]);
t3=C_a_i_list1(&a,1,t2);
/* support.scm:391: ##sys#hash-table-set! */
t4=*((C_word*)lf[153]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[6],t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}}

/* ##compiler#put! in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6405(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_6405,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6409,a[2]=t4,a[3]=t1,a[4]=t5,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm:386: ##sys#hash-table-ref */
t7=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t2,t3);}

/* loop in dump-nodes in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_15261(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15261,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=C_slot(t4,C_fix(1));
t6=t5;
t7=t3;
t8=C_slot(t7,C_fix(2));
t9=t8;
t10=t3;
t11=C_slot(t10,C_fix(3));
t12=t11;
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_15289,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t12,a[5]=t3,a[6]=t1,a[7]=t9,a[8]=t6,tmp=(C_word)a,a+=9,tmp);
/* support.scm:1496: make-string */
t14=*((C_word*)lf[507]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t13,t2,C_make_character(32));}

/* k6271 in k6223 in initialize-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6273,2,t0,t1);}
t2=*((C_word*)lf[140]+1);
t3=C_i_check_list_2(*((C_word*)lf[140]+1),lf[34]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6300,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_6300(t7,((C_word*)t0)[2],*((C_word*)lf[140]+1));}

/* k6242 in for-each-loop584 in k6223 in initialize-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6244,2,t0,t1);}
if(C_truep(C_i_memq(((C_word*)t0)[2],*((C_word*)lf[144]+1)))){
t2=C_a_i_list(&a,1,C_SCHEME_TRUE);
if(C_truep(C_i_nullp(t2))){
/* tweaks.scm:54: ##sys#put! */
t3=*((C_word*)lf[142]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],lf[145],C_SCHEME_TRUE);}
else{
t3=C_i_car(t2);
/* tweaks.scm:54: ##sys#put! */
t4=*((C_word*)lf[142]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[145],t3);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k7702 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7704,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
t3=((C_word*)t0)[2];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[211],lf[234],((C_word*)t0)[3],t2));}

/* k15287 in loop in dump-nodes in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15289,2,t0,t1);}
t2=t1;
t3=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(2));
t4=t3;
t5=*((C_word*)lf[13]+1);
t6=*((C_word*)lf[13]+1);
t7=C_i_check_port_2(*((C_word*)lf[13]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[14]);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_15298,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t5,a[9]=((C_word*)t0)[8],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
/* support.scm:1491: ##sys#write-char-0 */
t9=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,C_make_character(10),*((C_word*)lf[13]+1));}

/* k4742 in for-each-loop47 in k4734 in k4722 in a4719 in text in debugging in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:65: ##sys#write-char-0 */
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(32),((C_word*)t0)[3]);}

/* k15296 in k15287 in loop in dump-nodes in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15298,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_15301,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* support.scm:1491: ##sys#print */
t3=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[10],C_SCHEME_FALSE,((C_word*)t0)[8]);}

/* k4734 in k4722 in a4719 in text in debugging in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4736,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4756,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4756(t6,((C_word*)t0)[3],t2);}

/* k13043 in a13034 in estimate-foreign-result-location-size in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_13045(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13045,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_i_foreign_fixnum_argumentp(C_fix(1));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub347(C_SCHEME_UNDEFINED,t3));}
else{
t2=C_eqp(((C_word*)t0)[3],lf[422]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13057,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_13057(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[3],lf[423]);
if(C_truep(t4)){
t5=t3;
f_13057(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[3],lf[369]);
t6=t3;
f_13057(t6,(C_truep(t5)?t5:C_eqp(((C_word*)t0)[3],lf[373])));}}}}

/* k4725 in k4722 in a4719 in text in debugging in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:67: newline */
t2=*((C_word*)lf[12]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4722 in a4719 in text in debugging in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4727,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4736,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:63: display */
t4=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[19]);}
else{
/* support.scm:67: newline */
t3=*((C_word*)lf[12]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}}

/* a4719 in text in debugging in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4724,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:61: display */
t3=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k6331 in for-each-loop584 in k6223 in initialize-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6323(t3,((C_word*)t0)[4],t2);}

/* k13055 in k13043 in a13034 in estimate-foreign-result-location-size in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_13057(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13057,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_i_foreign_fixnum_argumentp(C_fix(2));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub347(C_SCHEME_UNDEFINED,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13063,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[4]))){
/* support.scm:1201: ##sys#hash-table-ref */
t3=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[395]+1),((C_word*)t0)[4]);}
else{
t3=t2;
f_13063(2,t3,C_SCHEME_FALSE);}}}

/* ##compiler#debugging in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4711(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr4r,(void*)f_4711r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4711r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4711r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(16);
t5=C_SCHEME_UNDEFINED;
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4714,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t9=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4779,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
if(C_truep(C_i_memq(t2,*((C_word*)lf[1]+1)))){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4801,a[2]=t1,a[3]=t2,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* support.scm:71: text */
t11=t5;
f_4714(t11,t10);}
else{
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4819,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_memq(t2,*((C_word*)lf[9]+1)))){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4829,a[2]=t7,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
/* support.scm:79: text */
t12=t5;
f_4714(t12,t11);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}}

/* text in debugging in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_4714(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4714,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4720,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:59: with-output-to-string */
t3=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* for-each-loop584 in k6223 in initialize-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_6323(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6323,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6333,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6244,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=C_a_i_list(&a,1,lf[146]);
if(C_truep(C_i_nullp(t8))){
/* tweaks.scm:54: ##sys#put! */
t9=*((C_word*)lf[142]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t7,t6,lf[143],C_SCHEME_TRUE);}
else{
t9=C_i_car(t8);
/* tweaks.scm:54: ##sys#put! */
t10=*((C_word*)lf[142]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t7,t6,lf[143],t9);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* ##compiler#estimate-foreign-result-location-size in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_13023(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13023,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13035,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13434,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1188: follow-without-loop */
t5=*((C_word*)lf[92]+1);
f_5641(5,t5,t1,t2,t3,t4);}

/* k4787 in k4784 in dump in debugging in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:57: ##sys#print */
t2=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k4784 in dump in debugging in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4786,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4789,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:57: ##sys#write-char-0 */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(124),((C_word*)t0)[4]);}

/* a13034 in estimate-foreign-result-location-size in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_13035(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_13035,4,t0,t1,t2,t3);}
t4=t2;
t5=C_eqp(t4,lf[348]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13045,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_13045(t7,t5);}
else{
t7=C_eqp(t4,lf[352]);
if(C_truep(t7)){
t8=t6;
f_13045(t8,t7);}
else{
t8=C_eqp(t4,lf[425]);
if(C_truep(t8)){
t9=t6;
f_13045(t9,t8);}
else{
t9=C_eqp(t4,lf[437]);
if(C_truep(t9)){
t10=t6;
f_13045(t10,t9);}
else{
t10=C_eqp(t4,lf[426]);
if(C_truep(t10)){
t11=t6;
f_13045(t11,t10);}
else{
t11=C_eqp(t4,lf[349]);
if(C_truep(t11)){
t12=t6;
f_13045(t12,t11);}
else{
t12=C_eqp(t4,lf[424]);
if(C_truep(t12)){
t13=t6;
f_13045(t13,t12);}
else{
t13=C_eqp(t4,lf[405]);
if(C_truep(t13)){
t14=t6;
f_13045(t14,t13);}
else{
t14=C_eqp(t4,lf[404]);
if(C_truep(t14)){
t15=t6;
f_13045(t15,t14);}
else{
t15=C_eqp(t4,lf[427]);
if(C_truep(t15)){
t16=t6;
f_13045(t16,t15);}
else{
t16=C_eqp(t4,lf[428]);
if(C_truep(t16)){
t17=t6;
f_13045(t17,t16);}
else{
t17=C_eqp(t4,lf[375]);
if(C_truep(t17)){
t18=t6;
f_13045(t18,t17);}
else{
t18=C_eqp(t4,lf[377]);
if(C_truep(t18)){
t19=t6;
f_13045(t19,t18);}
else{
t19=C_eqp(t4,lf[371]);
if(C_truep(t19)){
t20=t6;
f_13045(t20,t19);}
else{
t20=C_eqp(t4,lf[367]);
if(C_truep(t20)){
t21=t6;
f_13045(t21,t20);}
else{
t21=C_eqp(t4,lf[354]);
if(C_truep(t21)){
t22=t6;
f_13045(t22,t21);}
else{
t22=C_eqp(t4,lf[378]);
if(C_truep(t22)){
t23=t6;
f_13045(t23,t22);}
else{
t23=C_eqp(t4,lf[382]);
if(C_truep(t23)){
t24=t6;
f_13045(t24,t23);}
else{
t24=C_eqp(t4,lf[357]);
if(C_truep(t24)){
t25=t6;
f_13045(t25,t24);}
else{
t25=C_eqp(t4,lf[359]);
if(C_truep(t25)){
t26=t6;
f_13045(t26,t25);}
else{
t26=C_eqp(t4,lf[429]);
if(C_truep(t26)){
t27=t6;
f_13045(t27,t26);}
else{
t27=C_eqp(t4,lf[430]);
if(C_truep(t27)){
t28=t6;
f_13045(t28,t27);}
else{
t28=C_eqp(t4,lf[407]);
if(C_truep(t28)){
t29=t6;
f_13045(t29,t28);}
else{
t29=C_eqp(t4,lf[403]);
if(C_truep(t29)){
t30=t6;
f_13045(t30,t29);}
else{
t30=C_eqp(t4,lf[399]);
if(C_truep(t30)){
t31=t6;
f_13045(t31,t30);}
else{
t31=C_eqp(t4,lf[400]);
if(C_truep(t31)){
t32=t6;
f_13045(t32,t31);}
else{
t32=C_eqp(t4,lf[397]);
if(C_truep(t32)){
t33=t6;
f_13045(t33,t32);}
else{
t33=C_eqp(t4,lf[406]);
if(C_truep(t33)){
t34=t6;
f_13045(t34,t33);}
else{
t34=C_eqp(t4,lf[381]);
if(C_truep(t34)){
t35=t6;
f_13045(t35,t34);}
else{
t35=C_eqp(t4,lf[398]);
if(C_truep(t35)){
t36=t6;
f_13045(t36,t35);}
else{
t36=C_eqp(t4,lf[396]);
if(C_truep(t36)){
t37=t6;
f_13045(t37,t36);}
else{
t37=C_eqp(t4,lf[401]);
t38=t6;
f_13045(t38,(C_truep(t37)?t37:C_eqp(t4,lf[402])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k6308 in for-each-loop633 in k6271 in k6223 in initialize-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6300(t3,((C_word*)t0)[4],t2);}

/* dump in debugging in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_4779(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4779,NULL,3,t0,t1,t2);}
t3=*((C_word*)lf[8]+1);
t4=*((C_word*)lf[8]+1);
t5=C_i_check_port_2(*((C_word*)lf[8]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[21]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4786,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:57: ##sys#print */
t7=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,((C_word*)t0)[2],C_SCHEME_FALSE,*((C_word*)lf[8]+1));}

/* for-each-loop2548 in a11498 in k11486 in pprint-expressions-to-file in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_11516(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11516,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11526,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11505,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1000: pretty-print */
t7=*((C_word*)lf[344]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* for-each-loop633 in k6271 in k6223 in initialize-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_6300(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6300,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6310,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_a_i_list(&a,1,lf[141]);
if(C_truep(C_i_nullp(t5))){
/* tweaks.scm:54: ##sys#put! */
t6=*((C_word*)lf[142]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t3,t4,lf[143],C_SCHEME_TRUE);}
else{
t6=C_i_car(t5);
/* tweaks.scm:54: ##sys#put! */
t7=*((C_word*)lf[142]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t3,t4,lf[143],t6);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* a11547 in foreign-type-check in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11548(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11548,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11554,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_11554(t7,t1,t2);}

/* ##compiler#foreign-type-check in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11542(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11542,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11548,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12478,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1014: follow-without-loop */
t6=*((C_word*)lf[92]+1);
f_5641(5,t6,t1,t3,t4,t5);}

/* a13016 in estimate-foreign-result-size in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_13017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13017,2,t0,t1);}
/* support.scm:1183: quit */
t2=*((C_word*)lf[28]+1);
f_4947(4,t2,t1,lf[440],((C_word*)t0)[2]);}

/* k5257 in stringify in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5259,2,t0,t1);}
t2=t1;
t3=C_i_check_port_2(t2,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[51]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5265,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:164: ##sys#print */
t5=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[3],C_SCHEME_FALSE,t2);}

/* k5263 in k5257 in stringify in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:164: get-output-string */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k11926 in k11881 in k11837 in k11810 in k11783 in k11757 in k11715 in k11592 in k11577 in repeat in a11547 in foreign-type-check in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_11928(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11928,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(*((C_word*)lf[350]+1))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,2,lf[379],((C_word*)t0)[3]));}
else{
t2=C_a_i_list(&a,2,lf[380],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,2,lf[379],t2));}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[382]);
if(C_truep(t2)){
if(C_truep(*((C_word*)lf[350]+1))){
t3=C_a_i_list(&a,2,lf[383],((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,2,lf[379],t3));}
else{
t3=C_a_i_list(&a,2,lf[383],((C_word*)t0)[3]);
t4=C_a_i_list(&a,2,lf[380],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_list(&a,2,lf[379],t4));}}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11971,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[6]))){
/* support.scm:1099: ##sys#hash-table-ref */
t4=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[395]+1),((C_word*)t0)[6]);}
else{
t4=t3;
f_11971(2,t4,C_SCHEME_FALSE);}}}}

/* ##compiler#stringify in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5240(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5240,3,t0,t1,t2);}
if(C_truep(C_i_stringp(t2))){
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep(C_i_symbolp(t2))){
/* support.scm:163: symbol->string */
t3=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5259,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:164: open-output-string */
t4=*((C_word*)lf[53]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}}

/* k11503 in for-each-loop2548 in a11498 in k11486 in pprint-expressions-to-file in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1001: newline */
t2=*((C_word*)lf[12]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k5291 in symbolify in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5293,2,t0,t1);}
t2=t1;
t3=C_i_check_port_2(t2,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[51]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5299,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:169: ##sys#print */
t5=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[3],C_SCHEME_FALSE,t2);}

/* k5297 in k5291 in symbolify in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5299,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5302,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:169: get-output-string */
t3=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word ab[59],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4708,2,t0,t1);}
t2=C_mutate2((C_word*)lf[8]+1 /* (set! ##compiler#collected-debugging-output ...) */,t1);
t3=C_mutate2((C_word*)lf[9]+1 /* (set! +logged-debugging-modes+ ...) */,lf[10]);
t4=C_mutate2((C_word*)lf[11]+1 /* (set! ##compiler#debugging ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4711,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate2((C_word*)lf[23]+1 /* (set! ##compiler#with-debugging-output ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4831,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate2((C_word*)lf[28]+1 /* (set! ##compiler#quit ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4947,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate2((C_word*)lf[32]+1 /* (set! ##sys#syntax-error-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4963,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate2((C_word*)lf[41]+1 /* (set! syntax-error ...) */,*((C_word*)lf[32]+1));
t9=C_mutate2((C_word*)lf[42]+1 /* (set! ##compiler#emit-syntax-trace-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5060,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate2((C_word*)lf[43]+1 /* (set! map-llist ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5063,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate2((C_word*)lf[44]+1 /* (set! ##compiler#check-signature ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5104,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate2((C_word*)lf[47]+1 /* (set! ##compiler#posq ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5172,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate2((C_word*)lf[48]+1 /* (set! ##compiler#posv ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5206,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate2((C_word*)lf[49]+1 /* (set! ##compiler#stringify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5240,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate2((C_word*)lf[54]+1 /* (set! ##compiler#symbolify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5270,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate2((C_word*)lf[56]+1 /* (set! ##compiler#slashify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5304,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate2((C_word*)lf[61]+1 /* (set! ##compiler#uncommentify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5314,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate2((C_word*)lf[64]+1 /* (set! ##compiler#build-lambda-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5324,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate2((C_word*)lf[65]+1 /* (set! ##compiler#string->c-identifier ...) */,*((C_word*)lf[66]+1));
t20=C_mutate2((C_word*)lf[67]+1 /* (set! ##compiler#c-ify-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5366,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate2((C_word*)lf[76]+1 /* (set! ##compiler#valid-c-identifier? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5463,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate2((C_word*)lf[78]+1 /* (set! ##compiler#words ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5515,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate2((C_word*)lf[79]+1 /* (set! ##compiler#words->bytes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5522,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate2((C_word*)lf[80]+1 /* (set! ##compiler#check-and-open-input-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5529,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate2((C_word*)lf[87]+1 /* (set! ##compiler#close-checked-input-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5573,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate2((C_word*)lf[90]+1 /* (set! ##compiler#fold-inner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5585,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate2((C_word*)lf[92]+1 /* (set! ##compiler#follow-without-loop ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5641,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate2((C_word*)lf[93]+1 /* (set! ##compiler#sort-symbols ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5672,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate2((C_word*)lf[96]+1 /* (set! ##compiler#constant? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5692,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate2((C_word*)lf[100]+1 /* (set! ##compiler#collapsable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5754,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate2((C_word*)lf[101]+1 /* (set! ##compiler#immediate? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5784,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate2((C_word*)lf[103]+1 /* (set! ##compiler#basic-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5830,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate2((C_word*)lf[106]+1 /* (set! ##compiler#canonicalize-begin-body ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5886,tmp=(C_word)a,a+=2,tmp));
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5961,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:301: condition-predicate */
t35=*((C_word*)lf[562]+1);
((C_proc3)(void*)(*((C_word*)t35+1)))(3,t35,t34,lf[515]);}

/* ##compiler#collect! in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6451(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_6451,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6455,a[2]=t4,a[3]=t5,a[4]=t1,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm:394: ##sys#hash-table-ref */
t7=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t2,t3);}

/* a14942 in display-real-name-table in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14943(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_14943,4,t0,t1,t2,t3);}
t4=*((C_word*)lf[13]+1);
t5=*((C_word*)lf[13]+1);
t6=C_i_check_port_2(*((C_word*)lf[13]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[14]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14950,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1444: ##sys#print */
t8=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,t2,C_SCHEME_TRUE,*((C_word*)lf[13]+1));}

/* ##compiler#symbolify in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5270(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5270,3,t0,t1,t2);}
if(C_truep(C_i_symbolp(t2))){
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep(C_i_stringp(t2))){
/* support.scm:168: string->symbol */
t3=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5293,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:169: open-output-string */
t4=*((C_word*)lf[53]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}}

/* k14951 in k14948 in a14942 in display-real-name-table in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14953,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14956,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1444: ##sys#print */
t3=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],C_SCHEME_TRUE,((C_word*)t0)[3]);}

/* k14954 in k14951 in k14948 in a14942 in display-real-name-table in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1444: ##sys#write-char-0 */
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(10),((C_word*)t0)[3]);}

/* k14948 in a14942 in display-real-name-table in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14950,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14953,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1444: ##sys#write-char-0 */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(9),((C_word*)t0)[3]);}

/* k6453 in collect! in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6455,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_assq(((C_word*)t0)[2],t1);
if(C_truep(t2)){
t3=C_slot(t2,C_fix(1));
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_i_setslot(t2,C_fix(1),t4));}
else{
t3=C_a_i_list1(&a,1,((C_word*)t0)[3]);
t4=C_slot(t1,C_fix(1));
t5=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[2],t3),t4);
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_i_setslot(t1,C_fix(1),t5));}}
else{
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=C_a_i_list1(&a,1,t2);
/* support.scm:399: ##sys#hash-table-set! */
t4=*((C_word*)lf[153]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],t3);}}

/* k14918 in k14822 in real-name in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14920,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14851,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm:1424: get */
t5=*((C_word*)lf[148]+1);
f_6369(5,t5,t4,((C_word*)t0)[2],((C_word*)t0)[5],lf[181]);}

/* k14927 in real-name2 in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm:1440: real-name */
t2=*((C_word*)lf[46]+1);
f_14805(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#real-name2 in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14925(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_14925,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14929,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1439: ##sys#hash-table-ref */
t5=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[494]+1),t2);}

/* k13061 in k13055 in k13043 in a13034 in estimate-foreign-result-location-size in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_13063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13063,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13067,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1201: g3124 */
t3=t2;
f_13067(t3,((C_word*)t0)[3],t1);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[4];
t3=C_u_i_car(t2);
t4=C_eqp(t3,lf[384]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13100,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_13100(t6,t4);}
else{
t6=C_eqp(t3,lf[392]);
if(C_truep(t6)){
t7=t5;
f_13100(t7,t6);}
else{
t7=C_eqp(t3,lf[393]);
if(C_truep(t7)){
t8=t5;
f_13100(t8,t7);}
else{
t8=C_eqp(t3,lf[375]);
if(C_truep(t8)){
t9=t5;
f_13100(t9,t8);}
else{
t9=C_eqp(t3,lf[377]);
t10=t5;
f_13100(t10,(C_truep(t9)?t9:C_eqp(t3,lf[394])));}}}}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[4];
/* support.scm:1187: quit */
t4=*((C_word*)lf[28]+1);
f_4947(4,t4,t2,lf[442],t3);}}}

/* g3124 in k13061 in k13055 in k13043 in a13034 in estimate-foreign-result-location-size in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_13067(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13067,NULL,3,t0,t1,t2);}
if(C_truep(C_i_vectorp(t2))){
t3=C_i_vector_ref(t2,C_fix(0));
/* support.scm:1203: next */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t3=t2;
/* support.scm:1203: next */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}}

/* ##compiler#display-real-name-table in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14937,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14943,tmp=(C_word)a,a+=2,tmp);
/* support.scm:1443: ##sys#hash-table-for-each */
t3=*((C_word*)lf[162]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,*((C_word*)lf[494]+1));}

/* k9197 in loop in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9199,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
/* support.scm:666: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9158(t3,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],t2);}

/* k14907 in k14875 in loop in k14849 in k14918 in k14822 in real-name in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14909,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t3=t2;
t4=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14905,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* support.scm:1434: get */
t7=*((C_word*)lf[148]+1);
f_6369(5,t7,t6,((C_word*)t0)[6],((C_word*)t0)[7],lf[181]);}

/* k14903 in k14907 in k14875 in loop in k14849 in k14918 in k14822 in real-name in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1432: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_14853(t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t1);}

/* k14914 in loop in k14849 in k14918 in k14822 in real-name in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1435: string-intersperse */
t2=*((C_word*)lf[496]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[500]);}

/* ##compiler#words in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5515(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5515,3,t0,t1,t2);}
t3=C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub342(C_SCHEME_UNDEFINED,t3));}

/* k5511 in valid-c-identifier? in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=*((C_word*)lf[72]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* ##compiler#words->bytes in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5522(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5522,3,t0,t1,t2);}
t3=C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub347(C_SCHEME_UNDEFINED,t3));}

/* loop in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_9158(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9158,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_zerop(t2))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9172,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* support.scm:665: reverse */
t6=*((C_word*)lf[91]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}
else{
t5=C_a_i_minus(&a,2,t2,C_fix(1));
t6=t5;
t7=C_i_cdr(t3);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9199,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t6,a[6]=t8,tmp=(C_word)a,a+=7,tmp);
t10=t3;
t11=C_u_i_car(t10);
/* support.scm:666: walk */
t12=((C_word*)((C_word*)t0)[2])[1];
f_8584(3,t12,t9,t11);}}

/* k15254 in dump-nodes in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1508: newline */
t2=*((C_word*)lf[12]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#dump-nodes in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15252(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_15252,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15256,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15261,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_15261(t7,t3,C_fix(0),t2);}

/* ##compiler#export-variable in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15598(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_15598,3,t0,t1,t2);}
t3=C_a_i_list(&a,1,lf[538]);
if(C_truep(C_i_nullp(t3))){
/* tweaks.scm:54: ##sys#put! */
t4=*((C_word*)lf[142]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,t2,lf[536],C_SCHEME_TRUE);}
else{
t4=C_i_car(t3);
/* tweaks.scm:54: ##sys#put! */
t5=*((C_word*)lf[142]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,lf[536],t4);}}

/* rec in simple-lambda-node? in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11031(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11031,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=C_eqp(t4,lf[251]);
if(C_truep(t5)){
t6=t2;
t7=C_slot(t6,C_fix(3));
t8=C_i_car(t7);
t9=C_slot(t8,C_fix(1));
t10=C_eqp(lf[221],t9);
if(C_truep(t10)){
t11=C_slot(t8,C_fix(2));
t12=C_i_car(t11);
t13=C_eqp(((C_word*)t0)[2],t12);
if(C_truep(t13)){
t14=C_u_i_cdr(t7);
/* support.scm:893: every */
t15=*((C_word*)lf[104]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,((C_word*)((C_word*)t0)[3])[1],t14);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t6=C_eqp(t4,lf[242]);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}
else{
t7=t2;
t8=C_slot(t7,C_fix(3));
/* support.scm:895: every */
t9=*((C_word*)lf[104]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t1,((C_word*)((C_word*)t0)[3])[1],t8);}}}

/* k14464 in walk in scan-free-variables in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_14466(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14466,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=C_eqp(((C_word*)t0)[3],lf[221]);
if(C_truep(t2)){
t3=C_i_car(((C_word*)t0)[4]);
t4=t3;
if(C_truep(C_i_memq(t4,((C_word*)t0)[5]))){
t5=C_SCHEME_UNDEFINED;
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14485,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[7],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* support.scm:1339: lset-adjoin */
t6=*((C_word*)lf[480]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,*((C_word*)lf[27]+1),((C_word*)((C_word*)t0)[6])[1],t4);}}
else{
t3=C_eqp(((C_word*)t0)[3],lf[244]);
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[4]);
if(C_truep(C_i_memq(t4,((C_word*)t0)[5]))){
t5=C_i_car(((C_word*)t0)[8]);
/* support.scm:1345: walk */
t6=((C_word*)((C_word*)t0)[9])[1];
f_14432(t6,((C_word*)t0)[2],t5,((C_word*)t0)[5]);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14521,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* support.scm:1344: lset-adjoin */
t6=*((C_word*)lf[480]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,*((C_word*)lf[27]+1),((C_word*)((C_word*)t0)[6])[1],t4);}}
else{
t4=C_eqp(((C_word*)t0)[3],lf[109]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14530,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t6=C_i_car(((C_word*)t0)[8]);
/* support.scm:1347: walk */
t7=((C_word*)((C_word*)t0)[9])[1];
f_14432(t7,t5,t6,((C_word*)t0)[5]);}
else{
t5=C_eqp(((C_word*)t0)[3],lf[133]);
if(C_truep(t5)){
t6=C_i_caddr(((C_word*)t0)[4]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14560,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1350: decompose-lambda-list */
t8=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[2],t6,t7);}
else{
/* support.scm:1354: walkeach */
t6=((C_word*)((C_word*)t0)[10])[1];
f_14616(t6,((C_word*)t0)[2],((C_word*)t0)[8],((C_word*)t0)[5]);}}}}}}

/* k8428 in a8342 in k8211 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8430,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t4=((C_word*)t0)[3];
f_8402(t4,C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_8402(t2,C_SCHEME_FALSE);}}

/* k5786 in immediate? in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_5788(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_eqp(C_SCHEME_UNDEFINED,((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=C_i_nullp(((C_word*)t0)[3]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=C_eofp(((C_word*)t0)[3]);
if(C_truep(t4)){
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=C_charp(((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?t5:C_booleanp(((C_word*)t0)[3])));}}}}}

/* ##compiler#immediate? in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5784(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5784,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5788,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_fixnump(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5828,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm:269: big-fixnum? */
t5=*((C_word*)lf[102]+1);
f_15554(3,t5,t4,t2);}
else{
t4=t3;
f_5788(t4,C_SCHEME_FALSE);}}

/* k5625 in fold in k5597 in fold-inner in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5627,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=C_a_i_list2(&a,2,t1,t3);
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[4],t4);}

/* k14483 in k14464 in walk in scan-free-variables in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14485,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14491,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1340: variable-visible? */
t4=*((C_word*)lf[311]+1);
f_15618(3,t4,t3,((C_word*)t0)[5]);}

/* k14983 in source-info->string in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1452: make-string */
t2=*((C_word*)lf[507]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_make_character(32));}

/* k14979 in source-info->string in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1452: conc */
t2=*((C_word*)lf[504]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[505],t1,lf[506],((C_word*)t0)[4]);}

/* ##compiler#source-info->line in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14995(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14995,3,t0,t1,t2);}
if(C_truep(C_i_listp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_car(t2));}
else{
if(C_truep(t2)){
/* support.scm:1458: ->string */
t3=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* fold in k5597 in fold-inner in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_5601(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5601,NULL,3,t0,t1,t2);}
t3=C_i_cddr(t2);
if(C_truep(C_i_nullp(t3))){
t4=t2;
t5=C_u_i_cdr(t4);
t6=C_u_i_car(t5);
t7=t2;
t8=C_u_i_car(t7);
t9=C_a_i_list2(&a,2,t6,t8);
C_apply(4,0,t1,((C_word*)t0)[2],t9);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5627,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=C_u_i_cdr(t5);
/* support.scm:236: fold */
t14=t4;
t15=t6;
t1=t14;
t2=t15;
goto loop;}}

/* k7445 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7447,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record4(&a,4,lf[211],((C_word*)t0)[3],C_SCHEME_END_OF_LIST,t1));}

/* map-loop1063 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_7449(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7449,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7478,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:528: g1069 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9170 in loop in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9172,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9176,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_car(((C_word*)t0)[3]);
/* support.scm:665: walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_8584(3,t5,t3,t4);}

/* k9174 in k9170 in loop in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9176,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,3,lf[269],((C_word*)t0)[3],t1));}

/* tmp14292 in a6004 in a5973 in string->expr in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_6007(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6007,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6011,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6033,tmp=(C_word)a,a+=2,tmp);
/* support.scm:310: with-input-from-string */
t4=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* ##compiler#scan-free-variables in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14429(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14429,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14432,a[2]=t4,a[3]=t6,a[4]=t8,a[5]=t10,tmp=(C_word)a,a+=6,tmp));
t12=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14616,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14654,a[2]=t1,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1359: walk */
t14=((C_word*)t8)[1];
f_14432(t14,t13,t2,C_SCHEME_END_OF_LIST);}

/* a6004 in a5973 in string->expr in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6005,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6007,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6048,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6065,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tmp14292 */
t5=t2;
f_6007(t5,t4);}

/* ##compiler#source-info->string in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14961(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14961,3,t0,t1,t2);}
if(C_truep(C_i_listp(t2))){
t3=C_i_car(t2);
t4=t3;
t5=C_i_cadr(t2);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14981,a[2]=t1,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14985,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=C_i_string_length(t4);
t10=C_a_i_minus(&a,2,C_fix(4),t9);
/* support.scm:1452: max */
t11=*((C_word*)lf[508]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t8,C_fix(0),t10);}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* ##compiler#intrinsic? in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15664(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_15664,3,t0,t1,t2);}
/* tweaks.scm:57: ##sys#get */
t3=*((C_word*)lf[253]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[143]);}

/* ##compiler#get-list in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6558(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6558,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6562,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:411: get */
t6=*((C_word*)lf[148]+1);
f_6369(5,t6,t5,t2,t3,t4);}

/* walk in scan-free-variables in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_14432(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14432,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=C_slot(t4,C_fix(3));
t6=t5;
t7=t2;
t8=C_slot(t7,C_fix(2));
t9=t8;
t10=t2;
t11=C_slot(t10,C_fix(1));
t12=t11;
t13=C_eqp(t12,lf[97]);
t14=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_14466,a[2]=t1,a[3]=t12,a[4]=t9,a[5]=t3,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],a[8]=t6,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t13)){
t15=t14;
f_14466(t15,t13);}
else{
t15=C_eqp(t12,lf[226]);
if(C_truep(t15)){
t16=t14;
f_14466(t16,t15);}
else{
t16=C_eqp(t12,lf[240]);
if(C_truep(t16)){
t17=t14;
f_14466(t17,t16);}
else{
t17=C_eqp(t12,lf[243]);
t18=t14;
f_14466(t18,(C_truep(t17)?t17:C_eqp(t12,lf[255])));}}}}

/* ##compiler#check-and-open-input-file in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5529(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_5529r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5529r(t0,t1,t2,t3);}}

static void C_ccall f_5529r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
if(C_truep(C_i_string_equal_p(t2,lf[81]))){
t4=*((C_word*)lf[82]+1);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,*((C_word*)lf[82]+1));}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5542,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:221: file-exists? */
t5=*((C_word*)lf[86]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* foldable? in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15675(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_15675,3,t0,t1,t2);}
/* tweaks.scm:57: ##sys#get */
t3=*((C_word*)lf[253]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[145]);}

/* map-loop2001 in k9910 in k9902 in k9839 in k9836 in a9822 in walk in k9647 in copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_9867(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9867,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9896,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:750: g2007 */
t5=((C_word*)t0)[5];
f_9855(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9863 in k9910 in k9902 in k9839 in k9836 in a9822 in walk in k9647 in copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9865,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record4(&a,4,lf[211],lf[133],((C_word*)t0)[3],t1));}

/* k13945 in k13923 in k13905 in k13884 in k13809 in k13734 in k13710 in foreign-type->scrutiny-type in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_13947(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[477]);}
else{
t2=C_eqp(((C_word*)t0)[3],lf[390]);
if(C_truep(t2)){
t3=C_i_cadr(((C_word*)t0)[4]);
/* support.scm:1301: foreign-type->scrutiny-type */
t4=*((C_word*)lf[458]+1);
f_13708(4,t4,((C_word*)t0)[2],t3,((C_word*)t0)[5]);}
else{
t3=C_eqp(((C_word*)t0)[3],lf[391]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[423]);}
else{
t4=C_eqp(((C_word*)t0)[3],lf[392]);
if(C_truep(t4)){
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?lf[393]:lf[239]));}
else{
t5=C_eqp(((C_word*)t0)[3],lf[377]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?lf[393]:lf[239]));}}}}}

/* k11899 in k11884 in k11881 in k11837 in k11810 in k11783 in k11757 in k11715 in k11592 in k11577 in repeat in a11547 in foreign-type-check in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_11901(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11901,NULL,2,t0,t1);}
t2=C_a_i_list(&a,2,lf[97],C_SCHEME_FALSE);
t3=C_a_i_list(&a,4,lf[225],((C_word*)t0)[2],t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,3,lf[109],((C_word*)t0)[4],t3));}

/* ##compiler#load-identifier-database in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15686(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_15686,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15690,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1597: repository-path */
t4=*((C_word*)lf[551]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k8011 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8013,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record4(&a,4,lf[211],((C_word*)t0)[3],((C_word*)t0)[4],t1));}

/* k15694 in k15688 in load-identifier-database in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15696,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15702,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15760,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1599: open-output-string */
t5=*((C_word*)lf[53]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* map-loop1232 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_8015(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8015,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8044,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:582: g1238 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k15494 in loop in k15485 in scan-sharp-greater-string in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15496,2,t0,t1);}
if(C_truep(C_eofp(t1))){
/* support.scm:1543: quit */
t2=*((C_word*)lf[28]+1);
f_4947(3,t2,((C_word*)t0)[2],lf[534]);}
else{
if(C_truep(C_i_char_equalp(t1,C_make_character(10)))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15514,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1545: newline */
t3=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}
else{
if(C_truep(C_i_char_equalp(t1,C_make_character(60)))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15526,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* read-char/port */
t3=*((C_word*)lf[533]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15549,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=*((C_word*)lf[522]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[4]);}}}}

/* k15688 in load-identifier-database in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15690,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15696,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15782,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1598: make-pathname */
t4=*((C_word*)lf[550]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop in k15485 in scan-sharp-greater-string in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_15492(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15492,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15496,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* read-char/port */
t3=*((C_word*)lf[533]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k13923 in k13905 in k13884 in k13809 in k13734 in k13710 in foreign-type->scrutiny-type in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_13925(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13925,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[476]);}
else{
t2=C_eqp(((C_word*)t0)[3],lf[382]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[382]);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t3=((C_word*)t0)[4];
t4=C_u_i_car(t3);
t5=C_eqp(t4,lf[384]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13947,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_13947(t7,t5);}
else{
t7=C_eqp(t4,lf[393]);
if(C_truep(t7)){
t8=t6;
f_13947(t8,t7);}
else{
t8=C_eqp(t4,lf[394]);
t9=t6;
f_13947(t9,(C_truep(t8)?t8:C_eqp(t4,lf[375])));}}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[239]);}}}}

/* k8995 in loop in k8959 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8997,2,t0,t1);}
t2=C_a_i_list(&a,2,lf[237],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,1,t2));}

/* k15620 in variable-visible? in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_eqp(t1,lf[535]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=C_eqp(t1,lf[538]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_TRUE:C_i_not(*((C_word*)lf[539]+1))));}}

/* k9836 in a9822 in walk in k9647 in copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9838,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9841,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t0)[8];
t9=C_i_check_list_2(t2,lf[161]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9930,a[2]=t3,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9932,a[2]=t7,a[3]=t12,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t14=((C_word*)t12)[1];
f_9932(t14,t10,t8,t2);}

/* k9830 in k9827 in g1940 in a9822 in walk in k9647 in copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* k8963 in k8959 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8965,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[267],t2));}

/* k8959 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8961,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8965,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=C_i_cdr(((C_word*)t0)[3]);
t5=C_u_i_cdr(((C_word*)t0)[4]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8973,a[2]=((C_word*)t0)[5],a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_8973(t9,t3,t4,t5);}

/* k9827 in g1940 in a9822 in walk in k9647 in copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9829,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9832,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:741: put! */
t4=*((C_word*)lf[152]+1);
f_6405(6,t4,t3,((C_word*)t0)[3],((C_word*)t0)[4],lf[286],C_SCHEME_TRUE);}

/* g1940 in a9822 in walk in k9647 in copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_9825(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9825,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9829,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:740: gensym */
t4=*((C_word*)lf[110]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* a9822 in walk in k9647 in copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9823(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9823,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9825,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t10=t2;
t11=C_i_check_list_2(t10,lf[161]);
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9838,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,a[7]=t4,a[8]=t2,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9981,a[2]=t8,a[3]=t14,a[4]=t6,a[5]=t9,tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_9981(t16,t12,t10);}

/* ##compiler#simple-lambda-node? in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11003(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11003,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(2));
t5=C_i_caddr(t4);
t6=C_i_pairp(t5);
t7=(C_truep(t6)?C_u_i_car(t5):C_SCHEME_FALSE);
t8=t7;
if(C_truep(t8)){
t9=C_u_i_cdr(t4);
if(C_truep(C_u_i_car(t9))){
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11031,a[2]=t8,a[3]=t11,tmp=(C_word)a,a+=4,tmp));
t13=((C_word*)t11)[1];
f_11031(3,t13,t1,t2);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}

/* k13905 in k13884 in k13809 in k13734 in k13710 in foreign-type->scrutiny-type in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_13907(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13907,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[474]);}
else{
t2=C_eqp(((C_word*)t0)[3],lf[401]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[3],lf[402]));
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[475]);}
else{
t4=C_eqp(((C_word*)t0)[3],lf[381]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13925,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_13925(t6,t4);}
else{
t6=C_eqp(((C_word*)t0)[3],lf[396]);
t7=t5;
f_13925(t7,(C_truep(t6)?t6:C_eqp(((C_word*)t0)[3],lf[397])));}}}}

/* loop in k8959 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_8973(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8973,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
if(C_truep(C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8997,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=C_i_car(t3);
/* support.scm:655: walk */
t6=((C_word*)((C_word*)t0)[2])[1];
f_8584(3,t6,t4,t5);}}
else{
t4=C_i_car(t2);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9024,a[2]=t5,a[3]=t1,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t7=C_i_car(t3);
/* support.scm:656: walk */
t8=((C_word*)((C_word*)t0)[2])[1];
f_8584(3,t8,t6,t7);}}

/* k11675 in k11660 in k11592 in k11577 in repeat in a11547 in foreign-type-check in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_11677(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11677,NULL,2,t0,t1);}
t2=C_a_i_list(&a,2,lf[97],C_SCHEME_FALSE);
t3=C_a_i_list(&a,4,lf[225],((C_word*)t0)[2],t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,3,lf[109],((C_word*)t0)[4],t3));}

/* ##compiler#mark-variable in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15643(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4r,(void*)f_15643r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_15643r(t0,t1,t2,t3,t4);}}

static void C_ccall f_15643r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
if(C_truep(C_i_nullp(t4))){
/* support.scm:1585: ##sys#put! */
t5=*((C_word*)lf[142]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,t3,C_SCHEME_TRUE);}
else{
t5=C_i_car(t4);
/* support.scm:1585: ##sys#put! */
t6=*((C_word*)lf[142]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,t3,t5);}}

/* k9894 in map-loop2001 in k9910 in k9902 in k9839 in k9836 in a9822 in walk in k9647 in copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9896,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9867(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9867(t6,((C_word*)t0)[5],t5);}}

/* ##compiler#variable-mark in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15658(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_15658,4,t0,t1,t2,t3);}
/* support.scm:1588: ##sys#get */
t4=*((C_word*)lf[253]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,t3);}

/* k11660 in k11592 in k11577 in repeat in a11547 in foreign-type-check in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11662,2,t0,t1);}
t2=t1;
t3=C_a_i_list(&a,2,t2,((C_word*)t0)[2]);
t4=C_a_i_list(&a,1,t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11677,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[350]+1))){
t7=t6;
f_11677(t7,t2);}
else{
t7=C_a_i_list(&a,2,lf[97],lf[361]);
t8=t6;
f_11677(t8,C_a_i_list(&a,3,lf[362],t7,t2));}}

/* k7476 in map-loop1063 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7478,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7449(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7449(t6,((C_word*)t0)[5],t5);}}

/* k11610 in k11592 in k11577 in repeat in a11547 in foreign-type-check in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11612,2,t0,t1);}
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=(C_truep(*((C_word*)lf[350]+1))?t1:C_a_i_list(&a,2,lf[358],t1));
t5=C_a_i_list(&a,2,lf[97],C_SCHEME_FALSE);
t6=C_a_i_list(&a,4,lf[225],t1,t4,t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_list(&a,3,lf[109],t3,t6));}

/* g2781 in k11969 in k11926 in k11881 in k11837 in k11810 in k11783 in k11757 in k11715 in k11592 in k11577 in repeat in a11547 in foreign-type-check in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_11975(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11975,NULL,3,t0,t1,t2);}
if(C_truep(C_i_vectorp(t2))){
t3=C_i_vector_ref(t2,C_fix(0));
/* support.scm:1101: next */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t3=t2;
/* support.scm:1101: next */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}}

/* k11969 in k11926 in k11881 in k11837 in k11810 in k11783 in k11757 in k11715 in k11592 in k11577 in repeat in a11547 in foreign-type-check in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11971,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11975,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1099: g2781 */
t3=t2;
f_11975(t3,((C_word*)t0)[3],t1);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[4];
t3=C_u_i_car(t2);
t4=C_eqp(t3,lf[384]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12008,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t4)){
t6=t5;
f_12008(t6,t4);}
else{
t6=C_eqp(t3,lf[393]);
if(C_truep(t6)){
t7=t5;
f_12008(t7,t6);}
else{
t7=C_eqp(t3,lf[394]);
t8=t5;
f_12008(t8,(C_truep(t7)?t7:C_eqp(t3,lf[375])));}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}}

/* ##compiler#variable-visible? in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15618(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_15618,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15622,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1578: ##sys#get */
t4=*((C_word*)lf[253]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[536]);}

/* k6223 in initialize-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6225,2,t0,t1);}
t2=*((C_word*)lf[139]+1);
t3=C_i_check_list_2(*((C_word*)lf[139]+1),lf[34]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6273,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6323,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_6323(t8,t4,*((C_word*)lf[139]+1));}

/* k6585 in k6582 in get-line-2 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_6587(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6587,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6591,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:420: g733 */
t3=t2;
f_6591(t3,((C_word*)t0)[3],t1);}
else{
/* support.scm:425: values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[4],C_SCHEME_FALSE);}}

/* k6582 in get-line-2 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6584,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6587,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=C_i_cdr(t2);
t5=t3;
f_6587(t5,C_i_assq(((C_word*)t0)[4],t4));}
else{
t4=t3;
f_6587(t4,C_SCHEME_FALSE);}}

/* k8901 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8903,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list3(&a,3,((C_word*)t0)[3],((C_word*)t0)[4],t1));}

/* g733 in k6585 in k6582 in get-line-2 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_6591(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6591,NULL,3,t0,t1,t2);}
t3=C_i_car(((C_word*)t0)[2]);
t4=C_i_cdr(t2);
/* support.scm:424: values */
C_values(4,0,t1,t3,t4);}

/* k13734 in k13710 in foreign-type->scrutiny-type in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_13736(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13736,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[230]);}
else{
t2=C_eqp(((C_word*)t0)[3],lf[354]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[3],lf[422]));
if(C_truep(t3)){
t4=((C_word*)t0)[4];
t5=C_eqp(t4,lf[459]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?lf[423]:lf[354]));}
else{
t4=C_eqp(((C_word*)t0)[3],lf[357]);
t5=(C_truep(t4)?t4:C_eqp(((C_word*)t0)[3],lf[359]));
if(C_truep(t5)){
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[239]);}
else{
t6=C_eqp(((C_word*)t0)[3],lf[356]);
if(C_truep(t6)){
t7=((C_word*)t0)[4];
t8=C_eqp(t7,lf[459]);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_truep(t8)?lf[460]:lf[356]));}
else{
t7=C_eqp(((C_word*)t0)[3],lf[360]);
if(C_truep(t7)){
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[356]);}
else{
t8=C_eqp(((C_word*)t0)[3],lf[361]);
if(C_truep(t8)){
t9=((C_word*)t0)[4];
t10=C_eqp(t9,lf[459]);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_truep(t10)?lf[461]:lf[361]));}
else{
t9=C_eqp(((C_word*)t0)[3],lf[363]);
if(C_truep(t9)){
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[361]);}
else{
t10=C_eqp(((C_word*)t0)[3],lf[364]);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13811,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t10)){
t12=t11;
f_13811(t12,t10);}
else{
t12=C_eqp(((C_word*)t0)[3],lf[415]);
if(C_truep(t12)){
t13=t11;
f_13811(t13,t12);}
else{
t13=C_eqp(((C_word*)t0)[3],lf[416]);
if(C_truep(t13)){
t14=t11;
f_13811(t14,t13);}
else{
t14=C_eqp(((C_word*)t0)[3],lf[417]);
if(C_truep(t14)){
t15=t11;
f_13811(t15,t14);}
else{
t15=C_eqp(((C_word*)t0)[3],lf[418]);
if(C_truep(t15)){
t16=t11;
f_13811(t16,t15);}
else{
t16=C_eqp(((C_word*)t0)[3],lf[419]);
if(C_truep(t16)){
t17=t11;
f_13811(t17,t16);}
else{
t17=C_eqp(((C_word*)t0)[3],lf[420]);
t18=t11;
f_13811(t18,(C_truep(t17)?t17:C_eqp(((C_word*)t0)[3],lf[421])));}}}}}}}}}}}}}}

/* ##compiler#get-line in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6567(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6567,3,t0,t1,t2);}
t3=C_i_car(t2);
/* support.scm:418: get */
t4=*((C_word*)lf[148]+1);
f_6369(5,t4,t1,*((C_word*)lf[158]+1),t3,t2);}

/* k6560 in get-list in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* ##compiler#foreign-type->scrutiny-type in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_13708(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_13708,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13712,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1251: final-foreign-type */
t5=*((C_word*)lf[434]+1);
f_12546(3,t5,t4,t2);}

/* ##compiler#get-line-2 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6577(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6577,3,t0,t1,t2);}
t3=C_i_car(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6584,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:422: ##sys#hash-table-ref */
t6=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,*((C_word*)lf[158]+1),t4);}

/* k6754 in k6707 in k6704 in a6695 in k6689 in display-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_6756(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6756,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[13]+1);
t3=*((C_word*)lf[13]+1);
t4=C_i_check_port_2(*((C_word*)lf[13]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[14]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6762,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:489: ##sys#print */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[166],C_SCHEME_FALSE,*((C_word*)lf[13]+1));}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6793,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t3=C_eqp(((C_word*)((C_word*)t0)[2])[1],lf[169]);
t4=t2;
f_6793(t4,C_i_not(t3));}
else{
t3=t2;
f_6793(t3,C_SCHEME_FALSE);}}}

/* k6760 in k6754 in k6707 in k6704 in a6695 in k6689 in display-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6762,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[2])[1];
t3=C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[2])[1];
t5=C_slot(t4,C_fix(2));
t6=C_a_i_cons(&a,2,t3,t5);
/* support.scm:489: ##sys#print */
t7=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,((C_word*)t0)[3],t6,C_SCHEME_TRUE,((C_word*)t0)[4]);}

/* k5352 in loop in build-lambda-list in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5354,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k9798 in k9778 in k9772 in k9769 in walk in k9647 in copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9800,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record4(&a,4,lf[211],lf[109],((C_word*)t0)[4],t2));}

/* k6728 in k6713 in k6710 in k6707 in k6704 in a6695 in k6689 in display-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_length(((C_word*)((C_word*)t0)[2])[1]);
/* support.scm:495: ##sys#print */
t3=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],t2,C_SCHEME_TRUE,((C_word*)t0)[4]);}

/* k10320 in walk in sexpr->node in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10322,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record4(&a,4,lf[211],((C_word*)t0)[3],((C_word*)t0)[4],t1));}

/* map-loop2148 in walk in sexpr->node in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_10324(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10324,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10353,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:774: g2154 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6744 in k6710 in k6707 in k6704 in a6695 in k6689 in display-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_length(((C_word*)((C_word*)t0)[2])[1]);
/* support.scm:494: ##sys#print */
t3=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],t2,C_SCHEME_TRUE,((C_word*)t0)[4]);}

/* k5376 in c-ify-string in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5378,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_make_character(34),t1);
/* list->string */
t3=*((C_word*)lf[68]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k6797 in k6791 in k6754 in k6707 in k6704 in a6695 in k6689 in display-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6799,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[2])[1];
t3=C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[2])[1];
t5=C_slot(t4,C_fix(2));
t6=C_a_i_cons(&a,2,t3,t5);
/* support.scm:491: ##sys#print */
t7=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,((C_word*)t0)[3],t6,C_SCHEME_TRUE,((C_word*)t0)[4]);}

/* k6791 in k6754 in k6707 in k6704 in a6695 in k6689 in display-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_6793(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6793,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[13]+1);
t3=*((C_word*)lf[13]+1);
t4=C_i_check_port_2(*((C_word*)lf[13]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[14]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6799,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:491: ##sys#print */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[167],C_SCHEME_FALSE,*((C_word*)lf[13]+1));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6830,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t3=C_eqp(((C_word*)((C_word*)t0)[5])[1],lf[169]);
t4=t2;
f_6830(t4,C_i_not(t3));}
else{
t3=t2;
f_6830(t3,C_SCHEME_FALSE);}}}

/* k11432 in k11429 in k11426 in k11420 in k11417 in k11414 in k11411 in k11408 in k11402 in a11396 in print-program-statistics in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11434,2,t0,t1);}
t2=*((C_word*)lf[13]+1);
t3=*((C_word*)lf[13]+1);
t4=C_i_check_port_2(*((C_word*)lf[13]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[14]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11440,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* support.scm:986: ##sys#print */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[336],C_SCHEME_FALSE,*((C_word*)lf[13]+1));}

/* k4669 in k4666 */
static void C_ccall f_4671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4671,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4674,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_chicken_2dsyntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k11429 in k11426 in k11420 in k11417 in k11414 in k11411 in k11408 in k11402 in a11396 in print-program-statistics in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11431,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11434,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm:985: ##sys#write-char-0 */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[7]);}

/* k11592 in k11577 in repeat in a11547 in foreign-type-check in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_11594(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11594,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(*((C_word*)lf[350]+1))?((C_word*)t0)[3]:C_a_i_list(&a,2,lf[355],((C_word*)t0)[3])));}
else{
t2=C_eqp(((C_word*)t0)[4],lf[356]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[4],lf[357]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11612,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1024: gensym */
t5=*((C_word*)lf[110]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[359]);
t5=(C_truep(t4)?t4:C_eqp(((C_word*)t0)[4],lf[360]));
if(C_truep(t5)){
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(*((C_word*)lf[350]+1))?((C_word*)t0)[3]:C_a_i_list(&a,2,lf[358],((C_word*)t0)[3])));}
else{
t6=C_eqp(((C_word*)t0)[4],lf[361]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11662,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1036: gensym */
t8=*((C_word*)lf[110]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=C_eqp(((C_word*)t0)[4],lf[363]);
if(C_truep(t7)){
if(C_truep(*((C_word*)lf[350]+1))){
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,((C_word*)t0)[3]);}
else{
t8=C_a_i_list(&a,2,lf[97],lf[361]);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_a_i_list(&a,3,lf[362],t8,((C_word*)t0)[3]));}}
else{
t8=C_eqp(((C_word*)t0)[4],lf[364]);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11717,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t8)){
t10=t9;
f_11717(t10,t8);}
else{
t10=C_eqp(((C_word*)t0)[4],lf[415]);
if(C_truep(t10)){
t11=t9;
f_11717(t11,t10);}
else{
t11=C_eqp(((C_word*)t0)[4],lf[416]);
if(C_truep(t11)){
t12=t9;
f_11717(t12,t11);}
else{
t12=C_eqp(((C_word*)t0)[4],lf[417]);
if(C_truep(t12)){
t13=t9;
f_11717(t13,t12);}
else{
t13=C_eqp(((C_word*)t0)[4],lf[418]);
if(C_truep(t13)){
t14=t9;
f_11717(t14,t13);}
else{
t14=C_eqp(((C_word*)t0)[4],lf[419]);
if(C_truep(t14)){
t15=t9;
f_11717(t15,t14);}
else{
t15=C_eqp(((C_word*)t0)[4],lf[420]);
t16=t9;
f_11717(t16,(C_truep(t15)?t15:C_eqp(((C_word*)t0)[4],lf[421])));}}}}}}}}}}}}

/* k4672 in k4669 in k4666 */
static void C_ccall f_4674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4674,2,t0,t1);}
t2=C_mutate2((C_word*)lf[0]+1 /* (set! ##compiler#compiler-cleanup-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4678,tmp=(C_word)a,a+=2,tmp));
t3=C_set_block_item(lf[1] /* ##compiler#debugging-chicken */,0,C_SCHEME_END_OF_LIST);
t4=C_set_block_item(lf[2] /* ##compiler#disabled-warnings */,0,C_SCHEME_END_OF_LIST);
t5=C_mutate2((C_word*)lf[3]+1 /* (set! ##compiler#bomb ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4683,tmp=(C_word)a,a+=2,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4708,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:53: open-output-string */
t7=*((C_word*)lf[53]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* ##compiler#compiler-cleanup-hook in k4672 in k4669 in k4666 */
static void C_ccall f_4678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4678,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k11837 in k11810 in k11783 in k11757 in k11715 in k11592 in k11577 in repeat in a11547 in foreign-type-check in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_11839(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11839,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11842,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1075: gensym */
t3=*((C_word*)lf[110]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[377]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,2,lf[376],((C_word*)t0)[2]));}
else{
t3=C_eqp(((C_word*)t0)[4],lf[378]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11883,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_11883(t5,t3);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[398]);
if(C_truep(t5)){
t6=t4;
f_11883(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[399]);
t7=t4;
f_11883(t7,(C_truep(t6)?t6:C_eqp(((C_word*)t0)[4],lf[400])));}}}}}

/* k11426 in k11420 in k11417 in k11414 in k11411 in k11408 in k11402 in a11396 in print-program-statistics in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11431,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* support.scm:985: ##sys#print */
t3=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[8],C_SCHEME_TRUE,((C_word*)t0)[7]);}

/* k11420 in k11417 in k11414 in k11411 in k11408 in k11402 in a11396 in print-program-statistics in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11422,2,t0,t1);}
t2=*((C_word*)lf[13]+1);
t3=*((C_word*)lf[13]+1);
t4=C_i_check_port_2(*((C_word*)lf[13]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[14]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11428,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* support.scm:985: ##sys#print */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[337],C_SCHEME_FALSE,*((C_word*)lf[13]+1));}

/* k10361 in emit-global-inline-file in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10366,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[4])[1]))){
/* support.scm:799: delete-file* */
t3=*((C_word*)lf[297]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10426,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* support.scm:800: with-output-to-file */
t4=*((C_word*)lf[305]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[5],t3);}}

/* k10364 in k10361 in emit-global-inline-file in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10372,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[3])[1]))){
/* support.scm:811: debugging */
t3=*((C_word*)lf[11]+1);
f_4711(4,t3,t2,lf[295],lf[296]);}
else{
t3=t2;
f_10372(2,t3,C_SCHEME_FALSE);}}

/* k9541 in k9537 in k9511 in k9508 in a9505 in a9493 in inline-lambda-bindings in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:691: fold-right */
t2=*((C_word*)lf[281]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1,((C_word*)t0)[5]);}

/* k4695 in bomb in k4672 in k4669 in k4666 */
static void C_ccall f_4697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
C_apply(5,0,((C_word*)t0)[3],*((C_word*)lf[4]+1),t1,t3);}

/* k9537 in k9511 in k9508 in a9505 in a9493 in inline-lambda-bindings in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_9539(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9539,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9543,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* support.scm:704: take */
t4=*((C_word*)lf[282]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[5],((C_word*)t0)[6]);}

/* loop in k5380 in c-ify-string in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_5384(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5384,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[69]);}
else{
t3=C_i_car(t2);
t4=t3;
t5=C_fix(C_character_code(t4));
t6=t5;
t7=C_fixnum_lessp(t6,C_fix(32));
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5406,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t6,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t7)){
t9=t8;
f_5406(t9,t7);}
else{
t9=C_fixnum_greater_or_equal_p(t6,C_fix(127));
if(C_truep(t9)){
t10=t8;
f_5406(t10,t9);}
else{
t10=C_u_i_memq(t4,lf[75]);
t11=t8;
f_5406(t11,t10);}}}}

/* k5380 in c-ify-string in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5382,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5384,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_5384(t5,((C_word*)t0)[2],t1);}

/* ##compiler#bomb in k4672 in k4669 in k4666 */
static void C_ccall f_4683(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4683r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4683r(t0,t1,t2);}}

static void C_ccall f_4683r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4697,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=C_u_i_car(t4);
/* support.scm:49: string-append */
t6=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,lf[6],t5);}
else{
/* support.scm:50: error */
t3=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,lf[7]);}}

/* k14489 in k14483 in k14464 in walk in scan-free-variables in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14491,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14495,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1341: lset-adjoin */
t3=*((C_word*)lf[480]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[27]+1),((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[4]);}}

/* k14493 in k14489 in k14483 in k14464 in walk in scan-free-variables in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k11881 in k11837 in k11810 in k11783 in k11757 in k11715 in k11592 in k11577 in repeat in a11547 in foreign-type-check in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_11883(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11883,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11886,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1083: gensym */
t3=*((C_word*)lf[110]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[381]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11928,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_11928(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[396]);
t5=t3;
f_11928(t5,(C_truep(t4)?t4:C_eqp(((C_word*)t0)[4],lf[397])));}}}

/* k11884 in k11881 in k11837 in k11810 in k11783 in k11757 in k11715 in k11592 in k11577 in repeat in a11547 in foreign-type-check in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11886,2,t0,t1);}
t2=t1;
t3=C_a_i_list(&a,2,t2,((C_word*)t0)[2]);
t4=C_a_i_list(&a,1,t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11901,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[350]+1))){
t7=t6;
f_11901(t7,C_a_i_list(&a,2,lf[379],t2));}
else{
t7=C_a_i_list(&a,2,lf[380],t2);
t8=t6;
f_11901(t8,C_a_i_list(&a,2,lf[379],t7));}}

/* k13710 in foreign-type->scrutiny-type in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_13712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13712,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_eqp(t3,lf[438]);
if(C_truep(t4)){
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[195]);}
else{
t5=C_eqp(t3,lf[348]);
t6=(C_truep(t5)?t5:C_eqp(t3,lf[349]));
if(C_truep(t6)){
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,lf[348]);}
else{
t7=C_eqp(t3,lf[352]);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13736,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t7)){
t9=t8;
f_13736(t9,t7);}
else{
t9=C_eqp(t3,lf[424]);
if(C_truep(t9)){
t10=t8;
f_13736(t10,t9);}
else{
t10=C_eqp(t3,lf[425]);
if(C_truep(t10)){
t11=t8;
f_13736(t11,t10);}
else{
t11=C_eqp(t3,lf[426]);
if(C_truep(t11)){
t12=t8;
f_13736(t12,t11);}
else{
t12=C_eqp(t3,lf[427]);
if(C_truep(t12)){
t13=t8;
f_13736(t13,t12);}
else{
t13=C_eqp(t3,lf[428]);
if(C_truep(t13)){
t14=t8;
f_13736(t14,t13);}
else{
t14=C_eqp(t3,lf[429]);
t15=t8;
f_13736(t15,(C_truep(t14)?t14:C_eqp(t3,lf[430])));}}}}}}}}}

/* k10370 in k10364 in k10361 in emit-global-inline-file in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10372,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10380,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:812: sort-symbols */
t3=*((C_word*)lf[93]+1);
f_5672(3,t3,t2,((C_word*)((C_word*)t0)[3])[1]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k11715 in k11592 in k11577 in repeat in a11547 in foreign-type-check in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_11717(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11717,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11720,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1048: gensym */
t3=*((C_word*)lf[110]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[365]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11759,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_11759(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[408]);
if(C_truep(t4)){
t5=t3;
f_11759(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[5],lf[409]);
if(C_truep(t5)){
t6=t3;
f_11759(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[5],lf[410]);
if(C_truep(t6)){
t7=t3;
f_11759(t7,t6);}
else{
t7=C_eqp(((C_word*)t0)[5],lf[411]);
if(C_truep(t7)){
t8=t3;
f_11759(t8,t7);}
else{
t8=C_eqp(((C_word*)t0)[5],lf[412]);
if(C_truep(t8)){
t9=t3;
f_11759(t9,t8);}
else{
t9=C_eqp(((C_word*)t0)[5],lf[413]);
t10=t3;
f_11759(t10,(C_truep(t9)?t9:C_eqp(((C_word*)t0)[5],lf[414])));}}}}}}}}

/* loop in posv in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_5212(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5212,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=C_i_car(t2);
if(C_truep(C_i_eqvp(((C_word*)t0)[2],t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=t2;
t6=C_u_i_cdr(t5);
t7=C_a_i_plus(&a,2,t3,C_fix(1));
/* support.scm:159: loop */
t9=t1;
t10=t6;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}}

/* k10351 in map-loop2148 in walk in sexpr->node in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10353,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_10324(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_10324(t6,((C_word*)t0)[5],t5);}}

/* ##compiler#emit-global-inline-file in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10359(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10359,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10363,a[2]=t1,a[3]=t5,a[4]=t7,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10476,a[2]=t5,a[3]=t7,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:779: ##sys#hash-table-for-each */
t10=*((C_word*)lf[162]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,t9,t3);}

/* k6716 in k6713 in k6710 in k6707 in k6704 in a6695 in k6689 in display-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:496: newline */
t2=*((C_word*)lf[12]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k6713 in k6710 in k6707 in k6704 in a6695 in k6689 in display-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6718,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[3])[1]))){
t3=*((C_word*)lf[13]+1);
t4=*((C_word*)lf[13]+1);
t5=C_i_check_port_2(*((C_word*)lf[13]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[14]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6730,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:495: ##sys#print */
t7=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[164],C_SCHEME_FALSE,*((C_word*)lf[13]+1));}
else{
/* support.scm:496: newline */
t3=*((C_word*)lf[12]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}}

/* k6710 in k6707 in k6704 in a6695 in k6689 in display-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6712,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6715,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[4])[1]))){
t3=*((C_word*)lf[13]+1);
t4=*((C_word*)lf[13]+1);
t5=C_i_check_port_2(*((C_word*)lf[13]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[14]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6746,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:494: ##sys#print */
t7=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[165],C_SCHEME_FALSE,*((C_word*)lf[13]+1));}
else{
t3=t2;
f_6715(2,t3,C_SCHEME_UNDEFINED);}}

/* k9281 in k9208 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:670: cons* */
t2=*((C_word*)lf[268]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* map-loop1724 in k9208 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_9285(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9285,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9314,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:670: g1730 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6009 in tmp14292 in a6004 in a5973 in string->expr in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6011,2,t0,t1);}
if(C_truep(C_i_nullp(t1))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[115]);}
else{
t2=C_i_cdr(t1);
t3=C_i_nullp(t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_u_i_car(t1):C_a_i_cons(&a,2,lf[116],t1)));}}

/* for-each-loop2231 in k10378 in k10370 in k10364 in k10361 in emit-global-inline-file in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_10388(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10388,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10398,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:812: g2247 */
t5=*((C_word*)lf[293]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[294],t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10378 in k10370 in k10364 in k10361 in emit-global-inline-file in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10380,2,t0,t1);}
t2=C_i_check_list_2(t1,lf[34]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10388,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_10388(t6,((C_word*)t0)[2],t1);}

/* ##compiler#posv in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5206(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5206,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5212,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5212(t7,t1,t3,C_fix(0));}

/* k15121 in a15109 in a15103 in a15081 in k15178 in k15069 in constant-form-eval in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15123,2,t0,t1);}
t2=t1;
t3=C_i_length(t2);
t4=C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15132,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* support.scm:1482: debugging */
t6=*((C_word*)lf[11]+1);
f_4711(5,t6,t5,lf[259],lf[517],((C_word*)t0)[4]);}
else{
/* support.scm:1485: bomb */
t5=*((C_word*)lf[3]+1);
f_4683(4,t5,((C_word*)t0)[3],lf[518],((C_word*)t0)[4]);}}

/* k11757 in k11715 in k11592 in k11577 in repeat in a11547 in foreign-type-check in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_11759(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11759,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(*((C_word*)lf[350]+1))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[4];
t3=C_u_i_assq(t2,lf[366]);
t4=C_slot(t3,C_fix(1));
t5=C_a_i_list(&a,2,lf[97],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_list(&a,3,lf[362],t5,((C_word*)t0)[3]));}}
else{
t2=C_eqp(((C_word*)t0)[5],lf[367]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11785,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_11785(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[405]);
if(C_truep(t4)){
t5=t3;
f_11785(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[5],lf[406]);
t6=t3;
f_11785(t6,(C_truep(t5)?t5:C_eqp(((C_word*)t0)[5],lf[407])));}}}}

/* k15130 in k15121 in a15109 in a15103 in a15081 in k15178 in k15069 in constant-form-eval in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_car(((C_word*)t0)[2]);
/* support.scm:1483: k */
t3=((C_word*)t0)[3];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[4],C_SCHEME_TRUE,((C_word*)t0)[5],t2,C_SCHEME_FALSE);}

/* k4666 */
static void C_ccall f_4668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4668,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4671,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* ##compiler#c-ify-string in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5366(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5366,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5378,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5382,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* string->list */
t5=*((C_word*)lf[72]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k11456 in k11453 in k11450 in k11444 in k11441 in k11438 in k11432 in k11429 in k11426 in k11420 in k11417 in k11414 in k11411 in k11408 in k11402 in a11396 in print-program-statistics in k7340 in k5962 in k5959 in k4706 in k4672 in ... */
static void C_ccall f_11458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11458,2,t0,t1);}
t2=*((C_word*)lf[13]+1);
t3=*((C_word*)lf[13]+1);
t4=C_i_check_port_2(*((C_word*)lf[13]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[14]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11464,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* support.scm:988: ##sys#print */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[334],C_SCHEME_FALSE,*((C_word*)lf[13]+1));}

/* k11453 in k11450 in k11444 in k11441 in k11438 in k11432 in k11429 in k11426 in k11420 in k11417 in k11414 in k11411 in k11408 in k11402 in a11396 in print-program-statistics in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in ... */
static void C_ccall f_11455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11458,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:987: ##sys#write-char-0 */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[5]);}

/* k11733 in k11718 in k11715 in k11592 in k11577 in repeat in a11547 in foreign-type-check in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_11735(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11735,NULL,2,t0,t1);}
t2=C_a_i_list(&a,2,lf[97],C_SCHEME_FALSE);
t3=C_a_i_list(&a,4,lf[225],((C_word*)t0)[2],t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,3,lf[109],((C_word*)t0)[4],t3));}

/* ##compiler#close-checked-input-file in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5573(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5573,4,t0,t1,t2,t3);}
if(C_truep(C_i_string_equal_p(t3,lf[88]))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
/* support.scm:226: close-input-port */
t4=*((C_word*)lf[89]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}}

/* a15148 in a15109 in a15103 in a15081 in k15178 in k15069 in constant-form-eval in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15149,2,t0,t1);}
C_apply(4,0,t1,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k8414 in k8407 in k8400 in a8342 in k8211 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8416,2,t0,t1);}
t2=((C_word*)t0)[2];
f_8406(2,t2,C_a_i_list2(&a,2,((C_word*)t0)[3],t1));}

/* k11450 in k11444 in k11441 in k11438 in k11432 in k11429 in k11426 in k11420 in k11417 in k11414 in k11411 in k11408 in k11402 in a11396 in print-program-statistics in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 in ... */
static void C_ccall f_11452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11455,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm:987: ##sys#print */
t3=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[5]);}

/* k9254 in map-loop1695 in k9215 in k9208 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9256,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9227(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9227(t6,((C_word*)t0)[5],t5);}}

/* k11444 in k11441 in k11438 in k11432 in k11429 in k11426 in k11420 in k11417 in k11414 in k11411 in k11408 in k11402 in a11396 in print-program-statistics in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11446,2,t0,t1);}
t2=*((C_word*)lf[13]+1);
t3=*((C_word*)lf[13]+1);
t4=C_i_check_port_2(*((C_word*)lf[13]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[14]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11452,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* support.scm:987: ##sys#print */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[335],C_SCHEME_FALSE,*((C_word*)lf[13]+1));}

/* k11441 in k11438 in k11432 in k11429 in k11426 in k11420 in k11417 in k11414 in k11411 in k11408 in k11402 in a11396 in print-program-statistics in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11446,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm:986: ##sys#write-char-0 */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[6]);}

/* map-loop1652 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_9101(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9101,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9130,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:660: g1658 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* ##compiler#fold-inner in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5585(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5585,4,t0,t1,t2,t3);}
t4=C_i_cdr(t3);
if(C_truep(C_i_nullp(t4))){
t5=t3;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5599,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:231: reverse */
t6=*((C_word*)lf[91]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}}

/* k11718 in k11715 in k11592 in k11577 in repeat in a11547 in foreign-type-check in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11720,2,t0,t1);}
t2=t1;
t3=C_a_i_list(&a,2,t2,((C_word*)t0)[2]);
t4=C_a_i_list(&a,1,t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11735,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[350]+1))){
t7=t6;
f_11735(t7,t2);}
else{
t7=C_a_i_list(&a,2,lf[97],((C_word*)t0)[4]);
t8=t6;
f_11735(t8,C_a_i_list(&a,3,lf[362],t7,t2));}}

/* k12044 in k12006 in k11969 in k11926 in k11881 in k11837 in k11810 in k11783 in k11757 in k11715 in k11592 in k11577 in repeat in a11547 in foreign-type-check in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 in ... */
static void C_ccall f_12046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12046,2,t0,t1);}
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=C_a_i_list(&a,2,lf[97],lf[387]);
t5=C_a_i_list(&a,3,lf[388],((C_word*)t0)[2],t4);
t6=C_a_i_list(&a,2,lf[97],C_SCHEME_FALSE);
t7=C_a_i_list(&a,4,lf[225],t1,t5,t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_list(&a,3,lf[109],t3,t7));}

/* a15157 in a15103 in a15081 in k15178 in k15069 in constant-form-eval in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15158(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_15158r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_15158r(t0,t1,t2);}}

static void C_ccall f_15158r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15164,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1471: k3674 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* loop in canonicalize-begin-body in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_5892(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5892,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[107]);}
else{
t3=C_i_cdr(t2);
if(C_truep(C_i_nullp(t3))){
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_u_i_car(t4));}
else{
t4=t2;
t5=C_u_i_car(t4);
t6=C_i_equalp(t5,lf[108]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5916,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t6)){
t8=t7;
f_5916(t8,t6);}
else{
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5947,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* support.scm:294: constant? */
t9=*((C_word*)lf[96]+1);
f_5692(3,t9,t8,t5);}}}}

/* k11438 in k11432 in k11429 in k11426 in k11420 in k11417 in k11414 in k11411 in k11408 in k11402 in a11396 in print-program-statistics in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11443,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm:986: ##sys#print */
t3=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[7],C_SCHEME_TRUE,((C_word*)t0)[6]);}

/* k11477 in k11474 in k11468 in k11465 in k11462 in k11456 in k11453 in k11450 in k11444 in k11441 in k11438 in k11432 in k11429 in k11426 in k11420 in k11417 in k11414 in k11411 in k11408 in k11402 in a11396 in print-program-statistics in ... */
static void C_ccall f_11479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:989: ##sys#write-char-0 */
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(10),((C_word*)t0)[3]);}

/* k11474 in k11468 in k11465 in k11462 in k11456 in k11453 in k11450 in k11444 in k11441 in k11438 in k11432 in k11429 in k11426 in k11420 in k11417 in k11414 in k11411 in k11408 in k11402 in a11396 in print-program-statistics in k7340 in ... */
static void C_ccall f_11476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11476,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11479,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:989: ##sys#print */
t3=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],C_SCHEME_TRUE,((C_word*)t0)[3]);}

/* k11468 in k11465 in k11462 in k11456 in k11453 in k11450 in k11444 in k11441 in k11438 in k11432 in k11429 in k11426 in k11420 in k11417 in k11414 in k11411 in k11408 in k11402 in a11396 in print-program-statistics in k7340 in k5962 in ... */
static void C_ccall f_11470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11470,2,t0,t1);}
t2=*((C_word*)lf[13]+1);
t3=*((C_word*)lf[13]+1);
t4=C_i_check_port_2(*((C_word*)lf[13]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[14]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11476,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm:989: ##sys#print */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[333],C_SCHEME_FALSE,*((C_word*)lf[13]+1));}

/* k4997 in for-each-loop169 in k4968 in k4965 in syntax-error-hook in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4989(t3,((C_word*)t0)[4],t2);}

/* k5597 in fold-inner in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5599,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5601,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5601(t5,((C_word*)t0)[3],t1);}

/* a14559 in k14464 in walk in scan-free-variables in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14560(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_14560,5,t0,t1,t2,t3,t4);}
t5=C_i_car(((C_word*)t0)[2]);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14572,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1353: append */
t8=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t2,((C_word*)t0)[4]);}

/* k11465 in k11462 in k11456 in k11453 in k11450 in k11444 in k11441 in k11438 in k11432 in k11429 in k11426 in k11420 in k11417 in k11414 in k11411 in k11408 in k11402 in a11396 in print-program-statistics in k7340 in k5962 in k5959 in ... */
static void C_ccall f_11467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11467,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11470,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:988: ##sys#write-char-0 */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[4]);}

/* k11462 in k11456 in k11453 in k11450 in k11444 in k11441 in k11438 in k11432 in k11429 in k11426 in k11420 in k11417 in k11414 in k11411 in k11408 in k11402 in a11396 in print-program-statistics in k7340 in k5962 in k5959 in k4706 in ... */
static void C_ccall f_11464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11464,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11467,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:988: ##sys#print */
t3=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4]);}

/* k9591 in k9511 in k9508 in a9505 in a9493 in inline-lambda-bindings in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9593,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
if(C_truep(C_i_nullp(((C_word*)t0)[2]))){
t3=C_a_i_list1(&a,1,C_SCHEME_END_OF_LIST);
t4=C_a_i_record4(&a,4,lf[211],lf[97],t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_list2(&a,2,t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[4];
f_9539(t6,C_a_i_record4(&a,4,lf[211],lf[109],t2,t5));}
else{
t3=C_i_length(((C_word*)t0)[2]);
t4=C_a_i_times(&a,2,C_fix(3),t3);
t5=C_a_i_list2(&a,2,lf[283],t4);
t6=((C_word*)t0)[2];
t7=C_a_i_record4(&a,4,lf[211],lf[249],t5,t6);
t8=C_a_i_list2(&a,2,t7,((C_word*)t0)[3]);
t9=((C_word*)t0)[4];
f_9539(t9,C_a_i_record4(&a,4,lf[211],lf[109],t2,t8));}}

/* k4982 in k4979 in k4968 in k4965 in syntax-error-hook in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:122: exit */
t2=*((C_word*)lf[30]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(70));}

/* for-each-loop169 in k4968 in k4965 in syntax-error-hook in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_4989(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4989,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4999,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:120: g170 */
t5=((C_word*)t0)[3];
f_4971(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4979 in k4968 in k4965 in syntax-error-hook in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4984,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:121: print-call-chain */
t3=*((C_word*)lf[35]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[3],C_fix(0),*((C_word*)lf[36]+1),lf[37]);}

/* k7833 in k7853 in loop in k7890 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7835,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record4(&a,4,lf[211],lf[236],((C_word*)t0)[3],t1));}

/* k12009 in k12006 in k11969 in k11926 in k11881 in k11837 in k11810 in k11783 in k11757 in k11715 in k11592 in k11577 in repeat in a11547 in foreign-type-check in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 in ... */
static void C_ccall f_12011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12011,2,t0,t1);}
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=C_a_i_list(&a,2,lf[376],t1);
t5=C_a_i_list(&a,2,lf[97],C_SCHEME_FALSE);
t6=C_a_i_list(&a,4,lf[225],t1,t4,t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_list(&a,3,lf[109],t3,t6));}

/* k11414 in k11411 in k11408 in k11402 in a11396 in print-program-statistics in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11419,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* support.scm:984: ##sys#print */
t3=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[9],C_SCHEME_TRUE,((C_word*)t0)[8]);}

/* k6174 in initialize-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k11417 in k11414 in k11411 in k11408 in k11402 in a11396 in print-program-statistics in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11422,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* support.scm:984: ##sys#write-char-0 */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[8]);}

/* ##compiler#canonicalize-begin-body in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5886(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5886,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5892,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_5892(t6,t1,t2);}

/* k11411 in k11408 in k11402 in a11396 in print-program-statistics in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11413,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11416,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* support.scm:984: ##sys#print */
t3=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[338],C_SCHEME_FALSE,((C_word*)t0)[8]);}

/* ##compiler#initialize-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6172,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6176,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=*((C_word*)lf[138]+1);
t4=C_i_check_list_2(*((C_word*)lf[138]+1),lf[34]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6225,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6346,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_6346(t9,t5,*((C_word*)lf[138]+1));}
else{
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g170 in k4968 in k4965 in syntax-error-hook in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_4971(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4971,NULL,3,t0,t1,t2);}
/* support.scm:120: g185 */
t3=*((C_word*)lf[21]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,((C_word*)t0)[2],lf[33],t2);}

/* k11408 in k11402 in a11396 in print-program-statistics in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11413,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* support.scm:984: ##sys#print */
t3=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[10],C_SCHEME_TRUE,((C_word*)t0)[8]);}

/* k4968 in k4965 in syntax-error-hook in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4971,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
t4=C_i_check_list_2(t3,lf[34]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4981,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4989,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_4989(t9,t5,t3);}

/* k5882 in k5844 in basic-literal? in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:280: every */
t2=*((C_word*)lf[104]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[103]+1),t1);}

/* k14539 in k14528 in k14464 in walk in scan-free-variables in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1348: walk */
t2=((C_word*)((C_word*)t0)[2])[1];
f_14432(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k11402 in a11396 in print-program-statistics in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11404,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[13]+1);
t3=*((C_word*)lf[13]+1);
t4=C_i_check_port_2(*((C_word*)lf[13]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[14]);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11410,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* support.scm:984: ##sys#print */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[339],C_SCHEME_FALSE,*((C_word*)lf[13]+1));}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k5540 in check-and-open-input-file in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5542,2,t0,t1);}
if(C_truep(t1)){
/* support.scm:221: open-input-file */
t2=*((C_word*)lf[83]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t2=C_i_nullp(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5554,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_5554(t4,t2);}
else{
t4=C_i_car(((C_word*)t0)[4]);
t5=t3;
f_5554(t5,C_i_not(t4));}}}

/* k12006 in k11969 in k11926 in k11881 in k11837 in k11810 in k11783 in k11757 in k11715 in k11592 in k11577 in repeat in a11547 in foreign-type-check in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_12008(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12008,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12011,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1105: gensym */
t3=*((C_word*)lf[110]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[385]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[4],lf[386]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12046,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1111: gensym */
t5=*((C_word*)lf[110]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[389]);
if(C_truep(t4)){
t5=C_a_i_list(&a,2,lf[97],lf[387]);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_list(&a,3,lf[388],((C_word*)t0)[2],t5));}
else{
t5=C_eqp(((C_word*)t0)[4],lf[390]);
if(C_truep(t5)){
t6=C_i_cadr(((C_word*)t0)[5]);
/* support.scm:1118: repeat */
t7=((C_word*)((C_word*)t0)[6])[1];
f_11554(t7,((C_word*)t0)[3],t6);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[391]);
if(C_truep(t6)){
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(*((C_word*)lf[350]+1))?((C_word*)t0)[2]:C_a_i_list(&a,2,lf[368],((C_word*)t0)[2])));}
else{
t7=C_eqp(((C_word*)t0)[4],lf[392]);
if(C_truep(t7)){
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_truep(t7)?C_a_i_list(&a,2,lf[376],((C_word*)t0)[2]):((C_word*)t0)[2]));}
else{
t8=C_eqp(((C_word*)t0)[4],lf[377]);
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_truep(t8)?C_a_i_list(&a,2,lf[376],((C_word*)t0)[2]):((C_word*)t0)[2]));}}}}}}}

/* ##sys#syntax-error-hook in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4963(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_4963r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4963r(t0,t1,t2,t3);}}

static void C_ccall f_4963r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(10);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t6=*((C_word*)lf[29]+1);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4967,a[2]=t6,a[3]=t5,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_symbolp(((C_word*)t4)[1]))){
t8=((C_word*)t4)[1];
t9=C_i_car(((C_word*)t5)[1]);
t10=C_set_block_item(t4,0,t9);
t11=C_i_cdr(((C_word*)t5)[1]);
t12=C_set_block_item(t5,0,t11);
t13=t7;
f_4967(t13,t8);}
else{
t8=t7;
f_4967(t8,C_SCHEME_FALSE);}}

/* k4965 in syntax-error-hook in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_4967(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4967,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4970,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=((C_word*)t0)[2];
t5=C_i_check_port_2(t4,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[21]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5016,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* support.scm:118: ##sys#print */
t7=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[39],C_SCHEME_FALSE,t4);}
else{
t4=((C_word*)t0)[2];
t5=C_i_check_port_2(t4,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[21]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5037,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm:119: ##sys#print */
t7=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[40],C_SCHEME_FALSE,t4);}}

/* k4959 in quit in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_4961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[2],*((C_word*)lf[21]+1),((C_word*)t0)[3],t1,((C_word*)t0)[4]);}

/* k9128 in map-loop1652 in k8616 in walk in build-expression-tree in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9130,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9101(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9101(t6,((C_word*)t0)[5],t5);}}

/* k5552 in k5540 in check-and-open-input-file in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_5554(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* support.scm:222: quit */
t2=*((C_word*)lf[28]+1);
f_4947(4,t2,((C_word*)t0)[2],lf[84],((C_word*)t0)[3]);}
else{
t2=C_i_car(((C_word*)t0)[4]);
/* support.scm:223: quit */
t3=*((C_word*)lf[28]+1);
f_4947(5,t3,((C_word*)t0)[2],lf[85],t2,((C_word*)t0)[3]);}}

/* k14519 in k14464 in walk in scan-free-variables in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_i_car(((C_word*)t0)[3]);
/* support.scm:1345: walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_14432(t4,((C_word*)t0)[5],t3,((C_word*)t0)[6]);}

/* k14570 in a14559 in k14464 in walk in scan-free-variables in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1353: walk */
t2=((C_word*)((C_word*)t0)[2])[1];
f_14432(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* ##compiler#big-fixnum? in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15554(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_15554,3,t0,t1,t2);}
if(C_truep(C_fixnump(t2))){
if(C_truep(C_fudge(C_fix(3)))){
t3=C_fixnum_greaterp(t2,C_fix(1073741823));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:C_fixnum_lessp(t2,C_fix(-1073741824))));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k5724 in constant? in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5726,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_i_vectorp(((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5738,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:258: ##sys#srfi-4-vector? */
t4=*((C_word*)lf[98]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}}}

/* k6194 in for-each-loop535 in initialize-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6196,2,t0,t1);}
if(C_truep(C_i_memq(((C_word*)t0)[2],*((C_word*)lf[144]+1)))){
t2=C_a_i_list(&a,1,C_SCHEME_TRUE);
if(C_truep(C_i_nullp(t2))){
/* tweaks.scm:54: ##sys#put! */
t3=*((C_word*)lf[142]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],lf[145],C_SCHEME_TRUE);}
else{
t3=C_i_car(t2);
/* tweaks.scm:54: ##sys#put! */
t4=*((C_word*)lf[142]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[145],t3);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k5736 in k5724 in constant? in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[3];
t3=C_u_i_car(t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_eqp(lf[97],t3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* ##compiler#hide-variable in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15578(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_15578,3,t0,t1,t2);}
t3=C_a_i_list(&a,1,lf[535]);
if(C_truep(C_i_nullp(t3))){
/* tweaks.scm:54: ##sys#put! */
t4=*((C_word*)lf[142]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,t2,lf[536],C_SCHEME_TRUE);}
else{
t4=C_i_car(t3);
/* tweaks.scm:54: ##sys#put! */
t5=*((C_word*)lf[142]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,lf[536],t4);}}

/* k8400 in a8342 in k8211 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_8402(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8402,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8406,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[5])){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8409,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* support.scm:609: real-name */
t5=*((C_word*)lf[46]+1);
f_14805(3,t5,t4,((C_word*)t0)[6]);}
else{
/* support.scm:612: ##sys#symbol->qualified-string */
t4=*((C_word*)lf[252]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[6]);}}

/* k8404 in k8400 in a8342 in k8211 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8406,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)((C_word*)t0)[3])[1];
t9=((C_word*)t0)[4];
t10=C_i_check_list_2(t9,lf[161]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8363,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8365,a[2]=t7,a[3]=t13,a[4]=t5,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_8365(t15,t11,t9);}

/* k8407 in k8400 in a8342 in k8211 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8409,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8416,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t1;
t4=((C_word*)t0)[2];
f_8406(2,t4,C_a_i_list2(&a,2,((C_word*)t0)[3],t3));}
else{
/* support.scm:611: ##sys#symbol->qualified-string */
t3=*((C_word*)lf[252]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}}

/* k14528 in k14464 in walk in scan-free-variables in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_14530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14530,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14541,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1348: append */
t5=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[5],((C_word*)t0)[6]);}

/* ##compiler#collapsable-literal? in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5754(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5754,3,t0,t1,t2);}
t3=C_booleanp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=C_eofp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=C_i_numberp(t2);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:C_i_symbolp(t2)));}}}}

/* k15512 in k15494 in loop in k15485 in scan-sharp-greater-string in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1546: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_15492(t2,((C_word*)t0)[3]);}

/* k11810 in k11783 in k11757 in k11715 in k11592 in k11577 in repeat in a11547 in foreign-type-check in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_11812(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11812,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(*((C_word*)lf[350]+1))){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,2,lf[372],((C_word*)t0)[2]));}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[373]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(*((C_word*)lf[350]+1))?((C_word*)t0)[2]:C_a_i_list(&a,2,lf[374],((C_word*)t0)[2])));}
else{
t3=C_eqp(((C_word*)t0)[4],lf[375]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11839,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_11839(t5,t3);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[401]);
t6=t4;
f_11839(t6,(C_truep(t5)?t5:C_eqp(((C_word*)t0)[4],lf[402])));}}}}

/* k15524 in k15494 in loop in k15485 in scan-sharp-greater-string in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15526,2,t0,t1);}
t2=t1;
t3=C_eqp(C_make_character(35),t2);
if(C_truep(t3)){
/* support.scm:1550: get-output-string */
t4=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15538,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t5=*((C_word*)lf[522]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_make_character(60),((C_word*)t0)[3]);}}

/* k15539 in k15536 in k15524 in k15494 in loop in k15485 in scan-sharp-greater-string in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1554: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_15492(t2,((C_word*)t0)[3]);}

/* k11840 in k11837 in k11810 in k11783 in k11757 in k11715 in k11592 in k11577 in repeat in a11547 in foreign-type-check in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_11842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11842,2,t0,t1);}
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=C_a_i_list(&a,2,lf[376],t1);
t5=C_a_i_list(&a,2,lf[97],C_SCHEME_FALSE);
t6=C_a_i_list(&a,4,lf[225],t1,t4,t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_list(&a,3,lf[109],t3,t6));}

/* k15536 in k15524 in k15494 in loop in k15485 in scan-sharp-greater-string in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15538,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15541,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=*((C_word*)lf[522]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k15547 in k15494 in loop in k15485 in scan-sharp-greater-string in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1557: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_15492(t2,((C_word*)t0)[3]);}

/* k6371 in get in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_i_assq(((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k11783 in k11757 in k11715 in k11592 in k11577 in repeat in a11547 in foreign-type-check in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_11785(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11785,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(*((C_word*)lf[350]+1))){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,2,lf[368],((C_word*)t0)[2]));}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[369]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(*((C_word*)lf[350]+1))?((C_word*)t0)[2]:C_a_i_list(&a,2,lf[370],((C_word*)t0)[2])));}
else{
t3=C_eqp(((C_word*)t0)[4],lf[371]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11812,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_11812(t5,t3);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[403]);
t6=t4;
f_11812(t6,(C_truep(t5)?t5:C_eqp(((C_word*)t0)[4],lf[404])));}}}}

/* k6354 in for-each-loop535 in initialize-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6346(t3,((C_word*)t0)[4],t2);}

/* ##compiler#get in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6369(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6369,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6373,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:374: ##sys#hash-table-ref */
t6=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,t3);}

/* for-each-loop535 in initialize-analysis-database in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_6346(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6346,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6356,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6196,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=C_a_i_list(&a,1,lf[147]);
if(C_truep(C_i_nullp(t8))){
/* tweaks.scm:54: ##sys#put! */
t9=*((C_word*)lf[142]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t7,t6,lf[143],C_SCHEME_TRUE);}
else{
t9=C_i_car(t8);
/* tweaks.scm:54: ##sys#put! */
t10=*((C_word*)lf[142]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t7,t6,lf[143],t9);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* ##compiler#valid-c-identifier? in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5463(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5463,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5467,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5513,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm:201: ->string */
t5=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5465 in valid-c-identifier? in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5467,2,t0,t1);}
if(C_truep(C_i_pairp(t1))){
t2=C_u_i_car(t1);
t3=C_u_i_char_alphabeticp(t2);
t4=(C_truep(t3)?t3:C_i_char_equalp(C_make_character(95),t2));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5488,tmp=(C_word)a,a+=2,tmp);
t6=C_u_i_cdr(t1);
/* support.scm:205: any */
t7=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[2],t5,t6);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k9631 in map-loop1801 in a9505 in a9493 in inline-lambda-bindings in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9633,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9604(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9604(t6,((C_word*)t0)[5],t5);}}

/* ##compiler#copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9639(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_9639,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_i_check_list_2(t3,lf[161]);
t12=C_i_check_list_2(t4,lf[161]);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9649,a[2]=t6,a[3]=t5,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10088,a[2]=t10,a[3]=t15,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t17=((C_word*)t15)[1];
f_10088(t17,t13,t3,t4);}

/* a6398 in k6389 in get-all in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6399(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6399,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_assq(t2,((C_word*)t0)[2]));}

/* k6389 in get-all in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6391,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6399,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:382: filter-map */
t4=*((C_word*)lf[151]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t3,((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}}

/* k5445 in k5404 in loop in k5380 in c-ify-string in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5447,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k10584 in k10505 in k10617 in k10481 in a10475 in emit-global-inline-file in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10586,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10541,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[3];
/* tweaks.scm:57: ##sys#get */
t4=*((C_word*)lf[253]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,lf[309]);}}

/* k8392 in map-loop1397 in k8404 in k8400 in a8342 in k8211 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8394,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8365(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8365(t6,((C_word*)t0)[5],t5);}}

/* k9943 in map-loop1964 in k9836 in a9822 in walk in k9647 in copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_9945(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[6])[1];
f_9932(t5,((C_word*)t0)[7],t3,t4);}

/* ##compiler#get-all in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_6387(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_6387r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6387r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6387r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6391,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm:380: ##sys#hash-table-ref */
t6=*((C_word*)lf[149]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,t3);}

/* k10558 in k10542 in k10539 in k10584 in k10505 in k10617 in k10481 in a10475 in emit-global-inline-file in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_10560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10560,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k5320 in uncommentify in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:173: string-translate* */
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[63]);}

/* ##compiler#build-lambda-list in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5324(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5324,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5330,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_5330(t8,t1,t2,t3);}

/* k9928 in k9836 in a9822 in walk in k9647 in copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:744: append */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* map-loop1964 in k9836 in a9822 in walk in k9647 in copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_9932(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9932,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_cons(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=t9;
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9945,a[2]=((C_word*)t0)[2],a[3]=t10,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t12=t11;
f_9945(t12,C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t10));}
else{
t12=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t10);
t13=t11;
f_9945(t13,t12);}}
else{
t6=((C_word*)((C_word*)t0)[4])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* a9505 in a9493 in inline-lambda-bindings in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9506(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9506,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9510,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[4])){
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=*((C_word*)lf[110]+1);
t10=((C_word*)t0)[6];
t11=C_i_check_list_2(t10,lf[161]);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9604,a[2]=t8,a[3]=t13,a[4]=t6,a[5]=t9,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_9604(t15,t4,t10);}
else{
t5=t4;
f_9510(2,t5,((C_word*)t0)[6]);}}

/* a9499 in a9493 in inline-lambda-bindings in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9500,2,t0,t1);}
/* support.scm:686: split-at */
t2=*((C_word*)lf[280]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* a8342 in k8211 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8343(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8343,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8402,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8430,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=t2;
/* tweaks.scm:57: ##sys#get */
t7=*((C_word*)lf[253]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,lf[254]);}

/* a15109 in a15103 in a15081 in k15178 in k15069 in constant-form-eval in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15110,2,t0,t1);}
t2=C_slot(((C_word*)t0)[2],C_fix(0));
t3=t2;
if(C_truep(C_i_closurep(t3))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15123,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15149,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1480: ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,*((C_word*)lf[519]+1));}
else{
/* support.scm:1486: bomb */
t4=*((C_word*)lf[3]+1);
f_4683(4,t4,t1,lf[520],((C_word*)t0)[4]);}}

/* k7576 in k7572 in k7569 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7578,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record4(&a,4,lf[211],lf[109],((C_word*)t0)[3],t1));}

/* a5487 in k5465 in valid-c-identifier? in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5488(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5488,3,t0,t1,t2);}
t3=C_u_i_char_alphabeticp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=C_u_i_char_numericp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:C_i_char_equalp(C_make_character(95),t2)));}}

/* walk in k9647 in copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_9657(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9657,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=C_slot(t4,C_fix(3));
t6=t5;
t7=t2;
t8=C_slot(t7,C_fix(2));
t9=t8;
t10=t2;
t11=C_slot(t10,C_fix(1));
t12=t11;
t13=C_eqp(t12,lf[97]);
if(C_truep(t13)){
t14=t1;
t15=t14;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_a_i_record4(&a,4,lf[211],t12,t9,C_SCHEME_END_OF_LIST));}
else{
t14=C_eqp(t12,lf[221]);
if(C_truep(t14)){
t15=C_i_car(t9);
t16=t15;
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9708,a[2]=t1,a[3]=t3,a[4]=t16,tmp=(C_word)a,a+=5,tmp);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9718,a[2]=((C_word*)t0)[2],a[3]=t17,a[4]=t16,tmp=(C_word)a,a+=5,tmp);
/* support.scm:719: get */
t19=*((C_word*)lf[148]+1);
f_6369(5,t19,t18,((C_word*)t0)[3],t16,lf[190]);}
else{
t15=C_eqp(t12,lf[244]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9755,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t17=C_i_car(t9);
t18=t3;
/* support.scm:709: alist-ref */
t19=*((C_word*)lf[285]+1);
((C_proc6)(void*)(*((C_word*)t19+1)))(6,t19,t16,t17,t18,*((C_word*)lf[27]+1),t17);}
else{
t16=C_eqp(t12,lf[109]);
if(C_truep(t16)){
t17=C_i_car(t9);
t18=t17;
t19=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9771,a[2]=t18,a[3]=t3,a[4]=t1,a[5]=t6,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t20=C_i_car(t6);
/* support.scm:728: walk */
t34=t19;
t35=t20;
t36=t3;
t1=t34;
t2=t35;
t3=t36;
goto loop;}
else{
t17=C_eqp(t12,lf[133]);
if(C_truep(t17)){
t18=C_i_caddr(t9);
t19=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9823,a[2]=((C_word*)t0)[3],a[3]=t9,a[4]=((C_word*)t0)[4],a[5]=t6,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm:736: decompose-lambda-list */
t20=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t1,t18,t19);}
else{
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10026,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t6,a[5]=t1,a[6]=t12,tmp=(C_word)a,a+=7,tmp);
/* support.scm:751: tree-copy */
t19=*((C_word*)lf[288]+1);
f_10137(3,t19,t18,t9);}}}}}}

/* a15103 in a15081 in k15178 in k15069 in constant-form-eval in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15104,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15110,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15158,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1471: ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* k15100 in a15093 in a15087 in a15081 in k15178 in k15069 in constant-form-eval in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_15102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1476: k */
t2=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[4],C_SCHEME_FALSE,t1);}

/* k7595 in k7572 in k7569 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_7597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7597,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7605,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:551: walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7383(3,t4,t3,((C_word*)t0)[4]);}

/* ##compiler#uncommentify in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5314(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5314,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5322,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:173: ->string */
t4=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k9647 in copy-node-tree-and-rename in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_9649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9649,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9657,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
/* support.scm:752: walk */
t5=((C_word*)t3)[1];
f_9657(t5,((C_word*)t0)[4],((C_word*)t0)[5],t1);}

/* k5310 in slashify in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:171: string-translate */
t2=*((C_word*)lf[57]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,lf[58],lf[59]);}

/* loop in build-lambda-list in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_5330(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5330,NULL,4,t0,t1,t2,t3);}
t4=C_i_zerop(t3);
t5=(C_truep(t4)?t4:C_i_nullp(t2));
if(C_truep(t5)){
t6=((C_word*)t0)[2];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:C_SCHEME_END_OF_LIST));}
else{
t6=C_i_car(t2);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5354,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=t2;
t10=C_u_i_cdr(t9);
t11=C_a_i_minus(&a,2,t3,C_fix(1));
/* support.scm:178: loop */
t14=t8;
t15=t10;
t16=t11;
t1=t14;
t2=t15;
t3=t16;
goto loop;}}

/* ##compiler#slashify in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5304(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5304,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5312,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:171: ->string */
t4=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k5300 in k5297 in k5291 in symbolify in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_5302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:169: string->symbol */
t2=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* map-loop1351 in k8211 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_fcall f_8299(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8299,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8328,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:599: g1357 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8295 in k8211 in walk in build-node-graph in k7340 in k5962 in k5959 in k4706 in k4672 in k4669 in k4666 */
static void C_ccall f_8297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8297,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record4(&a,4,lf[211],lf[251],((C_word*)t0)[3],t1));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[751] = {
{"f_13811:support_2escm",(void*)f_13811},
{"f_8267:support_2escm",(void*)f_8267},
{"f_8363:support_2escm",(void*)f_8363},
{"f_8365:support_2escm",(void*)f_8365},
{"f_9363:support_2escm",(void*)f_9363},
{"f_15164:support_2escm",(void*)f_15164},
{"f_7296:support_2escm",(void*)f_7296},
{"f_15182:support_2escm",(void*)f_15182},
{"f_15180:support_2escm",(void*)f_15180},
{"f_15798:support_2escm",(void*)f_15798},
{"f_9227:support_2escm",(void*)f_9227},
{"f_9225:support_2escm",(void*)f_9225},
{"f_15791:support_2escm",(void*)f_15791},
{"f_12497:support_2escm",(void*)f_12497},
{"f_7281:support_2escm",(void*)f_7281},
{"f_7287:support_2escm",(void*)f_7287},
{"f_9217:support_2escm",(void*)f_9217},
{"f_9210:support_2escm",(void*)f_9210},
{"f_15013:support_2escm",(void*)f_15013},
{"f_4891:support_2escm",(void*)f_4891},
{"f_5994:support_2escm",(void*)f_5994},
{"f_5997:support_2escm",(void*)f_5997},
{"f_12478:support_2escm",(void*)f_12478},
{"f_13886:support_2escm",(void*)f_13886},
{"f_12484:support_2escm",(void*)f_12484},
{"f_7273:support_2escm",(void*)f_7273},
{"f_8878:support_2escm",(void*)f_8878},
{"f_7275:support_2escm",(void*)f_7275},
{"f_7892:support_2escm",(void*)f_7892},
{"f_4929:support_2escm",(void*)f_4929},
{"f_4917:support_2escm",(void*)f_4917},
{"f_4914:support_2escm",(void*)f_4914},
{"f_5828:support_2escm",(void*)f_5828},
{"f_8849:support_2escm",(void*)f_8849},
{"f_7580:support_2escm",(void*)f_7580},
{"f_7880:support_2escm",(void*)f_7880},
{"f_5969:support_2escm",(void*)f_5969},
{"f_5961:support_2escm",(void*)f_5961},
{"f_9513:support_2escm",(void*)f_9513},
{"f_5965:support_2escm",(void*)f_5965},
{"f_5964:support_2escm",(void*)f_5964},
{"f_9518:support_2escm",(void*)f_9518},
{"f_15077:support_2escm",(void*)f_15077},
{"f_9510:support_2escm",(void*)f_9510},
{"f_15071:support_2escm",(void*)f_15071},
{"f_7571:support_2escm",(void*)f_7571},
{"f_4878:support_2escm",(void*)f_4878},
{"f_7574:support_2escm",(void*)f_7574},
{"f_5974:support_2escm",(void*)f_5974},
{"f_15088:support_2escm",(void*)f_15088},
{"f_11499:support_2escm",(void*)f_11499},
{"f_4908:support_2escm",(void*)f_4908},
{"f_11491:support_2escm",(void*)f_11491},
{"f_15082:support_2escm",(void*)f_15082},
{"f_4863:support_2escm",(void*)f_4863},
{"f_4868:support_2escm",(void*)f_4868},
{"f_5986:support_2escm",(void*)f_5986},
{"f_10541:support_2escm",(void*)f_10541},
{"f_5980:support_2escm",(void*)f_5980},
{"f_10544:support_2escm",(void*)f_10544},
{"f_15094:support_2escm",(void*)f_15094},
{"f_11484:support_2escm",(void*)f_11484},
{"f_11488:support_2escm",(void*)f_11488},
{"f_5852:support_2escm",(void*)f_5852},
{"f_7855:support_2escm",(void*)f_7855},
{"f_8800:support_2escm",(void*)f_8800},
{"f_4954:support_2escm",(void*)f_4954},
{"f_5867:support_2escm",(void*)f_5867},
{"f_4951:support_2escm",(void*)f_4951},
{"f_7843:support_2escm",(void*)f_7843},
{"f_8813:support_2escm",(void*)f_8813},
{"f_7847:support_2escm",(void*)f_7847},
{"f_4945:support_2escm",(void*)f_4945},
{"f_4947:support_2escm",(void*)f_4947},
{"f_6119:support_2escm",(void*)f_6119},
{"f_5830:support_2escm",(void*)f_5830},
{"f_6115:support_2escm",(void*)f_6115},
{"f_7876:support_2escm",(void*)f_7876},
{"f_4938:support_2escm",(void*)f_4938},
{"f_5846:support_2escm",(void*)f_5846},
{"f_10507:support_2escm",(void*)f_10507},
{"f_10940:support_2escm",(void*)f_10940},
{"f_4923:support_2escm",(void*)f_4923},
{"f_4920:support_2escm",(void*)f_4920},
{"f_10948:support_2escm",(void*)f_10948},
{"f_7813:support_2escm",(void*)f_7813},
{"f_5063:support_2escm",(void*)f_5063},
{"f_5060:support_2escm",(void*)f_5060},
{"f_10926:support_2escm",(void*)f_10926},
{"f_5069:support_2escm",(void*)f_5069},
{"f_5037:support_2escm",(void*)f_5037},
{"f_8778:support_2escm",(void*)f_8778},
{"f_10430:support_2escm",(void*)f_10430},
{"f_10435:support_2escm",(void*)f_10435},
{"f_5043:support_2escm",(void*)f_5043},
{"f_5040:support_2escm",(void*)f_5040},
{"f_8781:support_2escm",(void*)f_8781},
{"f_10426:support_2escm",(void*)f_10426},
{"f_5092:support_2escm",(void*)f_5092},
{"f_5096:support_2escm",(void*)f_5096},
{"f_10101:support_2escm",(void*)f_10101},
{"f_10474:support_2escm",(void*)f_10474},
{"f_10476:support_2escm",(void*)f_10476},
{"f_8683:support_2escm",(void*)f_8683},
{"f_8685:support_2escm",(void*)f_8685},
{"f_10459:support_2escm",(void*)f_10459},
{"f_9747:support_2escm",(void*)f_9747},
{"f_10444:support_2escm",(void*)f_10444},
{"f_10441:support_2escm",(void*)f_10441},
{"f_10449:support_2escm",(void*)f_10449},
{"f_9771:support_2escm",(void*)f_9771},
{"f_9774:support_2escm",(void*)f_9774},
{"f_15020:support_2escm",(void*)f_15020},
{"f_9755:support_2escm",(void*)f_9755},
{"f_10088:support_2escm",(void*)f_10088},
{"f_6999:support_2escm",(void*)f_6999},
{"f_6993:support_2escm",(void*)f_6993},
{"f_6996:support_2escm",(void*)f_6996},
{"f_8328:support_2escm",(void*)f_8328},
{"f_8659:support_2escm",(void*)f_8659},
{"f_10483:support_2escm",(void*)f_10483},
{"f_14686:support_2escm",(void*)f_14686},
{"f_8337:support_2escm",(void*)f_8337},
{"f_10174:support_2escm",(void*)f_10174},
{"f_10171:support_2escm",(void*)f_10171},
{"f_10177:support_2escm",(void*)f_10177},
{"f_15050:support_2escm",(void*)f_15050},
{"f_14654:support_2escm",(void*)f_14654},
{"f_8630:support_2escm",(void*)f_8630},
{"f_14659:support_2escm",(void*)f_14659},
{"f_10161:support_2escm",(void*)f_10161},
{"f_7671:support_2escm",(void*)f_7671},
{"f_5417:support_2escm",(void*)f_5417},
{"f_5413:support_2escm",(void*)f_5413},
{"f_10167:support_2escm",(void*)f_10167},
{"f_9604:support_2escm",(void*)f_9604},
{"f_8790:support_2escm",(void*)f_8790},
{"f_7930:support_2escm",(void*)f_7930},
{"f_8794:support_2escm",(void*)f_8794},
{"f_8798:support_2escm",(void*)f_8798},
{"f_6637:support_2escm",(void*)f_6637},
{"f_6634:support_2escm",(void*)f_6634},
{"f_5427:support_2escm",(void*)f_5427},
{"f_5421:support_2escm",(void*)f_5421},
{"f_10157:support_2escm",(void*)f_10157},
{"f_6624:support_2escm",(void*)f_6624},
{"f_10143:support_2escm",(void*)f_10143},
{"f_9920:support_2escm",(void*)f_9920},
{"f_7928:support_2escm",(void*)f_7928},
{"f_14640:support_2escm",(void*)f_14640},
{"f_10137:support_2escm",(void*)f_10137},
{"f_7642:support_2escm",(void*)f_7642},
{"f_5406:support_2escm",(void*)f_5406},
{"f_7511:support_2escm",(void*)f_7511},
{"f_10900:support_2escm",(void*)f_10900},
{"f_14618:support_2escm",(void*)f_14618},
{"f_14616:support_2escm",(void*)f_14616},
{"f_9334:support_2escm",(void*)f_9334},
{"f_9332:support_2escm",(void*)f_9332},
{"f_7636:support_2escm",(void*)f_7636},
{"f_9981:support_2escm",(void*)f_9981},
{"f_9325:support_2escm",(void*)f_9325},
{"f_14669:support_2escm",(void*)f_14669},
{"f_15468:support_2escm",(void*)f_15468},
{"f_9780:support_2escm",(void*)f_9780},
{"f_14630:support_2escm",(void*)f_14630},
{"f_9314:support_2escm",(void*)f_9314},
{"f_8236:support_2escm",(void*)f_8236},
{"f_8238:support_2escm",(void*)f_8238},
{"f_6618:support_2escm",(void*)f_6618},
{"f_15487:support_2escm",(void*)f_15487},
{"f_15483:support_2escm",(void*)f_15483},
{"f_8213:support_2escm",(void*)f_8213},
{"f_15458:support_2escm",(void*)f_15458},
{"f_15452:support_2escm",(void*)f_15452},
{"f_10398:support_2escm",(void*)f_10398},
{"f_15471:support_2escm",(void*)f_15471},
{"f_9912:support_2escm",(void*)f_9912},
{"f_4819:support_2escm",(void*)f_4819},
{"f_5916:support_2escm",(void*)f_5916},
{"f_4810:support_2escm",(void*)f_4810},
{"f_15413:support_2escm",(void*)f_15413},
{"f_15416:support_2escm",(void*)f_15416},
{"f_9904:support_2escm",(void*)f_9904},
{"f_4836:support_2escm",(void*)f_4836},
{"f_4834:support_2escm",(void*)f_4834},
{"f_4831:support_2escm",(void*)f_4831},
{"f_5932:support_2escm",(void*)f_5932},
{"f_15435:support_2escm",(void*)f_15435},
{"f_15431:support_2escm",(void*)f_15431},
{"f_4829:support_2escm",(void*)f_4829},
{"f_5947:support_2escm",(void*)f_5947},
{"f_5942:support_2escm",(void*)f_5942},
{"f_15409:support_2escm",(void*)f_15409},
{"f_7501:support_2escm",(void*)f_7501},
{"f_4849:support_2escm",(void*)f_4849},
{"f_4846:support_2escm",(void*)f_4846},
{"f_4843:support_2escm",(void*)f_4843},
{"f_10660:support_2escm",(void*)f_10660},
{"f_7504:support_2escm",(void*)f_7504},
{"f_4801:support_2escm",(void*)f_4801},
{"f_4807:support_2escm",(void*)f_4807},
{"f_4804:support_2escm",(void*)f_4804},
{"f_10671:support_2escm",(void*)f_10671},
{"f_10677:support_2escm",(void*)f_10677},
{"f_10621:support_2escm",(void*)f_10621},
{"f_10627:support_2escm",(void*)f_10627},
{"f_10680:support_2escm",(void*)f_10680},
{"f_10688:support_2escm",(void*)f_10688},
{"f_6054:support_2escm",(void*)f_6054},
{"f_12515:support_2escm",(void*)f_12515},
{"f_11208:support_2escm",(void*)f_11208},
{"f_6068:support_2escm",(void*)f_6068},
{"f_12528:support_2escm",(void*)f_12528},
{"f_6065:support_2escm",(void*)f_6065},
{"f_11200:support_2escm",(void*)f_11200},
{"f_11202:support_2escm",(void*)f_11202},
{"f_14695:support_2escm",(void*)f_14695},
{"f_6039:support_2escm",(void*)f_6039},
{"f_6033:support_2escm",(void*)f_6033},
{"f_5016:support_2escm",(void*)f_5016},
{"f_5019:support_2escm",(void*)f_5019},
{"f_6048:support_2escm",(void*)f_6048},
{"f_6047:support_2escm",(void*)f_6047},
{"f_5022:support_2escm",(void*)f_5022},
{"f_5025:support_2escm",(void*)f_5025},
{"f_5028:support_2escm",(void*)f_5028},
{"f_9099:support_2escm",(void*)f_9099},
{"f_6071:support_2escm",(void*)f_6071},
{"f17172:support_2escm",(void*)f17172},
{"f_8192:support_2escm",(void*)f_8192},
{"f_9075:support_2escm",(void*)f_9075},
{"f_9715:support_2escm",(void*)f_9715},
{"f_11276:support_2escm",(void*)f_11276},
{"f_9718:support_2escm",(void*)f_9718},
{"f_6077:support_2escm",(void*)f_6077},
{"f_11272:support_2escm",(void*)f_11272},
{"f_8172:support_2escm",(void*)f_8172},
{"f_8176:support_2escm",(void*)f_8176},
{"f_11261:support_2escm",(void*)f_11261},
{"f_15304:support_2escm",(void*)f_15304},
{"f_15307:support_2escm",(void*)f_15307},
{"f_15301:support_2escm",(void*)f_15301},
{"f_14757:support_2escm",(void*)f_14757},
{"f_8618:support_2escm",(void*)f_8618},
{"f_5172:support_2escm",(void*)f_5172},
{"f_5178:support_2escm",(void*)f_5178},
{"f_9046:support_2escm",(void*)f_9046},
{"f_15313:support_2escm",(void*)f_15313},
{"f_15314:support_2escm",(void*)f_15314},
{"f_14766:support_2escm",(void*)f_14766},
{"f_14763:support_2escm",(void*)f_14763},
{"f_15310:support_2escm",(void*)f_15310},
{"f_14769:support_2escm",(void*)f_14769},
{"f_12591:support_2escm",(void*)f_12591},
{"f_11283:support_2escm",(void*)f_11283},
{"f_12597:support_2escm",(void*)f_12597},
{"f_7383:support_2escm",(void*)f_7383},
{"f_7380:support_2escm",(void*)f_7380},
{"f_11281:support_2escm",(void*)f_11281},
{"f_14734:support_2escm",(void*)f_14734},
{"f_12585:support_2escm",(void*)f_12585},
{"f_14749:support_2escm",(void*)f_14749},
{"f_14740:support_2escm",(void*)f_14740},
{"f_11221:support_2escm",(void*)f_11221},
{"f_14798:support_2escm",(void*)f_14798},
{"f_12560:support_2escm",(void*)f_12560},
{"f_7350:support_2escm",(void*)f_7350},
{"f_11251:support_2escm",(void*)f_11251},
{"f_7605:support_2escm",(void*)f_7605},
{"f_7607:support_2escm",(void*)f_7607},
{"f_11249:support_2escm",(void*)f_11249},
{"f_12556:support_2escm",(void*)f_12556},
{"f_12552:support_2escm",(void*)f_12552},
{"f_7342:support_2escm",(void*)f_7342},
{"f_7344:support_2escm",(void*)f_7344},
{"f_15366:support_2escm",(void*)f_15366},
{"f_15369:support_2escm",(void*)f_15369},
{"f_14775:support_2escm",(void*)f_14775},
{"f_14772:support_2escm",(void*)f_14772},
{"f_8714:support_2escm",(void*)f_8714},
{"f_14779:support_2escm",(void*)f_14779},
{"f_14783:support_2escm",(void*)f_14783},
{"f_14787:support_2escm",(void*)f_14787},
{"f_10637:support_2escm",(void*)f_10637},
{"f_10633:support_2escm",(void*)f_10633},
{"f_7365:support_2escm",(void*)f_7365},
{"f_12546:support_2escm",(void*)f_12546},
{"f_15386:support_2escm",(void*)f_15386},
{"f_15396:support_2escm",(void*)f_15396},
{"f_10619:support_2escm",(void*)f_10619},
{"f_7959:support_2escm",(void*)f_7959},
{"f_9708:support_2escm",(void*)f_9708},
{"f_14728:support_2escm",(void*)f_14728},
{"f_8628:support_2escm",(void*)f_8628},
{"f_7919:support_2escm",(void*)f_7919},
{"f_6987:support_2escm",(void*)f_6987},
{"f_10212:support_2escm",(void*)f_10212},
{"f_11362:support_2escm",(void*)f_11362},
{"f_6914:support_2escm",(void*)f_6914},
{"f_10206:support_2escm",(void*)f_10206},
{"f_10714:support_2escm",(void*)f_10714},
{"f_13588:support_2escm",(void*)f_13588},
{"f_6908:support_2escm",(void*)f_6908},
{"f_9470:support_2escm",(void*)f_9470},
{"f_9474:support_2escm",(void*)f_9474},
{"f_13560:support_2escm",(void*)f_13560},
{"f_10753:support_2escm",(void*)f_10753},
{"f_11391:support_2escm",(void*)f_11391},
{"f_8584:support_2escm",(void*)f_8584},
{"f_9488:support_2escm",(void*)f_9488},
{"f_15324:support_2escm",(void*)f_15324},
{"f_11397:support_2escm",(void*)f_11397},
{"f_10736:support_2escm",(void*)f_10736},
{"f_5115:support_2escm",(void*)f_5115},
{"f_9438:support_2escm",(void*)f_9438},
{"f_5119:support_2escm",(void*)f_5119},
{"f_10296:support_2escm",(void*)f_10296},
{"f_8567:support_2escm",(void*)f_8567},
{"f_6706:support_2escm",(void*)f_6706},
{"f_6709:support_2escm",(void*)f_6709},
{"f_10290:support_2escm",(void*)f_10290},
{"f_15330:support_2escm",(void*)f_15330},
{"f_5128:support_2escm",(void*)f_5128},
{"f_15345:support_2escm",(void*)f_15345},
{"f_10284:support_2escm",(void*)f_10284},
{"f_15348:support_2escm",(void*)f_15348},
{"f_15342:support_2escm",(void*)f_15342},
{"f_7769:support_2escm",(void*)f_7769},
{"f_15353:support_2escm",(void*)f_15353},
{"f_9444:support_2escm",(void*)f_9444},
{"f_8556:support_2escm",(void*)f_8556},
{"f_4766:support_2escm",(void*)f_4766},
{"f_10253:support_2escm",(void*)f_10253},
{"f_10255:support_2escm",(void*)f_10255},
{"f_7792:support_2escm",(void*)f_7792},
{"f_4756:support_2escm",(void*)f_4756},
{"f_4751:support_2escm",(void*)f_4751},
{"f_7738:support_2escm",(void*)f_7738},
{"f_14312:support_2escm",(void*)f_14312},
{"f_10824:support_2escm",(void*)f_10824},
{"f_10010:support_2escm",(void*)f_10010},
{"f_15784:support_2escm",(void*)f_15784},
{"f_6640:support_2escm",(void*)f_6640},
{"f_6510:support_2escm",(void*)f_6510},
{"f_9024:support_2escm",(void*)f_9024},
{"f_15782:support_2escm",(void*)f_15782},
{"f_8135:support_2escm",(void*)f_8135},
{"f_8570:support_2escm",(void*)f_8570},
{"f_8578:support_2escm",(void*)f_8578},
{"f_6650:support_2escm",(void*)f_6650},
{"f_6652:support_2escm",(void*)f_6652},
{"f_6507:support_2escm",(void*)f_6507},
{"f_6503:support_2escm",(void*)f_6503},
{"f_9012:support_2escm",(void*)f_9012},
{"f_9494:support_2escm",(void*)f_9494},
{"f_8106:support_2escm",(void*)f_8106},
{"f_8104:support_2escm",(void*)f_8104},
{"f_15778:support_2escm",(void*)f_15778},
{"f_15775:support_2escm",(void*)f_15775},
{"f_15772:support_2escm",(void*)f_15772},
{"f_10040:support_2escm",(void*)f_10040},
{"f_14330:support_2escm",(void*)f_14330},
{"f_15745:support_2escm",(void*)f_15745},
{"f_14344:support_2escm",(void*)f_14344},
{"f_10038:support_2escm",(void*)f_10038},
{"f_7314:support_2escm",(void*)f_7314},
{"f_15714:support_2escm",(void*)f_15714},
{"f_15718:support_2escm",(void*)f_15718},
{"f_10026:support_2escm",(void*)f_10026},
{"f_10028:support_2escm",(void*)f_10028},
{"f_15769:support_2escm",(void*)f_15769},
{"f_15766:support_2escm",(void*)f_15766},
{"f_7305:support_2escm",(void*)f_7305},
{"f_15760:support_2escm",(void*)f_15760},
{"f_5104:support_2escm",(void*)f_5104},
{"f_5107:support_2escm",(void*)f_5107},
{"f_14320:support_2escm",(void*)f_14320},
{"f_7332:support_2escm",(void*)f_7332},
{"f_15735:support_2escm",(void*)f_15735},
{"f_15730:support_2escm",(void*)f_15730},
{"f_7323:support_2escm",(void*)f_7323},
{"f_15702:support_2escm",(void*)f_15702},
{"f_10793:support_2escm",(void*)f_10793},
{"f_10069:support_2escm",(void*)f_10069},
{"f_10775:support_2escm",(void*)f_10775},
{"f_13434:support_2escm",(void*)f_13434},
{"f_6687:support_2escm",(void*)f_6687},
{"f_6696:support_2escm",(void*)f_6696},
{"f_6691:support_2escm",(void*)f_6691},
{"f_13100:support_2escm",(void*)f_13100},
{"f_6830:support_2escm",(void*)f_6830},
{"f_5690:support_2escm",(void*)f_5690},
{"f_5692:support_2escm",(void*)f_5692},
{"f_14853:support_2escm",(void*)f_14853},
{"f_10894:support_2escm",(void*)f_10894},
{"f_14851:support_2escm",(void*)f_14851},
{"f_5662:support_2escm",(void*)f_5662},
{"f_6836:support_2escm",(void*)f_6836},
{"f_14867:support_2escm",(void*)f_14867},
{"f_5672:support_2escm",(void*)f_5672},
{"f_10874:support_2escm",(void*)f_10874},
{"f_5678:support_2escm",(void*)f_5678},
{"f_6897:support_2escm",(void*)f_6897},
{"f_5641:support_2escm",(void*)f_5641},
{"f_5647:support_2escm",(void*)f_5647},
{"f_10868:support_2escm",(void*)f_10868},
{"f_14808:support_2escm",(void*)f_14808},
{"f_14805:support_2escm",(void*)f_14805},
{"f_11579:support_2escm",(void*)f_11579},
{"f_14812:support_2escm",(void*)f_14812},
{"f_14818:support_2escm",(void*)f_14818},
{"f_14824:support_2escm",(void*)f_14824},
{"f_11526:support_2escm",(void*)f_11526},
{"f_6884:support_2escm",(void*)f_6884},
{"f_14394:support_2escm",(void*)f_14394},
{"f_12640:support_2escm",(void*)f_12640},
{"f_11554:support_2escm",(void*)f_11554},
{"f_12646:support_2escm",(void*)f_12646},
{"f_5686:support_2escm",(void*)f_5686},
{"f_15821:support_2escm",(void*)f_15821},
{"f_14376:support_2escm",(void*)f_14376},
{"f_15827:support_2escm",(void*)f_15827},
{"f_11385:support_2escm",(void*)f_11385},
{"f_13444:support_2escm",(void*)f_13444},
{"toplevel:support_2escm",(void*)C_support_toplevel},
{"f_13440:support_2escm",(void*)f_13440},
{"f_12628:support_2escm",(void*)f_12628},
{"f_15834:support_2escm",(void*)f_15834},
{"f_8927:support_2escm",(void*)f_8927},
{"f_14384:support_2escm",(void*)f_14384},
{"f_15837:support_2escm",(void*)f_15837},
{"f_15840:support_2escm",(void*)f_15840},
{"f_15843:support_2escm",(void*)f_15843},
{"f_14877:support_2escm",(void*)f_14877},
{"f_9855:support_2escm",(void*)f_9855},
{"f_12607:support_2escm",(void*)f_12607},
{"f_9841:support_2escm",(void*)f_9841},
{"f_14890:support_2escm",(void*)f_14890},
{"f_8527:support_2escm",(void*)f_8527},
{"f_11181:support_2escm",(void*)f_11181},
{"f_8525:support_2escm",(void*)f_8525},
{"f_11178:support_2escm",(void*)f_11178},
{"f_12650:support_2escm",(void*)f_12650},
{"f_11171:support_2escm",(void*)f_11171},
{"f_15809:support_2escm",(void*)f_15809},
{"f_15217:support_2escm",(void*)f_15217},
{"f_11165:support_2escm",(void*)f_11165},
{"f_11163:support_2escm",(void*)f_11163},
{"f_8044:support_2escm",(void*)f_8044},
{"f_15813:support_2escm",(void*)f_15813},
{"f_15816:support_2escm",(void*)f_15816},
{"f_14274:support_2escm",(void*)f_14274},
{"f_14278:support_2escm",(void*)f_14278},
{"f_11140:support_2escm",(void*)f_11140},
{"f_14280:support_2escm",(void*)f_14280},
{"f_11137:support_2escm",(void*)f_11137},
{"f_12616:support_2escm",(void*)f_12616},
{"f_11130:support_2escm",(void*)f_11130},
{"f_11124:support_2escm",(void*)f_11124},
{"f_6409:support_2escm",(void*)f_6409},
{"f_6405:support_2escm",(void*)f_6405},
{"f_15261:support_2escm",(void*)f_15261},
{"f_6273:support_2escm",(void*)f_6273},
{"f_6244:support_2escm",(void*)f_6244},
{"f_7704:support_2escm",(void*)f_7704},
{"f_15289:support_2escm",(void*)f_15289},
{"f_4744:support_2escm",(void*)f_4744},
{"f_15298:support_2escm",(void*)f_15298},
{"f_4736:support_2escm",(void*)f_4736},
{"f_13045:support_2escm",(void*)f_13045},
{"f_4727:support_2escm",(void*)f_4727},
{"f_4724:support_2escm",(void*)f_4724},
{"f_4720:support_2escm",(void*)f_4720},
{"f_6333:support_2escm",(void*)f_6333},
{"f_13057:support_2escm",(void*)f_13057},
{"f_4711:support_2escm",(void*)f_4711},
{"f_4714:support_2escm",(void*)f_4714},
{"f_6323:support_2escm",(void*)f_6323},
{"f_13023:support_2escm",(void*)f_13023},
{"f_4789:support_2escm",(void*)f_4789},
{"f_4786:support_2escm",(void*)f_4786},
{"f_13035:support_2escm",(void*)f_13035},
{"f_6310:support_2escm",(void*)f_6310},
{"f_4779:support_2escm",(void*)f_4779},
{"f_11516:support_2escm",(void*)f_11516},
{"f_6300:support_2escm",(void*)f_6300},
{"f_11548:support_2escm",(void*)f_11548},
{"f_11542:support_2escm",(void*)f_11542},
{"f_13017:support_2escm",(void*)f_13017},
{"f_5259:support_2escm",(void*)f_5259},
{"f_5265:support_2escm",(void*)f_5265},
{"f_11928:support_2escm",(void*)f_11928},
{"f_5240:support_2escm",(void*)f_5240},
{"f_11505:support_2escm",(void*)f_11505},
{"f_5293:support_2escm",(void*)f_5293},
{"f_5299:support_2escm",(void*)f_5299},
{"f_4708:support_2escm",(void*)f_4708},
{"f_6451:support_2escm",(void*)f_6451},
{"f_14943:support_2escm",(void*)f_14943},
{"f_5270:support_2escm",(void*)f_5270},
{"f_14953:support_2escm",(void*)f_14953},
{"f_14956:support_2escm",(void*)f_14956},
{"f_14950:support_2escm",(void*)f_14950},
{"f_6455:support_2escm",(void*)f_6455},
{"f_14920:support_2escm",(void*)f_14920},
{"f_14929:support_2escm",(void*)f_14929},
{"f_14925:support_2escm",(void*)f_14925},
{"f_13063:support_2escm",(void*)f_13063},
{"f_13067:support_2escm",(void*)f_13067},
{"f_14937:support_2escm",(void*)f_14937},
{"f_9199:support_2escm",(void*)f_9199},
{"f_14909:support_2escm",(void*)f_14909},
{"f_14905:support_2escm",(void*)f_14905},
{"f_14916:support_2escm",(void*)f_14916},
{"f_5515:support_2escm",(void*)f_5515},
{"f_5513:support_2escm",(void*)f_5513},
{"f_5522:support_2escm",(void*)f_5522},
{"f_9158:support_2escm",(void*)f_9158},
{"f_15256:support_2escm",(void*)f_15256},
{"f_15252:support_2escm",(void*)f_15252},
{"f_15598:support_2escm",(void*)f_15598},
{"f_11031:support_2escm",(void*)f_11031},
{"f_14466:support_2escm",(void*)f_14466},
{"f_8430:support_2escm",(void*)f_8430},
{"f_5788:support_2escm",(void*)f_5788},
{"f_5784:support_2escm",(void*)f_5784},
{"f_5627:support_2escm",(void*)f_5627},
{"f_14485:support_2escm",(void*)f_14485},
{"f_14985:support_2escm",(void*)f_14985},
{"f_14981:support_2escm",(void*)f_14981},
{"f_14995:support_2escm",(void*)f_14995},
{"f_5601:support_2escm",(void*)f_5601},
{"f_7447:support_2escm",(void*)f_7447},
{"f_7449:support_2escm",(void*)f_7449},
{"f_9172:support_2escm",(void*)f_9172},
{"f_9176:support_2escm",(void*)f_9176},
{"f_6007:support_2escm",(void*)f_6007},
{"f_14429:support_2escm",(void*)f_14429},
{"f_6005:support_2escm",(void*)f_6005},
{"f_14961:support_2escm",(void*)f_14961},
{"f_15664:support_2escm",(void*)f_15664},
{"f_6558:support_2escm",(void*)f_6558},
{"f_14432:support_2escm",(void*)f_14432},
{"f_5529:support_2escm",(void*)f_5529},
{"f_15675:support_2escm",(void*)f_15675},
{"f_9867:support_2escm",(void*)f_9867},
{"f_9865:support_2escm",(void*)f_9865},
{"f_13947:support_2escm",(void*)f_13947},
{"f_11901:support_2escm",(void*)f_11901},
{"f_15686:support_2escm",(void*)f_15686},
{"f_8013:support_2escm",(void*)f_8013},
{"f_15696:support_2escm",(void*)f_15696},
{"f_8015:support_2escm",(void*)f_8015},
{"f_15496:support_2escm",(void*)f_15496},
{"f_15690:support_2escm",(void*)f_15690},
{"f_15492:support_2escm",(void*)f_15492},
{"f_13925:support_2escm",(void*)f_13925},
{"f_8997:support_2escm",(void*)f_8997},
{"f_15622:support_2escm",(void*)f_15622},
{"f_9838:support_2escm",(void*)f_9838},
{"f_9832:support_2escm",(void*)f_9832},
{"f_8965:support_2escm",(void*)f_8965},
{"f_8961:support_2escm",(void*)f_8961},
{"f_9829:support_2escm",(void*)f_9829},
{"f_9825:support_2escm",(void*)f_9825},
{"f_9823:support_2escm",(void*)f_9823},
{"f_11003:support_2escm",(void*)f_11003},
{"f_13907:support_2escm",(void*)f_13907},
{"f_8973:support_2escm",(void*)f_8973},
{"f_11677:support_2escm",(void*)f_11677},
{"f_15643:support_2escm",(void*)f_15643},
{"f_9896:support_2escm",(void*)f_9896},
{"f_15658:support_2escm",(void*)f_15658},
{"f_11662:support_2escm",(void*)f_11662},
{"f_7478:support_2escm",(void*)f_7478},
{"f_11612:support_2escm",(void*)f_11612},
{"f_11975:support_2escm",(void*)f_11975},
{"f_11971:support_2escm",(void*)f_11971},
{"f_15618:support_2escm",(void*)f_15618},
{"f_6225:support_2escm",(void*)f_6225},
{"f_6587:support_2escm",(void*)f_6587},
{"f_6584:support_2escm",(void*)f_6584},
{"f_8903:support_2escm",(void*)f_8903},
{"f_6591:support_2escm",(void*)f_6591},
{"f_13736:support_2escm",(void*)f_13736},
{"f_6567:support_2escm",(void*)f_6567},
{"f_6562:support_2escm",(void*)f_6562},
{"f_13708:support_2escm",(void*)f_13708},
{"f_6577:support_2escm",(void*)f_6577},
{"f_6756:support_2escm",(void*)f_6756},
{"f_6762:support_2escm",(void*)f_6762},
{"f_5354:support_2escm",(void*)f_5354},
{"f_9800:support_2escm",(void*)f_9800},
{"f_6730:support_2escm",(void*)f_6730},
{"f_10322:support_2escm",(void*)f_10322},
{"f_10324:support_2escm",(void*)f_10324},
{"f_6746:support_2escm",(void*)f_6746},
{"f_5378:support_2escm",(void*)f_5378},
{"f_6799:support_2escm",(void*)f_6799},
{"f_6793:support_2escm",(void*)f_6793},
{"f_11434:support_2escm",(void*)f_11434},
{"f_4671:support_2escm",(void*)f_4671},
{"f_11431:support_2escm",(void*)f_11431},
{"f_11594:support_2escm",(void*)f_11594},
{"f_4674:support_2escm",(void*)f_4674},
{"f_4678:support_2escm",(void*)f_4678},
{"f_11839:support_2escm",(void*)f_11839},
{"f_11428:support_2escm",(void*)f_11428},
{"f_11422:support_2escm",(void*)f_11422},
{"f_10363:support_2escm",(void*)f_10363},
{"f_10366:support_2escm",(void*)f_10366},
{"f_9543:support_2escm",(void*)f_9543},
{"f_4697:support_2escm",(void*)f_4697},
{"f_9539:support_2escm",(void*)f_9539},
{"f_5384:support_2escm",(void*)f_5384},
{"f_5382:support_2escm",(void*)f_5382},
{"f_4683:support_2escm",(void*)f_4683},
{"f_14491:support_2escm",(void*)f_14491},
{"f_14495:support_2escm",(void*)f_14495},
{"f_11883:support_2escm",(void*)f_11883},
{"f_11886:support_2escm",(void*)f_11886},
{"f_13712:support_2escm",(void*)f_13712},
{"f_10372:support_2escm",(void*)f_10372},
{"f_11717:support_2escm",(void*)f_11717},
{"f_5212:support_2escm",(void*)f_5212},
{"f_10353:support_2escm",(void*)f_10353},
{"f_10359:support_2escm",(void*)f_10359},
{"f_6718:support_2escm",(void*)f_6718},
{"f_6715:support_2escm",(void*)f_6715},
{"f_6712:support_2escm",(void*)f_6712},
{"f_9283:support_2escm",(void*)f_9283},
{"f_9285:support_2escm",(void*)f_9285},
{"f_6011:support_2escm",(void*)f_6011},
{"f_10388:support_2escm",(void*)f_10388},
{"f_10380:support_2escm",(void*)f_10380},
{"f_5206:support_2escm",(void*)f_5206},
{"f_15123:support_2escm",(void*)f_15123},
{"f_11759:support_2escm",(void*)f_11759},
{"f_15132:support_2escm",(void*)f_15132},
{"f_4668:support_2escm",(void*)f_4668},
{"f_5366:support_2escm",(void*)f_5366},
{"f_11458:support_2escm",(void*)f_11458},
{"f_11455:support_2escm",(void*)f_11455},
{"f_11735:support_2escm",(void*)f_11735},
{"f_5573:support_2escm",(void*)f_5573},
{"f_15149:support_2escm",(void*)f_15149},
{"f_8416:support_2escm",(void*)f_8416},
{"f_11452:support_2escm",(void*)f_11452},
{"f_9256:support_2escm",(void*)f_9256},
{"f_11446:support_2escm",(void*)f_11446},
{"f_11443:support_2escm",(void*)f_11443},
{"f_9101:support_2escm",(void*)f_9101},
{"f_5585:support_2escm",(void*)f_5585},
{"f_11720:support_2escm",(void*)f_11720},
{"f_12046:support_2escm",(void*)f_12046},
{"f_15158:support_2escm",(void*)f_15158},
{"f_5892:support_2escm",(void*)f_5892},
{"f_11440:support_2escm",(void*)f_11440},
{"f_11479:support_2escm",(void*)f_11479},
{"f_11476:support_2escm",(void*)f_11476},
{"f_11470:support_2escm",(void*)f_11470},
{"f_4999:support_2escm",(void*)f_4999},
{"f_5599:support_2escm",(void*)f_5599},
{"f_14560:support_2escm",(void*)f_14560},
{"f_11467:support_2escm",(void*)f_11467},
{"f_11464:support_2escm",(void*)f_11464},
{"f_9593:support_2escm",(void*)f_9593},
{"f_4984:support_2escm",(void*)f_4984},
{"f_4989:support_2escm",(void*)f_4989},
{"f_4981:support_2escm",(void*)f_4981},
{"f_7835:support_2escm",(void*)f_7835},
{"f_12011:support_2escm",(void*)f_12011},
{"f_11416:support_2escm",(void*)f_11416},
{"f_6176:support_2escm",(void*)f_6176},
{"f_11419:support_2escm",(void*)f_11419},
{"f_5886:support_2escm",(void*)f_5886},
{"f_11413:support_2escm",(void*)f_11413},
{"f_6172:support_2escm",(void*)f_6172},
{"f_4971:support_2escm",(void*)f_4971},
{"f_11410:support_2escm",(void*)f_11410},
{"f_4970:support_2escm",(void*)f_4970},
{"f_5884:support_2escm",(void*)f_5884},
{"f_14541:support_2escm",(void*)f_14541},
{"f_11404:support_2escm",(void*)f_11404},
{"f_5542:support_2escm",(void*)f_5542},
{"f_12008:support_2escm",(void*)f_12008},
{"f_4963:support_2escm",(void*)f_4963},
{"f_4967:support_2escm",(void*)f_4967},
{"f_4961:support_2escm",(void*)f_4961},
{"f_9130:support_2escm",(void*)f_9130},
{"f_5554:support_2escm",(void*)f_5554},
{"f_14521:support_2escm",(void*)f_14521},
{"f_14572:support_2escm",(void*)f_14572},
{"f_15554:support_2escm",(void*)f_15554},
{"f_5726:support_2escm",(void*)f_5726},
{"f_6196:support_2escm",(void*)f_6196},
{"f_5738:support_2escm",(void*)f_5738},
{"f_15578:support_2escm",(void*)f_15578},
{"f_8402:support_2escm",(void*)f_8402},
{"f_8406:support_2escm",(void*)f_8406},
{"f_8409:support_2escm",(void*)f_8409},
{"f_14530:support_2escm",(void*)f_14530},
{"f_5754:support_2escm",(void*)f_5754},
{"f_15514:support_2escm",(void*)f_15514},
{"f_11812:support_2escm",(void*)f_11812},
{"f_15526:support_2escm",(void*)f_15526},
{"f_15541:support_2escm",(void*)f_15541},
{"f_11842:support_2escm",(void*)f_11842},
{"f_15538:support_2escm",(void*)f_15538},
{"f_15549:support_2escm",(void*)f_15549},
{"f_6373:support_2escm",(void*)f_6373},
{"f_11785:support_2escm",(void*)f_11785},
{"f_6356:support_2escm",(void*)f_6356},
{"f_6369:support_2escm",(void*)f_6369},
{"f_6346:support_2escm",(void*)f_6346},
{"f_5463:support_2escm",(void*)f_5463},
{"f_5467:support_2escm",(void*)f_5467},
{"f_9633:support_2escm",(void*)f_9633},
{"f_9639:support_2escm",(void*)f_9639},
{"f_6399:support_2escm",(void*)f_6399},
{"f_6391:support_2escm",(void*)f_6391},
{"f_5447:support_2escm",(void*)f_5447},
{"f_10586:support_2escm",(void*)f_10586},
{"f_8394:support_2escm",(void*)f_8394},
{"f_9945:support_2escm",(void*)f_9945},
{"f_6387:support_2escm",(void*)f_6387},
{"f_10560:support_2escm",(void*)f_10560},
{"f_5322:support_2escm",(void*)f_5322},
{"f_5324:support_2escm",(void*)f_5324},
{"f_9930:support_2escm",(void*)f_9930},
{"f_9932:support_2escm",(void*)f_9932},
{"f_9506:support_2escm",(void*)f_9506},
{"f_9500:support_2escm",(void*)f_9500},
{"f_8343:support_2escm",(void*)f_8343},
{"f_15110:support_2escm",(void*)f_15110},
{"f_7578:support_2escm",(void*)f_7578},
{"f_5488:support_2escm",(void*)f_5488},
{"f_9657:support_2escm",(void*)f_9657},
{"f_15104:support_2escm",(void*)f_15104},
{"f_15102:support_2escm",(void*)f_15102},
{"f_7597:support_2escm",(void*)f_7597},
{"f_5314:support_2escm",(void*)f_5314},
{"f_9649:support_2escm",(void*)f_9649},
{"f_5312:support_2escm",(void*)f_5312},
{"f_5330:support_2escm",(void*)f_5330},
{"f_5304:support_2escm",(void*)f_5304},
{"f_5302:support_2escm",(void*)f_5302},
{"f_8299:support_2escm",(void*)f_8299},
{"f_8297:support_2escm",(void*)f_8297},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  map		30
S|  sprintf		4
S|  fprintf		5
S|  printf		19
S|  for-each		15
o|eliminated procedure checks: 395 
o|specializations:
o|  1 (eqv? (not float) *)
o|  3 (= fixnum fixnum)
o|  1 (assq * (list-of pair))
o|  1 (current-output-port)
o|  1 (second (pair * pair))
o|  3 (first pair)
o|  5 (cddr (pair * pair))
o|  1 (caddr (pair * (pair * pair)))
o|  349 (eqv? * (not float))
o|  1 (##sys#call-with-values (procedure () *) *)
o|  1 (cadr (pair * pair))
o|  1 (current-input-port)
o|  3 (memq * list)
o|  1 (>= fixnum fixnum)
o|  3 (< fixnum fixnum)
o|  2 (current-error-port)
o|  8 (##sys#check-list (or pair list) *)
o|  28 (##sys#check-output-port * * *)
o|  31 (cdr pair)
o|  27 (car pair)
o|safe globals: (##compiler#bomb ##compiler#disabled-warnings ##compiler#debugging-chicken ##compiler#compiler-cleanup-hook constant25 constant22) 
o|Removed `not' forms: 7 
o|removed side-effect free assignment to unused variable: constant22 
o|inlining procedure: k4685 
o|inlining procedure: k4685 
o|inlining procedure: k4725 
o|inlining procedure: k4758 
o|contracted procedure: "(support.scm:64) g4855" 
o|propagated global variable: out5862 ##sys#standard-output 
o|substituted constant variable: a4740 
o|substituted constant variable: a4741 
o|inlining procedure: k4758 
o|inlining procedure: k4725 
o|propagated global variable: out7478 ##compiler#collected-debugging-output 
o|substituted constant variable: a4782 
o|substituted constant variable: a4783 
o|propagated global variable: out7478 ##compiler#collected-debugging-output 
o|inlining procedure: k4793 
o|inlining procedure: k4793 
o|propagated global variable: out112116 ##compiler#collected-debugging-output 
o|substituted constant variable: a4839 
o|substituted constant variable: a4840 
o|inlining procedure: k4854 
o|inlining procedure: k4854 
o|inlining procedure: k4870 
o|inlining procedure: k4870 
o|inlining procedure: k4893 
o|inlining procedure: k4893 
o|inlining procedure: k4909 
o|inlining procedure: k4909 
o|inlining procedure: k4991 
o|inlining procedure: k4991 
o|substituted constant variable: a5012 
o|substituted constant variable: a5013 
o|substituted constant variable: a5033 
o|substituted constant variable: a5034 
o|inlining procedure: k5071 
o|inlining procedure: k5071 
o|inlining procedure: k5130 
o|inlining procedure: k5130 
o|inlining procedure: k5151 
o|inlining procedure: k5151 
o|inlining procedure: k5180 
o|inlining procedure: k5180 
o|inlining procedure: k5214 
o|inlining procedure: k5214 
o|inlining procedure: k5242 
o|inlining procedure: k5242 
o|substituted constant variable: a5261 
o|substituted constant variable: a5262 
o|inlining procedure: k5272 
o|inlining procedure: k5272 
o|substituted constant variable: a5295 
o|substituted constant variable: a5296 
o|inlining procedure: k5332 
o|inlining procedure: k5332 
o|inlining procedure: k5386 
o|inlining procedure: k5386 
o|inlining procedure: k5431 
o|inlining procedure: k5431 
o|substituted constant variable: a5438 
o|substituted constant variable: a5440 
o|inlining procedure: k5453 
o|inlining procedure: k5453 
o|substituted constant variable: a5457 
o|substituted constant variable: a5459 
o|substituted constant variable: a5461 
o|inlining procedure: k5468 
o|inlining procedure: k5493 
o|inlining procedure: k5493 
o|inlining procedure: k5468 
o|inlining procedure: k5531 
o|propagated global variable: r553215919 ##sys#standard-input 
o|inlining procedure: k5531 
o|inlining procedure: k5546 
o|inlining procedure: k5546 
o|inlining procedure: k5575 
o|inlining procedure: k5575 
o|inlining procedure: k5587 
o|inlining procedure: k5587 
o|inlining procedure: k5607 
o|inlining procedure: k5607 
o|inlining procedure: k5649 
o|inlining procedure: k5649 
o|inlining procedure: k5697 
o|inlining procedure: k5697 
o|inlining procedure: k5709 
o|inlining procedure: k5709 
o|inlining procedure: k5721 
o|inlining procedure: k5721 
o|inlining procedure: k5733 
o|inlining procedure: k5733 
o|inlining procedure: k5742 
o|inlining procedure: k5742 
o|inlining procedure: k5759 
o|inlining procedure: k5759 
o|inlining procedure: k5771 
o|inlining procedure: k5771 
o|inlining procedure: k5789 
o|inlining procedure: k5789 
o|inlining procedure: k5801 
o|inlining procedure: k5801 
o|inlining procedure: k5813 
o|inlining procedure: k5813 
o|inlining procedure: k5835 
o|inlining procedure: k5835 
o|inlining procedure: k5847 
o|inlining procedure: k5847 
o|inlining procedure: k5856 
o|inlining procedure: k5856 
o|inlining procedure: k5894 
o|inlining procedure: k5894 
o|inlining procedure: k5907 
o|inlining procedure: k5907 
o|inlining procedure: k5948 
o|inlining procedure: k5948 
o|inlining procedure: k5992 
o|inlining procedure: k5992 
o|inlining procedure: k6012 
o|inlining procedure: k6012 
o|merged explicitly consed rest parameter: args486502 
o|consed rest parameter at call site: tmp24293 1 
o|inlining procedure: k6079 
o|inlining procedure: k6079 
o|inlining procedure: k6094 
o|inlining procedure: k6094 
o|inlining procedure: k6174 
o|inlining procedure: k6302 
o|contracted procedure: "(support.scm:367) g634641" 
o|contracted procedure: "(support.scm:369) g644645" 
o|inlining procedure: k6302 
o|propagated global variable: g640642 ##compiler#internal-bindings 
o|inlining procedure: k6325 
o|contracted procedure: "(support.scm:361) g585592" 
o|inlining procedure: k6245 
o|contracted procedure: "(support.scm:365) g610611" 
o|inlining procedure: k6245 
o|contracted procedure: "(support.scm:363) g595596" 
o|inlining procedure: k6325 
o|propagated global variable: g591593 extended-bindings 
o|inlining procedure: k6348 
o|contracted procedure: "(support.scm:355) g536543" 
o|inlining procedure: k6197 
o|contracted procedure: "(support.scm:359) g561562" 
o|inlining procedure: k6197 
o|contracted procedure: "(support.scm:357) g546547" 
o|inlining procedure: k6348 
o|propagated global variable: g542544 standard-bindings 
o|inlining procedure: k6174 
o|inlining procedure: k6374 
o|inlining procedure: k6374 
o|inlining procedure: k6392 
o|inlining procedure: k6392 
o|inlining procedure: k6410 
o|inlining procedure: k6422 
o|inlining procedure: k6422 
o|inlining procedure: k6410 
o|inlining procedure: k6456 
o|inlining procedure: k6456 
o|inlining procedure: k6511 
o|inlining procedure: k6511 
o|inlining procedure: k6563 
o|inlining procedure: k6563 
o|inlining procedure: k6588 
o|inlining procedure: k6588 
o|propagated global variable: out739743 ##sys#standard-output 
o|substituted constant variable: a6630 
o|substituted constant variable: a6631 
o|inlining procedure: k6626 
o|inlining procedure: k6654 
o|inlining procedure: k6654 
o|propagated global variable: out739743 ##sys#standard-output 
o|inlining procedure: k6626 
o|inlining procedure: k6698 
o|inlining procedure: k6698 
o|propagated global variable: out948952 ##sys#standard-output 
o|substituted constant variable: a6726 
o|substituted constant variable: a6727 
o|propagated global variable: out948952 ##sys#standard-output 
o|propagated global variable: out941945 ##sys#standard-output 
o|substituted constant variable: a6742 
o|substituted constant variable: a6743 
o|propagated global variable: out941945 ##sys#standard-output 
o|propagated global variable: out900904 ##sys#standard-output 
o|substituted constant variable: a6758 
o|substituted constant variable: a6759 
o|contracted procedure: "(support.scm:489) g908909" 
o|contracted procedure: "(support.scm:489) g905906" 
o|propagated global variable: out900904 ##sys#standard-output 
o|propagated global variable: out914918 ##sys#standard-output 
o|substituted constant variable: a6795 
o|substituted constant variable: a6796 
o|inlining procedure: k6788 
o|contracted procedure: "(support.scm:491) g922923" 
o|contracted procedure: "(support.scm:491) g919920" 
o|propagated global variable: out914918 ##sys#standard-output 
o|inlining procedure: k6788 
o|propagated global variable: out928932 ##sys#standard-output 
o|substituted constant variable: a6832 
o|substituted constant variable: a6833 
o|contracted procedure: "(support.scm:493) g936937" 
o|contracted procedure: "(support.scm:493) g933934" 
o|propagated global variable: out928932 ##sys#standard-output 
o|inlining procedure: k6886 
o|propagated global variable: out853857 ##sys#standard-output 
o|substituted constant variable: a6910 
o|substituted constant variable: a6911 
o|substituted constant variable: names775 
o|propagated global variable: out853857 ##sys#standard-output 
o|inlining procedure: k6930 
o|inlining procedure: k6930 
o|inlining procedure: k6943 
o|inlining procedure: k6943 
o|inlining procedure: k6953 
o|inlining procedure: k6953 
o|propagated global variable: out884888 ##sys#standard-output 
o|substituted constant variable: a6989 
o|substituted constant variable: a6990 
o|inlining procedure: k6979 
o|propagated global variable: out884888 ##sys#standard-output 
o|inlining procedure: k6979 
o|inlining procedure: k7021 
o|inlining procedure: k7021 
o|substituted constant variable: a7037 
o|substituted constant variable: a7039 
o|inlining procedure: k7043 
o|inlining procedure: k7043 
o|inlining procedure: k7055 
o|inlining procedure: k7055 
o|inlining procedure: k7067 
o|inlining procedure: k7067 
o|inlining procedure: k7079 
o|inlining procedure: k7079 
o|substituted constant variable: a7086 
o|substituted constant variable: a7088 
o|substituted constant variable: a7090 
o|substituted constant variable: a7092 
o|substituted constant variable: a7094 
o|substituted constant variable: a7096 
o|substituted constant variable: a7098 
o|substituted constant variable: a7100 
o|substituted constant variable: a7102 
o|substituted constant variable: a7104 
o|substituted constant variable: a7106 
o|substituted constant variable: a7108 
o|substituted constant variable: a7110 
o|inlining procedure: k7114 
o|inlining procedure: k7114 
o|inlining procedure: k7126 
o|inlining procedure: k7126 
o|inlining procedure: k7138 
o|inlining procedure: k7138 
o|inlining procedure: k7150 
o|inlining procedure: k7150 
o|inlining procedure: k7162 
o|inlining procedure: k7162 
o|inlining procedure: k7174 
o|inlining procedure: k7174 
o|inlining procedure: k7186 
o|inlining procedure: k7186 
o|inlining procedure: k7198 
o|inlining procedure: k7198 
o|inlining procedure: k7210 
o|inlining procedure: k7210 
o|inlining procedure: k7222 
o|inlining procedure: k7222 
o|substituted constant variable: a7229 
o|substituted constant variable: a7231 
o|substituted constant variable: a7233 
o|substituted constant variable: a7235 
o|substituted constant variable: a7237 
o|substituted constant variable: a7239 
o|substituted constant variable: a7241 
o|substituted constant variable: a7243 
o|substituted constant variable: a7245 
o|substituted constant variable: a7247 
o|substituted constant variable: a7249 
o|substituted constant variable: a7251 
o|substituted constant variable: a7253 
o|substituted constant variable: a7255 
o|substituted constant variable: a7257 
o|substituted constant variable: a7259 
o|substituted constant variable: a7261 
o|substituted constant variable: a7263 
o|substituted constant variable: a7265 
o|substituted constant variable: a7267 
o|substituted constant variable: a7269 
o|inlining procedure: k6886 
o|contracted procedure: "(support.scm:517) g10231024" 
o|contracted procedure: "(support.scm:518) g10301031" 
o|inlining procedure: k7385 
o|inlining procedure: k7385 
o|inlining procedure: k7405 
o|inlining procedure: k7405 
o|inlining procedure: k7421 
o|contracted procedure: "(support.scm:528) g10561057" 
o|inlining procedure: k7451 
o|inlining procedure: k7451 
o|inlining procedure: k7421 
o|inlining procedure: k7496 
o|inlining procedure: k7496 
o|inlining procedure: k7515 
o|inlining procedure: k7515 
o|inlining procedure: k7528 
o|contracted procedure: "(support.scm:544) g10931094" 
o|inlining procedure: k7609 
o|inlining procedure: k7609 
o|inlining procedure: k7644 
o|contracted procedure: "(support.scm:546) g11061115" 
o|inlining procedure: k7560 
o|inlining procedure: k7560 
o|inlining procedure: k7644 
o|inlining procedure: k7528 
o|contracted procedure: "(support.scm:553) g11551156" 
o|inlining procedure: k7713 
o|contracted procedure: "(support.scm:555) g11601161" 
o|inlining procedure: k7713 
o|inlining procedure: k7771 
o|contracted procedure: "(support.scm:562) g11731174" 
o|contracted procedure: "(support.scm:566) g11781179" 
o|inlining procedure: k7771 
o|contracted procedure: "(support.scm:568) g11831184" 
o|inlining procedure: k7897 
o|contracted procedure: "(support.scm:577) g11901191" 
o|inlining procedure: k7932 
o|inlining procedure: k7932 
o|inlining procedure: k7965 
o|inlining procedure: k7965 
o|inlining procedure: k7897 
o|contracted procedure: "(support.scm:582) g12251226" 
o|inlining procedure: k8017 
o|inlining procedure: k8017 
o|inlining procedure: k8053 
o|contracted procedure: "(support.scm:584) g12561257" 
o|inlining procedure: k8053 
o|contracted procedure: "(support.scm:586) g12641265" 
o|inlining procedure: k8108 
o|inlining procedure: k8108 
o|inlining procedure: k8144 
o|contracted procedure: "(support.scm:591) g12961297" 
o|inlining procedure: k8144 
o|contracted procedure: "(support.scm:597) g13131314" 
o|inlining procedure: k8240 
o|inlining procedure: k8240 
o|inlining procedure: k8272 
o|contracted procedure: "(support.scm:599) g13441345" 
o|inlining procedure: k8301 
o|inlining procedure: k8301 
o|inlining procedure: k8272 
o|contracted procedure: "(support.scm:602) g13771378" 
o|inlining procedure: k8367 
o|inlining procedure: k8367 
o|inlining procedure: k8404 
o|inlining procedure: k8414 
o|inlining procedure: k8414 
o|inlining procedure: k8404 
o|contracted procedure: "(support.scm:604) g13861387" 
o|substituted constant variable: a8436 
o|inlining procedure: k8440 
o|inlining procedure: k8440 
o|inlining procedure: k8452 
o|inlining procedure: k8452 
o|substituted constant variable: a8459 
o|substituted constant variable: a8461 
o|substituted constant variable: a8463 
o|substituted constant variable: a8465 
o|substituted constant variable: a8467 
o|substituted constant variable: a8469 
o|substituted constant variable: a8474 
o|substituted constant variable: a8476 
o|substituted constant variable: a8478 
o|substituted constant variable: a8483 
o|substituted constant variable: a8485 
o|substituted constant variable: a8487 
o|substituted constant variable: a8489 
o|substituted constant variable: a8491 
o|substituted constant variable: a8496 
o|substituted constant variable: a8498 
o|substituted constant variable: a8500 
o|substituted constant variable: a8502 
o|substituted constant variable: a8507 
o|substituted constant variable: a8509 
o|contracted procedure: "(support.scm:614) g14211422" 
o|inlining procedure: k8529 
o|inlining procedure: k8529 
o|contracted procedure: "(support.scm:524) g10441045" 
o|inlining procedure: k8568 
o|inlining procedure: k8568 
o|inlining procedure: k8610 
o|inlining procedure: k8632 
o|inlining procedure: k8632 
o|inlining procedure: k8610 
o|inlining procedure: k8687 
o|inlining procedure: k8687 
o|inlining procedure: k8719 
o|inlining procedure: k8719 
o|inlining procedure: k8737 
o|inlining procedure: k8737 
o|inlining procedure: k8754 
o|inlining procedure: k8754 
o|inlining procedure: k8766 
o|inlining procedure: k8802 
o|inlining procedure: k8802 
o|inlining procedure: k8851 
o|inlining procedure: k8851 
o|inlining procedure: k8766 
o|inlining procedure: k8911 
o|inlining procedure: k8911 
o|inlining procedure: k8945 
o|inlining procedure: k8975 
o|inlining procedure: k8975 
o|inlining procedure: k8945 
o|inlining procedure: k9048 
o|inlining procedure: k9048 
o|inlining procedure: k9080 
o|inlining procedure: k9103 
o|inlining procedure: k9103 
o|inlining procedure: k9080 
o|inlining procedure: k9144 
o|inlining procedure: k9160 
o|inlining procedure: k9160 
o|inlining procedure: k9144 
o|inlining procedure: k9229 
o|inlining procedure: k9229 
o|inlining procedure: k9265 
o|inlining procedure: k9287 
o|inlining procedure: k9287 
o|inlining procedure: k9265 
o|inlining procedure: k9336 
o|inlining procedure: k9336 
o|substituted constant variable: a9372 
o|substituted constant variable: a9374 
o|inlining procedure: k9378 
o|inlining procedure: k9378 
o|substituted constant variable: a9391 
o|substituted constant variable: a9393 
o|substituted constant variable: a9395 
o|substituted constant variable: a9397 
o|substituted constant variable: a9399 
o|substituted constant variable: a9401 
o|substituted constant variable: a9403 
o|substituted constant variable: a9405 
o|substituted constant variable: a9407 
o|substituted constant variable: a9409 
o|substituted constant variable: a9411 
o|substituted constant variable: a9413 
o|substituted constant variable: a9415 
o|substituted constant variable: a9417 
o|substituted constant variable: a9419 
o|substituted constant variable: a9421 
o|inlining procedure: k9425 
o|inlining procedure: k9425 
o|substituted constant variable: a9432 
o|substituted constant variable: a9434 
o|substituted constant variable: a9436 
o|contracted procedure: "(support.scm:624) g14681469" 
o|contracted procedure: "(support.scm:623) g14651466" 
o|contracted procedure: "(support.scm:622) g14621463" 
o|inlining procedure: k9446 
o|inlining procedure: k9446 
o|contracted procedure: "(support.scm:677) g17801781" 
o|contracted procedure: "(support.scm:692) g18291830" 
o|contracted procedure: "(support.scm:694) g18341835" 
o|inlining procedure: k9561 
o|inlining procedure: k9561 
o|contracted procedure: "(support.scm:698) g18391840" 
o|inlining procedure: k9606 
o|inlining procedure: k9606 
o|inlining procedure: k9683 
o|contracted procedure: "(support.scm:716) g19061907" 
o|inlining procedure: k9683 
o|inlining procedure: "(support.scm:721) rename1882" 
o|inlining procedure: k9722 
o|contracted procedure: "(support.scm:723) g19131914" 
o|inlining procedure: "(support.scm:724) rename1882" 
o|inlining procedure: k9722 
o|contracted procedure: "(support.scm:732) g19221923" 
o|inlining procedure: k9809 
o|contracted procedure: "(support.scm:745) g19931994" 
o|inlining procedure: k9869 
o|inlining procedure: k9869 
o|inlining procedure: k9918 
o|inlining procedure: "(support.scm:748) rename1882" 
o|inlining procedure: k9918 
o|inlining procedure: k9934 
o|inlining procedure: k9934 
o|inlining procedure: k9983 
o|inlining procedure: k9983 
o|inlining procedure: k9809 
o|contracted procedure: "(support.scm:751) g20332034" 
o|inlining procedure: k10042 
o|inlining procedure: k10042 
o|substituted constant variable: a10075 
o|substituted constant variable: a10077 
o|substituted constant variable: a10079 
o|substituted constant variable: a10081 
o|substituted constant variable: a10083 
o|contracted procedure: "(support.scm:713) g18971898" 
o|contracted procedure: "(support.scm:712) g18941895" 
o|contracted procedure: "(support.scm:711) g18911892" 
o|inlining procedure: k10090 
o|inlining procedure: k10090 
o|inlining procedure: k10145 
o|inlining procedure: k10145 
o|contracted procedure: "(support.scm:763) g20882089" 
o|contracted procedure: "(support.scm:762) g20852086" 
o|contracted procedure: "(support.scm:761) g20822083" 
o|inlining procedure: k10257 
o|inlining procedure: k10257 
o|contracted procedure: "(support.scm:770) g21262127" 
o|contracted procedure: "(support.scm:769) g21042105" 
o|contracted procedure: "(support.scm:768) g21012102" 
o|contracted procedure: "(support.scm:774) g21412142" 
o|inlining procedure: k10326 
o|inlining procedure: k10326 
o|inlining procedure: k10367 
o|inlining procedure: k10390 
o|contracted procedure: "(support.scm:812) g22322239" 
o|inlining procedure: k10390 
o|inlining procedure: k10367 
o|inlining procedure: k10451 
o|contracted procedure: "(support.scm:804) g22102217" 
o|inlining procedure: k10451 
o|inlining procedure: k10478 
o|contracted procedure: k10493 
o|inlining procedure: k10490 
o|inlining procedure: k10490 
o|inlining procedure: k10508 
o|contracted procedure: k10528 
o|inlining procedure: k10525 
o|inlining procedure: k10525 
o|inlining procedure: k10566 
o|inlining procedure: k10566 
o|substituted constant variable: a10580 
o|substituted constant variable: a10582 
o|contracted procedure: "(support.scm:790) g22022203" 
o|contracted procedure: "(support.scm:788) g21932194" 
o|inlining procedure: k10508 
o|contracted procedure: "(support.scm:783) g21812182" 
o|contracted procedure: "(support.scm:783) g21842185" 
o|inlining procedure: k10478 
o|inlining procedure: k10638 
o|inlining procedure: k10638 
o|contracted procedure: "(support.scm:820) g22602261" 
o|inlining procedure: k10685 
o|inlining procedure: k10685 
o|inlining procedure: k10716 
o|inlining procedure: k10716 
o|inlining procedure: k10731 
o|inlining procedure: k10731 
o|inlining procedure: k10755 
o|inlining procedure: k10755 
o|inlining procedure: k10770 
o|inlining procedure: k10795 
o|inlining procedure: k10795 
o|inlining procedure: k10813 
o|inlining procedure: k10813 
o|contracted procedure: "(support.scm:850) g23222323" 
o|inlining procedure: k10770 
o|contracted procedure: "(support.scm:849) g23102311" 
o|contracted procedure: "(support.scm:848) g23062307" 
o|inlining procedure: k10869 
o|contracted procedure: "(support.scm:861) g23302331" 
o|contracted procedure: "(support.scm:861) g23272328" 
o|inlining procedure: k10869 
o|inlining procedure: k10918 
o|inlining procedure: k10918 
o|contracted procedure: "(support.scm:873) g23652366" 
o|inlining procedure: k10958 
o|inlining procedure: k10958 
o|substituted constant variable: a10974 
o|substituted constant variable: a10976 
o|substituted constant variable: a10978 
o|inlining procedure: k10982 
o|inlining procedure: k10982 
o|substituted constant variable: a10995 
o|substituted constant variable: a10997 
o|substituted constant variable: a10999 
o|substituted constant variable: a11001 
o|contracted procedure: "(support.scm:870) g23522353" 
o|contracted procedure: "(support.scm:869) g23432344" 
o|inlining procedure: k11019 
o|inlining procedure: k11041 
o|inlining procedure: k11064 
o|inlining procedure: k11064 
o|contracted procedure: "(support.scm:892) g24052406" 
o|contracted procedure: "(support.scm:891) g24012402" 
o|contracted procedure: "(support.scm:889) g23962397" 
o|inlining procedure: k11041 
o|contracted procedure: "(support.scm:895) g24082409" 
o|substituted constant variable: a11116 
o|substituted constant variable: a11118 
o|contracted procedure: "(support.scm:887) g23922393" 
o|inlining procedure: k11019 
o|contracted procedure: "(support.scm:881) g23762377" 
o|inlining procedure: k11132 
o|inlining procedure: k11132 
o|contracted procedure: k11144 
o|inlining procedure: k11147 
o|inlining procedure: k11147 
o|inlining procedure: k11173 
o|inlining procedure: k11173 
o|contracted procedure: k11185 
o|inlining procedure: k11188 
o|inlining procedure: k11188 
o|inlining procedure: k11210 
o|inlining procedure: k11230 
o|inlining procedure: k11230 
o|inlining procedure: k11210 
o|contracted procedure: k11240 
o|inlining procedure: k11253 
o|inlining procedure: k11253 
o|contracted procedure: k11265 
o|inlining procedure: k11292 
o|inlining procedure: k11292 
o|inlining procedure: k11312 
o|inlining procedure: k11312 
o|contracted procedure: "(support.scm:967) g24672468" 
o|inlining procedure: k11333 
o|inlining procedure: k11333 
o|substituted constant variable: a11350 
o|substituted constant variable: a11352 
o|substituted constant variable: a11354 
o|inlining procedure: k11364 
o|inlining procedure: k11364 
o|propagated global variable: out24872491 ##sys#standard-output 
o|substituted constant variable: a11406 
o|substituted constant variable: a11407 
o|propagated global variable: out24972501 ##sys#standard-output 
o|substituted constant variable: a11424 
o|substituted constant variable: a11425 
o|propagated global variable: out25052509 ##sys#standard-output 
o|substituted constant variable: a11436 
o|substituted constant variable: a11437 
o|propagated global variable: out25132517 ##sys#standard-output 
o|substituted constant variable: a11448 
o|substituted constant variable: a11449 
o|propagated global variable: out25212525 ##sys#standard-output 
o|substituted constant variable: a11460 
o|substituted constant variable: a11461 
o|propagated global variable: out25292533 ##sys#standard-output 
o|substituted constant variable: a11472 
o|substituted constant variable: a11473 
o|inlining procedure: k11399 
o|propagated global variable: out25292533 ##sys#standard-output 
o|propagated global variable: out25212525 ##sys#standard-output 
o|propagated global variable: out25132517 ##sys#standard-output 
o|propagated global variable: out25052509 ##sys#standard-output 
o|propagated global variable: out24972501 ##sys#standard-output 
o|propagated global variable: out24872491 ##sys#standard-output 
o|inlining procedure: k11399 
o|inlining procedure: k11492 
o|inlining procedure: k11492 
o|inlining procedure: k11518 
o|contracted procedure: "(support.scm:997) g25492556" 
o|inlining procedure: k11518 
o|inlining procedure: k11556 
o|inlining procedure: k11556 
o|inlining procedure: k11580 
o|inlining procedure: k11580 
o|inlining procedure: k11586 
o|inlining procedure: k11586 
o|inlining procedure: k11639 
o|inlining procedure: k11639 
o|inlining procedure: k11693 
o|inlining procedure: k11693 
o|inlining procedure: k11751 
o|substituted constant variable: tmap2567 
o|substituted constant variable: tmap2567 
o|inlining procedure: k11751 
o|inlining procedure: k11786 
o|inlining procedure: k11786 
o|inlining procedure: k11792 
o|inlining procedure: k11792 
o|inlining procedure: k11813 
o|inlining procedure: k11813 
o|inlining procedure: k11819 
o|inlining procedure: k11819 
o|inlining procedure: k11866 
o|inlining procedure: k11866 
o|inlining procedure: k11920 
o|inlining procedure: k11920 
o|inlining procedure: k11948 
o|inlining procedure: k11948 
o|inlining procedure: k11981 
o|inlining procedure: k11981 
o|inlining procedure: k11972 
o|inlining procedure: k11972 
o|inlining procedure: k12000 
o|inlining procedure: k12000 
o|inlining procedure: k12074 
o|inlining procedure: k12074 
o|inlining procedure: k12100 
o|inlining procedure: k12100 
o|substituted constant variable: a12128 
o|substituted constant variable: a12130 
o|substituted constant variable: a12132 
o|substituted constant variable: a12134 
o|substituted constant variable: a12136 
o|substituted constant variable: a12141 
o|substituted constant variable: a12143 
o|inlining procedure: k12147 
o|inlining procedure: k12147 
o|substituted constant variable: a12160 
o|substituted constant variable: a12162 
o|substituted constant variable: a12164 
o|substituted constant variable: a12166 
o|substituted constant variable: a12174 
o|inlining procedure: k12178 
o|inlining procedure: k12178 
o|substituted constant variable: a12185 
o|substituted constant variable: a12187 
o|substituted constant variable: a12189 
o|inlining procedure: k12193 
o|inlining procedure: k12193 
o|substituted constant variable: a12206 
o|substituted constant variable: a12208 
o|substituted constant variable: a12210 
o|substituted constant variable: a12212 
o|substituted constant variable: a12214 
o|inlining procedure: k12218 
o|inlining procedure: k12218 
o|substituted constant variable: a12225 
o|substituted constant variable: a12227 
o|substituted constant variable: a12229 
o|substituted constant variable: a12231 
o|inlining procedure: k12235 
o|inlining procedure: k12235 
o|substituted constant variable: a12242 
o|substituted constant variable: a12244 
o|substituted constant variable: a12246 
o|substituted constant variable: a12248 
o|inlining procedure: k12252 
o|inlining procedure: k12252 
o|substituted constant variable: a12265 
o|substituted constant variable: a12267 
o|substituted constant variable: a12269 
o|substituted constant variable: a12271 
o|inlining procedure: k12275 
o|inlining procedure: k12275 
o|inlining procedure: k12287 
o|inlining procedure: k12287 
o|inlining procedure: k12299 
o|inlining procedure: k12299 
o|substituted constant variable: a12312 
o|substituted constant variable: a12314 
o|substituted constant variable: a12316 
o|substituted constant variable: a12318 
o|substituted constant variable: a12320 
o|substituted constant variable: a12322 
o|substituted constant variable: a12324 
o|substituted constant variable: a12326 
o|inlining procedure: k12330 
o|inlining procedure: k12330 
o|inlining procedure: k12342 
o|inlining procedure: k12342 
o|inlining procedure: k12354 
o|inlining procedure: k12354 
o|substituted constant variable: a12367 
o|substituted constant variable: a12369 
o|substituted constant variable: a12371 
o|substituted constant variable: a12373 
o|substituted constant variable: a12375 
o|substituted constant variable: a12377 
o|substituted constant variable: a12379 
o|substituted constant variable: a12381 
o|substituted constant variable: a12383 
o|substituted constant variable: a12385 
o|substituted constant variable: a12390 
o|substituted constant variable: a12392 
o|substituted constant variable: a12397 
o|substituted constant variable: a12399 
o|inlining procedure: k12403 
o|inlining procedure: k12403 
o|substituted constant variable: a12410 
o|substituted constant variable: a12412 
o|substituted constant variable: a12414 
o|inlining procedure: k12418 
o|inlining procedure: k12418 
o|inlining procedure: k12430 
o|inlining procedure: k12430 
o|inlining procedure: k12442 
o|inlining procedure: k12442 
o|substituted constant variable: a12455 
o|substituted constant variable: a12457 
o|substituted constant variable: a12459 
o|substituted constant variable: a12461 
o|substituted constant variable: a12463 
o|substituted constant variable: a12465 
o|substituted constant variable: a12467 
o|substituted constant variable: a12469 
o|substituted constant variable: a12474 
o|substituted constant variable: a12476 
o|inlining procedure: k12489 
o|inlining procedure: k12489 
o|inlining procedure: k12498 
o|inlining procedure: k12498 
o|inlining procedure: k12520 
o|inlining procedure: k12520 
o|inlining procedure: k12529 
o|inlining procedure: k12529 
o|inlining procedure: k12566 
o|inlining procedure: k12566 
o|inlining procedure: k12557 
o|inlining procedure: k12557 
o|inlining procedure: k12599 
o|inlining procedure: k12599 
o|inlining procedure: "(support.scm:1168) words->bytes" 
o|inlining procedure: k12620 
o|inlining procedure: "(support.scm:1170) words->bytes" 
o|inlining procedure: k12620 
o|inlining procedure: "(support.scm:1172) words->bytes" 
o|inlining procedure: k12656 
o|inlining procedure: k12656 
o|inlining procedure: k12647 
o|inlining procedure: k12647 
o|inlining procedure: k12675 
o|inlining procedure: "(support.scm:1180) words->bytes" 
o|inlining procedure: k12675 
o|inlining procedure: k12690 
o|inlining procedure: k12690 
o|inlining procedure: k12702 
o|inlining procedure: k12702 
o|inlining procedure: k12714 
o|inlining procedure: k12714 
o|inlining procedure: k12726 
o|inlining procedure: k12726 
o|substituted constant variable: a12733 
o|substituted constant variable: a12735 
o|substituted constant variable: a12737 
o|substituted constant variable: a12739 
o|substituted constant variable: a12741 
o|substituted constant variable: a12743 
o|substituted constant variable: a12745 
o|substituted constant variable: a12747 
o|substituted constant variable: a12749 
o|inlining procedure: k12759 
o|inlining procedure: k12759 
o|inlining procedure: k12771 
o|inlining procedure: k12771 
o|substituted constant variable: a12778 
o|substituted constant variable: a12780 
o|substituted constant variable: a12782 
o|substituted constant variable: a12784 
o|substituted constant variable: a12786 
o|inlining procedure: k12790 
o|inlining procedure: k12790 
o|inlining procedure: k12802 
o|inlining procedure: k12802 
o|inlining procedure: k12814 
o|inlining procedure: k12814 
o|substituted constant variable: a12821 
o|substituted constant variable: a12823 
o|substituted constant variable: a12825 
o|substituted constant variable: a12827 
o|substituted constant variable: a12829 
o|substituted constant variable: a12831 
o|substituted constant variable: a12833 
o|inlining procedure: k12837 
o|inlining procedure: k12837 
o|inlining procedure: k12849 
o|inlining procedure: k12849 
o|inlining procedure: k12861 
o|inlining procedure: k12861 
o|inlining procedure: k12873 
o|inlining procedure: k12873 
o|inlining procedure: k12885 
o|inlining procedure: k12885 
o|substituted constant variable: a12898 
o|substituted constant variable: a12900 
o|substituted constant variable: a12902 
o|substituted constant variable: a12904 
o|substituted constant variable: a12906 
o|substituted constant variable: a12908 
o|substituted constant variable: a12910 
o|substituted constant variable: a12912 
o|substituted constant variable: a12914 
o|substituted constant variable: a12916 
o|substituted constant variable: a12918 
o|substituted constant variable: a12920 
o|inlining procedure: k12924 
o|inlining procedure: k12924 
o|inlining procedure: k12936 
o|inlining procedure: k12936 
o|inlining procedure: k12948 
o|inlining procedure: k12948 
o|inlining procedure: k12960 
o|inlining procedure: k12960 
o|inlining procedure: k12972 
o|inlining procedure: k12972 
o|inlining procedure: k12984 
o|inlining procedure: k12984 
o|substituted constant variable: a12991 
o|substituted constant variable: a12993 
o|substituted constant variable: a12995 
o|substituted constant variable: a12997 
o|substituted constant variable: a12999 
o|substituted constant variable: a13001 
o|substituted constant variable: a13003 
o|substituted constant variable: a13005 
o|substituted constant variable: a13007 
o|substituted constant variable: a13009 
o|substituted constant variable: a13011 
o|substituted constant variable: a13013 
o|substituted constant variable: a13015 
o|inlining procedure: k13037 
o|inlining procedure: "(support.scm:1197) words->bytes" 
o|inlining procedure: k13037 
o|inlining procedure: "(support.scm:1199) words->bytes" 
o|inlining procedure: k13073 
o|inlining procedure: k13073 
o|inlining procedure: k13064 
o|inlining procedure: k13064 
o|inlining procedure: k13092 
o|inlining procedure: "(support.scm:1206) words->bytes" 
o|inlining procedure: k13092 
o|inlining procedure: "(support.scm:1207) err3002" 
o|inlining procedure: k13110 
o|inlining procedure: k13110 
o|inlining procedure: k13122 
o|inlining procedure: k13122 
o|substituted constant variable: a13135 
o|substituted constant variable: a13137 
o|substituted constant variable: a13139 
o|substituted constant variable: a13141 
o|substituted constant variable: a13143 
o|substituted constant variable: a13145 
o|inlining procedure: "(support.scm:1208) err3002" 
o|inlining procedure: k13158 
o|inlining procedure: k13158 
o|substituted constant variable: a13171 
o|substituted constant variable: a13173 
o|substituted constant variable: a13175 
o|substituted constant variable: a13177 
o|inlining procedure: k13181 
o|inlining procedure: k13181 
o|inlining procedure: k13193 
o|inlining procedure: k13193 
o|inlining procedure: k13205 
o|inlining procedure: k13205 
o|inlining procedure: k13217 
o|inlining procedure: k13217 
o|inlining procedure: k13229 
o|inlining procedure: k13229 
o|inlining procedure: k13241 
o|inlining procedure: k13241 
o|inlining procedure: k13253 
o|inlining procedure: k13253 
o|inlining procedure: k13265 
o|inlining procedure: k13265 
o|inlining procedure: k13277 
o|inlining procedure: k13277 
o|inlining procedure: k13289 
o|inlining procedure: k13289 
o|inlining procedure: k13301 
o|inlining procedure: k13301 
o|inlining procedure: k13313 
o|inlining procedure: k13313 
o|inlining procedure: k13325 
o|inlining procedure: k13325 
o|inlining procedure: k13337 
o|inlining procedure: k13337 
o|inlining procedure: k13349 
o|inlining procedure: k13349 
o|inlining procedure: k13361 
o|inlining procedure: k13361 
o|substituted constant variable: a13368 
o|substituted constant variable: a13370 
o|substituted constant variable: a13372 
o|substituted constant variable: a13374 
o|substituted constant variable: a13376 
o|substituted constant variable: a13378 
o|substituted constant variable: a13380 
o|substituted constant variable: a13382 
o|substituted constant variable: a13384 
o|substituted constant variable: a13386 
o|substituted constant variable: a13388 
o|substituted constant variable: a13390 
o|substituted constant variable: a13392 
o|substituted constant variable: a13394 
o|substituted constant variable: a13396 
o|substituted constant variable: a13398 
o|substituted constant variable: a13400 
o|substituted constant variable: a13402 
o|substituted constant variable: a13404 
o|substituted constant variable: a13406 
o|substituted constant variable: a13408 
o|substituted constant variable: a13410 
o|substituted constant variable: a13412 
o|substituted constant variable: a13414 
o|substituted constant variable: a13416 
o|substituted constant variable: a13418 
o|substituted constant variable: a13420 
o|substituted constant variable: a13422 
o|substituted constant variable: a13424 
o|substituted constant variable: a13426 
o|substituted constant variable: a13428 
o|substituted constant variable: a13430 
o|substituted constant variable: a13432 
o|inlining procedure: k13445 
o|inlining procedure: k13445 
o|inlining procedure: k13474 
o|inlining procedure: k13474 
o|inlining procedure: k13506 
o|inlining procedure: k13506 
o|inlining procedure: k13536 
o|inlining procedure: k13536 
o|inlining procedure: k13555 
o|inlining procedure: k13555 
o|inlining procedure: k13577 
o|inlining procedure: k13577 
o|substituted constant variable: a13642 
o|substituted constant variable: a13647 
o|substituted constant variable: a13649 
o|substituted constant variable: a13650 
o|inlining procedure: k13658 
o|substituted constant variable: a13668 
o|inlining procedure: k13658 
o|substituted constant variable: a13669 
o|substituted constant variable: a13679 
o|substituted constant variable: a13681 
o|substituted constant variable: a13683 
o|substituted constant variable: a13688 
o|substituted constant variable: a13690 
o|substituted constant variable: a13695 
o|substituted constant variable: a13697 
o|substituted constant variable: a13699 
o|substituted constant variable: a13704 
o|substituted constant variable: a13706 
o|inlining procedure: k13713 
o|inlining procedure: k13713 
o|inlining procedure: k13728 
o|inlining procedure: k13728 
o|inlining procedure: k13746 
o|inlining procedure: k13746 
o|substituted constant variable: a13753 
o|inlining procedure: k13754 
o|inlining procedure: k13754 
o|inlining procedure: k13769 
o|inlining procedure: k13769 
o|substituted constant variable: a13776 
o|inlining procedure: k13777 
o|inlining procedure: k13777 
o|inlining procedure: k13789 
o|inlining procedure: k13789 
o|substituted constant variable: a13796 
o|inlining procedure: k13797 
o|inlining procedure: k13797 
o|inlining procedure: k13812 
o|inlining procedure: k13812 
o|substituted constant variable: a13829 
o|inlining procedure: k13830 
o|inlining procedure: k13830 
o|inlining procedure: k13842 
o|inlining procedure: k13842 
o|inlining procedure: k13854 
o|inlining procedure: k13854 
o|inlining procedure: k13866 
o|inlining procedure: k13866 
o|inlining procedure: k13878 
o|inlining procedure: k13878 
o|inlining procedure: k13893 
o|inlining procedure: k13893 
o|inlining procedure: k13908 
o|inlining procedure: k13908 
o|inlining procedure: k13926 
o|inlining procedure: k13926 
o|inlining procedure: k13939 
o|inlining procedure: k13939 
o|inlining procedure: k13961 
o|inlining procedure: k13961 
o|inlining procedure: k13973 
o|inlining procedure: k13973 
o|substituted constant variable: a13980 
o|substituted constant variable: a13982 
o|substituted constant variable: a13984 
o|substituted constant variable: a13986 
o|inlining procedure: k13990 
o|inlining procedure: k13990 
o|substituted constant variable: a14003 
o|substituted constant variable: a14005 
o|substituted constant variable: a14007 
o|substituted constant variable: a14009 
o|substituted constant variable: a14011 
o|inlining procedure: k14015 
o|inlining procedure: k14015 
o|substituted constant variable: a14022 
o|substituted constant variable: a14024 
o|substituted constant variable: a14026 
o|substituted constant variable: a14031 
o|substituted constant variable: a14033 
o|inlining procedure: k14037 
o|inlining procedure: k14037 
o|substituted constant variable: a14050 
o|substituted constant variable: a14052 
o|substituted constant variable: a14054 
o|substituted constant variable: a14056 
o|substituted constant variable: a14058 
o|substituted constant variable: a14060 
o|inlining procedure: k14064 
o|inlining procedure: k14064 
o|inlining procedure: k14076 
o|inlining procedure: k14076 
o|inlining procedure: k14088 
o|inlining procedure: k14088 
o|substituted constant variable: a14101 
o|substituted constant variable: a14103 
o|substituted constant variable: a14105 
o|substituted constant variable: a14107 
o|substituted constant variable: a14109 
o|substituted constant variable: a14111 
o|substituted constant variable: a14113 
o|substituted constant variable: a14115 
o|substituted constant variable: a14117 
o|substituted constant variable: a14119 
o|substituted constant variable: a14121 
o|substituted constant variable: a14123 
o|substituted constant variable: a14125 
o|substituted constant variable: a14127 
o|substituted constant variable: a14129 
o|substituted constant variable: a14131 
o|inlining procedure: k14135 
o|inlining procedure: k14135 
o|inlining procedure: k14147 
o|inlining procedure: k14147 
o|inlining procedure: k14159 
o|inlining procedure: k14159 
o|substituted constant variable: a14172 
o|substituted constant variable: a14174 
o|substituted constant variable: a14176 
o|substituted constant variable: a14178 
o|substituted constant variable: a14180 
o|substituted constant variable: a14182 
o|substituted constant variable: a14184 
o|substituted constant variable: a14186 
o|substituted constant variable: a14188 
o|substituted constant variable: a14190 
o|substituted constant variable: a14192 
o|substituted constant variable: a14194 
o|substituted constant variable: a14199 
o|substituted constant variable: a14201 
o|substituted constant variable: a14206 
o|substituted constant variable: a14208 
o|inlining procedure: k14212 
o|inlining procedure: k14212 
o|inlining procedure: k14224 
o|inlining procedure: k14224 
o|inlining procedure: k14236 
o|inlining procedure: k14236 
o|substituted constant variable: a14249 
o|substituted constant variable: a14251 
o|substituted constant variable: a14253 
o|substituted constant variable: a14255 
o|substituted constant variable: a14257 
o|substituted constant variable: a14259 
o|substituted constant variable: a14261 
o|substituted constant variable: a14263 
o|substituted constant variable: a14268 
o|substituted constant variable: a14270 
o|substituted constant variable: a14272 
o|inlining procedure: k14298 
o|inlining procedure: k14322 
o|inlining procedure: k14322 
o|contracted procedure: "(support.scm:1316) g33823383" 
o|inlining procedure: k14298 
o|inlining procedure: k14386 
o|inlining procedure: k14386 
o|inlining procedure: k14409 
o|inlining procedure: k14409 
o|substituted constant variable: a14416 
o|substituted constant variable: a14418 
o|substituted constant variable: a14420 
o|substituted constant variable: a14425 
o|substituted constant variable: a14427 
o|contracted procedure: "(support.scm:1314) g33753376" 
o|contracted procedure: "(support.scm:1313) g33663367" 
o|inlining procedure: k14458 
o|inlining procedure: k14458 
o|inlining procedure: k14476 
o|inlining procedure: k14476 
o|inlining procedure: k14496 
o|inlining procedure: k14496 
o|inlining procedure: k14546 
o|inlining procedure: k14546 
o|substituted constant variable: a14577 
o|substituted constant variable: a14579 
o|substituted constant variable: a14581 
o|substituted constant variable: a14583 
o|inlining procedure: k14587 
o|inlining procedure: k14587 
o|inlining procedure: k14599 
o|inlining procedure: k14599 
o|substituted constant variable: a14606 
o|substituted constant variable: a14608 
o|substituted constant variable: a14610 
o|substituted constant variable: a14612 
o|substituted constant variable: a14614 
o|contracted procedure: "(support.scm:1334) g34513452" 
o|contracted procedure: "(support.scm:1333) g34423443" 
o|contracted procedure: "(support.scm:1332) g34393440" 
o|inlining procedure: k14632 
o|inlining procedure: k14632 
o|inlining procedure: k14664 
o|inlining procedure: k14664 
o|substituted constant variable: a14680 
o|inlining procedure: k14697 
o|inlining procedure: k14697 
o|substituted constant variable: a14759 
o|substituted constant variable: a14760 
o|inlining procedure: k14785 
o|inlining procedure: k14785 
o|inlining procedure: k14813 
o|inlining procedure: k14813 
o|contracted procedure: k14828 
o|inlining procedure: k14825 
o|inlining procedure: k14855 
o|inlining procedure: k14855 
o|inlining procedure: k14878 
o|inlining procedure: k14878 
o|inlining procedure: k14825 
o|inlining procedure: k14930 
o|inlining procedure: k14930 
o|propagated global variable: out35813585 ##sys#standard-output 
o|substituted constant variable: a14946 
o|substituted constant variable: a14947 
o|propagated global variable: out35813585 ##sys#standard-output 
o|inlining procedure: k14963 
o|inlining procedure: k14963 
o|inlining procedure: k14997 
o|inlining procedure: k14997 
o|inlining procedure: k15021 
o|inlining procedure: k15021 
o|inlining procedure: k15024 
o|inlining procedure: k15024 
o|inlining procedure: k15115 
o|substituted constant variable: a15143 
o|inlining procedure: k15115 
o|inlining procedure: k15184 
o|contracted procedure: "(support.scm:1473) g36523661" 
o|inlining procedure: k15184 
o|inlining procedure: k15219 
o|contracted procedure: "(support.scm:1472) g36213630" 
o|contracted procedure: "(support.scm:1472) g36333634" 
o|inlining procedure: k15219 
o|propagated global variable: out37093713 ##sys#standard-output 
o|substituted constant variable: a15294 
o|substituted constant variable: a15295 
o|propagated global variable: out37463750 ##sys#standard-output 
o|substituted constant variable: a15338 
o|substituted constant variable: a15339 
o|inlining procedure: k15328 
o|inlining procedure: k15355 
o|propagated global variable: out37563760 ##sys#standard-output 
o|substituted constant variable: a15362 
o|substituted constant variable: a15363 
o|inlining procedure: k15355 
o|propagated global variable: out37563760 ##sys#standard-output 
o|propagated global variable: out37463750 ##sys#standard-output 
o|inlining procedure: k15328 
o|inlining procedure: k15388 
o|inlining procedure: k15388 
o|propagated global variable: out37093713 ##sys#standard-output 
o|contracted procedure: "(support.scm:1495) g37063707" 
o|contracted procedure: "(support.scm:1494) g37033704" 
o|contracted procedure: "(support.scm:1493) g37003701" 
o|inlining procedure: k15411 
o|inlining procedure: k15436 
o|inlining procedure: k15436 
o|inlining procedure: k15411 
o|inlining procedure: k15460 
o|inlining procedure: k15460 
o|inlining procedure: k15497 
o|inlining procedure: k15497 
o|inlining procedure: k15518 
o|substituted constant variable: a15545 
o|inlining procedure: k15518 
o|inlining procedure: k15556 
o|inlining procedure: k15571 
o|inlining procedure: k15571 
o|inlining procedure: k15556 
o|contracted procedure: "(support.scm:1572) g38153816" 
o|contracted procedure: "(support.scm:1575) g38323833" 
o|inlining procedure: k15623 
o|inlining procedure: k15623 
o|substituted constant variable: a15639 
o|substituted constant variable: a15641 
o|contracted procedure: "(support.scm:1590) g38803881" 
o|contracted procedure: "(support.scm:1591) g38913892" 
o|inlining procedure: k15691 
o|inlining procedure: k15737 
o|contracted procedure: "(support.scm:1600) g39163923" 
o|inlining procedure: k15737 
o|substituted constant variable: a15762 
o|substituted constant variable: a15763 
o|inlining procedure: k15691 
o|substituted constant variable: constant25 
o|substituted constant variable: a15830 
o|substituted constant variable: a15831 
o|contracted procedure: "(support.scm:512) g10091010" 
o|contracted procedure: "(support.scm:512) g10061007" 
o|replaced variables: 2864 
o|removed binding forms: 618 
o|removed side-effect free assignment to unused variable: constant25 
o|propagated global variable: out5862 ##sys#standard-output 
o|propagated global variable: out7478 ##compiler#collected-debugging-output 
o|substituted constant variable: r479415879 
o|inlining procedure: k4808 
o|substituted constant variable: r479415880 
o|inlining procedure: k4817 
o|propagated global variable: out112116 ##compiler#collected-debugging-output 
o|substituted constant variable: r507215893 
o|converted assignments to bindings: (err212) 
o|substituted constant variable: r518115899 
o|substituted constant variable: r521515901 
o|substituted constant variable: r538715909 
o|substituted constant variable: r543215911 
o|substituted constant variable: r543215912 
o|substituted constant variable: r546915918 
o|substituted constant variable: r574315942 
o|substituted constant variable: r585715958 
o|substituted constant variable: r589515959 
o|substituted constant variable: r601315969 
o|substituted constant variable: mark652 
o|substituted constant variable: mark618 
o|substituted constant variable: mark603 
o|substituted constant variable: mark569 
o|substituted constant variable: mark554 
o|substituted constant variable: r637515992 
o|substituted constant variable: r639315994 
o|substituted constant variable: r656416004 
o|propagated global variable: out739743 ##sys#standard-output 
o|propagated global variable: out948952 ##sys#standard-output 
o|inlining procedure: k6716 
o|propagated global variable: out941945 ##sys#standard-output 
o|propagated global variable: out900904 ##sys#standard-output 
o|propagated global variable: out914918 ##sys#standard-output 
o|propagated global variable: out928932 ##sys#standard-output 
o|propagated global variable: out853857 ##sys#standard-output 
o|propagated global variable: out884888 ##sys#standard-output 
o|substituted constant variable: c1025 
o|substituted constant variable: s1027 
o|substituted constant variable: c1032 
o|substituted constant variable: s1034 
o|substituted constant variable: p1059 
o|substituted constant variable: r751616068 
o|substituted constant variable: c1095 
o|substituted constant variable: c1157 
o|substituted constant variable: c1162 
o|substituted constant variable: c1175 
o|substituted constant variable: c1180 
o|substituted constant variable: p1181 
o|substituted constant variable: s1182 
o|substituted constant variable: c1185 
o|substituted constant variable: c1258 
o|substituted constant variable: s1260 
o|substituted constant variable: c1266 
o|substituted constant variable: c1298 
o|substituted constant variable: c1346 
o|substituted constant variable: c1379 
o|substituted constant variable: mark1389 
o|substituted constant variable: c1423 
o|substituted constant variable: c1782 
o|substituted constant variable: p1783 
o|substituted constant variable: c1831 
o|substituted constant variable: c1836 
o|substituted constant variable: c1841 
o|removed side-effect free assignment to unused variable: rename1882 
o|substituted constant variable: s1910 
o|substituted constant variable: c1915 
o|substituted constant variable: c1924 
o|substituted constant variable: c1995 
o|substituted constant variable: r991916204 
o|substituted constant variable: r991916204 
o|substituted constant variable: r1049116228 
o|substituted constant variable: r1052616231 
o|substituted constant variable: r1056716233 
o|substituted constant variable: mark2205 
o|substituted constant variable: r1050916235 
o|substituted constant variable: mark2187 
o|substituted constant variable: mark2268 
o|substituted constant variable: r1073216244 
o|substituted constant variable: r1081416250 
o|substituted constant variable: r1077116252 
o|substituted constant variable: r1087016254 
o|substituted constant variable: r1091916255 
o|substituted constant variable: r1095916258 
o|substituted constant variable: r1106516264 
o|substituted constant variable: r1102016266 
o|substituted constant variable: r1114816270 
o|substituted constant variable: r1118916274 
o|substituted constant variable: r1123116278 
o|substituted constant variable: r1123116278 
o|propagated global variable: out24872491 ##sys#standard-output 
o|propagated global variable: out24972501 ##sys#standard-output 
o|propagated global variable: out25052509 ##sys#standard-output 
o|propagated global variable: out25132517 ##sys#standard-output 
o|propagated global variable: out25212525 ##sys#standard-output 
o|propagated global variable: out25292533 ##sys#standard-output 
o|substituted constant variable: r1249916370 
o|substituted constant variable: r1253016374 
o|substituted constant variable: r1260016381 
o|substituted constant variable: int34634916384 
o|substituted constant variable: int34634916391 
o|substituted constant variable: int34634916398 
o|substituted constant variable: int34634916411 
o|substituted constant variable: r1267616416 
o|removed side-effect free assignment to unused variable: err3002 
o|substituted constant variable: int34634916459 
o|substituted constant variable: int34634916466 
o|substituted constant variable: int34634916479 
o|substituted constant variable: r1365916546 
o|substituted constant variable: r1371416547 
o|substituted constant variable: r1372916549 
o|substituted constant variable: r1374716551 
o|substituted constant variable: r1374716552 
o|substituted constant variable: r1375516553 
o|substituted constant variable: r1377016555 
o|substituted constant variable: r1377016556 
o|substituted constant variable: r1377816557 
o|substituted constant variable: r1379016559 
o|substituted constant variable: r1379016560 
o|substituted constant variable: r1379816561 
o|substituted constant variable: r1383116565 
o|substituted constant variable: r1384316567 
o|substituted constant variable: r1385516569 
o|substituted constant variable: r1386716571 
o|substituted constant variable: r1387916573 
o|substituted constant variable: r1389416575 
o|substituted constant variable: r1390916577 
o|substituted constant variable: r1392716579 
o|substituted constant variable: r1394016581 
o|substituted constant variable: r1396216583 
o|substituted constant variable: r1445916619 
o|converted assignments to bindings: (resolve3551) 
o|substituted constant variable: r1493116650 
o|propagated global variable: out35813585 ##sys#standard-output 
o|substituted constant variable: r1502516658 
o|propagated global variable: out37093713 ##sys#standard-output 
o|propagated global variable: out37463750 ##sys#standard-output 
o|propagated global variable: out37563760 ##sys#standard-output 
o|substituted constant variable: r1543716683 
o|substituted constant variable: r1543716683 
o|substituted constant variable: r1555716696 
o|substituted constant variable: mark3823 
o|substituted constant variable: mark3840 
o|substituted constant variable: r1562416697 
o|substituted constant variable: mark3883 
o|substituted constant variable: mark3894 
o|substituted constant variable: r1569216702 
o|simplifications: ((let . 2)) 
o|replaced variables: 74 
o|removed binding forms: 2795 
o|substituted constant variable: r47941587916708 
o|substituted constant variable: r47941588016710 
o|inlining procedure: k6278 
o|inlining procedure: k6253 
o|inlining procedure: k6230 
o|inlining procedure: k6205 
o|inlining procedure: k6182 
o|inlining procedure: k6895 
o|inlining procedure: k6895 
o|inlining procedure: k6895 
o|inlining procedure: k6895 
o|inlining procedure: k6895 
o|inlining procedure: k6895 
o|inlining procedure: k6895 
o|inlining procedure: k6895 
o|inlining procedure: k10646 
o|inlining procedure: k10964 
o|inlining procedure: k12118 
o|inlining procedure: k12486 
o|inlining procedure: k12486 
o|inlining procedure: k12486 
o|inlining procedure: k12517 
o|inlining procedure: k12517 
o|inlining procedure: k12517 
o|inlining procedure: k14505 
o|inlining procedure: k14505 
o|inlining procedure: k15018 
o|inlining procedure: k15018 
o|inlining procedure: k15582 
o|inlining procedure: k15602 
o|inlining procedure: k15645 
o|inlining procedure: k15789 
o|replaced variables: 101 
o|removed binding forms: 205 
o|substituted constant variable: r627916972 
o|substituted constant variable: r625416975 
o|substituted constant variable: r623116976 
o|substituted constant variable: r620616979 
o|substituted constant variable: r618316980 
o|inlining procedure: k7968 
o|substituted constant variable: r1064717091 
o|substituted constant variable: r1248717109 
o|substituted constant variable: r1248717109 
o|substituted constant variable: r1248717109 
o|substituted constant variable: r1248717112 
o|substituted constant variable: r1248717112 
o|substituted constant variable: r1248717112 
o|substituted constant variable: r1248717115 
o|substituted constant variable: r1248717115 
o|substituted constant variable: r1248717115 
o|substituted constant variable: r1251817118 
o|substituted constant variable: r1251817118 
o|substituted constant variable: r1251817118 
o|substituted constant variable: r1251817121 
o|substituted constant variable: r1251817121 
o|substituted constant variable: r1251817121 
o|substituted constant variable: r1251817124 
o|substituted constant variable: r1251817124 
o|substituted constant variable: r1251817124 
o|substituted constant variable: r1501917147 
o|substituted constant variable: r1501917147 
o|substituted constant variable: r1501917147 
o|substituted constant variable: r1501917150 
o|substituted constant variable: r1501917150 
o|substituted constant variable: r1501917150 
o|substituted constant variable: r1558317165 
o|substituted constant variable: r1560317166 
o|substituted constant variable: r1564617167 
o|replaced variables: 3 
o|removed binding forms: 115 
o|removed conditional forms: 8 
o|substituted constant variable: r796917220 
o|removed binding forms: 21 
o|removed conditional forms: 1 
o|removed binding forms: 1 
o|simplifications: ((if . 70) (##core#call . 1377)) 
o|  call simplifications:
o|    ##sys#fudge
o|    read-char	3
o|    ##sys#size
o|    fx>	2
o|    write-char	6
o|    procedure?
o|    fx+	2
o|    string-length	3
o|    >	2
o|    string-ref	2
o|    list?	4
o|    vector-ref	6
o|    <
o|    *
o|    -	2
o|    first	19
o|    positive?
o|    not-pair?	5
o|    ##sys#call-with-values	5
o|    cdddr
o|    second	10
o|    third	6
o|    fourth	4
o|    caddr	4
o|    cadr	24
o|    integer?
o|    inexact->exact
o|    ##sys#check-structure	7
o|    ##sys#block-ref	4
o|    ##sys#structure?	4
o|    ##sys#make-structure	31
o|    cdar	6
o|    caar	5
o|    length	8
o|    values	4
o|    +	7
o|    ##sys#setslot	36
o|    assq	17
o|    alist-cons	8
o|    atom?
o|    ##sys#apply	2
o|    ##sys#cons	7
o|    equal?	3
o|    ##sys#list	124
o|    fixnum?	2
o|    number?	4
o|    char?	4
o|    boolean?	4
o|    eof-object?	5
o|    vector?	8
o|    member
o|    cddr	3
o|    list	50
o|    string=?	2
o|    not	12
o|    ##sys#foreign-fixnum-argument	9
o|    char-alphabetic?	2
o|    char-numeric?
o|    char=?	6
o|    char->integer
o|    fx>=	2
o|    fx<	4
o|    number->string
o|    string->list	3
o|    list->string
o|    zero?	3
o|    sub1	4
o|    string?	4
o|    eqv?
o|    eq?	375
o|    add1	4
o|    null?	41
o|    cons	61
o|    car	51
o|    cdr	20
o|    ##sys#check-list	40
o|    symbol?	18
o|    memq	12
o|    ##sys#slot	152
o|    pair?	69
o|    apply	5
o|contracted procedure: k4688 
o|contracted procedure: k4731 
o|contracted procedure: k4761 
o|contracted procedure: k4771 
o|contracted procedure: k4775 
o|contracted procedure: k4796 
o|contracted procedure: k4811 
o|contracted procedure: k4820 
o|contracted procedure: k4857 
o|propagated global variable: out112116 ##compiler#collected-debugging-output 
o|contracted procedure: k4873 
o|contracted procedure: k4883 
o|contracted procedure: k4887 
o|contracted procedure: k4896 
o|contracted procedure: k4976 
o|contracted procedure: k4994 
o|contracted procedure: k5004 
o|contracted procedure: k5008 
o|contracted procedure: k5047 
o|contracted procedure: k5051 
o|contracted procedure: k5055 
o|contracted procedure: k5074 
o|contracted procedure: k5080 
o|contracted procedure: k5100 
o|contracted procedure: k5121 
o|contracted procedure: k5133 
o|contracted procedure: k5139 
o|contracted procedure: k5145 
o|contracted procedure: k5154 
o|contracted procedure: k5164 
o|contracted procedure: k5168 
o|contracted procedure: k5183 
o|contracted procedure: k5202 
o|contracted procedure: k5189 
o|contracted procedure: k5198 
o|contracted procedure: k5217 
o|contracted procedure: k5236 
o|contracted procedure: k5223 
o|contracted procedure: k5232 
o|contracted procedure: k5245 
o|contracted procedure: k5251 
o|contracted procedure: k5275 
o|contracted procedure: k5281 
o|contracted procedure: k5335 
o|contracted procedure: k5338 
o|contracted procedure: k5348 
o|contracted procedure: k5358 
o|contracted procedure: k5372 
o|contracted procedure: k5389 
o|contracted procedure: k5392 
o|contracted procedure: k5395 
o|contracted procedure: k5401 
o|contracted procedure: k5428 
o|contracted procedure: k5434 
o|contracted procedure: k5450 
o|contracted procedure: k5471 
o|contracted procedure: k5478 
o|contracted procedure: k5481 
o|contracted procedure: k5490 
o|contracted procedure: k5496 
o|contracted procedure: k5518 
o|contracted procedure: k5525 
o|contracted procedure: k5534 
o|contracted procedure: k5549 
o|contracted procedure: k5562 
o|contracted procedure: k5569 
o|contracted procedure: k5578 
o|contracted procedure: k5637 
o|contracted procedure: k5590 
o|contracted procedure: k5633 
o|contracted procedure: k5610 
o|inlining procedure: k5607 
o|inlining procedure: k5607 
o|contracted procedure: k5652 
o|contracted procedure: k5668 
o|contracted procedure: k5694 
o|contracted procedure: k5700 
o|contracted procedure: k5706 
o|contracted procedure: k5712 
o|contracted procedure: k5718 
o|contracted procedure: k5730 
o|contracted procedure: k5745 
o|contracted procedure: k5756 
o|contracted procedure: k5762 
o|contracted procedure: k5768 
o|contracted procedure: k5774 
o|contracted procedure: k5792 
o|contracted procedure: k5798 
o|contracted procedure: k5804 
o|contracted procedure: k5810 
o|contracted procedure: k5819 
o|contracted procedure: k5832 
o|contracted procedure: k5838 
o|contracted procedure: k5859 
o|contracted procedure: k5875 
o|contracted procedure: k5897 
o|contracted procedure: k5955 
o|contracted procedure: k5903 
o|contracted procedure: k5911 
o|contracted procedure: k5936 
o|contracted procedure: k5926 
o|contracted procedure: k6015 
o|contracted procedure: k6029 
o|contracted procedure: k6021 
o|contracted procedure: k6082 
o|contracted procedure: k6088 
o|contracted procedure: k6097 
o|contracted procedure: k6107 
o|contracted procedure: k6111 
o|contracted procedure: k6121 
o|contracted procedure: k6125 
o|contracted procedure: k6168 
o|contracted procedure: k6164 
o|contracted procedure: k6136 
o|contracted procedure: k6160 
o|contracted procedure: k6156 
o|contracted procedure: k6140 
o|contracted procedure: k6152 
o|contracted procedure: k6148 
o|contracted procedure: k6144 
o|contracted procedure: k6132 
o|contracted procedure: k6220 
o|contracted procedure: k6268 
o|contracted procedure: k6293 
o|contracted procedure: k6305 
o|contracted procedure: k6315 
o|contracted procedure: k6319 
o|contracted procedure: k6284 
o|contracted procedure: k6278 
o|propagated global variable: g640642 ##compiler#internal-bindings 
o|contracted procedure: k6328 
o|contracted procedure: k6338 
o|contracted procedure: k6342 
o|contracted procedure: k6248 
o|contracted procedure: k6259 
o|contracted procedure: k6253 
o|contracted procedure: k6236 
o|contracted procedure: k6230 
o|propagated global variable: g591593 extended-bindings 
o|contracted procedure: k6351 
o|contracted procedure: k6361 
o|contracted procedure: k6365 
o|contracted procedure: k6200 
o|contracted procedure: k6211 
o|contracted procedure: k6205 
o|contracted procedure: k6188 
o|contracted procedure: k6182 
o|propagated global variable: g542544 standard-bindings 
o|contracted procedure: k6377 
o|contracted procedure: k6413 
o|contracted procedure: k6433 
o|contracted procedure: k6429 
o|contracted procedure: k6447 
o|contracted procedure: k6443 
o|contracted procedure: k6459 
o|contracted procedure: k6473 
o|contracted procedure: k6469 
o|contracted procedure: k6484 
o|contracted procedure: k6488 
o|contracted procedure: k6480 
o|contracted procedure: k6499 
o|contracted procedure: k6495 
o|contracted procedure: k6514 
o|contracted procedure: k6528 
o|contracted procedure: k6524 
o|contracted procedure: k6539 
o|contracted procedure: k6535 
o|contracted procedure: k6550 
o|contracted procedure: k6546 
o|contracted procedure: k6553 
o|contracted procedure: k6573 
o|contracted procedure: k6579 
o|contracted procedure: k6597 
o|contracted procedure: k6601 
o|contracted procedure: k6614 
o|contracted procedure: k6645 
o|contracted procedure: k6657 
o|contracted procedure: k6683 
o|contracted procedure: k6679 
o|contracted procedure: k6660 
o|contracted procedure: k6671 
o|contracted procedure: k6701 
o|contracted procedure: k6722 
o|contracted procedure: k6735 
o|contracted procedure: k6738 
o|contracted procedure: k6751 
o|contracted procedure: k6776 
o|contracted procedure: k6785 
o|contracted procedure: k6767 
o|contracted procedure: k6813 
o|contracted procedure: k6822 
o|contracted procedure: k6804 
o|contracted procedure: k6850 
o|contracted procedure: k6859 
o|contracted procedure: k6841 
o|contracted procedure: k6866 
o|contracted procedure: k6873 
o|contracted procedure: k6880 
o|contracted procedure: k6889 
o|contracted procedure: k6892 
o|contracted procedure: k6903 
o|contracted procedure: k6927 
o|contracted procedure: k6923 
o|contracted procedure: k6919 
o|contracted procedure: k6933 
o|contracted procedure: k6940 
o|contracted procedure: k6946 
o|contracted procedure: k6950 
o|contracted procedure: k6956 
o|contracted procedure: k6962 
o|contracted procedure: k6966 
o|contracted procedure: k6972 
o|contracted procedure: k6976 
o|contracted procedure: k6982 
o|contracted procedure: k7004 
o|contracted procedure: k7008 
o|contracted procedure: k7014 
o|contracted procedure: k7018 
o|contracted procedure: k7024 
o|contracted procedure: k7028 
o|contracted procedure: k7040 
o|contracted procedure: k7046 
o|contracted procedure: k7052 
o|contracted procedure: k7058 
o|contracted procedure: k7064 
o|contracted procedure: k7070 
o|contracted procedure: k7076 
o|contracted procedure: k7111 
o|contracted procedure: k7117 
o|contracted procedure: k7123 
o|contracted procedure: k7129 
o|contracted procedure: k7135 
o|contracted procedure: k7141 
o|contracted procedure: k7147 
o|contracted procedure: k7153 
o|contracted procedure: k7159 
o|contracted procedure: k7165 
o|contracted procedure: k7171 
o|contracted procedure: k7177 
o|contracted procedure: k7183 
o|contracted procedure: k7189 
o|contracted procedure: k7195 
o|contracted procedure: k7201 
o|contracted procedure: k7207 
o|contracted procedure: k7213 
o|contracted procedure: k7219 
o|contracted procedure: k7289 
o|contracted procedure: k7298 
o|contracted procedure: k7307 
o|contracted procedure: k7316 
o|contracted procedure: k7325 
o|contracted procedure: k7334 
o|contracted procedure: k7361 
o|contracted procedure: k7376 
o|contracted procedure: k7388 
o|contracted procedure: k7402 
o|contracted procedure: k7408 
o|contracted procedure: k8562 
o|contracted procedure: k7417 
o|contracted procedure: k7424 
o|contracted procedure: k7427 
o|contracted procedure: k7442 
o|contracted procedure: k7454 
o|contracted procedure: k7457 
o|contracted procedure: k7468 
o|contracted procedure: k7480 
o|contracted procedure: k7486 
o|contracted procedure: k7489 
o|contracted procedure: k7496 
o|contracted procedure: k7512 
o|contracted procedure: k7518 
o|contracted procedure: k7525 
o|contracted procedure: k7531 
o|contracted procedure: k7534 
o|contracted procedure: k7537 
o|contracted procedure: k7543 
o|contracted procedure: k7586 
o|contracted procedure: k7589 
o|contracted procedure: k7592 
o|contracted procedure: k7599 
o|contracted procedure: k7612 
o|contracted procedure: k7615 
o|contracted procedure: k7626 
o|contracted procedure: k7638 
o|contracted procedure: k7647 
o|contracted procedure: k7650 
o|contracted procedure: k7661 
o|contracted procedure: k7673 
o|contracted procedure: k7563 
o|contracted procedure: k7679 
o|contracted procedure: k7682 
o|contracted procedure: k7710 
o|contracted procedure: k7694 
o|contracted procedure: k7698 
o|contracted procedure: k7706 
o|contracted procedure: k7716 
o|contracted procedure: k7744 
o|contracted procedure: k7748 
o|contracted procedure: k7728 
o|contracted procedure: k7732 
o|contracted procedure: k7740 
o|contracted procedure: k7754 
o|contracted procedure: k7761 
o|contracted procedure: k7765 
o|contracted procedure: k7774 
o|contracted procedure: k7807 
o|contracted procedure: k7786 
o|contracted procedure: k7803 
o|contracted procedure: k7794 
o|contracted procedure: k7886 
o|contracted procedure: k7817 
o|contracted procedure: k7849 
o|contracted procedure: k7829 
o|contracted procedure: k7837 
o|contracted procedure: k7857 
o|contracted procedure: k7882 
o|contracted procedure: k7866 
o|contracted procedure: k7870 
o|contracted procedure: k7900 
o|contracted procedure: k7903 
o|contracted procedure: k7923 
o|contracted procedure: k7935 
o|contracted procedure: k7938 
o|contracted procedure: k7949 
o|contracted procedure: k7961 
o|contracted procedure: k7974 
o|contracted procedure: k7968 
o|contracted procedure: k7965 
o|contracted procedure: k7985 
o|contracted procedure: k7988 
o|contracted procedure: k8050 
o|contracted procedure: k8002 
o|contracted procedure: k8008 
o|contracted procedure: k8020 
o|contracted procedure: k8023 
o|contracted procedure: k8034 
o|contracted procedure: k8046 
o|contracted procedure: k8056 
o|contracted procedure: k8072 
o|contracted procedure: k8068 
o|contracted procedure: k8078 
o|contracted procedure: k8081 
o|contracted procedure: k8141 
o|contracted procedure: k8093 
o|contracted procedure: k8099 
o|contracted procedure: k8111 
o|contracted procedure: k8114 
o|contracted procedure: k8125 
o|contracted procedure: k8137 
o|contracted procedure: k8147 
o|contracted procedure: k8202 
o|contracted procedure: k8150 
o|contracted procedure: k8198 
o|contracted procedure: k8178 
o|contracted procedure: k8194 
o|contracted procedure: k8182 
o|contracted procedure: k8186 
o|contracted procedure: k8162 
o|contracted procedure: k8166 
o|contracted procedure: k8208 
o|contracted procedure: k8225 
o|contracted procedure: k8231 
o|contracted procedure: k8243 
o|contracted procedure: k8246 
o|contracted procedure: k8257 
o|contracted procedure: k8269 
o|contracted procedure: k8275 
o|contracted procedure: k8287 
o|contracted procedure: k8292 
o|contracted procedure: k8304 
o|contracted procedure: k8307 
o|contracted procedure: k8318 
o|contracted procedure: k8330 
o|contracted procedure: k8354 
o|contracted procedure: k8358 
o|contracted procedure: k8370 
o|contracted procedure: k8373 
o|contracted procedure: k8384 
o|contracted procedure: k8396 
o|contracted procedure: k8432 
o|contracted procedure: k8437 
o|contracted procedure: k8443 
o|contracted procedure: k8449 
o|contracted procedure: k8519 
o|contracted procedure: k8532 
o|contracted procedure: k8535 
o|contracted procedure: k8546 
o|contracted procedure: k8558 
o|contracted procedure: k8571 
o|contracted procedure: k8591 
o|contracted procedure: k8599 
o|contracted procedure: k8607 
o|contracted procedure: k8613 
o|contracted procedure: k8623 
o|contracted procedure: k8635 
o|contracted procedure: k8638 
o|contracted procedure: k8649 
o|contracted procedure: k8661 
o|contracted procedure: k8667 
o|contracted procedure: k8678 
o|contracted procedure: k8674 
o|contracted procedure: k8690 
o|contracted procedure: k8693 
o|contracted procedure: k8704 
o|contracted procedure: k8716 
o|contracted procedure: k8722 
o|contracted procedure: k8731 
o|contracted procedure: k8734 
o|contracted procedure: k8740 
o|inlining procedure: k8743 
o|contracted procedure: k8751 
o|inlining procedure: k8743 
o|contracted procedure: k8757 
o|inlining procedure: k8743 
o|contracted procedure: k8769 
o|contracted procedure: k8782 
o|contracted procedure: k8785 
o|contracted procedure: k8842 
o|contracted procedure: k8805 
o|contracted procedure: k8835 
o|contracted procedure: k8839 
o|contracted procedure: k8831 
o|contracted procedure: k8808 
o|contracted procedure: k8819 
o|contracted procedure: k8823 
o|contracted procedure: k8854 
o|contracted procedure: k8857 
o|contracted procedure: k8868 
o|contracted procedure: k8880 
o|contracted procedure: k8886 
o|contracted procedure: k8908 
o|contracted procedure: k8893 
o|contracted procedure: k8897 
o|contracted procedure: k8905 
o|contracted procedure: k8914 
o|contracted procedure: k8921 
o|contracted procedure: k8929 
o|contracted procedure: k8935 
o|contracted procedure: k8942 
o|contracted procedure: k8948 
o|contracted procedure: k8955 
o|contracted procedure: k8967 
o|contracted procedure: k8978 
o|contracted procedure: k8984 
o|contracted procedure: k8991 
o|contracted procedure: k8999 
o|contracted procedure: k9018 
o|contracted procedure: k9006 
o|contracted procedure: k9026 
o|contracted procedure: k9030 
o|contracted procedure: k9036 
o|contracted procedure: k9039 
o|contracted procedure: k9051 
o|contracted procedure: k9054 
o|contracted procedure: k9065 
o|contracted procedure: k9077 
o|contracted procedure: k9083 
o|contracted procedure: k9090 
o|contracted procedure: k9094 
o|contracted procedure: k9106 
o|contracted procedure: k9109 
o|contracted procedure: k9120 
o|contracted procedure: k9132 
o|contracted procedure: k9138 
o|contracted procedure: k9147 
o|contracted procedure: k9154 
o|contracted procedure: k9163 
o|contracted procedure: k9178 
o|contracted procedure: k9185 
o|contracted procedure: k9189 
o|contracted procedure: k9193 
o|contracted procedure: k9205 
o|contracted procedure: k9220 
o|contracted procedure: k9232 
o|contracted procedure: k9235 
o|contracted procedure: k9246 
o|contracted procedure: k9258 
o|contracted procedure: k9262 
o|contracted procedure: k9268 
o|contracted procedure: k9271 
o|contracted procedure: k9278 
o|contracted procedure: k9290 
o|contracted procedure: k9293 
o|contracted procedure: k9304 
o|contracted procedure: k9316 
o|contracted procedure: k9327 
o|contracted procedure: k9339 
o|contracted procedure: k9342 
o|contracted procedure: k9353 
o|contracted procedure: k9365 
o|contracted procedure: k9375 
o|contracted procedure: k9381 
o|contracted procedure: k9422 
o|contracted procedure: k9484 
o|contracted procedure: k9449 
o|contracted procedure: k9464 
o|contracted procedure: k9480 
o|contracted procedure: k9529 
o|contracted procedure: k9533 
o|contracted procedure: k9553 
o|contracted procedure: k9557 
o|contracted procedure: k9564 
o|contracted procedure: k9587 
o|contracted procedure: k9583 
o|contracted procedure: k9579 
o|contracted procedure: k9597 
o|contracted procedure: k9609 
o|contracted procedure: k9612 
o|contracted procedure: k9623 
o|contracted procedure: k9635 
o|contracted procedure: k9641 
o|contracted procedure: k9644 
o|contracted procedure: k9664 
o|contracted procedure: k9672 
o|contracted procedure: k9680 
o|contracted procedure: k9686 
o|contracted procedure: k9700 
o|contracted procedure: k9703 
o|contracted procedure: k9725 
o|contracted procedure: k9737 
o|contracted procedure: k9741 
o|contracted procedure: k9749 
o|contracted procedure: k9757 
o|contracted procedure: k9763 
o|contracted procedure: k9766 
o|contracted procedure: k9775 
o|contracted procedure: k9790 
o|contracted procedure: k9794 
o|contracted procedure: k9802 
o|contracted procedure: k9806 
o|contracted procedure: k9812 
o|contracted procedure: k9819 
o|contracted procedure: k9833 
o|contracted procedure: k9906 
o|contracted procedure: k9914 
o|contracted procedure: k9851 
o|contracted procedure: k9860 
o|contracted procedure: k9872 
o|contracted procedure: k9875 
o|contracted procedure: k9886 
o|contracted procedure: k9898 
o|contracted procedure: k9925 
o|contracted procedure: k9974 
o|contracted procedure: k9937 
o|contracted procedure: k9967 
o|contracted procedure: k9971 
o|contracted procedure: k9963 
o|contracted procedure: k9940 
o|contracted procedure: k9951 
o|contracted procedure: k9955 
o|contracted procedure: k9986 
o|contracted procedure: k9989 
o|contracted procedure: k10000 
o|contracted procedure: k10012 
o|contracted procedure: k10033 
o|contracted procedure: k10045 
o|contracted procedure: k10048 
o|contracted procedure: k10059 
o|contracted procedure: k10071 
o|contracted procedure: k10130 
o|contracted procedure: k10093 
o|contracted procedure: k10123 
o|contracted procedure: k10127 
o|contracted procedure: k10119 
o|contracted procedure: k10096 
o|contracted procedure: k10107 
o|contracted procedure: k10111 
o|contracted procedure: k10148 
o|contracted procedure: k10184 
o|contracted procedure: k10193 
o|contracted procedure: k10202 
o|contracted procedure: k10223 
o|contracted procedure: k10236 
o|contracted procedure: k10245 
o|contracted procedure: k10248 
o|contracted procedure: k10227 
o|contracted procedure: k10260 
o|contracted procedure: k10263 
o|contracted procedure: k10274 
o|contracted procedure: k10286 
o|contracted procedure: k10307 
o|contracted procedure: k10311 
o|contracted procedure: k10317 
o|contracted procedure: k10329 
o|contracted procedure: k10332 
o|contracted procedure: k10343 
o|contracted procedure: k10355 
o|contracted procedure: k10381 
o|contracted procedure: k10393 
o|contracted procedure: k10403 
o|contracted procedure: k10407 
o|contracted procedure: k10410 
o|contracted procedure: k10416 
o|contracted procedure: k10454 
o|contracted procedure: k10464 
o|contracted procedure: k10468 
o|contracted procedure: k10484 
o|contracted procedure: k10608 
o|contracted procedure: k10499 
o|contracted procedure: k10502 
o|contracted procedure: k10511 
o|contracted procedure: k10588 
o|contracted procedure: k10519 
o|contracted procedure: k10546 
o|contracted procedure: k10554 
o|contracted procedure: k10550 
o|contracted procedure: k10563 
o|contracted procedure: k10569 
o|contracted procedure: k10576 
o|contracted procedure: k10599 
o|contracted procedure: k10595 
o|contracted procedure: k10641 
o|contracted procedure: k10665 
o|contracted procedure: k10652 
o|contracted procedure: k10646 
o|contracted procedure: k10673 
o|contracted procedure: k10682 
o|contracted procedure: k10694 
o|contracted procedure: k10703 
o|contracted procedure: k10707 
o|contracted procedure: k10719 
o|contracted procedure: k10728 
o|contracted procedure: k10745 
o|contracted procedure: k10749 
o|contracted procedure: k10758 
o|contracted procedure: k10859 
o|contracted procedure: k10863 
o|contracted procedure: k10767 
o|contracted procedure: k10785 
o|contracted procedure: k10789 
o|contracted procedure: k10798 
o|contracted procedure: k10807 
o|contracted procedure: k10816 
o|contracted procedure: k10833 
o|contracted procedure: k10837 
o|contracted procedure: k10846 
o|contracted procedure: k10850 
o|contracted procedure: k10881 
o|contracted procedure: k10890 
o|contracted procedure: k10907 
o|contracted procedure: k10915 
o|contracted procedure: k10921 
o|contracted procedure: k10930 
o|contracted procedure: k10955 
o|contracted procedure: k10933 
o|contracted procedure: k10961 
o|contracted procedure: k10964 
o|contracted procedure: k10979 
o|contracted procedure: k10985 
o|contracted procedure: k11010 
o|contracted procedure: k11013 
o|contracted procedure: k11119 
o|contracted procedure: k11016 
o|contracted procedure: k11038 
o|contracted procedure: k11044 
o|contracted procedure: k11052 
o|contracted procedure: k11055 
o|contracted procedure: k11094 
o|contracted procedure: k11061 
o|contracted procedure: k11085 
o|contracted procedure: k11076 
o|contracted procedure: k11067 
o|contracted procedure: k11100 
o|contracted procedure: k11112 
o|contracted procedure: k11150 
o|contracted procedure: k11157 
o|contracted procedure: k11191 
o|contracted procedure: k11213 
o|contracted procedure: k11216 
o|contracted procedure: k11237 
o|contracted procedure: k11230 
o|inlining procedure: k11226 
o|inlining procedure: k11226 
o|contracted procedure: k11256 
o|contracted procedure: k11286 
o|contracted procedure: k11289 
o|contracted procedure: k11295 
o|contracted procedure: k11299 
o|contracted procedure: k11305 
o|contracted procedure: k11309 
o|contracted procedure: k11328 
o|contracted procedure: k11315 
o|contracted procedure: k11319 
o|contracted procedure: k11336 
o|contracted procedure: k11344 
o|contracted procedure: k11340 
o|contracted procedure: k11355 
o|contracted procedure: k11367 
o|contracted procedure: k11377 
o|contracted procedure: k11381 
o|contracted procedure: k11509 
o|contracted procedure: k11521 
o|contracted procedure: k11531 
o|contracted procedure: k11535 
o|contracted procedure: k11559 
o|contracted procedure: k11562 
o|contracted procedure: k11574 
o|contracted procedure: k11589 
o|contracted procedure: k11604 
o|contracted procedure: k11607 
o|contracted procedure: k11636 
o|contracted procedure: k11617 
o|contracted procedure: k11625 
o|contracted procedure: k11629 
o|contracted procedure: k11621 
o|contracted procedure: k11642 
o|contracted procedure: k11645 
o|contracted procedure: k11657 
o|contracted procedure: k11690 
o|contracted procedure: k11667 
o|contracted procedure: k11679 
o|contracted procedure: k11671 
o|contracted procedure: k11686 
o|contracted procedure: k11696 
o|contracted procedure: k11706 
o|contracted procedure: k11712 
o|contracted procedure: k11748 
o|contracted procedure: k11725 
o|contracted procedure: k11737 
o|contracted procedure: k11729 
o|contracted procedure: k11744 
o|contracted procedure: k11754 
o|contracted procedure: k11771 
o|contracted procedure: k11767 
o|contracted procedure: k11780 
o|contracted procedure: k11795 
o|contracted procedure: k11807 
o|contracted procedure: k11822 
o|contracted procedure: k11834 
o|contracted procedure: k11863 
o|contracted procedure: k11847 
o|contracted procedure: k11855 
o|contracted procedure: k11859 
o|contracted procedure: k11851 
o|contracted procedure: k11869 
o|contracted procedure: k11878 
o|contracted procedure: k11917 
o|contracted procedure: k11891 
o|contracted procedure: k11903 
o|contracted procedure: k11895 
o|contracted procedure: k11913 
o|contracted procedure: k11923 
o|contracted procedure: k11939 
o|contracted procedure: k11945 
o|contracted procedure: k11955 
o|contracted procedure: k11966 
o|contracted procedure: k11962 
o|contracted procedure: k11984 
o|contracted procedure: k11981 
o|contracted procedure: k11996 
o|contracted procedure: k12003 
o|contracted procedure: k12032 
o|contracted procedure: k12016 
o|contracted procedure: k12024 
o|contracted procedure: k12028 
o|contracted procedure: k12020 
o|contracted procedure: k12038 
o|contracted procedure: k12041 
o|contracted procedure: k12071 
o|contracted procedure: k12051 
o|contracted procedure: k12067 
o|contracted procedure: k12059 
o|contracted procedure: k12063 
o|contracted procedure: k12055 
o|contracted procedure: k12077 
o|contracted procedure: k12084 
o|contracted procedure: k12090 
o|contracted procedure: k12097 
o|contracted procedure: k12103 
o|contracted procedure: k12115 
o|contracted procedure: k12118 
o|contracted procedure: k12144 
o|contracted procedure: k12150 
o|contracted procedure: k12167 
o|contracted procedure: k12175 
o|contracted procedure: k12190 
o|contracted procedure: k12196 
o|contracted procedure: k12215 
o|contracted procedure: k12232 
o|contracted procedure: k12249 
o|contracted procedure: k12255 
o|contracted procedure: k12272 
o|contracted procedure: k12278 
o|contracted procedure: k12284 
o|contracted procedure: k12290 
o|contracted procedure: k12296 
o|contracted procedure: k12302 
o|contracted procedure: k12327 
o|contracted procedure: k12333 
o|contracted procedure: k12339 
o|contracted procedure: k12345 
o|contracted procedure: k12351 
o|contracted procedure: k12357 
o|contracted procedure: k12400 
o|contracted procedure: k12415 
o|contracted procedure: k12421 
o|contracted procedure: k12427 
o|contracted procedure: k12433 
o|contracted procedure: k12439 
o|contracted procedure: k12445 
o|contracted procedure: k12492 
o|contracted procedure: k12504 
o|contracted procedure: k12511 
o|contracted procedure: k12486 
o|contracted procedure: k12523 
o|contracted procedure: k12535 
o|contracted procedure: k12542 
o|contracted procedure: k12517 
o|contracted procedure: k12569 
o|contracted procedure: k12566 
o|contracted procedure: k12578 
o|contracted procedure: k12602 
o|contracted procedure: k12611 
o|contracted procedure: k552516388 
o|contracted procedure: k12623 
o|contracted procedure: k552516395 
o|contracted procedure: k12635 
o|contracted procedure: k552516402 
o|contracted procedure: k12659 
o|contracted procedure: k12656 
o|contracted procedure: k12671 
o|contracted procedure: k12678 
o|contracted procedure: k552516415 
o|contracted procedure: k12687 
o|contracted procedure: k12693 
o|contracted procedure: k12699 
o|contracted procedure: k12705 
o|contracted procedure: k12711 
o|contracted procedure: k12717 
o|contracted procedure: k12723 
o|contracted procedure: k12750 
o|contracted procedure: k12756 
o|contracted procedure: k12762 
o|contracted procedure: k12768 
o|contracted procedure: k12787 
o|contracted procedure: k12793 
o|contracted procedure: k12799 
o|contracted procedure: k12805 
o|contracted procedure: k12811 
o|contracted procedure: k12834 
o|contracted procedure: k12840 
o|contracted procedure: k12846 
o|contracted procedure: k12852 
o|contracted procedure: k12858 
o|contracted procedure: k12864 
o|contracted procedure: k12870 
o|contracted procedure: k12876 
o|contracted procedure: k12882 
o|contracted procedure: k12888 
o|contracted procedure: k12921 
o|contracted procedure: k12927 
o|contracted procedure: k12933 
o|contracted procedure: k12939 
o|contracted procedure: k12945 
o|contracted procedure: k12951 
o|contracted procedure: k12957 
o|contracted procedure: k12963 
o|contracted procedure: k12969 
o|contracted procedure: k12975 
o|contracted procedure: k12981 
o|contracted procedure: k13040 
o|contracted procedure: k552516463 
o|contracted procedure: k13052 
o|contracted procedure: k552516470 
o|contracted procedure: k13076 
o|contracted procedure: k13073 
o|contracted procedure: k13088 
o|contracted procedure: k13095 
o|contracted procedure: k552516483 
o|contracted procedure: k13107 
o|contracted procedure: k13113 
o|contracted procedure: k13119 
o|contracted procedure: k13125 
o|contracted procedure: k13149 
o|contracted procedure: k13155 
o|contracted procedure: k13161 
o|contracted procedure: k13178 
o|contracted procedure: k13184 
o|contracted procedure: k13190 
o|contracted procedure: k13196 
o|contracted procedure: k13202 
o|contracted procedure: k13208 
o|contracted procedure: k13214 
o|contracted procedure: k13220 
o|contracted procedure: k13226 
o|contracted procedure: k13232 
o|contracted procedure: k13238 
o|contracted procedure: k13244 
o|contracted procedure: k13250 
o|contracted procedure: k13256 
o|contracted procedure: k13262 
o|contracted procedure: k13268 
o|contracted procedure: k13274 
o|contracted procedure: k13280 
o|contracted procedure: k13286 
o|contracted procedure: k13292 
o|contracted procedure: k13298 
o|contracted procedure: k13304 
o|contracted procedure: k13310 
o|contracted procedure: k13316 
o|contracted procedure: k13322 
o|contracted procedure: k13328 
o|contracted procedure: k13334 
o|contracted procedure: k13340 
o|contracted procedure: k13346 
o|contracted procedure: k13352 
o|contracted procedure: k13358 
o|contracted procedure: k13448 
o|contracted procedure: k13451 
o|contracted procedure: k13458 
o|contracted procedure: k13464 
o|contracted procedure: k13471 
o|contracted procedure: k13477 
o|contracted procedure: k13480 
o|contracted procedure: k13487 
o|contracted procedure: k13493 
o|contracted procedure: k13496 
o|contracted procedure: k13503 
o|contracted procedure: k13509 
o|contracted procedure: k13520 
o|contracted procedure: k13516 
o|contracted procedure: k13526 
o|contracted procedure: k13533 
o|contracted procedure: k13539 
o|contracted procedure: k13546 
o|contracted procedure: k13552 
o|contracted procedure: k13565 
o|contracted procedure: k13652 
o|contracted procedure: k13571 
o|contracted procedure: k13574 
o|contracted procedure: k13580 
o|contracted procedure: k13583 
o|contracted procedure: k13621 
o|contracted procedure: k13593 
o|contracted procedure: k13617 
o|contracted procedure: k13601 
o|contracted procedure: k13609 
o|contracted procedure: k13613 
o|contracted procedure: k13605 
o|contracted procedure: k13597 
o|contracted procedure: k13627 
o|contracted procedure: k13634 
o|contracted procedure: k13638 
o|contracted procedure: k13675 
o|contracted procedure: k13655 
o|contracted procedure: k13671 
o|contracted procedure: k13661 
o|contracted procedure: k13665 
o|contracted procedure: k13716 
o|contracted procedure: k13722 
o|contracted procedure: k13725 
o|contracted procedure: k13731 
o|contracted procedure: k13740 
o|contracted procedure: k13743 
o|contracted procedure: k13749 
o|contracted procedure: k13757 
o|contracted procedure: k13760 
o|contracted procedure: k13766 
o|contracted procedure: k13772 
o|contracted procedure: k13780 
o|contracted procedure: k13786 
o|contracted procedure: k13792 
o|contracted procedure: k13800 
o|contracted procedure: k13806 
o|contracted procedure: k13815 
o|contracted procedure: k13822 
o|contracted procedure: k13833 
o|contracted procedure: k13839 
o|contracted procedure: k13845 
o|contracted procedure: k13851 
o|contracted procedure: k13857 
o|contracted procedure: k13863 
o|contracted procedure: k13869 
o|contracted procedure: k13875 
o|contracted procedure: k13881 
o|contracted procedure: k13890 
o|contracted procedure: k13896 
o|contracted procedure: k13902 
o|contracted procedure: k13911 
o|contracted procedure: k13914 
o|contracted procedure: k13920 
o|contracted procedure: k13929 
o|contracted procedure: k13935 
o|contracted procedure: k13942 
o|contracted procedure: k13951 
o|contracted procedure: k13958 
o|contracted procedure: k13964 
o|contracted procedure: k13970 
o|contracted procedure: k13973 
o|contracted procedure: k13987 
o|contracted procedure: k13993 
o|contracted procedure: k14012 
o|contracted procedure: k14034 
o|contracted procedure: k14040 
o|contracted procedure: k14061 
o|contracted procedure: k14067 
o|contracted procedure: k14073 
o|contracted procedure: k14079 
o|contracted procedure: k14085 
o|contracted procedure: k14091 
o|contracted procedure: k14132 
o|contracted procedure: k14138 
o|contracted procedure: k14144 
o|contracted procedure: k14150 
o|contracted procedure: k14156 
o|contracted procedure: k14162 
o|contracted procedure: k14209 
o|contracted procedure: k14215 
o|contracted procedure: k14221 
o|contracted procedure: k14227 
o|contracted procedure: k14233 
o|contracted procedure: k14239 
o|contracted procedure: k14287 
o|contracted procedure: k14295 
o|contracted procedure: k14301 
o|contracted procedure: k14304 
o|contracted procedure: k14365 
o|contracted procedure: k14307 
o|contracted procedure: k14313 
o|contracted procedure: k14325 
o|contracted procedure: k14335 
o|contracted procedure: k14339 
o|contracted procedure: k14346 
o|contracted procedure: k14349 
o|contracted procedure: k14356 
o|contracted procedure: k14371 
o|contracted procedure: k14377 
o|contracted procedure: k14389 
o|contracted procedure: k14399 
o|contracted procedure: k14403 
o|contracted procedure: k14406 
o|contracted procedure: k14439 
o|contracted procedure: k14447 
o|contracted procedure: k14455 
o|contracted procedure: k14461 
o|contracted procedure: k14470 
o|contracted procedure: k14473 
o|contracted procedure: k14479 
o|contracted procedure: k14499 
o|contracted procedure: k14502 
o|contracted procedure: k14515 
o|contracted procedure: k1451217136 
o|contracted procedure: k1451217140 
o|contracted procedure: k14525 
o|contracted procedure: k14535 
o|contracted procedure: k14543 
o|contracted procedure: k14549 
o|contracted procedure: k14556 
o|contracted procedure: k14566 
o|contracted procedure: k14584 
o|contracted procedure: k14590 
o|contracted procedure: k14596 
o|contracted procedure: k14623 
o|contracted procedure: k14635 
o|contracted procedure: k14645 
o|contracted procedure: k14649 
o|contracted procedure: k14682 
o|contracted procedure: k14661 
o|contracted procedure: k14673 
o|contracted procedure: k14677 
o|contracted procedure: k14724 
o|contracted procedure: k14688 
o|contracted procedure: k14700 
o|contracted procedure: k14720 
o|contracted procedure: k14706 
o|contracted procedure: k14716 
o|contracted procedure: k14742 
o|contracted procedure: k14788 
o|inlining procedure: k14785 
o|contracted procedure: k14837 
o|contracted procedure: k14845 
o|contracted procedure: k14858 
o|contracted procedure: k14869 
o|contracted procedure: k14881 
o|contracted procedure: k14895 
o|contracted procedure: k14899 
o|contracted procedure: k14966 
o|contracted procedure: k14969 
o|contracted procedure: k14972 
o|contracted procedure: k14991 
o|contracted procedure: k14987 
o|contracted procedure: k15000 
o|contracted procedure: k15046 
o|contracted procedure: k15039 
o|contracted procedure: k15015 
o|contracted procedure: k15027 
o|contracted procedure: k15030 
o|contracted procedure: k15033 
o|contracted procedure: k15066 
o|contracted procedure: k15175 
o|contracted procedure: k15072 
o|contracted procedure: k15112 
o|contracted procedure: k15118 
o|contracted procedure: k15145 
o|contracted procedure: k15127 
o|contracted procedure: k15137 
o|contracted procedure: k15187 
o|contracted procedure: k15213 
o|contracted procedure: k15209 
o|contracted procedure: k15190 
o|contracted procedure: k15201 
o|contracted procedure: k15222 
o|contracted procedure: k15225 
o|contracted procedure: k15236 
o|contracted procedure: k15248 
o|contracted procedure: k15063 
o|contracted procedure: k15268 
o|contracted procedure: k15276 
o|contracted procedure: k15284 
o|contracted procedure: k15290 
o|contracted procedure: k15319 
o|contracted procedure: k15325 
o|contracted procedure: k15334 
o|contracted procedure: k15358 
o|contracted procedure: k15374 
o|contracted procedure: k15378 
o|contracted procedure: k15382 
o|contracted procedure: k15391 
o|contracted procedure: k15401 
o|contracted procedure: k15405 
o|contracted procedure: k15421 
o|inlining procedure: k15425 
o|inlining procedure: k15425 
o|contracted procedure: k15441 
o|contracted procedure: k15448 
o|contracted procedure: k15463 
o|contracted procedure: k15476 
o|contracted procedure: k15500 
o|contracted procedure: k15509 
o|contracted procedure: k15521 
o|contracted procedure: k15530 
o|contracted procedure: k15559 
o|contracted procedure: k15565 
o|contracted procedure: k15568 
o|contracted procedure: k15588 
o|contracted procedure: k15582 
o|contracted procedure: k15608 
o|contracted procedure: k15602 
o|contracted procedure: k15626 
o|contracted procedure: k15632 
o|contracted procedure: k15651 
o|contracted procedure: k15645 
o|contracted procedure: k15740 
o|contracted procedure: k15750 
o|contracted procedure: k15754 
o|contracted procedure: k15705 
o|contracted procedure: k15719 
o|contracted procedure: k15723 
o|contracted procedure: k15802 
o|contracted procedure: k15786 
o|contracted procedure: k15853 
o|contracted procedure: k15862 
o|simplifications: ((let . 161)) 
o|removed binding forms: 1138 
o|inlining procedure: k6663 
o|inlining procedure: k6663 
o|inlining procedure: "(support.scm:523) varnode" 
o|inlining procedure: k7460 
o|inlining procedure: k7460 
o|inlining procedure: "(support.scm:531) qnode" 
o|inlining procedure: "(support.scm:531) qnode" 
o|inlining procedure: k7618 
o|inlining procedure: k7618 
o|inlining procedure: k7653 
o|inlining procedure: k7653 
o|inlining procedure: k7941 
o|inlining procedure: k7941 
o|inlining procedure: k8026 
o|inlining procedure: k8026 
o|inlining procedure: k8117 
o|inlining procedure: k8117 
o|inlining procedure: k8249 
o|inlining procedure: k8249 
o|inlining procedure: k8310 
o|inlining procedure: k8310 
o|inlining procedure: k8376 
o|inlining procedure: k8376 
o|inlining procedure: k8538 
o|inlining procedure: k8538 
o|inlining procedure: k8641 
o|inlining procedure: k8641 
o|inlining procedure: k8696 
o|inlining procedure: k8696 
o|inlining procedure: k8860 
o|inlining procedure: k8860 
o|inlining procedure: k9057 
o|inlining procedure: k9057 
o|inlining procedure: k9112 
o|inlining procedure: k9112 
o|inlining procedure: k9238 
o|inlining procedure: k9238 
o|inlining procedure: k9296 
o|inlining procedure: k9296 
o|inlining procedure: k9345 
o|inlining procedure: k9345 
o|inlining procedure: "(support.scm:697) qnode" 
o|inlining procedure: k9561 
o|inlining procedure: k9615 
o|inlining procedure: k9615 
o|inlining procedure: "(support.scm:721) varnode" 
o|inlining procedure: k9878 
o|inlining procedure: k9878 
o|inlining procedure: k9992 
o|inlining procedure: k9992 
o|inlining procedure: k10051 
o|inlining procedure: k10051 
o|inlining procedure: "(support.scm:763) node-subexpressions-set!" 
o|inlining procedure: "(support.scm:762) node-parameters-set!" 
o|inlining procedure: "(support.scm:761) node-class-set!" 
o|inlining procedure: k10266 
o|inlining procedure: k10266 
o|inlining procedure: k10335 
o|inlining procedure: k10335 
o|inlining procedure: k12681 
o|inlining procedure: k12681 
o|inlining procedure: k12681 
o|inlining procedure: k12681 
o|inlining procedure: k12681 
o|inlining procedure: k12681 
o|inlining procedure: k12681 
o|inlining procedure: k12681 
o|inlining procedure: k12681 
o|inlining procedure: k15193 
o|inlining procedure: k15193 
o|inlining procedure: k15228 
o|inlining procedure: k15228 
o|replaced variables: 368 
o|removed binding forms: 4 
o|substituted constant variable: const102918325 
o|simplifications: ((if . 17)) 
o|replaced variables: 30 
o|removed binding forms: 295 
o|inlining procedure: k9561 
o|contracted procedure: k15244 
o|replaced variables: 108 
o|removed binding forms: 26 
o|removed binding forms: 28 
o|replaced variables: 2 
o|removed binding forms: 1 
o|direct leaf routine/allocation: loop509 0 
o|direct leaf routine/allocation: g22932294 0 
o|direct leaf routine/allocation: g24512458 20 
o|converted assignments to bindings: (loop509) 
o|contracted procedure: "(support.scm:959) k11370" 
o|simplifications: ((let . 1)) 
o|removed binding forms: 1 
o|customizable procedures: (for-each-loop39153930 loop3794 k15414 g37233730 for-each-loop37223740 doloop37533754 loop3692 map-loop36153636 map-loop36463667 resolve3551 loop3563 loop3504 k14667 g34793486 for-each-loop34783489 k14464 walkeach3434 walk3433 k14374 for-each-loop34123422 k14342 k14310 for-each-loop33883398 k13734 k13809 k13884 k13905 k13923 k13945 k13558 k13043 k13055 k13098 g31243125 k12605 k12614 k12626 k12638 g29672968 g28482849 k11577 k11592 k11715 k11757 k11783 k11810 k11837 k11881 k11926 k12006 repeat2572 g27812782 k11899 k11733 k11675 for-each-loop25482560 for-each-loop24502472 k11176 k11135 k10924 matchn2284 loop2313 match12283 resolve2282 loop2258 k10505 k10542 for-each-loop22092221 for-each-loop22312249 map-loop21482165 map-loop21092129 rec2076 k10099 map-loop18531872 g20462055 map-loop20402065 g19401949 map-loop19341954 k9943 map-loop19641983 g20072016 map-loop20012026 walk1883 map-loop18011818 k9537 fold1778 k8616 k9208 map-loop17501767 map-loop17241741 map-loop16951712 loop1676 map-loop16521669 map-loop16261643 loop1617 map-loop15771594 k8811 map-loop15561601 map-loop15141531 map-loop14851502 map-loop14281445 k8211 k8400 map-loop13971414 map-loop13511368 map-loop13201337 map-loop12711288 map-loop12321249 k7917 map-loop11981215 loop1165 map-loop11001118 g11331142 map-loop11271145 k7499 map-loop10631080 k6689 k6906 k6985 loop785 k6754 k6791 k6828 map-loop746763 k6585 g733734 k6508 for-each-loop535577 for-each-loop584626 for-each-loop633659 tmp14292 tmp24293 k5914 loop464 k5786 loop377 fold370 k5552 k5404 k5411 loop306 loop289 loop239 loop228 loop213 err212 loop201 k4965 g170177 for-each-loop169187 test-mode97 collect96 g102109 for-each-loop101121 text43 dump44 for-each-loop4765) 
o|calls to known targets: 583 
o|identified direct recursive calls: f_5128 1 
o|identified direct recursive calls: f_5178 1 
o|identified direct recursive calls: f_5212 1 
o|identified direct recursive calls: f_5330 1 
o|identified direct recursive calls: f_5601 1 
o|identified direct recursive calls: f_6077 1 
o|identified direct recursive calls: f_6652 2 
o|identified direct recursive calls: f_7383 4 
o|identified direct recursive calls: f_9657 1 
o|identified direct recursive calls: f_10143 1 
o|identified direct recursive calls: f_10714 1 
o|identified direct recursive calls: f_11362 1 
o|identified direct recursive calls: f_14695 1 
o|identified direct recursive calls: f_15182 2 
o|identified direct recursive calls: f_15217 2 
o|fast box initializations: 86 
o|dropping unused closure argument: f_4891 
o|dropping unused closure argument: f_6077 
o|dropping unused closure argument: f_14808 
*/
/* end of file */
