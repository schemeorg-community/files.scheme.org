/* Generated from chicken-install.scm by the CHICKEN compiler
   http://www.call-cc.org
   2014-06-02 16:40
   Version 4.9.0 (rev 3f195ba)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2014-06-02 on yves (Linux)
   command line: chicken-install.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -no-lambda-info -local -no-trace -output-file chicken-install.c
   used units: library eval chicken_2dsyntax srfi_2d1 posix data_2dstructures utils irregex ports extras srfi_2d13 files chicken_2dsyntax chicken_2dffi_2dsyntax
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_chicken_2dsyntax_toplevel)
C_externimport void C_ccall C_chicken_2dsyntax_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_2d1_toplevel)
C_externimport void C_ccall C_srfi_2d1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_2dstructures_toplevel)
C_externimport void C_ccall C_data_2dstructures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_irregex_toplevel)
C_externimport void C_ccall C_irregex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_2d13_toplevel)
C_externimport void C_ccall C_srfi_2d13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_chicken_2dsyntax_toplevel)
C_externimport void C_ccall C_chicken_2dsyntax_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_chicken_2dffi_2dsyntax_toplevel)
C_externimport void C_ccall C_chicken_2dffi_2dsyntax_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[442];
static double C_possibly_force_alignment;


C_noret_decl(f_4622)
static void C_ccall f_4622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5323)
static void C_ccall f_5323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5326)
static void C_ccall f_5326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5329)
static void C_ccall f_5329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7393)
static void C_ccall f_7393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5320)
static void C_ccall f_5320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5507)
static void C_fcall f_5507(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4306)
static void C_ccall f_4306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5381)
static void C_ccall f_5381(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4569)
static void C_fcall f_4569(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5379)
static void C_ccall f_5379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5375)
static void C_ccall f_5375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4598)
static void C_ccall f_4598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4582)
static void C_ccall f_4582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2619)
static void C_ccall f_2619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4534)
static void C_ccall f_4534(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4180)
static void C_ccall f_4180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4183)
static void C_ccall f_4183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2608)
static void C_ccall f_2608(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7034)
static void C_ccall f_7034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2519)
static void C_ccall f_2519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4544)
static void C_ccall f_4544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2510)
static void C_ccall f_2510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2516)
static void C_ccall f_2516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2528)
static void C_ccall f_2528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2522)
static void C_ccall f_2522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2525)
static void C_ccall f_2525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6493)
static void C_ccall f_6493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4512)
static void C_fcall f_4512(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5113)
static void C_ccall f_5113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5997)
static void C_fcall f_5997(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3806)
static void C_ccall f_3806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3803)
static void C_ccall f_3803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3800)
static void C_ccall f_3800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5989)
static void C_ccall f_5989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5986)
static void C_ccall f_5986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5338)
static void C_fcall f_5338(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5169)
static void C_ccall f_5169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5163)
static void C_ccall f_5163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4009)
static void C_ccall f_4009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5958)
static void C_ccall f_5958(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5952)
static void C_ccall f_5952(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3846)
static void C_ccall f_3846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5139)
static void C_ccall f_5139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5134)
static void C_ccall f_5134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5940)
static void C_ccall f_5940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5129)
static void C_ccall f_5129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7416)
static void C_ccall f_7416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5120)
static void C_ccall f_5120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7420)
static void C_ccall f_7420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4393)
static void C_ccall f_4393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4395)
static void C_fcall f_4395(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3574)
static void C_ccall f_3574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3560)
static void C_ccall f_3560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3566)
static void C_ccall f_3566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5911)
static void C_fcall f_5911(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3883)
static void C_fcall f_3883(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7408)
static void C_ccall f_7408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7402)
static void C_ccall f_7402(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7402)
static void C_ccall f_7402r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7400)
static void C_ccall f_7400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3595)
static void C_ccall f_3595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4065)
static void C_ccall f_4065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6893)
static void C_ccall f_6893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3877)
static void C_ccall f_3877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3873)
static void C_fcall f_3873(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3589)
static void C_ccall f_3589(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3589)
static void C_ccall f_3589r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3652)
static void C_ccall f_3652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3866)
static void C_ccall f_3866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5156)
static void C_ccall f_5156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3779)
static void C_ccall f_3779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3852)
static void C_ccall f_3852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3647)
static void C_fcall f_3647(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3644)
static void C_ccall f_3644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3769)
static void C_ccall f_3769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5145)
static void C_ccall f_5145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3765)
static void C_fcall f_3765(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4032)
static void C_ccall f_4032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3631)
static void C_ccall f_3631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3791)
static void C_ccall f_3791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3797)
static void C_ccall f_3797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3794)
static void C_ccall f_3794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4022)
static void C_fcall f_4022(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3788)
static void C_ccall f_3788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3785)
static void C_ccall f_3785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3690)
static void C_ccall f_3690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3890)
static void C_ccall f_3890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3896)
static void C_ccall f_3896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3899)
static void C_ccall f_3899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3727)
static void C_ccall f_3727(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3721)
static void C_ccall f_3721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3676)
static void C_ccall f_3676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5597)
static void C_ccall f_5597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5599)
static C_word C_fcall f_5599(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_3757)
static void C_ccall f_3757(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3755)
static void C_ccall f_3755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6188)
static void C_ccall f_6188(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6818)
static void C_ccall f_6818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3747)
static void C_ccall f_3747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6804)
static void C_ccall f_6804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3005)
static void C_fcall f_3005(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6686)
static void C_ccall f_6686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6152)
static void C_fcall f_6152(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5399)
static void C_ccall f_5399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3706)
static void C_ccall f_3706(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6679)
static void C_ccall f_6679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6135)
static void C_ccall f_6135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6138)
static void C_ccall f_6138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6131)
static void C_fcall f_6131(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4486)
static void C_fcall f_4486(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4473)
static void C_ccall f_4473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6119)
static void C_ccall f_6119(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6644)
static void C_ccall f_6644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6648)
static void C_ccall f_6648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6111)
static void C_ccall f_6111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3021)
static void C_ccall f_3021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6107)
static void C_ccall f_6107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6637)
static void C_ccall f_6637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6103)
static void C_ccall f_6103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3015)
static void C_fcall f_3015(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6621)
static void C_ccall f_6621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6628)
static void C_ccall f_6628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3083)
static void C_fcall f_3083(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4441)
static void C_ccall f_4441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4463)
static void C_fcall f_4463(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5724)
static void C_ccall f_5724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6559)
static void C_ccall f_6559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5716)
static void C_ccall f_5716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5710)
static void C_ccall f_5710(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6588)
static void C_ccall f_6588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7291)
static void C_ccall f_7291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5704)
static void C_ccall f_5704(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3228)
static void C_ccall f_3228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3212)
static void C_fcall f_3212(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3215)
static void C_ccall f_3215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5191)
static void C_ccall f_5191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3513)
static void C_fcall f_3513(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4424)
static void C_fcall f_4424(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3516)
static void C_ccall f_3516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7271)
static void C_ccall f_7271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3519)
static void C_ccall f_3519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7275)
static void C_ccall f_7275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5765)
static void C_ccall f_5765(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5765)
static void C_ccall f_5765r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5763)
static void C_ccall f_5763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3501)
static void C_fcall f_3501(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5180)
static void C_ccall f_5180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3504)
static void C_ccall f_3504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7245)
static void C_ccall f_7245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6179)
static void C_ccall f_6179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5759)
static void C_ccall f_5759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7060)
static void C_ccall f_7060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7251)
static void C_ccall f_7251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6175)
static void C_ccall f_6175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6168)
static void C_ccall f_6168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5747)
static void C_ccall f_5747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7255)
static void C_fcall f_7255(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5741)
static void C_ccall f_5741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6162)
static void C_ccall f_6162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7225)
static void C_fcall f_7225(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7229)
static void C_ccall f_7229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5736)
static void C_ccall f_5736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2318)
static void C_ccall f_2318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5739)
static void C_ccall f_5739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3257)
static void C_ccall f_3257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5733)
static void C_ccall f_5733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5730)
static void C_ccall f_5730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7232)
static void C_ccall f_7232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2373)
static void C_ccall f_2373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7238)
static void C_ccall f_7238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6529)
static void C_ccall f_6529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3622)
static void C_ccall f_3622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3626)
static void C_ccall f_3626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7208)
static void C_ccall f_7208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2346)
static void C_ccall f_2346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2343)
static void C_ccall f_2343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2340)
static void C_ccall f_2340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3610)
static void C_fcall f_3610(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5790)
static void C_ccall f_5790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4785)
static void C_ccall f_4785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3601)
static void C_fcall f_3601(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5780)
static void C_fcall f_5780(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3605)
static void C_ccall f_3605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3295)
static void C_ccall f_3295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3291)
static void C_ccall f_3291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5477)
static void C_ccall f_5477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5474)
static void C_ccall f_5474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5771)
static void C_ccall f_5771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5471)
static void C_ccall f_5471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6373)
static void C_ccall f_6373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6376)
static void C_ccall f_6376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6370)
static void C_ccall f_6370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5468)
static void C_ccall f_5468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5465)
static void C_ccall f_5465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5462)
static void C_ccall f_5462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3276)
static void C_ccall f_3276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6364)
static void C_ccall f_6364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3272)
static void C_ccall f_3272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5499)
static void C_ccall f_5499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6379)
static void C_ccall f_6379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5493)
static void C_ccall f_5493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5491)
static void C_ccall f_5491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4746)
static void C_ccall f_4746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4740)
static void C_ccall f_4740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6350)
static void C_ccall f_6350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5487)
static void C_ccall f_5487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5480)
static void C_ccall f_5480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4776)
static void C_ccall f_4776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4773)
static void C_ccall f_4773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4779)
static void C_ccall f_4779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2398)
static void C_ccall f_2398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5438)
static void C_ccall f_5438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5431)
static void C_fcall f_5431(C_word t0) C_noret;
C_noret_decl(f_4767)
static void C_ccall f_4767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4797)
static void C_ccall f_4797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3051)
static void C_ccall f_3051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4791)
static void C_ccall f_4791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4794)
static void C_ccall f_4794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6321)
static void C_fcall f_6321(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2864)
static void C_fcall f_2864(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2862)
static void C_ccall f_2862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5459)
static void C_ccall f_5459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5456)
static void C_ccall f_5456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5453)
static void C_ccall f_5453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5450)
static void C_ccall f_5450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6312)
static void C_ccall f_6312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4736)
static void C_ccall f_4736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4999)
static void C_ccall f_4999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4991)
static void C_ccall f_4991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2294)
static void C_ccall f_2294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2291)
static void C_ccall f_2291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6319)
static void C_ccall f_6319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4993)
static void C_ccall f_4993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4720)
static void C_ccall f_4720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2297)
static void C_ccall f_2297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4724)
static void C_ccall f_4724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4728)
static void C_ccall f_4728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4988)
static void C_ccall f_4988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4981)
static void C_ccall f_4981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4985)
static void C_ccall f_4985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6306)
static void C_ccall f_6306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4755)
static void C_ccall f_4755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4752)
static void C_ccall f_4752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4758)
static void C_ccall f_4758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5414)
static void C_ccall f_5414(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2828)
static void C_ccall f_2828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5418)
static void C_ccall f_5418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4253)
static void C_ccall f_4253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2833)
static void C_fcall f_2833(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4250)
static void C_ccall f_4250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4258)
static void C_ccall f_4258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5405)
static void C_ccall f_5405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5402)
static void C_ccall f_5402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2843)
static void C_ccall f_2843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5253)
static void C_ccall f_5253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5255)
static void C_ccall f_5255(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4273)
static void C_ccall f_4273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2459)
static void C_ccall f_2459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4944)
static void C_ccall f_4944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3244)
static void C_ccall f_3244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2858)
static void C_ccall f_2858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4949)
static void C_fcall f_4949(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4948)
static void C_ccall f_4948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5289)
static void C_ccall f_5289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4710)
static void C_ccall f_4710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4713)
static void C_ccall f_4713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4717)
static void C_ccall f_4717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2461)
static void C_fcall f_2461(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5220)
static void C_ccall f_5220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2468)
static void C_ccall f_2468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4268)
static void C_ccall f_4268(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4975)
static void C_ccall f_4975(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5279)
static void C_fcall f_5279(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5274)
static void C_ccall f_5274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2475)
static void C_fcall f_2475(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4217)
static void C_ccall f_4217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2479)
static void C_ccall f_2479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4964)
static void C_ccall f_4964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4960)
static void C_ccall f_4960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4969)
static void C_ccall f_4969(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2288)
static void C_ccall f_2288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2402)
static void C_ccall f_2402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4286)
static void C_ccall f_4286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2408)
static void C_ccall f_2408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4280)
static void C_ccall f_4280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4913)
static void C_ccall f_4913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4289)
static void C_ccall f_4289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4919)
static void C_ccall f_4919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5613)
static void C_ccall f_5613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5214)
static void C_fcall f_5214(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5217)
static void C_ccall f_5217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2411)
static void C_ccall f_2411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2414)
static void C_ccall f_2414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5230)
static void C_ccall f_5230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4235)
static void C_ccall f_4235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4901)
static void C_fcall f_4901(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4900)
static void C_ccall f_4900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4905)
static void C_ccall f_4905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4908)
static void C_ccall f_4908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4930)
static void C_ccall f_4930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4931)
static void C_fcall f_4931(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4938)
static void C_ccall f_4938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6592)
static void C_ccall f_6592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5234)
static void C_ccall f_5234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5238)
static void C_ccall f_5238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4923)
static void C_ccall f_4923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4926)
static void C_ccall f_4926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4247)
static void C_ccall f_4247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4241)
static void C_ccall f_4241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4244)
static void C_ccall f_4244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5011)
static void C_ccall f_5011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5005)
static void C_ccall f_5005(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5005)
static void C_ccall f_5005r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5895)
static void C_ccall f_5895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5891)
static void C_ccall f_5891(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5882)
static void C_ccall f_5882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5889)
static void C_ccall f_5889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2321)
static void C_ccall f_2321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2324)
static void C_ccall f_2324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2327)
static void C_ccall f_2327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4207)
static void C_ccall f_4207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2330)
static void C_ccall f_2330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2333)
static void C_ccall f_2333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3908)
static void C_ccall f_3908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5853)
static void C_ccall f_5853(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3905)
static void C_ccall f_3905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3902)
static void C_ccall f_3902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4098)
static void C_ccall f_4098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2303)
static void C_ccall f_2303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2300)
static void C_ccall f_2300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2306)
static void C_ccall f_2306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5077)
static void C_ccall f_5077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4080)
static void C_ccall f_4080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4083)
static void C_ccall f_4083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5071)
static void C_ccall f_5071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4088)
static void C_fcall f_4088(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2312)
static void C_ccall f_2312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2315)
static void C_ccall f_2315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2309)
static void C_ccall f_2309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5066)
static void C_ccall f_5066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5069)
static void C_ccall f_5069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5879)
static void C_ccall f_5879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5873)
static void C_ccall f_5873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5876)
static void C_ccall f_5876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5063)
static void C_ccall f_5063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5869)
static void C_ccall f_5869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3914)
static void C_ccall f_3914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3917)
static void C_ccall f_3917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3911)
static void C_ccall f_3911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5816)
static void C_fcall f_5816(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5814)
static void C_ccall f_5814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5819)
static void C_fcall f_5819(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5810)
static void C_ccall f_5810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6092)
static void C_ccall f_6092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6099)
static void C_ccall f_6099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5036)
static void C_ccall f_5036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5030)
static void C_ccall f_5030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5803)
static void C_ccall f_5803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6082)
static void C_ccall f_6082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6392)
static void C_ccall f_6392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6088)
static void C_ccall f_6088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5833)
static void C_ccall f_5833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5692)
static void C_fcall f_5692(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5696)
static void C_ccall f_5696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5699)
static void C_ccall f_5699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5059)
static void C_ccall f_5059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5053)
static void C_ccall f_5053(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5685)
static void C_ccall f_5685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5047)
static void C_ccall f_5047(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5042)
static void C_ccall f_5042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3980)
static void C_ccall f_3980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3988)
static void C_ccall f_3988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3983)
static void C_ccall f_3983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3984)
static void C_fcall f_3984(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6053)
static void C_ccall f_6053(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2422)
static void C_fcall f_2422(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6051)
static void C_ccall f_6051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3971)
static void C_ccall f_3971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6038)
static void C_ccall f_6038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3991)
static void C_ccall f_3991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3997)
static void C_ccall f_3997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6024)
static void C_ccall f_6024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6020)
static void C_fcall f_6020(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5690)
static void C_ccall f_5690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3462)
static void C_ccall f_3462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3467)
static void C_ccall f_3467(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4292)
static void C_ccall f_4292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4297)
static void C_ccall f_4297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6007)
static void C_ccall f_6007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3968)
static void C_ccall f_3968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3964)
static void C_fcall f_3964(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7182)
static void C_ccall f_7182(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5615)
static void C_fcall f_5615(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7190)
static void C_ccall f_7190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3479)
static void C_ccall f_3479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3473)
static void C_ccall f_3473(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5650)
static void C_fcall f_5650(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4891)
static void C_ccall f_4891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4894)
static void C_ccall f_4894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3116)
static void C_ccall f_3116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4888)
static void C_ccall f_4888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3456)
static void C_ccall f_3456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4880)
static void C_ccall f_4880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4881)
static void C_fcall f_4881(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7144)
static void C_fcall f_7144(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4885)
static void C_fcall f_4885(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7140)
static void C_ccall f_7140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6475)
static void C_fcall f_6475(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7371)
static void C_ccall f_7371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7374)
static void C_ccall f_7374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3489)
static void C_fcall f_3489(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7389)
static void C_ccall f_7389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7383)
static void C_ccall f_7383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7128)
static void C_ccall f_7128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7121)
static void C_ccall f_7121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6450)
static void C_ccall f_6450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7352)
static void C_ccall f_7352(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6457)
static void C_ccall f_6457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7350)
static void C_ccall f_7350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7358)
static void C_ccall f_7358(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4853)
static void C_ccall f_4853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4850)
static void C_fcall f_4850(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4859)
static void C_ccall f_4859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3153)
static void C_ccall f_3153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7368)
static void C_ccall f_7368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7364)
static void C_ccall f_7364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3492)
static void C_ccall f_3492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7106)
static void C_fcall f_7106(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3100)
static void C_ccall f_3100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7335)
static void C_ccall f_7335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7338)
static void C_ccall f_7338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4874)
static void C_ccall f_4874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7115)
static void C_ccall f_7115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4871)
static void C_ccall f_4871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4877)
static void C_ccall f_4877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6421)
static void C_fcall f_6421(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7344)
static void C_ccall f_7344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7347)
static void C_ccall f_7347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7341)
static void C_ccall f_7341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4496)
static void C_ccall f_4496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4868)
static void C_ccall f_4868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6412)
static void C_ccall f_6412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3122)
static void C_fcall f_3122(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6419)
static void C_ccall f_6419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4813)
static void C_ccall f_4813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4816)
static void C_ccall f_4816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4819)
static void C_ccall f_4819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6486)
static void C_ccall f_6486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4807)
static void C_ccall f_4807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4804)
static void C_ccall f_4804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4835)
static void C_ccall f_4835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4826)
static void C_ccall f_4826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3359)
static void C_fcall f_3359(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3358)
static void C_ccall f_3358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5089)
static void C_ccall f_5089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5083)
static void C_ccall f_5083(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5083)
static void C_ccall f_5083r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3184)
static void C_fcall f_3184(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3370)
static void C_ccall f_3370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6252)
static void C_ccall f_6252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3375)
static void C_fcall f_3375(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2709)
static void C_ccall f_2709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6285)
static void C_ccall f_6285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6281)
static void C_ccall f_6281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3364)
static void C_ccall f_3364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6288)
static void C_ccall f_6288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6949)
static void C_ccall f_6949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6945)
static void C_ccall f_6945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6402)
static void C_ccall f_6402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f7920)
static void C_ccall f7920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f7925)
static void C_ccall f7925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6262)
static void C_ccall f_6262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2740)
static void C_ccall f_2740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3309)
static void C_ccall f_3309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2650)
static void C_ccall f_2650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6210)
static void C_ccall f_6210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6215)
static void C_fcall f_6215(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2711)
static void C_fcall f_2711(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6919)
static void C_ccall f_6919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2621)
static void C_fcall f_2621(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6246)
static void C_ccall f_6246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6249)
static void C_ccall f_6249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2673)
static void C_ccall f_2673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6784)
static void C_ccall f_6784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2559)
static void C_ccall f_2559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2754)
static void C_ccall f_2754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2787)
static void C_ccall f_2787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2666)
static void C_fcall f_2666(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2664)
static void C_ccall f_2664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6207)
static void C_ccall f_6207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2757)
static void C_fcall f_2757(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3393)
static void C_ccall f_3393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3428)
static void C_fcall f_3428(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2531)
static void C_ccall f_2531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6740)
static void C_ccall f_6740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3389)
static void C_ccall f_3389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6070)
static void C_fcall f_6070(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f7994)
static void C_ccall f7994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3402)
static void C_ccall f_3402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3408)
static void C_ccall f_3408(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2595)
static void C_ccall f_2595(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2795)
static void C_ccall f_2795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3131)
static void C_fcall f_3131(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f7982)
static void C_ccall f7982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f7989)
static void C_ccall f7989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3438)
static void C_ccall f_3438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2577)
static void C_fcall f_2577(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2930)
static void C_ccall f_2930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3163)
static void C_ccall f_3163(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2932)
static C_word C_fcall f_2932(C_word t0,C_word t1);
C_noret_decl(f7972)
static void C_ccall f7972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6711)
static void C_ccall f_6711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f7977)
static void C_ccall f7977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6714)
static void C_ccall f_6714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2575)
static void C_ccall f_2575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2589)
static void C_ccall f_2589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f7962)
static void C_ccall f7962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f7967)
static void C_ccall f7967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4170)
static void C_ccall f_4170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4176)
static void C_ccall f_4176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2581)
static void C_ccall f_2581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2584)
static void C_ccall f_2584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2910)
static void C_ccall f_2910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2913)
static void C_fcall f_2913(C_word t0,C_word t1) C_noret;
C_noret_decl(f7952)
static void C_ccall f7952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4690)
static void C_ccall f_4690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f7957)
static void C_ccall f7957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6770)
static void C_ccall f_6770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4165)
static void C_ccall f_4165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4687)
static void C_ccall f_4687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2920)
static void C_ccall f_2920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f7942)
static void C_ccall f7942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4681)
static void C_ccall f_4681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f7947)
static void C_ccall f7947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4684)
static void C_ccall f_4684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f7930)
static void C_ccall f7930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2974)
static void C_ccall f_2974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2970)
static void C_ccall f_2970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f7935)
static void C_ccall f7935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5577)
static void C_ccall f_5577(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5571)
static void C_ccall f_5571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2982)
static void C_fcall f_2982(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2957)
static void C_ccall f_2957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2958)
static void C_fcall f_2958(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4138)
static void C_ccall f_4138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4134)
static void C_fcall f_4134(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4366)
static void C_ccall f_4366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6737)
static void C_ccall f_6737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2951)
static void C_ccall f_2951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5556)
static void C_ccall f_5556(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4353)
static void C_ccall f_4353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4359)
static void C_ccall f_4359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2966)
static void C_ccall f_2966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4156)
static void C_ccall f_4156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5583)
static C_word C_fcall f_5583(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_4675)
static void C_ccall f_4675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4387)
static void C_ccall f_4387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4678)
static void C_ccall f_4678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5532)
static void C_ccall f_5532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5534)
static void C_ccall f_5534(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4661)
static void C_fcall f_4661(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4669)
static void C_ccall f_4669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5566)
static void C_ccall f_5566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5563)
static void C_ccall f_5563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4321)
static void C_ccall f_4321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2992)
static void C_ccall f_2992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5517)
static void C_ccall f_5517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4311)
static void C_fcall f_4311(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5542)
static void C_ccall f_5542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5546)
static void C_ccall f_5546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4349)
static void C_ccall f_4349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4336)
static void C_ccall f_4336(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_5507)
static void C_fcall trf_5507(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5507(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5507(t0,t1,t2);}

C_noret_decl(trf_4569)
static void C_fcall trf_4569(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4569(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4569(t0,t1);}

C_noret_decl(trf_4512)
static void C_fcall trf_4512(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4512(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4512(t0,t1);}

C_noret_decl(trf_5997)
static void C_fcall trf_5997(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5997(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5997(t0,t1,t2);}

C_noret_decl(trf_5338)
static void C_fcall trf_5338(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5338(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5338(t0,t1,t2);}

C_noret_decl(trf_4395)
static void C_fcall trf_4395(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4395(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4395(t0,t1,t2);}

C_noret_decl(trf_5911)
static void C_fcall trf_5911(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5911(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5911(t0,t1,t2);}

C_noret_decl(trf_3883)
static void C_fcall trf_3883(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3883(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3883(t0,t1);}

C_noret_decl(trf_3873)
static void C_fcall trf_3873(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3873(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3873(t0,t1,t2);}

C_noret_decl(trf_3647)
static void C_fcall trf_3647(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3647(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3647(t0,t1);}

C_noret_decl(trf_3765)
static void C_fcall trf_3765(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3765(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3765(t0,t1,t2);}

C_noret_decl(trf_4022)
static void C_fcall trf_4022(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4022(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4022(t0,t1,t2);}

C_noret_decl(trf_3005)
static void C_fcall trf_3005(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3005(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3005(t0,t1);}

C_noret_decl(trf_6152)
static void C_fcall trf_6152(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6152(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6152(t0,t1);}

C_noret_decl(trf_6131)
static void C_fcall trf_6131(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6131(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6131(t0,t1,t2);}

C_noret_decl(trf_4486)
static void C_fcall trf_4486(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4486(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4486(t0,t1,t2);}

C_noret_decl(trf_3015)
static void C_fcall trf_3015(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3015(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3015(t0,t1);}

C_noret_decl(trf_3083)
static void C_fcall trf_3083(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3083(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3083(t0,t1);}

C_noret_decl(trf_4463)
static void C_fcall trf_4463(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4463(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4463(t0,t1,t2);}

C_noret_decl(trf_3212)
static void C_fcall trf_3212(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3212(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3212(t0,t1);}

C_noret_decl(trf_3513)
static void C_fcall trf_3513(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3513(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3513(t0,t1);}

C_noret_decl(trf_4424)
static void C_fcall trf_4424(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4424(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4424(t0,t1);}

C_noret_decl(trf_3501)
static void C_fcall trf_3501(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3501(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3501(t0,t1);}

C_noret_decl(trf_7255)
static void C_fcall trf_7255(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7255(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7255(t0,t1,t2);}

C_noret_decl(trf_7225)
static void C_fcall trf_7225(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7225(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7225(t0,t1);}

C_noret_decl(trf_3610)
static void C_fcall trf_3610(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3610(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3610(t0,t1,t2);}

C_noret_decl(trf_3601)
static void C_fcall trf_3601(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3601(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3601(t0,t1);}

C_noret_decl(trf_5780)
static void C_fcall trf_5780(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5780(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5780(t0,t1,t2);}

C_noret_decl(trf_5431)
static void C_fcall trf_5431(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5431(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_5431(t0);}

C_noret_decl(trf_6321)
static void C_fcall trf_6321(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6321(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6321(t0,t1,t2);}

C_noret_decl(trf_2864)
static void C_fcall trf_2864(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2864(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2864(t0,t1);}

C_noret_decl(trf_2833)
static void C_fcall trf_2833(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2833(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2833(t0,t1,t2);}

C_noret_decl(trf_4949)
static void C_fcall trf_4949(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4949(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4949(t0,t1);}

C_noret_decl(trf_2461)
static void C_fcall trf_2461(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2461(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2461(t0,t1,t2);}

C_noret_decl(trf_5279)
static void C_fcall trf_5279(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5279(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5279(t0,t1,t2,t3);}

C_noret_decl(trf_2475)
static void C_fcall trf_2475(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2475(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2475(t0,t1,t2);}

C_noret_decl(trf_5214)
static void C_fcall trf_5214(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5214(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5214(t0,t1);}

C_noret_decl(trf_4901)
static void C_fcall trf_4901(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4901(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4901(t0,t1,t2);}

C_noret_decl(trf_4931)
static void C_fcall trf_4931(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4931(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4931(t0,t1);}

C_noret_decl(trf_4088)
static void C_fcall trf_4088(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4088(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4088(t0,t1,t2);}

C_noret_decl(trf_5816)
static void C_fcall trf_5816(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5816(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5816(t0,t1);}

C_noret_decl(trf_5819)
static void C_fcall trf_5819(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5819(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5819(t0,t1);}

C_noret_decl(trf_5692)
static void C_fcall trf_5692(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5692(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5692(t0,t1,t2);}

C_noret_decl(trf_3984)
static void C_fcall trf_3984(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3984(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3984(t0,t1,t2);}

C_noret_decl(trf_2422)
static void C_fcall trf_2422(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2422(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2422(t0,t1);}

C_noret_decl(trf_6020)
static void C_fcall trf_6020(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6020(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6020(t0,t1);}

C_noret_decl(trf_3964)
static void C_fcall trf_3964(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3964(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3964(t0,t1,t2);}

C_noret_decl(trf_5615)
static void C_fcall trf_5615(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5615(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5615(t0,t1,t2);}

C_noret_decl(trf_5650)
static void C_fcall trf_5650(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5650(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5650(t0,t1,t2);}

C_noret_decl(trf_4881)
static void C_fcall trf_4881(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4881(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4881(t0,t1,t2,t3);}

C_noret_decl(trf_7144)
static void C_fcall trf_7144(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7144(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7144(t0,t1,t2);}

C_noret_decl(trf_4885)
static void C_fcall trf_4885(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4885(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4885(t0,t1);}

C_noret_decl(trf_6475)
static void C_fcall trf_6475(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6475(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6475(t0,t1);}

C_noret_decl(trf_3489)
static void C_fcall trf_3489(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3489(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3489(t0,t1);}

C_noret_decl(trf_4850)
static void C_fcall trf_4850(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4850(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4850(t0,t1);}

C_noret_decl(trf_7106)
static void C_fcall trf_7106(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7106(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7106(t0,t1);}

C_noret_decl(trf_6421)
static void C_fcall trf_6421(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6421(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6421(t0,t1,t2);}

C_noret_decl(trf_3122)
static void C_fcall trf_3122(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3122(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3122(t0,t1);}

C_noret_decl(trf_3359)
static void C_fcall trf_3359(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3359(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3359(t0,t1,t2);}

C_noret_decl(trf_3184)
static void C_fcall trf_3184(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3184(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3184(t0,t1);}

C_noret_decl(trf_3375)
static void C_fcall trf_3375(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3375(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3375(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6215)
static void C_fcall trf_6215(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6215(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6215(t0,t1,t2,t3);}

C_noret_decl(trf_2711)
static void C_fcall trf_2711(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2711(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2711(t0,t1,t2);}

C_noret_decl(trf_2621)
static void C_fcall trf_2621(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2621(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2621(t0,t1,t2);}

C_noret_decl(trf_2666)
static void C_fcall trf_2666(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2666(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2666(t0,t1,t2);}

C_noret_decl(trf_2757)
static void C_fcall trf_2757(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2757(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2757(t0,t1);}

C_noret_decl(trf_3428)
static void C_fcall trf_3428(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3428(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3428(t0,t1,t2);}

C_noret_decl(trf_6070)
static void C_fcall trf_6070(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6070(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6070(t0,t1,t2);}

C_noret_decl(trf_3131)
static void C_fcall trf_3131(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3131(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3131(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2577)
static void C_fcall trf_2577(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2577(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2577(t0,t1,t2);}

C_noret_decl(trf_2913)
static void C_fcall trf_2913(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2913(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2913(t0,t1);}

C_noret_decl(trf_2982)
static void C_fcall trf_2982(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2982(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2982(t0,t1,t2);}

C_noret_decl(trf_2958)
static void C_fcall trf_2958(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2958(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2958(t0,t1,t2);}

C_noret_decl(trf_4134)
static void C_fcall trf_4134(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4134(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4134(t0,t1);}

C_noret_decl(trf_4661)
static void C_fcall trf_4661(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4661(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4661(t0,t1);}

C_noret_decl(trf_4311)
static void C_fcall trf_4311(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4311(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4311(t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* k4620 in k4567 in loop in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_ccall f_4622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
/* chicken-install.scm:515: fail */
t2=((C_word*)t0)[3];
f_4512(t2,((C_word*)t0)[2]);}}

/* k5321 in k5318 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in ... */
static void C_ccall f_5323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5323,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5326,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:585: ##sys#print */
t3=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[337],C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k5324 in k5321 in k5318 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in ... */
static void C_ccall f_5326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5329,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:586: cleanup */
f_5431(t2);}

/* k5327 in k5324 in k5321 in k5318 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in ... */
static void C_ccall f_5329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:587: exit */
t2=C_fast_retrieve(lf[68]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(1));}

/* k7391 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in ... */
static void C_ccall f_7393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:1066: cleanup */
f_5431(((C_word*)t0)[2]);}

/* k5318 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in ... */
static void C_ccall f_5320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5320,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5323,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_list_ref(((C_word*)t0)[4],((C_word*)t0)[5]);
/* chicken-install.scm:585: ##sys#print */
t4=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* for-each-loop1364 in a5492 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in ... */
static void C_fcall f_5507(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5507,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5517,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5499,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:708: write */
t7=*((C_word*)lf[227]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4304 in k4290 in k4287 in k4284 in k4278 in k4391 in k4385 in k4271 in a4267 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in ... */
static void C_ccall f_4306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:492: retrieve */
f_4134(((C_word*)t0)[2],((C_word*)t0)[3]);}

/* a5380 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_ccall f_5381(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5381,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=t2;
t4=C_u_i_car(t3);
/* chicken-install.scm:575: extension-information */
t5=C_fast_retrieve(lf[49]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}
else{
t3=t2;
/* chicken-install.scm:575: extension-information */
t4=C_fast_retrieve(lf[49]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}}

/* k4567 in loop in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_fcall f_4569(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4569,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4582,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* chicken-install.scm:511: loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4534(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[4];
t3=C_u_i_car(t2);
t4=C_eqp(lf[145],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4598,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=((C_word*)t0)[4];
t7=C_u_i_cdr(t6);
/* chicken-install.scm:513: every */
t8=C_fast_retrieve(lf[146]);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,((C_word*)((C_word*)t0)[5])[1],t7);}
else{
t5=((C_word*)t0)[4];
t6=C_u_i_car(t5);
t7=C_eqp(lf[62],t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4622,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t9=((C_word*)t0)[4];
t10=C_u_i_cdr(t9);
/* chicken-install.scm:515: any */
t11=C_fast_retrieve(lf[147]);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t8,((C_word*)((C_word*)t0)[5])[1],t10);}
else{
t8=C_i_cadr(((C_word*)t0)[6]);
/* chicken-install.scm:516: error */
t9=*((C_word*)lf[55]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],lf[148],((C_word*)t0)[7],t8);}}}}

/* k5377 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_ccall f_5379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_4850(t3,t2);}

/* k5373 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in ... */
static void C_ccall f_5375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:579: reverse */
t2=*((C_word*)lf[103]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4596 in k4567 in loop in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_ccall f_4598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-install.scm:513: fail */
t2=((C_word*)t0)[2];
f_4512(t2,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4580 in k4567 in loop in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_ccall f_4582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
/* chicken-install.scm:511: fail */
t2=((C_word*)t0)[3];
f_4512(t2,((C_word*)t0)[2]);}}

/* k2617 in k2477 in g249 in k2856 in k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_ccall f_2619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:153: append */
t2=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[22],"main#\052mappings\052"),t1);}

/* loop in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in ... */
static void C_ccall f_4534(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4534,3,t0,t1,t2);}
if(C_truep(C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4544,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:507: feature? */
t4=C_fast_retrieve(lf[144]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
if(C_truep(C_i_listp(t2))){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4569,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=C_i_car(t2);
t5=C_eqp(lf[149],t4);
if(C_truep(t5)){
t6=t2;
t7=C_u_i_cdr(t6);
t8=t3;
f_4569(t8,C_i_pairp(t7));}
else{
t6=t3;
f_4569(t6,C_SCHEME_FALSE);}}
else{
t3=C_i_cadr(((C_word*)t0)[4]);
/* chicken-install.scm:509: error */
t4=*((C_word*)lf[55]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[150],((C_word*)t0)[5],t3);}}}

/* k4178 in a4175 in k4163 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in ... */
static void C_ccall f_4180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4183,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:450: print */
t3=*((C_word*)lf[69]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[186],((C_word*)t0)[2],lf[187],((C_word*)t0)[3]);}

/* k4181 in k4178 in a4175 in k4163 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in ... */
static void C_ccall f_4183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4183,2,t0,t1);}
t2=C_a_i_list3(&a,3,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);
t3=C_a_i_cons(&a,2,t2,C_retrieve2(lf[63],"main#\052eggs+dirs+vers\052"));
t4=C_mutate2(&lf[63] /* (set! main#*eggs+dirs+vers* ...) */,t3);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* a2607 in g293 in k2477 in g249 in k2856 in k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in ... */
static void C_ccall f_2608(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2608,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_eqp(lf[365],t2));}

/* k7032 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f_7034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_mutate2(&lf[66] /* (set! main#*csi* ...) */,t2);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
/* chicken-install.scm:1010: loop */
t7=((C_word*)((C_word*)t0)[3])[1];
f_6215(t7,((C_word*)t0)[4],t6,((C_word*)((C_word*)t0)[5])[1]);}

/* k2517 in k2514 in k2508 in k2477 in g249 in k2856 in k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in ... */
static void C_ccall f_2519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2519,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2522,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:141: ##sys#print */
t3=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[361],C_SCHEME_FALSE,((C_word*)t0)[5]);}

/* k4542 in loop in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f_4544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* chicken-install.scm:507: fail */
t2=((C_word*)t0)[3];
f_4512(t2,((C_word*)t0)[2]);}}

/* k2508 in k2477 in g249 in k2856 in k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_ccall f_2510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2510,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[122]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2516,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:141: ##sys#print */
t6=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[362],C_SCHEME_FALSE,t3);}

/* k2514 in k2508 in k2477 in g249 in k2856 in k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in ... */
static void C_ccall f_2516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2516,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2519,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:141: ##sys#print */
t3=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,C_retrieve2(lf[2],"main#constant163"),C_SCHEME_FALSE,((C_word*)t0)[5]);}

/* k2526 in k2523 in k2520 in k2517 in k2514 in k2508 in k2477 in g249 in k2856 in k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in ... */
static void C_ccall f_2528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2528,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2531,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:141: get-output-string */
t3=C_fast_retrieve(lf[123]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k2520 in k2517 in k2514 in k2508 in k2477 in g249 in k2856 in k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in ... */
static void C_ccall f_2522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2522,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2525,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:141: ##sys#print */
t3=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,C_fix(1),C_SCHEME_FALSE,((C_word*)t0)[5]);}

/* k2523 in k2520 in k2517 in k2514 in k2508 in k2477 in g249 in k2856 in k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in ... */
static void C_ccall f_2525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2525,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2528,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:141: ##sys#write-char-0 */
((C_proc4)C_fast_retrieve_symbol_proc(lf[124]))(4,*((C_word*)lf[124]+1),t2,C_make_character(41),((C_word*)t0)[5]);}

/* k6491 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f_6493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:906: print */
t2=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* fail in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in ... */
static void C_fcall f_4512(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4512,NULL,2,t0,t1);}
/* chicken-install.scm:502: error */
t2=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[142],((C_word*)t0)[2]);}

/* a5112 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in ... */
static void C_ccall f_5113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5113,2,t0,t1);}
/* chicken-install.scm:647: change-directory */
t2=C_fast_retrieve(lf[256]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* for-each-loop1451 in k5987 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_fcall f_5997(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5997,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6007,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=C_i_car(t4);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5986,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:737: cadadr */
t9=*((C_word*)lf[251]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3804 in k3801 in k3798 in k3795 in k3792 in k3789 in k3786 in k3783 in k3777 in g612 in k3850 in a3756 in k4278 in k4391 in k4385 in k4271 in a4267 in k4251 in k4248 in k4245 in k4242 in k4239 in ... */
static void C_ccall f_3806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:385: warning */
t2=C_fast_retrieve(lf[60]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3801 in k3798 in k3795 in k3792 in k3789 in k3786 in k3783 in k3777 in g612 in k3850 in a3756 in k4278 in k4391 in k4385 in k4271 in a4267 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in ... */
static void C_ccall f_3803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3803,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3806,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:386: get-output-string */
t3=C_fast_retrieve(lf[123]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k3798 in k3795 in k3792 in k3789 in k3786 in k3783 in k3777 in g612 in k3850 in a3756 in k4278 in k4391 in k4385 in k4271 in a4267 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in ... */
static void C_ccall f_3800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3800,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3803,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:386: ##sys#write-char-0 */
((C_proc4)C_fast_retrieve_symbol_proc(lf[124]))(4,*((C_word*)lf[124]+1),t2,C_make_character(39),((C_word*)t0)[4]);}

/* k5987 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in ... */
static void C_ccall f_5989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5989,2,t0,t1);}
t2=C_i_check_list_2(t1,lf[86]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5997,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_5997(t6,((C_word*)t0)[2],t1);}

/* k5984 in for-each-loop1451 in k5987 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_ccall f_5986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5986,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
/* chicken-install.scm:737: pp */
t3=C_fast_retrieve(lf[250]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],t2);}

/* map-loop1035 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in ... */
static void C_fcall f_5338(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5338,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_assoc(t3,C_retrieve2(lf[63],"main#\052eggs+dirs+vers\052"));
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* a5168 in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in ... */
static void C_ccall f_5169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5169,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_retrieve2(lf[23],"main#\052deploy\052"));
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,C_retrieve2(lf[27],"main#\052prefix\052"));
t4=C_mutate2(&lf[23] /* (set! main#*deploy* ...) */,((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate2(&lf[27] /* (set! main#*prefix* ...) */,((C_word*)((C_word*)t0)[5])[1]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}

/* a5162 in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in ... */
static void C_ccall f_5163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5163,2,t0,t1);}
/* chicken-install.scm:651: setup */
t2=((C_word*)t0)[2];
f_4901(t2,t1,((C_word*)t0)[3]);}

/* k4007 in k3995 in k3989 in k3986 in g693 in k3981 in k3978 in k3969 in k3966 in main#show-depends in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f_4009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4009,2,t0,t1);}
t2=C_i_check_list_2(((C_word*)t0)[2],lf[86]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4022,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4022(t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5957 in a5951 in a5890 in main#apply-mappings in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in ... */
static void C_ccall f_5958(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5958,3,t0,t1,t2);}
/* chicken-install.scm:724: g1413 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5853(4,t3,t1,((C_word*)t0)[3],t2);}

/* a5951 in a5890 in main#apply-mappings in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in ... */
static void C_ccall f_5952(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5952,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5958,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_i_car(t2);
/* chicken-install.scm:724: find */
t5=C_fast_retrieve(lf[203]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* k3844 in k3850 in a3756 in k4278 in k4391 in k4385 in k4271 in a4267 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in ... */
static void C_ccall f_3846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_i_assq(lf[46],t1);
t3=(C_truep(t2)?C_i_cadr(t2):lf[129]);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
/* chicken-install.scm:390: conc */
t6=C_fast_retrieve(lf[130]);
((C_proc10)(void*)(*((C_word*)t6+1)))(10,t6,((C_word*)t0)[3],lf[131],((C_word*)t0)[4],lf[132],t3,lf[133],t5,lf[134],C_make_character(10));}

/* a5138 in k5127 in k5118 in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in ... */
static void C_ccall f_5139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5139,2,t0,t1);}
/* chicken-install.scm:656: setup */
t2=((C_word*)t0)[2];
f_4901(t2,t1,((C_word*)t0)[3]);}

/* a5133 in k5127 in k5118 in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in ... */
static void C_ccall f_5134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5134,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_retrieve2(lf[30],"main#\052host-extension\052"));
t3=C_mutate2(&lf[30] /* (set! main#*host-extension* ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k5938 in map-loop1420 in k5893 in a5890 in main#apply-mappings in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in ... */
static void C_ccall f_5940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5940,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_5911(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_5911(t6,((C_word*)t0)[5],t5);}}

/* k5127 in k5118 in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in ... */
static void C_ccall f_5129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5129,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5134,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5139,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5145,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:655: ##sys#dynamic-wind */
t9=*((C_word*)lf[243]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[4],t6,t7,t8);}

/* k7414 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 */
static void C_ccall f_7416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:309: setup-api#shellpath */
((C_proc3)C_fast_retrieve_symbol_proc(lf[283]))(3,*((C_word*)lf[283]+1),((C_word*)t0)[2],t1);}

/* k5118 in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in ... */
static void C_ccall f_5120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5120,2,t0,t1);}
t2=(C_truep(C_retrieve2(lf[31],"main#\052target-extension\052"))?C_retrieve2(lf[30],"main#\052host-extension\052"):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5129,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:654: print */
t4=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[322]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7418 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 */
static void C_ccall f_7420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:309: make-pathname */
t2=C_fast_retrieve(lf[79]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[4],"main#\052program-path\052"),t1);}

/* k4391 in k4385 in k4271 in a4267 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in ... */
static void C_ccall f_4393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4393,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,t2,C_retrieve2(lf[64],"main#\052dependencies\052"));
t4=C_mutate2(&lf[64] /* (set! main#*dependencies* ...) */,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4280,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[6])[1]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4359,a[2]=t5,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4366,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:477: string-intersperse */
t8=C_fast_retrieve(lf[110]);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)((C_word*)t0)[6])[1],lf[138]);}
else{
t6=t5;
f_4280(2,t6,C_SCHEME_UNDEFINED);}}

/* map-loop816 in k4385 in k4271 in a4267 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in ... */
static void C_fcall f_4395(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4395,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4424,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
if(C_truep(C_i_pairp(t4))){
t5=C_u_i_car(t4);
t6=t3;
f_4424(t6,t5);}
else{
t5=t3;
f_4424(t5,t4);}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3572 in a3565 in a3559 in a3466 in a3720 in a3705 in a4169 in k4163 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_ccall f_3574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_retrieve2(lf[9],"main#\052retrieve-only\052");
t3=(C_truep(C_retrieve2(lf[9],"main#\052retrieve-only\052"))?C_SCHEME_FALSE:C_i_not(C_retrieve2(lf[5],"main#\052keep\052")));
/* chicken-install.scm:313: setup-download#retrieve-extension */
((C_proc25)C_fast_retrieve_symbol_proc(lf[172]))(25,*((C_word*)lf[172]+1),((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],lf[173],((C_word*)t0)[6],lf[174],t1,lf[175],C_retrieve2(lf[8],"main#\052run-tests\052"),lf[176],C_retrieve2(lf[11],"main#\052username\052"),lf[177],C_retrieve2(lf[12],"main#\052password\052"),lf[178],C_retrieve2(lf[24],"main#\052trunk\052"),lf[179],C_retrieve2(lf[18],"main#\052proxy-host\052"),lf[180],C_retrieve2(lf[19],"main#\052proxy-port\052"),lf[181],C_retrieve2(lf[20],"main#\052proxy-user-pass\052"),lf[182],t3);}

/* a3559 in a3466 in a3720 in a3705 in a4169 in k4163 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in ... */
static void C_ccall f_3560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3560,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3566,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3589,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:311: ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a3565 in a3559 in a3466 in a3720 in a3705 in a4169 in k4163 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f_3566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3566,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3574,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve2(lf[9],"main#\052retrieve-only\052"))){
/* chicken-install.scm:316: current-directory */
t3=C_fast_retrieve(lf[80]);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=t2;
f_3574(2,t3,C_SCHEME_FALSE);}}

/* map-loop1420 in k5893 in a5890 in main#apply-mappings in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in ... */
static void C_fcall f_5911(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5911,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5940,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-install.scm:726: g1426 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3881 in g643 in k3864 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in ... */
static void C_fcall f_3883(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3883,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3890,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:405: open-output-string */
t3=C_fast_retrieve(lf[128]);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* chicken-install.scm:409: print */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[193],((C_word*)t0)[5]);}}

/* a7407 in a7401 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in ... */
static void C_ccall f_7408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7408,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a7401 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in ... */
static void C_ccall f_7402(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_7402r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7402r(t0,t1,t2);}}

static void C_ccall f_7402r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7408,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:1059: k1765 */
t4=((C_word*)t0)[2];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t1,t3);}

/* k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in ... */
static void C_ccall f_7400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7400,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t1;
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6207,a[2]=t5,a[3]=t7,a[4]=t9,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm:846: irregex */
t11=C_fast_retrieve(lf[245]);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,lf[432]);}

/* a3594 in a3588 in a3559 in a3466 in a3720 in a3705 in a4169 in k4163 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_ccall f_3595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3595,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* k4063 in k3986 in g693 in k3981 in k3978 in k3969 in k3966 in main#show-depends in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in ... */
static void C_ccall f_4065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-install.scm:424: with-input-from-file */
t2=C_fast_retrieve(lf[91]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],*((C_word*)lf[92]+1));}
else{
t2=((C_word*)t0)[2];
f_3991(2,t2,C_SCHEME_FALSE);}}

/* k6891 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f_6893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_mutate2(&lf[11] /* (set! main#*username* ...) */,t2);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
/* chicken-install.scm:983: loop */
t7=((C_word*)((C_word*)t0)[3])[1];
f_6215(t7,((C_word*)t0)[4],t6,((C_word*)((C_word*)t0)[5])[1]);}

/* k3875 in g643 in k3864 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in ... */
static void C_ccall f_3877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_cadr(((C_word*)t0)[3]));}

/* g643 in k3864 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in ... */
static void C_fcall f_3873(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3873,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3877,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3883,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t5=C_i_cadr(t2);
t6=C_u_i_cdr(((C_word*)t0)[2]);
t7=C_i_equalp(t5,t6);
t8=t4;
f_3883(t8,C_i_not(t7));}
else{
t5=t4;
f_3883(t5,C_SCHEME_FALSE);}}

/* a3588 in a3559 in a3466 in a3720 in a3705 in a4169 in k4163 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f_3589(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3589r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3589r(t0,t1,t2);}}

static void C_ccall f_3589r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3595,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:311: k542 */
t4=((C_word*)t0)[2];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3651 in k3645 in k3642 in trying-sources in k3603 in main#with-default-sources in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in ... */
static void C_ccall f_3652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3652,2,t0,t1);}
t2=C_eqp(lf[74],((C_word*)t0)[2]);
if(C_truep(t2)){
t3=C_i_cdr(((C_word*)t0)[3]);
/* chicken-install.scm:361: trying-sources */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3610(t4,t1,t3);}
else{
t3=C_i_set_car(((C_word*)t0)[3],C_SCHEME_FALSE);
t4=C_i_cdr(((C_word*)t0)[3]);
/* chicken-install.scm:361: trying-sources */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3610(t5,t1,t4);}}

/* k3864 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in ... */
static void C_ccall f_3866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3866,2,t0,t1);}
t2=t1;
t3=C_i_assq(t2,C_retrieve2(lf[34],"main#\052override\052"));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3873,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:399: g643 */
t5=t4;
f_3873(t5,((C_word*)t0)[3],t3);}
else{
t4=C_i_pairp(((C_word*)t0)[2]);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?C_u_i_cdr(((C_word*)t0)[2]):C_SCHEME_FALSE));}}

/* a5155 in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in ... */
static void C_ccall f_5156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5156,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_retrieve2(lf[23],"main#\052deploy\052"));
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,C_retrieve2(lf[27],"main#\052prefix\052"));
t4=C_mutate2(&lf[23] /* (set! main#*deploy* ...) */,((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate2(&lf[27] /* (set! main#*prefix* ...) */,((C_word*)((C_word*)t0)[5])[1]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}

/* k3777 in g612 in k3850 in a3756 in k4278 in k4391 in k4385 in k4271 in a4267 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in ... */
static void C_ccall f_3779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3779,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[122]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3785,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm:386: ##sys#print */
t6=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[127],C_SCHEME_FALSE,t3);}

/* k3850 in a3756 in k4278 in k4391 in k4385 in k4271 in a4267 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in ... */
static void C_ccall f_3852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3852,2,t0,t1);}
t2=C_i_assq(t1,C_retrieve2(lf[34],"main#\052override\052"));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3765,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:381: g612 */
t4=t3;
f_3765(t4,((C_word*)t0)[3],t2);}
else{
t3=((C_word*)t0)[2];
t4=C_u_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3846,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=((C_word*)t0)[2];
t7=C_u_i_car(t6);
/* chicken-install.scm:392: extension-information */
t8=C_fast_retrieve(lf[49]);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t5,t7);}}

/* k3645 in k3642 in trying-sources in k3603 in main#with-default-sources in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in ... */
static void C_fcall f_3647(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3647,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3652,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:356: proc */
t4=((C_word*)t0)[4];
((C_proc5)C_fast_retrieve_proc(t4))(5,t4,((C_word*)t0)[5],t2,((C_word*)t0)[6],t3);}

/* k3642 in trying-sources in k3603 in main#with-default-sources in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in ... */
static void C_ccall f_3644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3644,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3647,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=C_i_assq(lf[75],((C_word*)t0)[6]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3676,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t4)){
t6=t3;
f_3647(t6,C_i_cadr(t4));}
else{
/* chicken-install.scm:355: error */
t6=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,lf[76],((C_word*)t0)[6]);}}

/* k3767 in g612 in k3850 in a3756 in k4278 in k4391 in k4385 in k4271 in a4267 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in ... */
static void C_ccall f_3769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* a5144 in k5127 in k5118 in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in ... */
static void C_ccall f_5145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5145,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_retrieve2(lf[30],"main#\052host-extension\052"));
t3=C_mutate2(&lf[30] /* (set! main#*host-extension* ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* g612 in k3850 in a3756 in k4278 in k4391 in k4385 in k4271 in a4267 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in ... */
static void C_fcall f_3765(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3765,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3769,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_i_cadr(t2);
t5=C_i_cdr(((C_word*)t0)[2]);
if(C_truep(C_i_equalp(t4,t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3779,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:386: open-output-string */
t7=C_fast_retrieve(lf[128]);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k4030 in for-each-loop709 in k4007 in k3995 in k3989 in k3986 in g693 in k3981 in k3978 in k3969 in k3966 in main#show-depends in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in ... */
static void C_ccall f_4032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4022(t3,((C_word*)t0)[4],t2);}

/* a3630 in a3621 in trying-sources in k3603 in main#with-default-sources in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in ... */
static void C_ccall f_3631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3631,2,t0,t1);}
/* chicken-install.scm:346: print */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[70],lf[71]);}

/* k3789 in k3786 in k3783 in k3777 in g612 in k3850 in a3756 in k4278 in k4391 in k4385 in k4271 in a4267 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in ... */
static void C_ccall f_3791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3791,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3794,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[6];
t4=C_u_i_car(t3);
/* chicken-install.scm:386: ##sys#print */
t5=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,t4,C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k3795 in k3792 in k3789 in k3786 in k3783 in k3777 in g612 in k3850 in a3756 in k4278 in k4391 in k4385 in k4271 in a4267 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in ... */
static void C_ccall f_3797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3797,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3800,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[5];
t4=C_u_i_cdr(t3);
/* chicken-install.scm:386: ##sys#print */
t5=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,t4,C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k3792 in k3789 in k3786 in k3783 in k3777 in g612 in k3850 in a3756 in k4278 in k4391 in k4385 in k4271 in a4267 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in ... */
static void C_ccall f_3794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3794,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3797,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:386: ##sys#print */
t3=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[125],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* for-each-loop709 in k4007 in k3995 in k3989 in k3986 in g693 in k3981 in k3978 in k3969 in k3966 in main#show-depends in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_fcall f_4022(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4022,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4032,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-install.scm:430: g725 */
t5=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[87],t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3786 in k3783 in k3777 in g612 in k3850 in a3756 in k4278 in k4391 in k4385 in k4271 in a4267 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in ... */
static void C_ccall f_3788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3788,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3791,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm:386: ##sys#print */
t3=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[126],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k3783 in k3777 in g612 in k3850 in a3756 in k4278 in k4391 in k4385 in k4271 in a4267 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in ... */
static void C_ccall f_3785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3785,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3788,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_cadr(((C_word*)t0)[6]);
/* chicken-install.scm:386: ##sys#print */
t4=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k3688 in trying-sources in k3603 in main#with-default-sources in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in ... */
static void C_ccall f_3690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cadr(t1);
/* chicken-install.scm:351: resolve-location */
f_2864(((C_word*)t0)[2],t2);}

/* k3888 in k3881 in g643 in k3864 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in ... */
static void C_ccall f_3890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3890,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[122]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3896,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* chicken-install.scm:405: ##sys#print */
t6=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[192],C_SCHEME_FALSE,t3);}

/* k3894 in k3888 in k3881 in g643 in k3864 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in ... */
static void C_ccall f_3896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3899,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_cadr(((C_word*)t0)[7]);
/* chicken-install.scm:405: ##sys#print */
t4=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k3897 in k3894 in k3888 in k3881 in g643 in k3864 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in ... */
static void C_ccall f_3899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3902,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm:405: ##sys#print */
t3=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[191],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* a3726 in a3705 in a4169 in k4163 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in ... */
static void C_ccall f_3727(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3727,4,t0,t1,t2,t3);}
if(C_truep(t2)){
/* chicken-install.scm:371: values */
C_values(4,0,t1,t2,t3);}
else{
/* chicken-install.scm:372: next */
t4=((C_word*)t0)[2];
((C_proc2)C_fast_retrieve_proc(t4))(2,t4,t1);}}

/* a3720 in a3705 in a4169 in k4163 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in ... */
static void C_ccall f_3721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3721,2,t0,t1);}
t2=t1;
t3=((C_word*)t0)[2];
t4=((C_word*)t0)[3];
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[5];
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3462,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3467,a[2]=t3,a[3]=t5,a[4]=t6,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:311: call-with-current-continuation */
t9=*((C_word*)lf[184]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* k3674 in k3642 in trying-sources in k3603 in main#with-default-sources in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in ... */
static void C_ccall f_3676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3647(t2,C_i_cadr(t1));}

/* k5595 in a5576 in k5564 in k5561 in a5555 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in ... */
static void C_ccall f_5597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5597,2,t0,t1);}
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5599,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=C_i_check_list_2(((C_word*)t0)[3],lf[105]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5613,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5615,a[2]=t7,a[3]=t6,a[4]=t11,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_5615(t13,t9,((C_word*)t0)[3]);}

/* g1340 in k5595 in a5576 in k5564 in k5561 in a5555 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in ... */
static C_word C_fcall f_5599(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_overflow_check;
t2=C_i_car(t1);
return(C_a_i_list3(&a,3,t2,lf[233],((C_word*)t0)[2]));}

/* a3756 in k4278 in k4391 in k4385 in k4271 in a4267 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in ... */
static void C_ccall f_3757(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3757,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3852,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=C_i_car(t2);
/* chicken-install.scm:382: string->symbol */
t5=*((C_word*)lf[135]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3753 in k4278 in k4391 in k4385 in k4271 in a4267 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in ... */
static void C_ccall f_3755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:376: append */
t2=*((C_word*)lf[90]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1,lf[121]);}

/* main#info->egg in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in ... */
static void C_ccall f_6188(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6188,3,t0,t1,t2);}
t3=C_i_cdr(t2);
if(C_truep((C_truep(C_i_equalp(t3,lf[219]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t3,lf[220]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t3,lf[221]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
t4=t2;
t5=C_u_i_car(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k6816 in k6802 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_ccall f_6818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6818,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_retrieve2(lf[26],"main#\052csc-nonfeatures\052"));
t3=C_mutate2(&lf[26] /* (set! main#*csc-nonfeatures* ...) */,t2);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
/* chicken-install.scm:964: loop */
t7=((C_word*)((C_word*)t0)[3])[1];
f_6215(t7,((C_word*)t0)[4],t6,((C_word*)((C_word*)t0)[5])[1]);}

/* k3745 in k4278 in k4391 in k4385 in k4271 in a4267 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in ... */
static void C_ccall f_3747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:375: string-concatenate */
t2=C_fast_retrieve(lf[118]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6802 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f_6804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6818,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm:963: string->symbol */
t4=*((C_word*)lf[135]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* main#ext-version in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 */
static void C_fcall f_3005(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3005,NULL,2,t1,t2);}
t3=C_eqp(t2,lf[44]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3015,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_3015(t5,t3);}
else{
t5=C_i_equalp(t2,lf[50]);
if(C_truep(t5)){
t6=t4;
f_3015(t6,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3051,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:218: ->string */
t7=C_fast_retrieve(lf[47]);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}}}

/* k6684 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f_6686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:942: print */
t2=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* main#setup-proxy in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in ... */
static void C_fcall f_6152(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6152,NULL,2,t1,t2);}
if(C_truep(C_i_stringp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6162,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:829: irregex-match */
t4=C_fast_retrieve(lf[216]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[217],t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k5397 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in ... */
static void C_ccall f_5399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5402,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:662: print* */
t3=*((C_word*)lf[234]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[318]);}

/* a3705 in a4169 in k4163 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in ... */
static void C_ccall f_3706(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3706,5,t0,t1,t2,t3,t4);}
t5=t2;
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3721,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3727,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:369: ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}
else{
/* chicken-install.scm:368: values */
C_values(4,0,t1,C_SCHEME_FALSE,lf[185]);}}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1738)){
C_save(t1);
C_rereclaim2(1738*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,442);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\012modules.db");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\016setup.defaults");
lf[16]=C_h_intern(&lf[16],4,"http");
lf[40]=C_h_intern(&lf[40],17,"\003syspeek-c-string");
lf[44]=C_h_intern(&lf[44],7,"chicken");
lf[45]=C_h_intern(&lf[45],15,"chicken-version");
lf[46]=C_h_intern(&lf[46],7,"version");
lf[47]=C_h_intern(&lf[47],8,"->string");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\0050.0.0");
lf[49]=C_h_intern(&lf[49],21,"extension-information");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[51]=C_h_intern(&lf[51],24,"\003syscore-library-modules");
lf[52]=C_h_intern(&lf[52],23,"\003syscore-syntax-modules");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[55]=C_h_intern(&lf[55],5,"error");
lf[56]=C_h_intern(&lf[56],13,"string-append");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000JYour CHICKEN version is not recent enough to use this extension - version ");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\025 or newer is required");
lf[59]=C_h_intern(&lf[59],20,"setup-api#version>=\077");
lf[60]=C_h_intern(&lf[60],7,"warning");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\0007invalid dependency syntax in extension meta information");
lf[62]=C_h_intern(&lf[62],2,"or");
lf[68]=C_h_intern(&lf[68],4,"exit");
lf[69]=C_h_intern(&lf[69],5,"print");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000,Could not determine a source of extensions. ");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000.Please specify a valid location and transport.");
lf[72]=C_h_intern(&lf[72],19,"with-output-to-port");
lf[73]=C_h_intern(&lf[73],18,"\003sysstandard-error");
lf[74]=C_h_intern(&lf[74],5,"local");
lf[75]=C_h_intern(&lf[75],9,"transport");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\027missing transport entry");
lf[77]=C_h_intern(&lf[77],8,"location");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\026missing location entry");
lf[79]=C_h_intern(&lf[79],13,"make-pathname");
lf[80]=C_h_intern(&lf[80],17,"current-directory");
lf[81]=C_h_intern(&lf[81],18,"absolute-pathname\077");
lf[83]=C_h_intern(&lf[83],7,"depends");
lf[84]=C_h_intern(&lf[84],19,"\003sysstandard-output");
lf[85]=C_h_intern(&lf[85],6,"printf");
lf[86]=C_h_intern(&lf[86],8,"for-each");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\001\011");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[89]=C_h_intern(&lf[89],5,"needs");
lf[90]=C_h_intern(&lf[90],6,"append");
lf[91]=C_h_intern(&lf[91],20,"with-input-from-file");
lf[92]=C_h_intern(&lf[92],4,"read");
lf[93]=C_h_intern(&lf[93],12,"file-exists\077");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\004meta");
lf[96]=C_h_intern(&lf[96],9,"\003sysprint");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000$ dependencies as reported in .meta:\012");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\003Egg");
lf[99]=C_h_intern(&lf[99],15,"foreign-depends");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\007Foreign");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\034fetching meta information...");
lf[103]=C_h_intern(&lf[103],7,"reverse");
lf[104]=C_h_intern(&lf[104],12,"test-depends");
lf[105]=C_h_intern(&lf[105],3,"map");
lf[106]=C_h_intern(&lf[106],26,"setup-api#remove-extension");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000)removing previously installed extension `");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\005\047 ...");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\012 upgrade: ");
lf[110]=C_h_intern(&lf[110],18,"string-intersperse");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\002, ");
lf[112]=C_h_intern(&lf[112],6,"unzip1");
lf[113]=C_h_intern(&lf[113],10,"yes-or-no\077");
lf[114]=C_h_intern(&lf[114],8,"\000default");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\002no");
lf[116]=C_h_intern(&lf[116],6,"\000abort");
lf[117]=C_h_intern(&lf[117],21,"setup-api#abort-setup");
lf[118]=C_h_intern(&lf[118],18,"string-concatenate");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000:The following installed extensions are outdated, because `");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\033\047 requires later versions:\012");
lf[121]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\0000\012Do you want to replace the existing extensions\077\376\377\016");
lf[122]=C_h_intern(&lf[122],7,"sprintf");
lf[123]=C_h_intern(&lf[123],17,"get-output-string");
lf[124]=C_h_intern(&lf[124],16,"\003syswrite-char-0");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\036\047 overrides required version `");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\020\047 of extension `");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\011version `");
lf[128]=C_h_intern(&lf[128],18,"open-output-string");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\003\077\077\077");
lf[130]=C_h_intern(&lf[130],4,"conc");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\002 (");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\004 -> ");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[135]=C_h_intern(&lf[135],14,"string->symbol");
lf[136]=C_h_intern(&lf[136],10,"filter-map");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\012 missing: ");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\002, ");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\033checking dependencies for `");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\005\047 ...");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000)extension is not targeted for this system");
lf[143]=C_h_intern(&lf[143],8,"platform");
lf[144]=C_h_intern(&lf[144],8,"feature\077");
lf[145]=C_h_intern(&lf[145],3,"and");
lf[146]=C_h_intern(&lf[146],5,"every");
lf[147]=C_h_intern(&lf[147],3,"any");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid `platform\047 property");
lf[149]=C_h_intern(&lf[149],3,"not");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid `platform\047 property");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\027checking platform for `");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\005\047 ...");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\013extension `");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\024\047 has no .meta file ");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000!- assuming it has no dependencies");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\004meta");
lf[157]=C_h_intern(&lf[157],6,"delete");
lf[158]=C_h_intern(&lf[158],3,"eq\077");
lf[159]=C_h_intern(&lf[159],9,"condition");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\023TCP connect timeout");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\023HTTP protocol error");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[165]=C_h_intern(&lf[165],19,"print-error-message");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\015Server error:");
lf[167]=C_h_intern(&lf[167],5,"abort");
lf[168]=C_h_intern(&lf[168],3,"exn");
lf[169]=C_h_intern(&lf[169],20,"setup-download-error");
lf[170]=C_h_intern(&lf[170],10,"http-fetch");
lf[171]=C_h_intern(&lf[171],3,"net");
lf[172]=C_h_intern(&lf[172],33,"setup-download#retrieve-extension");
lf[173]=C_h_intern(&lf[173],8,"\000version");
lf[174]=C_h_intern(&lf[174],12,"\000destination");
lf[175]=C_h_intern(&lf[175],6,"\000tests");
lf[176]=C_h_intern(&lf[176],9,"\000username");
lf[177]=C_h_intern(&lf[177],9,"\000password");
lf[178]=C_h_intern(&lf[178],6,"\000trunk");
lf[179]=C_h_intern(&lf[179],11,"\000proxy-host");
lf[180]=C_h_intern(&lf[180],11,"\000proxy-port");
lf[181]=C_h_intern(&lf[181],16,"\000proxy-user-pass");
lf[182]=C_h_intern(&lf[182],6,"\000clean");
lf[183]=C_h_intern(&lf[183],22,"with-exception-handler");
lf[184]=C_h_intern(&lf[184],30,"call-with-current-continuation");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\014 located at ");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\036extension or version not found");
lf[189]=C_h_intern(&lf[189],9,"directory");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000&\047 overrides explicitly given version `");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\020\047 of extension `");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\011version `");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\014overriding: ");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\016retrieving ...");
lf[195]=C_h_intern(&lf[195],26,"setup-api#remove-directory");
lf[196]=C_h_intern(&lf[196],34,"setup-download#temporary-directory");
lf[197]=C_h_intern(&lf[197],14,"symbol->string");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\035internal error - bad egg spec");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\007mapped ");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\004 to ");
lf[201]=C_h_intern(&lf[201],5,"lset=");
lf[202]=C_h_intern(&lf[202],17,"delete-duplicates");
lf[203]=C_h_intern(&lf[203],4,"find");
lf[204]=C_h_intern(&lf[204],10,"append-map");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000/shell command terminated with nonzero exit code");
lf[207]=C_h_intern(&lf[207],6,"system");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[213]=C_h_intern(&lf[213],23,"irregex-match-substring");
lf[214]=C_h_intern(&lf[214],24,"get-environment-variable");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\012proxy_auth");
lf[216]=C_h_intern(&lf[216],13,"irregex-match");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\033(http://)\077([^:]+):\077([0-9]\052)");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\007unknown");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\005trunk");
lf[222]=C_h_intern(&lf[222],25,"\003sysimplicit-exit-handler");
lf[223]=C_h_intern(&lf[223],7,"newline");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000B`-deploy\047 only makes sense in combination with `-prefix DIRECTORY`");
lf[225]=C_h_intern(&lf[225],19,"setup-api#copy-file");
lf[226]=C_h_intern(&lf[226],15,"repository-path");
lf[227]=C_h_intern(&lf[227],5,"write");
lf[228]=C_h_intern(&lf[228],19,"with-output-to-file");
lf[229]=C_h_intern(&lf[229],8,"string<\077");
lf[230]=C_h_intern(&lf[230],4,"sort");
lf[231]=C_h_intern(&lf[231],18,"\003sysmodule-exports");
lf[232]=C_h_intern(&lf[232],6,"syntax");
lf[233]=C_h_intern(&lf[233],5,"value");
lf[234]=C_h_intern(&lf[234],6,"print\052");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[236]=C_h_intern(&lf[236],15,"\003sysmodule-name");
lf[237]=C_h_intern(&lf[237],16,"\003sysmodule-table");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\023generating database");
lf[239]=C_h_intern(&lf[239],20,"\003syswarnings-enabled");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\027Failed to import from `");
lf[241]=C_h_intern(&lf[241],6,"import");
lf[242]=C_h_intern(&lf[242],4,"eval");
lf[243]=C_h_intern(&lf[243],16,"\003sysdynamic-wind");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\034loading import libraries ...");
lf[245]=C_h_intern(&lf[245],7,"irregex");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\034.\052/([^/]+)\134.import\134.(scm|so)");
lf[247]=C_h_intern(&lf[247],26,"create-temporary-directory");
lf[248]=C_h_intern(&lf[248],4,"glob");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\012\052.import.\052");
lf[250]=C_h_intern(&lf[250],2,"pp");
lf[251]=C_h_intern(&lf[251],6,"cadadr");
lf[252]=C_h_intern(&lf[252],37,"setup-download#gather-egg-information");
lf[253]=C_h_intern(&lf[253],7,"display");
lf[254]=C_h_intern(&lf[254],30,"setup-download#list-extensions");
lf[255]=C_h_intern(&lf[255],6,"\000quiet");
lf[256]=C_h_intern(&lf[256],16,"change-directory");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\023~a -s run.scm ~a ~a");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000$\012nevertheless trying to continue ...");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000\007testing");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\014 extension `");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\011\047 failed:");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\005tests");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\015tests/run.scm");
lf[264]=C_h_intern(&lf[264],10,"directory\077");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\005tests");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\005tests");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\012installing");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\034-e \042(setup-error-handling)\042 ");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\027 -e \042(sudo-install #t)\042");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\035 -e \042(keep-intermediates #t)\042");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\035 -e \042(setup-install-mode #f)\042");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\031 -e \042(host-extension #t)\042");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\032 -e \042(deployment-mode #t)\042");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\006 -bnq ");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\0009-e \042(require-library setup-api)\042 -e \042(import setup-api)\042 ");
lf[283]=C_h_intern(&lf[283],19,"setup-api#shellpath");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\006.setup");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\002)\042");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\031 -e \042(extra-nonfeatures \047");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\002)\042");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\026 -e \042(extra-features \047");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\004\134\042)\042");
lf[292]=C_h_intern(&lf[292],18,"normalize-pathname");
lf[293]=C_h_intern(&lf[293],4,"unix");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\027 -e \042(runtime-prefix \134\042");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\004\134\042)\042");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\033 -e \042(destination-prefix \134\042");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[299]=C_h_intern(&lf[299],22,"setup-api#sudo-install");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\005\134\042))\042");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\005\134\042 \134\042");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000$-e \042(extension-name-and-version \047(\134\042");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\014-setup-mode ");
lf[305]=C_h_intern(&lf[305],1,"\052");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\001o");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\003dll");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[310]=C_h_intern(&lf[310],3,"seq");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[312]=C_h_intern(&lf[312],12,"delete-file\052");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[314]=C_h_intern(&lf[314],10,"find-files");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[316]=C_h_intern(&lf[316],5,"\000test");
lf[317]=C_h_intern(&lf[317],7,"\000action");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\033deleting stale binaries ...");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\033deleting stale binaries ...");
lf[320]=C_h_intern(&lf[320],12,"dynamic-wind");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\036changing current directory to ");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\031installing for target ...");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\005xcopy");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\005cp -r");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\010~a ~a ~a");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\001\052");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\047copying sources for target installation");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\013installing ");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\026aborting installation.");
lf[331]=C_h_intern(&lf[331],17,"\003sysstring-append");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000@You specified `-no-install\047, but this extension has dependencies");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000C that are required for building.\012Do you still want to install them\077");
lf[334]=C_h_intern(&lf[334],4,"iota");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\016install order:");
lf[336]=C_h_intern(&lf[336],7,"fprintf");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\002\012\012");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\030\012Unresolved dependency: ");
lf[339]=C_h_intern(&lf[339],10,"list-index");
lf[340]=C_h_intern(&lf[340],16,"topological-sort");
lf[341]=C_h_intern(&lf[341],8,"string=\077");
lf[342]=C_h_intern(&lf[342],6,"remove");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000;no default location defined - please use `-location\047 option");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000=no default transport defined - please use `-transport\047 option");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\0009 currently installed extensions - do you want to proceed\077");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\030About to re-install all ");
lf[347]=C_h_intern(&lf[347],6,"equal\077");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[349]=C_h_intern(&lf[349],8,"egg-name");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000Dinstalled extension has no information about which egg it belongs to");
lf[351]=C_h_intern(&lf[351],13,"pathname-file");
lf[352]=C_h_intern(&lf[352],9,"read-file");
lf[353]=C_decode_literal(C_heaptop,"\376B\000\000\001\052");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\000\010chicken/");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\033no setup-scripts to process");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\007\052.setup");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000\036invalid entry in defaults file");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000$\047 does not match setup-API version (");
lf[362]=C_decode_literal(C_heaptop,"\376B\000\000\026version of installed `");
lf[363]=C_h_intern(&lf[363],6,"server");
lf[364]=C_h_intern(&lf[364],8,"split-at");
lf[365]=C_h_intern(&lf[365],2,"->");
lf[366]=C_h_intern(&lf[366],5,"alias");
lf[367]=C_h_intern(&lf[367],7,"string\077");
lf[368]=C_h_intern(&lf[368],8,"override");
lf[369]=C_h_intern(&lf[369],4,"hack");
lf[370]=C_h_intern(&lf[370],12,"chicken-home");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\012\007usage: chicken-install [OPTION | EXTENSION[:VERSION]] ...\012\012  -h   -help    "
"                show this message and exit\012       -version                 show "
"version and exit\012       -force                   don\047t ask, install even if vers"
"ions don\047t match\012  -k   -keep                    keep temporary files\012  -x   -ke"
"ep-installed          install only if not already installed\012       -reinstall   "
"            reinstall all currently installed extensions\012  -l   -location LOCATI"
"ON       install from given location instead of default\012  -t   -transport TRANSP"
"ORT     use given transport instead of default\012       -proxy HOST[:PORT]       d"
"ownload via HTTP proxy\012  -s   -sudo                    use sudo(1) for filesyste"
"m operations\012  -r   -retrieve                only retrieve egg into current dire"
"ctory, don\047t install\012  -n   -no-install              do not install, just build "
"(implies `-keep\047)\012  -p   -prefix PREFIX           change installation prefix to "
"PREFIX\012       -list                    list extensions available over selected t"
"ransport and location\012       -host                    when cross-compiling, comp"
"ile extension only for host\012       -target                  when cross-compiling"
", compile extension only for target\012       -test                    run included"
" test-cases, if available\012       -username USER           set username for trans"
"ports that require this\012       -password PASS           set password for transpo"
"rts that require this\012  -i   -init DIRECTORY          initialize empty alternati"
"ve repository\012  -u   -update-db               update export database\012       -rep"
"ository              print path used for egg installation\012       -deploy        "
"          build extensions for deployment\012       -trunk                   build "
"trunk instead of tagged version (only local)\012  -D   -feature FEATURE         fea"
"tures to pass to sub-invocations of `csc\047\012       -debug                   enable"
" full display of error message information\012       -keep-going              conti"
"nue installation even if dependency fails\012       -scan DIRECTORY          scan l"
"ocal directory for highest available egg versions\012       -override FILENAME     "
"  override versions for installed eggs with information from file\012       -csi FI"
"LENAME            use given pathname for invocations of \042csi\042\012       -show-depen"
"ds            display a list of egg dependencies for the given egg(s)\012       -sh"
"ow-foreign-depends    display a list of foreign dependencies for the given egg(s"
")\012\012chicken-install recognizes the http_proxy, and proxy_auth environment variabl"
"es, if set.\012");
lf[373]=C_decode_literal(C_heaptop,"\376B\000\000\013-repository");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000\006-force");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000\002-k");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000\005-keep");
lf[377]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[378]=C_decode_literal(C_heaptop,"\376B\000\000\005-sudo");
lf[379]=C_decode_literal(C_heaptop,"\376B\000\000\002-r");
lf[380]=C_decode_literal(C_heaptop,"\376B\000\000\011-retrieve");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000\002-l");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\000\011-location");
lf[383]=C_decode_literal(C_heaptop,"\376B\000\000\002-t");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000\012-transport");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000\002-p");
lf[386]=C_decode_literal(C_heaptop,"\376B\000\000\007-prefix");
lf[387]=C_decode_literal(C_heaptop,"\376B\000\000\002-n");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000\013-no-install");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000\010-version");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000\002-u");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000\012-update-db");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\002-i");
lf[393]=C_decode_literal(C_heaptop,"\376B\000\000\005-init");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\004copy");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\005cp -r");
lf[396]=C_decode_literal(C_heaptop,"\376B\000\000\010~a ~a ~a");
lf[397]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014setup-api.so\376\003\000\000\002\376B\000\000\023setup-api.import.so\376\003\000\000\002\376B\000\000\021setup-download.so\376\003"
"\000\000\002\376B\000\000\030setup-download.import.so\376\003\000\000\002\376B\000\000\021chicken.import.so\376\003\000\000\002\376B\000\000\021lolevel.imp"
"ort.so\376\003\000\000\002\376B\000\000\020srfi-1.import.so\376\003\000\000\002\376B\000\000\020srfi-4.import.so\376\003\000\000\002\376B\000\000\031data-structu"
"res.import.so\376\003\000\000\002\376B\000\000\017ports.import.so\376\003\000\000\002\376B\000\000\017files.import.so\376\003\000\000\002\376B\000\000\017posix.i"
"mport.so\376\003\000\000\002\376B\000\000\021srfi-13.import.so\376\003\000\000\002\376B\000\000\021srfi-69.import.so\376\003\000\000\002\376B\000\000\020extras.i"
"mport.so\376\003\000\000\002\376B\000\000\021srfi-14.import.so\376\003\000\000\002\376B\000\000\015tcp.import.so\376\003\000\000\002\376B\000\000\021foreign.impo"
"rt.so\376\003\000\000\002\376B\000\000\021srfi-18.import.so\376\003\000\000\002\376B\000\000\017utils.import.so\376\003\000\000\002\376B\000\000\015csi.import.so"
"\376\003\000\000\002\376B\000\000\021irregex.import.so\376\003\000\000\002\376B\000\000\010types.db\376\377\016");
lf[398]=C_decode_literal(C_heaptop,"\376B\000\000\032copying required files to ");
lf[399]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[400]=C_decode_literal(C_heaptop,"\376B\000\000\006-proxy");
lf[401]=C_decode_literal(C_heaptop,"\376B\000\000\002-D");
lf[402]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[403]=C_decode_literal(C_heaptop,"\376B\000\000\013-no-feature");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\005-test");
lf[405]=C_decode_literal(C_heaptop,"\376B\000\000\005-host");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\007-target");
lf[407]=C_decode_literal(C_heaptop,"\376B\000\000\006-debug");
lf[408]=C_decode_literal(C_heaptop,"\376B\000\000\007-deploy");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000\011-username");
lf[410]=C_decode_literal(C_heaptop,"\376B\000\000\005-scan");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000\011-override");
lf[412]=C_decode_literal(C_heaptop,"\376B\000\000\002-x");
lf[413]=C_decode_literal(C_heaptop,"\376B\000\000\017-keep-installed");
lf[414]=C_decode_literal(C_heaptop,"\376B\000\000\012-reinstall");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000\006-trunk");
lf[416]=C_decode_literal(C_heaptop,"\376B\000\000\013-keep-going");
lf[417]=C_decode_literal(C_heaptop,"\376B\000\000\005-list");
lf[418]=C_decode_literal(C_heaptop,"\376B\000\000\004-csi");
lf[419]=C_decode_literal(C_heaptop,"\376B\000\000\011-password");
lf[420]=C_decode_literal(C_heaptop,"\376B\000\000\015-show-depends");
lf[421]=C_decode_literal(C_heaptop,"\376B\000\000\025-show-foreign-depends");
lf[422]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000k\376\003\000\000\002\376\377\012\000\000l\376\003\000\000\002\376\377\012\000\000t\376\003\000\000\002\376\377\012\000\000s\376\003\000\000\002\376\377\012\000\000p\376\003\000\000\002\376\377\012\000\000r\376\003\000"
"\000\002\376\377\012\000\000n\376\003\000\000\002\376\377\012\000\000v\376\003\000\000\002\376\377\012\000\000i\376\003\000\000\002\376\377\012\000\000u\376\003\000\000\002\376\377\012\000\000D\376\377\016");
lf[423]=C_h_intern(&lf[423],16,"\003sysstring->list");
lf[424]=C_h_intern(&lf[424],9,"substring");
lf[425]=C_decode_literal(C_heaptop,"\376B\000\000\005setup");
lf[426]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[427]=C_h_intern(&lf[427],18,"pathname-directory");
lf[428]=C_h_intern(&lf[428],18,"pathname-extension");
lf[429]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[430]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[431]=C_decode_literal(C_heaptop,"\376B\000\000\012http_proxy");
lf[432]=C_decode_literal(C_heaptop,"\376B\000\000\014([^:]+):(.+)");
lf[433]=C_h_intern(&lf[433],22,"command-line-arguments");
lf[434]=C_h_intern(&lf[434],17,"register-feature!");
lf[435]=C_h_intern(&lf[435],15,"chicken-install");
lf[436]=C_h_intern(&lf[436],14,"\000cross-chicken");
lf[437]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[438]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[439]=C_h_intern(&lf[439],11,"\003sysrequire");
lf[440]=C_h_intern(&lf[440],9,"setup-api");
lf[441]=C_h_intern(&lf[441],14,"setup-download");
C_register_lf2(lf,442,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2288,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k6677 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f_6679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:943: exit */
t2=C_fast_retrieve(lf[68]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k6133 in main#command in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in ... */
static void C_ccall f_6135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6135,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6138,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:781: print */
t4=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[211],t2);}

/* k6136 in k6133 in main#command in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in ... */
static void C_ccall f_6138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:782: $system */
f_6020(((C_word*)t0)[2],((C_word*)t0)[3]);}

/* main#command in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in ... */
static void C_fcall f_6131(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6131,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6135,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t4,*((C_word*)lf[122]+1),t2,t3);}

/* for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in ... */
static void C_fcall f_4486(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4486,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4496,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=C_i_assoc(t4,C_retrieve2(lf[63],"main#\052eggs+dirs+vers\052"));
if(C_truep(t6)){
t7=t5;
t8=t6;
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4156,a[2]=t8,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:442: delete */
t10=C_fast_retrieve(lf[157]);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,t8,C_retrieve2(lf[63],"main#\052eggs+dirs+vers\052"),*((C_word*)lf[158]+1));}
else{
t7=C_i_pairp(t4);
t8=(C_truep(t7)?C_u_i_car(t4):t4);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4165,a[2]=t9,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t11=t10;
t12=t4;
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3866,a[2]=t12,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(t12))){
t14=C_u_i_car(t12);
/* chicken-install.scm:400: string->symbol */
t15=*((C_word*)lf[135]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t13,t14);}
else{
/* chicken-install.scm:400: string->symbol */
t14=*((C_word*)lf[135]+1);
((C_proc3)(void*)(*((C_word*)t14+1)))(3,t14,t13,t12);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4471 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in ... */
static void C_ccall f_4473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4463(t3,((C_word*)t0)[4],t2);}

/* a6118 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in ... */
static void C_ccall f_6119(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6119,5,t0,t1,t2,t3,t4);}
if(C_truep(t2)){
/* chicken-install.scm:769: setup-download#list-extensions */
((C_proc16)C_fast_retrieve_symbol_proc(lf[254]))(16,*((C_word*)lf[254]+1),t1,t2,t3,lf[255],C_SCHEME_TRUE,lf[176],C_retrieve2(lf[11],"main#\052username\052"),lf[177],C_retrieve2(lf[12],"main#\052password\052"),lf[179],C_retrieve2(lf[18],"main#\052proxy-host\052"),lf[180],C_retrieve2(lf[19],"main#\052proxy-port\052"),lf[181],C_retrieve2(lf[20],"main#\052proxy-user-pass\052"));}
else{
/* chicken-install.scm:777: next */
t5=t4;
((C_proc2)C_fast_retrieve_proc(t5))(2,t5,t1);}}

/* k6642 in k6635 in k6619 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in ... */
static void C_ccall f_6644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:934: normalize-pathname */
t2=C_fast_retrieve(lf[292]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6646 in k6635 in k6619 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in ... */
static void C_ccall f_6648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:935: make-pathname */
t2=C_fast_retrieve(lf[79]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* k6109 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f_6111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:762: make-pathname */
t2=C_fast_retrieve(lf[79]);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,lf[353],lf[354]);}

/* k3019 in k3013 in main#ext-version in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in ... */
static void C_ccall f_3021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=t1;
t4=C_i_assq(lf[46],t3);
if(C_truep(t4)){
t5=C_i_cadr(t4);
/* chicken-install.scm:226: ->string */
t6=C_fast_retrieve(lf[47]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t2,t5);}
else{
t5=t2;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[48]);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6105 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f_6107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:762: glob */
t2=C_fast_retrieve(lf[248]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6635 in k6619 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_ccall f_6637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6637,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_6628(2,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6644,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6648,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:935: current-directory */
t4=C_fast_retrieve(lf[80]);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6101 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f_6103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:750: filter-map */
t2=C_fast_retrieve(lf[136]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k3013 in main#ext-version in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in ... */
static void C_fcall f_3015(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3015,NULL,2,t0,t1);}
if(C_truep(t1)){
/* chicken-install.scm:221: chicken-version */
t2=C_fast_retrieve(lf[45]);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3021,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:222: extension-information */
t3=C_fast_retrieve(lf[49]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}}

/* k6619 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f_6621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6621,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6628,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6637,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:932: absolute-pathname? */
t6=C_fast_retrieve(lf[81]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}

/* k6626 in k6619 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_ccall f_6628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_mutate2(&lf[27] /* (set! main#*prefix* ...) */,t1);
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
t5=C_u_i_cdr(t4);
/* chicken-install.scm:936: loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_6215(t6,((C_word*)t0)[4],t5,((C_word*)((C_word*)t0)[5])[1]);}

/* main#check-dependency in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 */
static void C_fcall f_3083(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3083,NULL,2,t1,t2);}
t3=C_i_symbolp(t2);
t4=(C_truep(t3)?t3:C_i_stringp(t2));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3100,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[23],"main#\052deploy\052"))){
/* chicken-install.scm:240: ->string */
t6=C_fast_retrieve(lf[47]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3116,a[2]=t1,a[3]=t5,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:241: ext-version */
f_3005(t6,t2);}}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3122,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_listp(t2))){
t6=C_i_car(t2);
t7=t5;
f_3122(t7,C_eqp(lf[62],t6));}
else{
t6=t5;
f_3122(t6,C_SCHEME_FALSE);}}}

/* k4439 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in ... */
static void C_ccall f_4441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:494: warning */
t2=C_fast_retrieve(lf[60]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in ... */
static void C_fcall f_4463(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4463,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4473,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=C_i_car(t6);
if(C_truep(C_i_member(t7,C_retrieve2(lf[65],"main#\052checked\052")))){
t8=C_SCHEME_UNDEFINED;
t9=t5;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=C_u_i_car(t6);
t9=C_a_i_cons(&a,2,t8,C_retrieve2(lf[65],"main#\052checked\052"));
t10=C_mutate2(&lf[65] /* (set! main#*checked* ...) */,t9);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4235,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t12=C_i_cadr(t6);
t13=C_u_i_car(t6);
/* chicken-install.scm:458: make-pathname */
t14=C_fast_retrieve(lf[79]);
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,t11,t12,t13,lf[156]);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5722 in a5715 in a5709 in a5703 in k5694 in g1246 in a5689 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in ... */
static void C_ccall f_5724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5724,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[122]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5730,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm:687: ##sys#print */
t6=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[240],C_SCHEME_FALSE,t3);}

/* k6557 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f_6559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_mutate2(&lf[14] /* (set! main#*default-location* ...) */,t2);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
/* chicken-install.scm:923: loop */
t7=((C_word*)((C_word*)t0)[3])[1];
f_6215(t7,((C_word*)t0)[4],t6,((C_word*)((C_word*)t0)[5])[1]);}

/* a5715 in a5709 in a5703 in k5694 in g1246 in a5689 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in ... */
static void C_ccall f_5716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5716,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5724,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:687: open-output-string */
t3=C_fast_retrieve(lf[128]);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* a5709 in a5703 in k5694 in g1246 in a5689 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in ... */
static void C_ccall f_5710(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5710,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5716,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:682: k1257 */
t4=((C_word*)t0)[3];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t1,t3);}

/* k6586 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f_6588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6588,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6592,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm:926: string->symbol */
t4=*((C_word*)lf[135]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* k7289 in k7104 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_ccall f_7291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7291,2,t0,t1);}
if(C_truep(C_i_equalp(lf[425],t1))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7208,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm:1033: pathname-file */
t3=C_fast_retrieve(lf[351]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7251,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm:1047: irregex-match */
t3=C_fast_retrieve(lf[216]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[7],((C_word*)t0)[6]);}}

/* a5703 in k5694 in g1246 in a5689 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in ... */
static void C_ccall f_5704(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5704,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5710,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5741,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:682: with-exception-handler */
t5=C_fast_retrieve(lf[183]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* k3226 in k3213 in k3210 in k3120 in main#check-dependency in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in ... */
static void C_ccall f_3228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:266: values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k3210 in k3120 in main#check-dependency in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in ... */
static void C_fcall f_3212(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3212,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3215,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* chicken-install.scm:264: ext-version */
f_3005(t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3309,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:284: warning */
t3=C_fast_retrieve(lf[60]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[61],((C_word*)t0)[3]);}}

/* k3213 in k3210 in k3120 in main#check-dependency in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in ... */
static void C_ccall f_3215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3215,2,t0,t1);}
t2=t1;
t3=C_retrieve2(lf[23],"main#\052deploy\052");
t4=(C_truep(C_retrieve2(lf[23],"main#\052deploy\052"))?C_retrieve2(lf[23],"main#\052deploy\052"):C_i_not(t2));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3228,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=((C_word*)t0)[3];
t7=C_u_i_car(t6);
/* chicken-install.scm:267: ->string */
t8=C_fast_retrieve(lf[47]);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t5,t7);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3291,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3295,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=C_i_cadr(((C_word*)t0)[3]);
/* chicken-install.scm:269: ->string */
t8=C_fast_retrieve(lf[47]);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}}

/* k5189 in k5178 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in ... */
static void C_ccall f_5191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5191,2,t0,t1);}
/* chicken-install.scm:613: command */
f_6131(((C_word*)t0)[2],lf[325],C_a_i_list(&a,3,((C_word*)t0)[3],t1,((C_word*)t0)[4]));}

/* k3511 in k3499 in k3487 in a3478 in a3472 in a3466 in a3720 in a3705 in a4169 in k4163 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_fcall f_3513(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3513,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3516,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:332: print */
t4=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[166]);}
else{
t2=((C_word*)t0)[2];
/* chicken-install.scm:336: abort */
t3=C_fast_retrieve(lf[167]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],t2);}}

/* k4422 in map-loop816 in k4385 in k4271 in a4267 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in ... */
static void C_fcall f_4424(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4424,NULL,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4395(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4395(t6,((C_word*)t0)[5],t5);}}

/* k3514 in k3511 in k3499 in k3487 in a3478 in a3472 in a3466 in a3720 in a3705 in a4169 in k4163 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in ... */
static void C_ccall f_3516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3516,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3519,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:333: print-error-message */
t3=C_fast_retrieve(lf[165]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k7269 in g1760 in k7249 in k7289 in k7104 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in ... */
static void C_ccall f_7271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7271,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7275,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm:1053: irregex-match-substring */
t4=C_fast_retrieve(lf[213]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[6],C_fix(2));}

/* k3517 in k3514 in k3511 in k3499 in k3487 in a3478 in a3472 in a3466 in a3720 in a3705 in a4169 in k4163 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in ... */
static void C_ccall f_3519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:334: values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_FALSE,lf[164]);}

/* k7273 in k7269 in g1760 in k7249 in k7289 in k7104 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in ... */
static void C_ccall f_7275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7275,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1),((C_word*)((C_word*)t0)[3])[1]);
/* chicken-install.scm:1049: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6215(t3,((C_word*)t0)[5],((C_word*)t0)[6],t2);}

/* a5764 in a5740 in a5703 in k5694 in g1246 in a5689 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in ... */
static void C_ccall f_5765(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_5765r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5765r(t0,t1,t2);}}

static void C_ccall f_5765r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5771,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:682: k1257 */
t4=((C_word*)t0)[2];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t1,t3);}

/* k5761 in a5746 in a5740 in a5703 in k5694 in g1246 in a5689 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in ... */
static void C_ccall f_5763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:688: string->symbol */
t2=*((C_word*)lf[135]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3499 in k3487 in a3478 in a3472 in a3466 in a3720 in a3705 in a4169 in k4163 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in ... */
static void C_fcall f_3501(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3501,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3504,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:329: print */
t3=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[163]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3513,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=C_i_memv(lf[168],((C_word*)t0)[4]);
t4=t2;
f_3513(t4,(C_truep(t3)?C_i_memv(lf[169],((C_word*)t0)[4]):C_SCHEME_FALSE));}
else{
t3=t2;
f_3513(t3,C_SCHEME_FALSE);}}}

/* k5178 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in ... */
static void C_ccall f_5180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5180,2,t0,t1);}
t2=(C_truep(C_retrieve2(lf[17],"main#\052windows-shell\052"))?lf[323]:lf[324]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5191,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:616: make-pathname */
t5=C_fast_retrieve(lf[79]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[4],lf[326]);}

/* k3502 in k3499 in k3487 in a3478 in a3472 in a3466 in a3720 in a3705 in a4169 in k4163 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_ccall f_3504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:330: values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_FALSE,lf[162]);}

/* k7243 in k7236 in k7227 in k7206 in k7289 in k7104 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in ... */
static void C_ccall f_7245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:1042: make-pathname */
t2=C_fast_retrieve(lf[79]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* k6177 in k6173 in k6166 in k6160 in main#setup-proxy in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in ... */
static void C_ccall f_6179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6179,2,t0,t1);}
t2=C_mutate2(&lf[18] /* (set! main#*proxy-host* ...) */,t1);
t3=C_a_i_string_to_number(&a,2,((C_word*)t0)[2],C_fix(10));
if(C_truep(t3)){
t4=C_mutate2(&lf[19] /* (set! main#*proxy-port* ...) */,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=lf[19] /* main#*proxy-port* */ =C_fix(80);;
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k5757 in a5746 in a5740 in a5703 in k5694 in g1246 in a5689 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in ... */
static void C_ccall f_5759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5759,2,t0,t1);}
t2=C_a_i_list(&a,2,lf[241],t1);
/* chicken-install.scm:688: eval */
t3=C_fast_retrieve(lf[242]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k7058 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f_7060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_mutate2(&lf[12] /* (set! main#*password* ...) */,t2);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
/* chicken-install.scm:1014: loop */
t7=((C_word*)((C_word*)t0)[3])[1];
f_6215(t7,((C_word*)t0)[4],t6,((C_word*)((C_word*)t0)[5])[1]);}

/* k7249 in k7289 in k7104 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in ... */
static void C_ccall f_7251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7251,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7255,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:900: g1760 */
t3=t2;
f_7255(t3,((C_word*)t0)[5],t1);}
else{
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1]);
/* chicken-install.scm:1055: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_6215(t5,((C_word*)t0)[5],t3,t4);}}

/* k6173 in k6166 in k6160 in main#setup-proxy in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in ... */
static void C_ccall f_6175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6175,2,t0,t1);}
t2=C_mutate2(&lf[20] /* (set! main#*proxy-user-pass* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6179,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:832: irregex-match-substring */
t4=C_fast_retrieve(lf[213]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],C_fix(2));}

/* k6166 in k6160 in main#setup-proxy in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in ... */
static void C_ccall f_6168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6168,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6175,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:831: get-environment-variable */
t4=C_fast_retrieve(lf[214]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[215]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a5746 in a5740 in a5703 in k5694 in g1246 in a5689 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in ... */
static void C_ccall f_5747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5747,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5759,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5763,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:688: irregex-match-substring */
t4=C_fast_retrieve(lf[213]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_fix(1));}

/* g1760 in k7249 in k7289 in k7104 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_fcall f_7255(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7255,NULL,3,t0,t1,t2);}
t3=C_i_cdr(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7271,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm:1052: irregex-match-substring */
t6=C_fast_retrieve(lf[213]);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,C_fix(1));}

/* a5740 in a5703 in k5694 in g1246 in a5689 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in ... */
static void C_ccall f_5741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5741,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5747,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5765,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:682: ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* k6160 in main#setup-proxy in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in ... */
static void C_ccall f_6162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6162,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6168,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:830: irregex-match-substring */
t4=C_fast_retrieve(lf[213]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,C_fix(3));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k7223 in k7206 in k7289 in k7104 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_fcall f_7225(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7225,NULL,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1),C_retrieve2(lf[63],"main#\052eggs+dirs+vers\052"));
t3=C_mutate2(&lf[63] /* (set! main#*eggs+dirs+vers* ...) */,t2);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);
/* chicken-install.scm:1046: loop */
t7=((C_word*)((C_word*)t0)[5])[1];
f_6215(t7,((C_word*)t0)[6],t5,t6);}

/* k7227 in k7206 in k7289 in k7104 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_ccall f_7229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7229,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7232,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7238,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:1040: absolute-pathname? */
t5=C_fast_retrieve(lf[81]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
/* chicken-install.scm:1043: current-directory */
t4=C_fast_retrieve(lf[80]);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5734 in k5731 in k5728 in k5722 in a5715 in a5709 in a5703 in k5694 in g1246 in a5689 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in ... */
static void C_ccall f_5736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5736,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5739,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:687: get-output-string */
t3=C_fast_retrieve(lf[123]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 */
static void C_ccall f_2318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2321,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k5737 in k5734 in k5731 in k5728 in k5722 in a5715 in a5709 in a5703 in k5694 in g1246 in a5689 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in ... */
static void C_ccall f_5739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:685: print-error-message */
t2=C_fast_retrieve(lf[165]);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],*((C_word*)lf[73]+1),t1);}

/* k3255 in k3242 in k3289 in k3213 in k3210 in k3120 in main#check-dependency in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in ... */
static void C_ccall f_3257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:273: error */
t2=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5731 in k5728 in k5722 in a5715 in a5709 in a5703 in k5694 in g1246 in a5689 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in ... */
static void C_ccall f_5733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5736,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:687: ##sys#write-char-0 */
((C_proc4)C_fast_retrieve_symbol_proc(lf[124]))(4,*((C_word*)lf[124]+1),t2,C_make_character(39),((C_word*)t0)[5]);}

/* k5728 in k5722 in a5715 in a5709 in a5703 in k5694 in g1246 in a5689 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in ... */
static void C_ccall f_5730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5730,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5733,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:687: ##sys#print */
t3=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[6],C_SCHEME_FALSE,((C_word*)t0)[5]);}

/* k7230 in k7227 in k7206 in k7289 in k7104 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in ... */
static void C_ccall f_7232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7232,2,t0,t1);}
t2=((C_word*)t0)[2];
f_7225(t2,C_a_i_list2(&a,2,t1,lf[426]));}

/* k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 */
static void C_ccall f_2373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2373,2,t0,t1);}
t2=C_mutate2(&lf[29] /* (set! main#*cross-chicken* ...) */,t1);
t3=C_mutate2(&lf[30] /* (set! main#*host-extension* ...) */,C_retrieve2(lf[29],"main#\052cross-chicken\052"));
t4=C_mutate2(&lf[31] /* (set! main#*target-extension* ...) */,C_retrieve2(lf[29],"main#\052cross-chicken\052"));
t5=lf[32] /* main#*debug-setup* */ =C_SCHEME_FALSE;;
t6=lf[33] /* main#*keep-going* */ =C_SCHEME_FALSE;;
t7=lf[34] /* main#*override* */ =C_SCHEME_END_OF_LIST;;
t8=lf[35] /* main#*reinstall* */ =C_SCHEME_FALSE;;
t9=lf[36] /* main#*show-depends* */ =C_SCHEME_FALSE;;
t10=lf[37] /* main#*show-foreign-depends* */ =C_SCHEME_FALSE;;
t11=lf[38] /* main#*hacks* */ =C_SCHEME_END_OF_LIST;;
t12=C_mutate2(&lf[39] /* (set! main#get-prefix ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2422,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate2(&lf[41] /* (set! main#resolve-location ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2864,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate2(&lf[42] /* (set! main#deps ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2932,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate2(&lf[43] /* (set! main#ext-version ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3005,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate2(&lf[53] /* (set! main#check-dependency ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3083,tmp=(C_word)a,a+=2,tmp));
t17=lf[63] /* main#*eggs+dirs+vers* */ =C_SCHEME_END_OF_LIST;;
t18=lf[64] /* main#*dependencies* */ =C_SCHEME_END_OF_LIST;;
t19=lf[65] /* main#*checked* */ =C_SCHEME_END_OF_LIST;;
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3456,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7416,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7420,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t23=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t23+1)))(4,t23,t22,C_mpointer(&a,(void*)C_CSI_PROGRAM),C_fix(0));}

/* k7236 in k7227 in k7206 in k7289 in k7104 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in ... */
static void C_ccall f_7238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7238,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_7225(t2,C_a_i_list2(&a,2,((C_word*)t0)[3],lf[426]));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7245,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:1042: current-directory */
t3=C_fast_retrieve(lf[80]);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k6527 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f_6529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* chicken-install.scm:916: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6215(t4,((C_word*)t0)[4],t3,((C_word*)((C_word*)t0)[5])[1]);}

/* a3621 in trying-sources in k3603 in main#with-default-sources in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in ... */
static void C_ccall f_3622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3622,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3626,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3631,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm:344: with-output-to-port */
t4=C_fast_retrieve(lf[72]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,*((C_word*)lf[73]+1),t3);}

/* k3624 in a3621 in trying-sources in k3603 in main#with-default-sources in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in ... */
static void C_ccall f_3626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:348: exit */
t2=C_fast_retrieve(lf[68]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(1));}

/* k7206 in k7289 in k7104 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in ... */
static void C_ccall f_7208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7208,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7225,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7229,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:1038: pathname-directory */
t5=C_fast_retrieve(lf[427]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[6]);}

/* k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 */
static void C_ccall f_2346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2346,2,t0,t1);}
t2=C_mutate2(&lf[4] /* (set! main#*program-path* ...) */,t1);
t3=lf[5] /* main#*keep* */ =C_SCHEME_FALSE;;
t4=lf[6] /* main#*keep-existing* */ =C_SCHEME_FALSE;;
t5=lf[7] /* main#*force* */ =C_SCHEME_FALSE;;
t6=lf[8] /* main#*run-tests* */ =C_SCHEME_FALSE;;
t7=lf[9] /* main#*retrieve-only* */ =C_SCHEME_FALSE;;
t8=lf[10] /* main#*no-install* */ =C_SCHEME_FALSE;;
t9=lf[11] /* main#*username* */ =C_SCHEME_FALSE;;
t10=lf[12] /* main#*password* */ =C_SCHEME_FALSE;;
t11=lf[13] /* main#*default-sources* */ =C_SCHEME_END_OF_LIST;;
t12=lf[14] /* main#*default-location* */ =C_SCHEME_FALSE;;
t13=C_mutate2(&lf[15] /* (set! main#*default-transport* ...) */,lf[16]);
t14=C_mutate2(&lf[17] /* (set! main#*windows-shell* ...) */,C_mk_bool(C_WINDOWS_SHELL));
t15=lf[18] /* main#*proxy-host* */ =C_SCHEME_FALSE;;
t16=lf[19] /* main#*proxy-port* */ =C_SCHEME_FALSE;;
t17=lf[20] /* main#*proxy-user-pass* */ =C_SCHEME_FALSE;;
t18=lf[21] /* main#*running-test* */ =C_SCHEME_FALSE;;
t19=lf[22] /* main#*mappings* */ =C_SCHEME_END_OF_LIST;;
t20=lf[23] /* main#*deploy* */ =C_SCHEME_FALSE;;
t21=lf[24] /* main#*trunk* */ =C_SCHEME_FALSE;;
t22=lf[25] /* main#*csc-features* */ =C_SCHEME_END_OF_LIST;;
t23=lf[26] /* main#*csc-nonfeatures* */ =C_SCHEME_END_OF_LIST;;
t24=lf[27] /* main#*prefix* */ =C_SCHEME_FALSE;;
t25=lf[28] /* main#*aliases* */ =C_SCHEME_END_OF_LIST;;
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2373,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:103: feature? */
t27=C_fast_retrieve(lf[144]);
((C_proc3)(void*)(*((C_word*)t27+1)))(3,t27,t26,lf[436]);}

/* k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 */
static void C_ccall f_2343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2346,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_2346(2,t3,t1);}
else{
/* ##sys#peek-c-string */
t3=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}}

/* k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 */
static void C_ccall f_2340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2340,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2343,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
/* chicken-install.scm:77: make-pathname */
t3=C_fast_retrieve(lf[79]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,lf[437]);}
else{
t3=t2;
f_2343(2,t3,C_SCHEME_FALSE);}}

/* trying-sources in k3603 in main#with-default-sources in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in ... */
static void C_fcall f_3610(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(10);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3610,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3622,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm:342: proc */
t4=((C_word*)t0)[2];
((C_proc5)C_fast_retrieve_proc(t4))(5,t4,t1,C_SCHEME_FALSE,C_SCHEME_FALSE,t3);}
else{
t3=C_i_car(t2);
t4=t3;
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3644,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=C_i_assq(lf[77],t4);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3690,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t6)){
t8=C_i_cadr(t6);
/* chicken-install.scm:351: resolve-location */
f_2864(t5,t8);}
else{
/* chicken-install.scm:353: error */
t8=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,lf[78],t4);}}
else{
t5=t2;
t6=C_u_i_cdr(t5);
/* chicken-install.scm:362: trying-sources */
t13=t1;
t14=t6;
t1=t13;
t2=t14;
goto loop;}}}

/* k5788 in for-each-loop1245 in a5689 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in ... */
static void C_ccall f_5790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5780(t3,((C_word*)t0)[4],t2);}

/* k4783 in k4715 in k4711 in k4708 in k4833 in k4688 in k4685 in k4682 in k4679 in k4676 in k4673 in k4667 in k4659 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in ... */
static void C_ccall f_4785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4785,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[122]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4791,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:544: ##sys#print */
t6=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[294],C_SCHEME_FALSE,t3);}

/* main#with-default-sources in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in ... */
static void C_fcall f_3601(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3601,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3605,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t3;
t5=(C_truep(C_retrieve2(lf[14],"main#\052default-location\052"))?C_retrieve2(lf[15],"main#\052default-transport\052"):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2910,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2913,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t8=C_eqp(C_retrieve2(lf[15],"main#\052default-transport\052"),lf[74]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2930,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:193: absolute-pathname? */
t10=C_fast_retrieve(lf[81]);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,C_retrieve2(lf[14],"main#\052default-location\052"));}
else{
t9=t7;
f_2913(t9,C_SCHEME_FALSE);}}
else{
t6=C_retrieve2(lf[13],"main#\052default-sources\052");
t7=t4;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_retrieve2(lf[13],"main#\052default-sources\052"));}}

/* for-each-loop1245 in a5689 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in ... */
static void C_fcall f_5780(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5780,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5790,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-install.scm:680: g1246 */
t5=((C_word*)t0)[3];
f_5692(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3603 in main#with-default-sources in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in ... */
static void C_ccall f_3605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3605,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3610,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3610(t5,((C_word*)t0)[3],t1);}

/* k3293 in k3213 in k3210 in k3120 in main#check-dependency in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in ... */
static void C_ccall f_3295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:269: setup-api#version>=? */
((C_proc4)C_fast_retrieve_symbol_proc(lf[59]))(4,*((C_word*)lf[59]+1),((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k3289 in k3213 in k3210 in k3120 in main#check-dependency in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in ... */
static void C_ccall f_3291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3291,2,t0,t1);}
if(C_truep(t1)){
/* chicken-install.scm:282: values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3244,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=C_u_i_car(t3);
/* chicken-install.scm:270: ->string */
t5=C_fast_retrieve(lf[47]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t2,t4);}}

/* k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in ... */
static void C_ccall f_5477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5480,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5487,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5491,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:709: repository-path */
t5=C_fast_retrieve(lf[226]);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in ... */
static void C_ccall f_5474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5477,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5493,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:706: with-output-to-file */
t4=C_fast_retrieve(lf[228]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[4],t3);}

/* a5770 in a5764 in a5740 in a5703 in k5694 in g1246 in a5689 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in ... */
static void C_ccall f_5771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5771,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in ... */
static void C_ccall f_5471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5471,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5474,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:705: newline */
t4=*((C_word*)lf[223]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6371 in k6368 in k6362 in k6304 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_ccall f_6373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6376,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:862: ##sys#print */
t3=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[345],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k6374 in k6371 in k6368 in k6362 in k6304 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in ... */
static void C_ccall f_6376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6379,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:862: get-output-string */
t3=C_fast_retrieve(lf[123]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k6368 in k6362 in k6304 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in ... */
static void C_ccall f_6370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6373,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_length(((C_word*)t0)[5]);
/* chicken-install.scm:862: ##sys#print */
t4=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in ... */
static void C_ccall f_5468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5468,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5471,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5532,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5556,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm:693: append-map */
t5=C_fast_retrieve(lf[204]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_fast_retrieve(lf[237]));}

/* k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in ... */
static void C_ccall f_5465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5468,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:690: print */
t3=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[238]);}

/* k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_ccall f_5462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5462,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5465,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5685,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5690,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5803,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:680: ##sys#dynamic-wind */
t10=*((C_word*)lf[243]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t6,t7,t8,t9);}

/* k3274 in k3270 in k3242 in k3289 in k3213 in k3210 in k3120 in main#check-dependency in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in ... */
static void C_ccall f_3276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3276,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
/* chicken-install.scm:279: values */
C_values(4,0,((C_word*)t0)[3],C_SCHEME_FALSE,t2);}

/* k6362 in k6304 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_ccall f_6364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6364,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[122]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6370,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:862: ##sys#print */
t6=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[346],C_SCHEME_FALSE,t3);}

/* k3270 in k3242 in k3289 in k3213 in k3210 in k3120 in main#check-dependency in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in ... */
static void C_ccall f_3272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3272,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3276,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=C_i_cadr(((C_word*)t0)[3]);
/* chicken-install.scm:281: ->string */
t5=C_fast_retrieve(lf[47]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k5497 in for-each-loop1364 in a5492 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in ... */
static void C_ccall f_5499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:708: newline */
t2=*((C_word*)lf[223]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k6377 in k6374 in k6371 in k6368 in k6362 in k6304 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in ... */
static void C_ccall f_6379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:861: yes-or-no? */
t2=C_fast_retrieve(lf[113]);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,lf[116],C_SCHEME_FALSE);}

/* a5492 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in ... */
static void C_ccall f_5493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5493,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5507,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_5507(t5,t1,((C_word*)t0)[2]);}

/* k5489 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in ... */
static void C_ccall f_5491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:709: make-pathname */
t2=C_fast_retrieve(lf[79]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_retrieve2(lf[0],"main#constant159"));}

/* k4744 in k4722 in k4718 in k4715 in k4711 in k4708 in k4833 in k4688 in k4685 in k4682 in k4679 in k4676 in k4673 in k4667 in k4659 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in ... */
static void C_ccall f_4746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4746,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[122]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4752,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:551: ##sys#print */
t6=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[286],C_SCHEME_FALSE,t3);}

/* k4738 in k4726 in k4722 in k4718 in k4715 in k4711 in k4708 in k4833 in k4688 in k4685 in k4682 in k4679 in k4676 in k4673 in k4667 in k4659 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in ... */
static void C_ccall f_4740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:555: setup-api#shellpath */
((C_proc3)C_fast_retrieve_symbol_proc(lf[283]))(3,*((C_word*)lf[283]+1),((C_word*)t0)[2],t1);}

/* k6348 in map-loop1558 in k6310 in k6304 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_ccall f_6350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6350,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6321(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6321(t6,((C_word*)t0)[5],t5);}}

/* k5485 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in ... */
static void C_ccall f_5487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:709: setup-api#copy-file */
((C_proc4)C_fast_retrieve_symbol_proc(lf[225]))(4,*((C_word*)lf[225]+1),((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in ... */
static void C_ccall f_5480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:710: setup-api#remove-directory */
((C_proc3)C_fast_retrieve_symbol_proc(lf[195]))(3,*((C_word*)lf[195]+1),((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k4774 in k4771 in k4765 in k4718 in k4715 in k4711 in k4708 in k4833 in k4688 in k4685 in k4682 in k4679 in k4676 in k4673 in k4667 in k4659 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in ... */
static void C_ccall f_4776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4776,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4779,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:548: ##sys#print */
t3=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[288],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k4771 in k4765 in k4718 in k4715 in k4711 in k4708 in k4833 in k4688 in k4685 in k4682 in k4679 in k4676 in k4673 in k4667 in k4659 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in ... */
static void C_ccall f_4773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4776,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:548: ##sys#print */
t3=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,C_retrieve2(lf[25],"main#\052csc-features\052"),C_SCHEME_TRUE,((C_word*)t0)[4]);}

/* k4777 in k4774 in k4771 in k4765 in k4718 in k4715 in k4711 in k4708 in k4833 in k4688 in k4685 in k4682 in k4679 in k4676 in k4673 in k4667 in k4659 in k4921 in a4918 in k4906 in k4903 in setup in ... */
static void C_ccall f_4779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:548: get-output-string */
t2=C_fast_retrieve(lf[123]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2396 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f_2398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2398,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2402,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:116: open-output-string */
t4=C_fast_retrieve(lf[128]);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5436 in main#cleanup in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in ... */
static void C_ccall f_5438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-install.scm:672: setup-api#remove-directory */
((C_proc3)C_fast_retrieve_symbol_proc(lf[195]))(3,*((C_word*)lf[195]+1),((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* main#cleanup in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in ... */
static void C_fcall f_5431(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5431,NULL,1,t1);}
if(C_truep(C_retrieve2(lf[5],"main#\052keep\052"))){
t2=C_SCHEME_UNDEFINED;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5438,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:671: setup-download#temporary-directory */
((C_proc2)C_fast_retrieve_symbol_proc(lf[196]))(2,*((C_word*)lf[196]+1),t2);}}

/* k4765 in k4718 in k4715 in k4711 in k4708 in k4833 in k4688 in k4685 in k4682 in k4679 in k4676 in k4673 in k4667 in k4659 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in ... */
static void C_ccall f_4767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4767,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[122]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4773,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:548: ##sys#print */
t6=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[289],C_SCHEME_FALSE,t3);}

/* k4795 in k4792 in k4789 in k4783 in k4715 in k4711 in k4708 in k4833 in k4688 in k4685 in k4682 in k4679 in k4676 in k4673 in k4667 in k4659 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in ... */
static void C_ccall f_4797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:544: get-output-string */
t2=C_fast_retrieve(lf[123]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3049 in main#ext-version in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in ... */
static void C_ccall f_3051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_member(t1,C_fast_retrieve(lf[51]));
t3=((C_word*)t0)[2];
f_3015(t3,(C_truep(t2)?t2:C_i_member(t1,C_fast_retrieve(lf[52]))));}

/* k4789 in k4783 in k4715 in k4711 in k4708 in k4833 in k4688 in k4685 in k4682 in k4679 in k4676 in k4673 in k4667 in k4659 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in ... */
static void C_ccall f_4791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4791,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4794,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4804,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:545: normalize-pathname */
t4=C_fast_retrieve(lf[292]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[5],lf[293]);}

/* k4792 in k4789 in k4783 in k4715 in k4711 in k4708 in k4833 in k4688 in k4685 in k4682 in k4679 in k4676 in k4673 in k4667 in k4659 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in ... */
static void C_ccall f_4794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4794,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4797,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:544: ##sys#print */
t3=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[291],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* map-loop1558 in k6310 in k6304 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in ... */
static void C_fcall f_6321(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6321,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6350,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-install.scm:866: g1564 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* main#resolve-location in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 */
static void C_fcall f_2864(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2864,NULL,2,t1,t2);}
t3=C_i_assoc(t2,C_retrieve2(lf[28],"main#\052aliases\052"));
if(C_truep(t3)){
t4=t1;
t5=C_i_cdr(t3);
/* chicken-install.scm:186: resolve-location */
t8=t4;
t9=t5;
t1=t8;
t2=t9;
goto loop;}
else{
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k2860 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in ... */
static void C_ccall f_2862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:127: make-pathname */
t2=C_fast_retrieve(lf[79]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_retrieve2(lf[2],"main#constant163"));}

/* k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in ... */
static void C_ccall f_5459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5459,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5462,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm:679: print */
t4=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[244]);}

/* k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_ccall f_5456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5456,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5459,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:678: irregex */
t4=C_fast_retrieve(lf[245]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[246]);}

/* k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f_5453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5453,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5456,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:677: make-pathname */
t4=C_fast_retrieve(lf[79]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,C_retrieve2(lf[0],"main#constant159"));}

/* k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in ... */
static void C_ccall f_5450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5450,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5453,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:676: create-temporary-directory */
t4=C_fast_retrieve(lf[247]);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6310 in k6304 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_ccall f_6312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6312,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_retrieve2(lf[218],"main#info->egg");
t7=C_i_check_list_2(((C_word*)t0)[2],lf[105]);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6319,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6321,a[2]=t5,a[3]=t10,a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_6321(t12,t8,((C_word*)t0)[2]);}
else{
/* chicken-install.scm:867: exit */
t2=C_fast_retrieve(lf[68]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],C_fix(1));}}

/* k4734 in k4726 in k4722 in k4718 in k4715 in k4711 in k4708 in k4833 in k4688 in k4685 in k4682 in k4679 in k4676 in k4673 in k4667 in k4659 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in ... */
static void C_ccall f_4736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:519: conc */
t2=C_fast_retrieve(lf[130]);
((C_proc19)(void*)(*((C_word*)t2+1)))(19,t2,((C_word*)t0)[2],C_retrieve2(lf[66],"main#\052csi\052"),lf[281],((C_word*)t0)[3],lf[282],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[8],((C_word*)t0)[9],((C_word*)t0)[10],((C_word*)t0)[11],((C_word*)t0)[12],((C_word*)t0)[13],((C_word*)t0)[14],C_make_character(32),t1);}

/* a4998 in a4992 in a4968 in k4946 in k4942 in k4936 in k4928 in k4924 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in ... */
static void C_ccall f_4999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4999,2,t0,t1);}
/* chicken-install.scm:642: tmp1139 */
t2=((C_word*)t0)[2];
f_4949(t2,t1);}

/* k4989 in k4986 in k4983 in a4980 in a4974 in a4968 in k4946 in k4942 in k4936 in k4928 in k4924 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in ... */
static void C_ccall f_4991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k2292 in k2289 in k2286 */
static void C_ccall f_2294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2297,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_2d1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2289 in k2286 */
static void C_ccall f_2291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2294,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_chicken_2dsyntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k6317 in k6310 in k6304 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in ... */
static void C_ccall f_6319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_6249(2,t3,t2);}

/* a4992 in a4968 in k4946 in k4942 in k4936 in k4928 in k4924 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in ... */
static void C_ccall f_4993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4993,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4999,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5005,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:642: ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* k4718 in k4715 in k4711 in k4708 in k4833 in k4688 in k4685 in k4682 in k4679 in k4676 in k4673 in k4667 in k4659 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in ... */
static void C_ccall f_4720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4720,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4724,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t2,a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_i_pairp(C_retrieve2(lf[25],"main#\052csc-features\052")))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4767,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:548: open-output-string */
t5=C_fast_retrieve(lf[128]);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_4724(2,t4,lf[290]);}}

/* k2295 in k2292 in k2289 in k2286 */
static void C_ccall f_2297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2300,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k4722 in k4718 in k4715 in k4711 in k4708 in k4833 in k4688 in k4685 in k4682 in k4679 in k4676 in k4673 in k4667 in k4659 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in ... */
static void C_ccall f_4724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4724,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4728,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(C_i_pairp(C_retrieve2(lf[26],"main#\052csc-nonfeatures\052")))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4746,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:551: open-output-string */
t5=C_fast_retrieve(lf[128]);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_4728(2,t4,lf[287]);}}

/* k4726 in k4722 in k4718 in k4715 in k4711 in k4708 in k4833 in k4688 in k4685 in k4682 in k4679 in k4676 in k4673 in k4667 in k4659 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in ... */
static void C_ccall f_4728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4728,2,t0,t1);}
t2=t1;
t3=(C_truep(C_retrieve2(lf[23],"main#\052deploy\052"))?lf[279]:lf[280]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4736,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t2,a[14]=t4,tmp=(C_word)a,a+=15,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4740,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:555: string-append */
t7=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[13],lf[284]);}

/* k4986 in k4983 in a4980 in a4974 in a4968 in k4946 in k4942 in k4936 in k4928 in k4924 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in ... */
static void C_ccall f_4988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4991,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:642: print */
t3=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[258]);}

/* a4980 in a4974 in a4968 in k4946 in k4942 in k4936 in k4928 in k4924 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in ... */
static void C_ccall f_4981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4985,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:642: print */
t3=*((C_word*)lf[69]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[259],lf[260],((C_word*)t0)[3],lf[261]);}

/* k4983 in a4980 in a4974 in a4968 in k4946 in k4942 in k4936 in k4928 in k4924 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in ... */
static void C_ccall f_4985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4985,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4988,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:642: print-error-message */
t3=C_fast_retrieve(lf[165]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k6304 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f_6306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6306,2,t0,t1);}
t2=t1;
t3=C_retrieve2(lf[7],"main#\052force\052");
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6312,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve2(lf[7],"main#\052force\052"))){
t5=t4;
f_6312(2,t5,C_retrieve2(lf[7],"main#\052force\052"));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6364,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:862: open-output-string */
t6=C_fast_retrieve(lf[128]);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k4753 in k4750 in k4744 in k4722 in k4718 in k4715 in k4711 in k4708 in k4833 in k4688 in k4685 in k4682 in k4679 in k4676 in k4673 in k4667 in k4659 in k4921 in a4918 in k4906 in k4903 in setup in ... */
static void C_ccall f_4755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4755,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4758,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:551: ##sys#print */
t3=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[285],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k4750 in k4744 in k4722 in k4718 in k4715 in k4711 in k4708 in k4833 in k4688 in k4685 in k4682 in k4679 in k4676 in k4673 in k4667 in k4659 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in ... */
static void C_ccall f_4752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4752,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4755,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:551: ##sys#print */
t3=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,C_retrieve2(lf[26],"main#\052csc-nonfeatures\052"),C_SCHEME_TRUE,((C_word*)t0)[4]);}

/* k4756 in k4753 in k4750 in k4744 in k4722 in k4718 in k4715 in k4711 in k4708 in k4833 in k4688 in k4685 in k4682 in k4679 in k4676 in k4673 in k4667 in k4659 in k4921 in a4918 in k4906 in k4903 in ... */
static void C_ccall f_4758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:551: get-output-string */
t2=C_fast_retrieve(lf[123]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* a5413 in k5400 in k5397 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in ... */
static void C_ccall f_5414(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5414,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5418,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:665: print* */
t5=*((C_word*)lf[234]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[313],t2);}

/* k2826 in k2856 in k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_ccall f_2828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2828,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2833,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2833(t5,((C_word*)t0)[3],t1);}

/* k5416 in a5413 in k5400 in k5397 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in ... */
static void C_ccall f_5418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:666: delete-file* */
t2=C_fast_retrieve(lf[312]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f_4253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4253,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4258,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4268,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:464: ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[4],t2,t3);}

/* for-each-loop248 in k2826 in k2856 in k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in ... */
static void C_fcall f_2833(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2833,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2843,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-install.scm:132: g249 */
t5=((C_word*)t0)[3];
f_2475(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in ... */
static void C_ccall f_4250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4250,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4253,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_u_i_car(((C_word*)t0)[2]);
/* chicken-install.scm:463: print */
t4=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[140],t3,lf[141]);}

/* a4257 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_ccall f_4258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4258,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[2]);
t3=t1;
t4=t2;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3358,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=f_2932(lf[83],((C_word*)t0)[3]);
t7=f_2932(lf[89],((C_word*)t0)[3]);
if(C_truep(C_retrieve2(lf[8],"main#\052run-tests\052"))){
t8=f_2932(lf[104],((C_word*)t0)[3]);
/* chicken-install.scm:231: append */
t9=*((C_word*)lf[90]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t5,t6,t7,t8);}
else{
/* chicken-install.scm:231: append */
t8=*((C_word*)lf[90]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t5,t6,t7,C_SCHEME_END_OF_LIST);}}

/* k5403 in k5400 in k5397 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in ... */
static void C_ccall f_5405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:667: newline */
t2=*((C_word*)lf[223]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k5400 in k5397 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in ... */
static void C_ccall f_5402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[38],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5402,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5405,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_a_i_list(&a,2,lf[305],lf[147]);
t4=C_a_i_list(&a,5,lf[62],lf[306],lf[307],lf[308],lf[309]);
t5=C_a_i_list(&a,4,lf[310],t3,lf[311],t4);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5414,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm:663: find-files */
t7=C_fast_retrieve(lf[314]);
((C_proc7)(void*)(*((C_word*)t7+1)))(7,t7,t2,lf[315],lf[316],t5,lf[317],t6);}

/* k2841 in for-each-loop248 in k2826 in k2856 in k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_ccall f_2843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2833(t3,((C_word*)t0)[4],t2);}

/* k5251 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in ... */
static void C_ccall f_5253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4885(t2,C_i_not(t1));}

/* a5254 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in ... */
static void C_ccall f_5255(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5255,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=t2;
t4=C_u_i_car(t3);
t5=C_i_car(((C_word*)t0)[2]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_i_equalp(t4,t5));}
else{
t3=t2;
t4=C_i_car(((C_word*)t0)[2]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_i_equalp(t3,t4));}}

/* k4271 in a4267 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in ... */
static void C_ccall f_4273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4273,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_i_car(((C_word*)t0)[3]);
t4=t3;
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4387,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[2],a[7]=t8,a[8]=t6,tmp=(C_word)a,a+=9,tmp);
/* chicken-install.scm:474: append */
t10=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[5]);}

/* k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in ... */
static void C_ccall f_2459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2459,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2461,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2468,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2858,a[2]=t3,a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:130: file-exists? */
t6=C_fast_retrieve(lf[93]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k4942 in k4936 in k4928 in k4924 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in ... */
static void C_ccall f_4944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4944,2,t0,t1);}
if(C_truep(t1)){
t2=lf[21] /* main#*running-test* */ =C_SCHEME_TRUE;;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4948,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:641: current-directory */
t4=C_fast_retrieve(lf[80]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[262]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3242 in k3289 in k3213 in k3210 in k3120 in main#check-dependency in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in ... */
static void C_ccall f_3244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3244,2,t0,t1);}
if(C_truep(C_u_i_string_equal_p(lf[54],t1))){
if(C_truep(C_retrieve2(lf[7],"main#\052force\052"))){
/* chicken-install.scm:272: values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3257,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
/* chicken-install.scm:274: string-append */
t4=*((C_word*)lf[56]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[57],t3,lf[58]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3272,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=C_u_i_car(t3);
/* chicken-install.scm:281: ->string */
t5=C_fast_retrieve(lf[47]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t2,t4);}}

/* k2856 in k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f_2858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2858,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2475,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2828,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:178: read-file */
t4=C_fast_retrieve(lf[352]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_pairp(C_retrieve2(lf[13],"main#\052default-sources\052")));}}

/* tmp1139 in k4946 in k4942 in k4936 in k4928 in k4924 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in ... */
static void C_fcall f_4949(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4949,NULL,2,t0,t1);}
t2=C_i_caddr(((C_word*)t0)[2]);
/* chicken-install.scm:644: command */
f_6131(t1,lf[257],C_a_i_list(&a,3,C_retrieve2(lf[66],"main#\052csi\052"),((C_word*)t0)[3],t2));}

/* k4946 in k4942 in k4936 in k4928 in k4924 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in ... */
static void C_ccall f_4948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4949,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4960,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[33],"main#\052keep-going\052"))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4964,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4969,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:642: call-with-current-continuation */
t6=*((C_word*)lf[184]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
/* chicken-install.scm:642: tmp1139 */
t4=t2;
f_4949(t4,t3);}}

/* k5287 in for-each-loop1080 in k5272 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in ... */
static void C_ccall f_5289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_slot(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_5279(t4,((C_word*)t0)[5],t2,t3);}

/* k4708 in k4833 in k4688 in k4685 in k4682 in k4679 in k4676 in k4673 in k4667 in k4659 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in ... */
static void C_ccall f_4710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4710,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4713,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4807,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:539: open-output-string */
t5=C_fast_retrieve(lf[128]);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_4713(2,t4,lf[298]);}}

/* k4711 in k4708 in k4833 in k4688 in k4685 in k4682 in k4679 in k4676 in k4673 in k4667 in k4659 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in ... */
static void C_ccall f_4713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4713,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4717,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken-install.scm:542: get-prefix */
f_2422(t3,C_a_i_list(&a,1,C_SCHEME_TRUE));}

/* k4715 in k4711 in k4708 in k4833 in k4688 in k4685 in k4682 in k4679 in k4676 in k4673 in k4667 in k4659 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in ... */
static void C_ccall f_4717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4717,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4720,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4785,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:544: open-output-string */
t5=C_fast_retrieve(lf[128]);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_4720(2,t4,lf[295]);}}

/* broken in k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_fcall f_2461(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2461,NULL,3,t0,t1,t2);}
/* chicken-install.scm:129: error */
t3=*((C_word*)lf[55]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,lf[360],((C_word*)t0)[2],t2);}

/* k5218 in k5215 in k5212 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in ... */
static void C_ccall f_5220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:605: exit */
t2=C_fast_retrieve(lf[68]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(1));}

/* k2466 in k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f_2468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_pairp(C_retrieve2(lf[13],"main#\052default-sources\052")));}

/* a4267 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_ccall f_4268(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4268,4,t0,t1,t2,t3);}
t4=t2;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=t3;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4273,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:466: apply-mappings */
f_5816(t7,((C_word*)t5)[1]);}

/* a4974 in a4968 in k4946 in k4942 in k4936 in k4928 in k4924 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in ... */
static void C_ccall f_4975(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4975,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4981,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:642: k1149 */
t4=((C_word*)t0)[3];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t1,t3);}

/* for-each-loop1080 in k5272 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in ... */
static void C_fcall f_5279(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5279,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5289,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
/* chicken-install.scm:590: g1081 */
t9=((C_word*)t0)[3];
f_4881(t9,t6,t7,t8);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k5272 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in ... */
static void C_ccall f_5274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5274,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5279,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5279(t5,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* g249 in k2856 in k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_fcall f_2475(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2475,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2479,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_listp(t2))){
t4=t2;
t5=C_u_i_length(t4);
if(C_truep(C_fixnum_greaterp(t5,C_fix(0)))){
t6=t3;
f_2479(2,t6,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm:135: broken */
t6=((C_word*)t0)[2];
f_2461(t6,t3,t2);}}
else{
/* chicken-install.scm:135: broken */
t4=((C_word*)t0)[2];
f_2461(t4,t3,t2);}}

/* k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in ... */
static void C_ccall f_4217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4217,2,t0,t1);}
if(C_truep(C_retrieve2(lf[9],"main#\052retrieve-only\052"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_retrieve2(lf[63],"main#\052eggs+dirs+vers\052");
t3=C_i_check_list_2(C_retrieve2(lf[63],"main#\052eggs+dirs+vers\052"),lf[86]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4463,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_4463(t7,((C_word*)t0)[2],C_retrieve2(lf[63],"main#\052eggs+dirs+vers\052"));}}

/* k2477 in g249 in k2856 in k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in ... */
static void C_ccall f_2479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2479,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[2]);
t3=C_eqp(t2,lf[46]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
if(C_truep(C_i_pairp(t5))){
t6=C_i_cadr(((C_word*)t0)[2]);
if(C_truep(C_i_nequalp(t6,C_fix(1)))){
t7=C_SCHEME_UNDEFINED;
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2510,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:141: open-output-string */
t8=C_fast_retrieve(lf[128]);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}
else{
/* chicken-install.scm:138: broken */
t6=((C_word*)t0)[4];
f_2461(t6,((C_word*)t0)[3],((C_word*)t0)[2]);}}
else{
t4=C_eqp(t2,lf[363]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2559,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t6=((C_word*)t0)[2];
t7=C_u_i_cdr(t6);
t8=C_a_i_list1(&a,1,t7);
/* chicken-install.scm:150: append */
t9=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t5,C_retrieve2(lf[13],"main#\052default-sources\052"),t8);}
else{
t5=C_eqp(t2,lf[105]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2575,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2577,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t12=((C_word*)t0)[2];
t13=C_u_i_cdr(t12);
t14=C_i_check_list_2(t13,lf[105]);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2619,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2621,a[2]=t10,a[3]=t17,a[4]=t8,a[5]=t11,tmp=(C_word)a,a+=6,tmp));
t19=((C_word*)t17)[1];
f_2621(t19,t15,t13);}
else{
t6=C_eqp(t2,lf[366]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2664,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2666,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t13=((C_word*)t0)[2];
t14=C_u_i_cdr(t13);
t15=C_i_check_list_2(t14,lf[105]);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2709,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2711,a[2]=t11,a[3]=t18,a[4]=t9,a[5]=t12,tmp=(C_word)a,a+=6,tmp));
t20=((C_word*)t18)[1];
f_2711(t20,t16,t14);}
else{
t7=C_eqp(t2,lf[368]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2754,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2757,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t10=((C_word*)t0)[2];
t11=C_u_i_cdr(t10);
if(C_truep(C_i_pairp(t11))){
t12=C_i_cadr(((C_word*)t0)[2]);
t13=t9;
f_2757(t13,C_i_stringp(t12));}
else{
t12=t9;
f_2757(t12,C_SCHEME_FALSE);}}
else{
t8=C_eqp(t2,lf[369]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2787,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2795,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm:176: eval */
t12=C_fast_retrieve(lf[242]);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}
else{
/* chicken-install.scm:177: broken */
t9=((C_word*)t0)[4];
f_2461(t9,((C_word*)t0)[3],((C_word*)t0)[2]);}}}}}}}

/* k4962 in k4946 in k4942 in k4936 in k4928 in k4924 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in ... */
static void C_ccall f_4964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:642: g1153 */
t2=t1;
((C_proc2)C_fast_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k4958 in k4946 in k4942 in k4936 in k4928 in k4924 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in ... */
static void C_ccall f_4960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=lf[21] /* main#*running-test* */ =C_SCHEME_FALSE;;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* a4968 in k4946 in k4942 in k4936 in k4928 in k4924 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in ... */
static void C_ccall f_4969(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4969,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4975,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4993,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:642: with-exception-handler */
t5=C_fast_retrieve(lf[183]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* k2286 */
static void C_ccall f_2288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2291,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2400 in k2396 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_ccall f_2402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2402,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[122]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2408,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:116: ##sys#print */
t6=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[355],C_SCHEME_FALSE,t3);}

/* k4284 in k4278 in k4391 in k4385 in k4271 in a4267 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in ... */
static void C_ccall f_4286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4286,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4289,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:485: unzip1 */
t3=C_fast_retrieve(lf[112]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2406 in k2400 in k2396 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in ... */
static void C_ccall f_2408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2411,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:116: ##sys#print */
t3=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,C_fix((C_word)C_BINARY_VERSION),C_SCHEME_FALSE,((C_word*)t0)[5]);}

/* k4278 in k4391 in k4385 in k4271 in a4267 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in ... */
static void C_ccall f_4280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4280,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4286,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t3=C_retrieve2(lf[7],"main#\052force\052");
if(C_truep(C_retrieve2(lf[7],"main#\052force\052"))){
t4=C_retrieve2(lf[7],"main#\052force\052");
t5=t2;
f_4286(2,t5,C_retrieve2(lf[7],"main#\052force\052"));}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4349,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3747,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=C_i_car(((C_word*)t0)[4]);
t8=C_a_i_list3(&a,3,lf[119],t7,lf[120]);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3755,a[2]=t6,a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3757,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm:380: filter-map */
t12=C_fast_retrieve(lf[136]);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t11,((C_word*)t0)[3]);}}
else{
t3=t2;
f_4286(2,t3,C_SCHEME_FALSE);}}

/* a4912 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in ... */
static void C_ccall f_4913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4913,2,t0,t1);}
/* chicken-install.scm:624: change-directory */
t2=C_fast_retrieve(lf[256]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k4287 in k4284 in k4278 in k4391 in k4385 in k4271 in a4267 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in ... */
static void C_ccall f_4289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4289,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4292,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4336,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:486: string-intersperse */
t5=C_fast_retrieve(lf[110]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[111]);}

/* a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in ... */
static void C_ccall f_4919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4923,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[29],"main#\052cross-chicken\052"))){
t3=t2;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5399,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:661: print* */
t5=*((C_word*)lf[234]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[319]);}
else{
t3=t2;
f_4923(2,t3,C_SCHEME_UNDEFINED);}}

/* k5611 in k5595 in a5576 in k5564 in k5561 in a5555 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in ... */
static void C_ccall f_5613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:699: append */
t2=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k5212 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in ... */
static void C_fcall f_5214(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5214,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5217,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:603: print */
t3=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[330]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_4888(2,t3,t2);}}

/* k5215 in k5212 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in ... */
static void C_ccall f_5217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5220,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:604: cleanup */
f_5431(t2);}

/* k2409 in k2406 in k2400 in k2396 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_ccall f_2411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2414,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:116: get-output-string */
t3=C_fast_retrieve(lf[123]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k2412 in k2409 in k2406 in k2400 in k2396 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in ... */
static void C_ccall f_2414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:116: make-pathname */
t2=C_fast_retrieve(lf[79]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k5228 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in ... */
static void C_ccall f_5230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5214(t2,C_i_not(t1));}

/* k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in ... */
static void C_ccall f_4235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4235,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4241,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:459: file-exists? */
t4=C_fast_retrieve(lf[93]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in ... */
static void C_fcall f_4901(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4901,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4905,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm:620: print */
t4=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[321],t2);}

/* k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in ... */
static void C_ccall f_4900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4901,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5120,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(C_retrieve2(lf[31],"main#\052target-extension\052"))?C_retrieve2(lf[30],"main#\052host-extension\052"):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5156,a[2]=t10,a[3]=t12,a[4]=t6,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5163,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5169,a[2]=t6,a[3]=t8,a[4]=t10,a[5]=t12,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:649: ##sys#dynamic-wind */
t16=*((C_word*)lf[243]+1);
((C_proc5)(void*)(*((C_word*)t16+1)))(5,t16,t3,t13,t14,t15);}
else{
/* chicken-install.scm:652: setup */
t5=t2;
f_4901(t5,t3,((C_word*)t0)[7]);}}

/* k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in ... */
static void C_ccall f_4905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4905,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4908,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm:621: current-directory */
t3=C_fast_retrieve(lf[80]);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in ... */
static void C_ccall f_4908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4908,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4913,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4919,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5113,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:622: dynamic-wind */
t6=C_fast_retrieve(lf[320]);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,((C_word*)t0)[6],t3,t4,t5);}

/* k4928 in k4924 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in ... */
static void C_ccall f_4930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4931,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4938,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[33],"main#\052keep-going\052"))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5042,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5047,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:632: call-with-current-continuation */
t6=*((C_word*)lf[184]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
/* chicken-install.scm:632: tmp1112 */
t4=t2;
f_4931(t4,t3);}}

/* tmp1112 in k4928 in k4924 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in ... */
static void C_fcall f_4931(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4931,NULL,2,t0,t1);}
/* chicken-install.scm:634: $system */
f_6020(t1,((C_word*)t0)[2]);}

/* k4936 in k4928 in k4924 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in ... */
static void C_ccall f_4938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4944,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve2(lf[8],"main#\052run-tests\052"))){
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_4944(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5030,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:637: file-exists? */
t4=C_fast_retrieve(lf[93]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[266]);}}
else{
t3=t2;
f_4944(2,t3,C_SCHEME_FALSE);}}

/* k6590 in k6586 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_ccall f_6592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_mutate2(&lf[15] /* (set! main#*default-transport* ...) */,t1);
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
t5=C_u_i_cdr(t4);
/* chicken-install.scm:927: loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_6215(t6,((C_word*)t0)[4],t5,((C_word*)((C_word*)t0)[5])[1]);}

/* k5232 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in ... */
static void C_ccall f_5234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5234,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5238,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:602: setup-api#abort-setup */
((C_proc2)C_fast_retrieve_symbol_proc(lf[117]))(2,*((C_word*)lf[117]+1),t3);}

/* k5236 in k5232 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in ... */
static void C_ccall f_5238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:598: yes-or-no? */
t2=C_fast_retrieve(lf[113]);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[116],t1);}

/* k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in ... */
static void C_ccall f_4923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4923,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4926,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)t0)[2]);
t4=C_i_caddr(((C_word*)t0)[2]);
t5=C_i_greaterp(((C_word*)t0)[5],C_fix(1));
t6=t2;
t7=t3;
t8=t4;
t9=t5;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4661,a[2]=t9,a[3]=t6,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t11=C_retrieve2(lf[23],"main#\052deploy\052");
if(C_truep(C_retrieve2(lf[23],"main#\052deploy\052"))){
t12=C_retrieve2(lf[23],"main#\052deploy\052");
t13=t10;
f_4661(t13,(C_truep(C_retrieve2(lf[23],"main#\052deploy\052"))?lf[303]:lf[304]));}
else{
if(C_truep(C_retrieve2(lf[29],"main#\052cross-chicken\052"))){
t12=C_retrieve2(lf[30],"main#\052host-extension\052");
t13=t10;
f_4661(t13,(C_truep(C_retrieve2(lf[30],"main#\052host-extension\052"))?lf[304]:lf[303]));}
else{
t12=t10;
f_4661(t12,lf[304]);}}}

/* k4924 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in ... */
static void C_ccall f_4926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4926,2,t0,t1);}
t2=t1;
t3=((C_word*)t0)[2];
t4=C_u_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4930,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm:631: print */
t6=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,lf[268],t2);}

/* k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in ... */
static void C_ccall f_4247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4250,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_u_i_car(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4512,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[29],"main#\052cross-chicken\052"))){
t6=C_SCHEME_UNDEFINED;
t7=t2;
f_4250(2,t7,t6);}
else{
t6=C_i_assq(lf[143],((C_word*)t0)[3]);
t7=t6;
if(C_truep(t7)){
t8=C_i_cadr(t7);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4534,a[2]=t5,a[3]=t10,a[4]=t7,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_4534(3,t12,t2,t8);}
else{
t8=t2;
f_4250(2,t8,C_SCHEME_FALSE);}}}

/* k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in ... */
static void C_ccall f_4241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4241,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4244,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:460: with-input-from-file */
t3=C_fast_retrieve(lf[91]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],*((C_word*)lf[92]+1));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4441,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=C_u_i_car(((C_word*)t0)[2]);
/* chicken-install.scm:495: string-append */
t4=*((C_word*)lf[56]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[153],t3,lf[154],lf[155]);}}

/* k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in ... */
static void C_ccall f_4244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4244,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4247,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=C_u_i_car(((C_word*)t0)[2]);
/* chicken-install.scm:461: print */
t5=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,lf[151],t4,lf[152]);}

/* a5010 in a5004 in a4992 in a4968 in k4946 in k4942 in k4936 in k4928 in k4924 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in ... */
static void C_ccall f_5011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5011,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a5004 in a4992 in a4968 in k4946 in k4942 in k4936 in k4928 in k4924 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in ... */
static void C_ccall f_5005(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_5005r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5005r(t0,t1,t2);}}

static void C_ccall f_5005r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5011,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:642: k1149 */
t4=((C_word*)t0)[2];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t1,t3);}

/* k5893 in a5890 in main#apply-mappings in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in ... */
static void C_ccall f_5895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5895,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=t1;
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_fast_retrieve(lf[47]);
t9=C_i_cdr(t3);
t10=C_i_check_list_2(t9,lf[105]);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5911,a[2]=t7,a[3]=t12,a[4]=t5,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_5911(t14,t2,t9);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list1(&a,1,((C_word*)t0)[3]));}}

/* a5890 in main#apply-mappings in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in ... */
static void C_ccall f_5891(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5891,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5895,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5952,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:724: find */
t5=C_fast_retrieve(lf[203]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_retrieve2(lf[22],"main#\052mappings\052"));}

/* k5880 in k5874 in main#apply-mappings in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in ... */
static void C_ccall f_5882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
/* chicken-install.scm:731: print */
t2=*((C_word*)lf[69]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[199],((C_word*)t0)[5],lf[200],((C_word*)t0)[3]);}}

/* k5887 in main#apply-mappings in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in ... */
static void C_ccall f_5889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:721: delete-duplicates */
t2=C_fast_retrieve(lf[202]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)((C_word*)t0)[3])[1]);}

/* k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 */
static void C_ccall f_2321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2324,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_chicken_2dsyntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 */
static void C_ccall f_2324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2327,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_chicken_2dffi_2dsyntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 */
static void C_ccall f_2327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2330,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:27: ##sys#require */
((C_proc3)C_fast_retrieve_symbol_proc(lf[439]))(3,*((C_word*)lf[439]+1),t2,lf[441]);}

/* k4205 in a4175 in k4163 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in ... */
static void C_ccall f_4207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_i_nullp(t1))){
/* chicken-install.scm:449: error */
t2=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[188]);}
else{
t2=((C_word*)t0)[2];
f_4180(2,t2,C_SCHEME_UNDEFINED);}}

/* k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 */
static void C_ccall f_2330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2330,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2333,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:27: ##sys#require */
((C_proc3)C_fast_retrieve_symbol_proc(lf[439]))(3,*((C_word*)lf[439]+1),t2,lf[440]);}

/* k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 */
static void C_ccall f_2333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2333,2,t0,t1);}
t2=C_mutate2(&lf[0] /* (set! main#constant159 ...) */,lf[1]);
t3=C_mutate2(&lf[2] /* (set! main#constant163 ...) */,lf[3]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2340,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:76: get-environment-variable */
t5=C_fast_retrieve(lf[214]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[438]);}

/* k3906 in k3903 in k3900 in k3897 in k3894 in k3888 in k3881 in g643 in k3864 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in ... */
static void C_ccall f_3908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3908,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3911,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm:405: ##sys#print */
t4=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* same? in main#apply-mappings in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in ... */
static void C_ccall f_5853(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5853,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5873,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:719: canonical */
f_5819(t4,t2);}

/* k3903 in k3900 in k3897 in k3894 in k3888 in k3881 in g643 in k3864 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_ccall f_3905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3905,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3908,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:405: ##sys#print */
t3=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[190],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k3900 in k3897 in k3894 in k3888 in k3881 in g643 in k3864 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f_3902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3902,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3905,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:405: ##sys#print */
t3=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[6],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k4096 in for-each-loop692 in k3981 in k3978 in k3969 in k3966 in main#show-depends in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in ... */
static void C_ccall f_4098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4088(t3,((C_word*)t0)[4],t2);}

/* k2301 in k2298 in k2295 in k2292 in k2289 in k2286 */
static void C_ccall f_2303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2306,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2298 in k2295 in k2292 in k2289 in k2286 */
static void C_ccall f_2300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2303,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_2dstructures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 */
static void C_ccall f_2306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2309,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_irregex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* a5076 in a5070 in a5046 in k4928 in k4924 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in ... */
static void C_ccall f_5077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5077,2,t0,t1);}
/* chicken-install.scm:632: tmp1112 */
t2=((C_word*)t0)[2];
f_4931(t2,t1);}

/* k4078 in k3981 in k3978 in k3969 in k3966 in main#show-depends in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in ... */
static void C_ccall f_4080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4080,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4083,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:432: cleanup */
f_5431(t2);}

/* k4081 in k4078 in k3981 in k3978 in k3969 in k3966 in main#show-depends in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in ... */
static void C_ccall f_4083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:433: exit */
t2=C_fast_retrieve(lf[68]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* a5070 in a5046 in k4928 in k4924 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in ... */
static void C_ccall f_5071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5071,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5077,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5083,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:632: ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* for-each-loop692 in k3981 in k3978 in k3969 in k3966 in main#show-depends in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in ... */
static void C_fcall f_4088(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4088,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4098,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-install.scm:421: g693 */
t5=((C_word*)t0)[3];
f_3984(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 */
static void C_ccall f_2312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2315,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 */
static void C_ccall f_2315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2318,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_2d13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 */
static void C_ccall f_2309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2312,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k5064 in k5061 in a5058 in a5052 in a5046 in k4928 in k4924 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in ... */
static void C_ccall f_5066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5066,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5069,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:632: print */
t3=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[258]);}

/* k5067 in k5064 in k5061 in a5058 in a5052 in a5046 in k4928 in k4924 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in ... */
static void C_ccall f_5069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k5877 in k5874 in main#apply-mappings in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in ... */
static void C_ccall f_5879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* k5871 in same? in main#apply-mappings in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in ... */
static void C_ccall f_5873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5873,2,t0,t1);}
t2=C_i_car(t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5869,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:719: canonical */
f_5819(t4,((C_word*)t0)[4]);}

/* k5874 in main#apply-mappings in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in ... */
static void C_ccall f_5876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5876,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5879,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5882,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:730: lset= */
t5=C_fast_retrieve(lf[201]);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3],t2);}

/* k5061 in a5058 in a5052 in a5046 in k4928 in k4924 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in ... */
static void C_ccall f_5063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5063,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5066,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:632: print-error-message */
t3=C_fast_retrieve(lf[165]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k5867 in k5871 in same? in main#apply-mappings in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in ... */
static void C_ccall f_5869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_car(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_equalp(((C_word*)t0)[3],t2));}

/* k3912 in k3909 in k3906 in k3903 in k3900 in k3897 in k3894 in k3888 in k3881 in g643 in k3864 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in ... */
static void C_ccall f_3914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3914,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3917,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:405: get-output-string */
t3=C_fast_retrieve(lf[123]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k3915 in k3912 in k3909 in k3906 in k3903 in k3900 in k3897 in k3894 in k3888 in k3881 in g643 in k3864 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in ... */
static void C_ccall f_3917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:404: warning */
t2=C_fast_retrieve(lf[60]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3909 in k3906 in k3903 in k3900 in k3897 in k3894 in k3888 in k3881 in g643 in k3864 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_ccall f_3911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3911,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3914,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:405: ##sys#write-char-0 */
((C_proc4)C_fast_retrieve_symbol_proc(lf[124]))(4,*((C_word*)lf[124]+1),t2,C_make_character(39),((C_word*)t0)[4]);}

/* main#apply-mappings in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in ... */
static void C_fcall f_5816(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5816,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5819,tmp=(C_word)a,a+=2,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5853,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5876,a[2]=t1,a[3]=t2,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5889,a[2]=t9,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5891,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:722: append-map */
t12=C_fast_retrieve(lf[204]);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t11,t2);}

/* k5812 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in ... */
static void C_ccall f_5814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:675: make-pathname */
t2=C_fast_retrieve(lf[79]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[249]);}

/* canonical in main#apply-mappings in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in ... */
static void C_fcall f_5819(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5819,NULL,2,t1,t2);}
if(C_truep(C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5833,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:714: symbol->string */
t4=*((C_word*)lf[197]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
if(C_truep(C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,t2,C_SCHEME_FALSE));}
else{
if(C_truep(C_i_pairp(t2))){
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* chicken-install.scm:717: error */
t3=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[198],t2);}}}}

/* k5808 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in ... */
static void C_ccall f_5810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:675: glob */
t2=C_fast_retrieve(lf[248]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6090 in k6097 in a6052 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in ... */
static void C_ccall f_6092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:758: warning */
t2=C_fast_retrieve(lf[60]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[350],t1);}

/* k6097 in a6052 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_ccall f_6099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6099,2,t0,t1);}
t2=C_i_car(t1);
t3=C_i_assq(lf[46],t2);
t4=(C_truep(t3)?C_i_cadr(t3):lf[348]);
t5=t4;
t6=C_i_assq(lf[349],t2);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6070,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:751: g1486 */
t8=t7;
f_6070(t8,((C_word*)t0)[2],t6);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6088,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6092,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:760: pathname-file */
t9=C_fast_retrieve(lf[351]);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,((C_word*)t0)[3]);}}

/* k5034 in k5028 in k4936 in k4928 in k4924 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in ... */
static void C_ccall f_5036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-install.scm:639: file-exists? */
t2=C_fast_retrieve(lf[93]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[263]);}
else{
t2=((C_word*)t0)[2];
f_4944(2,t2,C_SCHEME_FALSE);}}

/* k5028 in k4936 in k4928 in k4924 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in ... */
static void C_ccall f_5030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5030,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5036,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:638: directory? */
t3=C_fast_retrieve(lf[264]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[265]);}
else{
t2=((C_word*)t0)[2];
f_4944(2,t2,C_SCHEME_FALSE);}}

/* a5802 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in ... */
static void C_ccall f_5803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5803,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_fast_retrieve(lf[239]));
t3=C_mutate2((C_word*)lf[239]+1 /* (set! ##sys#warnings-enabled ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k6080 in g1486 in k6097 in a6052 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_ccall f_6082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6082,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k6390 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f_6392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6392,2,t0,t1);}
if(C_truep(C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6402,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6419,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6421,a[2]=t6,a[3]=t9,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_6421(t11,t7,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6457,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:879: print */
t3=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[358]);}}

/* k6086 in k6097 in a6052 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in ... */
static void C_ccall f_6088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k5831 in canonical in main#apply-mappings in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in ... */
static void C_ccall f_5833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5833,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,t1,C_SCHEME_FALSE));}

/* g1246 in a5689 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in ... */
static void C_fcall f_5692(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5692,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5696,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:683: irregex-match */
t4=C_fast_retrieve(lf[216]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],t2);}

/* k5694 in g1246 in a5689 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in ... */
static void C_ccall f_5696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5696,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5699,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5704,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:682: call-with-current-continuation */
t5=*((C_word*)lf[184]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k5697 in k5694 in g1246 in a5689 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in ... */
static void C_ccall f_5699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:682: g1261 */
t2=t1;
((C_proc2)C_fast_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a5058 in a5052 in a5046 in k4928 in k4924 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in ... */
static void C_ccall f_5059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5059,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5063,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:632: print */
t3=*((C_word*)lf[69]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[267],lf[260],((C_word*)t0)[3],lf[261]);}

/* a5052 in a5046 in k4928 in k4924 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in ... */
static void C_ccall f_5053(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5053,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5059,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:632: k1122 */
t4=((C_word*)t0)[3];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t1,t3);}

/* a5684 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in ... */
static void C_ccall f_5685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5685,2,t0,t1);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_fast_retrieve(lf[239]));
t3=C_mutate2((C_word*)lf[239]+1 /* (set! ##sys#warnings-enabled ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a5046 in k4928 in k4924 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in ... */
static void C_ccall f_5047(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5047,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5053,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5071,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:632: with-exception-handler */
t5=C_fast_retrieve(lf[183]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* k5040 in k4928 in k4924 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in ... */
static void C_ccall f_5042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:632: g1126 */
t2=t1;
((C_proc2)C_fast_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k3978 in k3969 in k3966 in main#show-depends in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in ... */
static void C_ccall f_3980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3983,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:417: ##sys#print */
t3=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[97],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k3986 in g693 in k3981 in k3978 in k3969 in k3966 in main#show-depends in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in ... */
static void C_ccall f_3988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3988,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4065,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:424: file-exists? */
t5=C_fast_retrieve(lf[93]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3981 in k3978 in k3969 in k3966 in main#show-depends in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in ... */
static void C_ccall f_3983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3984,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve2(lf[63],"main#\052eggs+dirs+vers\052");
t4=C_i_check_list_2(C_retrieve2(lf[63],"main#\052eggs+dirs+vers\052"),lf[86]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4080,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4088,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_4088(t9,t5,C_retrieve2(lf[63],"main#\052eggs+dirs+vers\052"));}

/* g693 in k3981 in k3978 in k3969 in k3966 in main#show-depends in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in ... */
static void C_fcall f_3984(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3984,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3988,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=C_i_cadr(t2);
t5=t2;
t6=C_u_i_car(t5);
/* chicken-install.scm:423: make-pathname */
t7=C_fast_retrieve(lf[79]);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t3,t4,t6,lf[94]);}

/* a6052 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f_6053(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6053,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6099,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:752: read-file */
t4=C_fast_retrieve(lf[352]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* main#get-prefix in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 */
static void C_fcall f_2422(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2422,NULL,2,t1,t2);}
t3=C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:C_i_car(t2));
t5=(C_truep(C_retrieve2(lf[29],"main#\052cross-chicken\052"))?C_i_not(C_retrieve2(lf[30],"main#\052host-extension\052")):C_SCHEME_FALSE);
if(C_truep(t5)){
if(C_truep(t4)){
/* ##sys#peek-c-string */
t6=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,C_mpointer(&a,(void*)C_TARGET_PREFIX),C_fix(0));}
else{
t6=C_retrieve2(lf[27],"main#\052prefix\052");
if(C_truep(C_retrieve2(lf[27],"main#\052prefix\052"))){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_retrieve2(lf[27],"main#\052prefix\052"));}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,C_mpointer(&a,(void*)C_TARGET_PREFIX),C_fix(0));}}}
else{
t6=C_retrieve2(lf[27],"main#\052prefix\052");
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_retrieve2(lf[27],"main#\052prefix\052"));}}

/* k6049 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f_6051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:749: delete-duplicates */
t2=C_fast_retrieve(lf[202]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[347]+1));}

/* k3969 in k3966 in main#show-depends in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in ... */
static void C_ccall f_3971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3971,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_i_nullp(t2);
t4=(C_truep(t3)?lf[83]:C_i_car(t2));
t5=t4;
t6=*((C_word*)lf[84]+1);
t7=*((C_word*)lf[84]+1);
t8=C_i_check_port_2(*((C_word*)lf[84]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[85]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3980,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t10=C_eqp(t5,lf[83]);
if(C_truep(t10)){
/* chicken-install.scm:417: ##sys#print */
t11=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t9,lf[98],C_SCHEME_FALSE,*((C_word*)lf[84]+1));}
else{
t11=C_eqp(t5,lf[99]);
if(C_truep(t11)){
/* chicken-install.scm:417: ##sys#print */
t12=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t12+1)))(5,t12,t9,lf[100],C_SCHEME_FALSE,t6);}
else{
t12=C_SCHEME_UNDEFINED;
/* chicken-install.scm:417: ##sys#print */
t13=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t13+1)))(5,t13,t9,t12,C_SCHEME_FALSE,t6);}}}

/* k6036 in main#$system in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in ... */
static void C_ccall f_6038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:741: system */
t2=C_fast_retrieve(lf[207]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3989 in k3986 in g693 in k3981 in k3978 in k3969 in k3966 in main#show-depends in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in ... */
static void C_ccall f_3991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3991,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3997,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_eqp(((C_word*)t0)[4],lf[83]);
if(C_truep(t3)){
t4=f_2932(lf[89],t1);
t5=f_2932(((C_word*)t0)[4],t1);
/* chicken-install.scm:426: append */
t6=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t2,t4,t5);}
else{
/* chicken-install.scm:427: deps */
t4=t2;
f_3997(2,t4,f_2932(((C_word*)t0)[4],t1));}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3995 in k3989 in k3986 in g693 in k3981 in k3978 in k3969 in k3966 in main#show-depends in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in ... */
static void C_ccall f_3997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3997,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
if(C_truep(C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4009,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_car(t4);
/* chicken-install.scm:429: print */
t6=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t5,lf[88]);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k6022 in main#$system in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in ... */
static void C_ccall f_6024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* chicken-install.scm:746: error */
t3=*((C_word*)lf[55]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[206],t1,((C_word*)t0)[3]);}}

/* main#$system in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in ... */
static void C_fcall f_6020(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6020,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6024,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6038,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"main#\052windows-shell\052"))){
/* chicken-install.scm:743: string-append */
t5=*((C_word*)lf[56]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,lf[208],t2,lf[209]);}
else{
t5=t2;
/* chicken-install.scm:741: system */
t6=C_fast_retrieve(lf[207]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t3,t5);}}

/* a5689 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in ... */
static void C_ccall f_5690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5692,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5780,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_5780(t6,t1,((C_word*)t0)[3]);}

/* k3460 in a3720 in a3705 in a4169 in k4163 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in ... */
static void C_ccall f_3462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:311: g546 */
t2=t1;
((C_proc2)C_fast_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a3466 in a3720 in a3705 in a4169 in k4163 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in ... */
static void C_ccall f_3467(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3467,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3473,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3560,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm:311: with-exception-handler */
t5=C_fast_retrieve(lf[183]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* k4290 in k4287 in k4284 in k4278 in k4391 in k4385 in k4271 in a4267 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in ... */
static void C_ccall f_4292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4292,2,t0,t1);}
t2=C_i_check_list_2(((C_word*)t0)[2],lf[86]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4306,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4311,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_4311(t7,t3,((C_word*)t0)[2]);}

/* k4295 in for-each-loop849 in k4290 in k4287 in k4284 in k4278 in k4391 in k4385 in k4271 in a4267 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in ... */
static void C_ccall f_4297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:490: setup-api#remove-extension */
((C_proc3)C_fast_retrieve_symbol_proc(lf[106]))(3,*((C_word*)lf[106]+1),((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k6005 in for-each-loop1451 in k5987 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_ccall f_6007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5997(t3,((C_word*)t0)[4],t2);}

/* k3966 in main#show-depends in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in ... */
static void C_ccall f_3968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3971,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:416: retrieve */
f_4134(t2,((C_word*)t0)[4]);}

/* main#show-depends in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in ... */
static void C_fcall f_3964(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3964,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3968,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:415: print */
t5=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[102]);}

/* a7181 in k7113 in k7104 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in ... */
static void C_ccall f_7182(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7182,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_memq(t2,lf[422]));}

/* map-loop1334 in k5595 in a5576 in k5564 in k5561 in a5555 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in ... */
static void C_fcall f_5615(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(12);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5615,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=f_5599(C_a_i(&a,9),((C_word*)t0)[2],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate2(((C_word *)((C_word*)t0)[5])+1,t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[5])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7188 in k7104 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_ccall f_7190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_fast_retrieve(lf[423]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* a3478 in a3472 in a3466 in a3720 in a3705 in a4169 in k4163 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f_3479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3479,2,t0,t1);}
t2=C_i_structurep(((C_word*)t0)[2],lf[159]);
t3=(C_truep(t2)?C_slot(((C_word*)t0)[2],C_fix(1)):C_SCHEME_FALSE);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3489,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=C_i_memv(lf[168],t4);
t7=t5;
f_3489(t7,(C_truep(t6)?C_i_memv(lf[171],t4):C_SCHEME_FALSE));}
else{
t6=t5;
f_3489(t6,C_SCHEME_FALSE);}}

/* a3472 in a3466 in a3720 in a3705 in a4169 in k4163 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in ... */
static void C_ccall f_3473(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3473,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3479,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:311: k542 */
t4=((C_word*)t0)[2];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t1,t3);}

/* map-loop1307 in a5576 in k5564 in k5561 in a5555 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in ... */
static void C_fcall f_5650(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(12);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5650,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=f_5583(C_a_i(&a,9),((C_word*)t0)[2],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate2(((C_word *)((C_word*)t0)[5])+1,t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[5])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in ... */
static void C_ccall f_4891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4894,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[31],"main#\052target-extension\052"))){
if(C_truep(C_retrieve2(lf[30],"main#\052host-extension\052"))){
/* chicken-install.scm:609: create-temporary-directory */
t3=C_fast_retrieve(lf[247]);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=t2;
f_4894(2,t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_4894(2,t3,C_SCHEME_FALSE);}}

/* k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in ... */
static void C_ccall f_4894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4894,2,t0,t1);}
t2=t1;
t3=C_i_cadr(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4900,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5180,a[2]=t5,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:612: print */
t7=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[327]);}
else{
t6=t5;
f_4900(2,t6,C_SCHEME_UNDEFINED);}}

/* k3114 in main#check-dependency in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in ... */
static void C_ccall f_3116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-install.scm:238: values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
/* chicken-install.scm:242: ->string */
t2=C_fast_retrieve(lf[47]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[4]);}}

/* k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in ... */
static void C_ccall f_4888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4888,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4891,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[2]);
t4=C_i_caddr(((C_word*)t0)[2]);
/* chicken-install.scm:606: print */
t5=*((C_word*)lf[69]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t2,lf[328],t3,C_make_character(58),t4,lf[329]);}

/* k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 */
static void C_ccall f_3456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3456,2,t0,t1);}
t2=C_mutate2(&lf[66] /* (set! main#*csi* ...) */,t1);
t3=C_mutate2(&lf[67] /* (set! main#with-default-sources ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3601,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate2(&lf[82] /* (set! main#show-depends ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3964,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate2(&lf[101] /* (set! main#retrieve ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4134,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate2(&lf[95] /* (set! main#cleanup ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5431,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate2(&lf[139] /* (set! main#apply-mappings ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5816,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate2(&lf[205] /* (set! main#$system ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6020,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate2(&lf[210] /* (set! main#command ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6131,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate2(&lf[212] /* (set! main#setup-proxy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6152,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate2(&lf[218] /* (set! main#info->egg ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6188,tmp=(C_word)a,a+=2,tmp));
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7338,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:1057: register-feature! */
t13=C_fast_retrieve(lf[434]);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,lf[435]);}

/* k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in ... */
static void C_ccall f_4880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4881,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5274,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:658: iota */
t5=C_fast_retrieve(lf[334]);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[6],((C_word*)t0)[6],C_fix(-1));}

/* g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in ... */
static void C_fcall f_4881(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4881,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4885,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[3])[1]))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5253,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5255,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:593: find */
t7=C_fast_retrieve(lf[203]);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)((C_word*)t0)[3])[1]);}
else{
t5=t4;
f_4885(t5,C_SCHEME_FALSE);}}

/* map-loop1724 in k7119 in k7113 in k7104 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_fcall f_7144(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7144,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_string(&a,2,C_make_character(45),t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in ... */
static void C_fcall f_4885(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4885,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4888,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[5])?C_SCHEME_FALSE:t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5214,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[10],"main#\052no-install\052"))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5230,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5234,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* ##sys#string-append */
((C_proc4)C_fast_retrieve_symbol_proc(lf[331]))(4,*((C_word*)lf[331]+1),t7,lf[332],lf[333]);}
else{
t6=t5;
f_5214(t6,C_SCHEME_FALSE);}}
else{
t5=t3;
f_4888(2,t5,C_SCHEME_UNDEFINED);}}

/* k7138 in k7119 in k7113 in k7104 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_ccall f_7140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* chicken-install.scm:1026: append */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],t1,t3);}

/* k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in ... */
static void C_fcall f_6475(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6475,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f7920,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:785: print */
t4=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[372]);}
else{
if(C_truep(C_u_i_string_equal_p(((C_word*)t0)[3],lf[373]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6486,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6493,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:906: repository-path */
t4=C_fast_retrieve(lf[226]);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep(C_u_i_string_equal_p(((C_word*)t0)[3],lf[374]))){
t2=lf[7] /* main#*force* */ =C_SCHEME_TRUE;;
t3=((C_word*)t0)[4];
t4=C_u_i_cdr(t3);
/* chicken-install.scm:910: loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_6215(t5,((C_word*)t0)[2],t4,((C_word*)((C_word*)t0)[6])[1]);}
else{
t2=C_u_i_string_equal_p(((C_word*)t0)[3],lf[375]);
t3=(C_truep(t2)?t2:C_u_i_string_equal_p(((C_word*)t0)[3],lf[376]));
if(C_truep(t3)){
t4=lf[5] /* main#*keep* */ =C_SCHEME_TRUE;;
t5=((C_word*)t0)[4];
t6=C_u_i_cdr(t5);
/* chicken-install.scm:913: loop */
t7=((C_word*)((C_word*)t0)[5])[1];
f_6215(t7,((C_word*)t0)[2],t6,((C_word*)((C_word*)t0)[6])[1]);}
else{
t4=C_u_i_string_equal_p(((C_word*)t0)[3],lf[377]);
t5=(C_truep(t4)?t4:C_u_i_string_equal_p(((C_word*)t0)[3],lf[378]));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6529,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:915: setup-api#sudo-install */
((C_proc3)C_fast_retrieve_symbol_proc(lf[299]))(3,*((C_word*)lf[299]+1),t6,C_SCHEME_TRUE);}
else{
t6=C_u_i_string_equal_p(((C_word*)t0)[3],lf[379]);
t7=(C_truep(t6)?t6:C_u_i_string_equal_p(((C_word*)t0)[3],lf[380]));
if(C_truep(t7)){
t8=lf[9] /* main#*retrieve-only* */ =C_SCHEME_TRUE;;
t9=((C_word*)t0)[4];
t10=C_u_i_cdr(t9);
/* chicken-install.scm:919: loop */
t11=((C_word*)((C_word*)t0)[5])[1];
f_6215(t11,((C_word*)t0)[2],t10,((C_word*)((C_word*)t0)[6])[1]);}
else{
t8=C_u_i_string_equal_p(((C_word*)t0)[3],lf[381]);
t9=(C_truep(t8)?t8:C_u_i_string_equal_p(((C_word*)t0)[3],lf[382]));
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6559,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t11=((C_word*)t0)[4];
t12=C_u_i_cdr(t11);
if(C_truep(C_i_pairp(t12))){
t13=t10;
f_6559(2,t13,C_SCHEME_UNDEFINED);}
else{
t13=t10;
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f7925,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:785: print */
t15=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t14,lf[372]);}}
else{
t10=C_u_i_string_equal_p(((C_word*)t0)[3],lf[383]);
t11=(C_truep(t10)?t10:C_u_i_string_equal_p(((C_word*)t0)[3],lf[384]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6588,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t13=((C_word*)t0)[4];
t14=C_u_i_cdr(t13);
if(C_truep(C_i_pairp(t14))){
t15=t12;
f_6588(2,t15,C_SCHEME_UNDEFINED);}
else{
t15=t12;
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f7930,a[2]=t15,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:785: print */
t17=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t16,lf[372]);}}
else{
t12=C_u_i_string_equal_p(((C_word*)t0)[3],lf[385]);
t13=(C_truep(t12)?t12:C_u_i_string_equal_p(((C_word*)t0)[3],lf[386]));
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6621,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t15=((C_word*)t0)[4];
t16=C_u_i_cdr(t15);
if(C_truep(C_i_pairp(t16))){
t17=t14;
f_6621(2,t17,C_SCHEME_UNDEFINED);}
else{
t17=t14;
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f7935,a[2]=t17,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:785: print */
t19=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t19+1)))(3,t19,t18,lf[372]);}}
else{
t14=C_u_i_string_equal_p(((C_word*)t0)[3],lf[387]);
t15=(C_truep(t14)?t14:C_u_i_string_equal_p(((C_word*)t0)[3],lf[388]));
if(C_truep(t15)){
t16=lf[5] /* main#*keep* */ =C_SCHEME_TRUE;;
t17=lf[10] /* main#*no-install* */ =C_SCHEME_TRUE;;
t18=((C_word*)t0)[4];
t19=C_u_i_cdr(t18);
/* chicken-install.scm:940: loop */
t20=((C_word*)((C_word*)t0)[5])[1];
f_6215(t20,((C_word*)t0)[2],t19,((C_word*)((C_word*)t0)[6])[1]);}
else{
if(C_truep(C_u_i_string_equal_p(((C_word*)t0)[3],lf[389]))){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6679,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6686,a[2]=t16,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:942: chicken-version */
t18=C_fast_retrieve(lf[45]);
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,t17);}
else{
t16=C_u_i_string_equal_p(((C_word*)t0)[3],lf[390]);
t17=(C_truep(t16)?t16:C_u_i_string_equal_p(((C_word*)t0)[3],lf[391]));
if(C_truep(t17)){
t18=C_set_block_item(((C_word*)t0)[7],0,C_SCHEME_TRUE);
t19=((C_word*)t0)[4];
t20=C_u_i_cdr(t19);
/* chicken-install.scm:946: loop */
t21=((C_word*)((C_word*)t0)[5])[1];
f_6215(t21,((C_word*)t0)[2],t20,((C_word*)((C_word*)t0)[6])[1]);}
else{
t18=C_u_i_string_equal_p(((C_word*)t0)[3],lf[392]);
t19=(C_truep(t18)?t18:C_u_i_string_equal_p(((C_word*)t0)[3],lf[393]));
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6711,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t21=((C_word*)t0)[4];
t22=C_u_i_cdr(t21);
if(C_truep(C_i_pairp(t22))){
t23=t20;
f_6711(2,t23,C_SCHEME_UNDEFINED);}
else{
t23=t20;
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f7942,a[2]=t23,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:785: print */
t25=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t25+1)))(3,t25,t24,lf[372]);}}
else{
if(C_truep(C_u_i_string_equal_p(lf[400],((C_word*)t0)[3]))){
t20=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6737,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t21=((C_word*)t0)[4];
t22=C_u_i_cdr(t21);
if(C_truep(C_i_pairp(t22))){
t23=t20;
f_6737(2,t23,C_SCHEME_UNDEFINED);}
else{
t23=t20;
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f7947,a[2]=t23,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:785: print */
t25=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t25+1)))(3,t25,t24,lf[372]);}}
else{
t20=C_u_i_string_equal_p(lf[401],((C_word*)t0)[3]);
t21=(C_truep(t20)?t20:C_u_i_string_equal_p(lf[402],((C_word*)t0)[3]));
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6770,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t23=((C_word*)t0)[4];
t24=C_u_i_cdr(t23);
if(C_truep(C_i_pairp(t24))){
t25=t22;
f_6770(2,t25,C_SCHEME_UNDEFINED);}
else{
t25=t22;
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f7952,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:785: print */
t27=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t27+1)))(3,t27,t26,lf[372]);}}
else{
if(C_truep(C_u_i_string_equal_p(lf[403],((C_word*)t0)[3]))){
t22=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6804,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t23=((C_word*)t0)[4];
t24=C_u_i_cdr(t23);
if(C_truep(C_i_pairp(t24))){
t25=t22;
f_6804(2,t25,C_SCHEME_UNDEFINED);}
else{
t25=t22;
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f7957,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:785: print */
t27=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t27+1)))(3,t27,t26,lf[372]);}}
else{
if(C_truep(C_u_i_string_equal_p(lf[404],((C_word*)t0)[3]))){
t22=lf[8] /* main#*run-tests* */ =C_SCHEME_TRUE;;
t23=((C_word*)t0)[4];
t24=C_u_i_cdr(t23);
/* chicken-install.scm:967: loop */
t25=((C_word*)((C_word*)t0)[5])[1];
f_6215(t25,((C_word*)t0)[2],t24,((C_word*)((C_word*)t0)[6])[1]);}
else{
if(C_truep(C_u_i_string_equal_p(lf[405],((C_word*)t0)[3]))){
t22=lf[31] /* main#*target-extension* */ =C_SCHEME_FALSE;;
t23=((C_word*)t0)[4];
t24=C_u_i_cdr(t23);
/* chicken-install.scm:970: loop */
t25=((C_word*)((C_word*)t0)[5])[1];
f_6215(t25,((C_word*)t0)[2],t24,((C_word*)((C_word*)t0)[6])[1]);}
else{
if(C_truep(C_u_i_string_equal_p(lf[406],((C_word*)t0)[3]))){
t22=lf[30] /* main#*host-extension* */ =C_SCHEME_FALSE;;
t23=((C_word*)t0)[4];
t24=C_u_i_cdr(t23);
/* chicken-install.scm:973: loop */
t25=((C_word*)((C_word*)t0)[5])[1];
f_6215(t25,((C_word*)t0)[2],t24,((C_word*)((C_word*)t0)[6])[1]);}
else{
if(C_truep(C_u_i_string_equal_p(lf[407],((C_word*)t0)[3]))){
t22=lf[32] /* main#*debug-setup* */ =C_SCHEME_TRUE;;
t23=((C_word*)t0)[4];
t24=C_u_i_cdr(t23);
/* chicken-install.scm:976: loop */
t25=((C_word*)((C_word*)t0)[5])[1];
f_6215(t25,((C_word*)t0)[2],t24,((C_word*)((C_word*)t0)[6])[1]);}
else{
if(C_truep(C_u_i_string_equal_p(lf[408],((C_word*)t0)[3]))){
t22=lf[23] /* main#*deploy* */ =C_SCHEME_TRUE;;
t23=((C_word*)t0)[4];
t24=C_u_i_cdr(t23);
/* chicken-install.scm:979: loop */
t25=((C_word*)((C_word*)t0)[5])[1];
f_6215(t25,((C_word*)t0)[2],t24,((C_word*)((C_word*)t0)[6])[1]);}
else{
if(C_truep(C_u_i_string_equal_p(lf[409],((C_word*)t0)[3]))){
t22=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6893,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t23=((C_word*)t0)[4];
t24=C_u_i_cdr(t23);
if(C_truep(C_i_pairp(t24))){
t25=t22;
f_6893(2,t25,C_SCHEME_UNDEFINED);}
else{
t25=t22;
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f7962,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:785: print */
t27=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t27+1)))(3,t27,t26,lf[372]);}}
else{
if(C_truep(C_u_i_string_equal_p(lf[410],((C_word*)t0)[3]))){
t22=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6919,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t23=((C_word*)t0)[4];
t24=C_u_i_cdr(t23);
if(C_truep(C_i_pairp(t24))){
t25=t22;
f_6919(2,t25,C_SCHEME_UNDEFINED);}
else{
t25=t22;
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f7967,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:785: print */
t27=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t27+1)))(3,t27,t26,lf[372]);}}
else{
if(C_truep(C_u_i_string_equal_p(lf[411],((C_word*)t0)[3]))){
t22=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6945,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t23=((C_word*)t0)[4];
t24=C_u_i_cdr(t23);
if(C_truep(C_i_pairp(t24))){
t25=t22;
f_6945(2,t25,C_SCHEME_UNDEFINED);}
else{
t25=t22;
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f7972,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:785: print */
t27=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t27+1)))(3,t27,t26,lf[372]);}}
else{
t22=C_u_i_string_equal_p(lf[412],((C_word*)t0)[3]);
t23=(C_truep(t22)?t22:C_u_i_string_equal_p(lf[413],((C_word*)t0)[3]));
if(C_truep(t23)){
t24=lf[6] /* main#*keep-existing* */ =C_SCHEME_TRUE;;
t25=((C_word*)t0)[4];
t26=C_u_i_cdr(t25);
/* chicken-install.scm:994: loop */
t27=((C_word*)((C_word*)t0)[5])[1];
f_6215(t27,((C_word*)t0)[2],t26,((C_word*)((C_word*)t0)[6])[1]);}
else{
if(C_truep(C_u_i_string_equal_p(lf[414],((C_word*)t0)[3]))){
t24=lf[35] /* main#*reinstall* */ =C_SCHEME_TRUE;;
t25=((C_word*)t0)[4];
t26=C_u_i_cdr(t25);
/* chicken-install.scm:997: loop */
t27=((C_word*)((C_word*)t0)[5])[1];
f_6215(t27,((C_word*)t0)[2],t26,((C_word*)((C_word*)t0)[6])[1]);}
else{
if(C_truep(C_u_i_string_equal_p(lf[415],((C_word*)t0)[3]))){
t24=lf[24] /* main#*trunk* */ =C_SCHEME_TRUE;;
t25=((C_word*)t0)[4];
t26=C_u_i_cdr(t25);
/* chicken-install.scm:1000: loop */
t27=((C_word*)((C_word*)t0)[5])[1];
f_6215(t27,((C_word*)t0)[2],t26,((C_word*)((C_word*)t0)[6])[1]);}
else{
if(C_truep(C_u_i_string_equal_p(lf[416],((C_word*)t0)[3]))){
t24=lf[33] /* main#*keep-going* */ =C_SCHEME_TRUE;;
t25=((C_word*)t0)[4];
t26=C_u_i_cdr(t25);
/* chicken-install.scm:1003: loop */
t27=((C_word*)((C_word*)t0)[5])[1];
f_6215(t27,((C_word*)t0)[2],t26,((C_word*)((C_word*)t0)[6])[1]);}
else{
if(C_truep(C_u_i_string_equal_p(lf[417],((C_word*)t0)[3]))){
t24=C_set_block_item(((C_word*)t0)[9],0,C_SCHEME_TRUE);
t25=((C_word*)t0)[4];
t26=C_u_i_cdr(t25);
/* chicken-install.scm:1006: loop */
t27=((C_word*)((C_word*)t0)[5])[1];
f_6215(t27,((C_word*)t0)[2],t26,((C_word*)((C_word*)t0)[6])[1]);}
else{
if(C_truep(C_u_i_string_equal_p(lf[418],((C_word*)t0)[3]))){
t24=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7034,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t25=((C_word*)t0)[4];
t26=C_u_i_cdr(t25);
if(C_truep(C_i_pairp(t26))){
t27=t24;
f_7034(2,t27,C_SCHEME_UNDEFINED);}
else{
t27=t24;
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f7977,a[2]=t27,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:785: print */
t29=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t29+1)))(3,t29,t28,lf[372]);}}
else{
if(C_truep(C_u_i_string_equal_p(lf[419],((C_word*)t0)[3]))){
t24=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7060,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t25=((C_word*)t0)[4];
t26=C_u_i_cdr(t25);
if(C_truep(C_i_pairp(t26))){
t27=t24;
f_7060(2,t27,C_SCHEME_UNDEFINED);}
else{
t27=t24;
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f7982,a[2]=t27,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:785: print */
t29=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t29+1)))(3,t29,t28,lf[372]);}}
else{
if(C_truep(C_u_i_string_equal_p(lf[420],((C_word*)t0)[3]))){
t24=lf[36] /* main#*show-depends* */ =C_SCHEME_TRUE;;
t25=((C_word*)t0)[4];
t26=C_u_i_cdr(t25);
/* chicken-install.scm:1017: loop */
t27=((C_word*)((C_word*)t0)[5])[1];
f_6215(t27,((C_word*)t0)[2],t26,((C_word*)((C_word*)t0)[6])[1]);}
else{
if(C_truep(C_u_i_string_equal_p(lf[421],((C_word*)t0)[3]))){
t24=lf[37] /* main#*show-foreign-depends* */ =C_SCHEME_TRUE;;
t25=((C_word*)t0)[4];
t26=C_u_i_cdr(t25);
/* chicken-install.scm:1020: loop */
t27=((C_word*)((C_word*)t0)[5])[1];
f_6215(t27,((C_word*)t0)[2],t26,((C_word*)((C_word*)t0)[6])[1]);}
else{
t24=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7106,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t25=C_block_size(((C_word*)t0)[3]);
if(C_truep(C_fixnum_greaterp(t25,C_fix(0)))){
t26=C_subchar(((C_word*)t0)[3],C_fix(0));
t27=t24;
f_7106(t27,C_i_char_equalp(C_make_character(45),t26));}
else{
t26=t24;
f_7106(t26,C_SCHEME_FALSE);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k7369 in k7366 in a7363 in a7357 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in ... */
static void C_ccall f_7371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7371,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7374,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:1063: cleanup */
f_5431(t2);}

/* k7372 in k7369 in k7366 in a7363 in a7357 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in ... */
static void C_ccall f_7374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve2(lf[21],"main#\052running-test\052"))){
/* chicken-install.scm:1064: exit */
t2=C_fast_retrieve(lf[68]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(2));}
else{
/* chicken-install.scm:1064: exit */
t2=C_fast_retrieve(lf[68]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(1));}}

/* k3487 in a3478 in a3472 in a3466 in a3720 in a3705 in a4169 in k4163 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_fcall f_3489(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3489,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3492,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:326: print */
t3=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[161]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3501,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=C_i_memv(lf[168],((C_word*)t0)[4]);
t4=t2;
f_3501(t4,(C_truep(t3)?C_i_memv(lf[170],((C_word*)t0)[4]):C_SCHEME_FALSE));}
else{
t3=t2;
f_3501(t3,C_SCHEME_FALSE);}}}

/* a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in ... */
static void C_ccall f_7389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7393,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7400,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:1065: command-line-arguments */
t4=C_fast_retrieve(lf[433]);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in ... */
static void C_ccall f_7383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7389,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7402,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:1059: ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* k7126 in k7119 in k7113 in k7104 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_ccall f_7128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:1026: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_6215(t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[4])[1]);}

/* k7119 in k7113 in k7104 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in ... */
static void C_ccall f_7121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7121,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7128,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_i_check_list_2(((C_word*)t0)[5],lf[105]);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7140,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7144,a[2]=t6,a[3]=t10,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_7144(t12,t8,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f7989,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:785: print */
t4=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[372]);}}

/* k6448 in map-loop1589 in k6390 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in ... */
static void C_ccall f_6450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6450,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6421(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6421(t6,((C_word*)t0)[5],t5);}}

/* a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in ... */
static void C_ccall f_7352(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7352,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7358,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7383,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:1059: with-exception-handler */
t5=C_fast_retrieve(lf[183]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* k6455 in k6390 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_ccall f_6457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:880: exit */
t2=C_fast_retrieve(lf[68]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(1));}

/* k7348 in k7342 in k7339 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in ... */
static void C_ccall f_7350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_fast_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a7357 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in ... */
static void C_ccall f_7358(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7358,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7364,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:1059: k1765 */
t4=((C_word*)t0)[2];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t1,t3);}

/* k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in ... */
static void C_ccall f_4853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4853,2,t0,t1);}
if(C_truep(C_retrieve2(lf[9],"main#\052retrieve-only\052"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4859,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5375,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:579: topological-sort */
t4=C_fast_retrieve(lf[340]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_retrieve2(lf[64],"main#\052dependencies\052"),*((C_word*)lf[341]+1));}}

/* k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_fcall f_4850(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4850,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4853,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:577: retrieve */
f_4134(t2,((C_word*)((C_word*)t0)[3])[1]);}

/* k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in ... */
static void C_ccall f_4859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4859,2,t0,t1);}
t2=t1;
t3=C_u_i_length(t2);
t4=C_retrieve2(lf[7],"main#\052force\052");
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4868,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5338,a[2]=t8,a[3]=t11,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_5338(t13,t9,t2);}

/* a3152 in scan in k3120 in main#check-dependency in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in ... */
static void C_ccall f_3153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3153,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm:252: check-dependency */
f_3083(t1,t2);}

/* k7366 in a7363 in a7357 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in ... */
static void C_ccall f_7368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7368,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7371,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:1062: print-error-message */
t3=C_fast_retrieve(lf[165]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],*((C_word*)lf[73]+1));}

/* a7363 in a7357 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in ... */
static void C_ccall f_7364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7364,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7368,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:1061: newline */
t3=*((C_word*)lf[223]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[73]+1));}

/* k3490 in k3487 in a3478 in a3472 in a3466 in a3720 in a3705 in a4169 in k4163 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in ... */
static void C_ccall f_3492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:327: values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_FALSE,lf[160]);}

/* k7104 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_fcall f_7106(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7106,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_block_size(((C_word*)t0)[2]);
if(C_truep(C_fixnum_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7115,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7190,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:1024: substring */
t5=*((C_word*)lf[424]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_fix(1));}
else{
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f7994,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:785: print */
t5=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[372]);}}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7291,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken-install.scm:1032: pathname-extension */
t3=C_fast_retrieve(lf[428]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k3098 in main#check-dependency in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in ... */
static void C_ccall f_3100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:238: values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k7333 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in ... */
static void C_ccall f_7335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:847: setup-proxy */
f_6152(((C_word*)t0)[2],t1);}

/* k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in ... */
static void C_ccall f_7338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7341,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7352,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm:1059: call-with-current-continuation */
t4=*((C_word*)lf[184]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in ... */
static void C_ccall f_4874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4874,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4877,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken-install.scm:588: print */
t3=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[335]);}

/* k7113 in k7104 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_ccall f_7115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7115,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7121,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7182,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm:1025: every */
t5=C_fast_retrieve(lf[146]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in ... */
static void C_ccall f_4871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4871,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4874,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=*((C_word*)lf[73]+1);
t5=*((C_word*)lf[73]+1);
t6=C_i_check_port_2(*((C_word*)lf[73]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[336]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5320,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[7],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:585: ##sys#print */
t8=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,lf[338],C_SCHEME_FALSE,*((C_word*)lf[73]+1));}
else{
t4=t3;
f_4874(2,t4,C_SCHEME_FALSE);}}

/* k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in ... */
static void C_ccall f_4877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4880,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm:589: pp */
t3=C_fast_retrieve(lf[250]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}

/* map-loop1589 in k6390 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_fcall f_6421(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6421,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6450,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6412,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:875: pathname-file */
t7=C_fast_retrieve(lf[351]);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7342 in k7339 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in ... */
static void C_ccall f_7344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7347,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7350,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_fast_retrieve_symbol_proc(lf[222]))(2,*((C_word*)lf[222]+1),t3);}

/* k7345 in k7342 in k7339 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in ... */
static void C_ccall f_7347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* k7339 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in ... */
static void C_ccall f_7341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7344,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:1059: g1769 */
t3=t1;
((C_proc2)C_fast_retrieve_proc(t3))(2,t3,t2);}

/* k4494 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in ... */
static void C_ccall f_4496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4486(t3,((C_word*)t0)[4],t2);}

/* k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in ... */
static void C_ccall f_4868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4868,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4871,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-install.scm:583: list-index */
t4=C_fast_retrieve(lf[339]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[149]+1),t2);}

/* k6410 in map-loop1589 in k6390 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in ... */
static void C_ccall f_6412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6412,2,t0,t1);}
t2=C_a_i_list2(&a,2,lf[356],lf[357]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,t1,t2));}

/* k3120 in main#check-dependency in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in ... */
static void C_fcall f_3122(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3122,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[2]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3131,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_3131(t6,((C_word*)t0)[3],t2,C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3212,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_listp(((C_word*)t0)[2]))){
t3=((C_word*)t0)[2];
t4=C_u_i_length(t3);
t5=C_eqp(C_fix(2),t4);
if(C_truep(t5)){
t6=C_i_car(((C_word*)t0)[2]);
t7=C_i_stringp(t6);
if(C_truep(t7)){
t8=t2;
f_3212(t8,t7);}
else{
t8=((C_word*)t0)[2];
t9=C_u_i_car(t8);
t10=t2;
f_3212(t10,C_i_symbolp(t9));}}
else{
t6=t2;
f_3212(t6,C_SCHEME_FALSE);}}
else{
t3=t2;
f_3212(t3,C_SCHEME_FALSE);}}}

/* k6417 in k6390 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_ccall f_6419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:872: append */
t2=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_retrieve2(lf[63],"main#\052eggs+dirs+vers\052"));}

/* k4811 in k4805 in k4708 in k4833 in k4688 in k4685 in k4682 in k4679 in k4676 in k4673 in k4667 in k4659 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in ... */
static void C_ccall f_4813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4813,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4816,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4826,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:540: normalize-pathname */
t4=C_fast_retrieve(lf[292]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[5],lf[293]);}

/* k4814 in k4811 in k4805 in k4708 in k4833 in k4688 in k4685 in k4682 in k4679 in k4676 in k4673 in k4667 in k4659 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in ... */
static void C_ccall f_4816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4816,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4819,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:539: ##sys#print */
t3=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[296],C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k4817 in k4814 in k4811 in k4805 in k4708 in k4833 in k4688 in k4685 in k4682 in k4679 in k4676 in k4673 in k4667 in k4659 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in ... */
static void C_ccall f_4819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:539: get-output-string */
t2=C_fast_retrieve(lf[123]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k6484 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f_6486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:907: exit */
t2=C_fast_retrieve(lf[68]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k4805 in k4708 in k4833 in k4688 in k4685 in k4682 in k4679 in k4676 in k4673 in k4667 in k4659 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in ... */
static void C_ccall f_4807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4807,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[122]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4813,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:539: ##sys#print */
t6=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[297],C_SCHEME_FALSE,t3);}

/* k4802 in k4789 in k4783 in k4715 in k4711 in k4708 in k4833 in k4688 in k4685 in k4682 in k4679 in k4676 in k4673 in k4667 in k4659 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in ... */
static void C_ccall f_4804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:544: ##sys#print */
t2=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k4833 in k4688 in k4685 in k4682 in k4679 in k4676 in k4673 in k4667 in k4659 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in ... */
static void C_ccall f_4835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4835,2,t0,t1);}
t2=(C_truep(t1)?lf[271]:lf[272]);
t3=t2;
t4=(C_truep(C_retrieve2(lf[5],"main#\052keep\052"))?lf[273]:lf[274]);
t5=t4;
t6=(C_truep(C_retrieve2(lf[10],"main#\052no-install\052"))?(C_truep(((C_word*)t0)[2])?lf[275]:lf[276]):lf[275]);
t7=t6;
t8=(C_truep(C_retrieve2(lf[30],"main#\052host-extension\052"))?lf[277]:lf[278]);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4710,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=t5,a[8]=t7,a[9]=t9,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
/* chicken-install.scm:537: get-prefix */
f_2422(t10,C_SCHEME_END_OF_LIST);}

/* k4824 in k4811 in k4805 in k4708 in k4833 in k4688 in k4685 in k4682 in k4679 in k4676 in k4673 in k4667 in k4659 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in ... */
static void C_ccall f_4826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:539: ##sys#print */
t2=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* g495 in k3356 in a4257 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_fcall f_3359(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3359,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3364,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:292: h */
t4=t2;
((C_proc4)C_fast_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k3356 in a4257 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in ... */
static void C_ccall f_3358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3358,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3359,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=C_retrieve2(lf[38],"main#\052hacks\052");
t6=C_i_check_list_2(C_retrieve2(lf[38],"main#\052hacks\052"),lf[86]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3370,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3428,a[2]=t9,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t11=((C_word*)t9)[1];
f_3428(t11,t7,C_retrieve2(lf[38],"main#\052hacks\052"));}

/* a5088 in a5082 in a5070 in a5046 in k4928 in k4924 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in ... */
static void C_ccall f_5089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5089,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a5082 in a5070 in a5046 in k4928 in k4924 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in ... */
static void C_ccall f_5083(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_5083r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5083r(t0,t1,t2);}}

static void C_ccall f_5083r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5089,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:632: k1122 */
t4=((C_word*)t0)[2];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t1,t3);}

/* k3182 in a3162 in scan in k3120 in main#check-dependency in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in ... */
static void C_fcall f_3184(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(((C_word*)t0)[2])?C_i_not(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t2)){
/* chicken-install.scm:255: scan */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3131(t3,((C_word*)t0)[5],((C_word*)t0)[6],t1,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
/* chicken-install.scm:255: scan */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3131(t4,((C_word*)t0)[5],((C_word*)t0)[6],t1,t3);}}

/* k3368 in k3356 in a4257 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_ccall f_3370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3370,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3375,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3375(t5,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_ccall f_6252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6252,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6262,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve2(lf[15],"main#\052default-transport\052");
t4=C_retrieve2(lf[14],"main#\052default-location\052");
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6119,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm:766: with-default-sources */
f_3601(t2,t5);}
else{
if(C_truep(C_retrieve2(lf[36],"main#\052show-depends\052"))){
/* chicken-install.scm:893: show-depends */
f_3964(((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1],C_a_i_list(&a,1,lf[83]));}
else{
if(C_truep(C_retrieve2(lf[37],"main#\052show-foreign-depends\052"))){
/* chicken-install.scm:895: show-depends */
f_3964(((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1],C_a_i_list(&a,1,lf[99]));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6281,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6285,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:897: reverse */
t4=*((C_word*)lf[103]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[4])[1]);}}}}

/* loop in k3368 in k3356 in a4257 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in ... */
static void C_fcall f_3375(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3375,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3389,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:296: reverse */
t6=*((C_word*)lf[103]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
t5=C_i_car(t2);
t6=t5;
t7=t2;
t8=C_u_i_cdr(t7);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3402,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3408,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:297: ##sys#call-with-values */
C_call_with_values(4,0,t1,t9,t10);}}

/* k2707 in k2477 in g249 in k2856 in k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_ccall f_2709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:163: append */
t2=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[28],"main#\052aliases\052"),t1);}

/* k6283 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in ... */
static void C_ccall f_6285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:897: apply-mappings */
f_5816(((C_word*)t0)[2],t1);}

/* k6279 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in ... */
static void C_ccall f_6281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6281,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t1;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4850,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[6],"main#\052keep-existing\052"))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5379,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5381,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm:574: remove */
t8=C_fast_retrieve(lf[342]);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t4)[1]);}
else{
t6=t5;
f_4850(t6,C_SCHEME_UNDEFINED);}}

/* k3362 in g495 in k3356 in a4257 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in ... */
static void C_ccall f_3364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k6286 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_ccall f_6288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_retrieve2(lf[14],"main#\052default-location\052"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_6252(2,t3,t2);}
else{
/* chicken-install.scm:886: error */
t2=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[343]);}}

/* k6947 in k6943 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_ccall f_6949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate2(&lf[34] /* (set! main#*override* ...) */,t1);
t3=C_i_cddr(((C_word*)t0)[2]);
/* chicken-install.scm:991: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6215(t4,((C_word*)t0)[4],t3,((C_word*)((C_word*)t0)[5])[1]);}

/* k6943 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f_6945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6949,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm:990: read-file */
t4=C_fast_retrieve(lf[352]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* k6400 in k6390 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_ccall f_6402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(&lf[63] /* (set! main#*eggs+dirs+vers* ...) */,t1);
t3=((C_word*)t0)[2];
f_6249(2,t3,t2);}

/* f7920 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f7920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:825: exit */
t2=C_fast_retrieve(lf[68]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* f7925 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f7925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:825: exit */
t2=C_fast_retrieve(lf[68]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(1));}

/* k6260 in k6250 in k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in ... */
static void C_ccall f_6262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:889: display */
t2=*((C_word*)lf[253]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2738 in map-loop332 in k2477 in g249 in k2856 in k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in ... */
static void C_ccall f_2740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2740,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_2711(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_2711(t6,((C_word*)t0)[5],t5);}}

/* k3307 in k3210 in k3120 in main#check-dependency in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in ... */
static void C_ccall f_3309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:287: values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k2648 in map-loop287 in k2477 in g249 in k2856 in k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in ... */
static void C_ccall f_2650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2650,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_2621(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_2621(t6,((C_word*)t0)[5],t5);}}

/* k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in ... */
static void C_ccall f_6210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6210,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6215,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_6215(t5,((C_word*)t0)[6],((C_word*)t0)[7],C_SCHEME_END_OF_LIST);}

/* loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in ... */
static void C_fcall f_6215(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6215,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
if(C_truep(C_i_nullp(t2))){
t5=(C_truep(C_retrieve2(lf[23],"main#\052deploy\052"))?C_i_not(C_retrieve2(lf[27],"main#\052prefix\052")):C_SCHEME_FALSE);
if(C_truep(t5)){
/* chicken-install.scm:851: error */
t6=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,lf[224]);}
else{
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=t1;
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5450,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5810,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5814,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:675: repository-path */
t10=C_fast_retrieve(lf[226]);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t6=t1;
t7=((C_word*)((C_word*)t0)[3])[1];
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5989,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:738: setup-download#gather-egg-information */
((C_proc3)C_fast_retrieve_symbol_proc(lf[252]))(3,*((C_word*)lf[252]+1),t8,t7);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6246,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2459,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2862,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:127: chicken-home */
t10=C_fast_retrieve(lf[370]);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}}}}
else{
t5=C_i_car(t2);
t6=t5;
t7=C_i_string_equal_p(t6,lf[371]);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6475,a[2]=t1,a[3]=t6,a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[6],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t7)){
t9=t8;
f_6475(t9,t7);}
else{
t9=C_u_i_string_equal_p(t6,lf[429]);
if(C_truep(t9)){
t10=t8;
f_6475(t10,t9);}
else{
t10=C_u_i_string_equal_p(t6,lf[430]);
t11=t8;
f_6475(t11,t10);}}}}

/* map-loop332 in k2477 in g249 in k2856 in k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_fcall f_2711(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2711,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2740,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-install.scm:165: g338 */
t5=((C_word*)t0)[5];
f_2666(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6917 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f_6919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
/* chicken-install.scm:987: loop */
t7=((C_word*)((C_word*)t0)[4])[1];
f_6215(t7,((C_word*)t0)[5],t6,((C_word*)((C_word*)t0)[6])[1]);}

/* map-loop287 in k2477 in g249 in k2856 in k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_fcall f_2621(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2621,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2650,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-install.scm:155: g293 */
t5=((C_word*)t0)[5];
f_2577(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in ... */
static void C_ccall f_6246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[31],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6246,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6249,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[4])[1]))){
if(C_truep(C_retrieve2(lf[35],"main#\052reinstall\052"))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6306,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6051,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6053,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6103,a[2]=t6,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6107,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6111,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=t10;
t12=(C_truep(C_retrieve2(lf[29],"main#\052cross-chicken\052"))?C_i_not(C_retrieve2(lf[30],"main#\052host-extension\052")):C_SCHEME_FALSE);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2398,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t14=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t13,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}
else{
/* chicken-install.scm:117: repository-path */
t13=C_fast_retrieve(lf[226]);
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t11);}}
else{
t4=((C_word*)((C_word*)t0)[2])[1];
if(C_truep(t4)){
t5=t3;
f_6249(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6392,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:869: glob */
t6=C_fast_retrieve(lf[248]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[359]);}}}
else{
t4=t3;
f_6249(2,t4,C_SCHEME_UNDEFINED);}}

/* k6247 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f_6249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6249,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6252,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_6252(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6288,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[15],"main#\052default-transport\052"))){
if(C_truep(C_retrieve2(lf[14],"main#\052default-location\052"))){
t4=C_SCHEME_UNDEFINED;
t5=t2;
f_6252(2,t5,t4);}
else{
/* chicken-install.scm:886: error */
t4=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,lf[343]);}}
else{
/* chicken-install.scm:883: error */
t4=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[344]);}}}

/* k2671 in g338 in k2477 in g249 in k2856 in k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in ... */
static void C_ccall f_2673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2673,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_i_cadr(((C_word*)t0)[2]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,t2,t3));}
else{
/* chicken-install.scm:168: broken */
t2=((C_word*)t0)[4];
f_2461(t2,((C_word*)t0)[3],((C_word*)t0)[5]);}}

/* k6782 in k6768 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_ccall f_6784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6784,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_retrieve2(lf[25],"main#\052csc-features\052"));
t3=C_mutate2(&lf[25] /* (set! main#*csc-features* ...) */,t2);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
/* chicken-install.scm:959: loop */
t7=((C_word*)((C_word*)t0)[3])[1];
f_6215(t7,((C_word*)t0)[4],t6,((C_word*)((C_word*)t0)[5])[1]);}

/* k2557 in k2477 in g249 in k2856 in k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_ccall f_2559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(&lf[13] /* (set! main#*default-sources* ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2752 in k2477 in g249 in k2856 in k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_ccall f_2754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(&lf[34] /* (set! main#*override* ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2785 in k2477 in g249 in k2856 in k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_ccall f_2787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(&lf[38] /* (set! main#*hacks* ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* g338 in k2477 in g249 in k2856 in k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_fcall f_2666(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2666,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2673,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_listp(t2))){
t4=t2;
t5=C_u_i_length(t4);
t6=C_eqp(C_fix(2),t5);
if(C_truep(t6)){
/* chicken-install.scm:166: every */
t7=C_fast_retrieve(lf[146]);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,*((C_word*)lf[367]+1),t2);}
else{
t7=t3;
f_2673(2,t7,C_SCHEME_FALSE);}}
else{
t4=t3;
f_2673(2,t4,C_SCHEME_FALSE);}}

/* k2662 in k2477 in g249 in k2856 in k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_ccall f_2664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(&lf[28] /* (set! main#*aliases* ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in ... */
static void C_ccall f_6207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6207,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6210,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7335,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:847: get-environment-variable */
t5=C_fast_retrieve(lf[214]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[431]);}

/* k2755 in k2477 in g249 in k2856 in k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_fcall f_2757(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm:173: read-file */
t3=C_fast_retrieve(lf[352]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],t2);}
else{
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_mutate2(&lf[34] /* (set! main#*override* ...) */,t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k3391 in k3387 in loop in k3368 in k3356 in a4257 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in ... */
static void C_ccall f_3393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:296: values */
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* for-each-loop494 in k3356 in a4257 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_fcall f_3428(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3428,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3438,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-install.scm:289: g495 */
t5=((C_word*)t0)[3];
f_3359(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2529 in k2526 in k2523 in k2520 in k2517 in k2514 in k2508 in k2477 in g249 in k2856 in k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in ... */
static void C_ccall f_2531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm:140: error */
t3=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t1,t2);}

/* k6738 in k6735 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_ccall f_6740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cddr(((C_word*)t0)[2]);
/* chicken-install.scm:954: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6215(t3,((C_word*)t0)[4],t2,((C_word*)((C_word*)t0)[5])[1]);}

/* k3387 in loop in k3368 in k3356 in a4257 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in ... */
static void C_ccall f_3389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3389,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3393,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:296: reverse */
t4=*((C_word*)lf[103]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* g1486 in k6097 in a6052 in k6244 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in ... */
static void C_fcall f_6070(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6070,NULL,3,t0,t1,t2);}
t3=C_i_cadr(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6082,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:756: ->string */
t6=C_fast_retrieve(lf[47]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* f7994 in k7104 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_ccall f7994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:825: exit */
t2=C_fast_retrieve(lf[68]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(1));}

/* a3401 in loop in k3368 in k3356 in a4257 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in ... */
static void C_ccall f_3402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3402,2,t0,t1);}
/* chicken-install.scm:299: check-dependency */
f_3083(t1,((C_word*)t0)[2]);}

/* a3407 in loop in k3368 in k3356 in a4257 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in ... */
static void C_ccall f_3408(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3408,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?C_a_i_cons(&a,2,t2,((C_word*)t0)[2]):((C_word*)t0)[2]);
if(C_truep(t3)){
t5=C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
/* chicken-install.scm:300: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3375(t6,t1,((C_word*)t0)[5],t4,t5);}
else{
t5=((C_word*)t0)[3];
/* chicken-install.scm:300: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3375(t6,t1,((C_word*)t0)[5],t4,t5);}}

/* a2594 in k2582 in k2579 in g293 in k2477 in g249 in k2856 in k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in ... */
static void C_ccall f_2595(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2595,4,t0,t1,t2,t3);}
t4=C_i_cdr(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_cons(&a,2,t2,t4));}

/* k2793 in k2477 in g249 in k2856 in k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_ccall f_2795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2795,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
/* chicken-install.scm:176: append */
t3=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],C_retrieve2(lf[38],"main#\052hacks\052"),t2);}

/* scan in k3120 in main#check-dependency in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in ... */
static void C_fcall f_3131(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3131,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_nullp(t2))){
if(C_truep(t4)){
/* chicken-install.scm:247: values */
C_values(4,0,t1,C_SCHEME_FALSE,t4);}
else{
if(C_truep(t3)){
t5=t3;
/* chicken-install.scm:247: values */
C_values(4,0,t1,t5,t4);}
else{
/* chicken-install.scm:247: values */
C_values(4,0,t1,C_SCHEME_FALSE,t4);}}}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3153,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3163,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:252: ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}}

/* f7982 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f7982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:825: exit */
t2=C_fast_retrieve(lf[68]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(1));}

/* f7989 in k7119 in k7113 in k7104 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_ccall f7989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:825: exit */
t2=C_fast_retrieve(lf[68]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(1));}

/* k3436 in for-each-loop494 in k3356 in a4257 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in ... */
static void C_ccall f_3438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3428(t3,((C_word*)t0)[4],t2);}

/* g293 in k2477 in g249 in k2856 in k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_fcall f_2577(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2577,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2581,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2608,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm:156: list-index */
t5=C_fast_retrieve(lf[339]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* k2928 in main#with-default-sources in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in ... */
static void C_ccall f_2930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2913(t2,C_i_not(t1));}

/* a3162 in scan in k3120 in main#check-dependency in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in ... */
static void C_ccall f_3163(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3163,4,t0,t1,t2,t3);}
t4=t3;
t5=(C_truep(t2)?C_SCHEME_FALSE:C_i_not(t4));
if(C_truep(t5)){
/* chicken-install.scm:254: values */
C_values(4,0,t1,C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
t6=C_i_cdr(((C_word*)t0)[2]);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3184,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t9=((C_word*)t0)[5];
t10=t8;
f_3184(t10,(C_truep(t9)?((C_word*)t0)[5]:t2));}
else{
t9=t8;
f_3184(t9,((C_word*)t0)[5]);}}}

/* main#deps in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 */
static C_word C_fcall f_2932(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_stack_overflow_check;
t3=C_i_assq(t1,t2);
if(C_truep(t3)){
t4=C_i_cdr(t3);
return((C_truep(t4)?t4:C_SCHEME_END_OF_LIST));}
else{
return(C_SCHEME_END_OF_LIST);}}

/* f7972 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f7972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:825: exit */
t2=C_fast_retrieve(lf[68]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(1));}

/* k6709 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f_6711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6711,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6714,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
t4=t2;
t5=t3;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2951,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:205: repository-path */
t7=C_fast_retrieve(lf[226]);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* f7977 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f7977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:825: exit */
t2=C_fast_retrieve(lf[68]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(1));}

/* k6712 in k6709 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_ccall f_6714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:950: exit */
t2=C_fast_retrieve(lf[68]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k2573 in k2477 in g249 in k2856 in k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_ccall f_2575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate2(&lf[22] /* (set! main#*mappings* ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* a2588 in k2582 in k2579 in g293 in k2477 in g249 in k2856 in k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in ... */
static void C_ccall f_2589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2589,2,t0,t1);}
/* chicken-install.scm:158: split-at */
t2=C_fast_retrieve(lf[364]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* f7962 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f7962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:825: exit */
t2=C_fast_retrieve(lf[68]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(1));}

/* f7967 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f7967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:825: exit */
t2=C_fast_retrieve(lf[68]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(1));}

/* a4169 in k4163 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in ... */
static void C_ccall f_4170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4170,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3706,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:365: with-default-sources */
f_3601(t1,t4);}

/* a4175 in k4163 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in ... */
static void C_ccall f_4176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4176,4,t0,t1,t2,t3);}
t4=t2;
t5=t3;
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4180,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=C_i_not(t4);
if(C_truep(t7)){
if(C_truep(t7)){
/* chicken-install.scm:449: error */
t8=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,lf[188]);}
else{
t8=t6;
f_4180(2,t8,C_SCHEME_UNDEFINED);}}
else{
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4207,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:448: directory */
t9=C_fast_retrieve(lf[189]);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t4);}}

/* k2579 in g293 in k2477 in g249 in k2856 in k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in ... */
static void C_ccall f_2581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2581,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2584,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_2584(2,t4,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm:157: broken */
t4=((C_word*)t0)[4];
f_2461(t4,t3,((C_word*)t0)[5]);}}

/* k2582 in k2579 in g293 in k2477 in g249 in k2856 in k2457 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in ... */
static void C_ccall f_2584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2584,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2589,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2595,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm:158: ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[4],t2,t3);}

/* k2908 in main#with-default-sources in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in ... */
static void C_ccall f_2910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2910,2,t0,t1);}
t2=C_a_i_list(&a,2,lf[77],t1);
t3=C_a_i_list(&a,2,lf[75],C_retrieve2(lf[15],"main#\052default-transport\052"));
t4=C_a_i_list(&a,2,t2,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_list(&a,1,t4));}

/* k2911 in main#with-default-sources in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in ... */
static void C_fcall f_2913(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2913,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2920,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:194: current-directory */
t3=C_fast_retrieve(lf[80]);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_retrieve2(lf[14],"main#\052default-location\052");
t3=C_retrieve2(lf[14],"main#\052default-location\052");
t4=C_a_i_list(&a,2,lf[77],C_retrieve2(lf[14],"main#\052default-location\052"));
t5=C_a_i_list(&a,2,lf[75],C_retrieve2(lf[15],"main#\052default-transport\052"));
t6=C_a_i_list(&a,2,t4,t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_list(&a,1,t6));}}

/* f7952 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f7952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:825: exit */
t2=C_fast_retrieve(lf[68]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(1));}

/* k4688 in k4685 in k4682 in k4679 in k4676 in k4673 in k4667 in k4659 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in ... */
static void C_ccall f_4690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4690,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4835,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-install.scm:533: setup-api#sudo-install */
((C_proc2)C_fast_retrieve_symbol_proc(lf[299]))(2,*((C_word*)lf[299]+1),t3);}

/* f7957 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f7957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:825: exit */
t2=C_fast_retrieve(lf[68]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(1));}

/* k6768 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f_6770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6770,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6784,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm:958: string->symbol */
t4=*((C_word*)lf[135]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* k4163 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in ... */
static void C_ccall f_4165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4165,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4170,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4176,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:444: ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],t3,t4);}

/* k4685 in k4682 in k4679 in k4676 in k4673 in k4667 in k4659 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in ... */
static void C_ccall f_4687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4687,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4690,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm:531: get-output-string */
t3=C_fast_retrieve(lf[123]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}

/* k2918 in k2911 in main#with-default-sources in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in ... */
static void C_ccall f_2920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:194: make-pathname */
t2=C_fast_retrieve(lf[79]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_retrieve2(lf[14],"main#\052default-location\052"));}

/* f7942 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f7942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:825: exit */
t2=C_fast_retrieve(lf[68]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(1));}

/* k4679 in k4676 in k4673 in k4667 in k4659 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in ... */
static void C_ccall f_4681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4684,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* chicken-install.scm:531: ##sys#print */
t3=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[9],C_SCHEME_FALSE,((C_word*)t0)[8]);}

/* f7947 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f7947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:825: exit */
t2=C_fast_retrieve(lf[68]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(1));}

/* k4682 in k4679 in k4676 in k4673 in k4667 in k4659 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in ... */
static void C_ccall f_4684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4684,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4687,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken-install.scm:531: ##sys#print */
t3=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[300],C_SCHEME_FALSE,((C_word*)t0)[8]);}

/* f7930 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f7930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:825: exit */
t2=C_fast_retrieve(lf[68]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(1));}

/* k2972 in g400 in k2955 in k2949 in k6709 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in ... */
static void C_ccall f_2974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:212: setup-api#shellpath */
((C_proc3)C_fast_retrieve_symbol_proc(lf[283]))(3,*((C_word*)lf[283]+1),((C_word*)t0)[2],t1);}

/* k2968 in k2964 in g400 in k2955 in k2949 in k6709 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in ... */
static void C_ccall f_2970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2970,2,t0,t1);}
/* chicken-install.scm:212: command */
f_6131(((C_word*)t0)[2],lf[396],C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[4],t1));}

/* f7935 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f7935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:825: exit */
t2=C_fast_retrieve(lf[68]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(1));}

/* a5576 in k5564 in k5561 in a5555 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in ... */
static void C_ccall f_5577(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[20],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5577,5,t0,t1,t2,t3,t4);}
t5=t3;
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5583,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t11=C_i_check_list_2(t4,lf[105]);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5597,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5650,a[2]=t10,a[3]=t9,a[4]=t14,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_5650(t16,t12,t4);}

/* a5570 in k5564 in k5561 in a5555 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in ... */
static void C_ccall f_5571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5571,2,t0,t1);}
/* chicken-install.scm:698: ##sys#module-exports */
((C_proc3)C_fast_retrieve_symbol_proc(lf[231]))(3,*((C_word*)lf[231]+1),t1,((C_word*)t0)[2]);}

/* for-each-loop399 in k2955 in k2949 in k6709 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_fcall f_2982(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2982,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2992,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-install.scm:210: g400 */
t5=((C_word*)t0)[3];
f_2958(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2955 in k2949 in k6709 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in ... */
static void C_ccall f_2957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2957,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2958,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_check_list_2(lf[397],lf[86]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2982,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_2982(t7,((C_word*)t0)[5],lf[397]);}

/* g400 in k2955 in k2949 in k6709 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_fcall f_2958(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2958,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2966,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2974,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:212: make-pathname */
t5=C_fast_retrieve(lf[79]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[4],t2);}

/* k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in ... */
static void C_ccall f_4138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4138,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_i_check_list_2(t2,lf[86]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4217,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4486,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_4486(t8,t4,t2);}

/* main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in k2292 in k2289 in k2286 in ... */
static void C_fcall f_4134(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4134,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4138,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:436: print */
t4=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[194]);}

/* k4364 in k4391 in k4385 in k4271 in a4267 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in ... */
static void C_ccall f_4366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:477: print */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[137],t1);}

/* k6735 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in ... */
static void C_ccall f_6737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6737,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6740,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm:953: setup-proxy */
f_6152(t2,t3);}

/* k2949 in k6709 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in ... */
static void C_ccall f_2951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2951,2,t0,t1);}
t2=t1;
t3=(C_truep(C_retrieve2(lf[17],"main#\052windows-shell\052"))?lf[394]:lf[395]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2957,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:209: print */
t6=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[398],((C_word*)t0)[2],lf[399]);}

/* a5555 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in ... */
static void C_ccall f_5556(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5556,3,t0,t1,t2);}
t3=C_i_cdr(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5563,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:696: ##sys#module-name */
((C_proc3)C_fast_retrieve_symbol_proc(lf[236]))(3,*((C_word*)lf[236]+1),t5,t4);}

/* k4351 in k4347 in k4278 in k4391 in k4385 in k4271 in a4267 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in ... */
static void C_ccall f_4353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:481: yes-or-no? */
t2=C_fast_retrieve(lf[113]);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[114],lf[115],lf[116],t1);}

/* k4357 in k4391 in k4385 in k4271 in a4267 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in ... */
static void C_ccall f_4359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:478: retrieve */
f_4134(((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);}

/* k2964 in g400 in k2955 in k2949 in k6709 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in ... */
static void C_ccall f_2966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2966,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2970,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:212: setup-api#shellpath */
((C_proc3)C_fast_retrieve_symbol_proc(lf[283]))(3,*((C_word*)lf[283]+1),t3,((C_word*)t0)[4]);}

/* k4154 in for-each-loop747 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2301 in k2298 in k2295 in ... */
static void C_ccall f_4156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4156,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_mutate2(&lf[63] /* (set! main#*eggs+dirs+vers* ...) */,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* g1313 in a5576 in k5564 in k5561 in a5555 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in ... */
static C_word C_fcall f_5583(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_overflow_check;
t2=C_i_car(t1);
return(C_a_i_list3(&a,3,t2,lf[232],((C_word*)t0)[2]));}

/* k4673 in k4667 in k4659 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in ... */
static void C_ccall f_4675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4678,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* chicken-install.scm:531: ##sys#print */
t3=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[6],C_SCHEME_FALSE,((C_word*)t0)[8]);}

/* k4385 in k4271 in a4267 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in k2322 in ... */
static void C_ccall f_4387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4387,2,t0,t1);}
t2=C_i_check_list_2(t1,lf[105]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4393,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4395,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4395(t7,t3,t1);}

/* k4676 in k4673 in k4667 in k4659 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in ... */
static void C_ccall f_4678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4681,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* chicken-install.scm:531: ##sys#print */
t3=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[301],C_SCHEME_FALSE,((C_word*)t0)[8]);}

/* k5530 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in ... */
static void C_ccall f_5532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5532,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5534,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm:692: sort */
t3=C_fast_retrieve(lf[230]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a5533 in k5530 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in ... */
static void C_ccall f_5534(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5534,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5542,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_i_car(t2);
/* chicken-install.scm:704: symbol->string */
t6=*((C_word*)lf[197]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k4659 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in k6250 in ... */
static void C_fcall f_4661(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4661,NULL,2,t0,t1);}
t2=t1;
t3=(C_truep(C_retrieve2(lf[32],"main#\052debug-setup\052"))?lf[269]:lf[270]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4669,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t4,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* chicken-install.scm:531: open-output-string */
t6=C_fast_retrieve(lf[128]);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k4667 in k4659 in k4921 in a4918 in k4906 in k4903 in setup in k4898 in k4892 in k4889 in k4886 in k4883 in g1081 in k4878 in k4875 in k4872 in k4869 in k4866 in k4857 in k4851 in k4848 in k6279 in ... */
static void C_ccall f_4669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4669,2,t0,t1);}
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[122]);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=t3,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* chicken-install.scm:531: ##sys#print */
t6=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[302],C_SCHEME_FALSE,t3);}

/* k5564 in k5561 in a5555 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in ... */
static void C_ccall f_5566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5566,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5571,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5577,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:698: ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[4],t2,t3);}

/* k5561 in a5555 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in ... */
static void C_ccall f_5563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5563,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5566,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:697: print* */
t4=*((C_word*)lf[234]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[235],t2);}

/* k4319 in for-each-loop849 in k4290 in k4287 in k4284 in k4278 in k4391 in k4385 in k4271 in a4267 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in ... */
static void C_ccall f_4321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4311(t3,((C_word*)t0)[4],t2);}

/* k2990 in for-each-loop399 in k2955 in k2949 in k6709 in k6473 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in k2328 in k2325 in ... */
static void C_ccall f_2992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2982(t3,((C_word*)t0)[4],t2);}

/* k5515 in for-each-loop1364 in a5492 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in ... */
static void C_ccall f_5517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5507(t3,((C_word*)t0)[4],t2);}

/* for-each-loop849 in k4290 in k4287 in k4284 in k4278 in k4391 in k4385 in k4271 in a4267 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in ... */
static void C_fcall f_4311(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4311,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4321,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4297,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:489: print */
t8=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,lf[107],t6,lf[108]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5540 in a5533 in k5530 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in k2341 in ... */
static void C_ccall f_5542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5542,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5546,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_car(((C_word*)t0)[3]);
/* chicken-install.scm:704: symbol->string */
t5=*((C_word*)lf[197]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k5544 in k5540 in a5533 in k5530 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in loop in k6208 in k6205 in k7398 in a7388 in a7382 in a7351 in k7336 in k3454 in k2371 in k2344 in ... */
static void C_ccall f_5546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:704: string<? */
t2=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k4347 in k4278 in k4391 in k4385 in k4271 in a4267 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in k2338 in k2331 in ... */
static void C_ccall f_4349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4349,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4353,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:484: setup-api#abort-setup */
((C_proc2)C_fast_retrieve_symbol_proc(lf[117]))(2,*((C_word*)lf[117]+1),t3);}

/* k4334 in k4287 in k4284 in k4278 in k4391 in k4385 in k4271 in a4267 in k4251 in k4248 in k4245 in k4242 in k4239 in k4233 in for-each-loop789 in k4215 in k4136 in main#retrieve in k3454 in k2371 in k2344 in k2341 in ... */
static void C_ccall f_4336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm:486: print */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[109],t1);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[570] = {
{"f_4622:chicken_2dinstall_2escm",(void*)f_4622},
{"f_5323:chicken_2dinstall_2escm",(void*)f_5323},
{"f_5326:chicken_2dinstall_2escm",(void*)f_5326},
{"f_5329:chicken_2dinstall_2escm",(void*)f_5329},
{"f_7393:chicken_2dinstall_2escm",(void*)f_7393},
{"f_5320:chicken_2dinstall_2escm",(void*)f_5320},
{"f_5507:chicken_2dinstall_2escm",(void*)f_5507},
{"f_4306:chicken_2dinstall_2escm",(void*)f_4306},
{"f_5381:chicken_2dinstall_2escm",(void*)f_5381},
{"f_4569:chicken_2dinstall_2escm",(void*)f_4569},
{"f_5379:chicken_2dinstall_2escm",(void*)f_5379},
{"f_5375:chicken_2dinstall_2escm",(void*)f_5375},
{"f_4598:chicken_2dinstall_2escm",(void*)f_4598},
{"f_4582:chicken_2dinstall_2escm",(void*)f_4582},
{"f_2619:chicken_2dinstall_2escm",(void*)f_2619},
{"f_4534:chicken_2dinstall_2escm",(void*)f_4534},
{"f_4180:chicken_2dinstall_2escm",(void*)f_4180},
{"f_4183:chicken_2dinstall_2escm",(void*)f_4183},
{"f_2608:chicken_2dinstall_2escm",(void*)f_2608},
{"f_7034:chicken_2dinstall_2escm",(void*)f_7034},
{"f_2519:chicken_2dinstall_2escm",(void*)f_2519},
{"f_4544:chicken_2dinstall_2escm",(void*)f_4544},
{"f_2510:chicken_2dinstall_2escm",(void*)f_2510},
{"f_2516:chicken_2dinstall_2escm",(void*)f_2516},
{"f_2528:chicken_2dinstall_2escm",(void*)f_2528},
{"f_2522:chicken_2dinstall_2escm",(void*)f_2522},
{"f_2525:chicken_2dinstall_2escm",(void*)f_2525},
{"f_6493:chicken_2dinstall_2escm",(void*)f_6493},
{"f_4512:chicken_2dinstall_2escm",(void*)f_4512},
{"f_5113:chicken_2dinstall_2escm",(void*)f_5113},
{"f_5997:chicken_2dinstall_2escm",(void*)f_5997},
{"f_3806:chicken_2dinstall_2escm",(void*)f_3806},
{"f_3803:chicken_2dinstall_2escm",(void*)f_3803},
{"f_3800:chicken_2dinstall_2escm",(void*)f_3800},
{"f_5989:chicken_2dinstall_2escm",(void*)f_5989},
{"f_5986:chicken_2dinstall_2escm",(void*)f_5986},
{"f_5338:chicken_2dinstall_2escm",(void*)f_5338},
{"f_5169:chicken_2dinstall_2escm",(void*)f_5169},
{"f_5163:chicken_2dinstall_2escm",(void*)f_5163},
{"f_4009:chicken_2dinstall_2escm",(void*)f_4009},
{"f_5958:chicken_2dinstall_2escm",(void*)f_5958},
{"f_5952:chicken_2dinstall_2escm",(void*)f_5952},
{"f_3846:chicken_2dinstall_2escm",(void*)f_3846},
{"f_5139:chicken_2dinstall_2escm",(void*)f_5139},
{"f_5134:chicken_2dinstall_2escm",(void*)f_5134},
{"f_5940:chicken_2dinstall_2escm",(void*)f_5940},
{"f_5129:chicken_2dinstall_2escm",(void*)f_5129},
{"f_7416:chicken_2dinstall_2escm",(void*)f_7416},
{"f_5120:chicken_2dinstall_2escm",(void*)f_5120},
{"f_7420:chicken_2dinstall_2escm",(void*)f_7420},
{"f_4393:chicken_2dinstall_2escm",(void*)f_4393},
{"f_4395:chicken_2dinstall_2escm",(void*)f_4395},
{"f_3574:chicken_2dinstall_2escm",(void*)f_3574},
{"f_3560:chicken_2dinstall_2escm",(void*)f_3560},
{"f_3566:chicken_2dinstall_2escm",(void*)f_3566},
{"f_5911:chicken_2dinstall_2escm",(void*)f_5911},
{"f_3883:chicken_2dinstall_2escm",(void*)f_3883},
{"f_7408:chicken_2dinstall_2escm",(void*)f_7408},
{"f_7402:chicken_2dinstall_2escm",(void*)f_7402},
{"f_7400:chicken_2dinstall_2escm",(void*)f_7400},
{"f_3595:chicken_2dinstall_2escm",(void*)f_3595},
{"f_4065:chicken_2dinstall_2escm",(void*)f_4065},
{"f_6893:chicken_2dinstall_2escm",(void*)f_6893},
{"f_3877:chicken_2dinstall_2escm",(void*)f_3877},
{"f_3873:chicken_2dinstall_2escm",(void*)f_3873},
{"f_3589:chicken_2dinstall_2escm",(void*)f_3589},
{"f_3652:chicken_2dinstall_2escm",(void*)f_3652},
{"f_3866:chicken_2dinstall_2escm",(void*)f_3866},
{"f_5156:chicken_2dinstall_2escm",(void*)f_5156},
{"f_3779:chicken_2dinstall_2escm",(void*)f_3779},
{"f_3852:chicken_2dinstall_2escm",(void*)f_3852},
{"f_3647:chicken_2dinstall_2escm",(void*)f_3647},
{"f_3644:chicken_2dinstall_2escm",(void*)f_3644},
{"f_3769:chicken_2dinstall_2escm",(void*)f_3769},
{"f_5145:chicken_2dinstall_2escm",(void*)f_5145},
{"f_3765:chicken_2dinstall_2escm",(void*)f_3765},
{"f_4032:chicken_2dinstall_2escm",(void*)f_4032},
{"f_3631:chicken_2dinstall_2escm",(void*)f_3631},
{"f_3791:chicken_2dinstall_2escm",(void*)f_3791},
{"f_3797:chicken_2dinstall_2escm",(void*)f_3797},
{"f_3794:chicken_2dinstall_2escm",(void*)f_3794},
{"f_4022:chicken_2dinstall_2escm",(void*)f_4022},
{"f_3788:chicken_2dinstall_2escm",(void*)f_3788},
{"f_3785:chicken_2dinstall_2escm",(void*)f_3785},
{"f_3690:chicken_2dinstall_2escm",(void*)f_3690},
{"f_3890:chicken_2dinstall_2escm",(void*)f_3890},
{"f_3896:chicken_2dinstall_2escm",(void*)f_3896},
{"f_3899:chicken_2dinstall_2escm",(void*)f_3899},
{"f_3727:chicken_2dinstall_2escm",(void*)f_3727},
{"f_3721:chicken_2dinstall_2escm",(void*)f_3721},
{"f_3676:chicken_2dinstall_2escm",(void*)f_3676},
{"f_5597:chicken_2dinstall_2escm",(void*)f_5597},
{"f_5599:chicken_2dinstall_2escm",(void*)f_5599},
{"f_3757:chicken_2dinstall_2escm",(void*)f_3757},
{"f_3755:chicken_2dinstall_2escm",(void*)f_3755},
{"f_6188:chicken_2dinstall_2escm",(void*)f_6188},
{"f_6818:chicken_2dinstall_2escm",(void*)f_6818},
{"f_3747:chicken_2dinstall_2escm",(void*)f_3747},
{"f_6804:chicken_2dinstall_2escm",(void*)f_6804},
{"f_3005:chicken_2dinstall_2escm",(void*)f_3005},
{"f_6686:chicken_2dinstall_2escm",(void*)f_6686},
{"f_6152:chicken_2dinstall_2escm",(void*)f_6152},
{"f_5399:chicken_2dinstall_2escm",(void*)f_5399},
{"f_3706:chicken_2dinstall_2escm",(void*)f_3706},
{"toplevel:chicken_2dinstall_2escm",(void*)C_toplevel},
{"f_6679:chicken_2dinstall_2escm",(void*)f_6679},
{"f_6135:chicken_2dinstall_2escm",(void*)f_6135},
{"f_6138:chicken_2dinstall_2escm",(void*)f_6138},
{"f_6131:chicken_2dinstall_2escm",(void*)f_6131},
{"f_4486:chicken_2dinstall_2escm",(void*)f_4486},
{"f_4473:chicken_2dinstall_2escm",(void*)f_4473},
{"f_6119:chicken_2dinstall_2escm",(void*)f_6119},
{"f_6644:chicken_2dinstall_2escm",(void*)f_6644},
{"f_6648:chicken_2dinstall_2escm",(void*)f_6648},
{"f_6111:chicken_2dinstall_2escm",(void*)f_6111},
{"f_3021:chicken_2dinstall_2escm",(void*)f_3021},
{"f_6107:chicken_2dinstall_2escm",(void*)f_6107},
{"f_6637:chicken_2dinstall_2escm",(void*)f_6637},
{"f_6103:chicken_2dinstall_2escm",(void*)f_6103},
{"f_3015:chicken_2dinstall_2escm",(void*)f_3015},
{"f_6621:chicken_2dinstall_2escm",(void*)f_6621},
{"f_6628:chicken_2dinstall_2escm",(void*)f_6628},
{"f_3083:chicken_2dinstall_2escm",(void*)f_3083},
{"f_4441:chicken_2dinstall_2escm",(void*)f_4441},
{"f_4463:chicken_2dinstall_2escm",(void*)f_4463},
{"f_5724:chicken_2dinstall_2escm",(void*)f_5724},
{"f_6559:chicken_2dinstall_2escm",(void*)f_6559},
{"f_5716:chicken_2dinstall_2escm",(void*)f_5716},
{"f_5710:chicken_2dinstall_2escm",(void*)f_5710},
{"f_6588:chicken_2dinstall_2escm",(void*)f_6588},
{"f_7291:chicken_2dinstall_2escm",(void*)f_7291},
{"f_5704:chicken_2dinstall_2escm",(void*)f_5704},
{"f_3228:chicken_2dinstall_2escm",(void*)f_3228},
{"f_3212:chicken_2dinstall_2escm",(void*)f_3212},
{"f_3215:chicken_2dinstall_2escm",(void*)f_3215},
{"f_5191:chicken_2dinstall_2escm",(void*)f_5191},
{"f_3513:chicken_2dinstall_2escm",(void*)f_3513},
{"f_4424:chicken_2dinstall_2escm",(void*)f_4424},
{"f_3516:chicken_2dinstall_2escm",(void*)f_3516},
{"f_7271:chicken_2dinstall_2escm",(void*)f_7271},
{"f_3519:chicken_2dinstall_2escm",(void*)f_3519},
{"f_7275:chicken_2dinstall_2escm",(void*)f_7275},
{"f_5765:chicken_2dinstall_2escm",(void*)f_5765},
{"f_5763:chicken_2dinstall_2escm",(void*)f_5763},
{"f_3501:chicken_2dinstall_2escm",(void*)f_3501},
{"f_5180:chicken_2dinstall_2escm",(void*)f_5180},
{"f_3504:chicken_2dinstall_2escm",(void*)f_3504},
{"f_7245:chicken_2dinstall_2escm",(void*)f_7245},
{"f_6179:chicken_2dinstall_2escm",(void*)f_6179},
{"f_5759:chicken_2dinstall_2escm",(void*)f_5759},
{"f_7060:chicken_2dinstall_2escm",(void*)f_7060},
{"f_7251:chicken_2dinstall_2escm",(void*)f_7251},
{"f_6175:chicken_2dinstall_2escm",(void*)f_6175},
{"f_6168:chicken_2dinstall_2escm",(void*)f_6168},
{"f_5747:chicken_2dinstall_2escm",(void*)f_5747},
{"f_7255:chicken_2dinstall_2escm",(void*)f_7255},
{"f_5741:chicken_2dinstall_2escm",(void*)f_5741},
{"f_6162:chicken_2dinstall_2escm",(void*)f_6162},
{"f_7225:chicken_2dinstall_2escm",(void*)f_7225},
{"f_7229:chicken_2dinstall_2escm",(void*)f_7229},
{"f_5736:chicken_2dinstall_2escm",(void*)f_5736},
{"f_2318:chicken_2dinstall_2escm",(void*)f_2318},
{"f_5739:chicken_2dinstall_2escm",(void*)f_5739},
{"f_3257:chicken_2dinstall_2escm",(void*)f_3257},
{"f_5733:chicken_2dinstall_2escm",(void*)f_5733},
{"f_5730:chicken_2dinstall_2escm",(void*)f_5730},
{"f_7232:chicken_2dinstall_2escm",(void*)f_7232},
{"f_2373:chicken_2dinstall_2escm",(void*)f_2373},
{"f_7238:chicken_2dinstall_2escm",(void*)f_7238},
{"f_6529:chicken_2dinstall_2escm",(void*)f_6529},
{"f_3622:chicken_2dinstall_2escm",(void*)f_3622},
{"f_3626:chicken_2dinstall_2escm",(void*)f_3626},
{"f_7208:chicken_2dinstall_2escm",(void*)f_7208},
{"f_2346:chicken_2dinstall_2escm",(void*)f_2346},
{"f_2343:chicken_2dinstall_2escm",(void*)f_2343},
{"f_2340:chicken_2dinstall_2escm",(void*)f_2340},
{"f_3610:chicken_2dinstall_2escm",(void*)f_3610},
{"f_5790:chicken_2dinstall_2escm",(void*)f_5790},
{"f_4785:chicken_2dinstall_2escm",(void*)f_4785},
{"f_3601:chicken_2dinstall_2escm",(void*)f_3601},
{"f_5780:chicken_2dinstall_2escm",(void*)f_5780},
{"f_3605:chicken_2dinstall_2escm",(void*)f_3605},
{"f_3295:chicken_2dinstall_2escm",(void*)f_3295},
{"f_3291:chicken_2dinstall_2escm",(void*)f_3291},
{"f_5477:chicken_2dinstall_2escm",(void*)f_5477},
{"f_5474:chicken_2dinstall_2escm",(void*)f_5474},
{"f_5771:chicken_2dinstall_2escm",(void*)f_5771},
{"f_5471:chicken_2dinstall_2escm",(void*)f_5471},
{"f_6373:chicken_2dinstall_2escm",(void*)f_6373},
{"f_6376:chicken_2dinstall_2escm",(void*)f_6376},
{"f_6370:chicken_2dinstall_2escm",(void*)f_6370},
{"f_5468:chicken_2dinstall_2escm",(void*)f_5468},
{"f_5465:chicken_2dinstall_2escm",(void*)f_5465},
{"f_5462:chicken_2dinstall_2escm",(void*)f_5462},
{"f_3276:chicken_2dinstall_2escm",(void*)f_3276},
{"f_6364:chicken_2dinstall_2escm",(void*)f_6364},
{"f_3272:chicken_2dinstall_2escm",(void*)f_3272},
{"f_5499:chicken_2dinstall_2escm",(void*)f_5499},
{"f_6379:chicken_2dinstall_2escm",(void*)f_6379},
{"f_5493:chicken_2dinstall_2escm",(void*)f_5493},
{"f_5491:chicken_2dinstall_2escm",(void*)f_5491},
{"f_4746:chicken_2dinstall_2escm",(void*)f_4746},
{"f_4740:chicken_2dinstall_2escm",(void*)f_4740},
{"f_6350:chicken_2dinstall_2escm",(void*)f_6350},
{"f_5487:chicken_2dinstall_2escm",(void*)f_5487},
{"f_5480:chicken_2dinstall_2escm",(void*)f_5480},
{"f_4776:chicken_2dinstall_2escm",(void*)f_4776},
{"f_4773:chicken_2dinstall_2escm",(void*)f_4773},
{"f_4779:chicken_2dinstall_2escm",(void*)f_4779},
{"f_2398:chicken_2dinstall_2escm",(void*)f_2398},
{"f_5438:chicken_2dinstall_2escm",(void*)f_5438},
{"f_5431:chicken_2dinstall_2escm",(void*)f_5431},
{"f_4767:chicken_2dinstall_2escm",(void*)f_4767},
{"f_4797:chicken_2dinstall_2escm",(void*)f_4797},
{"f_3051:chicken_2dinstall_2escm",(void*)f_3051},
{"f_4791:chicken_2dinstall_2escm",(void*)f_4791},
{"f_4794:chicken_2dinstall_2escm",(void*)f_4794},
{"f_6321:chicken_2dinstall_2escm",(void*)f_6321},
{"f_2864:chicken_2dinstall_2escm",(void*)f_2864},
{"f_2862:chicken_2dinstall_2escm",(void*)f_2862},
{"f_5459:chicken_2dinstall_2escm",(void*)f_5459},
{"f_5456:chicken_2dinstall_2escm",(void*)f_5456},
{"f_5453:chicken_2dinstall_2escm",(void*)f_5453},
{"f_5450:chicken_2dinstall_2escm",(void*)f_5450},
{"f_6312:chicken_2dinstall_2escm",(void*)f_6312},
{"f_4736:chicken_2dinstall_2escm",(void*)f_4736},
{"f_4999:chicken_2dinstall_2escm",(void*)f_4999},
{"f_4991:chicken_2dinstall_2escm",(void*)f_4991},
{"f_2294:chicken_2dinstall_2escm",(void*)f_2294},
{"f_2291:chicken_2dinstall_2escm",(void*)f_2291},
{"f_6319:chicken_2dinstall_2escm",(void*)f_6319},
{"f_4993:chicken_2dinstall_2escm",(void*)f_4993},
{"f_4720:chicken_2dinstall_2escm",(void*)f_4720},
{"f_2297:chicken_2dinstall_2escm",(void*)f_2297},
{"f_4724:chicken_2dinstall_2escm",(void*)f_4724},
{"f_4728:chicken_2dinstall_2escm",(void*)f_4728},
{"f_4988:chicken_2dinstall_2escm",(void*)f_4988},
{"f_4981:chicken_2dinstall_2escm",(void*)f_4981},
{"f_4985:chicken_2dinstall_2escm",(void*)f_4985},
{"f_6306:chicken_2dinstall_2escm",(void*)f_6306},
{"f_4755:chicken_2dinstall_2escm",(void*)f_4755},
{"f_4752:chicken_2dinstall_2escm",(void*)f_4752},
{"f_4758:chicken_2dinstall_2escm",(void*)f_4758},
{"f_5414:chicken_2dinstall_2escm",(void*)f_5414},
{"f_2828:chicken_2dinstall_2escm",(void*)f_2828},
{"f_5418:chicken_2dinstall_2escm",(void*)f_5418},
{"f_4253:chicken_2dinstall_2escm",(void*)f_4253},
{"f_2833:chicken_2dinstall_2escm",(void*)f_2833},
{"f_4250:chicken_2dinstall_2escm",(void*)f_4250},
{"f_4258:chicken_2dinstall_2escm",(void*)f_4258},
{"f_5405:chicken_2dinstall_2escm",(void*)f_5405},
{"f_5402:chicken_2dinstall_2escm",(void*)f_5402},
{"f_2843:chicken_2dinstall_2escm",(void*)f_2843},
{"f_5253:chicken_2dinstall_2escm",(void*)f_5253},
{"f_5255:chicken_2dinstall_2escm",(void*)f_5255},
{"f_4273:chicken_2dinstall_2escm",(void*)f_4273},
{"f_2459:chicken_2dinstall_2escm",(void*)f_2459},
{"f_4944:chicken_2dinstall_2escm",(void*)f_4944},
{"f_3244:chicken_2dinstall_2escm",(void*)f_3244},
{"f_2858:chicken_2dinstall_2escm",(void*)f_2858},
{"f_4949:chicken_2dinstall_2escm",(void*)f_4949},
{"f_4948:chicken_2dinstall_2escm",(void*)f_4948},
{"f_5289:chicken_2dinstall_2escm",(void*)f_5289},
{"f_4710:chicken_2dinstall_2escm",(void*)f_4710},
{"f_4713:chicken_2dinstall_2escm",(void*)f_4713},
{"f_4717:chicken_2dinstall_2escm",(void*)f_4717},
{"f_2461:chicken_2dinstall_2escm",(void*)f_2461},
{"f_5220:chicken_2dinstall_2escm",(void*)f_5220},
{"f_2468:chicken_2dinstall_2escm",(void*)f_2468},
{"f_4268:chicken_2dinstall_2escm",(void*)f_4268},
{"f_4975:chicken_2dinstall_2escm",(void*)f_4975},
{"f_5279:chicken_2dinstall_2escm",(void*)f_5279},
{"f_5274:chicken_2dinstall_2escm",(void*)f_5274},
{"f_2475:chicken_2dinstall_2escm",(void*)f_2475},
{"f_4217:chicken_2dinstall_2escm",(void*)f_4217},
{"f_2479:chicken_2dinstall_2escm",(void*)f_2479},
{"f_4964:chicken_2dinstall_2escm",(void*)f_4964},
{"f_4960:chicken_2dinstall_2escm",(void*)f_4960},
{"f_4969:chicken_2dinstall_2escm",(void*)f_4969},
{"f_2288:chicken_2dinstall_2escm",(void*)f_2288},
{"f_2402:chicken_2dinstall_2escm",(void*)f_2402},
{"f_4286:chicken_2dinstall_2escm",(void*)f_4286},
{"f_2408:chicken_2dinstall_2escm",(void*)f_2408},
{"f_4280:chicken_2dinstall_2escm",(void*)f_4280},
{"f_4913:chicken_2dinstall_2escm",(void*)f_4913},
{"f_4289:chicken_2dinstall_2escm",(void*)f_4289},
{"f_4919:chicken_2dinstall_2escm",(void*)f_4919},
{"f_5613:chicken_2dinstall_2escm",(void*)f_5613},
{"f_5214:chicken_2dinstall_2escm",(void*)f_5214},
{"f_5217:chicken_2dinstall_2escm",(void*)f_5217},
{"f_2411:chicken_2dinstall_2escm",(void*)f_2411},
{"f_2414:chicken_2dinstall_2escm",(void*)f_2414},
{"f_5230:chicken_2dinstall_2escm",(void*)f_5230},
{"f_4235:chicken_2dinstall_2escm",(void*)f_4235},
{"f_4901:chicken_2dinstall_2escm",(void*)f_4901},
{"f_4900:chicken_2dinstall_2escm",(void*)f_4900},
{"f_4905:chicken_2dinstall_2escm",(void*)f_4905},
{"f_4908:chicken_2dinstall_2escm",(void*)f_4908},
{"f_4930:chicken_2dinstall_2escm",(void*)f_4930},
{"f_4931:chicken_2dinstall_2escm",(void*)f_4931},
{"f_4938:chicken_2dinstall_2escm",(void*)f_4938},
{"f_6592:chicken_2dinstall_2escm",(void*)f_6592},
{"f_5234:chicken_2dinstall_2escm",(void*)f_5234},
{"f_5238:chicken_2dinstall_2escm",(void*)f_5238},
{"f_4923:chicken_2dinstall_2escm",(void*)f_4923},
{"f_4926:chicken_2dinstall_2escm",(void*)f_4926},
{"f_4247:chicken_2dinstall_2escm",(void*)f_4247},
{"f_4241:chicken_2dinstall_2escm",(void*)f_4241},
{"f_4244:chicken_2dinstall_2escm",(void*)f_4244},
{"f_5011:chicken_2dinstall_2escm",(void*)f_5011},
{"f_5005:chicken_2dinstall_2escm",(void*)f_5005},
{"f_5895:chicken_2dinstall_2escm",(void*)f_5895},
{"f_5891:chicken_2dinstall_2escm",(void*)f_5891},
{"f_5882:chicken_2dinstall_2escm",(void*)f_5882},
{"f_5889:chicken_2dinstall_2escm",(void*)f_5889},
{"f_2321:chicken_2dinstall_2escm",(void*)f_2321},
{"f_2324:chicken_2dinstall_2escm",(void*)f_2324},
{"f_2327:chicken_2dinstall_2escm",(void*)f_2327},
{"f_4207:chicken_2dinstall_2escm",(void*)f_4207},
{"f_2330:chicken_2dinstall_2escm",(void*)f_2330},
{"f_2333:chicken_2dinstall_2escm",(void*)f_2333},
{"f_3908:chicken_2dinstall_2escm",(void*)f_3908},
{"f_5853:chicken_2dinstall_2escm",(void*)f_5853},
{"f_3905:chicken_2dinstall_2escm",(void*)f_3905},
{"f_3902:chicken_2dinstall_2escm",(void*)f_3902},
{"f_4098:chicken_2dinstall_2escm",(void*)f_4098},
{"f_2303:chicken_2dinstall_2escm",(void*)f_2303},
{"f_2300:chicken_2dinstall_2escm",(void*)f_2300},
{"f_2306:chicken_2dinstall_2escm",(void*)f_2306},
{"f_5077:chicken_2dinstall_2escm",(void*)f_5077},
{"f_4080:chicken_2dinstall_2escm",(void*)f_4080},
{"f_4083:chicken_2dinstall_2escm",(void*)f_4083},
{"f_5071:chicken_2dinstall_2escm",(void*)f_5071},
{"f_4088:chicken_2dinstall_2escm",(void*)f_4088},
{"f_2312:chicken_2dinstall_2escm",(void*)f_2312},
{"f_2315:chicken_2dinstall_2escm",(void*)f_2315},
{"f_2309:chicken_2dinstall_2escm",(void*)f_2309},
{"f_5066:chicken_2dinstall_2escm",(void*)f_5066},
{"f_5069:chicken_2dinstall_2escm",(void*)f_5069},
{"f_5879:chicken_2dinstall_2escm",(void*)f_5879},
{"f_5873:chicken_2dinstall_2escm",(void*)f_5873},
{"f_5876:chicken_2dinstall_2escm",(void*)f_5876},
{"f_5063:chicken_2dinstall_2escm",(void*)f_5063},
{"f_5869:chicken_2dinstall_2escm",(void*)f_5869},
{"f_3914:chicken_2dinstall_2escm",(void*)f_3914},
{"f_3917:chicken_2dinstall_2escm",(void*)f_3917},
{"f_3911:chicken_2dinstall_2escm",(void*)f_3911},
{"f_5816:chicken_2dinstall_2escm",(void*)f_5816},
{"f_5814:chicken_2dinstall_2escm",(void*)f_5814},
{"f_5819:chicken_2dinstall_2escm",(void*)f_5819},
{"f_5810:chicken_2dinstall_2escm",(void*)f_5810},
{"f_6092:chicken_2dinstall_2escm",(void*)f_6092},
{"f_6099:chicken_2dinstall_2escm",(void*)f_6099},
{"f_5036:chicken_2dinstall_2escm",(void*)f_5036},
{"f_5030:chicken_2dinstall_2escm",(void*)f_5030},
{"f_5803:chicken_2dinstall_2escm",(void*)f_5803},
{"f_6082:chicken_2dinstall_2escm",(void*)f_6082},
{"f_6392:chicken_2dinstall_2escm",(void*)f_6392},
{"f_6088:chicken_2dinstall_2escm",(void*)f_6088},
{"f_5833:chicken_2dinstall_2escm",(void*)f_5833},
{"f_5692:chicken_2dinstall_2escm",(void*)f_5692},
{"f_5696:chicken_2dinstall_2escm",(void*)f_5696},
{"f_5699:chicken_2dinstall_2escm",(void*)f_5699},
{"f_5059:chicken_2dinstall_2escm",(void*)f_5059},
{"f_5053:chicken_2dinstall_2escm",(void*)f_5053},
{"f_5685:chicken_2dinstall_2escm",(void*)f_5685},
{"f_5047:chicken_2dinstall_2escm",(void*)f_5047},
{"f_5042:chicken_2dinstall_2escm",(void*)f_5042},
{"f_3980:chicken_2dinstall_2escm",(void*)f_3980},
{"f_3988:chicken_2dinstall_2escm",(void*)f_3988},
{"f_3983:chicken_2dinstall_2escm",(void*)f_3983},
{"f_3984:chicken_2dinstall_2escm",(void*)f_3984},
{"f_6053:chicken_2dinstall_2escm",(void*)f_6053},
{"f_2422:chicken_2dinstall_2escm",(void*)f_2422},
{"f_6051:chicken_2dinstall_2escm",(void*)f_6051},
{"f_3971:chicken_2dinstall_2escm",(void*)f_3971},
{"f_6038:chicken_2dinstall_2escm",(void*)f_6038},
{"f_3991:chicken_2dinstall_2escm",(void*)f_3991},
{"f_3997:chicken_2dinstall_2escm",(void*)f_3997},
{"f_6024:chicken_2dinstall_2escm",(void*)f_6024},
{"f_6020:chicken_2dinstall_2escm",(void*)f_6020},
{"f_5690:chicken_2dinstall_2escm",(void*)f_5690},
{"f_3462:chicken_2dinstall_2escm",(void*)f_3462},
{"f_3467:chicken_2dinstall_2escm",(void*)f_3467},
{"f_4292:chicken_2dinstall_2escm",(void*)f_4292},
{"f_4297:chicken_2dinstall_2escm",(void*)f_4297},
{"f_6007:chicken_2dinstall_2escm",(void*)f_6007},
{"f_3968:chicken_2dinstall_2escm",(void*)f_3968},
{"f_3964:chicken_2dinstall_2escm",(void*)f_3964},
{"f_7182:chicken_2dinstall_2escm",(void*)f_7182},
{"f_5615:chicken_2dinstall_2escm",(void*)f_5615},
{"f_7190:chicken_2dinstall_2escm",(void*)f_7190},
{"f_3479:chicken_2dinstall_2escm",(void*)f_3479},
{"f_3473:chicken_2dinstall_2escm",(void*)f_3473},
{"f_5650:chicken_2dinstall_2escm",(void*)f_5650},
{"f_4891:chicken_2dinstall_2escm",(void*)f_4891},
{"f_4894:chicken_2dinstall_2escm",(void*)f_4894},
{"f_3116:chicken_2dinstall_2escm",(void*)f_3116},
{"f_4888:chicken_2dinstall_2escm",(void*)f_4888},
{"f_3456:chicken_2dinstall_2escm",(void*)f_3456},
{"f_4880:chicken_2dinstall_2escm",(void*)f_4880},
{"f_4881:chicken_2dinstall_2escm",(void*)f_4881},
{"f_7144:chicken_2dinstall_2escm",(void*)f_7144},
{"f_4885:chicken_2dinstall_2escm",(void*)f_4885},
{"f_7140:chicken_2dinstall_2escm",(void*)f_7140},
{"f_6475:chicken_2dinstall_2escm",(void*)f_6475},
{"f_7371:chicken_2dinstall_2escm",(void*)f_7371},
{"f_7374:chicken_2dinstall_2escm",(void*)f_7374},
{"f_3489:chicken_2dinstall_2escm",(void*)f_3489},
{"f_7389:chicken_2dinstall_2escm",(void*)f_7389},
{"f_7383:chicken_2dinstall_2escm",(void*)f_7383},
{"f_7128:chicken_2dinstall_2escm",(void*)f_7128},
{"f_7121:chicken_2dinstall_2escm",(void*)f_7121},
{"f_6450:chicken_2dinstall_2escm",(void*)f_6450},
{"f_7352:chicken_2dinstall_2escm",(void*)f_7352},
{"f_6457:chicken_2dinstall_2escm",(void*)f_6457},
{"f_7350:chicken_2dinstall_2escm",(void*)f_7350},
{"f_7358:chicken_2dinstall_2escm",(void*)f_7358},
{"f_4853:chicken_2dinstall_2escm",(void*)f_4853},
{"f_4850:chicken_2dinstall_2escm",(void*)f_4850},
{"f_4859:chicken_2dinstall_2escm",(void*)f_4859},
{"f_3153:chicken_2dinstall_2escm",(void*)f_3153},
{"f_7368:chicken_2dinstall_2escm",(void*)f_7368},
{"f_7364:chicken_2dinstall_2escm",(void*)f_7364},
{"f_3492:chicken_2dinstall_2escm",(void*)f_3492},
{"f_7106:chicken_2dinstall_2escm",(void*)f_7106},
{"f_3100:chicken_2dinstall_2escm",(void*)f_3100},
{"f_7335:chicken_2dinstall_2escm",(void*)f_7335},
{"f_7338:chicken_2dinstall_2escm",(void*)f_7338},
{"f_4874:chicken_2dinstall_2escm",(void*)f_4874},
{"f_7115:chicken_2dinstall_2escm",(void*)f_7115},
{"f_4871:chicken_2dinstall_2escm",(void*)f_4871},
{"f_4877:chicken_2dinstall_2escm",(void*)f_4877},
{"f_6421:chicken_2dinstall_2escm",(void*)f_6421},
{"f_7344:chicken_2dinstall_2escm",(void*)f_7344},
{"f_7347:chicken_2dinstall_2escm",(void*)f_7347},
{"f_7341:chicken_2dinstall_2escm",(void*)f_7341},
{"f_4496:chicken_2dinstall_2escm",(void*)f_4496},
{"f_4868:chicken_2dinstall_2escm",(void*)f_4868},
{"f_6412:chicken_2dinstall_2escm",(void*)f_6412},
{"f_3122:chicken_2dinstall_2escm",(void*)f_3122},
{"f_6419:chicken_2dinstall_2escm",(void*)f_6419},
{"f_4813:chicken_2dinstall_2escm",(void*)f_4813},
{"f_4816:chicken_2dinstall_2escm",(void*)f_4816},
{"f_4819:chicken_2dinstall_2escm",(void*)f_4819},
{"f_6486:chicken_2dinstall_2escm",(void*)f_6486},
{"f_4807:chicken_2dinstall_2escm",(void*)f_4807},
{"f_4804:chicken_2dinstall_2escm",(void*)f_4804},
{"f_4835:chicken_2dinstall_2escm",(void*)f_4835},
{"f_4826:chicken_2dinstall_2escm",(void*)f_4826},
{"f_3359:chicken_2dinstall_2escm",(void*)f_3359},
{"f_3358:chicken_2dinstall_2escm",(void*)f_3358},
{"f_5089:chicken_2dinstall_2escm",(void*)f_5089},
{"f_5083:chicken_2dinstall_2escm",(void*)f_5083},
{"f_3184:chicken_2dinstall_2escm",(void*)f_3184},
{"f_3370:chicken_2dinstall_2escm",(void*)f_3370},
{"f_6252:chicken_2dinstall_2escm",(void*)f_6252},
{"f_3375:chicken_2dinstall_2escm",(void*)f_3375},
{"f_2709:chicken_2dinstall_2escm",(void*)f_2709},
{"f_6285:chicken_2dinstall_2escm",(void*)f_6285},
{"f_6281:chicken_2dinstall_2escm",(void*)f_6281},
{"f_3364:chicken_2dinstall_2escm",(void*)f_3364},
{"f_6288:chicken_2dinstall_2escm",(void*)f_6288},
{"f_6949:chicken_2dinstall_2escm",(void*)f_6949},
{"f_6945:chicken_2dinstall_2escm",(void*)f_6945},
{"f_6402:chicken_2dinstall_2escm",(void*)f_6402},
{"f7920:chicken_2dinstall_2escm",(void*)f7920},
{"f7925:chicken_2dinstall_2escm",(void*)f7925},
{"f_6262:chicken_2dinstall_2escm",(void*)f_6262},
{"f_2740:chicken_2dinstall_2escm",(void*)f_2740},
{"f_3309:chicken_2dinstall_2escm",(void*)f_3309},
{"f_2650:chicken_2dinstall_2escm",(void*)f_2650},
{"f_6210:chicken_2dinstall_2escm",(void*)f_6210},
{"f_6215:chicken_2dinstall_2escm",(void*)f_6215},
{"f_2711:chicken_2dinstall_2escm",(void*)f_2711},
{"f_6919:chicken_2dinstall_2escm",(void*)f_6919},
{"f_2621:chicken_2dinstall_2escm",(void*)f_2621},
{"f_6246:chicken_2dinstall_2escm",(void*)f_6246},
{"f_6249:chicken_2dinstall_2escm",(void*)f_6249},
{"f_2673:chicken_2dinstall_2escm",(void*)f_2673},
{"f_6784:chicken_2dinstall_2escm",(void*)f_6784},
{"f_2559:chicken_2dinstall_2escm",(void*)f_2559},
{"f_2754:chicken_2dinstall_2escm",(void*)f_2754},
{"f_2787:chicken_2dinstall_2escm",(void*)f_2787},
{"f_2666:chicken_2dinstall_2escm",(void*)f_2666},
{"f_2664:chicken_2dinstall_2escm",(void*)f_2664},
{"f_6207:chicken_2dinstall_2escm",(void*)f_6207},
{"f_2757:chicken_2dinstall_2escm",(void*)f_2757},
{"f_3393:chicken_2dinstall_2escm",(void*)f_3393},
{"f_3428:chicken_2dinstall_2escm",(void*)f_3428},
{"f_2531:chicken_2dinstall_2escm",(void*)f_2531},
{"f_6740:chicken_2dinstall_2escm",(void*)f_6740},
{"f_3389:chicken_2dinstall_2escm",(void*)f_3389},
{"f_6070:chicken_2dinstall_2escm",(void*)f_6070},
{"f7994:chicken_2dinstall_2escm",(void*)f7994},
{"f_3402:chicken_2dinstall_2escm",(void*)f_3402},
{"f_3408:chicken_2dinstall_2escm",(void*)f_3408},
{"f_2595:chicken_2dinstall_2escm",(void*)f_2595},
{"f_2795:chicken_2dinstall_2escm",(void*)f_2795},
{"f_3131:chicken_2dinstall_2escm",(void*)f_3131},
{"f7982:chicken_2dinstall_2escm",(void*)f7982},
{"f7989:chicken_2dinstall_2escm",(void*)f7989},
{"f_3438:chicken_2dinstall_2escm",(void*)f_3438},
{"f_2577:chicken_2dinstall_2escm",(void*)f_2577},
{"f_2930:chicken_2dinstall_2escm",(void*)f_2930},
{"f_3163:chicken_2dinstall_2escm",(void*)f_3163},
{"f_2932:chicken_2dinstall_2escm",(void*)f_2932},
{"f7972:chicken_2dinstall_2escm",(void*)f7972},
{"f_6711:chicken_2dinstall_2escm",(void*)f_6711},
{"f7977:chicken_2dinstall_2escm",(void*)f7977},
{"f_6714:chicken_2dinstall_2escm",(void*)f_6714},
{"f_2575:chicken_2dinstall_2escm",(void*)f_2575},
{"f_2589:chicken_2dinstall_2escm",(void*)f_2589},
{"f7962:chicken_2dinstall_2escm",(void*)f7962},
{"f7967:chicken_2dinstall_2escm",(void*)f7967},
{"f_4170:chicken_2dinstall_2escm",(void*)f_4170},
{"f_4176:chicken_2dinstall_2escm",(void*)f_4176},
{"f_2581:chicken_2dinstall_2escm",(void*)f_2581},
{"f_2584:chicken_2dinstall_2escm",(void*)f_2584},
{"f_2910:chicken_2dinstall_2escm",(void*)f_2910},
{"f_2913:chicken_2dinstall_2escm",(void*)f_2913},
{"f7952:chicken_2dinstall_2escm",(void*)f7952},
{"f_4690:chicken_2dinstall_2escm",(void*)f_4690},
{"f7957:chicken_2dinstall_2escm",(void*)f7957},
{"f_6770:chicken_2dinstall_2escm",(void*)f_6770},
{"f_4165:chicken_2dinstall_2escm",(void*)f_4165},
{"f_4687:chicken_2dinstall_2escm",(void*)f_4687},
{"f_2920:chicken_2dinstall_2escm",(void*)f_2920},
{"f7942:chicken_2dinstall_2escm",(void*)f7942},
{"f_4681:chicken_2dinstall_2escm",(void*)f_4681},
{"f7947:chicken_2dinstall_2escm",(void*)f7947},
{"f_4684:chicken_2dinstall_2escm",(void*)f_4684},
{"f7930:chicken_2dinstall_2escm",(void*)f7930},
{"f_2974:chicken_2dinstall_2escm",(void*)f_2974},
{"f_2970:chicken_2dinstall_2escm",(void*)f_2970},
{"f7935:chicken_2dinstall_2escm",(void*)f7935},
{"f_5577:chicken_2dinstall_2escm",(void*)f_5577},
{"f_5571:chicken_2dinstall_2escm",(void*)f_5571},
{"f_2982:chicken_2dinstall_2escm",(void*)f_2982},
{"f_2957:chicken_2dinstall_2escm",(void*)f_2957},
{"f_2958:chicken_2dinstall_2escm",(void*)f_2958},
{"f_4138:chicken_2dinstall_2escm",(void*)f_4138},
{"f_4134:chicken_2dinstall_2escm",(void*)f_4134},
{"f_4366:chicken_2dinstall_2escm",(void*)f_4366},
{"f_6737:chicken_2dinstall_2escm",(void*)f_6737},
{"f_2951:chicken_2dinstall_2escm",(void*)f_2951},
{"f_5556:chicken_2dinstall_2escm",(void*)f_5556},
{"f_4353:chicken_2dinstall_2escm",(void*)f_4353},
{"f_4359:chicken_2dinstall_2escm",(void*)f_4359},
{"f_2966:chicken_2dinstall_2escm",(void*)f_2966},
{"f_4156:chicken_2dinstall_2escm",(void*)f_4156},
{"f_5583:chicken_2dinstall_2escm",(void*)f_5583},
{"f_4675:chicken_2dinstall_2escm",(void*)f_4675},
{"f_4387:chicken_2dinstall_2escm",(void*)f_4387},
{"f_4678:chicken_2dinstall_2escm",(void*)f_4678},
{"f_5532:chicken_2dinstall_2escm",(void*)f_5532},
{"f_5534:chicken_2dinstall_2escm",(void*)f_5534},
{"f_4661:chicken_2dinstall_2escm",(void*)f_4661},
{"f_4669:chicken_2dinstall_2escm",(void*)f_4669},
{"f_5566:chicken_2dinstall_2escm",(void*)f_5566},
{"f_5563:chicken_2dinstall_2escm",(void*)f_5563},
{"f_4321:chicken_2dinstall_2escm",(void*)f_4321},
{"f_2992:chicken_2dinstall_2escm",(void*)f_2992},
{"f_5517:chicken_2dinstall_2escm",(void*)f_5517},
{"f_4311:chicken_2dinstall_2escm",(void*)f_4311},
{"f_5542:chicken_2dinstall_2escm",(void*)f_5542},
{"f_5546:chicken_2dinstall_2escm",(void*)f_5546},
{"f_4349:chicken_2dinstall_2escm",(void*)f_4349},
{"f_4336:chicken_2dinstall_2escm",(void*)f_4336},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
o|hiding nonexported module bindings: main#+default-repository-files+ 
o|hiding nonexported module bindings: main#constant159 
o|hiding nonexported module bindings: main#constant163 
o|hiding nonexported module bindings: main#*program-path* 
o|hiding nonexported module bindings: main#*keep* 
o|hiding nonexported module bindings: main#*keep-existing* 
o|hiding nonexported module bindings: main#*force* 
o|hiding nonexported module bindings: main#*run-tests* 
o|hiding nonexported module bindings: main#*retrieve-only* 
o|hiding nonexported module bindings: main#*no-install* 
o|hiding nonexported module bindings: main#*username* 
o|hiding nonexported module bindings: main#*password* 
o|hiding nonexported module bindings: main#*default-sources* 
o|hiding nonexported module bindings: main#*default-location* 
o|hiding nonexported module bindings: main#*default-transport* 
o|hiding nonexported module bindings: main#*windows-shell* 
o|hiding nonexported module bindings: main#*proxy-host* 
o|hiding nonexported module bindings: main#*proxy-port* 
o|hiding nonexported module bindings: main#*proxy-user-pass* 
o|hiding nonexported module bindings: main#*running-test* 
o|hiding nonexported module bindings: main#*mappings* 
o|hiding nonexported module bindings: main#*deploy* 
o|hiding nonexported module bindings: main#*trunk* 
o|hiding nonexported module bindings: main#*csc-features* 
o|hiding nonexported module bindings: main#*csc-nonfeatures* 
o|hiding nonexported module bindings: main#*prefix* 
o|hiding nonexported module bindings: main#*aliases* 
o|hiding nonexported module bindings: main#*cross-chicken* 
o|hiding nonexported module bindings: main#*host-extension* 
o|hiding nonexported module bindings: main#*target-extension* 
o|hiding nonexported module bindings: main#*debug-setup* 
o|hiding nonexported module bindings: main#*keep-going* 
o|hiding nonexported module bindings: main#*override* 
o|hiding nonexported module bindings: main#*reinstall* 
o|hiding nonexported module bindings: main#*show-depends* 
o|hiding nonexported module bindings: main#*show-foreign-depends* 
o|hiding nonexported module bindings: main#*hacks* 
o|hiding nonexported module bindings: main#repo-path 
o|hiding nonexported module bindings: main#get-prefix 
o|hiding nonexported module bindings: main#load-defaults 
o|hiding nonexported module bindings: main#resolve-location 
o|hiding nonexported module bindings: main#known-default-sources 
o|hiding nonexported module bindings: main#deps 
o|hiding nonexported module bindings: main#init-repository 
o|hiding nonexported module bindings: main#ext-version 
o|hiding nonexported module bindings: main#meta-dependencies 
o|hiding nonexported module bindings: main#check-dependency 
o|hiding nonexported module bindings: main#outdated-dependencies 
o|hiding nonexported module bindings: main#*eggs+dirs+vers* 
o|hiding nonexported module bindings: main#*dependencies* 
o|hiding nonexported module bindings: main#*checked* 
o|hiding nonexported module bindings: main#*csi* 
o|hiding nonexported module bindings: main#try-extension 
o|hiding nonexported module bindings: main#with-default-sources 
o|hiding nonexported module bindings: main#try-default-sources 
o|hiding nonexported module bindings: main#make-replace-extension-question 
o|hiding nonexported module bindings: main#override-version 
o|hiding nonexported module bindings: main#show-depends 
o|hiding nonexported module bindings: main#retrieve 
o|hiding nonexported module bindings: main#check-platform 
o|hiding nonexported module bindings: main#make-install-command 
o|hiding nonexported module bindings: main#keep-going 
o|hiding nonexported module bindings: main#install 
o|hiding nonexported module bindings: main#delete-stale-binaries 
o|hiding nonexported module bindings: main#cleanup 
o|hiding nonexported module bindings: main#update-db 
o|hiding nonexported module bindings: main#apply-mappings 
o|hiding nonexported module bindings: main#scan-directory 
o|hiding nonexported module bindings: main#$system 
o|hiding nonexported module bindings: main#installed-extensions 
o|hiding nonexported module bindings: main#list-available-extensions 
o|hiding nonexported module bindings: main#command 
o|hiding nonexported module bindings: main#usage 
o|hiding nonexported module bindings: main#setup-proxy 
o|hiding nonexported module bindings: main#info->egg 
o|hiding nonexported module bindings: main#*short-options* 
o|hiding nonexported module bindings: main#main 
S|applied compiler syntax:
S|  fprintf		1
S|  printf		1
S|  map		10
S|  for-each		12
S|  sprintf		11
o|eliminated procedure checks: 130 
o|specializations:
o|  1 (> fixnum fixnum)
o|  1 (string-ref string fixnum)
o|  2 (string-length string)
o|  9 (cddr (pair * pair))
o|  1 (zero? fixnum)
o|  1 (string-append string string)
o|  5 (current-error-port)
o|  46 (string=? string string)
o|  24 (car pair)
o|  7 (##sys#check-list (or pair list) *)
o|  2 (= fixnum fixnum)
o|  48 (cdr pair)
o|  8 (eqv? * (not float))
o|  2 (positive? fixnum)
o|  4 (length list)
o|  13 (##sys#check-output-port * * *)
o|Removed `not' forms: 15 
o|merged explicitly consed rest parameter: tmp222223 
o|inlining procedure: k2427 
o|contracted procedure: k2442 
o|inlining procedure: k2427 
o|propagated global variable: r24287428 main#*prefix* 
o|inlining procedure: k2869 
o|contracted procedure: "(chicken-install.scm:181) g376377" 
o|inlining procedure: k2869 
o|inlining procedure: k2940 
o|inlining procedure: k2940 
o|inlining procedure: k3007 
o|inlining procedure: k3007 
o|contracted procedure: "(chicken-install.scm:215) g434435" 
o|inlining procedure: k3030 
o|inlining procedure: k3030 
o|inlining procedure: k3046 
o|inlining procedure: k3046 
o|inlining procedure: k3085 
o|inlining procedure: k3098 
o|inlining procedure: k3098 
o|contracted procedure: k3107 
o|inlining procedure: k3085 
o|inlining procedure: k3133 
o|inlining procedure: k3143 
o|inlining procedure: k3143 
o|inlining procedure: k3133 
o|inlining procedure: k3165 
o|inlining procedure: k3165 
o|inlining procedure: k3186 
o|inlining procedure: k3186 
o|inlining procedure: k3195 
o|inlining procedure: k3195 
o|contracted procedure: k3201 
o|inlining procedure: k3207 
o|contracted procedure: k3234 
o|inlining procedure: k3231 
o|inlining procedure: k3231 
o|substituted constant variable: a3240 
o|inlining procedure: k3245 
o|inlining procedure: k3245 
o|propagated global variable: tmp480482 main#*deploy* 
o|propagated global variable: tmp480482 main#*deploy* 
o|inlining procedure: k3207 
o|inlining procedure: k3316 
o|inlining procedure: k3316 
o|substituted constant variable: a3337 
o|inlining procedure: k3612 
o|inlining procedure: k3612 
o|inlining procedure: k3674 
o|inlining procedure: k3674 
o|inlining procedure: k3688 
o|inlining procedure: k3688 
o|contracted procedure: "(chicken-install.scm:339) main#known-default-sources" 
o|inlining procedure: k2886 
o|inlining procedure: k2908 
o|inlining procedure: k2908 
o|propagated global variable: r29097480 main#*default-location* 
o|inlining procedure: k2886 
o|propagated global variable: r28877482 main#*default-sources* 
o|merged explicitly consed rest parameter: type671 
o|propagated global variable: out677681 ##sys#standard-output 
o|substituted constant variable: a3976 
o|substituted constant variable: a3977 
o|inlining procedure: k3992 
o|inlining procedure: k4001 
o|inlining procedure: k4001 
o|inlining procedure: k4024 
o|contracted procedure: "(chicken-install.scm:430) g710717" 
o|inlining procedure: k4024 
o|inlining procedure: k3992 
o|inlining procedure: k4090 
o|inlining procedure: k4090 
o|propagated global variable: g699701 main#*eggs+dirs+vers* 
o|inlining procedure: k4111 
o|inlining procedure: k4111 
o|substituted constant variable: a4124 
o|substituted constant variable: a4126 
o|inlining procedure: k4218 
o|inlining procedure: k4218 
o|inlining procedure: k4465 
o|contracted procedure: "(chicken-install.scm:454) g790797" 
o|inlining procedure: k4223 
o|inlining procedure: k4223 
o|contracted procedure: "(chicken-install.scm:465) main#outdated-dependencies" 
o|inlining procedure: k3377 
o|inlining procedure: k3377 
o|inlining procedure: k3418 
o|inlining procedure: k3418 
o|inlining procedure: k3430 
o|inlining procedure: k3430 
o|propagated global variable: g501503 main#*hacks* 
o|contracted procedure: "(chicken-install.scm:290) main#meta-dependencies" 
o|inlining procedure: k3076 
o|inlining procedure: k3076 
o|inlining procedure: k4281 
o|inlining procedure: k4313 
o|contracted procedure: "(chicken-install.scm:487) g850857" 
o|inlining procedure: k4313 
o|inlining procedure: k4281 
o|propagated global variable: tmp843845 main#*force* 
o|inlining procedure: k4340 
o|propagated global variable: tmp843845 main#*force* 
o|inlining procedure: k4340 
o|contracted procedure: "(chicken-install.scm:482) main#make-replace-extension-question" 
o|inlining procedure: k3767 
o|inlining procedure: k3767 
o|substituted constant variable: a3781 
o|substituted constant variable: a3782 
o|inlining procedure: k3762 
o|inlining procedure: k3762 
o|inlining procedure: k4397 
o|contracted procedure: "(chicken-install.scm:470) g822831" 
o|inlining procedure: k4378 
o|inlining procedure: k4378 
o|inlining procedure: k4397 
o|contracted procedure: "(chicken-install.scm:462) main#check-platform" 
o|inlining procedure: k4517 
o|inlining procedure: k4517 
o|inlining procedure: k4536 
o|inlining procedure: k4536 
o|contracted procedure: k4554 
o|inlining procedure: k4564 
o|contracted procedure: k4573 
o|inlining procedure: k4564 
o|inlining procedure: k4593 
o|inlining procedure: k4593 
o|inlining procedure: k4604 
o|contracted procedure: k4613 
o|inlining procedure: k4604 
o|inlining procedure: k4465 
o|propagated global variable: g796798 main#*eggs+dirs+vers* 
o|inlining procedure: k4488 
o|contracted procedure: "(chicken-install.scm:437) g748755" 
o|inlining procedure: k4144 
o|contracted procedure: "(chicken-install.scm:438) g764765" 
o|inlining procedure: k4144 
o|contracted procedure: "(chicken-install.scm:446) main#try-default-sources" 
o|contracted procedure: k3711 
o|inlining procedure: k3708 
o|contracted procedure: "(chicken-install.scm:369) main#try-extension" 
o|inlining procedure: k3484 
o|inlining procedure: k3484 
o|inlining procedure: k3508 
o|inlining procedure: k3508 
o|inlining procedure: k3526 
o|inlining procedure: k3526 
o|inlining procedure: k3535 
o|inlining procedure: k3535 
o|inlining procedure: k3544 
o|inlining procedure: k3544 
o|contracted procedure: k3579 
o|propagated global variable: r3580 main#*retrieve-only* 
o|inlining procedure: k3729 
o|inlining procedure: k3729 
o|inlining procedure: k3708 
o|contracted procedure: "(chicken-install.scm:445) main#override-version" 
o|inlining procedure: k3875 
o|substituted constant variable: a3892 
o|substituted constant variable: a3893 
o|inlining procedure: k3875 
o|inlining procedure: k3870 
o|inlining procedure: k3870 
o|inlining procedure: k3956 
o|inlining procedure: k3956 
o|inlining procedure: k4488 
o|inlining procedure: k5433 
o|inlining procedure: k5433 
o|inlining procedure: k5821 
o|inlining procedure: k5821 
o|inlining procedure: k5843 
o|inlining procedure: k5843 
o|inlining procedure: k5877 
o|inlining procedure: k5877 
o|inlining procedure: k5896 
o|contracted procedure: "(chicken-install.scm:723) g14151416" 
o|inlining procedure: k5913 
o|inlining procedure: k5913 
o|inlining procedure: k5896 
o|inlining procedure: k6025 
o|inlining procedure: k6025 
o|inlining procedure: k6036 
o|inlining procedure: k6036 
o|merged explicitly consed rest parameter: args1498 
o|inlining procedure: k6154 
o|inlining procedure: k6169 
o|inlining procedure: k6169 
o|inlining procedure: k6154 
o|inlining procedure: k6190 
o|inlining procedure: k6190 
o|inlining procedure: k7379 
o|inlining procedure: k7379 
o|contracted procedure: "(chicken-install.scm:1065) main#main" 
o|inlining procedure: k6217 
o|inlining procedure: k6232 
o|contracted procedure: "(chicken-install.scm:853) main#update-db" 
o|inlining procedure: k5509 
o|contracted procedure: "(chicken-install.scm:707) g13651372" 
o|inlining procedure: k5509 
o|inlining procedure: k5617 
o|inlining procedure: k5617 
o|inlining procedure: k5652 
o|inlining procedure: k5652 
o|substituted constant variable: a5726 
o|substituted constant variable: a5727 
o|inlining procedure: k5782 
o|inlining procedure: k5782 
o|inlining procedure: k6232 
o|contracted procedure: "(chicken-install.scm:854) main#scan-directory" 
o|inlining procedure: k5999 
o|contracted procedure: "(chicken-install.scm:734) g14521459" 
o|inlining procedure: k5999 
o|inlining procedure: k6253 
o|contracted procedure: "(chicken-install.scm:890) main#list-available-extensions" 
o|inlining procedure: k6121 
o|inlining procedure: k6121 
o|inlining procedure: k6253 
o|consed rest parameter at call site: "(chicken-install.scm:893) main#show-depends" 2 
o|inlining procedure: k6269 
o|consed rest parameter at call site: "(chicken-install.scm:895) main#show-depends" 2 
o|inlining procedure: k6269 
o|contracted procedure: "(chicken-install.scm:897) main#install" 
o|inlining procedure: k4854 
o|consed rest parameter at call site: "(chicken-install.scm:644) main#command" 2 
o|inlining procedure: k4939 
o|inlining procedure: k4939 
o|contracted procedure: k5022 
o|inlining procedure: k5019 
o|inlining procedure: k5019 
o|inlining procedure: k5031 
o|inlining procedure: k5031 
o|contracted procedure: "(chicken-install.scm:628) main#make-install-command" 
o|substituted constant variable: a4671 
o|substituted constant variable: a4672 
o|substituted constant variable: a4748 
o|substituted constant variable: a4749 
o|substituted constant variable: a4769 
o|substituted constant variable: a4770 
o|substituted constant variable: a4787 
o|substituted constant variable: a4788 
o|consed rest parameter at call site: "(chicken-install.scm:542) main#get-prefix" 1 
o|substituted constant variable: a4809 
o|substituted constant variable: a4810 
o|consed rest parameter at call site: "(chicken-install.scm:537) main#get-prefix" 1 
o|inlining procedure: k4827 
o|inlining procedure: k4827 
o|propagated global variable: tmp906908 main#*deploy* 
o|inlining procedure: k4836 
o|propagated global variable: tmp906908 main#*deploy* 
o|inlining procedure: k4836 
o|contracted procedure: "(chicken-install.scm:627) main#delete-stale-binaries" 
o|inlining procedure: k5121 
o|inlining procedure: k5121 
o|consed rest parameter at call site: "(chicken-install.scm:613) main#command" 2 
o|inlining procedure: k5192 
o|inlining procedure: k5192 
o|inlining procedure: k5209 
o|inlining procedure: k5209 
o|substituted constant variable: a5239 
o|substituted constant variable: a5240 
o|contracted procedure: k5241 
o|inlining procedure: k4854 
o|inlining procedure: k5281 
o|inlining procedure: k5281 
o|propagated global variable: out10681072 ##sys#standard-error 
o|substituted constant variable: a5316 
o|substituted constant variable: a5317 
o|propagated global variable: out10681072 ##sys#standard-error 
o|inlining procedure: k5340 
o|contracted procedure: "(chicken-install.scm:582) g10411050" 
o|inlining procedure: k5340 
o|inlining procedure: k5387 
o|inlining procedure: k5387 
o|inlining procedure: k6289 
o|inlining procedure: k6289 
o|inlining procedure: k6301 
o|inlining procedure: k6323 
o|inlining procedure: k6323 
o|propagated global variable: tmp15401542 main#*force* 
o|propagated global variable: tmp15401542 main#*force* 
o|substituted constant variable: a6366 
o|substituted constant variable: a6367 
o|contracted procedure: "(chicken-install.scm:859) main#installed-extensions" 
o|inlining procedure: k6067 
o|inlining procedure: k6067 
o|contracted procedure: "(chicken-install.scm:762) main#repo-path" 
o|inlining procedure: k2386 
o|substituted constant variable: a2404 
o|substituted constant variable: a2405 
o|inlining procedure: k2386 
o|inlining procedure: k6301 
o|contracted procedure: k6387 
o|inlining procedure: k6393 
o|inlining procedure: k6423 
o|contracted procedure: "(chicken-install.scm:873) g15951604" 
o|inlining procedure: k6423 
o|inlining procedure: k6393 
o|contracted procedure: "(chicken-install.scm:856) main#load-defaults" 
o|contracted procedure: k2472 
o|inlining procedure: k2483 
o|contracted procedure: k2492 
o|contracted procedure: k2501 
o|inlining procedure: k2498 
o|inlining procedure: k2498 
o|substituted constant variable: a2512 
o|substituted constant variable: a2513 
o|inlining procedure: k2483 
o|inlining procedure: k2566 
o|inlining procedure: k2623 
o|inlining procedure: k2623 
o|inlining procedure: k2566 
o|inlining procedure: k2668 
o|inlining procedure: k2668 
o|inlining procedure: k2691 
o|inlining procedure: k2691 
o|substituted constant variable: a2700 
o|inlining procedure: k2713 
o|inlining procedure: k2713 
o|inlining procedure: k2745 
o|inlining procedure: k2745 
o|substituted constant variable: a2804 
o|substituted constant variable: a2806 
o|substituted constant variable: a2808 
o|substituted constant variable: a2810 
o|substituted constant variable: a2812 
o|substituted constant variable: a2814 
o|inlining procedure: k2466 
o|inlining procedure: k2835 
o|inlining procedure: k2835 
o|inlining procedure: k2466 
o|inlining procedure: k6217 
o|substituted constant variable: a6483 
o|inlining procedure: k6479 
o|inlining procedure: k6479 
o|substituted constant variable: a6498 
o|substituted constant variable: a6509 
o|inlining procedure: k6505 
o|inlining procedure: k6505 
o|substituted constant variable: a6523 
o|substituted constant variable: a6539 
o|inlining procedure: k6535 
o|inlining procedure: k6535 
o|substituted constant variable: a6553 
o|substituted constant variable: a6582 
o|inlining procedure: k6578 
o|inlining procedure: k6578 
o|substituted constant variable: a6615 
o|substituted constant variable: a6661 
o|inlining procedure: k6657 
o|inlining procedure: k6657 
o|substituted constant variable: a6676 
o|substituted constant variable: a6691 
o|inlining procedure: k6687 
o|inlining procedure: k6687 
o|substituted constant variable: a6705 
o|contracted procedure: "(chicken-install.scm:949) main#init-repository" 
o|consed rest parameter at call site: "(chicken-install.scm:212) main#command" 2 
o|substituted constant variable: main#+default-repository-files+ 
o|inlining procedure: k2984 
o|inlining procedure: k2984 
o|propagated global variable: g406408 main#+default-repository-files+ 
o|substituted constant variable: a6733 
o|inlining procedure: k6730 
o|inlining procedure: k6730 
o|substituted constant variable: a6763 
o|substituted constant variable: a6800 
o|inlining procedure: k6797 
o|inlining procedure: k6797 
o|substituted constant variable: a6834 
o|substituted constant variable: a6845 
o|inlining procedure: k6842 
o|inlining procedure: k6842 
o|substituted constant variable: a6856 
o|substituted constant variable: a6867 
o|inlining procedure: k6864 
o|inlining procedure: k6864 
o|substituted constant variable: a6878 
o|substituted constant variable: a6889 
o|inlining procedure: k6886 
o|inlining procedure: k6886 
o|substituted constant variable: a6915 
o|substituted constant variable: a6941 
o|inlining procedure: k6938 
o|inlining procedure: k6938 
o|substituted constant variable: a6972 
o|substituted constant variable: a6986 
o|inlining procedure: k6983 
o|inlining procedure: k6983 
o|substituted constant variable: a6997 
o|substituted constant variable: a7008 
o|inlining procedure: k7005 
o|inlining procedure: k7005 
o|substituted constant variable: a7019 
o|substituted constant variable: a7030 
o|inlining procedure: k7027 
o|inlining procedure: k7027 
o|substituted constant variable: a7056 
o|substituted constant variable: a7082 
o|inlining procedure: k7079 
o|inlining procedure: k7079 
o|substituted constant variable: a7093 
o|inlining procedure: k7101 
o|inlining procedure: k7116 
o|inlining procedure: k7146 
o|contracted procedure: "(chicken-install.scm:1027) g17301739" 
o|inlining procedure: k7146 
o|inlining procedure: k7116 
o|substituted constant variable: main#*short-options* 
o|substituted constant variable: a7198 
o|inlining procedure: k7101 
o|inlining procedure: k7230 
o|inlining procedure: k7230 
o|inlining procedure: k7252 
o|inlining procedure: k7252 
o|substituted constant variable: a7301 
o|substituted constant variable: a7303 
o|substituted constant variable: a7305 
o|substituted constant variable: a7308 
o|substituted constant variable: a7310 
o|substituted constant variable: a7312 
o|substituted constant variable: a7314 
o|substituted constant variable: a7316 
o|substituted constant variable: a7318 
o|substituted constant variable: a7320 
o|substituted constant variable: a7322 
o|substituted constant variable: a7324 
o|substituted constant variable: a7326 
o|inlining procedure: k7327 
o|inlining procedure: k7327 
o|substituted constant variable: a7331 
o|replaced variables: 921 
o|removed binding forms: 419 
o|Removed `not' forms: 2 
o|substituted constant variable: r29417432 
o|substituted constant variable: r30317436 
o|inlining procedure: k3098 
o|substituted constant variable: r31447446 
o|substituted constant variable: r31447446 
o|inlining procedure: k3143 
o|inlining procedure: k3143 
o|contracted procedure: k3195 
o|substituted constant variable: r31967458 
o|substituted constant variable: r33177466 
o|propagated global variable: a29077481 main#*default-location* 
o|propagated global variable: out677681 ##sys#standard-output 
o|substituted constant variable: r39937488 
o|substituted constant variable: r41127491 
o|substituted constant variable: r41127491 
o|inlining procedure: k4111 
o|inlining procedure: k4111 
o|substituted constant variable: r30777510 
o|substituted constant variable: r30777510 
o|propagated global variable: r43417516 main#*force* 
o|substituted constant variable: r45947535 
o|converted assignments to bindings: (fail885) 
o|substituted constant variable: r35277548 
o|substituted constant variable: r35367550 
o|substituted constant variable: r35457552 
o|inlining procedure: k6184 
o|inlining procedure: k6184 
o|substituted constant variable: r61707595 
o|substituted constant variable: r61557596 
o|removed side-effect free assignment to unused variable: main#*short-options* 
o|substituted constant variable: r73807599 
o|substituted constant variable: r73807599 
o|substituted constant variable: r73807601 
o|substituted constant variable: r73807601 
o|substituted constant variable: r50207625 
o|substituted constant variable: r50327628 
o|contracted procedure: k4827 
o|substituted constant variable: r48287630 
o|propagated global variable: r48377631 main#*deploy* 
o|inlining procedure: k4836 
o|substituted constant variable: r51937636 
o|propagated global variable: out10681072 ##sys#standard-error 
o|substituted constant variable: r60687654 
o|substituted constant variable: r26927673 
o|inlining procedure: k2752 
o|converted assignments to bindings: (broken244) 
o|substituted constant variable: g406408 
o|substituted constant variable: main#+default-repository-files+ 
o|inlining procedure: k7230 
o|simplifications: ((let . 2)) 
o|replaced variables: 38 
o|removed binding forms: 972 
o|removed conditional forms: 2 
o|Removed `not' forms: 1 
o|removed side-effect free assignment to unused variable: main#+default-repository-files+ 
o|inlining procedure: k2433 
o|inlining procedure: k2433 
o|propagated global variable: r24347856 main#*prefix* 
o|propagated global variable: r24347856 main#*prefix* 
o|inlining procedure: k2937 
o|substituted constant variable: r30997739 
o|substituted constant variable: r31447743 
o|inlining procedure: k3654 
o|inlining procedure: k4195 
o|substituted constant variable: r61857793 
o|contracted procedure: k4836 
o|propagated global variable: r4837 main#*host-extension* 
o|substituted constant variable: r48377816 
o|inlining procedure: k6286 
o|inlining procedure: k2815 
o|inlining procedure: k2815 
o|inlining procedure: "(chicken-install.scm:904) main#usage" 
o|inlining procedure: "(chicken-install.scm:921) main#usage" 
o|inlining procedure: "(chicken-install.scm:925) main#usage" 
o|inlining procedure: "(chicken-install.scm:929) main#usage" 
o|inlining procedure: "(chicken-install.scm:948) main#usage" 
o|inlining procedure: "(chicken-install.scm:952) main#usage" 
o|inlining procedure: "(chicken-install.scm:956) main#usage" 
o|inlining procedure: "(chicken-install.scm:961) main#usage" 
o|inlining procedure: "(chicken-install.scm:981) main#usage" 
o|inlining procedure: "(chicken-install.scm:985) main#usage" 
o|inlining procedure: "(chicken-install.scm:989) main#usage" 
o|inlining procedure: "(chicken-install.scm:1008) main#usage" 
o|inlining procedure: "(chicken-install.scm:1012) main#usage" 
o|inlining procedure: "(chicken-install.scm:1030) main#usage" 
o|inlining procedure: "(chicken-install.scm:1031) main#usage" 
o|replaced variables: 23 
o|removed binding forms: 79 
o|removed conditional forms: 1 
o|substituted constant variable: r24347855 
o|substituted constant variable: r24347855 
o|substituted constant variable: r29387857 
o|substituted constant variable: r29387857 
o|substituted constant variable: r29387857 
o|substituted constant variable: r41127761 
o|removed side-effect free assignment to unused variable: main#usage 
o|substituted constant variable: r28167914 
o|substituted constant variable: code15027918 
o|substituted constant variable: code15027923 
o|substituted constant variable: code15027928 
o|substituted constant variable: code15027933 
o|substituted constant variable: code15027940 
o|substituted constant variable: code15027945 
o|substituted constant variable: code15027950 
o|substituted constant variable: code15027955 
o|substituted constant variable: code15027960 
o|substituted constant variable: code15027965 
o|substituted constant variable: code15027970 
o|substituted constant variable: code15027975 
o|substituted constant variable: code15027980 
o|substituted constant variable: code15027987 
o|substituted constant variable: code15027992 
o|simplifications: ((let . 1)) 
o|removed binding forms: 33 
o|removed conditional forms: 3 
o|removed binding forms: 20 
o|simplifications: ((if . 48) (##core#call . 399)) 
o|  call simplifications:
o|    string=?
o|    char=?
o|    alist-cons	2
o|    ##sys#size	2
o|    fx>
o|    string->list
o|    memq
o|    string
o|    cddr	2
o|    =
o|    first
o|    length
o|    list-ref
o|    >
o|    caddr	3
o|    string->number
o|    apply
o|    ##sys#apply	5
o|    ##sys#structure?
o|    memv	6
o|    ##sys#setslot	10
o|    list	10
o|    ##sys#check-list	16
o|    pair?	54
o|    ##sys#slot	47
o|    ##sys#list	9
o|    set-car!
o|    list?	5
o|    string?	5
o|    symbol?	4
o|    cons	29
o|    ##sys#call-with-values	12
o|    values	17
o|    eq?	20
o|    equal?	6
o|    member	4
o|    cadr	41
o|    assq	10
o|    assoc	3
o|    cdr	13
o|    null?	9
o|    car	28
o|    not	12
o|contracted procedure: k2448 
o|contracted procedure: k2424 
o|contracted procedure: k2430 
o|contracted procedure: k2866 
o|contracted procedure: k2874 
o|contracted procedure: k2934 
o|contracted procedure: k2937 
o|contracted procedure: k3010 
o|contracted procedure: k3027 
o|contracted procedure: k3037 
o|contracted procedure: k3043 
o|contracted procedure: k3052 
o|contracted procedure: k3088 
o|contracted procedure: k3091 
o|contracted procedure: k3127 
o|contracted procedure: k3136 
o|contracted procedure: k3159 
o|contracted procedure: k3168 
o|contracted procedure: k3178 
o|contracted procedure: k3189 
o|contracted procedure: k3219 
o|contracted procedure: k3259 
o|contracted procedure: k3266 
o|contracted procedure: k3278 
o|contracted procedure: k3297 
o|contracted procedure: k3304 
o|contracted procedure: k3313 
o|contracted procedure: k3319 
o|contracted procedure: k3334 
o|contracted procedure: k3322 
o|contracted procedure: k3340 
o|contracted procedure: k3347 
o|contracted procedure: k3615 
o|contracted procedure: k3636 
o|contracted procedure: k3664 
o|contracted procedure: k36617865 
o|contracted procedure: k3654 
o|contracted procedure: k3661 
o|contracted procedure: k3671 
o|contracted procedure: k3685 
o|inlining procedure: k3681 
o|inlining procedure: k3681 
o|contracted procedure: k2889 
o|contracted procedure: k2904 
o|contracted procedure: k2896 
o|contracted procedure: k2921 
o|contracted procedure: k4127 
o|contracted procedure: k3972 
o|contracted procedure: k4004 
o|contracted procedure: k4015 
o|contracted procedure: k4027 
o|contracted procedure: k4037 
o|contracted procedure: k4041 
o|contracted procedure: k4046 
o|contracted procedure: k4070 
o|contracted procedure: k4075 
o|contracted procedure: k4093 
o|contracted procedure: k4103 
o|contracted procedure: k4107 
o|propagated global variable: g699701 main#*eggs+dirs+vers* 
o|contracted procedure: k4114 
o|propagated global variable: out677681 ##sys#standard-output 
o|contracted procedure: k4120 
o|contracted procedure: k4212 
o|contracted procedure: k4456 
o|contracted procedure: k4468 
o|contracted procedure: k4478 
o|contracted procedure: k4482 
o|contracted procedure: k4453 
o|contracted procedure: k4226 
o|contracted procedure: k4230 
o|contracted procedure: k4264 
o|contracted procedure: k3365 
o|contracted procedure: k3380 
o|contracted procedure: k3394 
o|contracted procedure: k3414 
o|contracted procedure: k3418 
o|contracted procedure: k3433 
o|contracted procedure: k3443 
o|contracted procedure: k3447 
o|propagated global variable: g501503 main#*hacks* 
o|contracted procedure: k4372 
o|contracted procedure: k4388 
o|contracted procedure: k4368 
o|contracted procedure: k4275 
o|contracted procedure: k4301 
o|contracted procedure: k4316 
o|contracted procedure: k4326 
o|contracted procedure: k4330 
o|contracted procedure: k4337 
o|contracted procedure: k3858 
o|contracted procedure: k3749 
o|contracted procedure: k3759 
o|contracted procedure: k3816 
o|contracted procedure: k3820 
o|contracted procedure: k3770 
o|contracted procedure: k3812 
o|contracted procedure: k3832 
o|contracted procedure: k3835 
o|contracted procedure: k3854 
o|contracted procedure: k4354 
o|contracted procedure: k4400 
o|contracted procedure: k4403 
o|contracted procedure: k4414 
o|contracted procedure: k4426 
o|contracted procedure: k4381 
o|contracted procedure: k4520 
o|contracted procedure: k4530 
o|contracted procedure: k4539 
o|contracted procedure: k4649 
o|contracted procedure: k4584 
o|contracted procedure: k4590 
o|contracted procedure: k4607 
o|contracted procedure: k4629 
o|contracted procedure: k4645 
o|contracted procedure: k4636 
o|contracted procedure: k4561 
o|contracted procedure: k4445 
o|propagated global variable: g796798 main#*eggs+dirs+vers* 
o|contracted procedure: k4491 
o|contracted procedure: k4501 
o|contracted procedure: k4505 
o|contracted procedure: k4141 
o|contracted procedure: k4150 
o|contracted procedure: k4208 
o|contracted procedure: k4160 
o|contracted procedure: k3553 
o|contracted procedure: k3481 
o|contracted procedure: k3529 
o|contracted procedure: k3538 
o|contracted procedure: k3547 
o|contracted procedure: k3576 
o|contracted procedure: k4189 
o|contracted procedure: k4185 
o|contracted procedure: k4192 
o|contracted procedure: k4195 
o|contracted procedure: k3867 
o|contracted procedure: k3919 
o|contracted procedure: k3923 
o|contracted procedure: k3929 
o|contracted procedure: k3940 
o|contracted procedure: k3936 
o|contracted procedure: k3951 
o|contracted procedure: k3959 
o|contracted procedure: k5824 
o|contracted procedure: k5837 
o|contracted procedure: k5846 
o|contracted procedure: k5859 
o|contracted procedure: k5863 
o|contracted procedure: k5901 
o|contracted procedure: k5904 
o|contracted procedure: k5916 
o|contracted procedure: k5919 
o|contracted procedure: k5930 
o|contracted procedure: k5942 
o|contracted procedure: k5964 
o|contracted procedure: k6028 
o|contracted procedure: k6157 
o|contracted procedure: k6181 
o|contracted procedure: k6198 
o|contracted procedure: k6193 
o|contracted procedure: k6220 
o|contracted procedure: k6226 
o|contracted procedure: k5512 
o|contracted procedure: k5522 
o|contracted procedure: k5526 
o|contracted procedure: k5548 
o|contracted procedure: k5552 
o|contracted procedure: k5558 
o|contracted procedure: k5589 
o|contracted procedure: k5592 
o|contracted procedure: k5605 
o|contracted procedure: k5608 
o|contracted procedure: k5620 
o|contracted procedure: k5623 
o|contracted procedure: k5634 
o|contracted procedure: k5646 
o|contracted procedure: k5655 
o|contracted procedure: k5658 
o|contracted procedure: k5669 
o|contracted procedure: k5681 
o|contracted procedure: k5753 
o|contracted procedure: k5785 
o|contracted procedure: k5795 
o|contracted procedure: k5799 
o|contracted procedure: k5990 
o|contracted procedure: k6002 
o|contracted procedure: k6012 
o|contracted procedure: k6016 
o|contracted procedure: k5980 
o|contracted procedure: k5976 
o|contracted procedure: k4895 
o|contracted procedure: k4955 
o|contracted procedure: k5098 
o|contracted procedure: k5102 
o|contracted procedure: k5106 
o|contracted procedure: k4663 
o|contracted procedure: k4692 
o|contracted procedure: k4696 
o|contracted procedure: k4700 
o|contracted procedure: k4704 
o|contracted procedure: k4730 
o|contracted procedure: k4741 
o|contracted procedure: k4762 
o|contracted procedure: k5423 
o|contracted procedure: k5427 
o|contracted procedure: k5410 
o|contracted procedure: k5124 
o|contracted procedure: k5149 
o|contracted procedure: k5185 
o|contracted procedure: k5199 
o|contracted procedure: k5203 
o|contracted procedure: k5206 
o|contracted procedure: k5244 
o|contracted procedure: k5265 
o|contracted procedure: k5268 
o|contracted procedure: k5309 
o|contracted procedure: k5284 
o|contracted procedure: k5294 
o|contracted procedure: k5298 
o|contracted procedure: k5302 
o|contracted procedure: k5306 
o|contracted procedure: k5334 
o|contracted procedure: k5343 
o|contracted procedure: k5369 
o|contracted procedure: k5365 
o|contracted procedure: k5346 
o|contracted procedure: k5357 
o|contracted procedure: k5390 
o|contracted procedure: k6298 
o|contracted procedure: k6314 
o|contracted procedure: k6326 
o|contracted procedure: k6329 
o|contracted procedure: k6340 
o|contracted procedure: k6352 
o|contracted procedure: k6381 
o|contracted procedure: k6055 
o|contracted procedure: k6058 
o|contracted procedure: k6061 
o|contracted procedure: k6064 
o|contracted procedure: k6076 
o|contracted procedure: k2389 
o|contracted procedure: k6396 
o|contracted procedure: k6426 
o|contracted procedure: k6429 
o|contracted procedure: k6440 
o|contracted procedure: k6452 
o|contracted procedure: k6414 
o|contracted procedure: k2480 
o|contracted procedure: k2486 
o|contracted procedure: k2545 
o|contracted procedure: k2541 
o|contracted procedure: k2537 
o|contracted procedure: k2533 
o|contracted procedure: k2553 
o|contracted procedure: k2561 
o|contracted procedure: k2569 
o|contracted procedure: k2601 
o|contracted procedure: k2614 
o|contracted procedure: k2626 
o|contracted procedure: k2629 
o|contracted procedure: k2640 
o|contracted procedure: k2652 
o|contracted procedure: k2658 
o|contracted procedure: k2678 
o|contracted procedure: k2682 
o|contracted procedure: k2688 
o|contracted procedure: k2694 
o|contracted procedure: k2704 
o|contracted procedure: k2716 
o|contracted procedure: k2719 
o|contracted procedure: k2730 
o|contracted procedure: k2742 
o|contracted procedure: k2748 
o|contracted procedure: k2762 
o|contracted procedure: k2766 
o|contracted procedure: k2773 
o|contracted procedure: k2781 
o|contracted procedure: k2789 
o|contracted procedure: k2797 
o|contracted procedure: k2821 
o|contracted procedure: k2838 
o|contracted procedure: k2848 
o|contracted procedure: k2852 
o|contracted procedure: k6464 
o|contracted procedure: k6470 
o|contracted procedure: k6510 
o|contracted procedure: k6524 
o|contracted procedure: k6540 
o|contracted procedure: k6554 
o|contracted procedure: k6561 
o|contracted procedure: k6570 
o|contracted procedure: k6583 
o|contracted procedure: k6600 
o|contracted procedure: k6603 
o|contracted procedure: k6616 
o|contracted procedure: k6623 
o|contracted procedure: k6649 
o|contracted procedure: k6662 
o|contracted procedure: k6692 
o|contracted procedure: k6706 
o|contracted procedure: k6719 
o|contracted procedure: k2952 
o|contracted procedure: k2975 
o|contracted procedure: k2987 
o|contracted procedure: k2997 
o|contracted procedure: k3001 
o|contracted procedure: k6722 
o|contracted procedure: k6745 
o|contracted procedure: k6749 
o|contracted procedure: k6752 
o|contracted procedure: k6765 
o|contracted procedure: k6772 
o|contracted procedure: k6786 
o|contracted procedure: k6789 
o|contracted procedure: k6806 
o|contracted procedure: k6820 
o|contracted procedure: k6823 
o|contracted procedure: k6895 
o|contracted procedure: k6904 
o|contracted procedure: k6921 
o|contracted procedure: k6930 
o|contracted procedure: k6954 
o|contracted procedure: k6958 
o|contracted procedure: k6961 
o|contracted procedure: k6974 
o|contracted procedure: k7036 
o|contracted procedure: k7045 
o|contracted procedure: k7062 
o|contracted procedure: k7071 
o|contracted procedure: k7195 
o|contracted procedure: k7110 
o|contracted procedure: k7135 
o|contracted procedure: k7149 
o|contracted procedure: k7175 
o|contracted procedure: k7171 
o|contracted procedure: k7152 
o|contracted procedure: k7163 
o|contracted procedure: k7203 
o|contracted procedure: k7210 
o|contracted procedure: k7219 
o|contracted procedure: k7261 
o|contracted procedure: k7265 
o|contracted procedure: k7285 
o|contracted procedure: k7293 
o|simplifications: ((if . 1) (let . 69)) 
o|removed binding forms: 339 
o|inlining procedure: k2900 
o|inlining procedure: k2900 
o|inlining procedure: k4406 
o|inlining procedure: k4406 
o|inlining procedure: k5922 
o|inlining procedure: k5922 
o|inlining procedure: k5626 
o|inlining procedure: k5626 
o|inlining procedure: k5661 
o|inlining procedure: k5661 
o|inlining procedure: k5261 
o|inlining procedure: k5261 
o|inlining procedure: k5349 
o|inlining procedure: k5349 
o|inlining procedure: k6332 
o|inlining procedure: k6332 
o|inlining procedure: k6432 
o|inlining procedure: k6432 
o|inlining procedure: k2632 
o|inlining procedure: k2632 
o|inlining procedure: k2722 
o|inlining procedure: k2722 
o|inlining procedure: k7155 
o|inlining procedure: k7155 
o|replaced variables: 86 
o|removed binding forms: 1 
o|simplifications: ((if . 1)) 
o|replaced variables: 4 
o|removed binding forms: 69 
o|replaced variables: 40 
o|removed binding forms: 4 
o|removed binding forms: 10 
o|direct leaf routine/allocation: main#deps 0 
o|direct leaf routine/allocation: g13131322 9 
o|direct leaf routine/allocation: g13401349 9 
o|contracted procedure: "(chicken-install.scm:426) k4053" 
o|contracted procedure: "(chicken-install.scm:426) k4057" 
o|contracted procedure: "(chicken-install.scm:232) k3068" 
o|contracted procedure: "(chicken-install.scm:233) k3072" 
o|contracted procedure: "(chicken-install.scm:234) k3076" 
o|contracted procedure: "(chicken-install.scm:701) k5642" 
o|contracted procedure: "(chicken-install.scm:700) k5677" 
o|removed binding forms: 7 
o|replaced variables: 14 
o|removed binding forms: 6 
o|customizable procedures: (k6473 k7104 g17601761 k7223 map-loop17241749 main#setup-proxy g400407 for-each-loop399410 loop1522 g249256 for-each-loop248361 k2755 g338347 map-loop332352 g293302 map-loop287323 broken244 map-loop15891607 g14861487 map-loop15581575 k4848 map-loop10351060 g10811089 for-each-loop10801205 k4883 k5212 setup1106 k4659 main#get-prefix tmp11121121 tmp11391148 main#command main#show-depends for-each-loop14511462 g12461253 for-each-loop12451282 map-loop13071325 map-loop13341352 for-each-loop13641376 main#$system map-loop14201437 canonical1389 g643644 k3881 main#with-default-sources k3487 k3499 k3511 for-each-loop747782 k4567 fail885 main#apply-mappings k4422 map-loop816834 g612613 for-each-loop849861 g495502 for-each-loop494505 loop510 for-each-loop789875 main#retrieve g693700 for-each-loop692733 main#cleanup for-each-loop709727 k2911 k3645 trying-sources574 k3120 k3210 k3182 scan451 main#check-dependency main#ext-version k3013 main#resolve-location) 
o|calls to known targets: 260 
o|identified direct recursive calls: f_2864 1 
o|identified direct recursive calls: f_3610 1 
o|identified direct recursive calls: f_5615 2 
o|identified direct recursive calls: f_5650 2 
o|identified direct recursive calls: f_5338 2 
o|identified direct recursive calls: f_7144 2 
o|fast box initializations: 29 
o|fast global references: 181 
o|fast global assignments: 103 
o|dropping unused closure argument: f_3005 
o|dropping unused closure argument: f_6152 
o|dropping unused closure argument: f_6131 
o|dropping unused closure argument: f_3083 
o|dropping unused closure argument: f_3601 
o|dropping unused closure argument: f_5431 
o|dropping unused closure argument: f_2864 
o|dropping unused closure argument: f_5816 
o|dropping unused closure argument: f_5819 
o|dropping unused closure argument: f_2422 
o|dropping unused closure argument: f_6020 
o|dropping unused closure argument: f_3964 
o|dropping unused closure argument: f_2932 
o|dropping unused closure argument: f_4134 
*/
/* end of file */
